const Contribution = artifacts.require( "./Contribution.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Contribution" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xC22462d4bC50952B061C9E6c585Fdd9A04d0d75A", "0x00677d06f75A0581262BACb3De91e1283309772d", "0x45fde77ff768aa83dF468fB1C6EbC5f2BB21DCea", "0x6B6334baA01fA10c05fcfE36cAa2653dA483c9E7", "0xeF370dfe413eA48b457D4E00ffe1aEbB4032cA4D", "0xd4c435F5B09F855C3317c8524Cb1F586E42795fa", "0x0cF3Da2058c228328a2427ABBcb25f3dC5c14dB3", "0xB25F18f2dc7F5069CcA91BF008b59cDA442C23Ec", "0x32c5c3b5D2EB4A60Ba0E3EACc69A51d8356fc7E0", "0x838b07F4304795cB5f9aA85DAcF194765B3E469a", "0x552B76F29F0b6f5bdDC2e5AD6c0256Bf5A7b5406", "0x434003dEA89C6Ed623444bBD11F8313D26f65AD7", "0x651664BCDb4DAfFb296Bd248Cbc0c57595d4F9E1", "0x2caa8CAf504397d53933514A10E1330b04bF14f0", "0xad6Bb7A25b6f35B921705d99485A07284F315f5a", "0xeD038477488A703CDE6485D6795beB2Bb8955dc2", "0xF53e02ced4bB46526196095f850AA424272Ad077", "0xD2E8827d4b1c44f64d1FA01BfBC14DC8545eCa41", "0x009E51B0D7A06b3A8A22dDc326E1981d417A8B4a", "0x15cC96acd61F3F564c8aC913114213cc3D666b68", "0xa9d8B2FD9AA8209e6c91780302413D33A515ad19", "0x8676F92151771425C5A506A60105Ee1a8e877456", "0x11dF9c71b1Ef9b69607A937F50a625e258733200", "0x009e02b21aBEFc7ECC1F2B11700b49106D7D552b", "0x213Ee0a9390921F5A0178Bf421D45a1985ee38A4", "0xb875f205eb38Ef3d0A1801AEa1dF08AE78933Dad", "0xba4115E85d09E3eF52c788043372cEA95368548F", "0xce632aEf4C0822b97f2862b3Dc9A70D3AC06faA5", "0x009D06cc6B11FA75412C3cda6Da63813BbbDAfaf", "0x10388A4db0b0EEf4afd11B3e58A63EdA90Fba1ca", "0x79B4B5287adD11272a0C626AFc3006844e5BdFCD", "0x22b2B07B38FE213ba32012aB30f05ED98F29ED31", "0x447c2F2A93B0a7B76A880639712Ab9DD1963D44C", "0xF8cdE04Ac5c33F235EB3CB138b301379bCF33FfF", "0x622B2C840d856181661482a2f7d9a5A41E0F992a", "0x22aAE1D3CaEbAAbAbe90016fCaDe68652414B0e0", "0xc7dF8a3b4eab37bAb57F90f60d17D8bec01f568C", "0xF0F646f6B61f57AD28D2Ab3A8c21110011D1A64c", "0x84484B1B89941A1DB3a3222Bcd75823095Abaca7", "0x1DA422edED980a4E633da67BD30C60765E872CBA", "0x0676949E2eE6574e7d1A80870CAbdE22724f2121", "0x8b22030f19431fEac38BB5201F16F3935e7cD447", "0x392028F4A6a7322B00638039663B2118Dac92263", "0xed50B8B0aDf6b37Ad15635dbC7e53F4a705014B9", "0x0b6DF62a52e9c60f07fc8B4d4F90Cab716367fb7", "0x55B22Ac7DDaD396E703f38d04009540490D122bF", "0xc458DEF22aED52417c4b78eAD6841D382aA9d427", "0x42b7deC83f4dfDAA70416d7a7e1951ad8e6e7847", "0xc967E3C453CAA4583451E2F7a4080e56e165E202", "0xa722F9F5D744D508C155fCEb9245CA57B5D13Bb5", "0x0024d5549BF5C3aCa24f1CEAeCF50f50C9D92bD7", "0x127FBBAEbCe7c6a85fbB2f744Ed021AD52eed6FD", "0x647bECA433382E60CfC9Adbb3a8bBd2aF3d053f8", "0xa145AdDb0a24f0C4697189a02EAdb006BE244D49", "0x572a26bF9358c099CC2FB0Be9c8B99499acA42C5", "0x99784406B8c01A9f752B86b5e6c9180eF7fE6B05", "0xD723329b502AfFBC63731fADF546e4FAE7D5ee7f", "0x1ef8598BeBc15Ba24F3a9fE2255B20B54fBB15a5", "0x9b73899cf3C29aDDE3086F993B001AB733723A38", "0xb927340C680a315677b918003FB6189B6D1Ca4aA", "0x924C251902924c7DBd4cBF166d42757fB2d146cb", "0x0009B5Fb5d267C0b91A33cc7cE69aaB9B5c62eDb", "0xf21749506CDC7C684b096bA172c99A8878a816FB", "0xc841Cd0ad77D714b3c6Ad86C1160034a1F11fEd3", "0x4AaDDB83FA8f8C8758d38F74F5564fB549846b31", "0x8e9Fe6f4717ea81a5BB2a249Af41B16E781DE4B2", "0xba52465fcb173E1965171B31BdD0c9Aade3609D2", "0xc0D3a8d939d8653F0Fd8fE7a0646DD3884293466", "0x0960Da039bb8151cacfeF620476e8bAf34Bd9565", "0xB9D00378957f680900C9961CfC1814BC1271c4c0", "0x3E77A7D70E3853E9EaEcDF8E3de78e94265fA8e5", "0x3384256F506520A2DC5d51Aa081e5016AC6e2730", "0x392257DAecc9b252529167214c9f8BA0a17B0e36", "0x00a96e78D4900Cb5F8C412C1437B15aaf81f6733", "0x006b65F5189599A187D4F4cC6661166aAaFa3ED4", "0x088Cca87b0D829B35EfEB6934ff807Cd3BEfc48B", "0x07895eBaD237645e1553dD195E870D2be9803a8D", "0x489554AB02c071D7279Cc1428592c1722aC5E33f", "0x501AC3B461e7517D07dCB5492679Cc7521AadD42", "0xFfe27b523078303768Ac6b2A9EBee8a22902FFaf", "0x3dE61a89290009B34000361cf94D9B7a218cf5eB", "0x1c74D52cA9D58f629E9b5bDFEE0fa82116DB047a", "0xD3438e11D5de4518dCef9A3C455fCB75DcC600Cf", "0x67e0887a3614Da0DC94b6B36bC787d7c528ec8c2", "0x00e7b744f07Fd1dC016ba84626C2c31edB15B9b7", "0x5f1D2141682745ec493876e13903562cac71b792", "0x10f77e56bDCcadE0B4542145e5C408F1f8Bf5AfB", "0x00db61875511c11e07ebe53edf787717410Fc916", "0x5f055DCAFBc494eB4d634744DD96B0813a718F99", "0x369342E4617cD365d7FFaCBEa47Ed1a143E48BeA", "0x7139cEEEF20464Fe9bD2BA713C8A68240f01711d", "0x704E0dE2534102E3102f358e6c78568d13053aaa", "0xCA568C15453844f78A5bEd1C7d74E5C81CcA557d", "0xF6D4d4DDbF3FC684d531B40c3c518D3825f2769d", "0x45d5eaB238d23e668A949EcdE1e77163C4275339", "0x33A96B5993F65e26Ad4f51b3d3CCEA513271B923", "0xCC6c95e8Bc9FE7B9dDccdeD787276b70728bD91D", "0x00b88dc7e00C5aD794595f208566bCc15d07f027", "0x9DC8a0886242B0Fd686D8f2A9Ed46516090B6fD3", "0x00f26Ece6c8716BDDeD31924B446C92ff388aEe2", "0x41fC0c45412422221ee6769F182cA9a344359e3F", "0xF482bEA9F562184Be993E9b1ac3D75efF57781cA", "0x0868411cA03e6655d7eE957089dc983d74b9Bf1A", "0x9F4cB6C14055163e9975Ff18E4230c2833F02726", "0xda6B22F0a07241448bEA9DcCd02B3b187E343664", "0xc4E3aAC985C8182e3DAc6c9b19eB606151fcd767", "0x3dD361b92Ef882C885E3E4a7d634C2D9DaEDEF85", "0xe4CbA77472F36A5Ee693b44c84989A1FA576992a", "0x00b6E47551b16D1919a74e2A6512fDe7675E15DA", "0x252FaC5e0f04d62AEf0556084c2C6E64FEef271E", "0xD1c5e193feb49a59c6Bd54b8AA28f22762F89D55", "0x39990eA12fD788062F16cE81b769Bbf0Ef9c2C8e", "0xd4E86be2d4ad7e987AB67ad679CEAeEC269573B6", "0x89a12ac6dE30463278eB4A0eEeBF2DA16eA9637d", "0x00bAb0D7068F8B2D753590949879E17FaF3F6088", "0x1EDeF22dCcdeD943A0Ddb453647723378C33410A", "0x55A1CaE7F45240680c83DbB7329046f894A71603", "0x00a888a4cAc1a5a82029bff090AadDB98407303A", "0x2FdEfc1c8F299E378473999707aA5eA7c8639af3", "0xBd9064fDb9a4274Df760f8Fc14abaF6B86D17f12", "0x4aa7269e78942F8B159Db827FDaC811587abcf51", "0xdE7799B2d6999aD6A752Aa0aF8B95FE41E725915", "0x3115aA1401d5Aba3220030D3db298cE8880a46B5", "0x0823c99DeBD091FE1A736Bd3888b1707ED820AEc", "0x2539b51EbDE65a75672aBcfE9439a706a99D18D1", "0x85c24edF1b51115CDf654c15FD29e1b32752e567", "0x04a782948d6ceA64d5F14D46C18Fb33470644Fd2", "0xf476E1267f86247cC908816F2E7ad5388C952Db0", "0xAab54b1b17Fd41fbAC81758e387bC8eca128cA88", "0x0B6121DDCE71373b3c02780b22CC78dD20D3A7f9", "0x59191198028f1e14d3aE814ebDae084f93a1746F", "0x229a55f621801934acb219478d556c7F128aCDe6", "0x9608a19685B95c49B86C859bEBAf3d1f0E8FfA1A", "0xc230cE5643a10702111572c938919C9f448c46D8", "0x3744C132637B13F7f410e0580a1fA2393875e444", "0x8c3720060f8cFDf8b8d4DA5698F4f51a48A0828a", "0x2561A6F4f32908F2BEf562987dA896701ec943Ae", "0x05939d370ce1A4f7d36B2b1c3c09d84eC4f7E9eB", "0x0593f77e9D19D4c322E18a24B89dfbFa311ea545", "0xDcc097955815c69b223865a050800dC44ecAF8aE", "0xffdD5bFe33C8fa18Af76b944e725B3A116467c64", "0x4995c29a93226c5858711F81E3B75eB2aa0a5a4e", "0x3C401C200233c07DD9BfdAc99edbc01068AFe118", "0xffc5b23D80b85c2a7a7DA49064d7354D09e5E3Cf", "0x9a73C36d924C197c6418A24ea986E5d3f7C1ddf3", "0x00bB85Eb9F8e166ACeF360942AC4e43DDa235f03", "0x00165307057322A93aDbe68050159Af11966778d", "0xB45d904431f0fC93F14eD273D7E8aCb71339207F", "0x0681516881536A06497017971c7c86128fAB5738", "0x34cc2861eeb213Da8bf366bECDfb319f16afF12C", "0x60ba6c590883AB3c06289eFf076F96B80065E3F5", "0xE835Ec939021Aa1189D4Ddf3AE1544b62F9579aB", "0x9A94771E7E73f9D8d6E880cfB12CAb4e9573C45E", "0x6D805c47cd158bEe253986CfBFCfCE34Fdb33eFe", "0xbaa68aa7b1257305Ab9D968E51786897E0e423b7", "0x6D0bb4cE7aCC1ba71Af6D1858deA64C6073dC27e", "0x07bD15dcb7F83045D3583Ae385B4B549951A33C2", "0x145663520246b70E32C96411B33F8dc71D4100dD", "0xBCCb13F64B2708F400304cBD10044C589C116925", "0xE414fEADDd562b0071810d1B1B4d8Bb85171632d", "0x5f9d89858fEe7De8F28E21e62650Bf1322C714f1", "0x7c0FBa9557B8F909Ab8D69d8DA1944501B6A9D07", "0xB1CcAB138E6C6a704F9Bf607A71c342CFc948053", "0x0e0193A44c0d7E36B8fAff8fD3d9004D5Bb5ff09", "0x00c2e468cd0f9576c6540F425Baf64969205b40c", "0x82e4D78C6c62D461251fA5A1D4Deb9F0fE378E30", "0x1bbCc79b91BeE48b60dA56329B7F0C5D797D56eD", "0x007d2f4FE301922c560D1a752836c4e99e0eD63C", "0xE9eBEE76A902b6536C0bddf79Ac4c4343e5bDBfb", "0xEc000C5461CdBc4497D61245176260671dB70d88", "0xA20AD2f8aD42831E9dC82C05715bcaAEc84F9ABb", "0xFf52C5c250D63E6903AA7b7bD4c256Bf47432602", "0x00582f083582f59A0dA86a0688332c77C7044a3A", "0x02C68E3dE38b00f958A53BD9182d09120312b2A2", "0x0e6EaD010B7249B46c56972A309D1376e53d9D50", "0x34A0Cd27e8489ad7346A9a40E2205CF6b715B364", "0x7fc796922627eED6FAF6C26E01A32c33B5Fc9131", "0x7F8E672A3079D3976ebC2b3CB5179dbD79863529", "0x70E8818a14d8841604497990BBd181170661a85E", "0x5dF3bbA2Cb0b3AA00fA940c14e2cc57F2Cba303a", "0x7C1B4e9d3dF68577655F67057A5076C9cdd8a7ED", "0xf190f0193B694D9d2bb865a66F0c17CBD8280c71", "0xa07B4b955C69aFBDB1e7C2eadF28E50BCc3f4C93", "0xE909E1C946C057d06B79CC72EBCB5B168c6E6D49", "0x76927E2CCAb0084BD19cEe74F78B63134b9d181E", "0xBE0B69eDC6E0aaae42b9964AF162F8A4A2FFe595", "0x6cB9E3274799ca43EC2582335867b9F7520D9F26", "0x22C8D09305D827F1CDF696D1b9Ee309227938F95", "0x5C72dA9CAd883D790eB1e4165CF2441B3bE165E2", "0xcb3bB2E2CBfa6Dc19C2bA39d7f9AAA022f0bdC8F", "0xba881a7b7F829D5c25BD120b3e80C640cD8ae0d6", "0xb46Ac18F8Fc29C552450E1Ba67272e8Dfc828FD1", "0x6e9Ec23Df252C5DEd1e83b2a19fc5d79759ACF03", "0x28091E33df862922F1a1Fc62e60AF9F791cb4deC", "0xE60C6d66c42B97300F116f34e2B971D8a627d557", "0x662a80DD9B873913CFdeEF75F771159A6782F3D8", "0x848C98731d0122e32217dcAfE0eE67842F3533e6", "0x76cd7F9Cb7030803fFf92875c49DF9aa8c558344", "0xD48505eE38C6E933Defa82E068d063b300781df8", "0x004BA25b9B23ac7b4DD583C7e6a8E811dD32e608", "0x43215241C3DEF445e151a881DB883a66c2df9bBe", "0x8c0114F7507485C2289cb4Fc7FAdb61d4e2F49B3", "0x2a980AfD3Cf9Ba8Bbb15ea10FE952d96641f0346", "0x76c265bDAa4350ED138735B7a514aDB1A89B71E2", "0x0A69945a4F4cd87B925a34FC9c641EFC1dA664D6", "0xeaA25AC8A4Cc52451917238638453737Af6e4a31", "0x717a58ED0eC76d4CFE0b64c0E112CE015653eDB2", "0x28472E097c91D75f6aa557c0223e50960078A6d0", "0x9D50Ca863D28c946A05560e9bD993Ba4C2d1F954", "0x28b54d4534052214f134A995663AF9C6bdAea435", "0x8215d8fdE5Eaf58901d01A438F7188016369b91f", "0xf5b9f5c093B63A609711fb56F6B8484013Ffa028", "0x1c2e28d5e50DeDd1dC8936d681B32D2458533D74", "0x6c27eA4B5d281E81e5A833a5E6e1C5A74F9B47be", "0xD78Fd123D2BC2Da7bB5621c753Dc665D3C0e85ac", "0x049503A94f506b601661D8bC792A2cC59Ea230d9", "0x0c6eAD592dd190072E898E807F2fC68E98bCd8Be", "0x047eB968d0dCe70280352d0834AB9f6b536da16F", "0x8F212180bF6B8178559a67268502057Fb0043Dd9", "0x9Faaa0efBe61bC445E1068aB1cD67f23B45D624f", "0xC6cc76eB55C49a839444800b66a66cBDDF76e3e0", "0xa39166DF6f039BA348D7cFa353280D19ddE04Cd8", "0xb0323032e7cc95e17555e9Fb37b33095EEe235f0", "0x78D8E8807F652B54AfE33B7645A26C5ffaE5291c", "0x3Dd932D51Fb898374E694D764d059d2E2453e4d1", "0xE7dc484e59f6b7ED74bc72a1129144F9Ea4Bf89A", "0x7eBe9268B8F7FF0B098a8567bF7490d33123DA4d", "0xF3CdF271cCaafB591372F81521Bd2019701dEf1B", "0x37E102AaB262f27e73a9733c7678D0D58ED7A5AB", "0xE055AFf35a3f212E713922E296d295fb50d6eDb9", "0x6317DAc8332F0B3Ef49146B45A6726cdb78C4DcF", "0xef243Aa4f940E72Eb1d7eBAB724672d88B4f18ed", "0x80259bc4E86f3FA837491838562e418a56A3359f", "0x2BAE4bf3595b96B2f07492B7d1622e3703E604F8", "0x0028673fc0a9532a5c0aF61EBB8369a4e5219EC0", "0x0B77E9fd0166Dd1A59FaD0d1393BFC41D2BC6f26", "0xe0dA8eD5B7b775b5fdF285131646fe2f54ef0005", "0xf70145fE48AB5606890A98d19949EdD2516Ea240", "0x9466c086239A0fd38932608572cEbb97D1D42Ee5", "0xf769dbD6d5C2cF4DB888f59C5768901411160E88", "0xa35b60fE8eB8184a379a0D0B726F3CeB57EE9073", "0x27dADEB9e5e35881402D54286AF63cc63505163A", "0x9Dac72188aEB760b60BEf84B85CfA5BB2DFD9B69", "0xe9080374375A1F92E2eDF6f314ea2Ec1800979Fe", "0x003Bb89E2cD29ACd745b11dc9D13a38BcCE6c242", "0x74C072d1Bd63e0B922D0BEFd79b3Ee1fCC3a8336", "0xCEF0E56B84aD7d5bE9edCB7Faf66f85AE83942A4", "0xA6d0c47Df7AF1EcDD555D08c44CA4F7186E6e982", "0x005Fe92d7A91a045fF6CFe888B0B982Cd3F2A06B", "0x678fb21b9736e6c7Da9f7d37a77Ab766bb2519c7", "0x2E15D7AA0650dE1009710FDd45C3468d75AE1392", "0xfd516Ec936908f1f409CD48C05fbBfaBaCdfA520", "0x94D9Cd17d85d2AfA8D71283d94386281f16612Bd", "0x07Ca04Dea1b05ef526F69F82661aa2bc911c7ab2", "0xEbeabcb3dd92973f863Ce54Bce5E1e4322777210", "0xb38Ecc6EC2fcaECFc8987f25ae58622a91A23034", "0x2565f8e0b33f2d3Bb1C0E2DD5fBb972dF48654c8", "0x428512bd5e9F8E486972C89B423EeD37D304d786", "0xb92F2E00983faA34B4AfaC034aA85569dF78039F", "0x23B991F7bE7Afc8706DCEF2f04288b44b455fEb7", "0x96F57B3b2aEe2F15198cC2862d17EB32591c0208", "0xAbD4277717fd22B4e91232578C34478546dc381f", "0xEdB34A82F00c71c2082171E4365ea85d422620AF", "0x67a01ab58Cc873bFBD93c89F2b0897E85007b772", "0xcf093b6DfCe969E640DbD38d7302cE2e7ca531dF", "0x54620853f4f0799beE70832B767fcb6eD5b48eBa", "0x7A836B45c06e57C65451C41168a7f269146B1B0D", "0x2d50a018E1C5194334D8CE52D7152D2aC99F7b37", "0x0d8571cF484De9f090EDB7e51882d60402212D83", "0xD1f982Eca739Bd2165ea085c379231646302EAe3", "0x0451B45ca19945C38AdC39bc91f45B3D518AA8e3", "0x002B254aBdcEf1F9Af4e56f0e9776Bc1fEeA1edc", "0x40692724326503b8Fdc8472Df7Ee658F4BdbFC89", "0x6c66ebb344C3251FbD49CF00B93ebb562F3637c6", "0x27570157D3B72560143AF4d8a4528117E2215575", "0x7837D0BfEC3AbD92A1720f21c77AEF0B71d0F58e", "0x61779AD9d36Ba354e235c59Fb48651AcE92F9FaE", "0xC08D21EB6000357b3d70fBEdaf6A1Ce5c94D6286", "0xA7E51Da6dF5079e42048f43fFb355952cbfD504D", "0xD93E1bd6d0716ECDEff07f59d31fdF3679250F3A", "0x6065043d769e88421e2592472A2394d4B5Ca1B44", "0xEfE628E9239bf3Dc14766aA465064E1784eDC052", "0x50f5Ff6683b508f356f97Beee5728A38abe3b51e", "0x9C232158b5E0f9A23bF9A399cD9197c7F131D13B", "0xC2e82B98Ebb92Cf36fAa85Fba798f838A86843d4", "0x8E6CeCa77bD9ae8a2C7f9d11870EC80bA6ab751C", "0x70E32ab40ffCf7d377ff89E51CCAD8F2223865ab"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "uint256"}], name: "tiers", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "foundersWallet", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "cnd", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalTokensSold", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "advisorsWallet", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "finalAllocation", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_investor", type: "address"}, {name: "_tier", type: "uint256"}], name: "isWhitelisted", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "contributionOpen", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "transferable", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "tierCount", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_investor", type: "address"}], name: "investorAmountTokensToBuy", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "October12_2017", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "leftForSale", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isCurrentTierCapReached", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "bountyWallet", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "contributionWallet", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "controller", outputs: [{name: "", type: "address"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_token", type: "address"}, {indexed: true, name: "_controller", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "ClaimedTokens", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_tierNumber", type: "uint256"}, {indexed: false, name: "_tierAddress", type: "address"}], name: "InitializedTier", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_tierCount", type: "uint256"}, {indexed: false, name: "_now", type: "uint256"}], name: "FinalizedTier", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_amount", type: "uint256"}], name: "Refund", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["ClaimedTokens(address,address,uint256)", "NewSale(address,uint256,uint256)", "InitializedTier(uint256,address)", "FinalizedTier(uint256,uint256)", "Refund(uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xf931edb47c50b4b4104c187b5814a9aef5f709e17e2ecf9617e860cacade929c", "0xa3ed4207b1480804a4590a74f4b9cc310dc0fc839af8d10e2141ca3b72fd9348", "0x4ce61604337bd51817e5c0fcc6750f9f529b9af602be0c3772fdd924b9351923", "0x6d3f008a218910723199a83b1200a39efd6a08b329d982e27eafd65bb938a568", "0x2e1897b0591d764356194f7a795238a87c1987c7a877568e50d829d547c92b97"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4254698 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4269942 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_contributionWallet", value: 4}, {type: "address", name: "_foundersWallet", value: 4}, {type: "address", name: "_advisorsWallet", value: 5}, {type: "address", name: "_bountyWallet", value: 6}], name: "Contribution", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "tiers", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tiers(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "foundersWallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "foundersWallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cnd", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cnd()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalTokensSold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalTokensSold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "advisorsWallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "advisorsWallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "finalAllocation", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "finalAllocation()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_investor", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_tier", value: random.range( maxRandom )}], name: "isWhitelisted", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isWhitelisted(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "contributionOpen", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contributionOpen()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "transferable", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "transferable()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tierCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tierCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_investor", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "investorAmountTokensToBuy", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorAmountTokensToBuy(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "October12_2017", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "October12_2017()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "leftForSale", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "leftForSale()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isCurrentTierCapReached", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isCurrentTierCapReached()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "bountyWallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bountyWallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "contributionWallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contributionWallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "controller", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "controller()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Contribution", function( accounts ) {

	it( "TEST: Contribution( addressList[4], addressList[4], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4254698", timeStamp: "1504947221", hash: "0xa391bb9809f37bae9341f54decd898ed8443808b31712d2f882a64de0ad4ec48", nonce: "16", blockHash: "0xbae195f646973f87468967a046f055cd4602f77d91b2ee60e81d4b90548d1bec", transactionIndex: "36", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: 0, value: "0", gas: "2940834", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0xc867cccb00000000000000000000000045fde77ff768aa83df468fb1c6ebc5f2bb21dcea00000000000000000000000045fde77ff768aa83df468fb1c6ebc5f2bb21dcea0000000000000000000000006b6334baa01fa10c05fcfe36caa2653da483c9e7000000000000000000000000ef370dfe413ea48b457d4e00ffe1aebb4032ca4d", contractAddress: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", cumulativeGasUsed: "3609835", gasUsed: "2450695", confirmations: "3450424"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_contributionWallet", value: addressList[4]}, {type: "address", name: "_foundersWallet", value: addressList[4]}, {type: "address", name: "_advisorsWallet", value: addressList[5]}, {type: "address", name: "_bountyWallet", value: addressList[6]}], name: "Contribution", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Contribution.new( addressList[4], addressList[4], addressList[5], addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1504947221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Contribution.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: initializeToken( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4254729", timeStamp: "1504947751", hash: "0xf974fc254bcad1e3b8f7e003b7fd24946f795b1b19e5b98c269d9dccfa568bc4", nonce: "18", blockHash: "0xb1eb13c281894d9eb31cd614b17b17871bb7b4306c7626f446d4cf84741fc053", transactionIndex: "61", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "58849", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x234a6ed8000000000000000000000000d4c435f5b09f855c3317c8524cb1f586e42795fa", contractAddress: "", cumulativeGasUsed: "1896672", gasUsed: "49041", confirmations: "3450393"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_cnd", value: addressList[7]}], name: "initializeToken", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initializeToken(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1504947751 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: initializeTier( \"0\", addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "4254847", timeStamp: "1504951121", hash: "0xbff3cc929dfc9d8f3cc0fa90caf73552e33fc21430e5bf690ef24126dd6017f9", nonce: "21", blockHash: "0x11798c0009664cc0ac94c06c5cdad937e78304a1a23efe3cd3ea5e1db9205053", transactionIndex: "112", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "210000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x674ef6c300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000cf3da2058c228328a2427abbcb25f3dc5c14db3", contractAddress: "", cumulativeGasUsed: "4335050", gasUsed: "51014", confirmations: "3450275"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tierNumber", value: "0"}, {type: "address", name: "_tierAddress", value: addressList[8]}], name: "initializeTier", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initializeTier(uint256,address)" ]( "0", addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1504951121 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tierNumber", type: "uint256"}, {indexed: false, name: "_tierAddress", type: "address"}], name: "InitializedTier", type: "event"} ;
		console.error( "eventCallOriginal[2,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InitializedTier", events: [{name: "_tierNumber", type: "uint256", value: "0"}, {name: "_tierAddress", type: "address", value: "0x0cf3da2058c228328a2427abbcb25f3dc5c14db3"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[2,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistAddresses( [addressList[9],addressList[10],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "4254892", timeStamp: "1504952100", hash: "0xa0cf200d2570f0648199e221572711ac710adc64a2123a57151ae538e1adbe47", nonce: "22", blockHash: "0x453a7b7121139abe635b4bed1d70c7f9df00a41bbf778aa6144a9c45f27780eb", transactionIndex: "11", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "4000000", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x763730bd000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000b25f18f2dc7f5069cca91bf008b59cda442c23ec00000000000000000000000032c5c3b5d2eb4a60ba0e3eacc69a51d8356fc7e0000000000000000000000000838b07f4304795cb5f9aa85dacf194765b3e469a000000000000000000000000552b76f29f0b6f5bddc2e5ad6c0256bf5a7b5406000000000000000000000000434003dea89c6ed623444bbd11f8313d26f65ad7000000000000000000000000651664bcdb4daffb296bd248cbc0c57595d4f9e10000000000000000000000002caa8caf504397d53933514a10e1330b04bf14f0000000000000000000000000ad6bb7a25b6f35b921705d99485a07284f315f5a000000000000000000000000ed038477488a703cde6485d6795beb2bb8955dc2000000000000000000000000f53e02ced4bb46526196095f850aa424272ad077000000000000000000000000d2e8827d4b1c44f64d1fa01bfbc14dc8545eca41000000000000000000000000009e51b0d7a06b3a8a22ddc326e1981d417a8b4a", contractAddress: "", cumulativeGasUsed: "720602", gasUsed: "412196", confirmations: "3450230"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20]]}, {type: "uint256", name: "_tier", value: "0"}, {type: "bool", name: "_status", value: true}], name: "whitelistAddresses", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistAddresses(address[],uint256,bool)" ]( [addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20]], "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1504952100 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistAddresses( [addressList[9],addressList[10],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "4254894", timeStamp: "1504952128", hash: "0x030fdee7db0556b1d8c8fb8bee2305465e2222ea89a22368bec3468fa79f070b", nonce: "23", blockHash: "0xc8277c2ed4bf80ef63aeda007fa37554820a4457e046ce49aebbb2b24c2fa5ae", transactionIndex: "30", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "2000000", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x763730bd000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000b25f18f2dc7f5069cca91bf008b59cda442c23ec00000000000000000000000032c5c3b5d2eb4a60ba0e3eacc69a51d8356fc7e0000000000000000000000000838b07f4304795cb5f9aa85dacf194765b3e469a000000000000000000000000552b76f29f0b6f5bddc2e5ad6c0256bf5a7b5406000000000000000000000000434003dea89c6ed623444bbd11f8313d26f65ad7000000000000000000000000651664bcdb4daffb296bd248cbc0c57595d4f9e10000000000000000000000002caa8caf504397d53933514a10e1330b04bf14f0000000000000000000000000ad6bb7a25b6f35b921705d99485a07284f315f5a000000000000000000000000ed038477488a703cde6485d6795beb2bb8955dc2000000000000000000000000f53e02ced4bb46526196095f850aa424272ad077000000000000000000000000d2e8827d4b1c44f64d1fa01bfbc14dc8545eca41000000000000000000000000009e51b0d7a06b3a8a22ddc326e1981d417a8b4a", contractAddress: "", cumulativeGasUsed: "1419586", gasUsed: "232196", confirmations: "3450228"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20]]}, {type: "uint256", name: "_tier", value: "0"}, {type: "bool", name: "_status", value: true}], name: "whitelistAddresses", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistAddresses(address[],uint256,bool)" ]( [addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20]], "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1504952128 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4255978", timeStamp: "1504978502", hash: "0x286f844f50b2f9823880fe266edff76f278f258d6e2ec4fba289767584f336af", nonce: "77", blockHash: "0xe4a7eea7200fcd923bd999c7fb22d28e1c6637a9a4cc3accd8483fb72a7f04bd", transactionIndex: "127", from: "0x434003dea89c6ed623444bbd11f8313d26f65ad7", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "29414300000000000000", gas: "90000", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "4933011", gasUsed: "90000", confirmations: "3449144"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "29414300000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "109661260966299469" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4255986", timeStamp: "1504978699", hash: "0xca6229f460e7b3c94c7c3b7719acd07ff2d514eafbac7433701480d535ab1b0f", nonce: "78", blockHash: "0x69134608a62ebc32f3c32806c517872e56d3f797bcbd74906727553660354d62", transactionIndex: "6", from: "0x434003dea89c6ed623444bbd11f8313d26f65ad7", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "115000000000000000000", gas: "90000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "413402", gasUsed: "90000", confirmations: "3449136"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "115000000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "109661260966299469" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4255997", timeStamp: "1504978941", hash: "0xd69c7491a164db7bb7fb172e0698d638157192b1ed589039be05fb894db06c49", nonce: "79", blockHash: "0x3b39188cf7317126e3f67509be674b8cec5231d30f079fe5fd616366bedbf51a", transactionIndex: "2", from: "0x434003dea89c6ed623444bbd11f8313d26f65ad7", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "140000000000000000000", gas: "200000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "242000", gasUsed: "200000", confirmations: "3449125"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "140000000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "109661260966299469" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4256015", timeStamp: "1504979478", hash: "0x161523b6d9517a45e0be8be65c55e38ce484c24907c8744ca068087ae9352125", nonce: "80", blockHash: "0x3792892a2fff7c90302e7fe7735f0f4b9176e2ccf7d4f934d1ccbb233fcf8fa1", transactionIndex: "25", from: "0x434003dea89c6ed623444bbd11f8313d26f65ad7", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "140000000000000000000", gas: "3000000", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "1445650", gasUsed: "223782", confirmations: "3449107"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "140000000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1504979478 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x434003dea89c6ed623444bbd11f8313d26f65ad7"}, {name: "_amount", type: "uint256", value: "140000000000000000000"}, {name: "_tokens", type: "uint256", value: "4085620000000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "109661260966299469" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4256036", timeStamp: "1504980105", hash: "0xb93fbaae67f9467115cc3332127271c5ae16ae1f10862338c29b91e0a35668da", nonce: "1", blockHash: "0xa56ab766a7962f15f464d5308cfeb8812b47011dca0865e30c85a8093c826fde", transactionIndex: "175", from: "0x009e51b0d7a06b3a8a22ddc326e1981d417a8b4a", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "342670000000000000000", gas: "217397", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "5952305", gasUsed: "181164", confirmations: "3449086"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "342670000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1504980105 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x009e51b0d7a06b3a8a22ddc326e1981d417a8b4a"}, {name: "_amount", type: "uint256", value: "342670000000000000000"}, {name: "_tokens", type: "uint256", value: "10000138610000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "529845155565120314" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4256506", timeStamp: "1504991391", hash: "0xe169ec75df2f1bce4cb31c239b5f147ebaadd73c640ac37df1be10baf000a161", nonce: "120", blockHash: "0xfd830ff4df4cc1385d6ea69b5d3039a647ed2b10af9debcb4fb2f8f0c6338752", transactionIndex: "48", from: "0x651664bcdb4daffb296bd248cbc0c57595d4f9e1", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "342670000000000000000", gas: "250000", gasPrice: "12000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "2075233", gasUsed: "181164", confirmations: "3448616"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "342670000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1504991391 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x651664bcdb4daffb296bd248cbc0c57595d4f9e1"}, {name: "_amount", type: "uint256", value: "342670000000000000000"}, {name: "_tokens", type: "uint256", value: "10000138610000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "999641017000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4256533", timeStamp: "1504992096", hash: "0xe6d1631ff4873bf4335385f040599355c87c3620c14b54f96e3127bddbde9c8f", nonce: "66", blockHash: "0x24a93f0074f727e58129060e8cc654b535794269607196984d3b16148eccc95c", transactionIndex: "2", from: "0xb25f18f2dc7f5069cca91bf008b59cda442c23ec", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "342670000000000000000", gas: "200000", gasPrice: "60000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "228039", gasUsed: "181164", confirmations: "3448589"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "342670000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1504992096 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0xb25f18f2dc7f5069cca91bf008b59cda442c23ec"}, {name: "_amount", type: "uint256", value: "342670000000000000000"}, {name: "_tokens", type: "uint256", value: "10000138610000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "177763492531262464" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4256606", timeStamp: "1504993651", hash: "0x61aaf278788724b607972ebc196b37564ad3b0d3340f5b70f801467a8f0e17f9", nonce: "132", blockHash: "0x720755d6c31618d8a5dffb6442126343ad3727278574ce65044221b00931dae7", transactionIndex: "1", from: "0x32c5c3b5d2eb4a60ba0e3eacc69a51d8356fc7e0", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "342670000000000000000", gas: "200000", gasPrice: "60000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "202164", gasUsed: "181164", confirmations: "3448516"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "342670000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1504993651 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x32c5c3b5d2eb4a60ba0e3eacc69a51d8356fc7e0"}, {name: "_amount", type: "uint256", value: "342670000000000000000"}, {name: "_tokens", type: "uint256", value: "10000138610000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "878119049722221974" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4256821", timeStamp: "1504998905", hash: "0x5727314dbc5cb2655bda5f07330c19d19343f477ba31f4eca17190de9262911d", nonce: "19", blockHash: "0x4f9559bda1cd3258117e27c049996a849def9b226b1ef7d135129ea6d968137c", transactionIndex: "112", from: "0x2caa8caf504397d53933514a10e1330b04bf14f0", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "342670000000000000000", gas: "225000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "4193935", gasUsed: "181164", confirmations: "3448301"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "342670000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1504998905 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x2caa8caf504397d53933514a10e1330b04bf14f0"}, {name: "_amount", type: "uint256", value: "342670000000000000000"}, {name: "_tokens", type: "uint256", value: "10000138610000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "313984146911281321" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4257014", timeStamp: "1505003744", hash: "0xc2c267759d72bc0654ae5db8bca4a3568cad88e01227465de27495dad8defd97", nonce: "83", blockHash: "0x5f15cac827aeff82dc79b08e5e3b3472670b712a2fb4d2b3ad3b0f7e05c75893", transactionIndex: "2", from: "0x838b07f4304795cb5f9aa85dacf194765b3e469a", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "172000000000000000000", gas: "200000", gasPrice: "60000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "253703", gasUsed: "181164", confirmations: "3448108"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "172000000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1505003744 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x838b07f4304795cb5f9aa85dacf194765b3e469a"}, {name: "_amount", type: "uint256", value: "172000000000000000000"}, {name: "_tokens", type: "uint256", value: "5019476000000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "369265274209277440" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4258119", timeStamp: "1505031117", hash: "0x9308d6362ff30a37b24fcd89f95865c0a37568b10b917c134ca455696e143110", nonce: "82", blockHash: "0x569ef12887decc972ac7e338210c5e2afef546190344d6455643e0ab53ad40c1", transactionIndex: "42", from: "0x434003dea89c6ed623444bbd11f8313d26f65ad7", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "18000000000000000000", gas: "300000", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "1732348", gasUsed: "151525", confirmations: "3447003"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "18000000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1505031117 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x434003dea89c6ed623444bbd11f8313d26f65ad7"}, {name: "_amount", type: "uint256", value: "18000000000000000000"}, {name: "_tokens", type: "uint256", value: "525294000000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "109661260966299469" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistAddresses( [addressList[21]], \"0\", true )", async function( ) {
		const txOriginal = {blockNumber: "4259768", timeStamp: "1505070703", hash: "0x02b9cde15c8dedb505178ec2002dda3eb28ee509b18b7b4271f748588deebd32", nonce: "27", blockHash: "0x9cf21bfcb2273d22a751df0d39de89a8daa2a00ab880a613e71af7e26b70ee06", transactionIndex: "60", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "66524", gasPrice: "21834513098", isError: "0", txreceipt_status: "", input: "0x763730bd000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000100000000000000000000000015cc96acd61f3f564c8ac913114213cc3d666b68", contractAddress: "", cumulativeGasUsed: "2661326", gasUsed: "55437", confirmations: "3445354"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[21]]}, {type: "uint256", name: "_tier", value: "0"}, {type: "bool", name: "_status", value: true}], name: "whitelistAddresses", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistAddresses(address[],uint256,bool)" ]( [addressList[21]], "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1505070703 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4260585", timeStamp: "1505090120", hash: "0x2cc0de73c322a5532f7e807f25530ddafaae92f0723bcd120272c21a8105c235", nonce: "6", blockHash: "0x7fdbe21b26bad3eeb102a182eecb384bb59a83ef05757a93907505c490c53e26", transactionIndex: "145", from: "0xad6bb7a25b6f35b921705d99485a07284f315f5a", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "342670000000000000000", gas: "271747", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "6052693", gasUsed: "181164", confirmations: "3444537"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "342670000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1505090120 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0xad6bb7a25b6f35b921705d99485a07284f315f5a"}, {name: "_amount", type: "uint256", value: "342670000000000000000"}, {name: "_tokens", type: "uint256", value: "10000138610000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "12668425785764000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4262074", timeStamp: "1505127595", hash: "0x33bf719a3d608ac57b31b53f400b52a8c372846c626066df5f293cd678ad98a7", nonce: "20", blockHash: "0x05103c6de7a7d507999917d37748d65d954f3908ed8cec519994283f3c493cf3", transactionIndex: "158", from: "0x552b76f29f0b6f5bddc2e5ad6c0256bf5a7b5406", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "342670000000000000000", gas: "181164", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "4971728", gasUsed: "181164", confirmations: "3443048"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "342670000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1505127595 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x552b76f29f0b6f5bddc2e5ad6c0256bf5a7b5406"}, {name: "_amount", type: "uint256", value: "342670000000000000000"}, {name: "_tokens", type: "uint256", value: "10000138610000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "677911960746001284" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistAddresses( [addressList[22]], \"0\", true )", async function( ) {
		const txOriginal = {blockNumber: "4262650", timeStamp: "1505140823", hash: "0x51d9b46f78f332b9b44531fffa2c089aa5fb1bec493e8f4e96a7bb9b7f32a421", nonce: "28", blockHash: "0x773c4b761861c77980db325c594be4cdb6b11050d62be1ba5986c1596b94fa63", transactionIndex: "69", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "66524", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x763730bd0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001000000000000000000000000a9d8b2fd9aa8209e6c91780302413d33a515ad19", contractAddress: "", cumulativeGasUsed: "1968130", gasUsed: "55437", confirmations: "3442472"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[22]]}, {type: "uint256", name: "_tier", value: "0"}, {type: "bool", name: "_status", value: true}], name: "whitelistAddresses", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistAddresses(address[],uint256,bool)" ]( [addressList[22]], "0", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1505140823 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4263611", timeStamp: "1505163876", hash: "0xaf6bbcba39da01cc8e38274dccc286a0e03e951c4a75e932e72d37dd11599a93", nonce: "28", blockHash: "0x208f2b1de1ff580a638a453df6813050e713a18164fae9d8c739c70816d50cd7", transactionIndex: "248", from: "0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "342670000000000000000", gas: "181164", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "6552000", gasUsed: "181164", confirmations: "3441511"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "342670000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1505163876 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0xd2e8827d4b1c44f64d1fa01bfbc14dc8545eca41"}, {name: "_amount", type: "uint256", value: "342670000000000000000"}, {name: "_tokens", type: "uint256", value: "10000138610000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "85229274128659308" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4263760", timeStamp: "1505167130", hash: "0xb13c7252e022cd0147d641c260368bdcac2f56e0bd6a0d59dff022b091a9e617", nonce: "3", blockHash: "0x237031c0467403496f9d3623dcdefcc3c13c54583828c0ee0af71b9fc227fc3c", transactionIndex: "171", from: "0x15cc96acd61f3f564c8ac913114213cc3d666b68", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "85670000000000000000", gas: "181164", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "5484744", gasUsed: "181164", confirmations: "3441362"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "85670000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1505167130 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x15cc96acd61f3f564c8ac913114213cc3d666b68"}, {name: "_amount", type: "uint256", value: "85670000000000000000"}, {name: "_tokens", type: "uint256", value: "2500107610000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "39190229000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4263864", timeStamp: "1505169503", hash: "0x4bc98c9e3e6962145e9abb8b40cb15fbd77608e14839e63ba1867ea5bb4c03be", nonce: "44", blockHash: "0x9485668d7ceb4f0653b98dcdc28be600d197d3814a72e7f365c7ef10dd6867ea", transactionIndex: "9", from: "0xed038477488a703cde6485d6795beb2bb8955dc2", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "342670000000000000000", gas: "250000", gasPrice: "33000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "639731", gasUsed: "181164", confirmations: "3441258"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "342670000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1505169503 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0xed038477488a703cde6485d6795beb2bb8955dc2"}, {name: "_amount", type: "uint256", value: "342670000000000000000"}, {name: "_tokens", type: "uint256", value: "10000138610000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "978948041735421618408" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4264136", timeStamp: "1505175969", hash: "0x4e23f05046240bf9a4730b21248a2eafabc0db1ccb724c349614ca868080b211", nonce: "54", blockHash: "0x0dedde3ec9e0dd844d610bcfc63f63482554a1db7d851909c2c3ac44d361fa2e", transactionIndex: "36", from: "0x8676f92151771425c5a506a60105ee1a8e877456", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "10000000000000000", gas: "210000", gasPrice: "6000000000", isError: "1", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "1241798", gasUsed: "210000", confirmations: "3440986"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "167675516171292608" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4264320", timeStamp: "1505180014", hash: "0x21a8a8308e65fbb0e3c957fcbbd216291bcdf280c0782c20729aa6578e2d64b1", nonce: "4", blockHash: "0x6a21755b612aedf5a62d3f837f1b63e93a5d5961c537067a222cb42dedbbd190", transactionIndex: "154", from: "0x15cc96acd61f3f564c8ac913114213cc3d666b68", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "85670000000000000000", gas: "151525", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "4319519", gasUsed: "151525", confirmations: "3440802"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "85670000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1505180014 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x15cc96acd61f3f564c8ac913114213cc3d666b68"}, {name: "_amount", type: "uint256", value: "85670000000000000000"}, {name: "_tokens", type: "uint256", value: "2500107610000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "39190229000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4264369", timeStamp: "1505181167", hash: "0xad221dfd38fc781685be78d491fd45069b99b512d805145d8e11ff8291e1e171", nonce: "0", blockHash: "0xbff0b7e9fd224dd82841536f82476dae4d6aa9545a7cb894108c70d9db94411c", transactionIndex: "103", from: "0xf53e02ced4bb46526196095f850aa424272ad077", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "342670000000000000000", gas: "181164", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "2952865", gasUsed: "181164", confirmations: "3440753"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "342670000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1505181167 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0xf53e02ced4bb46526196095f850aa424272ad077"}, {name: "_amount", type: "uint256", value: "342670000000000000000"}, {name: "_tokens", type: "uint256", value: "10000138610000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "2890295540000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4265267", timeStamp: "1505203115", hash: "0xe8d19fd203c42d28ca8ab0b1eb4d5875a6d5acc6268f7942bd7bf16bbc83f5b7", nonce: "0", blockHash: "0x54e383c910c987e8d42e26815fce3717ae901ca23b145ba6124c9e43d31b3ae0", transactionIndex: "139", from: "0xa9d8b2fd9aa8209e6c91780302413d33a515ad19", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "182900000000000000000", gas: "21300", gasPrice: "15000000000", isError: "1", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "4420445", gasUsed: "21300", confirmations: "3439855"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "182900000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4265273", timeStamp: "1505203309", hash: "0x805bbe1ea5e9ee67f901aa25644614249b44a374b08109021e486895f990520f", nonce: "1", blockHash: "0x94838c887c33ce7b3ba70c6ad36611d978bb06e37fe1eb4b396d8d903bd12e66", transactionIndex: "111", from: "0xa9d8b2fd9aa8209e6c91780302413d33a515ad19", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "182900000000000000000", gas: "253633", gasPrice: "15000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "4905902", gasUsed: "252485", confirmations: "3439849"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "182900000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1505203309 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0xa9d8b2fd9aa8209e6c91780302413d33a515ad19"}, {name: "_amount", type: "uint256", value: "12610000000000000000"}, {name: "_tokens", type: "uint256", value: "367997630000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tierCount", type: "uint256"}, {indexed: false, name: "_now", type: "uint256"}], name: "FinalizedTier", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FinalizedTier", events: [{name: "_tierCount", type: "uint256", value: "1"}, {name: "_now", type: "uint256", value: "1505203309"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_amount", type: "uint256"}], name: "Refund", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Refund", events: [{name: "_amount", type: "uint256", value: "170290000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistAddresses( [addressList[24],addressList[25],address... )", async function( ) {
		const txOriginal = {blockNumber: "4269739", timeStamp: "1505311816", hash: "0xe10d9f270b499ca1df333a8b077719eb64b346698e2e0877c8e461d3aed6c1c4", nonce: "32", blockHash: "0xce59874deb9debd47e5f1cb5fa116d6ef8e13f558a8dfe86836763e64fc8b152", transactionIndex: "39", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "2000000", gasPrice: "22463230501", isError: "1", txreceipt_status: "", input: "0x763730bd000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000010800000000000000000000000011df9c71b1ef9b69607a937f50a625e258733200000000000000000000000000009e02b21abefc7ecc1f2b11700b49106d7d552b000000000000000000000000213ee0a9390921f5a0178bf421d45a1985ee38a4000000000000000000000000b875f205eb38ef3d0a1801aea1df08ae78933dad000000000000000000000000ba4115e85d09e3ef52c788043372cea95368548f000000000000000000000000ce632aef4c0822b97f2862b3dc9a70d3ac06faa5000000000000000000000000009d06cc6b11fa75412c3cda6da63813bbbdafaf00000000000000000000000010388a4db0b0eef4afd11b3e58a63eda90fba1ca00000000000000000000000079b4b5287add11272a0c626afc3006844e5bdfcd00000000000000000000000022b2b07b38fe213ba32012ab30f05ed98f29ed31000000000000000000000000447c2f2a93b0a7b76a880639712ab9dd1963d44c000000000000000000000000f8cde04ac5c33f235eb3cb138b301379bcf33fff000000000000000000000000622b2c840d856181661482a2f7d9a5a41e0f992a00000000000000000000000022aae1d3caebaababe90016fcade68652414b0e0000000000000000000000000c7df8a3b4eab37bab57f90f60d17d8bec01f568c000000000000000000000000f0f646f6b61f57ad28d2ab3a8c21110011d1a64c00000000000000000000000084484b1b89941a1db3a3222bcd75823095abaca70000000000000000000000001da422eded980a4e633da67bd30c60765e872cba0000000000000000000000000676949e2ee6574e7d1a80870cabde22724f21210000000000000000000000008b22030f19431feac38bb5201f16f3935e7cd447000000000000000000000000392028f4a6a7322b00638039663b2118dac92263000000000000000000000000ed50b8b0adf6b37ad15635dbc7e53f4a705014b90000000000000000000000000b6df62a52e9c60f07fc8b4d4f90cab716367fb700000000000000000000000055b22ac7ddad396e703f38d04009540490d122bf000000000000000000000000c458def22aed52417c4b78ead6841d382aa9d42700000000000000000000000042b7dec83f4dfdaa70416d7a7e1951ad8e6e7847000000000000000000000000c967e3c453caa4583451e2f7a4080e56e165e202000000000000000000000000a722f9f5d744d508c155fceb9245ca57b5d13bb50000000000000000000000000024d5549bf5c3aca24f1ceaecf50f50c9d92bd7000000000000000000000000127fbbaebce7c6a85fbb2f744ed021ad52eed6fd000000000000000000000000647beca433382e60cfc9adbb3a8bbd2af3d053f8000000000000000000000000a145addb0a24f0c4697189a02eadb006be244d49000000000000000000000000572a26bf9358c099cc2fb0be9c8b99499aca42c500000000000000000000000099784406b8c01a9f752b86b5e6c9180ef7fe6b05000000000000000000000000d723329b502affbc63731fadf546e4fae7d5ee7f0000000000000000000000001ef8598bebc15ba24f3a9fe2255b20b54fbb15a50000000000000000000000009b73899cf3c29adde3086f993b001ab733723a38000000000000000000000000b927340c680a315677b918003fb6189b6d1ca4aa000000000000000000000000924c251902924c7dbd4cbf166d42757fb2d146cb0000000000000000000000000009b5fb5d267c0b91a33cc7ce69aab9b5c62edb000000000000000000000000f21749506cdc7c684b096ba172c99a8878a816fb000000000000000000000000c841cd0ad77d714b3c6ad86c1160034a1f11fed30000000000000000000000004aaddb83fa8f8c8758d38f74f5564fb549846b310000000000000000000000008e9fe6f4717ea81a5bb2a249af41b16e781de4b2000000000000000000000000ba52465fcb173e1965171b31bdd0c9aade3609d2000000000000000000000000c0d3a8d939d8653f0fd8fe7a0646dd38842934660000000000000000000000000960da039bb8151cacfef620476e8baf34bd9565000000000000000000000000b9d00378957f680900c9961cfc1814bc1271c4c00000000000000000000000003e77a7d70e3853e9eaecdf8e3de78e94265fa8e50000000000000000000000003384256f506520a2dc5d51aa081e5016ac6e2730000000000000000000000000392257daecc9b252529167214c9f8ba0a17b0e3600000000000000000000000000a96e78d4900cb5f8c412c1437b15aaf81f6733000000000000000000000000006b65f5189599a187d4f4cc6661166aaafa3ed4000000000000000000000000088cca87b0d829b35efeb6934ff807cd3befc48b00000000000000000000000007895ebad237645e1553dd195e870d2be9803a8d000000000000000000000000489554ab02c071d7279cc1428592c1722ac5e33f000000000000000000000000501ac3b461e7517d07dcb5492679cc7521aadd42000000000000000000000000ffe27b523078303768ac6b2a9ebee8a22902ffaf0000000000000000000000003de61a89290009b34000361cf94d9b7a218cf5eb0000000000000000000000001c74d52ca9d58f629e9b5bdfee0fa82116db047a000000000000000000000000d3438e11d5de4518dcef9a3c455fcb75dcc600cf00000000000000000000000067e0887a3614da0dc94b6b36bc787d7c528ec8c200000000000000000000000000e7b744f07fd1dc016ba84626c2c31edb15b9b70000000000000000000000005f1d2141682745ec493876e13903562cac71b79200000000000000000000000010f77e56bdccade0b4542145e5c408f1f8bf5afb00000000000000000000000000db61875511c11e07ebe53edf787717410fc9160000000000000000000000005f055dcafbc494eb4d634744dd96b0813a718f99000000000000000000000000369342e4617cd365d7ffacbea47ed1a143e48bea0000000000000000000000007139ceeef20464fe9bd2ba713c8a68240f01711d000000000000000000000000704e0de2534102e3102f358e6c78568d13053aaa000000000000000000000000ca568c15453844f78a5bed1c7d74e5c81cca557d000000000000000000000000f6d4d4ddbf3fc684d531b40c3c518d3825f2769d00000000000000000000000045d5eab238d23e668a949ecde1e77163c427533900000000000000000000000033a96b5993f65e26ad4f51b3d3ccea513271b923000000000000000000000000cc6c95e8bc9fe7b9ddccded787276b70728bd91d00000000000000000000000000b88dc7e00c5ad794595f208566bcc15d07f0270000000000000000000000009dc8a0886242b0fd686d8f2a9ed46516090b6fd300000000000000000000000000f26ece6c8716bdded31924b446c92ff388aee200000000000000000000000041fc0c45412422221ee6769f182ca9a344359e3f000000000000000000000000f482bea9f562184be993e9b1ac3d75eff57781ca0000000000000000000000000868411ca03e6655d7ee957089dc983d74b9bf1a0000000000000000000000009f4cb6c14055163e9975ff18e4230c2833f02726000000000000000000000000da6b22f0a07241448bea9dccd02b3b187e343664000000000000000000000000c4e3aac985c8182e3dac6c9b19eb606151fcd7670000000000000000000000003dd361b92ef882c885e3e4a7d634c2d9daedef85000000000000000000000000e4cba77472f36a5ee693b44c84989a1fa576992a00000000000000000000000000b6e47551b16d1919a74e2a6512fde7675e15da000000000000000000000000252fac5e0f04d62aef0556084c2c6e64feef271e000000000000000000000000d1c5e193feb49a59c6bd54b8aa28f22762f89d5500000000000000000000000039990ea12fd788062f16ce81b769bbf0ef9c2c8e000000000000000000000000d4e86be2d4ad7e987ab67ad679ceaeec269573b600000000000000000000000089a12ac6de30463278eb4a0eeebf2da16ea9637d00000000000000000000000000bab0d7068f8b2d753590949879e17faf3f60880000000000000000000000001edef22dccded943a0ddb453647723378c33410a00000000000000000000000055a1cae7f45240680c83dbb7329046f894a7160300000000000000000000000000a888a4cac1a5a82029bff090aaddb98407303a0000000000000000000000002fdefc1c8f299e378473999707aa5ea7c8639af3000000000000000000000000bd9064fdb9a4274df760f8fc14abaf6b86d17f120000000000000000000000004aa7269e78942f8b159db827fdac811587abcf51000000000000000000000000de7799b2d6999ad6a752aa0af8b95fe41e7259150000000000000000000000003115aa1401d5aba3220030d3db298ce8880a46b50000000000000000000000000823c99debd091fe1a736bd3888b1707ed820aec0000000000000000000000002539b51ebde65a75672abcfe9439a706a99d18d100000000000000000000000085c24edf1b51115cdf654c15fd29e1b32752e56700000000000000000000000004a782948d6cea64d5f14d46c18fb33470644fd2000000000000000000000000f476e1267f86247cc908816f2e7ad5388c952db0000000000000000000000000aab54b1b17fd41fbac81758e387bc8eca128ca880000000000000000000000000b6121ddce71373b3c02780b22cc78dd20d3a7f900000000000000000000000059191198028f1e14d3ae814ebdae084f93a1746f000000000000000000000000229a55f621801934acb219478d556c7f128acde60000000000000000000000009608a19685b95c49b86c859bebaf3d1f0e8ffa1a000000000000000000000000c230ce5643a10702111572c938919c9f448c46d80000000000000000000000003744c132637b13f7f410e0580a1fa2393875e4440000000000000000000000008c3720060f8cfdf8b8d4da5698f4f51a48a0828a0000000000000000000000002561a6f4f32908f2bef562987da896701ec943ae00000000000000000000000005939d370ce1a4f7d36b2b1c3c09d84ec4f7e9eb0000000000000000000000000593f77e9d19d4c322e18a24b89dfbfa311ea545000000000000000000000000dcc097955815c69b223865a050800dc44ecaf8ae000000000000000000000000ffdd5bfe33c8fa18af76b944e725b3a116467c640000000000000000000000004995c29a93226c5858711f81e3b75eb2aa0a5a4e0000000000000000000000003c401c200233c07dd9bfdac99edbc01068afe118000000000000000000000000ffc5b23d80b85c2a7a7da49064d7354d09e5e3cf0000000000000000000000009a73c36d924c197c6418a24ea986e5d3f7c1ddf300000000000000000000000000bb85eb9f8e166acef360942ac4e43dda235f0300000000000000000000000000165307057322a93adbe68050159af11966778d000000000000000000000000b45d904431f0fc93f14ed273d7e8acb71339207f0000000000000000000000000681516881536a06497017971c7c86128fab573800000000000000000000000034cc2861eeb213da8bf366becdfb319f16aff12c00000000000000000000000060ba6c590883ab3c06289eff076f96b80065e3f5000000000000000000000000e835ec939021aa1189d4ddf3ae1544b62f9579ab0000000000000000000000009a94771e7e73f9d8d6e880cfb12cab4e9573c45e0000000000000000000000006d805c47cd158bee253986cfbfcfce34fdb33efe000000000000000000000000baa68aa7b1257305ab9d968e51786897e0e423b70000000000000000000000006d0bb4ce7acc1ba71af6d1858dea64c6073dc27e00000000000000000000000007bd15dcb7f83045d3583ae385b4b549951a33c2000000000000000000000000145663520246b70e32c96411b33f8dc71d4100dd000000000000000000000000bccb13f64b2708f400304cbd10044c589c116925000000000000000000000000e414feaddd562b0071810d1b1b4d8bb85171632d0000000000000000000000005f9d89858fee7de8f28e21e62650bf1322c714f10000000000000000000000007c0fba9557b8f909ab8d69d8da1944501b6a9d07000000000000000000000000b1ccab138e6c6a704f9bf607a71c342cfc9480530000000000000000000000000e0193a44c0d7e36b8faff8fd3d9004d5bb5ff0900000000000000000000000000c2e468cd0f9576c6540f425baf64969205b40c00000000000000000000000082e4d78c6c62d461251fa5a1d4deb9f0fe378e300000000000000000000000001bbcc79b91bee48b60da56329b7f0c5d797d56ed000000000000000000000000007d2f4fe301922c560d1a752836c4e99e0ed63c000000000000000000000000e9ebee76a902b6536c0bddf79ac4c4343e5bdbfb000000000000000000000000ec000c5461cdbc4497d61245176260671db70d88000000000000000000000000a20ad2f8ad42831e9dc82c05715bcaaec84f9abb000000000000000000000000ff52c5c250d63e6903aa7b7bd4c256bf4743260200000000000000000000000000582f083582f59a0da86a0688332c77c7044a3a00000000000000000000000002c68e3de38b00f958a53bd9182d09120312b2a20000000000000000000000000e6ead010b7249b46c56972a309d1376e53d9d5000000000000000000000000034a0cd27e8489ad7346a9a40e2205cf6b715b3640000000000000000000000007fc796922627eed6faf6c26e01a32c33b5fc91310000000000000000000000007f8e672a3079d3976ebc2b3cb5179dbd7986352900000000000000000000000070e8818a14d8841604497990bbd181170661a85e0000000000000000000000005df3bba2cb0b3aa00fa940c14e2cc57f2cba303a0000000000000000000000007c1b4e9d3df68577655f67057a5076c9cdd8a7ed000000000000000000000000f190f0193b694d9d2bb865a66f0c17cbd8280c71000000000000000000000000a07b4b955c69afbdb1e7c2eadf28e50bcc3f4c93000000000000000000000000e909e1c946c057d06b79cc72ebcb5b168c6e6d4900000000000000000000000076927e2ccab0084bd19cee74f78b63134b9d181e000000000000000000000000be0b69edc6e0aaae42b9964af162f8a4a2ffe5950000000000000000000000006cb9e3274799ca43ec2582335867b9f7520d9f2600000000000000000000000022c8d09305d827f1cdf696d1b9ee309227938f950000000000000000000000005c72da9cad883d790eb1e4165cf2441b3be165e2000000000000000000000000cb3bb2e2cbfa6dc19c2ba39d7f9aaa022f0bdc8f000000000000000000000000ba881a7b7f829d5c25bd120b3e80c640cd8ae0d6000000000000000000000000b46ac18f8fc29c552450e1ba67272e8dfc828fd10000000000000000000000006e9ec23df252c5ded1e83b2a19fc5d79759acf0300000000000000000000000028091e33df862922f1a1fc62e60af9f791cb4dec000000000000000000000000e60c6d66c42b97300f116f34e2b971d8a627d557000000000000000000000000662a80dd9b873913cfdeef75f771159a6782f3d8000000000000000000000000848c98731d0122e32217dcafe0ee67842f3533e600000000000000000000000076cd7f9cb7030803fff92875c49df9aa8c558344000000000000000000000000d48505ee38c6e933defa82e068d063b300781df8000000000000000000000000004ba25b9b23ac7b4dd583c7e6a8e811dd32e60800000000000000000000000043215241c3def445e151a881db883a66c2df9bbe0000000000000000000000008c0114f7507485c2289cb4fc7fadb61d4e2f49b30000000000000000000000002a980afd3cf9ba8bbb15ea10fe952d96641f034600000000000000000000000076c265bdaa4350ed138735b7a514adb1a89b71e20000000000000000000000000a69945a4f4cd87b925a34fc9c641efc1da664d6000000000000000000000000eaa25ac8a4cc52451917238638453737af6e4a31000000000000000000000000717a58ed0ec76d4cfe0b64c0e112ce015653edb200000000000000000000000028472e097c91d75f6aa557c0223e50960078a6d00000000000000000000000009d50ca863d28c946a05560e9bd993ba4c2d1f95400000000000000000000000028b54d4534052214f134a995663af9c6bdaea4350000000000000000000000008215d8fde5eaf58901d01a438f7188016369b91f000000000000000000000000f5b9f5c093b63a609711fb56f6b8484013ffa0280000000000000000000000001c2e28d5e50dedd1dc8936d681b32d2458533d740000000000000000000000006c27ea4b5d281e81e5a833a5e6e1c5a74f9b47be000000000000000000000000d78fd123d2bc2da7bb5621c753dc665d3c0e85ac000000000000000000000000049503a94f506b601661d8bc792a2cc59ea230d90000000000000000000000000c6ead592dd190072e898e807f2fc68e98bcd8be000000000000000000000000047eb968d0dce70280352d0834ab9f6b536da16f0000000000000000000000008f212180bf6b8178559a67268502057fb0043dd90000000000000000000000009faaa0efbe61bc445e1068ab1cd67f23b45d624f000000000000000000000000c6cc76eb55c49a839444800b66a66cbddf76e3e0000000000000000000000000a39166df6f039ba348d7cfa353280d19dde04cd8000000000000000000000000b0323032e7cc95e17555e9fb37b33095eee235f000000000000000000000000078d8e8807f652b54afe33b7645a26c5ffae5291c0000000000000000000000003dd932d51fb898374e694d764d059d2e2453e4d1000000000000000000000000e7dc484e59f6b7ed74bc72a1129144f9ea4bf89a0000000000000000000000007ebe9268b8f7ff0b098a8567bf7490d33123da4d000000000000000000000000f3cdf271ccaafb591372f81521bd2019701def1b00000000000000000000000037e102aab262f27e73a9733c7678d0d58ed7a5ab000000000000000000000000e055aff35a3f212e713922e296d295fb50d6edb90000000000000000000000006317dac8332f0b3ef49146b45a6726cdb78c4dcf000000000000000000000000ef243aa4f940e72eb1d7ebab724672d88b4f18ed00000000000000000000000080259bc4e86f3fa837491838562e418a56a3359f0000000000000000000000002bae4bf3595b96b2f07492b7d1622e3703e604f80000000000000000000000000028673fc0a9532a5c0af61ebb8369a4e5219ec00000000000000000000000000b77e9fd0166dd1a59fad0d1393bfc41d2bc6f26000000000000000000000000e0da8ed5b7b775b5fdf285131646fe2f54ef0005000000000000000000000000f70145fe48ab5606890a98d19949edd2516ea2400000000000000000000000009466c086239a0fd38932608572cebb97d1d42ee5000000000000000000000000f769dbd6d5c2cf4db888f59c5768901411160e88000000000000000000000000a35b60fe8eb8184a379a0d0b726f3ceb57ee907300000000000000000000000027dadeb9e5e35881402d54286af63cc63505163a0000000000000000000000009dac72188aeb760b60bef84b85cfa5bb2dfd9b69000000000000000000000000e9080374375a1f92e2edf6f314ea2ec1800979fe000000000000000000000000003bb89e2cd29acd745b11dc9d13a38bcce6c24200000000000000000000000074c072d1bd63e0b922d0befd79b3ee1fcc3a8336000000000000000000000000cef0e56b84ad7d5be9edcb7faf66f85ae83942a4000000000000000000000000a6d0c47df7af1ecdd555d08c44ca4f7186e6e982000000000000000000000000005fe92d7a91a045ff6cfe888b0b982cd3f2a06b000000000000000000000000678fb21b9736e6c7da9f7d37a77ab766bb2519c70000000000000000000000002e15d7aa0650de1009710fdd45c3468d75ae1392000000000000000000000000fd516ec936908f1f409cd48c05fbbfabacdfa52000000000000000000000000094d9cd17d85d2afa8d71283d94386281f16612bd00000000000000000000000007ca04dea1b05ef526f69f82661aa2bc911c7ab2000000000000000000000000ebeabcb3dd92973f863ce54bce5e1e4322777210000000000000000000000000b38ecc6ec2fcaecfc8987f25ae58622a91a230340000000000000000000000002565f8e0b33f2d3bb1c0e2dd5fbb972df48654c8000000000000000000000000428512bd5e9f8e486972c89b423eed37d304d786000000000000000000000000b92f2e00983faa34b4afac034aa85569df78039f00000000000000000000000023b991f7be7afc8706dcef2f04288b44b455feb700000000000000000000000096f57b3b2aee2f15198cc2862d17eb32591c0208000000000000000000000000abd4277717fd22b4e91232578c34478546dc381f000000000000000000000000edb34a82f00c71c2082171e4365ea85d422620af00000000000000000000000067a01ab58cc873bfbd93c89f2b0897e85007b772000000000000000000000000cf093b6dfce969e640dbd38d7302ce2e7ca531df00000000000000000000000054620853f4f0799bee70832b767fcb6ed5b48eba0000000000000000000000007a836b45c06e57c65451c41168a7f269146b1b0d0000000000000000000000002d50a018e1c5194334d8ce52d7152d2ac99f7b370000000000000000000000000d8571cf484de9f090edb7e51882d60402212d83000000000000000000000000d1f982eca739bd2165ea085c379231646302eae30000000000000000000000000451b45ca19945c38adc39bc91f45b3d518aa8e3000000000000000000000000002b254abdcef1f9af4e56f0e9776bc1feea1edc00000000000000000000000040692724326503b8fdc8472df7ee658f4bdbfc890000000000000000000000006c66ebb344c3251fbd49cf00b93ebb562f3637c600000000000000000000000027570157d3b72560143af4d8a4528117e22155750000000000000000000000007837d0bfec3abd92a1720f21c77aef0b71d0f58e00000000000000000000000061779ad9d36ba354e235c59fb48651ace92f9fae000000000000000000000000c08d21eb6000357b3d70fbedaf6a1ce5c94d6286000000000000000000000000a7e51da6df5079e42048f43ffb355952cbfd504d000000000000000000000000d93e1bd6d0716ecdeff07f59d31fdf3679250f3a0000000000000000000000006065043d769e88421e2592472a2394d4b5ca1b44000000000000000000000000efe628e9239bf3dc14766aa465064e1784edc05200000000000000000000000050f5ff6683b508f356f97beee5728a38abe3b51e0000000000000000000000009c232158b5e0f9a23bf9a399cd9197c7f131d13b000000000000000000000000c2e82b98ebb92cf36faa85fba798f838a86843d40000000000000000000000008e6ceca77bd9ae8a2c7f9d11870ec80ba6ab751c", contractAddress: "", cumulativeGasUsed: "3320809", gasUsed: "2000000", confirmations: "3435383"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210],addressList[211],addressList[212],addressList[213],addressList[214],addressList[215],addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[221],addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229],addressList[230],addressList[231],addressList[232],addressList[233],addressList[234],addressList[235],addressList[236],addressList[237],addressList[238],addressList[239],addressList[240],addressList[241],addressList[242],addressList[243],addressList[244],addressList[245],addressList[246],addressList[247],addressList[248],addressList[249],addressList[250],addressList[251],addressList[252],addressList[253],addressList[254],addressList[255],addressList[256],addressList[257],addressList[258],addressList[259],addressList[260],addressList[261],addressList[262],addressList[263],addressList[264],addressList[265],addressList[266],addressList[267],addressList[268],addressList[269],addressList[270],addressList[271],addressList[272],addressList[273],addressList[274],addressList[275],addressList[276],addressList[277],addressList[278],addressList[279],addressList[280],addressList[281],addressList[282],addressList[283],addressList[284],addressList[285],addressList[286],addressList[287]]}, {type: "uint256", name: "_tier", value: "1"}, {type: "bool", name: "_status", value: true}], name: "whitelistAddresses", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistAddresses( [addressList[24],addressList[25],address... )", async function( ) {
		const txOriginal = {blockNumber: "4269742", timeStamp: "1505311865", hash: "0xd69efd17f42c9fe2cd1501180ccb85b9337f2433af34ac0945e00705a297e196", nonce: "33", blockHash: "0xe67935c3697faedd1dad1c9ffd0994e66750549f70747637056b2e0b3ea82e01", transactionIndex: "28", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "4000000", gasPrice: "22463230501", isError: "1", txreceipt_status: "", input: "0x763730bd000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000010800000000000000000000000011df9c71b1ef9b69607a937f50a625e258733200000000000000000000000000009e02b21abefc7ecc1f2b11700b49106d7d552b000000000000000000000000213ee0a9390921f5a0178bf421d45a1985ee38a4000000000000000000000000b875f205eb38ef3d0a1801aea1df08ae78933dad000000000000000000000000ba4115e85d09e3ef52c788043372cea95368548f000000000000000000000000ce632aef4c0822b97f2862b3dc9a70d3ac06faa5000000000000000000000000009d06cc6b11fa75412c3cda6da63813bbbdafaf00000000000000000000000010388a4db0b0eef4afd11b3e58a63eda90fba1ca00000000000000000000000079b4b5287add11272a0c626afc3006844e5bdfcd00000000000000000000000022b2b07b38fe213ba32012ab30f05ed98f29ed31000000000000000000000000447c2f2a93b0a7b76a880639712ab9dd1963d44c000000000000000000000000f8cde04ac5c33f235eb3cb138b301379bcf33fff000000000000000000000000622b2c840d856181661482a2f7d9a5a41e0f992a00000000000000000000000022aae1d3caebaababe90016fcade68652414b0e0000000000000000000000000c7df8a3b4eab37bab57f90f60d17d8bec01f568c000000000000000000000000f0f646f6b61f57ad28d2ab3a8c21110011d1a64c00000000000000000000000084484b1b89941a1db3a3222bcd75823095abaca70000000000000000000000001da422eded980a4e633da67bd30c60765e872cba0000000000000000000000000676949e2ee6574e7d1a80870cabde22724f21210000000000000000000000008b22030f19431feac38bb5201f16f3935e7cd447000000000000000000000000392028f4a6a7322b00638039663b2118dac92263000000000000000000000000ed50b8b0adf6b37ad15635dbc7e53f4a705014b90000000000000000000000000b6df62a52e9c60f07fc8b4d4f90cab716367fb700000000000000000000000055b22ac7ddad396e703f38d04009540490d122bf000000000000000000000000c458def22aed52417c4b78ead6841d382aa9d42700000000000000000000000042b7dec83f4dfdaa70416d7a7e1951ad8e6e7847000000000000000000000000c967e3c453caa4583451e2f7a4080e56e165e202000000000000000000000000a722f9f5d744d508c155fceb9245ca57b5d13bb50000000000000000000000000024d5549bf5c3aca24f1ceaecf50f50c9d92bd7000000000000000000000000127fbbaebce7c6a85fbb2f744ed021ad52eed6fd000000000000000000000000647beca433382e60cfc9adbb3a8bbd2af3d053f8000000000000000000000000a145addb0a24f0c4697189a02eadb006be244d49000000000000000000000000572a26bf9358c099cc2fb0be9c8b99499aca42c500000000000000000000000099784406b8c01a9f752b86b5e6c9180ef7fe6b05000000000000000000000000d723329b502affbc63731fadf546e4fae7d5ee7f0000000000000000000000001ef8598bebc15ba24f3a9fe2255b20b54fbb15a50000000000000000000000009b73899cf3c29adde3086f993b001ab733723a38000000000000000000000000b927340c680a315677b918003fb6189b6d1ca4aa000000000000000000000000924c251902924c7dbd4cbf166d42757fb2d146cb0000000000000000000000000009b5fb5d267c0b91a33cc7ce69aab9b5c62edb000000000000000000000000f21749506cdc7c684b096ba172c99a8878a816fb000000000000000000000000c841cd0ad77d714b3c6ad86c1160034a1f11fed30000000000000000000000004aaddb83fa8f8c8758d38f74f5564fb549846b310000000000000000000000008e9fe6f4717ea81a5bb2a249af41b16e781de4b2000000000000000000000000ba52465fcb173e1965171b31bdd0c9aade3609d2000000000000000000000000c0d3a8d939d8653f0fd8fe7a0646dd38842934660000000000000000000000000960da039bb8151cacfef620476e8baf34bd9565000000000000000000000000b9d00378957f680900c9961cfc1814bc1271c4c00000000000000000000000003e77a7d70e3853e9eaecdf8e3de78e94265fa8e50000000000000000000000003384256f506520a2dc5d51aa081e5016ac6e2730000000000000000000000000392257daecc9b252529167214c9f8ba0a17b0e3600000000000000000000000000a96e78d4900cb5f8c412c1437b15aaf81f6733000000000000000000000000006b65f5189599a187d4f4cc6661166aaafa3ed4000000000000000000000000088cca87b0d829b35efeb6934ff807cd3befc48b00000000000000000000000007895ebad237645e1553dd195e870d2be9803a8d000000000000000000000000489554ab02c071d7279cc1428592c1722ac5e33f000000000000000000000000501ac3b461e7517d07dcb5492679cc7521aadd42000000000000000000000000ffe27b523078303768ac6b2a9ebee8a22902ffaf0000000000000000000000003de61a89290009b34000361cf94d9b7a218cf5eb0000000000000000000000001c74d52ca9d58f629e9b5bdfee0fa82116db047a000000000000000000000000d3438e11d5de4518dcef9a3c455fcb75dcc600cf00000000000000000000000067e0887a3614da0dc94b6b36bc787d7c528ec8c200000000000000000000000000e7b744f07fd1dc016ba84626c2c31edb15b9b70000000000000000000000005f1d2141682745ec493876e13903562cac71b79200000000000000000000000010f77e56bdccade0b4542145e5c408f1f8bf5afb00000000000000000000000000db61875511c11e07ebe53edf787717410fc9160000000000000000000000005f055dcafbc494eb4d634744dd96b0813a718f99000000000000000000000000369342e4617cd365d7ffacbea47ed1a143e48bea0000000000000000000000007139ceeef20464fe9bd2ba713c8a68240f01711d000000000000000000000000704e0de2534102e3102f358e6c78568d13053aaa000000000000000000000000ca568c15453844f78a5bed1c7d74e5c81cca557d000000000000000000000000f6d4d4ddbf3fc684d531b40c3c518d3825f2769d00000000000000000000000045d5eab238d23e668a949ecde1e77163c427533900000000000000000000000033a96b5993f65e26ad4f51b3d3ccea513271b923000000000000000000000000cc6c95e8bc9fe7b9ddccded787276b70728bd91d00000000000000000000000000b88dc7e00c5ad794595f208566bcc15d07f0270000000000000000000000009dc8a0886242b0fd686d8f2a9ed46516090b6fd300000000000000000000000000f26ece6c8716bdded31924b446c92ff388aee200000000000000000000000041fc0c45412422221ee6769f182ca9a344359e3f000000000000000000000000f482bea9f562184be993e9b1ac3d75eff57781ca0000000000000000000000000868411ca03e6655d7ee957089dc983d74b9bf1a0000000000000000000000009f4cb6c14055163e9975ff18e4230c2833f02726000000000000000000000000da6b22f0a07241448bea9dccd02b3b187e343664000000000000000000000000c4e3aac985c8182e3dac6c9b19eb606151fcd7670000000000000000000000003dd361b92ef882c885e3e4a7d634c2d9daedef85000000000000000000000000e4cba77472f36a5ee693b44c84989a1fa576992a00000000000000000000000000b6e47551b16d1919a74e2a6512fde7675e15da000000000000000000000000252fac5e0f04d62aef0556084c2c6e64feef271e000000000000000000000000d1c5e193feb49a59c6bd54b8aa28f22762f89d5500000000000000000000000039990ea12fd788062f16ce81b769bbf0ef9c2c8e000000000000000000000000d4e86be2d4ad7e987ab67ad679ceaeec269573b600000000000000000000000089a12ac6de30463278eb4a0eeebf2da16ea9637d00000000000000000000000000bab0d7068f8b2d753590949879e17faf3f60880000000000000000000000001edef22dccded943a0ddb453647723378c33410a00000000000000000000000055a1cae7f45240680c83dbb7329046f894a7160300000000000000000000000000a888a4cac1a5a82029bff090aaddb98407303a0000000000000000000000002fdefc1c8f299e378473999707aa5ea7c8639af3000000000000000000000000bd9064fdb9a4274df760f8fc14abaf6b86d17f120000000000000000000000004aa7269e78942f8b159db827fdac811587abcf51000000000000000000000000de7799b2d6999ad6a752aa0af8b95fe41e7259150000000000000000000000003115aa1401d5aba3220030d3db298ce8880a46b50000000000000000000000000823c99debd091fe1a736bd3888b1707ed820aec0000000000000000000000002539b51ebde65a75672abcfe9439a706a99d18d100000000000000000000000085c24edf1b51115cdf654c15fd29e1b32752e56700000000000000000000000004a782948d6cea64d5f14d46c18fb33470644fd2000000000000000000000000f476e1267f86247cc908816f2e7ad5388c952db0000000000000000000000000aab54b1b17fd41fbac81758e387bc8eca128ca880000000000000000000000000b6121ddce71373b3c02780b22cc78dd20d3a7f900000000000000000000000059191198028f1e14d3ae814ebdae084f93a1746f000000000000000000000000229a55f621801934acb219478d556c7f128acde60000000000000000000000009608a19685b95c49b86c859bebaf3d1f0e8ffa1a000000000000000000000000c230ce5643a10702111572c938919c9f448c46d80000000000000000000000003744c132637b13f7f410e0580a1fa2393875e4440000000000000000000000008c3720060f8cfdf8b8d4da5698f4f51a48a0828a0000000000000000000000002561a6f4f32908f2bef562987da896701ec943ae00000000000000000000000005939d370ce1a4f7d36b2b1c3c09d84ec4f7e9eb0000000000000000000000000593f77e9d19d4c322e18a24b89dfbfa311ea545000000000000000000000000dcc097955815c69b223865a050800dc44ecaf8ae000000000000000000000000ffdd5bfe33c8fa18af76b944e725b3a116467c640000000000000000000000004995c29a93226c5858711f81e3b75eb2aa0a5a4e0000000000000000000000003c401c200233c07dd9bfdac99edbc01068afe118000000000000000000000000ffc5b23d80b85c2a7a7da49064d7354d09e5e3cf0000000000000000000000009a73c36d924c197c6418a24ea986e5d3f7c1ddf300000000000000000000000000bb85eb9f8e166acef360942ac4e43dda235f0300000000000000000000000000165307057322a93adbe68050159af11966778d000000000000000000000000b45d904431f0fc93f14ed273d7e8acb71339207f0000000000000000000000000681516881536a06497017971c7c86128fab573800000000000000000000000034cc2861eeb213da8bf366becdfb319f16aff12c00000000000000000000000060ba6c590883ab3c06289eff076f96b80065e3f5000000000000000000000000e835ec939021aa1189d4ddf3ae1544b62f9579ab0000000000000000000000009a94771e7e73f9d8d6e880cfb12cab4e9573c45e0000000000000000000000006d805c47cd158bee253986cfbfcfce34fdb33efe000000000000000000000000baa68aa7b1257305ab9d968e51786897e0e423b70000000000000000000000006d0bb4ce7acc1ba71af6d1858dea64c6073dc27e00000000000000000000000007bd15dcb7f83045d3583ae385b4b549951a33c2000000000000000000000000145663520246b70e32c96411b33f8dc71d4100dd000000000000000000000000bccb13f64b2708f400304cbd10044c589c116925000000000000000000000000e414feaddd562b0071810d1b1b4d8bb85171632d0000000000000000000000005f9d89858fee7de8f28e21e62650bf1322c714f10000000000000000000000007c0fba9557b8f909ab8d69d8da1944501b6a9d07000000000000000000000000b1ccab138e6c6a704f9bf607a71c342cfc9480530000000000000000000000000e0193a44c0d7e36b8faff8fd3d9004d5bb5ff0900000000000000000000000000c2e468cd0f9576c6540f425baf64969205b40c00000000000000000000000082e4d78c6c62d461251fa5a1d4deb9f0fe378e300000000000000000000000001bbcc79b91bee48b60da56329b7f0c5d797d56ed000000000000000000000000007d2f4fe301922c560d1a752836c4e99e0ed63c000000000000000000000000e9ebee76a902b6536c0bddf79ac4c4343e5bdbfb000000000000000000000000ec000c5461cdbc4497d61245176260671db70d88000000000000000000000000a20ad2f8ad42831e9dc82c05715bcaaec84f9abb000000000000000000000000ff52c5c250d63e6903aa7b7bd4c256bf4743260200000000000000000000000000582f083582f59a0da86a0688332c77c7044a3a00000000000000000000000002c68e3de38b00f958a53bd9182d09120312b2a20000000000000000000000000e6ead010b7249b46c56972a309d1376e53d9d5000000000000000000000000034a0cd27e8489ad7346a9a40e2205cf6b715b3640000000000000000000000007fc796922627eed6faf6c26e01a32c33b5fc91310000000000000000000000007f8e672a3079d3976ebc2b3cb5179dbd7986352900000000000000000000000070e8818a14d8841604497990bbd181170661a85e0000000000000000000000005df3bba2cb0b3aa00fa940c14e2cc57f2cba303a0000000000000000000000007c1b4e9d3df68577655f67057a5076c9cdd8a7ed000000000000000000000000f190f0193b694d9d2bb865a66f0c17cbd8280c71000000000000000000000000a07b4b955c69afbdb1e7c2eadf28e50bcc3f4c93000000000000000000000000e909e1c946c057d06b79cc72ebcb5b168c6e6d4900000000000000000000000076927e2ccab0084bd19cee74f78b63134b9d181e000000000000000000000000be0b69edc6e0aaae42b9964af162f8a4a2ffe5950000000000000000000000006cb9e3274799ca43ec2582335867b9f7520d9f2600000000000000000000000022c8d09305d827f1cdf696d1b9ee309227938f950000000000000000000000005c72da9cad883d790eb1e4165cf2441b3be165e2000000000000000000000000cb3bb2e2cbfa6dc19c2ba39d7f9aaa022f0bdc8f000000000000000000000000ba881a7b7f829d5c25bd120b3e80c640cd8ae0d6000000000000000000000000b46ac18f8fc29c552450e1ba67272e8dfc828fd10000000000000000000000006e9ec23df252c5ded1e83b2a19fc5d79759acf0300000000000000000000000028091e33df862922f1a1fc62e60af9f791cb4dec000000000000000000000000e60c6d66c42b97300f116f34e2b971d8a627d557000000000000000000000000662a80dd9b873913cfdeef75f771159a6782f3d8000000000000000000000000848c98731d0122e32217dcafe0ee67842f3533e600000000000000000000000076cd7f9cb7030803fff92875c49df9aa8c558344000000000000000000000000d48505ee38c6e933defa82e068d063b300781df8000000000000000000000000004ba25b9b23ac7b4dd583c7e6a8e811dd32e60800000000000000000000000043215241c3def445e151a881db883a66c2df9bbe0000000000000000000000008c0114f7507485c2289cb4fc7fadb61d4e2f49b30000000000000000000000002a980afd3cf9ba8bbb15ea10fe952d96641f034600000000000000000000000076c265bdaa4350ed138735b7a514adb1a89b71e20000000000000000000000000a69945a4f4cd87b925a34fc9c641efc1da664d6000000000000000000000000eaa25ac8a4cc52451917238638453737af6e4a31000000000000000000000000717a58ed0ec76d4cfe0b64c0e112ce015653edb200000000000000000000000028472e097c91d75f6aa557c0223e50960078a6d00000000000000000000000009d50ca863d28c946a05560e9bd993ba4c2d1f95400000000000000000000000028b54d4534052214f134a995663af9c6bdaea4350000000000000000000000008215d8fde5eaf58901d01a438f7188016369b91f000000000000000000000000f5b9f5c093b63a609711fb56f6b8484013ffa0280000000000000000000000001c2e28d5e50dedd1dc8936d681b32d2458533d740000000000000000000000006c27ea4b5d281e81e5a833a5e6e1c5a74f9b47be000000000000000000000000d78fd123d2bc2da7bb5621c753dc665d3c0e85ac000000000000000000000000049503a94f506b601661d8bc792a2cc59ea230d90000000000000000000000000c6ead592dd190072e898e807f2fc68e98bcd8be000000000000000000000000047eb968d0dce70280352d0834ab9f6b536da16f0000000000000000000000008f212180bf6b8178559a67268502057fb0043dd90000000000000000000000009faaa0efbe61bc445e1068ab1cd67f23b45d624f000000000000000000000000c6cc76eb55c49a839444800b66a66cbddf76e3e0000000000000000000000000a39166df6f039ba348d7cfa353280d19dde04cd8000000000000000000000000b0323032e7cc95e17555e9fb37b33095eee235f000000000000000000000000078d8e8807f652b54afe33b7645a26c5ffae5291c0000000000000000000000003dd932d51fb898374e694d764d059d2e2453e4d1000000000000000000000000e7dc484e59f6b7ed74bc72a1129144f9ea4bf89a0000000000000000000000007ebe9268b8f7ff0b098a8567bf7490d33123da4d000000000000000000000000f3cdf271ccaafb591372f81521bd2019701def1b00000000000000000000000037e102aab262f27e73a9733c7678d0d58ed7a5ab000000000000000000000000e055aff35a3f212e713922e296d295fb50d6edb90000000000000000000000006317dac8332f0b3ef49146b45a6726cdb78c4dcf000000000000000000000000ef243aa4f940e72eb1d7ebab724672d88b4f18ed00000000000000000000000080259bc4e86f3fa837491838562e418a56a3359f0000000000000000000000002bae4bf3595b96b2f07492b7d1622e3703e604f80000000000000000000000000028673fc0a9532a5c0af61ebb8369a4e5219ec00000000000000000000000000b77e9fd0166dd1a59fad0d1393bfc41d2bc6f26000000000000000000000000e0da8ed5b7b775b5fdf285131646fe2f54ef0005000000000000000000000000f70145fe48ab5606890a98d19949edd2516ea2400000000000000000000000009466c086239a0fd38932608572cebb97d1d42ee5000000000000000000000000f769dbd6d5c2cf4db888f59c5768901411160e88000000000000000000000000a35b60fe8eb8184a379a0d0b726f3ceb57ee907300000000000000000000000027dadeb9e5e35881402d54286af63cc63505163a0000000000000000000000009dac72188aeb760b60bef84b85cfa5bb2dfd9b69000000000000000000000000e9080374375a1f92e2edf6f314ea2ec1800979fe000000000000000000000000003bb89e2cd29acd745b11dc9d13a38bcce6c24200000000000000000000000074c072d1bd63e0b922d0befd79b3ee1fcc3a8336000000000000000000000000cef0e56b84ad7d5be9edcb7faf66f85ae83942a4000000000000000000000000a6d0c47df7af1ecdd555d08c44ca4f7186e6e982000000000000000000000000005fe92d7a91a045ff6cfe888b0b982cd3f2a06b000000000000000000000000678fb21b9736e6c7da9f7d37a77ab766bb2519c70000000000000000000000002e15d7aa0650de1009710fdd45c3468d75ae1392000000000000000000000000fd516ec936908f1f409cd48c05fbbfabacdfa52000000000000000000000000094d9cd17d85d2afa8d71283d94386281f16612bd00000000000000000000000007ca04dea1b05ef526f69f82661aa2bc911c7ab2000000000000000000000000ebeabcb3dd92973f863ce54bce5e1e4322777210000000000000000000000000b38ecc6ec2fcaecfc8987f25ae58622a91a230340000000000000000000000002565f8e0b33f2d3bb1c0e2dd5fbb972df48654c8000000000000000000000000428512bd5e9f8e486972c89b423eed37d304d786000000000000000000000000b92f2e00983faa34b4afac034aa85569df78039f00000000000000000000000023b991f7be7afc8706dcef2f04288b44b455feb700000000000000000000000096f57b3b2aee2f15198cc2862d17eb32591c0208000000000000000000000000abd4277717fd22b4e91232578c34478546dc381f000000000000000000000000edb34a82f00c71c2082171e4365ea85d422620af00000000000000000000000067a01ab58cc873bfbd93c89f2b0897e85007b772000000000000000000000000cf093b6dfce969e640dbd38d7302ce2e7ca531df00000000000000000000000054620853f4f0799bee70832b767fcb6ed5b48eba0000000000000000000000007a836b45c06e57c65451c41168a7f269146b1b0d0000000000000000000000002d50a018e1c5194334d8ce52d7152d2ac99f7b370000000000000000000000000d8571cf484de9f090edb7e51882d60402212d83000000000000000000000000d1f982eca739bd2165ea085c379231646302eae30000000000000000000000000451b45ca19945c38adc39bc91f45b3d518aa8e3000000000000000000000000002b254abdcef1f9af4e56f0e9776bc1feea1edc00000000000000000000000040692724326503b8fdc8472df7ee658f4bdbfc890000000000000000000000006c66ebb344c3251fbd49cf00b93ebb562f3637c600000000000000000000000027570157d3b72560143af4d8a4528117e22155750000000000000000000000007837d0bfec3abd92a1720f21c77aef0b71d0f58e00000000000000000000000061779ad9d36ba354e235c59fb48651ace92f9fae000000000000000000000000c08d21eb6000357b3d70fbedaf6a1ce5c94d6286000000000000000000000000a7e51da6df5079e42048f43ffb355952cbfd504d000000000000000000000000d93e1bd6d0716ecdeff07f59d31fdf3679250f3a0000000000000000000000006065043d769e88421e2592472a2394d4b5ca1b44000000000000000000000000efe628e9239bf3dc14766aa465064e1784edc05200000000000000000000000050f5ff6683b508f356f97beee5728a38abe3b51e0000000000000000000000009c232158b5e0f9a23bf9a399cd9197c7f131d13b000000000000000000000000c2e82b98ebb92cf36faa85fba798f838a86843d40000000000000000000000008e6ceca77bd9ae8a2c7f9d11870ec80ba6ab751c", contractAddress: "", cumulativeGasUsed: "5119803", gasUsed: "4000000", confirmations: "3435380"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210],addressList[211],addressList[212],addressList[213],addressList[214],addressList[215],addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[221],addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229],addressList[230],addressList[231],addressList[232],addressList[233],addressList[234],addressList[235],addressList[236],addressList[237],addressList[238],addressList[239],addressList[240],addressList[241],addressList[242],addressList[243],addressList[244],addressList[245],addressList[246],addressList[247],addressList[248],addressList[249],addressList[250],addressList[251],addressList[252],addressList[253],addressList[254],addressList[255],addressList[256],addressList[257],addressList[258],addressList[259],addressList[260],addressList[261],addressList[262],addressList[263],addressList[264],addressList[265],addressList[266],addressList[267],addressList[268],addressList[269],addressList[270],addressList[271],addressList[272],addressList[273],addressList[274],addressList[275],addressList[276],addressList[277],addressList[278],addressList[279],addressList[280],addressList[281],addressList[282],addressList[283],addressList[284],addressList[285],addressList[286],addressList[287]]}, {type: "uint256", name: "_tier", value: "1"}, {type: "bool", name: "_status", value: true}], name: "whitelistAddresses", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistAddresses( [addressList[24],addressList[25],address... )", async function( ) {
		const txOriginal = {blockNumber: "4269744", timeStamp: "1505311900", hash: "0x4423ff30f350e7e768adb8ff9bd870d10e8ca34aa5565361d77f4f917030a751", nonce: "34", blockHash: "0x82252bd6429aac81e97fa9b639ab672e961a965621462e38b1538168215eafb0", transactionIndex: "32", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "4000000", gasPrice: "22463230501", isError: "1", txreceipt_status: "", input: "0x763730bd000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000007600000000000000000000000011df9c71b1ef9b69607a937f50a625e258733200000000000000000000000000009e02b21abefc7ecc1f2b11700b49106d7d552b000000000000000000000000213ee0a9390921f5a0178bf421d45a1985ee38a4000000000000000000000000b875f205eb38ef3d0a1801aea1df08ae78933dad000000000000000000000000ba4115e85d09e3ef52c788043372cea95368548f000000000000000000000000ce632aef4c0822b97f2862b3dc9a70d3ac06faa5000000000000000000000000009d06cc6b11fa75412c3cda6da63813bbbdafaf00000000000000000000000010388a4db0b0eef4afd11b3e58a63eda90fba1ca00000000000000000000000079b4b5287add11272a0c626afc3006844e5bdfcd00000000000000000000000022b2b07b38fe213ba32012ab30f05ed98f29ed31000000000000000000000000447c2f2a93b0a7b76a880639712ab9dd1963d44c000000000000000000000000f8cde04ac5c33f235eb3cb138b301379bcf33fff000000000000000000000000622b2c840d856181661482a2f7d9a5a41e0f992a00000000000000000000000022aae1d3caebaababe90016fcade68652414b0e0000000000000000000000000c7df8a3b4eab37bab57f90f60d17d8bec01f568c000000000000000000000000f0f646f6b61f57ad28d2ab3a8c21110011d1a64c00000000000000000000000084484b1b89941a1db3a3222bcd75823095abaca70000000000000000000000001da422eded980a4e633da67bd30c60765e872cba0000000000000000000000000676949e2ee6574e7d1a80870cabde22724f21210000000000000000000000008b22030f19431feac38bb5201f16f3935e7cd447000000000000000000000000392028f4a6a7322b00638039663b2118dac92263000000000000000000000000ed50b8b0adf6b37ad15635dbc7e53f4a705014b90000000000000000000000000b6df62a52e9c60f07fc8b4d4f90cab716367fb700000000000000000000000055b22ac7ddad396e703f38d04009540490d122bf000000000000000000000000c458def22aed52417c4b78ead6841d382aa9d42700000000000000000000000042b7dec83f4dfdaa70416d7a7e1951ad8e6e7847000000000000000000000000c967e3c453caa4583451e2f7a4080e56e165e202000000000000000000000000a722f9f5d744d508c155fceb9245ca57b5d13bb50000000000000000000000000024d5549bf5c3aca24f1ceaecf50f50c9d92bd7000000000000000000000000127fbbaebce7c6a85fbb2f744ed021ad52eed6fd000000000000000000000000647beca433382e60cfc9adbb3a8bbd2af3d053f8000000000000000000000000a145addb0a24f0c4697189a02eadb006be244d49000000000000000000000000572a26bf9358c099cc2fb0be9c8b99499aca42c500000000000000000000000099784406b8c01a9f752b86b5e6c9180ef7fe6b05000000000000000000000000d723329b502affbc63731fadf546e4fae7d5ee7f0000000000000000000000001ef8598bebc15ba24f3a9fe2255b20b54fbb15a50000000000000000000000009b73899cf3c29adde3086f993b001ab733723a38000000000000000000000000b927340c680a315677b918003fb6189b6d1ca4aa000000000000000000000000924c251902924c7dbd4cbf166d42757fb2d146cb0000000000000000000000000009b5fb5d267c0b91a33cc7ce69aab9b5c62edb000000000000000000000000f21749506cdc7c684b096ba172c99a8878a816fb000000000000000000000000c841cd0ad77d714b3c6ad86c1160034a1f11fed30000000000000000000000004aaddb83fa8f8c8758d38f74f5564fb549846b310000000000000000000000008e9fe6f4717ea81a5bb2a249af41b16e781de4b2000000000000000000000000ba52465fcb173e1965171b31bdd0c9aade3609d2000000000000000000000000c0d3a8d939d8653f0fd8fe7a0646dd38842934660000000000000000000000000960da039bb8151cacfef620476e8baf34bd9565000000000000000000000000b9d00378957f680900c9961cfc1814bc1271c4c00000000000000000000000003e77a7d70e3853e9eaecdf8e3de78e94265fa8e50000000000000000000000003384256f506520a2dc5d51aa081e5016ac6e2730000000000000000000000000392257daecc9b252529167214c9f8ba0a17b0e3600000000000000000000000000a96e78d4900cb5f8c412c1437b15aaf81f6733000000000000000000000000006b65f5189599a187d4f4cc6661166aaafa3ed4000000000000000000000000088cca87b0d829b35efeb6934ff807cd3befc48b00000000000000000000000007895ebad237645e1553dd195e870d2be9803a8d000000000000000000000000489554ab02c071d7279cc1428592c1722ac5e33f000000000000000000000000501ac3b461e7517d07dcb5492679cc7521aadd42000000000000000000000000ffe27b523078303768ac6b2a9ebee8a22902ffaf0000000000000000000000003de61a89290009b34000361cf94d9b7a218cf5eb0000000000000000000000001c74d52ca9d58f629e9b5bdfee0fa82116db047a000000000000000000000000d3438e11d5de4518dcef9a3c455fcb75dcc600cf00000000000000000000000067e0887a3614da0dc94b6b36bc787d7c528ec8c200000000000000000000000000e7b744f07fd1dc016ba84626c2c31edb15b9b70000000000000000000000005f1d2141682745ec493876e13903562cac71b79200000000000000000000000010f77e56bdccade0b4542145e5c408f1f8bf5afb00000000000000000000000000db61875511c11e07ebe53edf787717410fc9160000000000000000000000005f055dcafbc494eb4d634744dd96b0813a718f99000000000000000000000000369342e4617cd365d7ffacbea47ed1a143e48bea0000000000000000000000007139ceeef20464fe9bd2ba713c8a68240f01711d000000000000000000000000704e0de2534102e3102f358e6c78568d13053aaa000000000000000000000000ca568c15453844f78a5bed1c7d74e5c81cca557d000000000000000000000000f6d4d4ddbf3fc684d531b40c3c518d3825f2769d00000000000000000000000045d5eab238d23e668a949ecde1e77163c427533900000000000000000000000033a96b5993f65e26ad4f51b3d3ccea513271b923000000000000000000000000cc6c95e8bc9fe7b9ddccded787276b70728bd91d00000000000000000000000000b88dc7e00c5ad794595f208566bcc15d07f0270000000000000000000000009dc8a0886242b0fd686d8f2a9ed46516090b6fd300000000000000000000000000f26ece6c8716bdded31924b446c92ff388aee200000000000000000000000041fc0c45412422221ee6769f182ca9a344359e3f000000000000000000000000f482bea9f562184be993e9b1ac3d75eff57781ca0000000000000000000000000868411ca03e6655d7ee957089dc983d74b9bf1a0000000000000000000000009f4cb6c14055163e9975ff18e4230c2833f02726000000000000000000000000da6b22f0a07241448bea9dccd02b3b187e343664000000000000000000000000c4e3aac985c8182e3dac6c9b19eb606151fcd7670000000000000000000000003dd361b92ef882c885e3e4a7d634c2d9daedef85000000000000000000000000e4cba77472f36a5ee693b44c84989a1fa576992a00000000000000000000000000b6e47551b16d1919a74e2a6512fde7675e15da000000000000000000000000252fac5e0f04d62aef0556084c2c6e64feef271e000000000000000000000000d1c5e193feb49a59c6bd54b8aa28f22762f89d5500000000000000000000000039990ea12fd788062f16ce81b769bbf0ef9c2c8e000000000000000000000000d4e86be2d4ad7e987ab67ad679ceaeec269573b600000000000000000000000089a12ac6de30463278eb4a0eeebf2da16ea9637d00000000000000000000000000bab0d7068f8b2d753590949879e17faf3f60880000000000000000000000001edef22dccded943a0ddb453647723378c33410a00000000000000000000000055a1cae7f45240680c83dbb7329046f894a7160300000000000000000000000000a888a4cac1a5a82029bff090aaddb98407303a0000000000000000000000002fdefc1c8f299e378473999707aa5ea7c8639af3000000000000000000000000bd9064fdb9a4274df760f8fc14abaf6b86d17f120000000000000000000000004aa7269e78942f8b159db827fdac811587abcf51000000000000000000000000de7799b2d6999ad6a752aa0af8b95fe41e7259150000000000000000000000003115aa1401d5aba3220030d3db298ce8880a46b50000000000000000000000000823c99debd091fe1a736bd3888b1707ed820aec0000000000000000000000002539b51ebde65a75672abcfe9439a706a99d18d100000000000000000000000085c24edf1b51115cdf654c15fd29e1b32752e56700000000000000000000000004a782948d6cea64d5f14d46c18fb33470644fd2000000000000000000000000f476e1267f86247cc908816f2e7ad5388c952db0000000000000000000000000aab54b1b17fd41fbac81758e387bc8eca128ca880000000000000000000000000b6121ddce71373b3c02780b22cc78dd20d3a7f900000000000000000000000059191198028f1e14d3ae814ebdae084f93a1746f000000000000000000000000229a55f621801934acb219478d556c7f128acde60000000000000000000000009608a19685b95c49b86c859bebaf3d1f0e8ffa1a000000000000000000000000c230ce5643a10702111572c938919c9f448c46d80000000000000000000000003744c132637b13f7f410e0580a1fa2393875e4440000000000000000000000008c3720060f8cfdf8b8d4da5698f4f51a48a0828a0000000000000000000000002561a6f4f32908f2bef562987da896701ec943ae00000000000000000000000005939d370ce1a4f7d36b2b1c3c09d84ec4f7e9eb0000000000000000000000000593f77e9d19d4c322e18a24b89dfbfa311ea545000000000000000000000000dcc097955815c69b223865a050800dc44ecaf8ae", contractAddress: "", cumulativeGasUsed: "5166003", gasUsed: "4000000", confirmations: "3435378"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141]]}, {type: "uint256", name: "_tier", value: "1"}, {type: "bool", name: "_status", value: true}], name: "whitelistAddresses", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistAddresses( [addressList[24],addressList[25],address... )", async function( ) {
		const txOriginal = {blockNumber: "4269760", timeStamp: "1505312249", hash: "0x18e2d7c9ab085aa2ad044a7bd38a4899d1afc04311242d83e0c6f285b98b8ced", nonce: "35", blockHash: "0x6d45674c65c328faab707cc49430872effeb496e4340f0b7024953d4b303daa4", transactionIndex: "5", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "6500000", gasPrice: "22463230501", isError: "0", txreceipt_status: "", input: "0x763730bd000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000007600000000000000000000000011df9c71b1ef9b69607a937f50a625e258733200000000000000000000000000009e02b21abefc7ecc1f2b11700b49106d7d552b000000000000000000000000213ee0a9390921f5a0178bf421d45a1985ee38a4000000000000000000000000b875f205eb38ef3d0a1801aea1df08ae78933dad000000000000000000000000ba4115e85d09e3ef52c788043372cea95368548f000000000000000000000000ce632aef4c0822b97f2862b3dc9a70d3ac06faa5000000000000000000000000009d06cc6b11fa75412c3cda6da63813bbbdafaf00000000000000000000000010388a4db0b0eef4afd11b3e58a63eda90fba1ca00000000000000000000000079b4b5287add11272a0c626afc3006844e5bdfcd00000000000000000000000022b2b07b38fe213ba32012ab30f05ed98f29ed31000000000000000000000000447c2f2a93b0a7b76a880639712ab9dd1963d44c000000000000000000000000f8cde04ac5c33f235eb3cb138b301379bcf33fff000000000000000000000000622b2c840d856181661482a2f7d9a5a41e0f992a00000000000000000000000022aae1d3caebaababe90016fcade68652414b0e0000000000000000000000000c7df8a3b4eab37bab57f90f60d17d8bec01f568c000000000000000000000000f0f646f6b61f57ad28d2ab3a8c21110011d1a64c00000000000000000000000084484b1b89941a1db3a3222bcd75823095abaca70000000000000000000000001da422eded980a4e633da67bd30c60765e872cba0000000000000000000000000676949e2ee6574e7d1a80870cabde22724f21210000000000000000000000008b22030f19431feac38bb5201f16f3935e7cd447000000000000000000000000392028f4a6a7322b00638039663b2118dac92263000000000000000000000000ed50b8b0adf6b37ad15635dbc7e53f4a705014b90000000000000000000000000b6df62a52e9c60f07fc8b4d4f90cab716367fb700000000000000000000000055b22ac7ddad396e703f38d04009540490d122bf000000000000000000000000c458def22aed52417c4b78ead6841d382aa9d42700000000000000000000000042b7dec83f4dfdaa70416d7a7e1951ad8e6e7847000000000000000000000000c967e3c453caa4583451e2f7a4080e56e165e202000000000000000000000000a722f9f5d744d508c155fceb9245ca57b5d13bb50000000000000000000000000024d5549bf5c3aca24f1ceaecf50f50c9d92bd7000000000000000000000000127fbbaebce7c6a85fbb2f744ed021ad52eed6fd000000000000000000000000647beca433382e60cfc9adbb3a8bbd2af3d053f8000000000000000000000000a145addb0a24f0c4697189a02eadb006be244d49000000000000000000000000572a26bf9358c099cc2fb0be9c8b99499aca42c500000000000000000000000099784406b8c01a9f752b86b5e6c9180ef7fe6b05000000000000000000000000d723329b502affbc63731fadf546e4fae7d5ee7f0000000000000000000000001ef8598bebc15ba24f3a9fe2255b20b54fbb15a50000000000000000000000009b73899cf3c29adde3086f993b001ab733723a38000000000000000000000000b927340c680a315677b918003fb6189b6d1ca4aa000000000000000000000000924c251902924c7dbd4cbf166d42757fb2d146cb0000000000000000000000000009b5fb5d267c0b91a33cc7ce69aab9b5c62edb000000000000000000000000f21749506cdc7c684b096ba172c99a8878a816fb000000000000000000000000c841cd0ad77d714b3c6ad86c1160034a1f11fed30000000000000000000000004aaddb83fa8f8c8758d38f74f5564fb549846b310000000000000000000000008e9fe6f4717ea81a5bb2a249af41b16e781de4b2000000000000000000000000ba52465fcb173e1965171b31bdd0c9aade3609d2000000000000000000000000c0d3a8d939d8653f0fd8fe7a0646dd38842934660000000000000000000000000960da039bb8151cacfef620476e8baf34bd9565000000000000000000000000b9d00378957f680900c9961cfc1814bc1271c4c00000000000000000000000003e77a7d70e3853e9eaecdf8e3de78e94265fa8e50000000000000000000000003384256f506520a2dc5d51aa081e5016ac6e2730000000000000000000000000392257daecc9b252529167214c9f8ba0a17b0e3600000000000000000000000000a96e78d4900cb5f8c412c1437b15aaf81f6733000000000000000000000000006b65f5189599a187d4f4cc6661166aaafa3ed4000000000000000000000000088cca87b0d829b35efeb6934ff807cd3befc48b00000000000000000000000007895ebad237645e1553dd195e870d2be9803a8d000000000000000000000000489554ab02c071d7279cc1428592c1722ac5e33f000000000000000000000000501ac3b461e7517d07dcb5492679cc7521aadd42000000000000000000000000ffe27b523078303768ac6b2a9ebee8a22902ffaf0000000000000000000000003de61a89290009b34000361cf94d9b7a218cf5eb0000000000000000000000001c74d52ca9d58f629e9b5bdfee0fa82116db047a000000000000000000000000d3438e11d5de4518dcef9a3c455fcb75dcc600cf00000000000000000000000067e0887a3614da0dc94b6b36bc787d7c528ec8c200000000000000000000000000e7b744f07fd1dc016ba84626c2c31edb15b9b70000000000000000000000005f1d2141682745ec493876e13903562cac71b79200000000000000000000000010f77e56bdccade0b4542145e5c408f1f8bf5afb00000000000000000000000000db61875511c11e07ebe53edf787717410fc9160000000000000000000000005f055dcafbc494eb4d634744dd96b0813a718f99000000000000000000000000369342e4617cd365d7ffacbea47ed1a143e48bea0000000000000000000000007139ceeef20464fe9bd2ba713c8a68240f01711d000000000000000000000000704e0de2534102e3102f358e6c78568d13053aaa000000000000000000000000ca568c15453844f78a5bed1c7d74e5c81cca557d000000000000000000000000f6d4d4ddbf3fc684d531b40c3c518d3825f2769d00000000000000000000000045d5eab238d23e668a949ecde1e77163c427533900000000000000000000000033a96b5993f65e26ad4f51b3d3ccea513271b923000000000000000000000000cc6c95e8bc9fe7b9ddccded787276b70728bd91d00000000000000000000000000b88dc7e00c5ad794595f208566bcc15d07f0270000000000000000000000009dc8a0886242b0fd686d8f2a9ed46516090b6fd300000000000000000000000000f26ece6c8716bdded31924b446c92ff388aee200000000000000000000000041fc0c45412422221ee6769f182ca9a344359e3f000000000000000000000000f482bea9f562184be993e9b1ac3d75eff57781ca0000000000000000000000000868411ca03e6655d7ee957089dc983d74b9bf1a0000000000000000000000009f4cb6c14055163e9975ff18e4230c2833f02726000000000000000000000000da6b22f0a07241448bea9dccd02b3b187e343664000000000000000000000000c4e3aac985c8182e3dac6c9b19eb606151fcd7670000000000000000000000003dd361b92ef882c885e3e4a7d634c2d9daedef85000000000000000000000000e4cba77472f36a5ee693b44c84989a1fa576992a00000000000000000000000000b6e47551b16d1919a74e2a6512fde7675e15da000000000000000000000000252fac5e0f04d62aef0556084c2c6e64feef271e000000000000000000000000d1c5e193feb49a59c6bd54b8aa28f22762f89d5500000000000000000000000039990ea12fd788062f16ce81b769bbf0ef9c2c8e000000000000000000000000d4e86be2d4ad7e987ab67ad679ceaeec269573b600000000000000000000000089a12ac6de30463278eb4a0eeebf2da16ea9637d00000000000000000000000000bab0d7068f8b2d753590949879e17faf3f60880000000000000000000000001edef22dccded943a0ddb453647723378c33410a00000000000000000000000055a1cae7f45240680c83dbb7329046f894a7160300000000000000000000000000a888a4cac1a5a82029bff090aaddb98407303a0000000000000000000000002fdefc1c8f299e378473999707aa5ea7c8639af3000000000000000000000000bd9064fdb9a4274df760f8fc14abaf6b86d17f120000000000000000000000004aa7269e78942f8b159db827fdac811587abcf51000000000000000000000000de7799b2d6999ad6a752aa0af8b95fe41e7259150000000000000000000000003115aa1401d5aba3220030d3db298ce8880a46b50000000000000000000000000823c99debd091fe1a736bd3888b1707ed820aec0000000000000000000000002539b51ebde65a75672abcfe9439a706a99d18d100000000000000000000000085c24edf1b51115cdf654c15fd29e1b32752e56700000000000000000000000004a782948d6cea64d5f14d46c18fb33470644fd2000000000000000000000000f476e1267f86247cc908816f2e7ad5388c952db0000000000000000000000000aab54b1b17fd41fbac81758e387bc8eca128ca880000000000000000000000000b6121ddce71373b3c02780b22cc78dd20d3a7f900000000000000000000000059191198028f1e14d3ae814ebdae084f93a1746f000000000000000000000000229a55f621801934acb219478d556c7f128acde60000000000000000000000009608a19685b95c49b86c859bebaf3d1f0e8ffa1a000000000000000000000000c230ce5643a10702111572c938919c9f448c46d80000000000000000000000003744c132637b13f7f410e0580a1fa2393875e4440000000000000000000000008c3720060f8cfdf8b8d4da5698f4f51a48a0828a0000000000000000000000002561a6f4f32908f2bef562987da896701ec943ae00000000000000000000000005939d370ce1a4f7d36b2b1c3c09d84ec4f7e9eb0000000000000000000000000593f77e9d19d4c322e18a24b89dfbfa311ea545000000000000000000000000dcc097955815c69b223865a050800dc44ecaf8ae", contractAddress: "", cumulativeGasUsed: "5808851", gasUsed: "5619717", confirmations: "3435362"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141]]}, {type: "uint256", name: "_tier", value: "1"}, {type: "bool", name: "_status", value: true}], name: "whitelistAddresses", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistAddresses(address[],uint256,bool)" ]( [addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141]], "1", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1505312249 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistAddresses( [addressList[24],addressList[25],address... )", async function( ) {
		const txOriginal = {blockNumber: "4269765", timeStamp: "1505312331", hash: "0xb326bb64f75a8443ae62bff86aecdeec9af0b000f22efaae6277519177912b6f", nonce: "36", blockHash: "0x9ae9725f064cf7e17e8c136814f206f005ba03785c3066b02c1994b25c338535", transactionIndex: "9", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "5619717", gasPrice: "22463230501", isError: "0", txreceipt_status: "", input: "0x763730bd000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000007600000000000000000000000011df9c71b1ef9b69607a937f50a625e258733200000000000000000000000000009e02b21abefc7ecc1f2b11700b49106d7d552b000000000000000000000000213ee0a9390921f5a0178bf421d45a1985ee38a4000000000000000000000000b875f205eb38ef3d0a1801aea1df08ae78933dad000000000000000000000000ba4115e85d09e3ef52c788043372cea95368548f000000000000000000000000ce632aef4c0822b97f2862b3dc9a70d3ac06faa5000000000000000000000000009d06cc6b11fa75412c3cda6da63813bbbdafaf00000000000000000000000010388a4db0b0eef4afd11b3e58a63eda90fba1ca00000000000000000000000079b4b5287add11272a0c626afc3006844e5bdfcd00000000000000000000000022b2b07b38fe213ba32012ab30f05ed98f29ed31000000000000000000000000447c2f2a93b0a7b76a880639712ab9dd1963d44c000000000000000000000000f8cde04ac5c33f235eb3cb138b301379bcf33fff000000000000000000000000622b2c840d856181661482a2f7d9a5a41e0f992a00000000000000000000000022aae1d3caebaababe90016fcade68652414b0e0000000000000000000000000c7df8a3b4eab37bab57f90f60d17d8bec01f568c000000000000000000000000f0f646f6b61f57ad28d2ab3a8c21110011d1a64c00000000000000000000000084484b1b89941a1db3a3222bcd75823095abaca70000000000000000000000001da422eded980a4e633da67bd30c60765e872cba0000000000000000000000000676949e2ee6574e7d1a80870cabde22724f21210000000000000000000000008b22030f19431feac38bb5201f16f3935e7cd447000000000000000000000000392028f4a6a7322b00638039663b2118dac92263000000000000000000000000ed50b8b0adf6b37ad15635dbc7e53f4a705014b90000000000000000000000000b6df62a52e9c60f07fc8b4d4f90cab716367fb700000000000000000000000055b22ac7ddad396e703f38d04009540490d122bf000000000000000000000000c458def22aed52417c4b78ead6841d382aa9d42700000000000000000000000042b7dec83f4dfdaa70416d7a7e1951ad8e6e7847000000000000000000000000c967e3c453caa4583451e2f7a4080e56e165e202000000000000000000000000a722f9f5d744d508c155fceb9245ca57b5d13bb50000000000000000000000000024d5549bf5c3aca24f1ceaecf50f50c9d92bd7000000000000000000000000127fbbaebce7c6a85fbb2f744ed021ad52eed6fd000000000000000000000000647beca433382e60cfc9adbb3a8bbd2af3d053f8000000000000000000000000a145addb0a24f0c4697189a02eadb006be244d49000000000000000000000000572a26bf9358c099cc2fb0be9c8b99499aca42c500000000000000000000000099784406b8c01a9f752b86b5e6c9180ef7fe6b05000000000000000000000000d723329b502affbc63731fadf546e4fae7d5ee7f0000000000000000000000001ef8598bebc15ba24f3a9fe2255b20b54fbb15a50000000000000000000000009b73899cf3c29adde3086f993b001ab733723a38000000000000000000000000b927340c680a315677b918003fb6189b6d1ca4aa000000000000000000000000924c251902924c7dbd4cbf166d42757fb2d146cb0000000000000000000000000009b5fb5d267c0b91a33cc7ce69aab9b5c62edb000000000000000000000000f21749506cdc7c684b096ba172c99a8878a816fb000000000000000000000000c841cd0ad77d714b3c6ad86c1160034a1f11fed30000000000000000000000004aaddb83fa8f8c8758d38f74f5564fb549846b310000000000000000000000008e9fe6f4717ea81a5bb2a249af41b16e781de4b2000000000000000000000000ba52465fcb173e1965171b31bdd0c9aade3609d2000000000000000000000000c0d3a8d939d8653f0fd8fe7a0646dd38842934660000000000000000000000000960da039bb8151cacfef620476e8baf34bd9565000000000000000000000000b9d00378957f680900c9961cfc1814bc1271c4c00000000000000000000000003e77a7d70e3853e9eaecdf8e3de78e94265fa8e50000000000000000000000003384256f506520a2dc5d51aa081e5016ac6e2730000000000000000000000000392257daecc9b252529167214c9f8ba0a17b0e3600000000000000000000000000a96e78d4900cb5f8c412c1437b15aaf81f6733000000000000000000000000006b65f5189599a187d4f4cc6661166aaafa3ed4000000000000000000000000088cca87b0d829b35efeb6934ff807cd3befc48b00000000000000000000000007895ebad237645e1553dd195e870d2be9803a8d000000000000000000000000489554ab02c071d7279cc1428592c1722ac5e33f000000000000000000000000501ac3b461e7517d07dcb5492679cc7521aadd42000000000000000000000000ffe27b523078303768ac6b2a9ebee8a22902ffaf0000000000000000000000003de61a89290009b34000361cf94d9b7a218cf5eb0000000000000000000000001c74d52ca9d58f629e9b5bdfee0fa82116db047a000000000000000000000000d3438e11d5de4518dcef9a3c455fcb75dcc600cf00000000000000000000000067e0887a3614da0dc94b6b36bc787d7c528ec8c200000000000000000000000000e7b744f07fd1dc016ba84626c2c31edb15b9b70000000000000000000000005f1d2141682745ec493876e13903562cac71b79200000000000000000000000010f77e56bdccade0b4542145e5c408f1f8bf5afb00000000000000000000000000db61875511c11e07ebe53edf787717410fc9160000000000000000000000005f055dcafbc494eb4d634744dd96b0813a718f99000000000000000000000000369342e4617cd365d7ffacbea47ed1a143e48bea0000000000000000000000007139ceeef20464fe9bd2ba713c8a68240f01711d000000000000000000000000704e0de2534102e3102f358e6c78568d13053aaa000000000000000000000000ca568c15453844f78a5bed1c7d74e5c81cca557d000000000000000000000000f6d4d4ddbf3fc684d531b40c3c518d3825f2769d00000000000000000000000045d5eab238d23e668a949ecde1e77163c427533900000000000000000000000033a96b5993f65e26ad4f51b3d3ccea513271b923000000000000000000000000cc6c95e8bc9fe7b9ddccded787276b70728bd91d00000000000000000000000000b88dc7e00c5ad794595f208566bcc15d07f0270000000000000000000000009dc8a0886242b0fd686d8f2a9ed46516090b6fd300000000000000000000000000f26ece6c8716bdded31924b446c92ff388aee200000000000000000000000041fc0c45412422221ee6769f182ca9a344359e3f000000000000000000000000f482bea9f562184be993e9b1ac3d75eff57781ca0000000000000000000000000868411ca03e6655d7ee957089dc983d74b9bf1a0000000000000000000000009f4cb6c14055163e9975ff18e4230c2833f02726000000000000000000000000da6b22f0a07241448bea9dccd02b3b187e343664000000000000000000000000c4e3aac985c8182e3dac6c9b19eb606151fcd7670000000000000000000000003dd361b92ef882c885e3e4a7d634c2d9daedef85000000000000000000000000e4cba77472f36a5ee693b44c84989a1fa576992a00000000000000000000000000b6e47551b16d1919a74e2a6512fde7675e15da000000000000000000000000252fac5e0f04d62aef0556084c2c6e64feef271e000000000000000000000000d1c5e193feb49a59c6bd54b8aa28f22762f89d5500000000000000000000000039990ea12fd788062f16ce81b769bbf0ef9c2c8e000000000000000000000000d4e86be2d4ad7e987ab67ad679ceaeec269573b600000000000000000000000089a12ac6de30463278eb4a0eeebf2da16ea9637d00000000000000000000000000bab0d7068f8b2d753590949879e17faf3f60880000000000000000000000001edef22dccded943a0ddb453647723378c33410a00000000000000000000000055a1cae7f45240680c83dbb7329046f894a7160300000000000000000000000000a888a4cac1a5a82029bff090aaddb98407303a0000000000000000000000002fdefc1c8f299e378473999707aa5ea7c8639af3000000000000000000000000bd9064fdb9a4274df760f8fc14abaf6b86d17f120000000000000000000000004aa7269e78942f8b159db827fdac811587abcf51000000000000000000000000de7799b2d6999ad6a752aa0af8b95fe41e7259150000000000000000000000003115aa1401d5aba3220030d3db298ce8880a46b50000000000000000000000000823c99debd091fe1a736bd3888b1707ed820aec0000000000000000000000002539b51ebde65a75672abcfe9439a706a99d18d100000000000000000000000085c24edf1b51115cdf654c15fd29e1b32752e56700000000000000000000000004a782948d6cea64d5f14d46c18fb33470644fd2000000000000000000000000f476e1267f86247cc908816f2e7ad5388c952db0000000000000000000000000aab54b1b17fd41fbac81758e387bc8eca128ca880000000000000000000000000b6121ddce71373b3c02780b22cc78dd20d3a7f900000000000000000000000059191198028f1e14d3ae814ebdae084f93a1746f000000000000000000000000229a55f621801934acb219478d556c7f128acde60000000000000000000000009608a19685b95c49b86c859bebaf3d1f0e8ffa1a000000000000000000000000c230ce5643a10702111572c938919c9f448c46d80000000000000000000000003744c132637b13f7f410e0580a1fa2393875e4440000000000000000000000008c3720060f8cfdf8b8d4da5698f4f51a48a0828a0000000000000000000000002561a6f4f32908f2bef562987da896701ec943ae00000000000000000000000005939d370ce1a4f7d36b2b1c3c09d84ec4f7e9eb0000000000000000000000000593f77e9d19d4c322e18a24b89dfbfa311ea545000000000000000000000000dcc097955815c69b223865a050800dc44ecaf8ae", contractAddress: "", cumulativeGasUsed: "2395286", gasUsed: "2079717", confirmations: "3435357"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141]]}, {type: "uint256", name: "_tier", value: "1"}, {type: "bool", name: "_status", value: true}], name: "whitelistAddresses", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistAddresses(address[],uint256,bool)" ]( [addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141]], "1", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1505312331 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistAddresses( [addressList[142],addressList[143],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4269780", timeStamp: "1505312673", hash: "0xdd4600415a27bea219ff513ee2a55e91b83f07cf58f5e65ee7735b7ca2455b2d", nonce: "37", blockHash: "0x4b1d041d231f8850c14ba5c5a7344ea69cc70192be2719ecd7abe5e4370950f3", transactionIndex: "26", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "5619717", gasPrice: "22463230501", isError: "1", txreceipt_status: "", input: "0x763730bd0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000092000000000000000000000000ffdd5bfe33c8fa18af76b944e725b3a116467c640000000000000000000000004995c29a93226c5858711f81e3b75eb2aa0a5a4e0000000000000000000000003c401c200233c07dd9bfdac99edbc01068afe118000000000000000000000000ffc5b23d80b85c2a7a7da49064d7354d09e5e3cf0000000000000000000000009a73c36d924c197c6418a24ea986e5d3f7c1ddf300000000000000000000000000bb85eb9f8e166acef360942ac4e43dda235f0300000000000000000000000000165307057322a93adbe68050159af11966778d000000000000000000000000b45d904431f0fc93f14ed273d7e8acb71339207f0000000000000000000000000681516881536a06497017971c7c86128fab573800000000000000000000000034cc2861eeb213da8bf366becdfb319f16aff12c00000000000000000000000060ba6c590883ab3c06289eff076f96b80065e3f5000000000000000000000000e835ec939021aa1189d4ddf3ae1544b62f9579ab0000000000000000000000009a94771e7e73f9d8d6e880cfb12cab4e9573c45e0000000000000000000000006d805c47cd158bee253986cfbfcfce34fdb33efe000000000000000000000000baa68aa7b1257305ab9d968e51786897e0e423b70000000000000000000000006d0bb4ce7acc1ba71af6d1858dea64c6073dc27e00000000000000000000000007bd15dcb7f83045d3583ae385b4b549951a33c2000000000000000000000000145663520246b70e32c96411b33f8dc71d4100dd000000000000000000000000bccb13f64b2708f400304cbd10044c589c116925000000000000000000000000e414feaddd562b0071810d1b1b4d8bb85171632d0000000000000000000000005f9d89858fee7de8f28e21e62650bf1322c714f10000000000000000000000007c0fba9557b8f909ab8d69d8da1944501b6a9d07000000000000000000000000b1ccab138e6c6a704f9bf607a71c342cfc9480530000000000000000000000000e0193a44c0d7e36b8faff8fd3d9004d5bb5ff0900000000000000000000000000c2e468cd0f9576c6540f425baf64969205b40c00000000000000000000000082e4d78c6c62d461251fa5a1d4deb9f0fe378e300000000000000000000000001bbcc79b91bee48b60da56329b7f0c5d797d56ed000000000000000000000000007d2f4fe301922c560d1a752836c4e99e0ed63c000000000000000000000000e9ebee76a902b6536c0bddf79ac4c4343e5bdbfb000000000000000000000000ec000c5461cdbc4497d61245176260671db70d88000000000000000000000000a20ad2f8ad42831e9dc82c05715bcaaec84f9abb000000000000000000000000ff52c5c250d63e6903aa7b7bd4c256bf4743260200000000000000000000000000582f083582f59a0da86a0688332c77c7044a3a00000000000000000000000002c68e3de38b00f958a53bd9182d09120312b2a20000000000000000000000000e6ead010b7249b46c56972a309d1376e53d9d5000000000000000000000000034a0cd27e8489ad7346a9a40e2205cf6b715b3640000000000000000000000007fc796922627eed6faf6c26e01a32c33b5fc91310000000000000000000000007f8e672a3079d3976ebc2b3cb5179dbd7986352900000000000000000000000070e8818a14d8841604497990bbd181170661a85e0000000000000000000000005df3bba2cb0b3aa00fa940c14e2cc57f2cba303a0000000000000000000000007c1b4e9d3df68577655f67057a5076c9cdd8a7ed000000000000000000000000f190f0193b694d9d2bb865a66f0c17cbd8280c71000000000000000000000000a07b4b955c69afbdb1e7c2eadf28e50bcc3f4c93000000000000000000000000e909e1c946c057d06b79cc72ebcb5b168c6e6d4900000000000000000000000076927e2ccab0084bd19cee74f78b63134b9d181e000000000000000000000000be0b69edc6e0aaae42b9964af162f8a4a2ffe5950000000000000000000000006cb9e3274799ca43ec2582335867b9f7520d9f2600000000000000000000000022c8d09305d827f1cdf696d1b9ee309227938f950000000000000000000000005c72da9cad883d790eb1e4165cf2441b3be165e2000000000000000000000000cb3bb2e2cbfa6dc19c2ba39d7f9aaa022f0bdc8f000000000000000000000000ba881a7b7f829d5c25bd120b3e80c640cd8ae0d6000000000000000000000000b46ac18f8fc29c552450e1ba67272e8dfc828fd10000000000000000000000006e9ec23df252c5ded1e83b2a19fc5d79759acf0300000000000000000000000028091e33df862922f1a1fc62e60af9f791cb4dec000000000000000000000000e60c6d66c42b97300f116f34e2b971d8a627d557000000000000000000000000662a80dd9b873913cfdeef75f771159a6782f3d8000000000000000000000000848c98731d0122e32217dcafe0ee67842f3533e600000000000000000000000076cd7f9cb7030803fff92875c49df9aa8c558344000000000000000000000000d48505ee38c6e933defa82e068d063b300781df8000000000000000000000000004ba25b9b23ac7b4dd583c7e6a8e811dd32e60800000000000000000000000043215241c3def445e151a881db883a66c2df9bbe0000000000000000000000008c0114f7507485c2289cb4fc7fadb61d4e2f49b30000000000000000000000002a980afd3cf9ba8bbb15ea10fe952d96641f034600000000000000000000000076c265bdaa4350ed138735b7a514adb1a89b71e20000000000000000000000000a69945a4f4cd87b925a34fc9c641efc1da664d6000000000000000000000000eaa25ac8a4cc52451917238638453737af6e4a31000000000000000000000000717a58ed0ec76d4cfe0b64c0e112ce015653edb200000000000000000000000028472e097c91d75f6aa557c0223e50960078a6d00000000000000000000000009d50ca863d28c946a05560e9bd993ba4c2d1f95400000000000000000000000028b54d4534052214f134a995663af9c6bdaea4350000000000000000000000008215d8fde5eaf58901d01a438f7188016369b91f000000000000000000000000f5b9f5c093b63a609711fb56f6b8484013ffa0280000000000000000000000001c2e28d5e50dedd1dc8936d681b32d2458533d740000000000000000000000006c27ea4b5d281e81e5a833a5e6e1c5a74f9b47be000000000000000000000000d78fd123d2bc2da7bb5621c753dc665d3c0e85ac000000000000000000000000049503a94f506b601661d8bc792a2cc59ea230d90000000000000000000000000c6ead592dd190072e898e807f2fc68e98bcd8be000000000000000000000000047eb968d0dce70280352d0834ab9f6b536da16f0000000000000000000000008f212180bf6b8178559a67268502057fb0043dd90000000000000000000000009faaa0efbe61bc445e1068ab1cd67f23b45d624f000000000000000000000000c6cc76eb55c49a839444800b66a66cbddf76e3e0000000000000000000000000a39166df6f039ba348d7cfa353280d19dde04cd8000000000000000000000000b0323032e7cc95e17555e9fb37b33095eee235f000000000000000000000000078d8e8807f652b54afe33b7645a26c5ffae5291c0000000000000000000000003dd932d51fb898374e694d764d059d2e2453e4d1000000000000000000000000e7dc484e59f6b7ed74bc72a1129144f9ea4bf89a0000000000000000000000007ebe9268b8f7ff0b098a8567bf7490d33123da4d000000000000000000000000f3cdf271ccaafb591372f81521bd2019701def1b00000000000000000000000037e102aab262f27e73a9733c7678d0d58ed7a5ab000000000000000000000000e055aff35a3f212e713922e296d295fb50d6edb90000000000000000000000006317dac8332f0b3ef49146b45a6726cdb78c4dcf000000000000000000000000ef243aa4f940e72eb1d7ebab724672d88b4f18ed00000000000000000000000080259bc4e86f3fa837491838562e418a56a3359f0000000000000000000000002bae4bf3595b96b2f07492b7d1622e3703e604f80000000000000000000000000028673fc0a9532a5c0af61ebb8369a4e5219ec00000000000000000000000000b77e9fd0166dd1a59fad0d1393bfc41d2bc6f26000000000000000000000000e0da8ed5b7b775b5fdf285131646fe2f54ef0005000000000000000000000000f70145fe48ab5606890a98d19949edd2516ea2400000000000000000000000009466c086239a0fd38932608572cebb97d1d42ee5000000000000000000000000f769dbd6d5c2cf4db888f59c5768901411160e88000000000000000000000000a35b60fe8eb8184a379a0d0b726f3ceb57ee907300000000000000000000000027dadeb9e5e35881402d54286af63cc63505163a0000000000000000000000009dac72188aeb760b60bef84b85cfa5bb2dfd9b69000000000000000000000000e9080374375a1f92e2edf6f314ea2ec1800979fe000000000000000000000000003bb89e2cd29acd745b11dc9d13a38bcce6c24200000000000000000000000074c072d1bd63e0b922d0befd79b3ee1fcc3a8336000000000000000000000000cef0e56b84ad7d5be9edcb7faf66f85ae83942a4000000000000000000000000a6d0c47df7af1ecdd555d08c44ca4f7186e6e982000000000000000000000000005fe92d7a91a045ff6cfe888b0b982cd3f2a06b000000000000000000000000678fb21b9736e6c7da9f7d37a77ab766bb2519c70000000000000000000000002e15d7aa0650de1009710fdd45c3468d75ae1392000000000000000000000000fd516ec936908f1f409cd48c05fbbfabacdfa52000000000000000000000000094d9cd17d85d2afa8d71283d94386281f16612bd00000000000000000000000007ca04dea1b05ef526f69f82661aa2bc911c7ab2000000000000000000000000ebeabcb3dd92973f863ce54bce5e1e4322777210000000000000000000000000b38ecc6ec2fcaecfc8987f25ae58622a91a230340000000000000000000000002565f8e0b33f2d3bb1c0e2dd5fbb972df48654c8000000000000000000000000428512bd5e9f8e486972c89b423eed37d304d786000000000000000000000000b92f2e00983faa34b4afac034aa85569df78039f00000000000000000000000023b991f7be7afc8706dcef2f04288b44b455feb700000000000000000000000096f57b3b2aee2f15198cc2862d17eb32591c0208000000000000000000000000abd4277717fd22b4e91232578c34478546dc381f000000000000000000000000edb34a82f00c71c2082171e4365ea85d422620af00000000000000000000000067a01ab58cc873bfbd93c89f2b0897e85007b772000000000000000000000000cf093b6dfce969e640dbd38d7302ce2e7ca531df00000000000000000000000054620853f4f0799bee70832b767fcb6ed5b48eba0000000000000000000000007a836b45c06e57c65451c41168a7f269146b1b0d0000000000000000000000002d50a018e1c5194334d8ce52d7152d2ac99f7b370000000000000000000000000d8571cf484de9f090edb7e51882d60402212d83000000000000000000000000d1f982eca739bd2165ea085c379231646302eae30000000000000000000000000451b45ca19945c38adc39bc91f45b3d518aa8e3000000000000000000000000002b254abdcef1f9af4e56f0e9776bc1feea1edc00000000000000000000000040692724326503b8fdc8472df7ee658f4bdbfc890000000000000000000000006c66ebb344c3251fbd49cf00b93ebb562f3637c600000000000000000000000027570157d3b72560143af4d8a4528117e22155750000000000000000000000007837d0bfec3abd92a1720f21c77aef0b71d0f58e00000000000000000000000061779ad9d36ba354e235c59fb48651ace92f9fae000000000000000000000000c08d21eb6000357b3d70fbedaf6a1ce5c94d6286000000000000000000000000a7e51da6df5079e42048f43ffb355952cbfd504d000000000000000000000000d93e1bd6d0716ecdeff07f59d31fdf3679250f3a0000000000000000000000006065043d769e88421e2592472a2394d4b5ca1b44000000000000000000000000efe628e9239bf3dc14766aa465064e1784edc05200000000000000000000000050f5ff6683b508f356f97beee5728a38abe3b51e0000000000000000000000009c232158b5e0f9a23bf9a399cd9197c7f131d13b000000000000000000000000c2e82b98ebb92cf36faa85fba798f838a86843d40000000000000000000000008e6ceca77bd9ae8a2c7f9d11870ec80ba6ab751c", contractAddress: "", cumulativeGasUsed: "6442145", gasUsed: "5619717", confirmations: "3435342"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210],addressList[211],addressList[212],addressList[213],addressList[214],addressList[215],addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[221],addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229],addressList[230],addressList[231],addressList[232],addressList[233],addressList[234],addressList[235],addressList[236],addressList[237],addressList[238],addressList[239],addressList[240],addressList[241],addressList[242],addressList[243],addressList[244],addressList[245],addressList[246],addressList[247],addressList[248],addressList[249],addressList[250],addressList[251],addressList[252],addressList[253],addressList[254],addressList[255],addressList[256],addressList[257],addressList[258],addressList[259],addressList[260],addressList[261],addressList[262],addressList[263],addressList[264],addressList[265],addressList[266],addressList[267],addressList[268],addressList[269],addressList[270],addressList[271],addressList[272],addressList[273],addressList[274],addressList[275],addressList[276],addressList[277],addressList[278],addressList[279],addressList[280],addressList[281],addressList[282],addressList[283],addressList[284],addressList[285],addressList[286],addressList[287]]}, {type: "uint256", name: "_tier", value: "1"}, {type: "bool", name: "_status", value: true}], name: "whitelistAddresses", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistAddresses( [addressList[142],addressList[143],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4269795", timeStamp: "1505313192", hash: "0x5fe9f1b8136d036c3e4a6f66b6226f5c57e0cf92568430115fabd9452ffffb52", nonce: "38", blockHash: "0x54f30811537466ed584eec55d8474de8bf22c0562c6bcd2670ac2723b95fa3d0", transactionIndex: "4", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "6500000", gasPrice: "22463230501", isError: "1", txreceipt_status: "", input: "0x763730bd0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000092000000000000000000000000ffdd5bfe33c8fa18af76b944e725b3a116467c640000000000000000000000004995c29a93226c5858711f81e3b75eb2aa0a5a4e0000000000000000000000003c401c200233c07dd9bfdac99edbc01068afe118000000000000000000000000ffc5b23d80b85c2a7a7da49064d7354d09e5e3cf0000000000000000000000009a73c36d924c197c6418a24ea986e5d3f7c1ddf300000000000000000000000000bb85eb9f8e166acef360942ac4e43dda235f0300000000000000000000000000165307057322a93adbe68050159af11966778d000000000000000000000000b45d904431f0fc93f14ed273d7e8acb71339207f0000000000000000000000000681516881536a06497017971c7c86128fab573800000000000000000000000034cc2861eeb213da8bf366becdfb319f16aff12c00000000000000000000000060ba6c590883ab3c06289eff076f96b80065e3f5000000000000000000000000e835ec939021aa1189d4ddf3ae1544b62f9579ab0000000000000000000000009a94771e7e73f9d8d6e880cfb12cab4e9573c45e0000000000000000000000006d805c47cd158bee253986cfbfcfce34fdb33efe000000000000000000000000baa68aa7b1257305ab9d968e51786897e0e423b70000000000000000000000006d0bb4ce7acc1ba71af6d1858dea64c6073dc27e00000000000000000000000007bd15dcb7f83045d3583ae385b4b549951a33c2000000000000000000000000145663520246b70e32c96411b33f8dc71d4100dd000000000000000000000000bccb13f64b2708f400304cbd10044c589c116925000000000000000000000000e414feaddd562b0071810d1b1b4d8bb85171632d0000000000000000000000005f9d89858fee7de8f28e21e62650bf1322c714f10000000000000000000000007c0fba9557b8f909ab8d69d8da1944501b6a9d07000000000000000000000000b1ccab138e6c6a704f9bf607a71c342cfc9480530000000000000000000000000e0193a44c0d7e36b8faff8fd3d9004d5bb5ff0900000000000000000000000000c2e468cd0f9576c6540f425baf64969205b40c00000000000000000000000082e4d78c6c62d461251fa5a1d4deb9f0fe378e300000000000000000000000001bbcc79b91bee48b60da56329b7f0c5d797d56ed000000000000000000000000007d2f4fe301922c560d1a752836c4e99e0ed63c000000000000000000000000e9ebee76a902b6536c0bddf79ac4c4343e5bdbfb000000000000000000000000ec000c5461cdbc4497d61245176260671db70d88000000000000000000000000a20ad2f8ad42831e9dc82c05715bcaaec84f9abb000000000000000000000000ff52c5c250d63e6903aa7b7bd4c256bf4743260200000000000000000000000000582f083582f59a0da86a0688332c77c7044a3a00000000000000000000000002c68e3de38b00f958a53bd9182d09120312b2a20000000000000000000000000e6ead010b7249b46c56972a309d1376e53d9d5000000000000000000000000034a0cd27e8489ad7346a9a40e2205cf6b715b3640000000000000000000000007fc796922627eed6faf6c26e01a32c33b5fc91310000000000000000000000007f8e672a3079d3976ebc2b3cb5179dbd7986352900000000000000000000000070e8818a14d8841604497990bbd181170661a85e0000000000000000000000005df3bba2cb0b3aa00fa940c14e2cc57f2cba303a0000000000000000000000007c1b4e9d3df68577655f67057a5076c9cdd8a7ed000000000000000000000000f190f0193b694d9d2bb865a66f0c17cbd8280c71000000000000000000000000a07b4b955c69afbdb1e7c2eadf28e50bcc3f4c93000000000000000000000000e909e1c946c057d06b79cc72ebcb5b168c6e6d4900000000000000000000000076927e2ccab0084bd19cee74f78b63134b9d181e000000000000000000000000be0b69edc6e0aaae42b9964af162f8a4a2ffe5950000000000000000000000006cb9e3274799ca43ec2582335867b9f7520d9f2600000000000000000000000022c8d09305d827f1cdf696d1b9ee309227938f950000000000000000000000005c72da9cad883d790eb1e4165cf2441b3be165e2000000000000000000000000cb3bb2e2cbfa6dc19c2ba39d7f9aaa022f0bdc8f000000000000000000000000ba881a7b7f829d5c25bd120b3e80c640cd8ae0d6000000000000000000000000b46ac18f8fc29c552450e1ba67272e8dfc828fd10000000000000000000000006e9ec23df252c5ded1e83b2a19fc5d79759acf0300000000000000000000000028091e33df862922f1a1fc62e60af9f791cb4dec000000000000000000000000e60c6d66c42b97300f116f34e2b971d8a627d557000000000000000000000000662a80dd9b873913cfdeef75f771159a6782f3d8000000000000000000000000848c98731d0122e32217dcafe0ee67842f3533e600000000000000000000000076cd7f9cb7030803fff92875c49df9aa8c558344000000000000000000000000d48505ee38c6e933defa82e068d063b300781df8000000000000000000000000004ba25b9b23ac7b4dd583c7e6a8e811dd32e60800000000000000000000000043215241c3def445e151a881db883a66c2df9bbe0000000000000000000000008c0114f7507485c2289cb4fc7fadb61d4e2f49b30000000000000000000000002a980afd3cf9ba8bbb15ea10fe952d96641f034600000000000000000000000076c265bdaa4350ed138735b7a514adb1a89b71e20000000000000000000000000a69945a4f4cd87b925a34fc9c641efc1da664d6000000000000000000000000eaa25ac8a4cc52451917238638453737af6e4a31000000000000000000000000717a58ed0ec76d4cfe0b64c0e112ce015653edb200000000000000000000000028472e097c91d75f6aa557c0223e50960078a6d00000000000000000000000009d50ca863d28c946a05560e9bd993ba4c2d1f95400000000000000000000000028b54d4534052214f134a995663af9c6bdaea4350000000000000000000000008215d8fde5eaf58901d01a438f7188016369b91f000000000000000000000000f5b9f5c093b63a609711fb56f6b8484013ffa0280000000000000000000000001c2e28d5e50dedd1dc8936d681b32d2458533d740000000000000000000000006c27ea4b5d281e81e5a833a5e6e1c5a74f9b47be000000000000000000000000d78fd123d2bc2da7bb5621c753dc665d3c0e85ac000000000000000000000000049503a94f506b601661d8bc792a2cc59ea230d90000000000000000000000000c6ead592dd190072e898e807f2fc68e98bcd8be000000000000000000000000047eb968d0dce70280352d0834ab9f6b536da16f0000000000000000000000008f212180bf6b8178559a67268502057fb0043dd90000000000000000000000009faaa0efbe61bc445e1068ab1cd67f23b45d624f000000000000000000000000c6cc76eb55c49a839444800b66a66cbddf76e3e0000000000000000000000000a39166df6f039ba348d7cfa353280d19dde04cd8000000000000000000000000b0323032e7cc95e17555e9fb37b33095eee235f000000000000000000000000078d8e8807f652b54afe33b7645a26c5ffae5291c0000000000000000000000003dd932d51fb898374e694d764d059d2e2453e4d1000000000000000000000000e7dc484e59f6b7ed74bc72a1129144f9ea4bf89a0000000000000000000000007ebe9268b8f7ff0b098a8567bf7490d33123da4d000000000000000000000000f3cdf271ccaafb591372f81521bd2019701def1b00000000000000000000000037e102aab262f27e73a9733c7678d0d58ed7a5ab000000000000000000000000e055aff35a3f212e713922e296d295fb50d6edb90000000000000000000000006317dac8332f0b3ef49146b45a6726cdb78c4dcf000000000000000000000000ef243aa4f940e72eb1d7ebab724672d88b4f18ed00000000000000000000000080259bc4e86f3fa837491838562e418a56a3359f0000000000000000000000002bae4bf3595b96b2f07492b7d1622e3703e604f80000000000000000000000000028673fc0a9532a5c0af61ebb8369a4e5219ec00000000000000000000000000b77e9fd0166dd1a59fad0d1393bfc41d2bc6f26000000000000000000000000e0da8ed5b7b775b5fdf285131646fe2f54ef0005000000000000000000000000f70145fe48ab5606890a98d19949edd2516ea2400000000000000000000000009466c086239a0fd38932608572cebb97d1d42ee5000000000000000000000000f769dbd6d5c2cf4db888f59c5768901411160e88000000000000000000000000a35b60fe8eb8184a379a0d0b726f3ceb57ee907300000000000000000000000027dadeb9e5e35881402d54286af63cc63505163a0000000000000000000000009dac72188aeb760b60bef84b85cfa5bb2dfd9b69000000000000000000000000e9080374375a1f92e2edf6f314ea2ec1800979fe000000000000000000000000003bb89e2cd29acd745b11dc9d13a38bcce6c24200000000000000000000000074c072d1bd63e0b922d0befd79b3ee1fcc3a8336000000000000000000000000cef0e56b84ad7d5be9edcb7faf66f85ae83942a4000000000000000000000000a6d0c47df7af1ecdd555d08c44ca4f7186e6e982000000000000000000000000005fe92d7a91a045ff6cfe888b0b982cd3f2a06b000000000000000000000000678fb21b9736e6c7da9f7d37a77ab766bb2519c70000000000000000000000002e15d7aa0650de1009710fdd45c3468d75ae1392000000000000000000000000fd516ec936908f1f409cd48c05fbbfabacdfa52000000000000000000000000094d9cd17d85d2afa8d71283d94386281f16612bd00000000000000000000000007ca04dea1b05ef526f69f82661aa2bc911c7ab2000000000000000000000000ebeabcb3dd92973f863ce54bce5e1e4322777210000000000000000000000000b38ecc6ec2fcaecfc8987f25ae58622a91a230340000000000000000000000002565f8e0b33f2d3bb1c0e2dd5fbb972df48654c8000000000000000000000000428512bd5e9f8e486972c89b423eed37d304d786000000000000000000000000b92f2e00983faa34b4afac034aa85569df78039f00000000000000000000000023b991f7be7afc8706dcef2f04288b44b455feb700000000000000000000000096f57b3b2aee2f15198cc2862d17eb32591c0208000000000000000000000000abd4277717fd22b4e91232578c34478546dc381f000000000000000000000000edb34a82f00c71c2082171e4365ea85d422620af00000000000000000000000067a01ab58cc873bfbd93c89f2b0897e85007b772000000000000000000000000cf093b6dfce969e640dbd38d7302ce2e7ca531df00000000000000000000000054620853f4f0799bee70832b767fcb6ed5b48eba0000000000000000000000007a836b45c06e57c65451c41168a7f269146b1b0d0000000000000000000000002d50a018e1c5194334d8ce52d7152d2ac99f7b370000000000000000000000000d8571cf484de9f090edb7e51882d60402212d83000000000000000000000000d1f982eca739bd2165ea085c379231646302eae30000000000000000000000000451b45ca19945c38adc39bc91f45b3d518aa8e3000000000000000000000000002b254abdcef1f9af4e56f0e9776bc1feea1edc00000000000000000000000040692724326503b8fdc8472df7ee658f4bdbfc890000000000000000000000006c66ebb344c3251fbd49cf00b93ebb562f3637c600000000000000000000000027570157d3b72560143af4d8a4528117e22155750000000000000000000000007837d0bfec3abd92a1720f21c77aef0b71d0f58e00000000000000000000000061779ad9d36ba354e235c59fb48651ace92f9fae000000000000000000000000c08d21eb6000357b3d70fbedaf6a1ce5c94d6286000000000000000000000000a7e51da6df5079e42048f43ffb355952cbfd504d000000000000000000000000d93e1bd6d0716ecdeff07f59d31fdf3679250f3a0000000000000000000000006065043d769e88421e2592472a2394d4b5ca1b44000000000000000000000000efe628e9239bf3dc14766aa465064e1784edc05200000000000000000000000050f5ff6683b508f356f97beee5728a38abe3b51e0000000000000000000000009c232158b5e0f9a23bf9a399cd9197c7f131d13b000000000000000000000000c2e82b98ebb92cf36faa85fba798f838a86843d40000000000000000000000008e6ceca77bd9ae8a2c7f9d11870ec80ba6ab751c", contractAddress: "", cumulativeGasUsed: "6681410", gasUsed: "6500000", confirmations: "3435327"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210],addressList[211],addressList[212],addressList[213],addressList[214],addressList[215],addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[221],addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229],addressList[230],addressList[231],addressList[232],addressList[233],addressList[234],addressList[235],addressList[236],addressList[237],addressList[238],addressList[239],addressList[240],addressList[241],addressList[242],addressList[243],addressList[244],addressList[245],addressList[246],addressList[247],addressList[248],addressList[249],addressList[250],addressList[251],addressList[252],addressList[253],addressList[254],addressList[255],addressList[256],addressList[257],addressList[258],addressList[259],addressList[260],addressList[261],addressList[262],addressList[263],addressList[264],addressList[265],addressList[266],addressList[267],addressList[268],addressList[269],addressList[270],addressList[271],addressList[272],addressList[273],addressList[274],addressList[275],addressList[276],addressList[277],addressList[278],addressList[279],addressList[280],addressList[281],addressList[282],addressList[283],addressList[284],addressList[285],addressList[286],addressList[287]]}, {type: "uint256", name: "_tier", value: "1"}, {type: "bool", name: "_status", value: true}], name: "whitelistAddresses", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistAddresses( [addressList[142],addressList[143],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4269819", timeStamp: "1505313837", hash: "0x34ed1743cff41ff9ae9ed6ad5d8565dde275ccac898668470d7694bbd1ff289f", nonce: "39", blockHash: "0x637067477dabc039decbb3d9c7d960876ee81a0b06d7b8b52dc5e161f4cd4453", transactionIndex: "5", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "6500000", gasPrice: "22463230501", isError: "0", txreceipt_status: "", input: "0x763730bd0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000044000000000000000000000000ffdd5bfe33c8fa18af76b944e725b3a116467c640000000000000000000000004995c29a93226c5858711f81e3b75eb2aa0a5a4e0000000000000000000000003c401c200233c07dd9bfdac99edbc01068afe118000000000000000000000000ffc5b23d80b85c2a7a7da49064d7354d09e5e3cf0000000000000000000000009a73c36d924c197c6418a24ea986e5d3f7c1ddf300000000000000000000000000bb85eb9f8e166acef360942ac4e43dda235f0300000000000000000000000000165307057322a93adbe68050159af11966778d000000000000000000000000b45d904431f0fc93f14ed273d7e8acb71339207f0000000000000000000000000681516881536a06497017971c7c86128fab573800000000000000000000000034cc2861eeb213da8bf366becdfb319f16aff12c00000000000000000000000060ba6c590883ab3c06289eff076f96b80065e3f5000000000000000000000000e835ec939021aa1189d4ddf3ae1544b62f9579ab0000000000000000000000009a94771e7e73f9d8d6e880cfb12cab4e9573c45e0000000000000000000000006d805c47cd158bee253986cfbfcfce34fdb33efe000000000000000000000000baa68aa7b1257305ab9d968e51786897e0e423b70000000000000000000000006d0bb4ce7acc1ba71af6d1858dea64c6073dc27e00000000000000000000000007bd15dcb7f83045d3583ae385b4b549951a33c2000000000000000000000000145663520246b70e32c96411b33f8dc71d4100dd000000000000000000000000bccb13f64b2708f400304cbd10044c589c116925000000000000000000000000e414feaddd562b0071810d1b1b4d8bb85171632d0000000000000000000000005f9d89858fee7de8f28e21e62650bf1322c714f10000000000000000000000007c0fba9557b8f909ab8d69d8da1944501b6a9d07000000000000000000000000b1ccab138e6c6a704f9bf607a71c342cfc9480530000000000000000000000000e0193a44c0d7e36b8faff8fd3d9004d5bb5ff0900000000000000000000000000c2e468cd0f9576c6540f425baf64969205b40c00000000000000000000000082e4d78c6c62d461251fa5a1d4deb9f0fe378e300000000000000000000000001bbcc79b91bee48b60da56329b7f0c5d797d56ed000000000000000000000000007d2f4fe301922c560d1a752836c4e99e0ed63c000000000000000000000000e9ebee76a902b6536c0bddf79ac4c4343e5bdbfb000000000000000000000000ec000c5461cdbc4497d61245176260671db70d88000000000000000000000000a20ad2f8ad42831e9dc82c05715bcaaec84f9abb000000000000000000000000ff52c5c250d63e6903aa7b7bd4c256bf4743260200000000000000000000000000582f083582f59a0da86a0688332c77c7044a3a00000000000000000000000002c68e3de38b00f958a53bd9182d09120312b2a20000000000000000000000000e6ead010b7249b46c56972a309d1376e53d9d5000000000000000000000000034a0cd27e8489ad7346a9a40e2205cf6b715b3640000000000000000000000007fc796922627eed6faf6c26e01a32c33b5fc91310000000000000000000000007f8e672a3079d3976ebc2b3cb5179dbd7986352900000000000000000000000070e8818a14d8841604497990bbd181170661a85e0000000000000000000000005df3bba2cb0b3aa00fa940c14e2cc57f2cba303a0000000000000000000000007c1b4e9d3df68577655f67057a5076c9cdd8a7ed000000000000000000000000f190f0193b694d9d2bb865a66f0c17cbd8280c71000000000000000000000000a07b4b955c69afbdb1e7c2eadf28e50bcc3f4c93000000000000000000000000e909e1c946c057d06b79cc72ebcb5b168c6e6d4900000000000000000000000076927e2ccab0084bd19cee74f78b63134b9d181e000000000000000000000000be0b69edc6e0aaae42b9964af162f8a4a2ffe5950000000000000000000000006cb9e3274799ca43ec2582335867b9f7520d9f2600000000000000000000000022c8d09305d827f1cdf696d1b9ee309227938f950000000000000000000000005c72da9cad883d790eb1e4165cf2441b3be165e2000000000000000000000000cb3bb2e2cbfa6dc19c2ba39d7f9aaa022f0bdc8f000000000000000000000000ba881a7b7f829d5c25bd120b3e80c640cd8ae0d6000000000000000000000000b46ac18f8fc29c552450e1ba67272e8dfc828fd10000000000000000000000006e9ec23df252c5ded1e83b2a19fc5d79759acf0300000000000000000000000028091e33df862922f1a1fc62e60af9f791cb4dec000000000000000000000000e60c6d66c42b97300f116f34e2b971d8a627d557000000000000000000000000662a80dd9b873913cfdeef75f771159a6782f3d8000000000000000000000000848c98731d0122e32217dcafe0ee67842f3533e600000000000000000000000076cd7f9cb7030803fff92875c49df9aa8c558344000000000000000000000000d48505ee38c6e933defa82e068d063b300781df8000000000000000000000000004ba25b9b23ac7b4dd583c7e6a8e811dd32e60800000000000000000000000043215241c3def445e151a881db883a66c2df9bbe0000000000000000000000008c0114f7507485c2289cb4fc7fadb61d4e2f49b30000000000000000000000002a980afd3cf9ba8bbb15ea10fe952d96641f034600000000000000000000000076c265bdaa4350ed138735b7a514adb1a89b71e20000000000000000000000000a69945a4f4cd87b925a34fc9c641efc1da664d6000000000000000000000000eaa25ac8a4cc52451917238638453737af6e4a31000000000000000000000000717a58ed0ec76d4cfe0b64c0e112ce015653edb200000000000000000000000028472e097c91d75f6aa557c0223e50960078a6d0", contractAddress: "", cumulativeGasUsed: "3445278", gasUsed: "3248035", confirmations: "3435303"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209]]}, {type: "uint256", name: "_tier", value: "1"}, {type: "bool", name: "_status", value: true}], name: "whitelistAddresses", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistAddresses(address[],uint256,bool)" ]( [addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209]], "1", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1505313837 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: whitelistAddresses( [addressList[210],addressList[211],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4269821", timeStamp: "1505313878", hash: "0xc462173bfc8f2d201cae758092e9bc0ea74b686eb8bc8a4cc073b29a436a3104", nonce: "40", blockHash: "0x649c69ca837753b823b0ccc6c47ceb0147a3677ae1c61591b872766f35887ed6", transactionIndex: "7", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "6500000", gasPrice: "22463230501", isError: "0", txreceipt_status: "", input: "0x763730bd000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000004e0000000000000000000000009d50ca863d28c946a05560e9bd993ba4c2d1f95400000000000000000000000028b54d4534052214f134a995663af9c6bdaea4350000000000000000000000008215d8fde5eaf58901d01a438f7188016369b91f000000000000000000000000f5b9f5c093b63a609711fb56f6b8484013ffa0280000000000000000000000001c2e28d5e50dedd1dc8936d681b32d2458533d740000000000000000000000006c27ea4b5d281e81e5a833a5e6e1c5a74f9b47be000000000000000000000000d78fd123d2bc2da7bb5621c753dc665d3c0e85ac000000000000000000000000049503a94f506b601661d8bc792a2cc59ea230d90000000000000000000000000c6ead592dd190072e898e807f2fc68e98bcd8be000000000000000000000000047eb968d0dce70280352d0834ab9f6b536da16f0000000000000000000000008f212180bf6b8178559a67268502057fb0043dd90000000000000000000000009faaa0efbe61bc445e1068ab1cd67f23b45d624f000000000000000000000000c6cc76eb55c49a839444800b66a66cbddf76e3e0000000000000000000000000a39166df6f039ba348d7cfa353280d19dde04cd8000000000000000000000000b0323032e7cc95e17555e9fb37b33095eee235f000000000000000000000000078d8e8807f652b54afe33b7645a26c5ffae5291c0000000000000000000000003dd932d51fb898374e694d764d059d2e2453e4d1000000000000000000000000e7dc484e59f6b7ed74bc72a1129144f9ea4bf89a0000000000000000000000007ebe9268b8f7ff0b098a8567bf7490d33123da4d000000000000000000000000f3cdf271ccaafb591372f81521bd2019701def1b00000000000000000000000037e102aab262f27e73a9733c7678d0d58ed7a5ab000000000000000000000000e055aff35a3f212e713922e296d295fb50d6edb90000000000000000000000006317dac8332f0b3ef49146b45a6726cdb78c4dcf000000000000000000000000ef243aa4f940e72eb1d7ebab724672d88b4f18ed00000000000000000000000080259bc4e86f3fa837491838562e418a56a3359f0000000000000000000000002bae4bf3595b96b2f07492b7d1622e3703e604f80000000000000000000000000028673fc0a9532a5c0af61ebb8369a4e5219ec00000000000000000000000000b77e9fd0166dd1a59fad0d1393bfc41d2bc6f26000000000000000000000000e0da8ed5b7b775b5fdf285131646fe2f54ef0005000000000000000000000000f70145fe48ab5606890a98d19949edd2516ea2400000000000000000000000009466c086239a0fd38932608572cebb97d1d42ee5000000000000000000000000f769dbd6d5c2cf4db888f59c5768901411160e88000000000000000000000000a35b60fe8eb8184a379a0d0b726f3ceb57ee907300000000000000000000000027dadeb9e5e35881402d54286af63cc63505163a0000000000000000000000009dac72188aeb760b60bef84b85cfa5bb2dfd9b69000000000000000000000000e9080374375a1f92e2edf6f314ea2ec1800979fe000000000000000000000000003bb89e2cd29acd745b11dc9d13a38bcce6c24200000000000000000000000074c072d1bd63e0b922d0befd79b3ee1fcc3a8336000000000000000000000000cef0e56b84ad7d5be9edcb7faf66f85ae83942a4000000000000000000000000a6d0c47df7af1ecdd555d08c44ca4f7186e6e982000000000000000000000000005fe92d7a91a045ff6cfe888b0b982cd3f2a06b000000000000000000000000678fb21b9736e6c7da9f7d37a77ab766bb2519c70000000000000000000000002e15d7aa0650de1009710fdd45c3468d75ae1392000000000000000000000000fd516ec936908f1f409cd48c05fbbfabacdfa52000000000000000000000000094d9cd17d85d2afa8d71283d94386281f16612bd00000000000000000000000007ca04dea1b05ef526f69f82661aa2bc911c7ab2000000000000000000000000ebeabcb3dd92973f863ce54bce5e1e4322777210000000000000000000000000b38ecc6ec2fcaecfc8987f25ae58622a91a230340000000000000000000000002565f8e0b33f2d3bb1c0e2dd5fbb972df48654c8000000000000000000000000428512bd5e9f8e486972c89b423eed37d304d786000000000000000000000000b92f2e00983faa34b4afac034aa85569df78039f00000000000000000000000023b991f7be7afc8706dcef2f04288b44b455feb700000000000000000000000096f57b3b2aee2f15198cc2862d17eb32591c0208000000000000000000000000abd4277717fd22b4e91232578c34478546dc381f000000000000000000000000edb34a82f00c71c2082171e4365ea85d422620af00000000000000000000000067a01ab58cc873bfbd93c89f2b0897e85007b772000000000000000000000000cf093b6dfce969e640dbd38d7302ce2e7ca531df00000000000000000000000054620853f4f0799bee70832b767fcb6ed5b48eba0000000000000000000000007a836b45c06e57c65451c41168a7f269146b1b0d0000000000000000000000002d50a018e1c5194334d8ce52d7152d2ac99f7b370000000000000000000000000d8571cf484de9f090edb7e51882d60402212d83000000000000000000000000d1f982eca739bd2165ea085c379231646302eae30000000000000000000000000451b45ca19945c38adc39bc91f45b3d518aa8e3000000000000000000000000002b254abdcef1f9af4e56f0e9776bc1feea1edc00000000000000000000000040692724326503b8fdc8472df7ee658f4bdbfc890000000000000000000000006c66ebb344c3251fbd49cf00b93ebb562f3637c600000000000000000000000027570157d3b72560143af4d8a4528117e22155750000000000000000000000007837d0bfec3abd92a1720f21c77aef0b71d0f58e00000000000000000000000061779ad9d36ba354e235c59fb48651ace92f9fae000000000000000000000000c08d21eb6000357b3d70fbedaf6a1ce5c94d6286000000000000000000000000a7e51da6df5079e42048f43ffb355952cbfd504d000000000000000000000000d93e1bd6d0716ecdeff07f59d31fdf3679250f3a0000000000000000000000006065043d769e88421e2592472a2394d4b5ca1b44000000000000000000000000efe628e9239bf3dc14766aa465064e1784edc05200000000000000000000000050f5ff6683b508f356f97beee5728a38abe3b51e0000000000000000000000009c232158b5e0f9a23bf9a399cd9197c7f131d13b000000000000000000000000c2e82b98ebb92cf36faa85fba798f838a86843d40000000000000000000000008e6ceca77bd9ae8a2c7f9d11870ec80ba6ab751c", contractAddress: "", cumulativeGasUsed: "3916895", gasUsed: "3722910", confirmations: "3435301"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addresses", value: [addressList[210],addressList[211],addressList[212],addressList[213],addressList[214],addressList[215],addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[221],addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229],addressList[230],addressList[231],addressList[232],addressList[233],addressList[234],addressList[235],addressList[236],addressList[237],addressList[238],addressList[239],addressList[240],addressList[241],addressList[242],addressList[243],addressList[244],addressList[245],addressList[246],addressList[247],addressList[248],addressList[249],addressList[250],addressList[251],addressList[252],addressList[253],addressList[254],addressList[255],addressList[256],addressList[257],addressList[258],addressList[259],addressList[260],addressList[261],addressList[262],addressList[263],addressList[264],addressList[265],addressList[266],addressList[267],addressList[268],addressList[269],addressList[270],addressList[271],addressList[272],addressList[273],addressList[274],addressList[275],addressList[276],addressList[277],addressList[278],addressList[279],addressList[280],addressList[281],addressList[282],addressList[283],addressList[284],addressList[285],addressList[286],addressList[287]]}, {type: "uint256", name: "_tier", value: "1"}, {type: "bool", name: "_status", value: true}], name: "whitelistAddresses", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "whitelistAddresses(address[],uint256,bool)" ]( [addressList[210],addressList[211],addressList[212],addressList[213],addressList[214],addressList[215],addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[221],addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229],addressList[230],addressList[231],addressList[232],addressList[233],addressList[234],addressList[235],addressList[236],addressList[237],addressList[238],addressList[239],addressList[240],addressList[241],addressList[242],addressList[243],addressList[244],addressList[245],addressList[246],addressList[247],addressList[248],addressList[249],addressList[250],addressList[251],addressList[252],addressList[253],addressList[254],addressList[255],addressList[256],addressList[257],addressList[258],addressList[259],addressList[260],addressList[261],addressList[262],addressList[263],addressList[264],addressList[265],addressList[266],addressList[267],addressList[268],addressList[269],addressList[270],addressList[271],addressList[272],addressList[273],addressList[274],addressList[275],addressList[276],addressList[277],addressList[278],addressList[279],addressList[280],addressList[281],addressList[282],addressList[283],addressList[284],addressList[285],addressList[286],addressList[287]], "1", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1505313878 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: initializeTier( \"1\", addressList[288] )", async function( ) {
		const txOriginal = {blockNumber: "4269831", timeStamp: "1505314076", hash: "0xf6fa9964801a38a0a234a79da2647e1cb4399c62035e4d80eefb3648e09896e5", nonce: "41", blockHash: "0x635d22bf821d12e6da91bce044fb9da17c8ad74a1a0291068ad2c26fbbbca000", transactionIndex: "12", from: "0x00677d06f75a0581262bacb3de91e1283309772d", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "0", gas: "210000", gasPrice: "22463230501", isError: "0", txreceipt_status: "", input: "0x674ef6c3000000000000000000000000000000000000000000000000000000000000000100000000000000000000000070e32ab40ffcf7d377ff89e51ccad8f2223865ab", contractAddress: "", cumulativeGasUsed: "574443", gasUsed: "51078", confirmations: "3435291"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tierNumber", value: "1"}, {type: "address", name: "_tierAddress", value: addressList[288]}], name: "initializeTier", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "initializeTier(uint256,address)" ]( "1", addressList[288], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1505314076 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_tierNumber", type: "uint256"}, {indexed: false, name: "_tierAddress", type: "address"}], name: "InitializedTier", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InitializedTier", events: [{name: "_tierNumber", type: "uint256", value: "1"}, {name: "_tierAddress", type: "address", value: "0x70e32ab40ffcf7d377ff89e51ccad8f2223865ab"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245410651868848261" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4269926", timeStamp: "1505316224", hash: "0xcb3c91e973281b6300b740bb21e8bb1a5a583a1f98f23d4aa7ca3adab8394cbc", nonce: "4", blockHash: "0xcd514270247a67d1a5bf0b9dca974a86e760b189e9fd157885605222bbc47bab", transactionIndex: "3", from: "0x23b991f7be7afc8706dcef2f04288b44b455feb7", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "64000000000000000000", gas: "196164", gasPrice: "40000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "285072", gasUsed: "196164", confirmations: "3435196"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[261], to: addressList[2], value: "64000000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1505316224 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x23b991f7be7afc8706dcef2f04288b44b455feb7"}, {name: "_amount", type: "uint256", value: "64000000000000000000"}, {name: "_tokens", type: "uint256", value: "1696000000000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[261], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[261], balance: ( await web3.eth.getBalance( addressList[261], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4269928", timeStamp: "1505316258", hash: "0x3c8925542bac50dcbdc67d0937454fa969ae467162a99e5028dc4701f6fb34f7", nonce: "205", blockHash: "0xef396abf980787d644c4a1ab1655b626207cf6db9034faec1a27b7ef15bd2f61", transactionIndex: "64", from: "0xa145addb0a24f0c4697189a02eadb006be244d49", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "64151000000000000000", gas: "196164", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "2376907", gasUsed: "181164", confirmations: "3435194"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[55], to: addressList[2], value: "64151000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1505316258 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0xa145addb0a24f0c4697189a02eadb006be244d49"}, {name: "_amount", type: "uint256", value: "64151000000000000000"}, {name: "_tokens", type: "uint256", value: "1700001500000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[55], balance: "233202323508313683" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[55], balance: ( await web3.eth.getBalance( addressList[55], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4269932", timeStamp: "1505316324", hash: "0x6f95c145e6c6a2473deb27b8b58a3c15480cf6faff257e2b9a6c35eade9d6d3a", nonce: "33", blockHash: "0xffcece8e1d31f2faa714e1da2f90b39913ebafc3e2e146cef740723ebfabfe7c", transactionIndex: "22", from: "0x0868411ca03e6655d7ee957089dc983d74b9bf1a", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "45000000000000000000", gas: "160508", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "1203794", gasUsed: "160508", confirmations: "3435190"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[104], to: addressList[2], value: "45000000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[104], balance: "106256573000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[104], balance: ( await web3.eth.getBalance( addressList[104], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4269932", timeStamp: "1505316324", hash: "0x43ff026e41d98e446b693311be1c945fcbca93b4de19d4e1642669e7775e1b65", nonce: "46", blockHash: "0xffcece8e1d31f2faa714e1da2f90b39913ebafc3e2e146cef740723ebfabfe7c", transactionIndex: "37", from: "0x8c0114f7507485c2289cb4fc7fadb61d4e2f49b3", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "64151000000000000000", gas: "60000", gasPrice: "22463230501", isError: "1", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "2119161", gasUsed: "60000", confirmations: "3435190"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[203], to: addressList[2], value: "64151000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[203], balance: "1065796593000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[203], balance: ( await web3.eth.getBalance( addressList[203], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4269932", timeStamp: "1505316324", hash: "0xfdb878d79518430e09f9177c4e915a13ef3805d12a66beec6e941bd8e990c62f", nonce: "24", blockHash: "0xffcece8e1d31f2faa714e1da2f90b39913ebafc3e2e146cef740723ebfabfe7c", transactionIndex: "42", from: "0x9a73c36d924c197c6418a24ea986e5d3f7c1ddf3", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "64151000000000000000", gas: "240763", gasPrice: "22463230501", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "2403211", gasUsed: "181164", confirmations: "3435190"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[146], to: addressList[2], value: "64151000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1505316324 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x9a73c36d924c197c6418a24ea986e5d3f7c1ddf3"}, {name: "_amount", type: "uint256", value: "64151000000000000000"}, {name: "_tokens", type: "uint256", value: "1700001500000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[146], balance: "79979149095311965" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[146], balance: ( await web3.eth.getBalance( addressList[146], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4269934", timeStamp: "1505316351", hash: "0xf4b6f4c37dd6a533e8b50bbba448d40170ccbf039d70a83a342e0c1e10a11b48", nonce: "112", blockHash: "0xe68dd4c344091e7e28ecebd068779d5d6c5fdc05c88df6d8874deb36b010a8f3", transactionIndex: "9", from: "0x0960da039bb8151cacfef620476e8baf34bd9565", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "64151000000000000000", gas: "250000", gasPrice: "32000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "459542", gasUsed: "181164", confirmations: "3435188"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[70], to: addressList[2], value: "64151000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1505316351 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x0960da039bb8151cacfef620476e8baf34bd9565"}, {name: "_amount", type: "uint256", value: "64151000000000000000"}, {name: "_tokens", type: "uint256", value: "1700001500000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[70], balance: "680421751823765131" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[70], balance: ( await web3.eth.getBalance( addressList[70], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4269936", timeStamp: "1505316430", hash: "0x723592d67fc5be4e8de6f716f3325ddbbd2a561b5e24ba202a49d97ed17982de", nonce: "34", blockHash: "0xd196b1f24f8c35ed203dec64cfe8d82baf203f277b425f2787405ab3eeceb06b", transactionIndex: "14", from: "0x0868411ca03e6655d7ee957089dc983d74b9bf1a", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "45000000000000000000", gas: "160508", gasPrice: "60000000000", isError: "1", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "1383950", gasUsed: "160508", confirmations: "3435186"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[104], to: addressList[2], value: "45000000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[104], balance: "106256573000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[104], balance: ( await web3.eth.getBalance( addressList[104], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4269936", timeStamp: "1505316430", hash: "0x98b8908580a1c8ddf8b5012b3f52425c3bd4eaf63fc88e2d19bed5f98bce3f17", nonce: "128", blockHash: "0xd196b1f24f8c35ed203dec64cfe8d82baf203f277b425f2787405ab3eeceb06b", transactionIndex: "34", from: "0xffdd5bfe33c8fa18af76b944e725b3a116467c64", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "64151000000000000000", gas: "160508", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "2176566", gasUsed: "160508", confirmations: "3435186"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[142], to: addressList[2], value: "64151000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[142], balance: "687061849000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[142], balance: ( await web3.eth.getBalance( addressList[142], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4269936", timeStamp: "1505316430", hash: "0x06e49673e61c707882b7fa3441100a834656e6038163d0bdc7c98e2079bd689c", nonce: "27", blockHash: "0xd196b1f24f8c35ed203dec64cfe8d82baf203f277b425f2787405ab3eeceb06b", transactionIndex: "40", from: "0xcef0e56b84ad7d5be9edcb7faf66f85ae83942a4", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "64000000000000000000", gas: "260509", gasPrice: "42000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "2488712", gasUsed: "181164", confirmations: "3435186"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[248], to: addressList[2], value: "64000000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1505316430 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0xcef0e56b84ad7d5be9edcb7faf66f85ae83942a4"}, {name: "_amount", type: "uint256", value: "64000000000000000000"}, {name: "_tokens", type: "uint256", value: "1696000000000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[248], balance: "15009540117133653903" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[248], balance: ( await web3.eth.getBalance( addressList[248], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4269941", timeStamp: "1505316532", hash: "0x16ffdcb15c15c843df9dca5ffcf0834b27942dbdc48a45fadf03ba94e550b5f9", nonce: "371", blockHash: "0x066d030d606a3085208972c24223110913721f8158ba3b99163ed20d9bb0e27f", transactionIndex: "168", from: "0x924c251902924c7dbd4cbf166d42757fb2d146cb", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "64000000000000000000", gas: "200000", gasPrice: "60000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "5120304", gasUsed: "181164", confirmations: "3435181"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[62], to: addressList[2], value: "64000000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1505316532 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x924c251902924c7dbd4cbf166d42757fb2d146cb"}, {name: "_amount", type: "uint256", value: "64000000000000000000"}, {name: "_tokens", type: "uint256", value: "1696000000000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[62], balance: "11931865194553635580" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[62], balance: ( await web3.eth.getBalance( addressList[62], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4269941", timeStamp: "1505316532", hash: "0xb47db7c06e1c4cc1173ac0d2ed8164a0b58d4fb9c2c2d45abf3e3374a183f8ee", nonce: "25", blockHash: "0x066d030d606a3085208972c24223110913721f8158ba3b99163ed20d9bb0e27f", transactionIndex: "171", from: "0x049503a94f506b601661d8bc792a2cc59ea230d9", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "64151000000000000000", gas: "200000", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "5363870", gasUsed: "160508", confirmations: "3435181"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[217], to: addressList[2], value: "64151000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1505316532 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x049503a94f506b601661d8bc792a2cc59ea230d9"}, {name: "_amount", type: "uint256", value: "64151000000000000000"}, {name: "_tokens", type: "uint256", value: "1700001500000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[217], balance: "1564975534185699977331" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[217], balance: ( await web3.eth.getBalance( addressList[217], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buy(  )", async function( ) {
		const txOriginal = {blockNumber: "4269942", timeStamp: "1505316567", hash: "0x1483b022cc8116524847fc4e77faa0e5f1bdbc778dd9fba8e571daf738888e4b", nonce: "35", blockHash: "0x6853a21c39891782aac159ca8b1d41384643ee2bb4ee7b5470c45ad496794705", transactionIndex: "4", from: "0x0868411ca03e6655d7ee957089dc983d74b9bf1a", to: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a", value: "45000000000000000000", gas: "250000", gasPrice: "60000000000", isError: "0", txreceipt_status: "", input: "0xa6f2ae3a", contractAddress: "", cumulativeGasUsed: "265164", gasUsed: "181164", confirmations: "3435180"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[104], to: addressList[2], value: "45000000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1505316567 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_tokens", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "_th", type: "address", value: "0x0868411ca03e6655d7ee957089dc983d74b9bf1a"}, {name: "_amount", type: "uint256", value: "45000000000000000000"}, {name: "_tokens", type: "uint256", value: "1192500000000000000000000"}], address: "0xc22462d4bc50952b061c9e6c585fdd9a04d0d75a"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[104], balance: "106256573000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[104], balance: ( await web3.eth.getBalance( addressList[104], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
