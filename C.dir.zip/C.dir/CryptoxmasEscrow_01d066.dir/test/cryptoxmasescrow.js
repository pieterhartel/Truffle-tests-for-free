const CryptoxmasEscrow = artifacts.require( "./CryptoxmasEscrow.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "CryptoxmasEscrow" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xcBD901dB55c9139828f7b5D5Cbfd5AfeAB01d066", "0x235b3683368BAd95dBa674d5F5177C02083Be1e2", "0x30f938fED5dE6e06a9A7Cd2Ac3517131C317B1E7", "0x6C0F58AD4eb24da5769412Bf34dDEe698c4d185b", "0xcb90B485b3f4fa49c0386D475E557074CA148feB", "0x572e508C073C8cf67DBf187Bc85F76F599096A97", "0xE47494379c1d48ee73454C251A6395FDd4F9eb43", "0x71B132a22885B20cAa13d8C52EECB28772AAB057", "0xf66246AeDE0f9EF18aAA2c491F17f40a4c2F6b86", "0xb9a985AC1Ae8430da4ec282C999c3BC32480e34e", "0xe47B0f0a25Bf0EDdefcaDdf374f9F93c87d4d058", "0x8D55e7de182DcC7a6627fD424cC0A3A00E049465", "0xAb32D6D9f59d6c9BDb87d5064dfCeA05b89B795b", "0x57a672f956e8a5785B55a1fD27176aA082a39913", "0x648002D98cEfFCAD8d49F3b8FF121FdA11EcadaD", "0x54BeCc7560a7Be76d72ED76a1f5fee6C5a2A7Ab6", "0x835de96A2d3D37Ea65c32ab8244668edcb0bc78E", "0x18495D4A42d07FDBB965732E26C33B61999F5F6C", "0xD8cc5F18c8A701ac353e7406c34cAF1660C08f18", "0xDe27635C9f742DeAa6B179A72d01c8e0776E8De9", "0x40FF713CACc6Fea944B65b7F4fbfEfc36b04f407"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "tokensCounter", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "givethBridge", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_transitAddress", type: "address"}], name: "getGift", outputs: [{name: "tokenId", type: "uint256"}, {name: "tokenUri", type: "string"}, {name: "sender", type: "address"}, {name: "claimEth", type: "uint256"}, {name: "nftPrice", type: "uint256"}, {name: "status", type: "uint8"}, {name: "msgHash", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "account", type: "address"}], name: "isPauser", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "nft", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "EPHEMERAL_ADDRESS_FEE", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenUri", type: "string"}, {name: "_transitAddress", type: "address"}, {name: "_value", type: "uint256"}], name: "canBuyGift", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenUri", type: "string"}], name: "getTokenCategory", outputs: [{name: "categoryId", type: "uint8"}, {name: "minted", type: "uint256"}, {name: "maxQnty", type: "uint256"}, {name: "price", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "MIN_PRICE", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "givethReceiverId", outputs: [{name: "", type: "uint64"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: true, name: "tokenUri", type: "string"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "claimEth", type: "uint256"}, {indexed: false, name: "nftPrice", type: "uint256"}], name: "LogBuy", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "claimEth", type: "uint256"}], name: "LogClaim", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}], name: "LogCancel", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}], name: "Paused", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}], name: "Unpaused", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "PauserAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "PauserRemoved", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogBuy(address,address,string,uint256,uint256,uint256)", "LogClaim(address,address,uint256,address,uint256)", "LogCancel(address,address,uint256)", "LogAddTokenCategory(string,uint8,uint256,uint256)", "OwnershipTransferred(address,address)", "Paused(address)", "Unpaused(address)", "PauserAdded(address)", "PauserRemoved(address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x1fb8c7c5590346996c8e14141338c3fc270cc0c2bbb2df2627f19cb917d65e23", "0x996c1a65142088eaea83b708f3800e60834c7357daf1469308e2aa52c2d1a3dd", "0x1f4fedef2ca6d59bb9d65eea71fc10da706e68e90d6bc96d278fc385b3195567", "0xeecad4c5fef104ebd8d817e80894be416315168481043aaddc34b44707b40b89", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0", "0x62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258", "0x5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa", "0x6719d08c1888103bea251a4ed56406bd0c3e69723c8a1686e017e7bbe159b6f8", "0xcd265ebaf09df2871cc7bd4133404a235ba12eff2041bb89d9c714a2621c7c7e"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6869533 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6873684 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_givethBridge", value: 4}, {type: "uint64", name: "_givethReceiverId", value: "569"}, {type: "string", name: "_name", value: "CryptoXmas Postcards"}, {type: "string", name: "_symbol", value: "CXMAS"}], name: "CryptoxmasEscrow", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "tokensCounter", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensCounter()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "givethBridge", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "givethBridge()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_transitAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getGift", outputs: [{name: "tokenId", type: "uint256"}, {name: "tokenUri", type: "string"}, {name: "sender", type: "address"}, {name: "claimEth", type: "uint256"}, {name: "nftPrice", type: "uint256"}, {name: "status", type: "uint8"}, {name: "msgHash", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getGift(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "account", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isPauser", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isPauser(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "nft", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nft()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "EPHEMERAL_ADDRESS_FEE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "EPHEMERAL_ADDRESS_FEE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "string", name: "_tokenUri", value: random.string( maxRandom )}, {type: "address", name: "_transitAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_value", value: random.range( maxRandom )}], name: "canBuyGift", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "canBuyGift(string,address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "string", name: "_tokenUri", value: random.string( maxRandom )}], name: "getTokenCategory", outputs: [{name: "categoryId", type: "uint8"}, {name: "minted", type: "uint256"}, {name: "maxQnty", type: "uint256"}, {name: "price", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokenCategory(string)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MIN_PRICE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MIN_PRICE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "givethReceiverId", outputs: [{name: "", type: "uint64"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "givethReceiverId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "CryptoxmasEscrow", function( accounts ) {

	it( "TEST: CryptoxmasEscrow( addressList[4], \"569\", `CryptoXmas Pos... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6869533", timeStamp: "1544569310", hash: "0x99ae2e70d9f4c6bcfeb86eab2ed2ca774dcbeaa1119a5fba471adbb96c25e613", nonce: "1", blockHash: "0xb07a6c37640e5e8a06c7da47e69d8120d2f18070e7b71abc500ed80f414d8722", transactionIndex: "85", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: 0, value: "0", gas: "4000000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xe17a76a200000000000000000000000030f938fed5de6e06a9a7cd2ac3517131c317b1e70000000000000000000000000000000000000000000000000000000000000239000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000001443727970746f586d617320506f73746361726473000000000000000000000000000000000000000000000000000000000000000000000000000000000000000543584d4153000000000000000000000000000000000000000000000000000000", contractAddress: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", cumulativeGasUsed: "7344084", gasUsed: "3562108", confirmations: "808065"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_givethBridge", value: addressList[4]}, {type: "uint64", name: "_givethReceiverId", value: "569"}, {type: "string", name: "_name", value: `CryptoXmas Postcards`}, {type: "string", name: "_symbol", value: `CXMAS`}], name: "CryptoxmasEscrow", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = CryptoxmasEscrow.new( addressList[4], "569", `CryptoXmas Postcards`, `CXMAS`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1544569310 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = CryptoxmasEscrow.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"} ;
		console.error( "eventCallOriginal[0,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnershipTransferred", events: [{name: "previousOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x235b3683368bad95dba674d5f5177c02083be1e2"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[0,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "PauserAdded", type: "event"} ;
		console.error( "eventCallOriginal[0,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PauserAdded", events: [{name: "account", type: "address", value: "0x235b3683368bad95dba674d5f5177c02083be1e2"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[0,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmbLR9VpdRK... )", async function( ) {
		const txOriginal = {blockNumber: "6869548", timeStamp: "1544569536", hash: "0xa6c67e46a8a763e703abed0628b2bf2e4fd4e0dda9e3b036ee8fddc9f4d4aa8a", nonce: "2", blockHash: "0xc8268fefe9d2a04817321214a3bb02af8762bf9db73330be3d4491787f2001c8", transactionIndex: "71", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d624c5239567064524b4c366e62313342464a6d445859426a43644d7647796f5036395652644a6f455a67503800000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7577915", gasUsed: "99195", confirmations: "808050"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmbLR9VpdRKL6nb13BFJmDXYBjCdMvGyoP69VRdJoEZgP8`}, {type: "uint8", name: "_categoryId", value: "4"}, {type: "uint256", name: "_maxQnty", value: "20"}, {type: "uint256", name: "_price", value: "500000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmbLR9VpdRKL6nb13BFJmDXYBjCdMvGyoP69VRdJoEZgP8`, "4", "20", "500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1544569536 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[1,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmbLR9VpdRKL6nb13BFJmDXYBjCdMvGyoP69VRdJoEZgP8"}, {name: "categoryId", type: "uint8", value: "4"}, {name: "maxQnty", type: "uint256", value: "20"}, {name: "price", type: "uint256", value: "500000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[1,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmZPiwDLeDa... )", async function( ) {
		const txOriginal = {blockNumber: "6869552", timeStamp: "1544569587", hash: "0x2b8816601e5a79d599cff6ebeb676d59b6aa6ebaa14b2d08632232111b040eb5", nonce: "3", blockHash: "0x82bf5b032b4cc3acadfc30ce454bbcac3b73b2c0da7c3d5573739b5b088cc74a", transactionIndex: "64", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d5a506977444c654461615070356a6174624455416674786e4e47726445446f6d6844534c6d6b327a7442323300000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3889737", gasUsed: "99195", confirmations: "808046"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmZPiwDLeDaaPp5jatbDUAftxnNGrdEDomhDSLmk2ztB23`}, {type: "uint8", name: "_categoryId", value: "2"}, {type: "uint256", name: "_maxQnty", value: "50"}, {type: "uint256", name: "_price", value: "100000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmZPiwDLeDaaPp5jatbDUAftxnNGrdEDomhDSLmk2ztB23`, "2", "50", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1544569587 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmZPiwDLeDaaPp5jatbDUAftxnNGrdEDomhDSLmk2ztB23"}, {name: "categoryId", type: "uint8", value: "2"}, {name: "maxQnty", type: "uint256", value: "50"}, {name: "price", type: "uint256", value: "100000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmeW9VoBpLU... )", async function( ) {
		const txOriginal = {blockNumber: "6869554", timeStamp: "1544569601", hash: "0xa2e0d1d330399d48d2ced91187db973703ed3e9a365db9695191abb2056a2b3d", nonce: "4", blockHash: "0x290d46bc9e794d76b3c90dac96e556099e5de84bf6b5a47ef0905de55f2c4f2f", transactionIndex: "17", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99131", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d655739566f42704c556832664856346b36446d38736766355254676d687431564742474d4c5962324746627500000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2206740", gasUsed: "99131", confirmations: "808044"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmeW9VoBpLUh2fHV4k6Dm8sgf5RTgmht1VGBGMLYb2GFbu`}, {type: "uint8", name: "_categoryId", value: "1"}, {type: "uint256", name: "_maxQnty", value: "100"}, {type: "uint256", name: "_price", value: "50000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmeW9VoBpLUh2fHV4k6Dm8sgf5RTgmht1VGBGMLYb2GFbu`, "1", "100", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1544569601 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmeW9VoBpLUh2fHV4k6Dm8sgf5RTgmht1VGBGMLYb2GFbu"}, {name: "categoryId", type: "uint8", value: "1"}, {name: "maxQnty", type: "uint256", value: "100"}, {name: "price", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmbUZGXhmFS... )", async function( ) {
		const txOriginal = {blockNumber: "6869556", timeStamp: "1544569626", hash: "0x0016885ab0f810c10fdf6ce511d33c248c50097104e9f483727691e14bcc7807", nonce: "5", blockHash: "0xf4967c65679e3194f30ec2d277b81b31cc927c82e530bcf728f147b7983cd0af", transactionIndex: "100", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d62555a4758686d4653484d565734697964655831707335486f647472555a38514b6e566e613864394445794400000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7667878", gasUsed: "99195", confirmations: "808042"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmbUZGXhmFSHMVW4iydeX1ps5HodtrUZ8QKnVna8d9DEyD`}, {type: "uint8", name: "_categoryId", value: "5"}, {type: "uint256", name: "_maxQnty", value: "10"}, {type: "uint256", name: "_price", value: "1000000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmbUZGXhmFSHMVW4iydeX1ps5HodtrUZ8QKnVna8d9DEyD`, "5", "10", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1544569626 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[4,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmbUZGXhmFSHMVW4iydeX1ps5HodtrUZ8QKnVna8d9DEyD"}, {name: "categoryId", type: "uint8", value: "5"}, {name: "maxQnty", type: "uint256", value: "10"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[4,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmawEobzFvg... )", async function( ) {
		const txOriginal = {blockNumber: "6869558", timeStamp: "1544569651", hash: "0x6ce2aec456be3c8631dfd9bb8aba27a8799acfbf7eec24a7cdfcee21de6fd308", nonce: "6", blockHash: "0x3bda35581f49394a8f048a69e119ca57de1232ec12988d11ec52a17575a191c4", transactionIndex: "40", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "3644686847", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d6177456f627a4676676f327a666477704d4379346b4e62365279726f45386a454b4c4a726f5155715356415900000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3710258", gasUsed: "99195", confirmations: "808040"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmawEobzFvgo2zfdwpMCy4kNb6RyroE8jEKLJroQUqSVAY`}, {type: "uint8", name: "_categoryId", value: "4"}, {type: "uint256", name: "_maxQnty", value: "20"}, {type: "uint256", name: "_price", value: "500000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmawEobzFvgo2zfdwpMCy4kNb6RyroE8jEKLJroQUqSVAY`, "4", "20", "500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1544569651 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[5,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmawEobzFvgo2zfdwpMCy4kNb6RyroE8jEKLJroQUqSVAY"}, {name: "categoryId", type: "uint8", value: "4"}, {name: "maxQnty", type: "uint256", value: "20"}, {name: "price", type: "uint256", value: "500000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[5,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmVdCsDqSub... )", async function( ) {
		const txOriginal = {blockNumber: "6869564", timeStamp: "1544569757", hash: "0xc6d62155adf9705a9a3d39a5c763477b3fd87d6a9df1554d7ebec7828269c899", nonce: "7", blockHash: "0xd79190061e81add0a39cc869ba669f729ef6b469f4c0c359a1629758b30bf04f", transactionIndex: "36", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000002100000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d566443734471537562466170566d32446632744775783373573561625558773532465a386d3931777477794e00000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6678047", gasUsed: "99195", confirmations: "808034"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmVdCsDqSubFapVm2Df2tGux3sW5abUXw52FZ8m91wtwyN`}, {type: "uint8", name: "_categoryId", value: "3"}, {type: "uint256", name: "_maxQnty", value: "33"}, {type: "uint256", name: "_price", value: "200000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmVdCsDqSubFapVm2Df2tGux3sW5abUXw52FZ8m91wtwyN`, "3", "33", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1544569757 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[6,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmVdCsDqSubFapVm2Df2tGux3sW5abUXw52FZ8m91wtwyN"}, {name: "categoryId", type: "uint8", value: "3"}, {name: "maxQnty", type: "uint256", value: "33"}, {name: "price", type: "uint256", value: "200000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[6,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmcQdmwxJxB... )", async function( ) {
		const txOriginal = {blockNumber: "6869570", timeStamp: "1544569903", hash: "0x2735060eaec943a0705a10f18a9000b2139e56054feee6eff184c0d17494a503", nonce: "8", blockHash: "0x88ca1dedf1713fba58c9fc9aa67f76244c8238d1e125f76ee44b53d1508a358a", transactionIndex: "53", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d6351646d77784a784264586f33336b53424b694458756d55525a6b516e4568386845726b5978447137524b6400000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7688569", gasUsed: "99195", confirmations: "808028"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmcQdmwxJxBdXo33kSBKiDXumURZkQnEh8hErkYxDq7RKd`}, {type: "uint8", name: "_categoryId", value: "5"}, {type: "uint256", name: "_maxQnty", value: "10"}, {type: "uint256", name: "_price", value: "1000000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmcQdmwxJxBdXo33kSBKiDXumURZkQnEh8hErkYxDq7RKd`, "5", "10", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1544569903 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[7,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmcQdmwxJxBdXo33kSBKiDXumURZkQnEh8hErkYxDq7RKd"}, {name: "categoryId", type: "uint8", value: "5"}, {name: "maxQnty", type: "uint256", value: "10"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[7,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmVj9LUNpHB... )", async function( ) {
		const txOriginal = {blockNumber: "6869575", timeStamp: "1544569985", hash: "0x97bf0514a301ccfbd4f29c18196e5fa287926776178572fe7bff381fffeace2c", nonce: "9", blockHash: "0xb5839196b9bc9df98a6f2dfee9ee54e6ba03a90f68a0e483068b84e27a9e2648", transactionIndex: "108", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d566a394c554e7048424348445a526f5858336e71766850506a7463444c7a3741717a704c416733737342416a00000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7990467", gasUsed: "99195", confirmations: "808023"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmVj9LUNpHBCHDZRoXX3nqvhPPjtcDLz7AqzpLAg3ssBAj`}, {type: "uint8", name: "_categoryId", value: "4"}, {type: "uint256", name: "_maxQnty", value: "20"}, {type: "uint256", name: "_price", value: "500000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmVj9LUNpHBCHDZRoXX3nqvhPPjtcDLz7AqzpLAg3ssBAj`, "4", "20", "500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1544569985 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmVj9LUNpHBCHDZRoXX3nqvhPPjtcDLz7AqzpLAg3ssBAj"}, {name: "categoryId", type: "uint8", value: "4"}, {name: "maxQnty", type: "uint256", value: "20"}, {name: "price", type: "uint256", value: "500000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmajaRS29Jc... )", async function( ) {
		const txOriginal = {blockNumber: "6869578", timeStamp: "1544570032", hash: "0xae2ba4cdd40fa6ca2bcffbab12e47a2f1442e9567bafb47d8c4358726e15dbb3", nonce: "10", blockHash: "0x84eb86a350e1e3c5ee267e3fae9ccf70100d8aedc4780b2f33ffbec25ccd3e71", transactionIndex: "74", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000002100000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d616a61525332394a63646f69396b324e4c4843536971646b34467a7a5476506946525961336d68414b75354d00000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3585095", gasUsed: "99195", confirmations: "808020"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmajaRS29Jcdoi9k2NLHCSiqdk4FzzTvPiFRYa3mhAKu5M`}, {type: "uint8", name: "_categoryId", value: "3"}, {type: "uint256", name: "_maxQnty", value: "33"}, {type: "uint256", name: "_price", value: "200000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmajaRS29Jcdoi9k2NLHCSiqdk4FzzTvPiFRYa3mhAKu5M`, "3", "33", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1544570032 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmajaRS29Jcdoi9k2NLHCSiqdk4FzzTvPiFRYa3mhAKu5M"}, {name: "categoryId", type: "uint8", value: "3"}, {name: "maxQnty", type: "uint256", value: "33"}, {name: "price", type: "uint256", value: "200000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmRgorNYL7J... )", async function( ) {
		const txOriginal = {blockNumber: "6869588", timeStamp: "1544570223", hash: "0x9b2eccb0ae44cdefa70be411c343075d3e92928da8f1e82403d7a23e15e042a7", nonce: "11", blockHash: "0x1ba0accd51523ac3146bc111f331f9731e45672cb8aa974bed6ab27911c3ea55", transactionIndex: "127", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d52676f724e594c374a4479714335754c6d376e364d4e3245544431795876427a75484773633974557a4c457500000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7520755", gasUsed: "99195", confirmations: "808010"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmRgorNYL7JDyqC5uLm7n6MN2ETD1yXvBzuHGsc9tUzLEu`}, {type: "uint8", name: "_categoryId", value: "4"}, {type: "uint256", name: "_maxQnty", value: "20"}, {type: "uint256", name: "_price", value: "500000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmRgorNYL7JDyqC5uLm7n6MN2ETD1yXvBzuHGsc9tUzLEu`, "4", "20", "500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1544570223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmRgorNYL7JDyqC5uLm7n6MN2ETD1yXvBzuHGsc9tUzLEu"}, {name: "categoryId", type: "uint8", value: "4"}, {name: "maxQnty", type: "uint256", value: "20"}, {name: "price", type: "uint256", value: "500000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmWHu73LLZH... )", async function( ) {
		const txOriginal = {blockNumber: "6869590", timeStamp: "1544570277", hash: "0x3f168f088c2e2e2eff2aa7664417bd12becb35aa7d424821caeab70320868662", nonce: "12", blockHash: "0x23e038bd11057930178c48865f6e335e260a03cf5d29412427ca5c6ea1be7dec", transactionIndex: "118", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "3600000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d57487537334c4c5a485844503637657047394b36454d39744c6576747a4350346a32697776385248586a514e00000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7867391", gasUsed: "99195", confirmations: "808008"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmWHu73LLZHXDP67epG9K6EM9tLevtzCP4j2iwv8RHXjQN`}, {type: "uint8", name: "_categoryId", value: "2"}, {type: "uint256", name: "_maxQnty", value: "50"}, {type: "uint256", name: "_price", value: "100000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmWHu73LLZHXDP67epG9K6EM9tLevtzCP4j2iwv8RHXjQN`, "2", "50", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1544570277 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[11,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmWHu73LLZHXDP67epG9K6EM9tLevtzCP4j2iwv8RHXjQN"}, {name: "categoryId", type: "uint8", value: "2"}, {name: "maxQnty", type: "uint256", value: "50"}, {name: "price", type: "uint256", value: "100000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[11,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmPvy6YsCQF... )", async function( ) {
		const txOriginal = {blockNumber: "6869597", timeStamp: "1544570362", hash: "0x722ea94d23dbf269750aa3a96d8e067a55f0e0ef8fe8acbc1844a84035cd7e24", nonce: "13", blockHash: "0x20513f8a8b87cb94bbd046890b219c8e8b380f251c21013135fccb3a047a5102", transactionIndex: "35", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99131", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d5076793659734351464a7446747641656b7563484855443469775447415a6f69483637337a484d6b6550543300000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3617476", gasUsed: "99131", confirmations: "808001"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmPvy6YsCQFJtFtvAekucHHUD4iwTGAZoiH673zHMkePT3`}, {type: "uint8", name: "_categoryId", value: "1"}, {type: "uint256", name: "_maxQnty", value: "100"}, {type: "uint256", name: "_price", value: "50000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmPvy6YsCQFJtFtvAekucHHUD4iwTGAZoiH673zHMkePT3`, "1", "100", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1544570362 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmPvy6YsCQFJtFtvAekucHHUD4iwTGAZoiH673zHMkePT3"}, {name: "categoryId", type: "uint8", value: "1"}, {name: "maxQnty", type: "uint256", value: "100"}, {name: "price", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmUPikCFEBL... )", async function( ) {
		const txOriginal = {blockNumber: "6869634", timeStamp: "1544570848", hash: "0x9b7f377022544ae0826b4c3e991cc3c014d50aa8d8909a86a85bf610a52bee86", nonce: "14", blockHash: "0x2fa599b016c0b12153e58519cf04e1daec09e336acfeb0f28e134884b4be5844", transactionIndex: "90", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "2211009000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d5550696b434645424c344a435859326546714e643370566e76564d5257466f4535724e77647745784e77536100000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7912726", gasUsed: "99195", confirmations: "807964"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmUPikCFEBL4JCXY2eFqNd3pVnvVMRWFoE5rNwdwExNwSa`}, {type: "uint8", name: "_categoryId", value: "5"}, {type: "uint256", name: "_maxQnty", value: "10"}, {type: "uint256", name: "_price", value: "1000000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmUPikCFEBL4JCXY2eFqNd3pVnvVMRWFoE5rNwdwExNwSa`, "5", "10", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1544570848 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[13,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmUPikCFEBL4JCXY2eFqNd3pVnvVMRWFoE5rNwdwExNwSa"}, {name: "categoryId", type: "uint8", value: "5"}, {name: "maxQnty", type: "uint256", value: "10"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[13,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmTSZpYwkbu... )", async function( ) {
		const txOriginal = {blockNumber: "6869674", timeStamp: "1544571359", hash: "0x007edfa04eba795ea2ad2bff46c30bc313b029609bb605014e0cc9fa72e9f7a8", nonce: "15", blockHash: "0xb2e36948f0930d4061d415368cf3211ba60d1d11ef62c0622544a45f47e2790f", transactionIndex: "24", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000002100000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d54535a7059776b6275664131443655336b347654774763626a4b5356795a376f5835314c516462457462486900000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2370954", gasUsed: "99195", confirmations: "807924"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmTSZpYwkbufA1D6U3k4vTwGcbjKSVyZ7oX51LQdbEtbHi`}, {type: "uint8", name: "_categoryId", value: "3"}, {type: "uint256", name: "_maxQnty", value: "33"}, {type: "uint256", name: "_price", value: "200000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmTSZpYwkbufA1D6U3k4vTwGcbjKSVyZ7oX51LQdbEtbHi`, "3", "33", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1544571359 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[14,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmTSZpYwkbufA1D6U3k4vTwGcbjKSVyZ7oX51LQdbEtbHi"}, {name: "categoryId", type: "uint8", value: "3"}, {name: "maxQnty", type: "uint256", value: "33"}, {name: "price", type: "uint256", value: "200000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[14,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmT2qign8Mb... )", async function( ) {
		const txOriginal = {blockNumber: "6869677", timeStamp: "1544571409", hash: "0x7ed03c0f2dbcb0585056c5dad72f64786ba5c9665d99c3684ebc3b6fd5f15d1e", nonce: "16", blockHash: "0x2dd1bb1e2430363e1e5890e8cbcd9846547b6b2f7f5372fe9089a6caacc69ff1", transactionIndex: "25", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99131", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d54327169676e384d627a354d35663736505a4c616d6d6271316e635748757777323135644c614e747a73416900000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1129356", gasUsed: "99131", confirmations: "807921"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmT2qign8Mbz5M5f76PZLammbq1ncWHuww215dLaNtzsAi`}, {type: "uint8", name: "_categoryId", value: "1"}, {type: "uint256", name: "_maxQnty", value: "100"}, {type: "uint256", name: "_price", value: "50000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmT2qign8Mbz5M5f76PZLammbq1ncWHuww215dLaNtzsAi`, "1", "100", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1544571409 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[15,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmT2qign8Mbz5M5f76PZLammbq1ncWHuww215dLaNtzsAi"}, {name: "categoryId", type: "uint8", value: "1"}, {name: "maxQnty", type: "uint256", value: "100"}, {name: "price", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[15,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmaoTHLBrig... )", async function( ) {
		const txOriginal = {blockNumber: "6869679", timeStamp: "1544571448", hash: "0x184b1250bc1bd3f457a9cbf327a972b4f74660f83487e03dc4ebce50b1ac31cd", nonce: "17", blockHash: "0x760e78778c58f6293903dac1a4b1323e7bf9f73b52553b1d33d53f3fe0f4354f", transactionIndex: "19", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000002100000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d616f54484c427269677233554c44794c59523634544336765a474a635637765777335139386359333567544a00000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1996951", gasUsed: "99195", confirmations: "807919"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmaoTHLBrigr3ULDyLYR64TC6vZGJcV7vWw3Q98cY35gTJ`}, {type: "uint8", name: "_categoryId", value: "3"}, {type: "uint256", name: "_maxQnty", value: "33"}, {type: "uint256", name: "_price", value: "200000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmaoTHLBrigr3ULDyLYR64TC6vZGJcV7vWw3Q98cY35gTJ`, "3", "33", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1544571448 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmaoTHLBrigr3ULDyLYR64TC6vZGJcV7vWw3Q98cY35gTJ"}, {name: "categoryId", type: "uint8", value: "3"}, {name: "maxQnty", type: "uint256", value: "33"}, {name: "price", type: "uint256", value: "200000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmSkyac6URh... )", async function( ) {
		const txOriginal = {blockNumber: "6869682", timeStamp: "1544571465", hash: "0x2337e79e182b649dd1bab334ecfed2f89b101b826585322b72a869a48ee9f0ad", nonce: "18", blockHash: "0x62613c2be66f6e220e41bdf511393c598457382c338b6134b85f61dca1565d33", transactionIndex: "14", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d536b79616336555268456158546879556d42456973534e34563576426f7a397944734b343859395a39434b7100000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4053189", gasUsed: "99195", confirmations: "807916"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmSkyac6URhEaXThyUmBEisSN4V5vBoz9yDsK48Y9Z9CKq`}, {type: "uint8", name: "_categoryId", value: "2"}, {type: "uint256", name: "_maxQnty", value: "50"}, {type: "uint256", name: "_price", value: "100000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmSkyac6URhEaXThyUmBEisSN4V5vBoz9yDsK48Y9Z9CKq`, "2", "50", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1544571465 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[17,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmSkyac6URhEaXThyUmBEisSN4V5vBoz9yDsK48Y9Z9CKq"}, {name: "categoryId", type: "uint8", value: "2"}, {name: "maxQnty", type: "uint256", value: "50"}, {name: "price", type: "uint256", value: "100000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[17,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmUTRX61dQo... )", async function( ) {
		const txOriginal = {blockNumber: "6869689", timeStamp: "1544571637", hash: "0x16364478a46dff026903469a7e6235e975eb3417ee5da62fab051d1f2425b261", nonce: "19", blockHash: "0x1d10a43ec4589e8457a984139e006bc5ad2cae5e0fd5ea4355070f30087c2a14", transactionIndex: "29", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99131", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d55545258363164516f345753726654624b326734576a326b34786a7859383944456639746d56643858437a4e00000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3446679", gasUsed: "99131", confirmations: "807909"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmUTRX61dQo4WSrfTbK2g4Wj2k4xjxY89DEf9tmVd8XCzN`}, {type: "uint8", name: "_categoryId", value: "1"}, {type: "uint256", name: "_maxQnty", value: "100"}, {type: "uint256", name: "_price", value: "50000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmUTRX61dQo4WSrfTbK2g4Wj2k4xjxY89DEf9tmVd8XCzN`, "1", "100", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1544571637 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[18,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmUTRX61dQo4WSrfTbK2g4Wj2k4xjxY89DEf9tmVd8XCzN"}, {name: "categoryId", type: "uint8", value: "1"}, {name: "maxQnty", type: "uint256", value: "100"}, {name: "price", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[18,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmXA64jk4sa... )", async function( ) {
		const txOriginal = {blockNumber: "6869694", timeStamp: "1544571801", hash: "0x5bf79d2809f10a7f8a9ff7e531bb305ecc3e9a0a7c082c9f879321deb12eb8af", nonce: "20", blockHash: "0xdc40edf4c70f9135b6089883e12b3fb9ea28955605eb1e347be936a52e0d478b", transactionIndex: "117", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d584136346a6b3473614232786b4d4d7376576f5648476832545555443464344343677779387835537266466100000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7461838", gasUsed: "99195", confirmations: "807904"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmXA64jk4saB2xkMMsvWoVHGh2TUUD4d4CCgwy8x5SrfFa`}, {type: "uint8", name: "_categoryId", value: "5"}, {type: "uint256", name: "_maxQnty", value: "10"}, {type: "uint256", name: "_price", value: "1000000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmXA64jk4saB2xkMMsvWoVHGh2TUUD4d4CCgwy8x5SrfFa`, "5", "10", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1544571801 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[19,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmXA64jk4saB2xkMMsvWoVHGh2TUUD4d4CCgwy8x5SrfFa"}, {name: "categoryId", type: "uint8", value: "5"}, {name: "maxQnty", type: "uint256", value: "10"}, {name: "price", type: "uint256", value: "1000000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[19,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmUPP342nv5... )", async function( ) {
		const txOriginal = {blockNumber: "6869698", timeStamp: "1544571860", hash: "0x47f9131861266e9ed86740ad3d4056728780ea839e25f430aac5cadcc517a69e", nonce: "21", blockHash: "0x94a86d927ce48f4aaf929b9995b6b995c7cd00b8b1ef2a947992fa8ee872a6e5", transactionIndex: "71", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d5550503334326e763555666275364a6b5a6b764d477636516f364a336d554a6e4b654c416d4c756b3345397a00000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6413402", gasUsed: "99195", confirmations: "807900"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmUPP342nv5Ufbu6JkZkvMGv6Qo6J3mUJnKeLAmLuk3E9z`}, {type: "uint8", name: "_categoryId", value: "4"}, {type: "uint256", name: "_maxQnty", value: "20"}, {type: "uint256", name: "_price", value: "500000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmUPP342nv5Ufbu6JkZkvMGv6Qo6J3mUJnKeLAmLuk3E9z`, "4", "20", "500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1544571860 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmUPP342nv5Ufbu6JkZkvMGv6Qo6J3mUJnKeLAmLuk3E9z"}, {name: "categoryId", type: "uint8", value: "4"}, {name: "maxQnty", type: "uint256", value: "20"}, {name: "price", type: "uint256", value: "500000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmRMJhBegrM... )", async function( ) {
		const txOriginal = {blockNumber: "6869709", timeStamp: "1544572037", hash: "0xf169ded9b2fa99a9f9ee88b52cb58f02f4128d615945e46b83ecbce7158c1a89", nonce: "22", blockHash: "0x8e920b1530a0c5fcff4b4ce41c193dd681ec06cbee1eb2151ae3fe9f39e6dbb1", transactionIndex: "78", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000002100000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d524d4a68426567724d4b554e38714b7a65746d355550327131723362415476337a4a5a6d6b773238395a617000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4419247", gasUsed: "99195", confirmations: "807889"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmRMJhBegrMKUN8qKzetm5UP2q1r3bATv3zJZmkw289Zap`}, {type: "uint8", name: "_categoryId", value: "3"}, {type: "uint256", name: "_maxQnty", value: "33"}, {type: "uint256", name: "_price", value: "200000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmRMJhBegrMKUN8qKzetm5UP2q1r3bATv3zJZmkw289Zap`, "3", "33", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1544572037 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[21,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmRMJhBegrMKUN8qKzetm5UP2q1r3bATv3zJZmkw289Zap"}, {name: "categoryId", type: "uint8", value: "3"}, {name: "maxQnty", type: "uint256", value: "33"}, {name: "price", type: "uint256", value: "200000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[21,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmaTKju4TPR... )", async function( ) {
		const txOriginal = {blockNumber: "6869712", timeStamp: "1544572073", hash: "0xe9b22a952e3e0a817736cff9ed6f939ef5618549d508a6f67b29ba27a6cabe35", nonce: "23", blockHash: "0xb927a19788180213f0e3d7662f279fa6f3f658b15729aa298a3ab435658144b7", transactionIndex: "54", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "5400000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d61544b6a75345450526f5a6d515153515a4c6b6f5532757570344d367a6645736f597046556e503654375a4600000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4661948", gasUsed: "99195", confirmations: "807886"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmaTKju4TPRoZmQQSQZLkoU2uup4M6zfEsoYpFUnP6T7ZF`}, {type: "uint8", name: "_categoryId", value: "4"}, {type: "uint256", name: "_maxQnty", value: "20"}, {type: "uint256", name: "_price", value: "500000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmaTKju4TPRoZmQQSQZLkoU2uup4M6zfEsoYpFUnP6T7ZF`, "4", "20", "500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1544572073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[22,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmaTKju4TPRoZmQQSQZLkoU2uup4M6zfEsoYpFUnP6T7ZF"}, {name: "categoryId", type: "uint8", value: "4"}, {name: "maxQnty", type: "uint256", value: "20"}, {name: "price", type: "uint256", value: "500000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[22,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmRA1hygwJX... )", async function( ) {
		const txOriginal = {blockNumber: "6869715", timeStamp: "1544572154", hash: "0xfa189e3abbc0805eff9a6b1b6b8e6811bbb41b6e6676d45cb725fbb7bd06d32d", nonce: "24", blockHash: "0x507cca6e64378a83a2369a0a5fe3d3931ca766bf59f4ae79a393bed9ac309813", transactionIndex: "101", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "3600000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000002100000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d524131687967774a58776b3743763933426831715541475075344637415462314e325948693352537334663300000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5041596", gasUsed: "99195", confirmations: "807883"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmRA1hygwJXwk7Cv93Bh1qUAGPu4F7ATb1N2YHi3RSs4f3`}, {type: "uint8", name: "_categoryId", value: "3"}, {type: "uint256", name: "_maxQnty", value: "33"}, {type: "uint256", name: "_price", value: "200000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmRA1hygwJXwk7Cv93Bh1qUAGPu4F7ATb1N2YHi3RSs4f3`, "3", "33", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1544572154 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[23,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmRA1hygwJXwk7Cv93Bh1qUAGPu4F7ATb1N2YHi3RSs4f3"}, {name: "categoryId", type: "uint8", value: "3"}, {name: "maxQnty", type: "uint256", value: "33"}, {name: "price", type: "uint256", value: "200000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[23,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/Qma6P5m4auA... )", async function( ) {
		const txOriginal = {blockNumber: "6869742", timeStamp: "1544572440", hash: "0xa872c142c6c8a821570abc063fd70f1a39fce61a5fb02e7698836b8c8518778f", nonce: "25", blockHash: "0x4e17b65abf113679e8ac1201337d4225a628eeadd3fb144f22d34b37e1828f46", transactionIndex: "46", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "2500000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d613650356d346175417076796d7976764e73476d5977756e416a4a62394a74796a6d32706670336466584e3800000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7460803", gasUsed: "99195", confirmations: "807856"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/Qma6P5m4auApvymyvvNsGmYwunAjJb9Jtyjm2pfp3dfXN8`}, {type: "uint8", name: "_categoryId", value: "2"}, {type: "uint256", name: "_maxQnty", value: "50"}, {type: "uint256", name: "_price", value: "100000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/Qma6P5m4auApvymyvvNsGmYwunAjJb9Jtyjm2pfp3dfXN8`, "2", "50", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1544572440 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/Qma6P5m4auApvymyvvNsGmYwunAjJb9Jtyjm2pfp3dfXN8"}, {name: "categoryId", type: "uint8", value: "2"}, {name: "maxQnty", type: "uint256", value: "50"}, {name: "price", type: "uint256", value: "100000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmS7R7aGLa9... )", async function( ) {
		const txOriginal = {blockNumber: "6869766", timeStamp: "1544572737", hash: "0xb1385c4f9db1836439509d51dd3511d2ab8133d477cc4d03556c4151681aca12", nonce: "26", blockHash: "0xc72d0aa7534ad527abbe45cb2646d7e5b158e1bb76f39e300b724c75a0b9d1c9", transactionIndex: "25", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000002100000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d5337523761474c6139563866354c3642725039414675437239476b6370484b55506b6563664e7879556e4a5500000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7766240", gasUsed: "99195", confirmations: "807832"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmS7R7aGLa9V8f5L6BrP9AFuCr9GkcpHKUPkecfNxyUnJU`}, {type: "uint8", name: "_categoryId", value: "3"}, {type: "uint256", name: "_maxQnty", value: "33"}, {type: "uint256", name: "_price", value: "200000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmS7R7aGLa9V8f5L6BrP9AFuCr9GkcpHKUPkecfNxyUnJU`, "3", "33", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1544572737 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[25,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmS7R7aGLa9V8f5L6BrP9AFuCr9GkcpHKUPkecfNxyUnJU"}, {name: "categoryId", type: "uint8", value: "3"}, {name: "maxQnty", type: "uint256", value: "33"}, {name: "price", type: "uint256", value: "200000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[25,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmRYhm79jBM... )", async function( ) {
		const txOriginal = {blockNumber: "6869768", timeStamp: "1544572758", hash: "0x05aba45bf87b08656eb4656f3a4b95e68392fa4942a8450939836bf667eaa739", nonce: "27", blockHash: "0xc302ddd89e421e1e29e9c78f70ed6db250301671d557c6be70d0ee6b169810f7", transactionIndex: "48", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d5259686d37396a424d555141666e676b3739566855506948443277556f7376314763436962727a774a61414800000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2816547", gasUsed: "99195", confirmations: "807830"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmRYhm79jBMUQAfngk79VhUPiHD2wUosv1GcCibrzwJaAH`}, {type: "uint8", name: "_categoryId", value: "2"}, {type: "uint256", name: "_maxQnty", value: "50"}, {type: "uint256", name: "_price", value: "100000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmRYhm79jBMUQAfngk79VhUPiHD2wUosv1GcCibrzwJaAH`, "2", "50", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1544572758 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[26,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmRYhm79jBMUQAfngk79VhUPiHD2wUosv1GcCibrzwJaAH"}, {name: "categoryId", type: "uint8", value: "2"}, {name: "maxQnty", type: "uint256", value: "50"}, {name: "price", type: "uint256", value: "100000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[26,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmW91NMPkn1... )", async function( ) {
		const txOriginal = {blockNumber: "6869772", timeStamp: "1544572839", hash: "0x5d8a98b728fa5c6cc406075cecb694d5f368c301cb333e583b9148e224be404a", nonce: "28", blockHash: "0x5ebc5e5c275ded6d7a7656144f3ec96474de88002b850072ef166c313d219161", transactionIndex: "87", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99131", gasPrice: "6500000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000006400000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d5739314e4d506b6e31696744385032413853754d694844486154327079576172453579784b344c396367734100000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3758470", gasUsed: "99131", confirmations: "807826"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmW91NMPkn1igD8P2A8SuMiHDHaT2pyWarE5yxK4L9cgsA`}, {type: "uint8", name: "_categoryId", value: "1"}, {type: "uint256", name: "_maxQnty", value: "100"}, {type: "uint256", name: "_price", value: "50000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmW91NMPkn1igD8P2A8SuMiHDHaT2pyWarE5yxK4L9cgsA`, "1", "100", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1544572839 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmW91NMPkn1igD8P2A8SuMiHDHaT2pyWarE5yxK4L9cgsA"}, {name: "categoryId", type: "uint8", value: "1"}, {name: "maxQnty", type: "uint256", value: "100"}, {name: "price", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmTbQXvbynC... )", async function( ) {
		const txOriginal = {blockNumber: "6869775", timeStamp: "1544572859", hash: "0x3e37a54ff5875ff0914d2af1f5e601afbdc76f3cd28aa3160b1ee8282331f29c", nonce: "29", blockHash: "0xf81962a07432b58c322cf0e2c33761383d5611d1e5bef894f5216e654a249c88", transactionIndex: "30", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "6500000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d546251587662796e43795163586b31416b637a46534a4856757a7a31316b34775155386351586d3563396a5000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1166929", gasUsed: "99195", confirmations: "807823"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmTbQXvbynCyQcXk1AkczFSJHVuzz11k4wQU8cQXm5c9jP`}, {type: "uint8", name: "_categoryId", value: "4"}, {type: "uint256", name: "_maxQnty", value: "20"}, {type: "uint256", name: "_price", value: "500000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmTbQXvbynCyQcXk1AkczFSJHVuzz11k4wQU8cQXm5c9jP`, "4", "20", "500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1544572859 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[28,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmTbQXvbynCyQcXk1AkczFSJHVuzz11k4wQU8cQXm5c9jP"}, {name: "categoryId", type: "uint8", value: "4"}, {name: "maxQnty", type: "uint256", value: "20"}, {name: "price", type: "uint256", value: "500000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[28,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmRf9R2ZGTe... )", async function( ) {
		const txOriginal = {blockNumber: "6869779", timeStamp: "1544572942", hash: "0x4a872b3740af4cc552bed7ba30fb064067148b4f9ccda06d57a624a23c8bb34f", nonce: "30", blockHash: "0xa2819f0bd2872bb6ce61cd7cea817ef4d7633fcec81fb0a1bbf6c958690be099", transactionIndex: "65", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000002100000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d52663952325a4754654c4b69477477335454587257366e6833324c41557246394157716154704b6d5a7a524200000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4873165", gasUsed: "99195", confirmations: "807819"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmRf9R2ZGTeLKiGtw3TTXrW6nh32LAUrF9AWqaTpKmZzRB`}, {type: "uint8", name: "_categoryId", value: "3"}, {type: "uint256", name: "_maxQnty", value: "33"}, {type: "uint256", name: "_price", value: "200000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmRf9R2ZGTeLKiGtw3TTXrW6nh32LAUrF9AWqaTpKmZzRB`, "3", "33", "200000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1544572942 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[29,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmRf9R2ZGTeLKiGtw3TTXrW6nh32LAUrF9AWqaTpKmZzRB"}, {name: "categoryId", type: "uint8", value: "3"}, {name: "maxQnty", type: "uint256", value: "33"}, {name: "price", type: "uint256", value: "200000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[29,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: addTokenCategory( `https://ipfs.infura.io/ipfs/QmPFu6Dari7... )", async function( ) {
		const txOriginal = {blockNumber: "6869783", timeStamp: "1544572970", hash: "0x794efda54725f5d5f7c36d09d4ac43d7c24e55970c015b6e32139a84db7ac1be", nonce: "31", blockHash: "0x75423f26b97b4c7e6076822b3bfc3af32b345afd6d10fcb10ef211daec8f9795", transactionIndex: "36", from: "0x235b3683368bad95dba674d5f5177c02083be1e2", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "99195", gasPrice: "3900000000", isError: "0", txreceipt_status: "1", input: "0xf12326dd000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000032000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d504675364461726937626554486861667966794b6d5256776953455a37364d4867616e664c3641536a436b3800000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4233620", gasUsed: "99195", confirmations: "807815"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmPFu6Dari7beTHhafyfyKmRVwiSEZ76MHganfL6ASjCk8`}, {type: "uint8", name: "_categoryId", value: "2"}, {type: "uint256", name: "_maxQnty", value: "50"}, {type: "uint256", name: "_price", value: "100000000000000000"}], name: "addTokenCategory", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addTokenCategory(string,uint8,uint256,uint256)" ]( `https://ipfs.infura.io/ipfs/QmPFu6Dari7beTHhafyfyKmRVwiSEZ76MHganfL6ASjCk8`, "2", "50", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1544572970 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenUri", type: "string"}, {indexed: false, name: "categoryId", type: "uint8"}, {indexed: false, name: "maxQnty", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "LogAddTokenCategory", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogAddTokenCategory", events: [{name: "tokenUri", type: "string", value: "https://ipfs.infura.io/ipfs/QmPFu6Dari7beTHhafyfyKmRVwiSEZ76MHganfL6ASjCk8"}, {name: "categoryId", type: "uint8", value: "2"}, {name: "maxQnty", type: "uint256", value: "50"}, {name: "price", type: "uint256", value: "100000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "70583359210153435" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buyGift( `https://ipfs.infura.io/ipfs/QmeW9VoBpLU... )", async function( ) {
		const txOriginal = {blockNumber: "6869824", timeStamp: "1544573603", hash: "0x6e6aebbbe2ee3a8cc3d1810fe185210d9daee144488b9579eff0a401db575acf", nonce: "445", blockHash: "0x84beaf701479964547dd7d05971e05cf083ccc84ad49ee8a6310612c5ceef998", transactionIndex: "42", from: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "51000000000000000", gas: "730680", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x9155f1820000000000000000000000000000000000000000000000000000000000000060000000000000000000000000cb90b485b3f4fa49c0386d475e557074ca148feb00000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d655739566f42704c556832664856346b36446d38736766355254676d687431564742474d4c5962324746627500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002e516d58536b74554e5737657a46463844677872324b32534136663665745957596154505355434d65576d68793366000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3379953", gasUsed: "487120", confirmations: "807774"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "51000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmeW9VoBpLUh2fHV4k6Dm8sgf5RTgmht1VGBGMLYb2GFbu`}, {type: "address", name: "_transitAddress", value: addressList[6]}, {type: "string", name: "_msgHash", value: `QmXSktUNW7ezFF8Dgxr2K2SA6f6etYWYaTPSUCMeWmhy3f`}], name: "buyGift", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGift(string,address,string)" ]( `https://ipfs.infura.io/ipfs/QmeW9VoBpLUh2fHV4k6Dm8sgf5RTgmht1VGBGMLYb2GFbu`, addressList[6], `QmXSktUNW7ezFF8Dgxr2K2SA6f6etYWYaTPSUCMeWmhy3f`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1544573603 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: true, name: "tokenUri", type: "string"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "claimEth", type: "uint256"}, {indexed: false, name: "nftPrice", type: "uint256"}], name: "LogBuy", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBuy", events: [{name: "transitAddress", type: "address", value: "0xcb90b485b3f4fa49c0386d475e557074ca148feb"}, {name: "sender", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "tokenUri", type: "string", value: "0x0c20a06f2637eb566fc503b5cbf32ffccf4309143413a9115f7337ef8522f353"}, {name: "tokenId", type: "uint256", value: "1"}, {name: "claimEth", type: "uint256", value: "1000000000000000"}, {name: "nftPrice", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "337559677883152233" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: claimGift( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6869904", timeStamp: "1544574823", hash: "0x172c335e5cbc5a53a9c5441de2f44b4b5296ba3289b6244ee844dde5263ecb5b", nonce: "0", blockHash: "0x083844f30a498663f0f96d95f654aa8ddc0130ac49eb6d0b51b5804819ccd097", transactionIndex: "39", from: "0xcb90b485b3f4fa49c0386d475e557074ca148feb", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "200000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04f3c40e0000000000000000000000006c0f58ad4eb24da5769412bf34ddee698c4d185b", contractAddress: "", cumulativeGasUsed: "1615719", gasUsed: "112313", confirmations: "807694"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[5]}], name: "claimGift", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimGift(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1544574823 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "claimEth", type: "uint256"}], name: "LogClaim", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogClaim", events: [{name: "transitAddress", type: "address", value: "0xcb90b485b3f4fa49c0386d475e557074ca148feb"}, {name: "sender", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "tokenId", type: "uint256", value: "1"}, {name: "receiver", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "claimEth", type: "uint256", value: "1000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8876870000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buyGift( `https://ipfs.infura.io/ipfs/QmeW9VoBpLU... )", async function( ) {
		const txOriginal = {blockNumber: "6869969", timeStamp: "1544575737", hash: "0x99909c422743a0350eaf77ca80671715736298b061931320d980d98e2039a4ea", nonce: "446", blockHash: "0x798d7e1540ad1bdd67ae55f8972eb0459acee22a412114a121144c09e0223dd4", transactionIndex: "43", from: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "50100000000000000", gas: "685680", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x9155f1820000000000000000000000000000000000000000000000000000000000000060000000000000000000000000572e508c073c8cf67dbf187bc85f76f599096a9700000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d655739566f42704c556832664856346b36446d38736766355254676d687431564742474d4c5962324746627500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002e516d6646385743755634654c4544356a4a4b33477a4c63364834773471646d44566d3141455839577079586e7774000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6040467", gasUsed: "457120", confirmations: "807629"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50100000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmeW9VoBpLUh2fHV4k6Dm8sgf5RTgmht1VGBGMLYb2GFbu`}, {type: "address", name: "_transitAddress", value: addressList[7]}, {type: "string", name: "_msgHash", value: `QmfF8WCuV4eLED5jJK3GzLc6H4w4qdmDVm1AEX9WpyXnwt`}], name: "buyGift", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGift(string,address,string)" ]( `https://ipfs.infura.io/ipfs/QmeW9VoBpLUh2fHV4k6Dm8sgf5RTgmht1VGBGMLYb2GFbu`, addressList[7], `QmfF8WCuV4eLED5jJK3GzLc6H4w4qdmDVm1AEX9WpyXnwt`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1544575737 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: true, name: "tokenUri", type: "string"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "claimEth", type: "uint256"}, {indexed: false, name: "nftPrice", type: "uint256"}], name: "LogBuy", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBuy", events: [{name: "transitAddress", type: "address", value: "0x572e508c073c8cf67dbf187bc85f76f599096a97"}, {name: "sender", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "tokenUri", type: "string", value: "0x0c20a06f2637eb566fc503b5cbf32ffccf4309143413a9115f7337ef8522f353"}, {name: "tokenId", type: "uint256", value: "2"}, {name: "claimEth", type: "uint256", value: "100000000000000"}, {name: "nftPrice", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "337559677883152233" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: claimGift( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6869983", timeStamp: "1544575959", hash: "0x8d4ffb0abf039735b386e12a98deccc65f9ce73c53d143aca8dfe41ea674d2ee", nonce: "0", blockHash: "0xbb441d009371b22ac7319d7bd76e082b610286f1fd1342a3cd7cf24defd02e5b", transactionIndex: "3", from: "0x572e508c073c8cf67dbf187bc85f76f599096a97", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "200000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x04f3c40e000000000000000000000000e47494379c1d48ee73454c251a6395fdd4f9eb43", contractAddress: "", cumulativeGasUsed: "400698", gasUsed: "112313", confirmations: "807615"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[8]}], name: "claimGift", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimGift(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1544575959 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "claimEth", type: "uint256"}], name: "LogClaim", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogClaim", events: [{name: "transitAddress", type: "address", value: "0x572e508c073c8cf67dbf187bc85f76f599096a97"}, {name: "sender", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "tokenId", type: "uint256", value: "2"}, {name: "receiver", type: "address", value: "0xe47494379c1d48ee73454c251a6395fdd4f9eb43"}, {name: "claimEth", type: "uint256", value: "100000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "8876870000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buyGift( `https://ipfs.infura.io/ipfs/QmeW9VoBpLU... )", async function( ) {
		const txOriginal = {blockNumber: "6870100", timeStamp: "1544577530", hash: "0x0e75ab7b5c7e9ca0f5bd3a0f68bd41eb6b9a192455a6c500e453170c70489986", nonce: "447", blockHash: "0xd020b174af17e10b99525a73854814a28a3a52dac9c6fc1d5c8ef63c7104dd54", transactionIndex: "43", from: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "50000000000000000", gas: "663180", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x9155f182000000000000000000000000000000000000000000000000000000000000006000000000000000000000000071b132a22885b20caa13d8c52eecb28772aab05700000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d655739566f42704c556832664856346b36446d38736766355254676d687431564742474d4c5962324746627500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002e516d54686d725a6e684a65534e324d7a694e63754b4d3343724367696750317379705275755251694267336f6859000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6415319", gasUsed: "442120", confirmations: "807498"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmeW9VoBpLUh2fHV4k6Dm8sgf5RTgmht1VGBGMLYb2GFbu`}, {type: "address", name: "_transitAddress", value: addressList[9]}, {type: "string", name: "_msgHash", value: `QmThmrZnhJeSN2MziNcuKM3CrCgigP1sypRuuRQiBg3ohY`}], name: "buyGift", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGift(string,address,string)" ]( `https://ipfs.infura.io/ipfs/QmeW9VoBpLUh2fHV4k6Dm8sgf5RTgmht1VGBGMLYb2GFbu`, addressList[9], `QmThmrZnhJeSN2MziNcuKM3CrCgigP1sypRuuRQiBg3ohY`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1544577530 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: true, name: "tokenUri", type: "string"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "claimEth", type: "uint256"}, {indexed: false, name: "nftPrice", type: "uint256"}], name: "LogBuy", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBuy", events: [{name: "transitAddress", type: "address", value: "0x71b132a22885b20caa13d8c52eecb28772aab057"}, {name: "sender", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "tokenUri", type: "string", value: "0x0c20a06f2637eb566fc503b5cbf32ffccf4309143413a9115f7337ef8522f353"}, {name: "tokenId", type: "uint256", value: "3"}, {name: "claimEth", type: "uint256", value: "0"}, {name: "nftPrice", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "337559677883152233" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buyGift( `https://ipfs.infura.io/ipfs/QmW91NMPkn1... )", async function( ) {
		const txOriginal = {blockNumber: "6870139", timeStamp: "1544578120", hash: "0xa551f5eafb48eddc221662ff4995e713b9a7b66fa1b0986d1654308fcdc81c2a", nonce: "27", blockHash: "0xb6068427ab8600f6127e02dca888c03e2e9838d2772fb174e696bf8547d6cf0e", transactionIndex: "106", from: "0xf66246aede0f9ef18aaa2c491f17f40a4c2f6b86", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "250000000000000000", gas: "685680", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x9155f1820000000000000000000000000000000000000000000000000000000000000060000000000000000000000000b9a985ac1ae8430da4ec282c999c3bc32480e34e00000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d5739314e4d506b6e31696744385032413853754d694844486154327079576172453579784b344c396367734100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002e516d554b664e4e75434672536a416537595367435667483631414d75567747434b356133546434524a347a48584d000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5786364", gasUsed: "457120", confirmations: "807459"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmW91NMPkn1igD8P2A8SuMiHDHaT2pyWarE5yxK4L9cgsA`}, {type: "address", name: "_transitAddress", value: addressList[11]}, {type: "string", name: "_msgHash", value: `QmUKfNNuCFrSjAe7YSgCVgH61AMuVwGCK5a3Td4RJ4zHXM`}], name: "buyGift", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGift(string,address,string)" ]( `https://ipfs.infura.io/ipfs/QmW91NMPkn1igD8P2A8SuMiHDHaT2pyWarE5yxK4L9cgsA`, addressList[11], `QmUKfNNuCFrSjAe7YSgCVgH61AMuVwGCK5a3Td4RJ4zHXM`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1544578120 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: true, name: "tokenUri", type: "string"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "claimEth", type: "uint256"}, {indexed: false, name: "nftPrice", type: "uint256"}], name: "LogBuy", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBuy", events: [{name: "transitAddress", type: "address", value: "0xb9a985ac1ae8430da4ec282c999c3bc32480e34e"}, {name: "sender", type: "address", value: "0xf66246aede0f9ef18aaa2c491f17f40a4c2f6b86"}, {name: "tokenUri", type: "string", value: "0x0e40c904d91088e63403bd14074d4a92e19ef8bc5ff8122fc52209ec9418e15c"}, {name: "tokenId", type: "uint256", value: "4"}, {name: "claimEth", type: "uint256", value: "200000000000000000"}, {name: "nftPrice", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "345933752237388238" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buyGift( `https://ipfs.infura.io/ipfs/QmT2qign8Mb... )", async function( ) {
		const txOriginal = {blockNumber: "6870294", timeStamp: "1544579908", hash: "0x5179374e3a9d65630b6aba976cae52fdcc64c9fdaa676ee545fc437b3305264c", nonce: "448", blockHash: "0x8c17475bff353adc1e25ef4c571ee08a514c47b32d8b46025c747e6f2386fde0", transactionIndex: "79", from: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "60000000000000000", gas: "685680", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x9155f1820000000000000000000000000000000000000000000000000000000000000060000000000000000000000000e47b0f0a25bf0eddefcaddf374f9f93c87d4d05800000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d54327169676e384d627a354d35663736505a4c616d6d6271316e635748757777323135644c614e747a73416900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002e516d617964464541784d77584b594b45794e6e663269416e377471556342316938774875483668524271314c4252000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7391675", gasUsed: "457120", confirmations: "807304"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmT2qign8Mbz5M5f76PZLammbq1ncWHuww215dLaNtzsAi`}, {type: "address", name: "_transitAddress", value: addressList[12]}, {type: "string", name: "_msgHash", value: `QmaydFEAxMwXKYKEyNnf2iAn7tqUcB1i8wHuH6hRBq1LBR`}], name: "buyGift", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGift(string,address,string)" ]( `https://ipfs.infura.io/ipfs/QmT2qign8Mbz5M5f76PZLammbq1ncWHuww215dLaNtzsAi`, addressList[12], `QmaydFEAxMwXKYKEyNnf2iAn7tqUcB1i8wHuH6hRBq1LBR`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1544579908 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: true, name: "tokenUri", type: "string"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "claimEth", type: "uint256"}, {indexed: false, name: "nftPrice", type: "uint256"}], name: "LogBuy", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBuy", events: [{name: "transitAddress", type: "address", value: "0xe47b0f0a25bf0eddefcaddf374f9f93c87d4d058"}, {name: "sender", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "tokenUri", type: "string", value: "0x0f846481321aae4146b3f4afa5c767d643f5159a5e74b3a9f13de743392e9483"}, {name: "tokenId", type: "uint256", value: "5"}, {name: "claimEth", type: "uint256", value: "10000000000000000"}, {name: "nftPrice", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "337559677883152233" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buyGift( `https://ipfs.infura.io/ipfs/QmW91NMPkn1... )", async function( ) {
		const txOriginal = {blockNumber: "6872201", timeStamp: "1544607872", hash: "0x6c74d2bb615c5d2161f0edb8052369ea77bc452447f778c5ec492a289e9fd75b", nonce: "499", blockHash: "0xd87673a86b3eeed08f8bfb550f98603b206cbff71c2e83907cf4048aa4a1c25f", transactionIndex: "53", from: "0x8d55e7de182dcc7a6627fd424cc0a3a00e049465", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "60000000000000000", gas: "442120", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x9155f1820000000000000000000000000000000000000000000000000000000000000060000000000000000000000000ab32d6d9f59d6c9bdb87d5064dfcea05b89b795b00000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d5739314e4d506b6e31696744385032413853754d694844486154327079576172453579784b344c396367734100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002e516d54734b326233366e384831345a4b577935564868345a6b4462744d3266783444434d684667707a57627a6a58000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2925749", gasUsed: "442120", confirmations: "805397"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmW91NMPkn1igD8P2A8SuMiHDHaT2pyWarE5yxK4L9cgsA`}, {type: "address", name: "_transitAddress", value: addressList[14]}, {type: "string", name: "_msgHash", value: `QmTsK2b36n8H14ZKWy5VHh4ZkDbtM2fx4DCMhFgpzWbzjX`}], name: "buyGift", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGift(string,address,string)" ]( `https://ipfs.infura.io/ipfs/QmW91NMPkn1igD8P2A8SuMiHDHaT2pyWarE5yxK4L9cgsA`, addressList[14], `QmTsK2b36n8H14ZKWy5VHh4ZkDbtM2fx4DCMhFgpzWbzjX`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1544607872 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: true, name: "tokenUri", type: "string"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "claimEth", type: "uint256"}, {indexed: false, name: "nftPrice", type: "uint256"}], name: "LogBuy", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBuy", events: [{name: "transitAddress", type: "address", value: "0xab32d6d9f59d6c9bdb87d5064dfcea05b89b795b"}, {name: "sender", type: "address", value: "0x8d55e7de182dcc7a6627fd424cc0a3a00e049465"}, {name: "tokenUri", type: "string", value: "0x0e40c904d91088e63403bd14074d4a92e19ef8bc5ff8122fc52209ec9418e15c"}, {name: "tokenId", type: "uint256", value: "6"}, {name: "claimEth", type: "uint256", value: "10000000000000000"}, {name: "nftPrice", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "55654095625765924" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: claimGift( addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6872240", timeStamp: "1544608444", hash: "0x5702c8f60db17499aa50b94e609249ad5134fed3a1f065589977ff3b4b0098eb", nonce: "0", blockHash: "0x67858f989a333f687d9105190a1aa98958b5f7862c5b1c7e953f5fdf48cb159d", transactionIndex: "71", from: "0xab32d6d9f59d6c9bdb87d5064dfcea05b89b795b", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "200000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x04f3c40e00000000000000000000000057a672f956e8a5785b55a1fd27176aa082a39913", contractAddress: "", cumulativeGasUsed: "3024604", gasUsed: "200000", confirmations: "805358"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[15]}], name: "claimGift", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "2953740000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: claimGift( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6872498", timeStamp: "1544611917", hash: "0x0b7699a82249c98e59c00d5e6d5fa4e9fe05a0e94a4a3ee3be94432fd8ecca7d", nonce: "0", blockHash: "0xb22e24ab4297a8b81b1319370977334f9d12a90c7708a4b6e9bf34b3edca0bb3", transactionIndex: "3", from: "0xe47b0f0a25bf0eddefcaddf374f9f93c87d4d058", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "157313", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x04f3c40e0000000000000000000000006c0f58ad4eb24da5769412bf34ddee698c4d185b", contractAddress: "", cumulativeGasUsed: "352980", gasUsed: "112313", confirmations: "805100"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[5]}], name: "claimGift", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimGift(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1544611917 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "claimEth", type: "uint256"}], name: "LogClaim", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogClaim", events: [{name: "transitAddress", type: "address", value: "0xe47b0f0a25bf0eddefcaddf374f9f93c87d4d058"}, {name: "sender", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "tokenId", type: "uint256", value: "5"}, {name: "receiver", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "claimEth", type: "uint256", value: "10000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "7753740000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buyGift( `https://ipfs.infura.io/ipfs/QmPvy6YsCQF... )", async function( ) {
		const txOriginal = {blockNumber: "6872530", timeStamp: "1544612344", hash: "0x5f81c6be3612ce629c316be9fba526de83250b0856b79a418981182517b1f1cf", nonce: "449", blockHash: "0x90395520873cb096f48cd87f5fa7f78fd8dfe04a02994ac9d2df45c04e49b5fc", transactionIndex: "128", from: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "50000000000000000", gas: "575508", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x9155f1820000000000000000000000000000000000000000000000000000000000000060000000000000000000000000648002d98ceffcad8d49f3b8ff121fda11ecadad00000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d5076793659734351464a7446747641656b7563484855443469775447415a6f69483637337a484d6b65505433000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5013853", gasUsed: "383672", confirmations: "805068"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmPvy6YsCQFJtFtvAekucHHUD4iwTGAZoiH673zHMkePT3`}, {type: "address", name: "_transitAddress", value: addressList[16]}, {type: "string", name: "_msgHash", value: ``}], name: "buyGift", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGift(string,address,string)" ]( `https://ipfs.infura.io/ipfs/QmPvy6YsCQFJtFtvAekucHHUD4iwTGAZoiH673zHMkePT3`, addressList[16], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1544612344 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: true, name: "tokenUri", type: "string"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "claimEth", type: "uint256"}, {indexed: false, name: "nftPrice", type: "uint256"}], name: "LogBuy", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBuy", events: [{name: "transitAddress", type: "address", value: "0x648002d98ceffcad8d49f3b8ff121fda11ecadad"}, {name: "sender", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "tokenUri", type: "string", value: "0x35109b3ccaa3a9965b69df737af765528462698eaf85ead6187172592a3e7106"}, {name: "tokenId", type: "uint256", value: "7"}, {name: "claimEth", type: "uint256", value: "0"}, {name: "nftPrice", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "337559677883152233" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: claimGift( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6872552", timeStamp: "1544612654", hash: "0xbdd9156a415ff2af44438c31e6933c2f10ee107a6f4c54ab9857099e2fe33622", nonce: "0", blockHash: "0x3ebee896a547da61da393f5894476aac252200ea58b6b59dab5b6c02ea62c961", transactionIndex: "17", from: "0x648002d98ceffcad8d49f3b8ff121fda11ecadad", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "149543", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x04f3c40e0000000000000000000000006c0f58ad4eb24da5769412bf34ddee698c4d185b", contractAddress: "", cumulativeGasUsed: "538124", gasUsed: "104543", confirmations: "805046"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[5]}], name: "claimGift", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimGift(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1544612654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "claimEth", type: "uint256"}], name: "LogClaim", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogClaim", events: [{name: "transitAddress", type: "address", value: "0x648002d98ceffcad8d49f3b8ff121fda11ecadad"}, {name: "sender", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "tokenId", type: "uint256", value: "7"}, {name: "receiver", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "claimEth", type: "uint256", value: "0"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "7909140000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: claimGift( addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6872558", timeStamp: "1544612761", hash: "0x57a3edededafcf63b299ad7b46826955a0d9594f98583e7aa50d9e345665b076", nonce: "1", blockHash: "0x36f6f17858484c4fe8bd017c5909a9ce868c79d6da44a1c4c8d9ee34be818b18", transactionIndex: "10", from: "0xab32d6d9f59d6c9bdb87d5064dfcea05b89b795b", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "200000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x04f3c40e00000000000000000000000057a672f956e8a5785b55a1fd27176aa082a39913", contractAddress: "", cumulativeGasUsed: "562455", gasUsed: "200000", confirmations: "805040"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[15]}], name: "claimGift", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "2953740000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: claimGift( addressList[15] )", async function( ) {
		const txOriginal = {blockNumber: "6872576", timeStamp: "1544613003", hash: "0x623e248709c87842ca137b68d4ef5a7b072cf61eaa489e7a22f41280c8b2377d", nonce: "2", blockHash: "0xc3f4ce3659727d1fbf6ba878f14ecb25b30799c776721b6ae1de5ae162bb26a8", transactionIndex: "23", from: "0xab32d6d9f59d6c9bdb87d5064dfcea05b89b795b", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "212313", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x04f3c40e00000000000000000000000057a672f956e8a5785b55a1fd27176aa082a39913", contractAddress: "", cumulativeGasUsed: "1350449", gasUsed: "152313", confirmations: "805022"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[15]}], name: "claimGift", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimGift(address)" ]( addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1544613003 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "claimEth", type: "uint256"}], name: "LogClaim", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogClaim", events: [{name: "transitAddress", type: "address", value: "0xab32d6d9f59d6c9bdb87d5064dfcea05b89b795b"}, {name: "sender", type: "address", value: "0x8d55e7de182dcc7a6627fd424cc0a3a00e049465"}, {name: "tokenId", type: "uint256", value: "6"}, {name: "receiver", type: "address", value: "0x57a672f956e8a5785b55a1fd27176aa082a39913"}, {name: "claimEth", type: "uint256", value: "10000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "2953740000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buyGift( `https://ipfs.infura.io/ipfs/QmUPikCFEBL... )", async function( ) {
		const txOriginal = {blockNumber: "6873178", timeStamp: "1544621264", hash: "0xea9c789680d7bb8172ee29dd5d85abf606fcbe60f26e8e0ef23f3034c926dce7", nonce: "591", blockHash: "0x50db86abdfcd771b66d7069e87b9678976526ef3a73ee33d340983a8c42b5ca9", transactionIndex: "9", from: "0x54becc7560a7be76d72ed76a1f5fee6c5a2a7ab6", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "1000000000000000000", gas: "575508", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x9155f1820000000000000000000000000000000000000000000000000000000000000060000000000000000000000000835de96a2d3d37ea65c32ab8244668edcb0bc78e00000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d5550696b434645424c344a435859326546714e643370566e76564d5257466f4535724e77647745784e775361000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "671159", gasUsed: "383672", confirmations: "804420"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmUPikCFEBL4JCXY2eFqNd3pVnvVMRWFoE5rNwdwExNwSa`}, {type: "address", name: "_transitAddress", value: addressList[18]}, {type: "string", name: "_msgHash", value: ``}], name: "buyGift", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGift(string,address,string)" ]( `https://ipfs.infura.io/ipfs/QmUPikCFEBL4JCXY2eFqNd3pVnvVMRWFoE5rNwdwExNwSa`, addressList[18], ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1544621264 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: true, name: "tokenUri", type: "string"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "claimEth", type: "uint256"}, {indexed: false, name: "nftPrice", type: "uint256"}], name: "LogBuy", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBuy", events: [{name: "transitAddress", type: "address", value: "0x835de96a2d3d37ea65c32ab8244668edcb0bc78e"}, {name: "sender", type: "address", value: "0x54becc7560a7be76d72ed76a1f5fee6c5a2a7ab6"}, {name: "tokenUri", type: "string", value: "0x2aefac7d00b8aa7e1ee0cdcfb91a3807e7d6f5cf7c61cecb6b44d26981f3055f"}, {name: "tokenId", type: "uint256", value: "8"}, {name: "claimEth", type: "uint256", value: "0"}, {name: "nftPrice", type: "uint256", value: "1000000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "8772029361569406912" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: claimGift( addressList[19] )", async function( ) {
		const txOriginal = {blockNumber: "6873192", timeStamp: "1544621482", hash: "0xe8e9272c5689cbc82f1679155f91d1ad11cab362e7d790a7f5c65cf9cf747cb3", nonce: "0", blockHash: "0xe0f70aa49116cc010bfa4111f5fdda7f3fb188c19596ad94555bc2f04b1bc576", transactionIndex: "34", from: "0x835de96a2d3d37ea65c32ab8244668edcb0bc78e", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "179543", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x04f3c40e00000000000000000000000018495d4a42d07fdbb965732e26c33b61999f5f6c", contractAddress: "", cumulativeGasUsed: "1398287", gasUsed: "119543", confirmations: "804406"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[19]}], name: "claimGift", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimGift(address)" ]( addressList[19], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1544621482 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "claimEth", type: "uint256"}], name: "LogClaim", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogClaim", events: [{name: "transitAddress", type: "address", value: "0x835de96a2d3d37ea65c32ab8244668edcb0bc78e"}, {name: "sender", type: "address", value: "0x54becc7560a7be76d72ed76a1f5fee6c5a2a7ab6"}, {name: "tokenId", type: "uint256", value: "8"}, {name: "receiver", type: "address", value: "0x18495d4a42d07fdbb965732e26c33b61999f5f6c"}, {name: "claimEth", type: "uint256", value: "0"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "7609140000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buyGift( `https://ipfs.infura.io/ipfs/QmeW9VoBpLU... )", async function( ) {
		const txOriginal = {blockNumber: "6873429", timeStamp: "1544624392", hash: "0xd94fb36c8e5b32b3c9809b6f98d6c4222293d1f5134a163775e53be4b48f9ebd", nonce: "450", blockHash: "0xd5eb7ce53590eb4b3f8145f1338758c1bb650531c7aff05f8dbc3a7bee18667c", transactionIndex: "34", from: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "50000000000000000", gas: "600000", gasPrice: "4771764706", isError: "0", txreceipt_status: "1", input: "0x9155f1820000000000000000000000000000000000000000000000000000000000000060000000000000000000000000d8cc5f18c8a701ac353e7406c34caf1660c08f1800000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d655739566f42704c556832664856346b36446d38736766355254676d687431564742474d4c5962324746627500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002e516d527a5634517a763355634a424b6b416e5a6a54656d79524d6432556b334b386535506a326959504e3832364e000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3454660", gasUsed: "427120", confirmations: "804169"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmeW9VoBpLUh2fHV4k6Dm8sgf5RTgmht1VGBGMLYb2GFbu`}, {type: "address", name: "_transitAddress", value: addressList[20]}, {type: "string", name: "_msgHash", value: `QmRzV4Qzv3UcJBKkAnZjTemyRMd2Uk3K8e5Pj2iYPN826N`}], name: "buyGift", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGift(string,address,string)" ]( `https://ipfs.infura.io/ipfs/QmeW9VoBpLUh2fHV4k6Dm8sgf5RTgmht1VGBGMLYb2GFbu`, addressList[20], `QmRzV4Qzv3UcJBKkAnZjTemyRMd2Uk3K8e5Pj2iYPN826N`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544624392 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: true, name: "tokenUri", type: "string"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "claimEth", type: "uint256"}, {indexed: false, name: "nftPrice", type: "uint256"}], name: "LogBuy", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBuy", events: [{name: "transitAddress", type: "address", value: "0xd8cc5f18c8a701ac353e7406c34caf1660c08f18"}, {name: "sender", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "tokenUri", type: "string", value: "0x0c20a06f2637eb566fc503b5cbf32ffccf4309143413a9115f7337ef8522f353"}, {name: "tokenId", type: "uint256", value: "9"}, {name: "claimEth", type: "uint256", value: "0"}, {name: "nftPrice", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "337559677883152233" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: claimGift( addressList[21] )", async function( ) {
		const txOriginal = {blockNumber: "6873460", timeStamp: "1544624842", hash: "0x01b4c5cf862692f8e504530b1c77a393d8d39d980f2ffae53701fd06596f7900", nonce: "0", blockHash: "0xa6f3d7757e41c21fa139561418ff3af3e99a2390ef300087f52d76a279ae0dd9", transactionIndex: "65", from: "0xd8cc5f18c8a701ac353e7406c34caf1660c08f18", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "0", gas: "179543", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x04f3c40e000000000000000000000000de27635c9f742deaa6b179a72d01c8e0776e8de9", contractAddress: "", cumulativeGasUsed: "2794205", gasUsed: "119543", confirmations: "804138"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[21]}], name: "claimGift", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimGift(address)" ]( addressList[21], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1544624842 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "claimEth", type: "uint256"}], name: "LogClaim", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogClaim", events: [{name: "transitAddress", type: "address", value: "0xd8cc5f18c8a701ac353e7406c34caf1660c08f18"}, {name: "sender", type: "address", value: "0x6c0f58ad4eb24da5769412bf34ddee698c4d185b"}, {name: "tokenId", type: "uint256", value: "9"}, {name: "receiver", type: "address", value: "0xde27635c9f742deaa6b179a72d01c8e0776e8de9"}, {name: "claimEth", type: "uint256", value: "0"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "7609140000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buyGift( `https://ipfs.infura.io/ipfs/QmUTRX61dQo... )", async function( ) {
		const txOriginal = {blockNumber: "6873684", timeStamp: "1544628055", hash: "0xe183fe62f1fec186341832d46a11f7ff82d9bd48ede62400a4187bda11d35985", nonce: "29", blockHash: "0xcf2e71823383014526acfb2e7a361ae9638e501cbb58ead9adb69f55bb64ccba", transactionIndex: "41", from: "0xf66246aede0f9ef18aaa2c491f17f40a4c2f6b86", to: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066", value: "150000000000000000", gas: "685680", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x9155f182000000000000000000000000000000000000000000000000000000000000006000000000000000000000000040ff713cacc6fea944b65b7f4fbfefc36b04f40700000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004a68747470733a2f2f697066732e696e667572612e696f2f697066732f516d55545258363164516f345753726654624b326734576a326b34786a7859383944456639746d56643858437a4e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002e516d6278365a624c5735735477536e3848543872746e45656f52614c5a75677576554d6466387167553471344b59000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1784245", gasUsed: "457120", confirmations: "803914"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "150000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenUri", value: `https://ipfs.infura.io/ipfs/QmUTRX61dQo4WSrfTbK2g4Wj2k4xjxY89DEf9tmVd8XCzN`}, {type: "address", name: "_transitAddress", value: addressList[22]}, {type: "string", name: "_msgHash", value: `Qmbx6ZbLW5sTwSn8HT8rtnEeoRaLZuguvUMdf8qgU4q4KY`}], name: "buyGift", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGift(string,address,string)" ]( `https://ipfs.infura.io/ipfs/QmUTRX61dQo4WSrfTbK2g4Wj2k4xjxY89DEf9tmVd8XCzN`, addressList[22], `Qmbx6ZbLW5sTwSn8HT8rtnEeoRaLZuguvUMdf8qgU4q4KY`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544628055 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transitAddress", type: "address"}, {indexed: true, name: "sender", type: "address"}, {indexed: true, name: "tokenUri", type: "string"}, {indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "claimEth", type: "uint256"}, {indexed: false, name: "nftPrice", type: "uint256"}], name: "LogBuy", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogBuy", events: [{name: "transitAddress", type: "address", value: "0x40ff713cacc6fea944b65b7f4fbfefc36b04f407"}, {name: "sender", type: "address", value: "0xf66246aede0f9ef18aaa2c491f17f40a4c2f6b86"}, {name: "tokenUri", type: "string", value: "0x56fab117bfcffd005473827dfdfec8b9b6bd4c067795e34f16ba4bcd1d29dbd5"}, {name: "tokenId", type: "uint256", value: "10"}, {name: "claimEth", type: "uint256", value: "100000000000000000"}, {name: "nftPrice", type: "uint256", value: "50000000000000000"}], address: "0xcbd901db55c9139828f7b5d5cbfd5afeab01d066"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "345933752237388238" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "851000000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
