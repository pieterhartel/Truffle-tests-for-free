const CryptoKaiju = artifacts.require( "./CryptoKaiju.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "CryptoKaiju" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x102C527714AB7e652630cAc7a30Abb482B041Fd0", "0x3f8C962eb167aD2f80C72b5F933511CcDF0719D4", "0x7205A1B9C5cf6494ba2CEb5adCca831C05536912", "0x30602250c5f1fcbA5407E99B1DFaAB992EA4fFD2", "0x8b104344F397aFC33Ee55C743a0FbD7d956201cD", "0x8fB52f1d21717D0cbF003b4aD891AEb73Bda929C", "0x75932b377D37B1374cbc138b3033f09b3F5f341c", "0x70E2b2d55E28be65DBdCB2Ac5c498De51C64e828", "0xC0D95fBB7bf19C7665a1C4042b683182B34e2150", "0xeD607bA16f6aC5AFbff9ad9B8C02debA2207Cbc0", "0xe1023C112A39c58238929153F25364c11A33B729", "0x47efE4d7De3F93Eb1F34831876ff605ec6b66A40", "0x15840002e49791971E151626f7ab85040F980eCf", "0xf3B9D698B60fA65C70212Eb31bA233193f39B6F0", "0x44087f09DD5D836AF4F15b14533712a9b4486c46", "0xf0b7ED3e7ec150Af6B26C204e08004e43Fad8b25", "0xdc6799B46a625AC55e944835F7634768a0BfCF6a", "0xEd5CE3eF1220d2D863b2d050F15f2a5A59e25e8f", "0xcc0dd5427fbf83b024966F88785988358a65A1A7", "0xDE0CDf2151AB58fA7E672E6B12315E472F6cbBf3", "0x62923707f8d307b3B4fb68175A796CA944a1A02A", "0x4eee395f3aEF457950806dd2fa4a4d44194FbAC7", "0xBDa403944400c2D857da706007E6EB4D183B9523", "0xb49b145D6384BAa7Bcb1226484ee0f776ae5d344", "0xbE2B28F870336B4eAA0aCc73cE02757fcC428dC9", "0x3295df41A2F288Da03818aE32565E1599f1B2Eee", "0xF22F00D0B95B1b728078066E5f4410F6B2Be8faE", "0xf70F772e6f452BF7f7C2645F4fbe0856c716aD51", "0xa44872579a0c406c604345a3640ECa2190133CF7", "0xa4e7E0dcA4393cbfefb91d4094530dBc0bDa1Fbc", "0x60E6F3bedb855c935b64b706dCfB976D8c53c81E", "0x8fD30d792D7BFb8955D7CfBfA1cCc878b04a39ec", "0x37C7bA963Abd135beD62C190980E0F6C972f4A00", "0x1c753a21062d40480e4B04638F4c9fE6B4EACe38", "0x21316E6A4F0Af45E5F1503984E83B10C53b177D8", "0xafBCC39f474baf9596C1135522810d5f409DDE0F"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_interfaceId", type: "bytes4"}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "getApproved", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_operator", type: "address"}, {name: "_role", type: "string"}], name: "checkRole", outputs: [], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ROLE_WHITELISTED", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "InterfaceId_ERC165", outputs: [{name: "", type: "bytes4"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_operator", type: "address"}, {name: "_role", type: "string"}], name: "hasRole", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_index", type: "uint256"}], name: "tokenOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokenIdPointer", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "nfcIdOf", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokenBaseURI", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "exists", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_index", type: "uint256"}], name: "tokenByIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "tokensOf", outputs: [{name: "_tokenIds", type: "uint256[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_nfcId", type: "bytes32"}], name: "nfcDetails", outputs: [{name: "tokenId", type: "uint256"}, {name: "nfcId", type: "bytes32"}, {name: "tokenUri", type: "string"}, {name: "dob", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "ownerOf", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_operator", type: "address"}], name: "whitelist", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_nfcId", type: "bytes32"}], name: "tokenOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "tokenURI", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_operator", type: "address"}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "birthDateOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "tokenDetails", outputs: [{name: "tokenId", type: "uint256"}, {name: "nfcId", type: "bytes32"}, {name: "tokenUri", type: "string"}, {name: "dob", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "operator", type: "address"}, {indexed: false, name: "role", type: "string"}], name: "RoleAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "operator", type: "address"}, {indexed: false, name: "role", type: "string"}], name: "RoleRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_approved", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_operator", type: "address"}, {indexed: false, name: "_approved", type: "bool"}], name: "ApprovalForAll", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["RoleAdded(address,string)", "RoleRemoved(address,string)", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)", "ApprovalForAll(address,address,bool)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xbfec83d64eaa953f2708271a023ab9ee82057f8f3578d548c1a4ba0b5b700489", "0xd211483f91fc6eff862467f8de606587a30c8fc9981056f051b897a418df803a", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0x17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6802211 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6856528 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "CryptoKaiju", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "bytes4", name: "_interfaceId", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "supportsInterface(bytes4)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "getApproved", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getApproved(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "string", name: "_role", value: random.string( maxRandom )}], name: "checkRole", outputs: [], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkRole(address,string)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ROLE_WHITELISTED", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ROLE_WHITELISTED()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "InterfaceId_ERC165", outputs: [{name: "", type: "bytes4"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "InterfaceId_ERC165()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "string", name: "_role", value: random.string( maxRandom )}], name: "hasRole", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "hasRole(address,string)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_index", value: random.range( maxRandom )}], name: "tokenOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenOfOwnerByIndex(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokenIdPointer", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenIdPointer()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "nfcIdOf", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nfcIdOf(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokenBaseURI", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenBaseURI()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "exists", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "exists(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_index", value: random.range( maxRandom )}], name: "tokenByIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenByIndex(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "tokensOf", outputs: [{name: "_tokenIds", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "_nfcId", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "nfcDetails", outputs: [{name: "tokenId", type: "uint256"}, {name: "nfcId", type: "bytes32"}, {name: "tokenUri", type: "string"}, {name: "dob", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nfcDetails(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "ownerOf", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerOf(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "whitelist", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whitelist(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "_nfcId", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "tokenOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenOf(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "tokenURI", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenURI(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isApprovedForAll(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "birthDateOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "birthDateOf(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "tokenDetails", outputs: [{name: "tokenId", type: "uint256"}, {name: "nfcId", type: "bytes32"}, {name: "tokenUri", type: "string"}, {name: "dob", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenDetails(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "CryptoKaiju", function( accounts ) {

	it( "TEST: CryptoKaiju(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6802211", timeStamp: "1543606789", hash: "0xad608b456af52a959f471e283f55be9c4b8339ecca7652841bf8cdb77bc7257f", nonce: "913", blockHash: "0x9106025e8eeaa247848bcc43757838399d01f367514a9c89032a133889b327e2", transactionIndex: "43", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: 0, value: "0", gas: "2920481", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x30c059ee", contractAddress: "0x102c527714ab7e652630cac7a30abb482b041fd0", cumulativeGasUsed: "6619791", gasUsed: "2920481", confirmations: "898640"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "CryptoKaiju", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = CryptoKaiju.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1543606789 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = CryptoKaiju.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "operator", type: "address"}, {indexed: false, name: "role", type: "string"}], name: "RoleAdded", type: "event"} ;
		console.error( "eventCallOriginal[0,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoleAdded", events: [{name: "operator", type: "address", value: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4"}, {name: "role", type: "string", value: "whitelist"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[0,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1834188307862314066" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: addAddressToWhitelist( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6802236", timeStamp: "1543607174", hash: "0xcda2fe786647795f3be352a5cd0ba991afd2f4079948c1eb440f9cf27d8b2785", nonce: "914", blockHash: "0xe86556a860b598f99b1d63ef2daf76e453cf9e93b2148f49131bbcd37e7b4d14", transactionIndex: "94", from: "0x3f8c962eb167ad2f80c72b5f933511ccdf0719d4", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "46963", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x7b9417c80000000000000000000000007205a1b9c5cf6494ba2ceb5adcca831c05536912", contractAddress: "", cumulativeGasUsed: "7610471", gasUsed: "46963", confirmations: "898615"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_operator", value: addressList[4]}], name: "addAddressToWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addAddressToWhitelist(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1543607174 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "operator", type: "address"}, {indexed: false, name: "role", type: "string"}], name: "RoleAdded", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "RoleAdded", events: [{name: "operator", type: "address", value: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912"}, {name: "role", type: "string", value: "whitelist"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1834188307862314066" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[4], \"0x30343235343641414532... )", async function( ) {
		const txOriginal = {blockNumber: "6805971", timeStamp: "1543660947", hash: "0xa0465dcd627cbd9af05eb7e4a5430039593a1891aa90359d0020052fce2822de", nonce: "2", blockHash: "0x2e811932465fc7973247a7aadec2cf85d3bbbd4b817f27ffcc6e6d682c613937", transactionIndex: "101", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "392028", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af00000000000000000000000007205a1b9c5cf6494ba2ceb5adcca831c055369123034323534364141453235363830000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000495eaa80000000000000000000000000000000000000000000000000000000000000002e516d5032637771396d757554747a544b4675424e3678525279675664667932703132347572506e31645138433977000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6682144", gasUsed: "261352", confirmations: "894880"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[4]}, {type: "bytes32", name: "nfcId", value: "0x3034323534364141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmP2cwq9muuTtzTKFuBN6xRRygVdfy2p124urPn1dQ8C9w`}, {type: "uint256", name: "birthDate", value: "1230940800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[4], "0x3034323534364141453235363830000000000000000000000000000000000000", `QmP2cwq9muuTtzTKFuBN6xRRygVdfy2p124urPn1dQ8C9w`, "1230940800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1543660947 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912"}, {name: "_tokenId", type: "uint256", value: "0"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[2,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[5], \"0x30343044343441414532... )", async function( ) {
		const txOriginal = {blockNumber: "6807247", timeStamp: "1543679413", hash: "0x4db2723d12cf63a6b01444b7a7bae7cf24f83d1935c9904563da5711abc91530", nonce: "3", blockHash: "0x0eeb94edb37489359c8e30aa4fe022cb4d8c829c96b11df8f7a8753a62e164ea", transactionIndex: "83", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000030602250c5f1fcba5407e99b1dfaab992ea4ffd230343044343441414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000004bf71070000000000000000000000000000000000000000000000000000000000000002e516d6433454a474d366d623458457363565178397065614e317855514a48655141353931727a4d466e375274555a000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3468117", gasUsed: "291352", confirmations: "893604"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[5]}, {type: "bytes32", name: "nfcId", value: "0x3034304434344141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `Qmd3EJGM6mb4XEscVQx9peaN1xUQJHeQA591rzMFn7RtUZ`}, {type: "uint256", name: "birthDate", value: "1274482800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[5], "0x3034304434344141453235363830000000000000000000000000000000000000", `Qmd3EJGM6mb4XEscVQx9peaN1xUQJHeQA591rzMFn7RtUZ`, "1274482800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1543679413 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x30602250c5f1fcba5407e99b1dfaab992ea4ffd2"}, {name: "_tokenId", type: "uint256", value: "1"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[3,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[6], \"0x30343342343341414532... )", async function( ) {
		const txOriginal = {blockNumber: "6807526", timeStamp: "1543683447", hash: "0x74594f930a6757e8d730700f64b1bd4be86ed30819616be34f3eea8da3e825a9", nonce: "4", blockHash: "0xbf2ac120438e4403378389263fe7a1538571b39e96a9bf4a1ac2749fe009dcf8", transactionIndex: "15", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "439716", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af00000000000000000000000008b104344f397afc33ee55c743a0fbd7d956201cd30343342343341414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080ffffffffffffffffffffffffffffffffffffffffffffffffffffffffe64d54f0000000000000000000000000000000000000000000000000000000000000002e516d515a455555446f78574e476b62367348426e707a35574a376a3362737a6b6e624145784b6b7a6d3579676779000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1072635", gasUsed: "293144", confirmations: "893325"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[6]}, {type: "bytes32", name: "nfcId", value: "0x3034334234334141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmQZEUUDoxWNGkb6sHBnpz5WJ7j3bszknbAExKkzm5yggy`}, {type: "uint256", name: "birthDate", value: "115792089237316195423570985008687907853269984665640564039457584007912698500336"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[6], "0x3034334234334141453235363830000000000000000000000000000000000000", `QmQZEUUDoxWNGkb6sHBnpz5WJ7j3bszknbAExKkzm5yggy`, "115792089237316195423570985008687907853269984665640564039457584007912698500336", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543683447 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x8b104344f397afc33ee55c743a0fbd7d956201cd"}, {name: "_tokenId", type: "uint256", value: "2"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[4,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[7], \"0x30343336343241414532... )", async function( ) {
		const txOriginal = {blockNumber: "6807885", timeStamp: "1543688698", hash: "0xa77aee0f3886e37d8c138a53da3bd1181e3f226b5f4f3621abb56222cc837a08", nonce: "5", blockHash: "0x39383391c8df90d19c5fa6e9096bd2ed742fff1bb0369c4b55928d68d9dbe97d", transactionIndex: "20", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436932", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af00000000000000000000000008fb52f1d21717d0cbf003b4ad891aeb73bda929c30343336343241414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005af37d70000000000000000000000000000000000000000000000000000000000000002e516d63587433527074616f754a6d385a517150523865316b487763734254786e76506264453756364a6677537531000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3967243", gasUsed: "291288", confirmations: "892966"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[7]}, {type: "bytes32", name: "nfcId", value: "0x3034333634324141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmcXt3RptaouJm8ZQqPR8e1kHwcsBTxnvPbdE7V6JfwSu1`}, {type: "uint256", name: "birthDate", value: "1525906800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[7], "0x3034333634324141453235363830000000000000000000000000000000000000", `QmcXt3RptaouJm8ZQqPR8e1kHwcsBTxnvPbdE7V6JfwSu1`, "1525906800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1543688698 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x8fb52f1d21717d0cbf003b4ad891aeb73bda929c"}, {name: "_tokenId", type: "uint256", value: "3"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[5,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[8], \"0x30343241343241414532... )", async function( ) {
		const txOriginal = {blockNumber: "6812431", timeStamp: "1543753933", hash: "0x70599374cf90e774d25494b4cce6f9a4df58cf1d825fd07ce724f35274efcd6e", nonce: "6", blockHash: "0x7079ee24362c4645edd1563949063a2f9318f342194f99fe51eff9aa8c51b68f", transactionIndex: "57", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436932", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000075932b377d37b1374cbc138b3033f09b3f5f341c30343241343241414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005a989400000000000000000000000000000000000000000000000000000000000000002e516d577767736a4a4d537533575a736a324c746b616956706843635154557241636b6a7843386e387a6d4a505473000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3327836", gasUsed: "291288", confirmations: "888420"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[8]}, {type: "bytes32", name: "nfcId", value: "0x3034324134324141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmWwgsjJMSu3WZsj2LtkaiVphCcQTUrAckjxC8n8zmJPTs`}, {type: "uint256", name: "birthDate", value: "1519948800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[8], "0x3034324134324141453235363830000000000000000000000000000000000000", `QmWwgsjJMSu3WZsj2LtkaiVphCcQTUrAckjxC8n8zmJPTs`, "1519948800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1543753933 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x75932b377d37b1374cbc138b3033f09b3f5f341c"}, {name: "_tokenId", type: "uint256", value: "4"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[6,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[9], \"0x30343234343241414532... )", async function( ) {
		const txOriginal = {blockNumber: "6812505", timeStamp: "1543755157", hash: "0xae51ac472506816415619e4720735d7f9d04b4292b9a0b04f24bbbcf183053e3", nonce: "7", blockHash: "0xbe40f609e9707b740ccc8027b3ab023d894582179d8c21995909bf40118a7bc8", transactionIndex: "5", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436918", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000070e2b2d55e28be65dbdcb2ac5c498de51c64e828303432343432414145323536383000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000056525700000000000000000000000000000000000000000000000000000000000000002e516d6455646f6f32545a566564705a65647232645a36773472543378795a78356b38513956584535334265615365000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "458665", gasUsed: "291288", confirmations: "888346"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[9]}, {type: "bytes32", name: "nfcId", value: "0x3034323434324141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmdUdoo2TZVedpZedr2dZ6w4rT3xyZx5k8Q9VXE53BeaSe`}, {type: "uint256", name: "birthDate", value: "1448236800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[9], "0x3034323434324141453235363830000000000000000000000000000000000000", `QmdUdoo2TZVedpZedr2dZ6w4rT3xyZx5k8Q9VXE53BeaSe`, "1448236800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543755157 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x70e2b2d55e28be65dbdcb2ac5c498de51c64e828"}, {name: "_tokenId", type: "uint256", value: "5"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[9], \"0x30343145343241414532... )", async function( ) {
		const txOriginal = {blockNumber: "6812561", timeStamp: "1543755883", hash: "0xff1332d99c46bf9792c3f9df053b6397efda4dafad8cd40e052ec160bda234b7", nonce: "8", blockHash: "0x9391a0cee657853313df99b28d6e947a81c7d86c523399624368183527679053", transactionIndex: "58", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "414432", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000070e2b2d55e28be65dbdcb2ac5c498de51c64e82830343145343241414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005bff2c00000000000000000000000000000000000000000000000000000000000000002e516d654b51624c797170396e78426b51616a7a4c794747746237367961416b5a4a57454a664873754c646f56314c000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4347514", gasUsed: "276288", confirmations: "888290"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[9]}, {type: "bytes32", name: "nfcId", value: "0x3034314534324141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmeKQbLyqp9nxBkQajzLyGGtb76yaAkZJWEJfHsuLdoV1L`}, {type: "uint256", name: "birthDate", value: "1543449600"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[9], "0x3034314534324141453235363830000000000000000000000000000000000000", `QmeKQbLyqp9nxBkQajzLyGGtb76yaAkZJWEJfHsuLdoV1L`, "1543449600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1543755883 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x70e2b2d55e28be65dbdcb2ac5c498de51c64e828"}, {name: "_tokenId", type: "uint256", value: "6"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[8,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[10], \"0x3034313934324141453... )", async function( ) {
		const txOriginal = {blockNumber: "6812599", timeStamp: "1543756546", hash: "0x7f38b15016f5d799920304052af5335350e99c29d8ab09620291deda374aac59", nonce: "9", blockHash: "0xe62e31e33a6e898c0fc9fc61f35d004719dea212086800aa0146fefeccc24d66", transactionIndex: "62", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000c0d95fbb7bf19c7665a1c4042b683182b34e215030343139343241414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005317ba80000000000000000000000000000000000000000000000000000000000000002e516d6137355937744a664b7957625962705a647574523733366647775a544239426f67503772345659453952597a000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2903656", gasUsed: "291352", confirmations: "888252"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[10]}, {type: "bytes32", name: "nfcId", value: "0x3034313934324141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `Qma75Y7tJfKyWbYbpZdutR736fGwZTB9BogP7r4VYE9RYz`}, {type: "uint256", name: "birthDate", value: "1394064000"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[10], "0x3034313934324141453235363830000000000000000000000000000000000000", `Qma75Y7tJfKyWbYbpZdutR736fGwZTB9BogP7r4VYE9RYz`, "1394064000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543756546 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xc0d95fbb7bf19c7665a1c4042b683182b34e2150"}, {name: "_tokenId", type: "uint256", value: "7"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[9,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[10], \"0x3034313334324141453... )", async function( ) {
		const txOriginal = {blockNumber: "6813397", timeStamp: "1543767719", hash: "0x15ac4ce80013749b4c0bc2d01e5c9dc856df565b68b672930bccc06dd3e76927", nonce: "10", blockHash: "0x8b04d4fdb197129db5cdfcea9bc7342e0ff3caf82e3ffc13f66b8808b315b4f7", transactionIndex: "102", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "414528", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000c0d95fbb7bf19c7665a1c4042b683182b34e215030343133343241414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005c032080000000000000000000000000000000000000000000000000000000000000002e516d57757a7234614b566d7a797265663478764d73393141686958746a6e3934384c7a6937714e78686a326f5959000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5460916", gasUsed: "276352", confirmations: "887454"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[10]}, {type: "bytes32", name: "nfcId", value: "0x3034313334324141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmWuzr4aKVmzyref4xvMs91AhiXtjn948Lzi7qNxhj2oYY`}, {type: "uint256", name: "birthDate", value: "1543708800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[10], "0x3034313334324141453235363830000000000000000000000000000000000000", `QmWuzr4aKVmzyref4xvMs91AhiXtjn948Lzi7qNxhj2oYY`, "1543708800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1543767719 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xc0d95fbb7bf19c7665a1c4042b683182b34e2150"}, {name: "_tokenId", type: "uint256", value: "8"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[11], \"0x3034304434324141453... )", async function( ) {
		const txOriginal = {blockNumber: "6813544", timeStamp: "1543769853", hash: "0xa2cf78e54cbaa9c38032f94f912bc3ce53cb3ed5f032f1f302a0a22d84e817d1", nonce: "11", blockHash: "0xc39e912fd7914a9f554922594dd2fbcae15319d6c977ad2ae4a1e3b17f9842d7", transactionIndex: "98", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000ed607ba16f6ac5afbff9ad9b8c02deba2207cbc030343044343241414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005abc1e70000000000000000000000000000000000000000000000000000000000000002e516d63344e69394d7a47754a5a5750375343656b7a6972315041645a4e6377707441316372557079575133475a6b000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7548303", gasUsed: "291352", confirmations: "887307"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[11]}, {type: "bytes32", name: "nfcId", value: "0x3034304434324141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `Qmc4Ni9MzGuJZWP7SCekzir1PAdZNcwptA1crUpyWQ3GZk`}, {type: "uint256", name: "birthDate", value: "1522278000"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[11], "0x3034304434324141453235363830000000000000000000000000000000000000", `Qmc4Ni9MzGuJZWP7SCekzir1PAdZNcwptA1crUpyWQ3GZk`, "1522278000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1543769853 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xed607ba16f6ac5afbff9ad9b8c02deba2207cbc0"}, {name: "_tokenId", type: "uint256", value: "9"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[12], \"0x3034303734324141453... )", async function( ) {
		const txOriginal = {blockNumber: "6813584", timeStamp: "1543770492", hash: "0xe425a5c0f7efb20f3ab70d90fa7fba4b27755a3945a2e597ca1bf25a7baab93a", nonce: "12", blockHash: "0xf5f67e0020ced5d2e9d0c18771f0229e33d9f4bdf30acacae5ae4ec33711fbdb", transactionIndex: "6", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000e1023c112a39c58238929153f25364c11a33b72930343037343241414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005a7ce480000000000000000000000000000000000000000000000000000000000000002e516d52457a484a6333516b7648506246655352434778624e59786f4e4c475a4e4d56746455326770445454323869000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7011025", gasUsed: "291352", confirmations: "887267"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[12]}, {type: "bytes32", name: "nfcId", value: "0x3034303734324141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmREzHJc3QkvHPbFeSRCGxbNYxoNLGZNMVtdU2gpDTT28i`}, {type: "uint256", name: "birthDate", value: "1518134400"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[12], "0x3034303734324141453235363830000000000000000000000000000000000000", `QmREzHJc3QkvHPbFeSRCGxbNYxoNLGZNMVtdU2gpDTT28i`, "1518134400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1543770492 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe1023c112a39c58238929153f25364c11a33b729"}, {name: "_tokenId", type: "uint256", value: "10"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[12,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[12], \"0x3034303434334141453... )", async function( ) {
		const txOriginal = {blockNumber: "6813763", timeStamp: "1543772865", hash: "0x155a94fc1a476ae54dd1aa013bd97d9f516677875ad115dde8a364281ca158ea", nonce: "13", blockHash: "0xecdd2473eca29c5f7e7c92cdf684de4704b67458b210c4ccd1253e258ee467f7", transactionIndex: "53", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "414528", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000e1023c112a39c58238929153f25364c11a33b72930343034343341414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005c032080000000000000000000000000000000000000000000000000000000000000002e516d554d79344b746a6d62415841753248427935514743564e544c3235705753445950754b4663396b6257435955000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3994457", gasUsed: "276352", confirmations: "887088"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[12]}, {type: "bytes32", name: "nfcId", value: "0x3034303434334141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmUMy4KtjmbAXAu2HBy5QGCVNTL25pWSDYPuKFc9kbWCYU`}, {type: "uint256", name: "birthDate", value: "1543708800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[12], "0x3034303434334141453235363830000000000000000000000000000000000000", `QmUMy4KtjmbAXAu2HBy5QGCVNTL25pWSDYPuKFc9kbWCYU`, "1543708800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1543772865 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe1023c112a39c58238929153f25364c11a33b729"}, {name: "_tokenId", type: "uint256", value: "11"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[13], \"0x3034313034334141453... )", async function( ) {
		const txOriginal = {blockNumber: "6818232", timeStamp: "1543836919", hash: "0x2103b57b7a368f56d49e530df7a936a5d7565179d2405c91e1a2de68e2d49565", nonce: "14", blockHash: "0x7ea0505bfe130d7d9ecd2bd42626ff9cf651f94c951fcf61442c16d529eea83b", transactionIndex: "85", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000047efe4d7de3f93eb1f34831876ff605ec6b66a4030343130343341414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005ee55a70000000000000000000000000000000000000000000000000000000000000002e516d514177686472615a6a553251785a546e6f41453142546e315a364a5145427a77344e56585050775769796256000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5969306", gasUsed: "291352", confirmations: "882619"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[13]}, {type: "bytes32", name: "nfcId", value: "0x3034313034334141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmQAwhdraZjU2QxZTnoAE1BTn1Z6JQEBzw4NVXPPwWiybV`}, {type: "uint256", name: "birthDate", value: "1592089200"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[13], "0x3034313034334141453235363830000000000000000000000000000000000000", `QmQAwhdraZjU2QxZTnoAE1BTn1Z6JQEBzw4NVXPPwWiybV`, "1592089200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1543836919 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x47efe4d7de3f93eb1f34831876ff605ec6b66a40"}, {name: "_tokenId", type: "uint256", value: "12"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[14], \"0x3034313734334141453... )", async function( ) {
		const txOriginal = {blockNumber: "6818338", timeStamp: "1543838473", hash: "0x791cc4a94ca1091a60dd1e4339860cdb0fb2ad1b288fea5170b6f6346089dca3", nonce: "15", blockHash: "0xfe6929d4ab598648475c7e0ade399f70b652b31c3e804f2eba7e72fd5df48178", transactionIndex: "104", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436932", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000015840002e49791971e151626f7ab85040f980ecf30343137343341414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000684fcf0000000000000000000000000000000000000000000000000000000000000002e516d51625a7035763550766739564b586b4b6f6a51366e6755686d4a6e596f4c4e526a5956477272475636774a6b000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5032181", gasUsed: "291288", confirmations: "882513"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[14]}, {type: "bytes32", name: "nfcId", value: "0x3034313734334141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmQbZp5v5Pvg9VKXkKojQ6ngUhmJnYoLNRjYVGrrGV6wJk`}, {type: "uint256", name: "birthDate", value: "109378800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[14], "0x3034313734334141453235363830000000000000000000000000000000000000", `QmQbZp5v5Pvg9VKXkKojQ6ngUhmJnYoLNRjYVGrrGV6wJk`, "109378800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1543838473 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x15840002e49791971e151626f7ab85040f980ecf"}, {name: "_tokenId", type: "uint256", value: "13"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[15,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[15], \"0x3034314534334141453... )", async function( ) {
		const txOriginal = {blockNumber: "6818408", timeStamp: "1543839423", hash: "0x2edf6a71caa80184d6e32264e541f7572eb060bf890a0ebc33a5b1e1233bed9d", nonce: "16", blockHash: "0x69a2246d05bed20ba27b9b9e7f49561a108256908c0a45600d4fe437b94fede2", transactionIndex: "75", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000f3b9d698b60fa65c70212eb31ba233193f39b6f030343145343341414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000001ef0a5f0000000000000000000000000000000000000000000000000000000000000002e516d6542745671786637704b667067355143334a3948783838615054523743324c54595456336d3972374b755673000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7106993", gasUsed: "291352", confirmations: "882443"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[15]}, {type: "bytes32", name: "nfcId", value: "0x3034314534334141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmeBtVqxf7pKfpg5QC3J9Hx88aPTR7C2LTYTV3m9r7KuVs`}, {type: "uint256", name: "birthDate", value: "519087600"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[15], "0x3034314534334141453235363830000000000000000000000000000000000000", `QmeBtVqxf7pKfpg5QC3J9Hx88aPTR7C2LTYTV3m9r7KuVs`, "519087600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1543839423 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xf3b9d698b60fa65c70212eb31ba233193f39b6f0"}, {name: "_tokenId", type: "uint256", value: "14"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[16,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[15], \"0x3034314534334141453... )", async function( ) {
		const txOriginal = {blockNumber: "6818411", timeStamp: "1543839451", hash: "0x344a78aa3086a604b9400103242becc24bb60f6a9649a7d858d826a9e0ce07b6", nonce: "17", blockHash: "0x3ae7327c787b17f8378b60e28c4c5bd2bb32569aa4217293748aff3c9db7e4d2", transactionIndex: "63", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0xd4264af0000000000000000000000000f3b9d698b60fa65c70212eb31ba233193f39b6f030343145343341414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000001ef0a5f0000000000000000000000000000000000000000000000000000000000000002e516d64697635394831445968764c3237634c3153724a59765a32587a46704c79436d595a616758686743387a545a000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5543664", gasUsed: "30171", confirmations: "882440"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[15]}, {type: "bytes32", name: "nfcId", value: "0x3034314534334141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `Qmdiv59H1DYhvL27cL1SrJYvZ2XzFpLyCmYZagXhgC8zTZ`}, {type: "uint256", name: "birthDate", value: "519087600"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[15], "0x3034314534334141453235363830000000000000000000000000000000000000", `Qmdiv59H1DYhvL27cL1SrJYvZ2XzFpLyCmYZagXhgC8zTZ`, "519087600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1543839451 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[16], \"0x3034323534334141453... )", async function( ) {
		const txOriginal = {blockNumber: "6827121", timeStamp: "1543962849", hash: "0x12191885992017a975fd66067a5ed6085ba6375cbab9866cc660712c0f506e1a", nonce: "19", blockHash: "0x6f9c9c8b5aa1b29d880498c87b3e92e42ebfcec2dee552c14e6501cb4e2c5a51", transactionIndex: "24", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436932", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000044087f09dd5d836af4f15b14533712a9b4486c46303432353433414145323536383000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000014370000000000000000000000000000000000000000000000000000000000000002e516d543764747a3173627169425172715634716d35626d36794d563943587547526b6b4b7a4d69546b71636b6439000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1961441", gasUsed: "291288", confirmations: "873730"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[16]}, {type: "bytes32", name: "nfcId", value: "0x3034323534334141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmT7dtz1sbqiBQrqV4qm5bm6yMV9CXuGRkkKzMiTkqckd9`}, {type: "uint256", name: "birthDate", value: "82800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[16], "0x3034323534334141453235363830000000000000000000000000000000000000", `QmT7dtz1sbqiBQrqV4qm5bm6yMV9CXuGRkkKzMiTkqckd9`, "82800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1543962849 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x44087f09dd5d836af4f15b14533712a9b4486c46"}, {name: "_tokenId", type: "uint256", value: "15"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[17], \"0x3034324334334141453... )", async function( ) {
		const txOriginal = {blockNumber: "6832822", timeStamp: "1544045179", hash: "0xb0121e9420e8dbdc895ffdcf83c2d5a16f95d34bdbe6d99d76f9c8dbcffc8754", nonce: "20", blockHash: "0x6af9db8d8555209b13e43cce03b689bb2eb5f5b9c02293d48c2d35bac8cff06c", transactionIndex: "76", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000f0b7ed3e7ec150af6b26c204e08004e43fad8b2530343243343341414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005afa14f0000000000000000000000000000000000000000000000000000000000000002e516d513867314b38575a486661504771327242537238636f71545572463346774b79657a744b5548427162724546000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4628012", gasUsed: "291352", confirmations: "868029"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[17]}, {type: "bytes32", name: "nfcId", value: "0x3034324334334141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmQ8g1K8WZHfaPGq2rBSr8coqTUrF3FwKyeztKUHBqbrEF`}, {type: "uint256", name: "birthDate", value: "1526338800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[17], "0x3034324334334141453235363830000000000000000000000000000000000000", `QmQ8g1K8WZHfaPGq2rBSr8coqTUrF3FwKyeztKUHBqbrEF`, "1526338800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1544045179 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xf0b7ed3e7ec150af6b26c204e08004e43fad8b25"}, {name: "_tokenId", type: "uint256", value: "16"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[18], \"0x3034333334334141453... )", async function( ) {
		const txOriginal = {blockNumber: "6832844", timeStamp: "1544045560", hash: "0xd794c5acb25994137ba6667f9848dd515d5738d2ea1558e9fae2efbedb1c7986", nonce: "21", blockHash: "0x786df16fb2a9d6f0e0eecd4632e1f12f5a20413f4bfcc9383eed916954aa9b40", transactionIndex: "61", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436932", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000dc6799b46a625ac55e944835f7634768a0bfcf6a30343333343341414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005c071500000000000000000000000000000000000000000000000000000000000000002e516d53515075654469654a5a36656747784147457759725764734266737745576d6e4e62644363345a4668747864000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7106031", gasUsed: "291288", confirmations: "868007"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[18]}, {type: "bytes32", name: "nfcId", value: "0x3034333334334141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmSQPueDieJZ6egGxAGEwYrWdsBfswEWmnNbdCc4ZFhtxd`}, {type: "uint256", name: "birthDate", value: "1543968000"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[18], "0x3034333334334141453235363830000000000000000000000000000000000000", `QmSQPueDieJZ6egGxAGEwYrWdsBfswEWmnNbdCc4ZFhtxd`, "1543968000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1544045560 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xdc6799b46a625ac55e944835f7634768a0bfcf6a"}, {name: "_tokenId", type: "uint256", value: "17"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[20,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[19], \"0x3034353234354141453... )", async function( ) {
		const txOriginal = {blockNumber: "6832983", timeStamp: "1544047541", hash: "0x63e2e90a54c8d015e7ba820d094cf08f2ccaff071dc101dcb4d4e2fc34de29e8", nonce: "23", blockHash: "0xc3c381599fabac6f0ab60201398338cc23929b8bf8c43edcd180fbc64f7c56fb", transactionIndex: "23", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000ed5ce3ef1220d2d863b2d050f15f2a5a59e25e8f3034353234354141453235363830000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000093e7480000000000000000000000000000000000000000000000000000000000000002e516d65633836324a6156466f346e374e674b6f6b324c444e64564e426b41347035764c78514c696f7a7544344a48000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4535126", gasUsed: "291352", confirmations: "867868"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[19]}, {type: "bytes32", name: "nfcId", value: "0x3034353234354141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `Qmec862JaVFo4n7NgKok2LDNdVNBkA4p5vLxQLiozuD4JH`}, {type: "uint256", name: "birthDate", value: "155088000"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[19], "0x3034353234354141453235363830000000000000000000000000000000000000", `Qmec862JaVFo4n7NgKok2LDNdVNBkA4p5vLxQLiozuD4JH`, "155088000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1544047541 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xed5ce3ef1220d2d863b2d050f15f2a5a59e25e8f"}, {name: "_tokenId", type: "uint256", value: "18"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[20], \"0x3034344334354141453... )", async function( ) {
		const txOriginal = {blockNumber: "6833043", timeStamp: "1544048297", hash: "0x6f43c1917d6d0e64bfa976a9e6a1019ff6992e52bbd2aa54e1364617216266c5", nonce: "24", blockHash: "0x1886b1e035a226793f385ef25b70b035cdc04566cbc402e2f47fd2410a214f85", transactionIndex: "23", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436932", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000cc0dd5427fbf83b024966f88785988358a65a1a730343443343541414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005a989400000000000000000000000000000000000000000000000000000000000000002e516d626e384d6b714a59414e39484c31706a59664a4255766a677a6b6863477850506e71416265536f706e386243000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1629998", gasUsed: "291288", confirmations: "867808"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[20]}, {type: "bytes32", name: "nfcId", value: "0x3034344334354141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `Qmbn8MkqJYAN9HL1pjYfJBUvjgzkhcGxPPnqAbeSopn8bC`}, {type: "uint256", name: "birthDate", value: "1519948800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[20], "0x3034344334354141453235363830000000000000000000000000000000000000", `Qmbn8MkqJYAN9HL1pjYfJBUvjgzkhcGxPPnqAbeSopn8bC`, "1519948800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1544048297 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xcc0dd5427fbf83b024966f88785988358a65a1a7"}, {name: "_tokenId", type: "uint256", value: "19"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[9], \"0x30343436343541414532... )", async function( ) {
		const txOriginal = {blockNumber: "6838543", timeStamp: "1544127207", hash: "0x2a131a3811dfc5d8d5fde67fafc9ddbbda95c4194017fab4069714c0f98c537c", nonce: "25", blockHash: "0x19948583813c40b3a9414a4312cd764b2e57a19a95fa398a9c9ac9c752aef0a6", transactionIndex: "22", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "414528", gasPrice: "6500000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000070e2b2d55e28be65dbdcb2ac5c498de51c64e82830343436343541414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005ae10870000000000000000000000000000000000000000000000000000000000000002e516d5963567a7258485779714b33634d76366341384c50396a6332735753546b6a6161444b45473346764c484348000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7501701", gasUsed: "276352", confirmations: "862308"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[9]}, {type: "bytes32", name: "nfcId", value: "0x3034343634354141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmYcVzrXHWyqK3cMv6cA8LP9jc2sWSTkjaaDKEG3FvLHCH`}, {type: "uint256", name: "birthDate", value: "1524697200"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[9], "0x3034343634354141453235363830000000000000000000000000000000000000", `QmYcVzrXHWyqK3cMv6cA8LP9jc2sWSTkjaaDKEG3FvLHCH`, "1524697200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1544127207 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x70e2b2d55e28be65dbdcb2ac5c498de51c64e828"}, {name: "_tokenId", type: "uint256", value: "20"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[9], \"0x30343239343441414532... )", async function( ) {
		const txOriginal = {blockNumber: "6838643", timeStamp: "1544128547", hash: "0xd8ccb8d422fe0fd622485c39ffd1c12fbc30de9871103889dab1ad2490c4c00d", nonce: "26", blockHash: "0x810d3fcae09f209147063820a4b5f0787c208f618c5d65455fc3c4f49522d901", transactionIndex: "16", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "414528", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000070e2b2d55e28be65dbdcb2ac5c498de51c64e82830343239343441414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000b263f80000000000000000000000000000000000000000000000000000000000000002e516d636a71476a6a697a55486a41766f665438446a736453463447736f71473337736e69475659436a4671587259000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7778697", gasUsed: "276352", confirmations: "862208"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[9]}, {type: "bytes32", name: "nfcId", value: "0x3034323934344141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmcjqGjjizUHjAvofT8DjsdSF4GsoqG37sniGVYCjFqXrY`}, {type: "uint256", name: "birthDate", value: "187056000"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[9], "0x3034323934344141453235363830000000000000000000000000000000000000", `QmcjqGjjizUHjAvofT8DjsdSF4GsoqG37sniGVYCjFqXrY`, "187056000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1544128547 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x70e2b2d55e28be65dbdcb2ac5c498de51c64e828"}, {name: "_tokenId", type: "uint256", value: "21"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[24,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[9], \"0x30343337343441453235... )", async function( ) {
		const txOriginal = {blockNumber: "6838651", timeStamp: "1544128679", hash: "0xc423982f8296a6e274689d42db49a0cc99f07d6e61c3b28ebfedbf751601b04a", nonce: "28", blockHash: "0xca027beffd83cca9c22ae6552dc8b51e5ae61c9666ca4b2fc2c499936699711f", transactionIndex: "97", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "414432", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000070e2b2d55e28be65dbdcb2ac5c498de51c64e82830343337343441453235363830000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000001ef0a5f0000000000000000000000000000000000000000000000000000000000000002e516d635758557250386945486e55326764476e51596f7a7a727545385a507839466a4d503750617839363356794b000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7565052", gasUsed: "276288", confirmations: "862200"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[9]}, {type: "bytes32", name: "nfcId", value: "0x3034333734344145323536383000000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmcWXUrP8iEHnU2gdGnQYozzruE8ZPx9FjMP7Pax963VyK`}, {type: "uint256", name: "birthDate", value: "519087600"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[9], "0x3034333734344145323536383000000000000000000000000000000000000000", `QmcWXUrP8iEHnU2gdGnQYozzruE8ZPx9FjMP7Pax963VyK`, "519087600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1544128679 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x70e2b2d55e28be65dbdcb2ac5c498de51c64e828"}, {name: "_tokenId", type: "uint256", value: "22"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[9], \"0x30343144343441414532... )", async function( ) {
		const txOriginal = {blockNumber: "6838743", timeStamp: "1544130222", hash: "0x249b4260dd5be7b1ff5339dc7f4b93eca0dd0532ff06d340c7f0a70fbdbf705c", nonce: "29", blockHash: "0x79a006207cf5fa89649f432e9d84c58bb2bd8aa73f35550549d8f8354512ae5d", transactionIndex: "34", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "414528", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000070e2b2d55e28be65dbdcb2ac5c498de51c64e82830343144343441414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005c086680000000000000000000000000000000000000000000000000000000000000002e516d65516745396e59726547473757365432457269793441434854634153627a356f386336526754414459675845000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7529510", gasUsed: "276352", confirmations: "862108"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[9]}, {type: "bytes32", name: "nfcId", value: "0x3034314434344141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmeQgE9nYreGG7W6T2Eriy4ACHTcASbz5o8c6RgTADYgXE`}, {type: "uint256", name: "birthDate", value: "1544054400"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[9], "0x3034314434344141453235363830000000000000000000000000000000000000", `QmeQgE9nYreGG7W6T2Eriy4ACHTcASbz5o8c6RgTADYgXE`, "1544054400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1544130222 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x70e2b2d55e28be65dbdcb2ac5c498de51c64e828"}, {name: "_tokenId", type: "uint256", value: "23"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[9], \"0x30343438343641414532... )", async function( ) {
		const txOriginal = {blockNumber: "6838757", timeStamp: "1544130425", hash: "0xf3e0f2eaf8114548b214b166875b34373192022b471d342853e8d0a741e32373", nonce: "30", blockHash: "0x203feb75236e8d8bf0c015279af0d0f8130f6cc1c4d05223bb0fc1cecfb15525", transactionIndex: "69", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "414528", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000070e2b2d55e28be65dbdcb2ac5c498de51c64e82830343438343641414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005c086680000000000000000000000000000000000000000000000000000000000000002e516d6531644c69686a4643336a4b78634669724e613138694164726a75717879466843676544454755777757734d000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7620456", gasUsed: "276352", confirmations: "862094"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[9]}, {type: "bytes32", name: "nfcId", value: "0x3034343834364141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `Qme1dLihjFC3jKxcFirNa18iAdrjuqxyFhCgeDEGUwwWsM`}, {type: "uint256", name: "birthDate", value: "1544054400"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[9], "0x3034343834364141453235363830000000000000000000000000000000000000", `Qme1dLihjFC3jKxcFirNa18iAdrjuqxyFhCgeDEGUwwWsM`, "1544054400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1544130425 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x70e2b2d55e28be65dbdcb2ac5c498de51c64e828"}, {name: "_tokenId", type: "uint256", value: "24"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: burn( \"22\" )", async function( ) {
		const txOriginal = {blockNumber: "6838757", timeStamp: "1544130425", hash: "0x45bb177ad2ea3201522042a14fb94b7d3c8fa83591ed4c3aee9969aeb0955c78", nonce: "31", blockHash: "0x203feb75236e8d8bf0c015279af0d0f8130f6cc1c4d05223bb0fc1cecfb15525", transactionIndex: "70", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "239299", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x42966c680000000000000000000000000000000000000000000000000000000000000016", contractAddress: "", cumulativeGasUsed: "7685216", gasUsed: "64760", confirmations: "862094"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "tokenId", value: "22"}], name: "burn", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "burn(uint256)" ]( "22", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1544130425 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x70e2b2d55e28be65dbdcb2ac5c498de51c64e828"}, {name: "_to", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_tokenId", type: "uint256", value: "22"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[28,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[9], \"0x30343337343441414532... )", async function( ) {
		const txOriginal = {blockNumber: "6838788", timeStamp: "1544130935", hash: "0xb84511646120ef26dc12b3a51621c63b8f447e99a526c73bcb8065fa124d667f", nonce: "32", blockHash: "0xa348b115978079855c99f2d1cfa7e899d53f7b173968aa57f5e5f24e6347c28f", transactionIndex: "188", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "414528", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000070e2b2d55e28be65dbdcb2ac5c498de51c64e82830343337343441414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000001ef0a5f0000000000000000000000000000000000000000000000000000000000000002e516d62716a6f697a447447506f4d3550523875544d44776357473566756672796e6e546f79547a377054695a3479000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7102030", gasUsed: "276352", confirmations: "862063"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[9]}, {type: "bytes32", name: "nfcId", value: "0x3034333734344141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmbqjoizDtGPoM5PR8uTMDwcWG5fufrynnToyTz7pTiZ4y`}, {type: "uint256", name: "birthDate", value: "519087600"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[9], "0x3034333734344141453235363830000000000000000000000000000000000000", `QmbqjoizDtGPoM5PR8uTMDwcWG5fufrynnToyTz7pTiZ4y`, "519087600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1544130935 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x70e2b2d55e28be65dbdcb2ac5c498de51c64e828"}, {name: "_tokenId", type: "uint256", value: "25"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[9], \"0x30343345343541414532... )", async function( ) {
		const txOriginal = {blockNumber: "6838831", timeStamp: "1544131569", hash: "0x9acf3a817c708f1a2122e10f762750ca8ec4401ba19c0437e1c425ea6136a26b", nonce: "33", blockHash: "0x4c1c1b31bd7e78b09ba5f2a4fa8df4c60b243f08c014d85c01939ee76bff5434", transactionIndex: "62", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "414432", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000070e2b2d55e28be65dbdcb2ac5c498de51c64e82830343345343541414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000002b1d4e00000000000000000000000000000000000000000000000000000000000000002e516d565650656239653971595955506d6b345068393851424e4c426933734263734354537459675a656839546b35000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7843059", gasUsed: "276288", confirmations: "862020"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[9]}, {type: "bytes32", name: "nfcId", value: "0x3034334534354141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmVVPeb9e9qYYUPmk4Ph98QBNLBi3sBcsCTStYgZeh9Tk5`}, {type: "uint256", name: "birthDate", value: "723340800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[9], "0x3034334534354141453235363830000000000000000000000000000000000000", `QmVVPeb9e9qYYUPmk4Ph98QBNLBi3sBcsCTStYgZeh9Tk5`, "723340800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1544131569 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x70e2b2d55e28be65dbdcb2ac5c498de51c64e828"}, {name: "_tokenId", type: "uint256", value: "26"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[30,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[21], \"0x3034343234364141453... )", async function( ) {
		const txOriginal = {blockNumber: "6849326", timeStamp: "1544282768", hash: "0x101e3df96ad990d39ae8d7a68d8d99f67b4ca88af6817db25ebd34e31a5a48b9", nonce: "34", blockHash: "0xbde087411f01d44e45d0d48b61f10de864ccc8d7bd818bf08e46f45bbd8d11ef", transactionIndex: "105", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000de0cdf2151ab58fa7e672e6b12315e472f6cbbf330343432343641414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005c032080000000000000000000000000000000000000000000000000000000000000002e516d62725870354d334153587368556a67576f4e716a316b627178664a54477043415a6242755566786e79777878000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4657361", gasUsed: "291352", confirmations: "851525"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[21]}, {type: "bytes32", name: "nfcId", value: "0x3034343234364141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmbrXp5M3ASXshUjgWoNqj1kbqxfJTGpCAZbBuUfxnywxx`}, {type: "uint256", name: "birthDate", value: "1543708800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[21], "0x3034343234364141453235363830000000000000000000000000000000000000", `QmbrXp5M3ASXshUjgWoNqj1kbqxfJTGpCAZbBuUfxnywxx`, "1543708800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1544282768 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xde0cdf2151ab58fa7e672e6b12315e472f6cbbf3"}, {name: "_tokenId", type: "uint256", value: "27"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[31,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[22], \"0x3034313734344141453... )", async function( ) {
		const txOriginal = {blockNumber: "6849399", timeStamp: "1544283874", hash: "0xbaa16514acb1df5aa7f98ace18b66442feb8061c8b4d76ad4dee9b0508117493", nonce: "35", blockHash: "0x604999319d789ad004f6c6f04ff49d28150c4f8d3772da0cb81b2edc3e93c080", transactionIndex: "56", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000062923707f8d307b3b4fb68175a796ca944a1a02a30343137343441414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000002e5e73f0000000000000000000000000000000000000000000000000000000000000002e516d624457743931725145666f73617a73593469347a38536b336d37316d6f684b3839704474526131354a736337000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7115044", gasUsed: "291352", confirmations: "851452"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[22]}, {type: "bytes32", name: "nfcId", value: "0x3034313734344141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmbDWt91rQEfosazsY4i4z8Sk3m71mohK89pDtRa15Jsc7`}, {type: "uint256", name: "birthDate", value: "777942000"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[22], "0x3034313734344141453235363830000000000000000000000000000000000000", `QmbDWt91rQEfosazsY4i4z8Sk3m71mohK89pDtRa15Jsc7`, "777942000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1544283874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x62923707f8d307b3b4fb68175a796ca944a1a02a"}, {name: "_tokenId", type: "uint256", value: "28"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[32,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[23], \"0x3034313134344141453... )", async function( ) {
		const txOriginal = {blockNumber: "6849454", timeStamp: "1544284647", hash: "0x2d5fa7059b3cfe314551d52763c4419257a4d5f38f11e3a8c795cb73dcd964ab", nonce: "36", blockHash: "0xde5066a4dd33aacffdd6ad33dde946b10ba1c74628d0bb44ef0c90a0dbb24237", transactionIndex: "47", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af00000000000000000000000004eee395f3aef457950806dd2fa4a4d44194fbac73034313134344141453235363830000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000366dbd80000000000000000000000000000000000000000000000000000000000000002e516d56734a77726d313459676e7343445756573636337074674a56473444343838596363793374376a5353336832000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3391767", gasUsed: "291352", confirmations: "851397"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[23]}, {type: "bytes32", name: "nfcId", value: "0x3034313134344141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmVsJwrm14YgnsCDWVW663ptgJVG4D488Yccy3t7jSS3h2`}, {type: "uint256", name: "birthDate", value: "913161600"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[23], "0x3034313134344141453235363830000000000000000000000000000000000000", `QmVsJwrm14YgnsCDWVW663ptgJVG4D488Yccy3t7jSS3h2`, "913161600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1544284647 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x4eee395f3aef457950806dd2fa4a4d44194fbac7"}, {name: "_tokenId", type: "uint256", value: "29"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[33,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[24], \"0x3034304234344141453... )", async function( ) {
		const txOriginal = {blockNumber: "6849739", timeStamp: "1544288347", hash: "0xe79f25df6430208602e67235768622baf6fb72a65a553e983ff0eac4ca1898bf", nonce: "37", blockHash: "0xb4aa19f47a841f4f396538dc26b7518d93be4e07a38c3234e264114e2790d779", transactionIndex: "42", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436936", gasPrice: "10300000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000bda403944400c2d857da706007e6eb4d183b952330343042343441414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000004fb03cf0000000000000000000000000000000000000000000000000000000000000002e516d656464774e6263435257625277434867645557735779506f7534623634385a586a6a6843486b785036706d56000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1738575", gasUsed: "291288", confirmations: "851112"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[24]}, {type: "bytes32", name: "nfcId", value: "0x3034304234344141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmeddwNbcCRWbRwCHgdUWsWyPou4b648ZXjjhCHkxP6pmV`}, {type: "uint256", name: "birthDate", value: "1336950000"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[24], "0x3034304234344141453235363830000000000000000000000000000000000000", `QmeddwNbcCRWbRwCHgdUWsWyPou4b648ZXjjhCHkxP6pmV`, "1336950000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1544288347 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xbda403944400c2d857da706007e6eb4d183b9523"}, {name: "_tokenId", type: "uint256", value: "30"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[34,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[25], \"0x3034353134364141453... )", async function( ) {
		const txOriginal = {blockNumber: "6849746", timeStamp: "1544288461", hash: "0xcb6b2eff67a4bdbaea80d6550ac66d1bd1e37a6a280d04ff70b03ace9835cb66", nonce: "38", blockHash: "0x8afce94d017b358e4365f14538462574d0b044749b536e5ac9e41c652004fb05", transactionIndex: "64", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000b49b145d6384baa7bcb1226484ee0f776ae5d34430343531343641414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005aca9ef0000000000000000000000000000000000000000000000000000000000000002e516d61537753664c32565875726645573641684b78464d44654d744c5479747a694835445375344a425652735251000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7278779", gasUsed: "291352", confirmations: "851105"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[25]}, {type: "bytes32", name: "nfcId", value: "0x3034353134364141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmaSwSfL2VXurfEW6AhKxFMDeMtLTytziH5DSu4JBVRsRQ`}, {type: "uint256", name: "birthDate", value: "1523228400"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[25], "0x3034353134364141453235363830000000000000000000000000000000000000", `QmaSwSfL2VXurfEW6AhKxFMDeMtLTytziH5DSu4JBVRsRQ`, "1523228400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1544288461 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xb49b145d6384baa7bcb1226484ee0f776ae5d344"}, {name: "_tokenId", type: "uint256", value: "31"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[26], \"0x3034333034344141453... )", async function( ) {
		const txOriginal = {blockNumber: "6849767", timeStamp: "1544288721", hash: "0xb8abbac2dee48bd5bb303a3ea9ae4e443792a498360a2f68bc51452c2a6ea7bd", nonce: "40", blockHash: "0xc4627805fe7af2a8f2458ea5385de8f08c3c6c16387f1948cb5a4185e358fbb6", transactionIndex: "25", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000be2b28f870336b4eaa0acc73ce02757fcc428dc9303433303434414145323536383000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000035241870000000000000000000000000000000000000000000000000000000000000002e516d516d3462735243356b6a38433752425833546b564c584c75766f6b4343326d454e6d59323879515354484745000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1792306", gasUsed: "291352", confirmations: "851084"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[26]}, {type: "bytes32", name: "nfcId", value: "0x3034333034344141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmQm4bsRC5kj8C7RBX3TkVLXLuvokCC2mENmY28yQSTHGE`}, {type: "uint256", name: "birthDate", value: "891558000"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[26], "0x3034333034344141453235363830000000000000000000000000000000000000", `QmQm4bsRC5kj8C7RBX3TkVLXLuvokCC2mENmY28yQSTHGE`, "891558000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1544288721 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xbe2b28f870336b4eaa0acc73ce02757fcc428dc9"}, {name: "_tokenId", type: "uint256", value: "32"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[36,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[27], \"0x3034313234354141453... )", async function( ) {
		const txOriginal = {blockNumber: "6855069", timeStamp: "1544364232", hash: "0xc0d7981434d57c84ee9ac7a513b10cc57f398467d4d21b7f8808d6bd58c4d06a", nonce: "41", blockHash: "0xfe535cf01aa6f2efe68913d450bad3a91c51114460f03ea9b7ae24a798a97c23", transactionIndex: "68", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af00000000000000000000000003295df41a2f288da03818ae32565e1599f1b2eee303431323435414145323536383000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000070dbd880000000000000000000000000000000000000000000000000000000000000002e516d5554633139787a354d4c4b7236576434344e6d346e7a463834504b636d515a79436774425862386456636941000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5319785", gasUsed: "291352", confirmations: "845782"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[27]}, {type: "bytes32", name: "nfcId", value: "0x3034313234354141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmUTc19xz5MLKr6Wd44Nm4nzF84PKcmQZyCgtBXb8dVciA`}, {type: "uint256", name: "birthDate", value: "1893456000"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[27], "0x3034313234354141453235363830000000000000000000000000000000000000", `QmUTc19xz5MLKr6Wd44Nm4nzF84PKcmQZyCgtBXb8dVciA`, "1893456000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1544364232 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x3295df41a2f288da03818ae32565e1599f1b2eee"}, {name: "_tokenId", type: "uint256", value: "33"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[27], \"0x3034313834354141453... )", async function( ) {
		const txOriginal = {blockNumber: "6855091", timeStamp: "1544364555", hash: "0xdcf9d73a62e1504f0bbb779ca4cd7963a8fd7a60aad7b47593b9f531ef7a6014", nonce: "42", blockHash: "0x234458393d22564b32b01b50b9e5eb4ef5bcca87955e113bdb2c4697661bee9a", transactionIndex: "16", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "414528", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af00000000000000000000000003295df41a2f288da03818ae32565e1599f1b2eee30343138343541414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000004c54aaf0000000000000000000000000000000000000000000000000000000000000002e516d4e774b583458575a6a5941556756393278544256377938336f476e7454385465326632754539664655415162000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "738336", gasUsed: "276352", confirmations: "845760"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[27]}, {type: "bytes32", name: "nfcId", value: "0x3034313834354141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmNwKX4XWZjYAUgV92xTBV7y83oGntT8Te2f2uE9fFUAQb`}, {type: "uint256", name: "birthDate", value: "1280617200"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[27], "0x3034313834354141453235363830000000000000000000000000000000000000", `QmNwKX4XWZjYAUgV92xTBV7y83oGntT8Te2f2uE9fFUAQb`, "1280617200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1544364555 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x3295df41a2f288da03818ae32565e1599f1b2eee"}, {name: "_tokenId", type: "uint256", value: "34"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[27], \"0x3034314534354141453... )", async function( ) {
		const txOriginal = {blockNumber: "6855133", timeStamp: "1544365084", hash: "0x503ec8b26db85bac8a0f96aaf519e554c12d24a01c7f2182bd58526cf2b3ab59", nonce: "43", blockHash: "0x19e1276cd04ca886b015cf118ee0730763f89c3fa65d3036b9acbe05efe5f2d2", transactionIndex: "116", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "414528", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af00000000000000000000000003295df41a2f288da03818ae32565e1599f1b2eee303431453435414145323536383000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000012457bf0000000000000000000000000000000000000000000000000000000000000002e516d61676659795434327248526a365545327959566945437a334659415a4e383351374765347735555268644176000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5182035", gasUsed: "276352", confirmations: "845718"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[27]}, {type: "bytes32", name: "nfcId", value: "0x3034314534354141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmagfYyT42rHRj6UE2yYViECz3FYAZN83Q7Ge4w5URhdAv`}, {type: "uint256", name: "birthDate", value: "306543600"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[27], "0x3034314534354141453235363830000000000000000000000000000000000000", `QmagfYyT42rHRj6UE2yYViECz3FYAZN83Q7Ge4w5URhdAv`, "306543600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1544365084 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x3295df41a2f288da03818ae32565e1599f1b2eee"}, {name: "_tokenId", type: "uint256", value: "35"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[39,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[28], \"0x3034323534354141453... )", async function( ) {
		const txOriginal = {blockNumber: "6855177", timeStamp: "1544365722", hash: "0x2eabaa09007ca069da95dce78b7a77cff4986748875554df1e2baaef81550735", nonce: "44", blockHash: "0xdffd594b0064859367a1dd0b5611eaf28e35899a4301e0a0b7301ff97b20eddb", transactionIndex: "101", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436932", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000f22f00d0b95b1b728078066e5f4410f6b2be8fae3034323534354141453235363830000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000684cad70000000000000000000000000000000000000000000000000000000000000002e516d516b53395676356e544559434b54554b636a61396d594655573652585956426e4c5175314d616a756e454274000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5044624", gasUsed: "291288", confirmations: "845674"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[28]}, {type: "bytes32", name: "nfcId", value: "0x3034323534354141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmQkS9Vv5nTEYCKTUKcja9mYFUW6RXYVBnLQu1MajunEBt`}, {type: "uint256", name: "birthDate", value: "1749855600"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[28], "0x3034323534354141453235363830000000000000000000000000000000000000", `QmQkS9Vv5nTEYCKTUKcja9mYFUW6RXYVBnLQu1MajunEBt`, "1749855600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1544365722 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xf22f00d0b95b1b728078066e5f4410f6b2be8fae"}, {name: "_tokenId", type: "uint256", value: "36"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[29], \"0x3034333234354141453... )", async function( ) {
		const txOriginal = {blockNumber: "6855231", timeStamp: "1544366400", hash: "0x97de15013a35617d3566ba2514399ed68978e9ff506d0b1d414ff77ca4c10ee1", nonce: "45", blockHash: "0xbfe6892dd4bbda3cb9ac9c600410d420188c5db7dafc38df84bb04630d2bf019", transactionIndex: "134", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000f70f772e6f452bf7f7c2645f4fbe0856c716ad51303433323435414145323536383000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000012badf80000000000000000000000000000000000000000000000000000000000000002e516d624172345a784d4875794432656d6e6b79347168575a47445150723533356b73625032794e6b73356a697452000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7238921", gasUsed: "291352", confirmations: "845620"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[29]}, {type: "bytes32", name: "nfcId", value: "0x3034333234354141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmbAr4ZxMHuyD2emnky4qhWZGDQPr535ksbP2yNks5jitR`}, {type: "uint256", name: "birthDate", value: "314236800"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[29], "0x3034333234354141453235363830000000000000000000000000000000000000", `QmbAr4ZxMHuyD2emnky4qhWZGDQPr535ksbP2yNks5jitR`, "314236800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1544366400 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xf70f772e6f452bf7f7c2645f4fbe0856c716ad51"}, {name: "_tokenId", type: "uint256", value: "37"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[30], \"0x3034334534364141453... )", async function( ) {
		const txOriginal = {blockNumber: "6855642", timeStamp: "1544372155", hash: "0x808a5d386fef55a63f71e2cbf6ccdf26b1c7128c3aa4dffc611b90a83b259b65", nonce: "46", blockHash: "0x387edd0aa1953a1415cb8a6a7dab268eab3c8f301c964c5c3d82bd8e25cb9d68", transactionIndex: "120", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436932", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000a44872579a0c406c604345a3640eca2190133cf73034334534364141453235363830000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000045600f0000000000000000000000000000000000000000000000000000000000000002e516d645852664e363566596e76337a684c71554d5669343767423646753153644451546a77376b4c58384e457532000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7378179", gasUsed: "291288", confirmations: "845209"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[30]}, {type: "bytes32", name: "nfcId", value: "0x3034334534364141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmdXRfN65fYnv3zhLqUMVi47gB6Fu1SdDQTjw7kLX8NEu2`}, {type: "uint256", name: "birthDate", value: "72745200"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[30], "0x3034334534364141453235363830000000000000000000000000000000000000", `QmdXRfN65fYnv3zhLqUMVi47gB6Fu1SdDQTjw7kLX8NEu2`, "72745200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1544372155 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xa44872579a0c406c604345a3640eca2190133cf7"}, {name: "_tokenId", type: "uint256", value: "38"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[31], \"0x3034343434364141453... )", async function( ) {
		const txOriginal = {blockNumber: "6855707", timeStamp: "1544373307", hash: "0xc75c94c7ac7ac21484afa66b04896d08f4c178b77b0f52e46896ce13eeef868d", nonce: "47", blockHash: "0x295f5b8f0988d9f8befa7eca834f149c36d36042517fbeedc8576ebfe6889fea", transactionIndex: "106", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436932", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000a4e7e0dca4393cbfefb91d4094530dbc0bda1fbc30343434343641414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000969f600000000000000000000000000000000000000000000000000000000000000002e516d51774e6977457066443672544837514b616338436e6e4a5a65486e5066425676776a374b5941525254584541000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5915670", gasUsed: "291288", confirmations: "845144"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[31]}, {type: "bytes32", name: "nfcId", value: "0x3034343434364141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmQwNiwEpfD6rTH7QKac8CnnJZeHnPfBVvwj7KYARRTXEA`}, {type: "uint256", name: "birthDate", value: "157939200"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[31], "0x3034343434364141453235363830000000000000000000000000000000000000", `QmQwNiwEpfD6rTH7QKac8CnnJZeHnPfBVvwj7KYARRTXEA`, "157939200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1544373307 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xa4e7e0dca4393cbfefb91d4094530dbc0bda1fbc"}, {name: "_tokenId", type: "uint256", value: "39"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[43,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[32], \"0x3034344234364141453... )", async function( ) {
		const txOriginal = {blockNumber: "6855767", timeStamp: "1544374117", hash: "0x60cc28032785296524b738e0022d7fefc98a6d778e335251a02e65aed167d928", nonce: "48", blockHash: "0xb3633f6e43a9c433f957db8b3d7214f4798e72b0cca900ff5cf69bc711a0f254", transactionIndex: "64", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000060e6f3bedb855c935b64b706dcfb976d8c53c81e30343442343641414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000005bfdda80000000000000000000000000000000000000000000000000000000000000002e516d56444b624e317137724141314d71517a6a644c58614d6966704334614b504847454d38637744335836346b70000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4792433", gasUsed: "291352", confirmations: "845084"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[32]}, {type: "bytes32", name: "nfcId", value: "0x3034344234364141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmVDKbN1q7rAA1MqQzjdLXaMifpC4aKPHGEM8cwD3X64kp`}, {type: "uint256", name: "birthDate", value: "1543363200"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[32], "0x3034344234364141453235363830000000000000000000000000000000000000", `QmVDKbN1q7rAA1MqQzjdLXaMifpC4aKPHGEM8cwD3X64kp`, "1543363200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1544374117 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x60e6f3bedb855c935b64b706dcfb976d8c53c81e"}, {name: "_tokenId", type: "uint256", value: "40"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[44,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[33], \"0x3034333834364141453... )", async function( ) {
		const txOriginal = {blockNumber: "6855840", timeStamp: "1544375130", hash: "0x6c9ac89efc50ecb756d32c388297e0f14226527c42085b5a0672b3cfe1017f38", nonce: "49", blockHash: "0x6b70546c6726c04794e1366e53eea0ba80d1784339b5e152255d6b99a4e2e04e", transactionIndex: "114", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af00000000000000000000000008fd30d792d7bfb8955d7cfbfa1ccc878b04a39ec30343338343641414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000001ef0a5f0000000000000000000000000000000000000000000000000000000000000002e516d5a7848447576587a786668713171385a317148794a5045466255626345626b716354466e7276504c44344333000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7580687", gasUsed: "291352", confirmations: "845011"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[33]}, {type: "bytes32", name: "nfcId", value: "0x3034333834364141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmZxHDuvXzxfhq1q8Z1qHyJPEFbUbcEbkqcTFnrvPLD4C3`}, {type: "uint256", name: "birthDate", value: "519087600"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[33], "0x3034333834364141453235363830000000000000000000000000000000000000", `QmZxHDuvXzxfhq1q8Z1qHyJPEFbUbcEbkqcTFnrvPLD4C3`, "519087600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1544375130 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x8fd30d792d7bfb8955d7cfbfa1ccc878b04a39ec"}, {name: "_tokenId", type: "uint256", value: "41"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[34], \"0x3034323334354141453... )", async function( ) {
		const txOriginal = {blockNumber: "6856333", timeStamp: "1544382026", hash: "0x5763813c7ded9ce8005c6967760caac08f4ba9294ade46e5340e6bf31a138590", nonce: "50", blockHash: "0x912d53fee1f06d324e902a4bb154dca49e50a281065c9a9ce8a1c72f9d46b62b", transactionIndex: "107", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436932", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000037c7ba963abd135bed62c190980e0f6c972f4a00303432333435414145323536383000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000045e61780000000000000000000000000000000000000000000000000000000000000002e516d534a35344b386f6b53366e584b343363616e4753704c6e59435955785046654142396d58725771475341546d000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5448426", gasUsed: "291288", confirmations: "844518"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[34]}, {type: "bytes32", name: "nfcId", value: "0x3034323334354141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmSJ54K8okS6nXK43canGSpLnYCYUxPFeAB9mXrWqGSATm`}, {type: "uint256", name: "birthDate", value: "1172707200"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[34], "0x3034323334354141453235363830000000000000000000000000000000000000", `QmSJ54K8okS6nXK43canGSpLnYCYUxPFeAB9mXrWqGSATm`, "1172707200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1544382026 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x37c7ba963abd135bed62c190980e0f6c972f4a00"}, {name: "_tokenId", type: "uint256", value: "42"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[35], \"0x3034343734334141453... )", async function( ) {
		const txOriginal = {blockNumber: "6856401", timeStamp: "1544383024", hash: "0x117296bd8f8f5879f8d88dee659dc5fa25d3132f3d665130711fc16585c1644d", nonce: "51", blockHash: "0x3aeacd8d9c205af93710109c64f6de472649ae780122bac414894638cd3aa142", transactionIndex: "21", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436932", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af00000000000000000000000001c753a21062d40480e4b04638f4c9fe6b4eace38303434373433414145323536383000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000053112300000000000000000000000000000000000000000000000000000000000000002e516d4e5757646b4c34526a736467594e4c44734144584861503356656959414e3677715963596e314b514e484a31000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6943937", gasUsed: "291288", confirmations: "844450"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[35]}, {type: "bytes32", name: "nfcId", value: "0x3034343734334141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmNWWdkL4RjsdgYNLDsADXHaP3VeiYAN6wqYcYn1KQNHJ1`}, {type: "uint256", name: "birthDate", value: "1393632000"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[35], "0x3034343734334141453235363830000000000000000000000000000000000000", `QmNWWdkL4RjsdgYNLDsADXHaP3VeiYAN6wqYcYn1KQNHJ1`, "1393632000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544383024 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x1c753a21062d40480e4b04638f4c9fe6b4eace38"}, {name: "_tokenId", type: "uint256", value: "43"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[36], \"0x3034304434334141453... )", async function( ) {
		const txOriginal = {blockNumber: "6856445", timeStamp: "1544383625", hash: "0x1d279b748f409c3e8402ecbcd9232a3cb927c5a2925c90168e1754116c64dd75", nonce: "52", blockHash: "0xa135f939d49d260a3c8157a693148504c9f0b2a3a9a84707594963d9905d4c5d", transactionIndex: "64", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "437028", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af000000000000000000000000021316e6a4f0af45e5f1503984e83b10c53b177d830343044343341414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000001ce3f0f0000000000000000000000000000000000000000000000000000000000000002e516d5735397a627768463932443146334e3541334733764b7359665870656f5735487a5162696a6f344450775071000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5294121", gasUsed: "291352", confirmations: "844406"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[36]}, {type: "bytes32", name: "nfcId", value: "0x3034304434334141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmW59zbwhF92D1F3N5A3G3vKsYfXpeoW5HzQbijo4DPwPq`}, {type: "uint256", name: "birthDate", value: "484700400"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[36], "0x3034304434334141453235363830000000000000000000000000000000000000", `QmW59zbwhF92D1F3N5A3G3vKsYfXpeoW5HzQbijo4DPwPq`, "484700400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1544383625 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x21316e6a4f0af45e5f1503984e83b10c53b177d8"}, {name: "_tokenId", type: "uint256", value: "44"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[48,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: mintTo( addressList[37], \"0x3034353034364141453... )", async function( ) {
		const txOriginal = {blockNumber: "6856528", timeStamp: "1544384636", hash: "0xd29dfa6a742f460baa5f3fca433d44e901e7fd8035bdd8f6c1a05a3ca398ac95", nonce: "53", blockHash: "0xb809582c886c39925a52bc3e2384bd402a7e6fc98c6634b78115f1e10ba056d7", transactionIndex: "45", from: "0x7205a1b9c5cf6494ba2ceb5adcca831c05536912", to: "0x102c527714ab7e652630cac7a30abb482b041fd0", value: "0", gas: "436932", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd4264af0000000000000000000000000afbcc39f474baf9596c1135522810d5f409dde0f30343530343641414532353638300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000587eb00000000000000000000000000000000000000000000000000000000000000002e516d505a686a70706162626b4b414b68457335556a5057427a6a73324e637569524c584669433565415639696736000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4708793", gasUsed: "291288", confirmations: "844323"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[37]}, {type: "bytes32", name: "nfcId", value: "0x3034353034364141453235363830000000000000000000000000000000000000"}, {type: "string", name: "tokenURI", value: `QmPZhjppabbkKAKhEs5UjPWBzjs2NcuiRLXFiC5eAV9ig6`}, {type: "uint256", name: "birthDate", value: "92793600"}], name: "mintTo", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTo(address,bytes32,string,uint256)" ]( addressList[37], "0x3034353034364141453235363830000000000000000000000000000000000000", `QmPZhjppabbkKAKhEs5UjPWBzjs2NcuiRLXFiC5eAV9ig6`, "92793600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544384636 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xafbcc39f474baf9596c1135522810d5f409dde0f"}, {name: "_tokenId", type: "uint256", value: "45"}], address: "0x102c527714ab7e652630cac7a30abb482b041fd0"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "85232961696498476" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
