const Congress = artifacts.require( "./Congress.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Congress" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x97282A7a15f9bEaDC854E8793AAe43B089F14b4e", "0x5F586681E6AAf49b43bC8808B65c4f566249De35", "0x6EFBA8fb2AC5b6730729a972eC224426a287C3Ad", "0x1e5Ac6A2663F1501EeEf5c28b7f49Bb06F2a0951", "0x4af013AfBAdb22D8A88c92D68Fc96B033b9Ebb8a", "0x6cdb5584F22586A1d08b5A91E71Dc0D378D27f3D", "0x3c71D90CC3f19aC14C5E59047bb1EcD6D3527D71", "0x7b52427cec68182C74d0b5f9Dec57ddD8f727DE9", "0xA2772a351e984d0582Ad80a8ba8863489939F6db", "0xbc8d39de02e370A6AaC34c850896ADCFc503d018", "0x32FABADE1D0e05F98c8bBE89e66C40DB040CBE8e", "0xe0D1C0926fd72107b866c1BA5DD2245FCB51EEE7", "0x4203BcE7f488ED0cf55437ad2E5b99AF51Dad07a", "0x399a40838258Af0836cAD506cC58Bf7A40061Ee0", "0x4C3c6F5f2ef44F5E2fFCf6c20b906A91D246c9A2"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "uint256"}], name: "proposals", outputs: [{name: "recipient", type: "address"}, {name: "amount", type: "uint256"}, {name: "description", type: "string"}, {name: "votingDeadline", type: "uint256"}, {name: "executed", type: "bool"}, {name: "proposalPassed", type: "bool"}, {name: "numberOfVotes", type: "uint256"}, {name: "currentResult", type: "int256"}, {name: "proposalHash", type: "bytes32"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "memberId", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "numProposals", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "hammer", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "members", outputs: [{name: "member", type: "address"}, {name: "name", type: "string"}, {name: "memberSince", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "debatingPeriodInMinutes", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "minimumQuorum", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "majorityMargin", outputs: [{name: "", type: "int256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "id", type: "uint256"}, {name: "beneficiary", type: "address"}, {name: "amount", type: "uint256"}, {name: "transactionBytecode", type: "bytes"}], name: "checkProposalCode", outputs: [{name: "codeChecksOut", type: "bool"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "recipient", type: "address"}, {indexed: true, name: "amount", type: "uint256"}, {indexed: false, name: "description", type: "string"}], name: "ProposalAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "quorum", type: "uint256"}, {indexed: true, name: "active", type: "bool"}], name: "ProposalTallied", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "member", type: "address"}, {indexed: true, name: "isMember", type: "bool"}], name: "MembershipChanged", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "minimumQuorum", type: "uint256"}, {indexed: true, name: "debatingPeriodInMinutes", type: "uint256"}, {indexed: true, name: "majorityMargin", type: "int256"}], name: "ChangeOfRules", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "amount", type: "uint256"}], name: "ReceivedEther", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "value", type: "uint256"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "extraData", type: "bytes"}], name: "ReceivedTokens", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["ProposalAdded(uint256,address,uint256,string)", "Voted(uint256,bool,address,string)", "ProposalTallied(uint256,uint256,bool)", "MembershipChanged(address,bool)", "ChangeOfRules(uint256,uint256,int256)", "ReceivedEther(address,uint256)", "ReceivedTokens(address,uint256,address,bytes)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x646fec02522b41e7125cfc859a64fd4f4cefd5dc3b6237ca0abe251ded1fa881", "0xc34f869b7ff431b034b7b9aea9822dac189a685e0b015c7d1be3add3f89128e8", "0xa9ac225c6a5870bf2106e428872d012a51247520cc3af4329905bbb60e28978c", "0x27b022af4a8347100c7a041ce5ccf8e14d644ff05de696315196faae8cd50c9b", "0xa439d3fa452be5e0e1e24a8145e715f4fd8b9c08c96a42fd82a855a85e5d57de", "0xa419615bc8fda4c87663805ee2a3597a6d71c1d476911d9892f340d965bc7bf1", "0xd65b48fd35864b3528d38e44760be5553248f89bf3ff6b06cca57817cc2650bf"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 51 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3687216 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 3721027 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "uint256", name: "minimumQuorumForProposals", value: "0"}, {type: "uint256", name: "minutesForDebate", value: "0"}, {type: "int256", name: "marginOfVotesForMajority", value: "0"}, {type: "address", name: "congressLeader", value: 4}], name: "Congress", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "proposals", outputs: [{name: "recipient", type: "address"}, {name: "amount", type: "uint256"}, {name: "description", type: "string"}, {name: "votingDeadline", type: "uint256"}, {name: "executed", type: "bool"}, {name: "proposalPassed", type: "bool"}, {name: "numberOfVotes", type: "uint256"}, {name: "currentResult", type: "int256"}, {name: "proposalHash", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "proposals(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "memberId", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "memberId(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numProposals", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numProposals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "hammer", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "hammer()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "members", outputs: [{name: "member", type: "address"}, {name: "name", type: "string"}, {name: "memberSince", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "members(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "debatingPeriodInMinutes", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "debatingPeriodInMinutes()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minimumQuorum", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimumQuorum()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "majorityMargin", outputs: [{name: "", type: "int256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "majorityMargin()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "id", value: random.range( maxRandom )}, {type: "address", name: "beneficiary", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "amount", value: random.range( maxRandom )}, {type: "bytes", name: "transactionBytecode", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "checkProposalCode", outputs: [{name: "codeChecksOut", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkProposalCode(uint256,address,uint256,bytes)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value,methodCall.inputs[ 3 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Congress", function( accounts ) {

	it( "TEST: Congress( \"0\", \"0\", \"0\", addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: 3687216, timeStamp: "0x59140667", hash: "0x0233ee95d6b34e3d67b380d0c7d58dca533ce5e3a07ed0b64c3ef3aa60aedbe6", from: "0x5f586681e6aaf49b43bc8808b65c4f566249de35", to: 0, value: "0x0", isError: "0", txreceipt_status: "1", gas: "0x1b9873", input: "0x3b1431840000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006efba8fb2ac5b6730729a972ec224426a287c3ad", contractAddress: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", gasUsed: "0x15d4e7"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0x0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "minimumQuorumForProposals", value: "0"}, {type: "uint256", name: "minutesForDebate", value: "0"}, {type: "int256", name: "marginOfVotesForMajority", value: "0"}, {type: "address", name: "congressLeader", value: addressList[4]}], name: "Congress", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Congress.new( "0", "0", "0", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 0x59140667 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Congress.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "member", type: "address"}, {indexed: true, name: "isMember", type: "bool"}], name: "MembershipChanged", type: "event"} ;
		console.error( "eventCallOriginal[0,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MembershipChanged", events: [{name: "member", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "isMember", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}, {name: "MembershipChanged", events: [{name: "member", type: "address", value: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad"}, {name: "isMember", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[0,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "minimumQuorum", type: "uint256"}, {indexed: true, name: "debatingPeriodInMinutes", type: "uint256"}, {indexed: true, name: "majorityMargin", type: "int256"}], name: "ChangeOfRules", type: "event"} ;
		console.error( "eventCallOriginal[0,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeOfRules", events: [{name: "minimumQuorum", type: "uint256", value: "0"}, {name: "debatingPeriodInMinutes", type: "uint256", value: "0"}, {name: "majorityMargin", type: "int256", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[0,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: addMember( addressList[5], `EvgenRad81` )", async function( ) {
		const txOriginal = {blockNumber: "3687716", timeStamp: "1494492165", hash: "0x2a24706fb0e1dbdb7209196889c8edeaae7eebaeaf81b216c6b3317275a2c7d7", nonce: "97", blockHash: "0x9aa5ee1ced5650a892f9a5d8f298fedafc21cfba565051e5a29434b653b6002e", transactionIndex: "0", from: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "136597", gasPrice: "20861374246", isError: "0", txreceipt_status: "", input: "0xc127c2470000000000000000000000001e5ac6a2663f1501eeef5c28b7f49bb06f2a09510000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000a457667656e526164383100000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "113831", gasUsed: "113831", confirmations: "4064027"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "targetMember", value: addressList[5]}, {type: "string", name: "memberName", value: `EvgenRad81`}], name: "addMember", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addMember(address,string)" ]( addressList[5], `EvgenRad81`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1494492165 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "member", type: "address"}, {indexed: true, name: "isMember", type: "bool"}], name: "MembershipChanged", type: "event"} ;
		console.error( "eventCallOriginal[1,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MembershipChanged", events: [{name: "member", type: "address", value: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951"}, {name: "isMember", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[1,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "135800168937804909" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: addMember( addressList[6], `akru` )", async function( ) {
		const txOriginal = {blockNumber: "3687742", timeStamp: "1494492647", hash: "0x2ec20f9d024f06711631d8e25f2f137475e0eb6aa16c29b005397a4f08a49002", nonce: "98", blockHash: "0x7d90ce47a50fae262f70f9b82c2c88579515801cab2f4b1d2dec6fe606f8ee1e", transactionIndex: "15", from: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "136136", gasPrice: "20861374246", isError: "0", txreceipt_status: "", input: "0xc127c2470000000000000000000000004af013afbadb22d8a88c92d68fc96b033b9ebb8a00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000004616b727500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "609152", gasUsed: "113447", confirmations: "4064001"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "targetMember", value: addressList[6]}, {type: "string", name: "memberName", value: `akru`}], name: "addMember", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addMember(address,string)" ]( addressList[6], `akru`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1494492647 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "member", type: "address"}, {indexed: true, name: "isMember", type: "bool"}], name: "MembershipChanged", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MembershipChanged", events: [{name: "member", type: "address", value: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a"}, {name: "isMember", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "135800168937804909" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: addMember( addressList[7], `vol4tim` )", async function( ) {
		const txOriginal = {blockNumber: "3687754", timeStamp: "1494492737", hash: "0x51539a92c00dfb5fc79279fa2a42a027a8cfb57e34b3398853e2ad46c0714868", nonce: "99", blockHash: "0x1c0e1d7d30d572ec5609f8409f5e1a6966781d81647d9d98bdd68df54558a8f2", transactionIndex: "2", from: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "136367", gasPrice: "20861374246", isError: "0", txreceipt_status: "", input: "0xc127c2470000000000000000000000006cdb5584f22586a1d08b5a91e71dc0d378d27f3d00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000007766f6c3474696d00000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "155639", gasUsed: "113639", confirmations: "4063989"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "targetMember", value: addressList[7]}, {type: "string", name: "memberName", value: `vol4tim`}], name: "addMember", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addMember(address,string)" ]( addressList[7], `vol4tim`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1494492737 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "member", type: "address"}, {indexed: true, name: "isMember", type: "bool"}], name: "MembershipChanged", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MembershipChanged", events: [{name: "member", type: "address", value: "0x6cdb5584f22586a1d08b5a91e71dc0d378d27f3d"}, {name: "isMember", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "135800168937804909" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: changeVotingRules( \"3\", \"240\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "3687782", timeStamp: "1494493099", hash: "0x7f803056d1f3809547f1d5a9dcbefcc4392c7dcbabea407651829acd35ded492", nonce: "100", blockHash: "0x08d48c1adf7172ec876f8bb8a488252f68b1d1691d6830e7c901c878a2639e6c", transactionIndex: "10", from: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "83486", gasPrice: "20861374246", isError: "0", txreceipt_status: "", input: "0xbcca1fd3000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "310561", gasUsed: "69572", confirmations: "4063961"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "minimumQuorumForProposals", value: "3"}, {type: "uint256", name: "minutesForDebate", value: "240"}, {type: "int256", name: "marginOfVotesForMajority", value: "0"}], name: "changeVotingRules", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeVotingRules(uint256,uint256,int256)" ]( "3", "240", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1494493099 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "minimumQuorum", type: "uint256"}, {indexed: true, name: "debatingPeriodInMinutes", type: "uint256"}, {indexed: true, name: "majorityMargin", type: "int256"}], name: "ChangeOfRules", type: "event"} ;
		console.error( "eventCallOriginal[4,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeOfRules", events: [{name: "minimumQuorum", type: "uint256", value: "3"}, {name: "debatingPeriodInMinutes", type: "uint256", value: "240"}, {name: "majorityMargin", type: "int256", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[4,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "135800168937804909" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: addMember( addressList[8], `kap2fox` )", async function( ) {
		const txOriginal = {blockNumber: "3693123", timeStamp: "1494574004", hash: "0x591f84dd2238f507bf1c12db19717f536aa39e78ed5fb6a04987624c9d40f54b", nonce: "102", blockHash: "0x2b26411f65da418c9f76ca97bdad0392f4d280f606363e8d6eddc5d58a7072d4", transactionIndex: "14", from: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "136367", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xc127c2470000000000000000000000003c71d90cc3f19ac14c5e59047bb1ecd6d3527d71000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000076b617032666f7800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "448479", gasUsed: "113639", confirmations: "4058620"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "targetMember", value: addressList[8]}, {type: "string", name: "memberName", value: `kap2fox`}], name: "addMember", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addMember(address,string)" ]( addressList[8], `kap2fox`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1494574004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "member", type: "address"}, {indexed: true, name: "isMember", type: "bool"}], name: "MembershipChanged", type: "event"} ;
		console.error( "eventCallOriginal[5,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MembershipChanged", events: [{name: "member", type: "address", value: "0x3c71d90cc3f19ac14c5e59047bb1ecd6d3527d71"}, {name: "isMember", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[5,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "135800168937804909" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setOwner( addressList[2] )", async function( ) {
		const txOriginal = {blockNumber: "3693142", timeStamp: "1494574236", hash: "0xf3a9bd8fd3a1a8d4fdcfa2f830311720c15f36828c9767234be603781ccc0154", nonce: "103", blockHash: "0x1b977be513d86132d51d194e2fdbde3911e45f42c626f7a2ba02394728c4e6d1", transactionIndex: "25", from: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "34405", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x13af403500000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e", contractAddress: "", cumulativeGasUsed: "862672", gasUsed: "28671", confirmations: "4058601"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_owner", value: addressList[2]}], name: "setOwner", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setOwner(address)" ]( addressList[2], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1494574236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "135800168937804909" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: newProposal( addressList[9], \"100000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "3694594", timeStamp: "1494596142", hash: "0x6e347e8620d5a695b1c8cff445b48f7ccbd02fc10f2a3119f99448a3c7689f9b", nonce: "426", blockHash: "0x87b0e502e52621a1a58a6d98a1bbdca1919a2db3112d5a93f9dec347125264cc", transactionIndex: "23", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "252480", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xb1050da50000000000000000000000007b52427cec68182c74d0b5f9dec57ddd8f727de9000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000002c4372656174652064726573732072656865617273616c2061697220746f6b656e20627920666163746f72792e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000124b604ad7200000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ab9800000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e0000000000000000000000000000000000000000000000000000000000000011447265737352656865617273616c4169720000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003445241000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1019824", gasUsed: "210400", confirmations: "4057149"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "beneficiary", value: addressList[9]}, {type: "uint256", name: "amount", value: "100000000000000000"}, {type: "string", name: "jobDescription", value: `Create dress rehearsal air token by factory.`}, {type: "bytes", name: "transactionBytecode", value: "0xb604ad7200000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ab9800000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e0000000000000000000000000000000000000000000000000000000000000011447265737352656865617273616c41697200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034452410000000000000000000000000000000000000000000000000000000000"}], name: "newProposal", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newProposal(address,uint256,string,bytes)" ]( addressList[9], "100000000000000000", `Create dress rehearsal air token by factory.`, "0xb604ad7200000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ab9800000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e0000000000000000000000000000000000000000000000000000000000000011447265737352656865617273616c41697200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034452410000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1494596142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "recipient", type: "address"}, {indexed: true, name: "amount", type: "uint256"}, {indexed: false, name: "description", type: "string"}], name: "ProposalAdded", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ProposalAdded", events: [{name: "proposal", type: "uint256", value: "0"}, {name: "recipient", type: "address", value: "0x7b52427cec68182c74d0b5f9dec57ddd8f727de9"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "description", type: "string", value: "Create dress rehearsal air token by factory."}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"0\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3694599", timeStamp: "1494596184", hash: "0xf5e3ced3b001979a1d3b0742ac2f45e25411f60453a37053489497401bc9762d", nonce: "427", blockHash: "0xc04c2f60e40233c753b85cd1a8c4dbf1fae9622e4ec686a7801da1cdb0c4b14e", transactionIndex: "12", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "104836", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "372441", gasUsed: "87363", confirmations: "4057144"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "0", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1494596184 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "0"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"0\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3694632", timeStamp: "1494596774", hash: "0xbbd2bc1b5b2b3d6d2c859a09ccda2bdf58fcc6564088126dadb8a34d9eca3678", nonce: "104", blockHash: "0x652a84b713485a17de00cbe3434fb53a66c678e813e3999bc50e699673dddea5", transactionIndex: "47", from: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68836", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2137817", gasUsed: "57363", confirmations: "4057111"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "0", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1494596774 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "0"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "135800168937804909" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"0\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3694937", timeStamp: "1494601380", hash: "0x2957e0909053c8fb4e8c6869cf7225855a1bc60828eb1594b50e104ba79a732f", nonce: "72", blockHash: "0xcef2265291d75eb6042ab2e1aa69e349824b1e3438103ba3f38b7b452c628b83", transactionIndex: "15", from: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68836", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "839338", gasUsed: "57363", confirmations: "4056806"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "0", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1494601380 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "0"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "175042264157609202" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: executeProposal( \"0\", \"0xb604ad72000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3695870", timeStamp: "1494616006", hash: "0xc0fb76a06c9e02252f4b08b5dcdf63148bb22d897c6dfa9389f328746ffa150c", nonce: "428", blockHash: "0x141cf3bb7fb7ef8e51372f75109c46210d33d6a4dbf1f8547678a720b299ed44", transactionIndex: "17", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "872273", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x237e9492000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000124b604ad7200000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ab9800000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e0000000000000000000000000000000000000000000000000000000000000011447265737352656865617273616c4169720000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003445241000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1539679", gasUsed: "695181", confirmations: "4055873"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "bytes", name: "transactionBytecode", value: "0xb604ad7200000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ab9800000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e0000000000000000000000000000000000000000000000000000000000000011447265737352656865617273616c41697200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034452410000000000000000000000000000000000000000000000000000000000"}], name: "executeProposal", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeProposal(uint256,bytes)" ]( "0", "0xb604ad7200000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ab9800000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e0000000000000000000000000000000000000000000000000000000000000011447265737352656865617273616c41697200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034452410000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1494616006 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "quorum", type: "uint256"}, {indexed: true, name: "active", type: "bool"}], name: "ProposalTallied", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ProposalTallied", events: [{name: "proposal", type: "uint256", value: "0"}, {name: "quorum", type: "uint256", value: "3"}, {name: "active", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: newProposal( addressList[10], \"100000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "3695921", timeStamp: "1494616870", hash: "0x4444ab7f45e51756067e90bbb57f4aa6b32621ebd59b66aa4f03324e011ee559", nonce: "429", blockHash: "0x524c30a999f3f3c0edb5a0b95513a6732396e5da11db8258dfb3834a96e413ec", transactionIndex: "22", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "240670", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xb1050da5000000000000000000000000a2772a351e984d0582ad80a8ba8863489939f6db000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000384372656174652064726573732072656865617273616c2063726f776466756e64696e6720636f6e747261637420627920666163746f72792e000000000000000000000000000000000000000000000000000000000000000000000000000001c4f7efd15000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000bc8d39de02e370a6aac34c850896adcfc503d018000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000003868e600000000000000000000000000000000000000000000000000000000003890d800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004c53ecdc18a6000000000000000000000000000000000000000000000000000000038d7ea4c6800000000000000000000000000000000000000000000000000000000000000000960000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000000e446f6373207265666572656e636500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1235394", gasUsed: "200558", confirmations: "4055822"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "beneficiary", value: addressList[10]}, {type: "uint256", name: "amount", value: "100000000000000000"}, {type: "string", name: "jobDescription", value: `Create dress rehearsal crowdfunding contract by factory.`}, {type: "bytes", name: "transactionBytecode", value: "0xf7efd15000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000bc8d39de02e370a6aac34c850896adcfc503d018000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000003868e600000000000000000000000000000000000000000000000000000000003890d800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004c53ecdc18a6000000000000000000000000000000000000000000000000000000038d7ea4c6800000000000000000000000000000000000000000000000000000000000000000960000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000000e446f6373207265666572656e6365000000000000000000000000000000000000"}], name: "newProposal", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newProposal(address,uint256,string,bytes)" ]( addressList[10], "100000000000000000", `Create dress rehearsal crowdfunding contract by factory.`, "0xf7efd15000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000bc8d39de02e370a6aac34c850896adcfc503d018000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000003868e600000000000000000000000000000000000000000000000000000000003890d800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004c53ecdc18a6000000000000000000000000000000000000000000000000000000038d7ea4c6800000000000000000000000000000000000000000000000000000000000000000960000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000000e446f6373207265666572656e6365000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1494616870 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "recipient", type: "address"}, {indexed: true, name: "amount", type: "uint256"}, {indexed: false, name: "description", type: "string"}], name: "ProposalAdded", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ProposalAdded", events: [{name: "proposal", type: "uint256", value: "1"}, {name: "recipient", type: "address", value: "0xa2772a351e984d0582ad80a8ba8863489939f6db"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "description", type: "string", value: "Create dress rehearsal crowdfunding contract by factory."}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"1\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3695929", timeStamp: "1494617006", hash: "0xf2226bfa1390d58ad3cfe1321459ee271bde11c13b0a1ae1227c31d331efe9c2", nonce: "430", blockHash: "0xd74cdf574259314d6640c92bd700b9bd3ef8ec0d49b52f5f11518ecf3c8996b0", transactionIndex: "79", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "104912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4116277", gasUsed: "87427", confirmations: "4055814"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "1"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "1", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1494617006 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "1"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"1\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3695931", timeStamp: "1494617051", hash: "0xc2ec471a91adf470e4f9449d26c4bc6318aef4e581a0127a1d0fa76f105e32d7", nonce: "105", blockHash: "0x7d4f58c46b59f38dc0b0d79be40f7aa263af45b89aa76495e63af138f27d5e0f", transactionIndex: "15", from: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "104912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "575296", gasUsed: "57427", confirmations: "4055812"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "1"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "1", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1494617051 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "1"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "135800168937804909" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"1\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3695934", timeStamp: "1494617093", hash: "0xd44797139e0c215defc228467dc7d658660a7bf361c44d62b567174cbbf45a7a", nonce: "73", blockHash: "0xb66379b4addcf74cca9866bb8bc358311b556d19f6820bcf487b28e6fe10029b", transactionIndex: "8", from: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "332078", gasUsed: "57427", confirmations: "4055809"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "1"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "1", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1494617093 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "1"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "175042264157609202" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: executeProposal( \"1\", \"0xf7efd150000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3696890", timeStamp: "1494631365", hash: "0xad1e0c49a968396f347a9554cc55ec0fad5fd39f30fee861de6d4e82f95c0b51", nonce: "431", blockHash: "0x1713e16944d154421dccd8f5fdd31c701e1aec1d287fad36062f9a6cb0d00868", transactionIndex: "40", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "1054825", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x237e94920000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001c4f7efd15000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000bc8d39de02e370a6aac34c850896adcfc503d018000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000003868e600000000000000000000000000000000000000000000000000000000003890d800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004c53ecdc18a6000000000000000000000000000000000000000000000000000000038d7ea4c6800000000000000000000000000000000000000000000000000000000000000000960000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000000e446f6373207265666572656e636500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1877018", gasUsed: "862308", confirmations: "4054853"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "1"}, {type: "bytes", name: "transactionBytecode", value: "0xf7efd15000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000bc8d39de02e370a6aac34c850896adcfc503d018000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000003868e600000000000000000000000000000000000000000000000000000000003890d800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004c53ecdc18a6000000000000000000000000000000000000000000000000000000038d7ea4c6800000000000000000000000000000000000000000000000000000000000000000960000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000000e446f6373207265666572656e6365000000000000000000000000000000000000"}], name: "executeProposal", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeProposal(uint256,bytes)" ]( "1", "0xf7efd15000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000bc8d39de02e370a6aac34c850896adcfc503d018000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000003868e600000000000000000000000000000000000000000000000000000000003890d800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004c53ecdc18a6000000000000000000000000000000000000000000000000000000038d7ea4c6800000000000000000000000000000000000000000000000000000000000000000960000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000000e446f6373207265666572656e6365000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1494631365 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "quorum", type: "uint256"}, {indexed: true, name: "active", type: "bool"}], name: "ProposalTallied", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ProposalTallied", events: [{name: "proposal", type: "uint256", value: "1"}, {name: "quorum", type: "uint256", value: "3"}, {name: "active", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: newProposal( addressList[11], \"0\", `Set rehearsal c... )", async function( ) {
		const txOriginal = {blockNumber: "3698903", timeStamp: "1494662718", hash: "0x35b861ad265ecd80afeef91b271c5058a944a8efeed68e0e85c73221ce47224d", nonce: "432", blockHash: "0xd2139f0988137fedd9b306b01382be5c26f979e7e8f7e346627e851cba73c14d", transactionIndex: "11", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "212552", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xb1050da5000000000000000000000000bc8d39de02e370a6aac34c850896adcfc503d0180000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000375365742072656865617273616c2063726f776466756e64696e67206265206f776e6572206f662072656865617273616c20746f6b656e2e000000000000000000000000000000000000000000000000000000000000000000000000000000002413af403500000000000000000000000032fabade1d0e05f98c8bbe89e66c40db040cbe8e00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1045195", gasUsed: "177127", confirmations: "4052840"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "beneficiary", value: addressList[11]}, {type: "uint256", name: "amount", value: "0"}, {type: "string", name: "jobDescription", value: `Set rehearsal crowdfunding be owner of rehearsal token.`}, {type: "bytes", name: "transactionBytecode", value: "0x13af403500000000000000000000000032fabade1d0e05f98c8bbe89e66c40db040cbe8e"}], name: "newProposal", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newProposal(address,uint256,string,bytes)" ]( addressList[11], "0", `Set rehearsal crowdfunding be owner of rehearsal token.`, "0x13af403500000000000000000000000032fabade1d0e05f98c8bbe89e66c40db040cbe8e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1494662718 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "recipient", type: "address"}, {indexed: true, name: "amount", type: "uint256"}, {indexed: false, name: "description", type: "string"}], name: "ProposalAdded", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ProposalAdded", events: [{name: "proposal", type: "uint256", value: "2"}, {name: "recipient", type: "address", value: "0xbc8d39de02e370a6aac34c850896adcfc503d018"}, {name: "amount", type: "uint256", value: "0"}, {name: "description", type: "string", value: "Set rehearsal crowdfunding be owner of rehearsal token."}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"2\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3698905", timeStamp: "1494662759", hash: "0xbd9b48bac8e3bde171aeb2ea1c78d96d245f94fdb1f447b813cf199638c5ac94", nonce: "433", blockHash: "0xf7e51706c0078234da9be8ad52d0c31523e9806a0c15f6a87a663f53ea70384f", transactionIndex: "12", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "104912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1292846", gasUsed: "87427", confirmations: "4052838"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "2"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "2", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1494662759 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "2"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"2\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3699015", timeStamp: "1494664728", hash: "0x180ef42548ae5d60c05fcb18894a5b07f38f55bf5e71b6a1fcbda04af7a9205a", nonce: "107", blockHash: "0xbbe7e97a1328d759025a53ec7f6bd1e06344d2a36fdb1761f1c5e1c4c504e827", transactionIndex: "11", from: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "654837", gasUsed: "57427", confirmations: "4052728"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "2"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "2", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1494664728 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "2"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "135800168937804909" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"2\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3699087", timeStamp: "1494665864", hash: "0x4f7b1ac8be1947b3d37a98eec626105ca49ca7e140c805d3e9d8546bec0cbf3f", nonce: "74", blockHash: "0x3181fc1bc87fa197510b7ae6a7262ecf5b4c8fd1180dc43131eefa629125cdc2", transactionIndex: "13", from: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1375966", gasUsed: "57427", confirmations: "4052656"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "2"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "2", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1494665864 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "2"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "175042264157609202" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: executeProposal( \"2\", \"0x13af4035000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3699860", timeStamp: "1494677459", hash: "0xc416ed5c3a5d514a4cd3f7388ea728835ee452b6dc3cc5833d252a4b797ae2a1", nonce: "434", blockHash: "0x910eaf7d6220094cd0b460f19150ac47be1ac36d0d6beeed20d2427e91913fd0", transactionIndex: "20", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "75059", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x237e949200000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002413af403500000000000000000000000032fabade1d0e05f98c8bbe89e66c40db040cbe8e00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "714557", gasUsed: "62549", confirmations: "4051883"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "2"}, {type: "bytes", name: "transactionBytecode", value: "0x13af403500000000000000000000000032fabade1d0e05f98c8bbe89e66c40db040cbe8e"}], name: "executeProposal", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeProposal(uint256,bytes)" ]( "2", "0x13af403500000000000000000000000032fabade1d0e05f98c8bbe89e66c40db040cbe8e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1494677459 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "quorum", type: "uint256"}, {indexed: true, name: "active", type: "bool"}], name: "ProposalTallied", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ProposalTallied", events: [{name: "proposal", type: "uint256", value: "2"}, {name: "quorum", type: "uint256", value: "3"}, {name: "active", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: newProposal( addressList[12], \"0\", `Withdrawal rehe... )", async function( ) {
		const txOriginal = {blockNumber: "3709837", timeStamp: "1494834990", hash: "0xf52839e0ecfc0c85b050ac4ded39b944a8f2aeae4a718fafb109a6910b5d100c", nonce: "438", blockHash: "0xfff2ceaf9fb85437cc6d3514166fd3fba77174ba40273812dd7532345f58039e", transactionIndex: "20", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "209137", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xb1050da500000000000000000000000032fabade1d0e05f98c8bbe89e66c40db040cbe8e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000225769746864726177616c2072656865617273616c2063726f776466756e64696e672e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000043ccfd60b00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1183390", gasUsed: "174281", confirmations: "4041906"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "beneficiary", value: addressList[12]}, {type: "uint256", name: "amount", value: "0"}, {type: "string", name: "jobDescription", value: `Withdrawal rehearsal crowdfunding.`}, {type: "bytes", name: "transactionBytecode", value: "0x3ccfd60b"}], name: "newProposal", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newProposal(address,uint256,string,bytes)" ]( addressList[12], "0", `Withdrawal rehearsal crowdfunding.`, "0x3ccfd60b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1494834990 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "recipient", type: "address"}, {indexed: true, name: "amount", type: "uint256"}, {indexed: false, name: "description", type: "string"}], name: "ProposalAdded", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ProposalAdded", events: [{name: "proposal", type: "uint256", value: "3"}, {name: "recipient", type: "address", value: "0x32fabade1d0e05f98c8bbe89e66c40db040cbe8e"}, {name: "amount", type: "uint256", value: "0"}, {name: "description", type: "string", value: "Withdrawal rehearsal crowdfunding."}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"3\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3709859", timeStamp: "1494835288", hash: "0x50dfe655bf441e931ea774c5356a5945a11897eb1d2d5eada164f1f1d1918da9", nonce: "110", blockHash: "0x725ae3950929cccded6b27a0a9588df8c7ce6a8c04e7234ac3c8e75857cd1b64", transactionIndex: "5", from: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "104912", gasPrice: "20850510847", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "240915", gasUsed: "87427", confirmations: "4041884"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "3"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "3", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1494835288 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "3"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "135800168937804909" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"3\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3709865", timeStamp: "1494835397", hash: "0x75e2a48342b5165f1280b4259d664067d59a9e5d888ca44d098145a94b14648b", nonce: "439", blockHash: "0x34c471e8d6a429667e2ddee9e4f9202aa8af99f05fe6dd5fbf06cd605b30782e", transactionIndex: "18", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20850510847", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "776198", gasUsed: "57427", confirmations: "4041878"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "3"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "3", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1494835397 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "3"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"3\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3710283", timeStamp: "1494841643", hash: "0x20d33cadf73d13ca78a19dc0cdd8a90d1ea4639ea676677582b2333b96ffd2d7", nonce: "17", blockHash: "0x20d419cfc1a7fb9a43442883cf09989d626630d638efbd95bfd1a35d82916629", transactionIndex: "1", from: "0x6cdb5584f22586a1d08b5a91e71dc0d378d27f3d", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20688571458", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "90998", gasUsed: "57427", confirmations: "4041460"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "3"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "3", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1494841643 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "3"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x6cdb5584f22586a1d08b5a91e71dc0d378d27f3d"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "22535812141107902" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: newProposal( addressList[9], \"100000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "3710614", timeStamp: "1494847446", hash: "0x13ab7fef8a6a1af4161601907184dd30731e54a24faf4a8d712edae37435211e", nonce: "445", blockHash: "0xacbb2c33600abae5e77ff5b1eb56bd0c6ad1dcee9f02ad6b5f2d837c28bea133", transactionIndex: "12", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "233866", gasPrice: "20926582954", isError: "0", txreceipt_status: "", input: "0xb1050da50000000000000000000000007b52427cec68182c74d0b5f9dec57ddd8f727de9000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000254372656174652072656865617365616c20233220746f6b656e20627920666163746f72792e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000124b604ad7200000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ab9800000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000001052656865617273616c20416972202332000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003524132000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "623957", gasUsed: "194888", confirmations: "4041129"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "beneficiary", value: addressList[9]}, {type: "uint256", name: "amount", value: "100000000000000000"}, {type: "string", name: "jobDescription", value: `Create reheaseal #2 token by factory.`}, {type: "bytes", name: "transactionBytecode", value: "0xb604ad7200000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ab9800000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000001052656865617273616c204169722023320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000035241320000000000000000000000000000000000000000000000000000000000"}], name: "newProposal", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newProposal(address,uint256,string,bytes)" ]( addressList[9], "100000000000000000", `Create reheaseal #2 token by factory.`, "0xb604ad7200000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ab9800000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000001052656865617273616c204169722023320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000035241320000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1494847446 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "recipient", type: "address"}, {indexed: true, name: "amount", type: "uint256"}, {indexed: false, name: "description", type: "string"}], name: "ProposalAdded", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ProposalAdded", events: [{name: "proposal", type: "uint256", value: "4"}, {name: "recipient", type: "address", value: "0x7b52427cec68182c74d0b5f9dec57ddd8f727de9"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "description", type: "string", value: "Create reheaseal #2 token by factory."}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"4\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3710620", timeStamp: "1494847535", hash: "0x7941adfb55ce8c99cf985d5b572aa38e36e43daeb375fdf428c3481c8139dc5d", nonce: "18", blockHash: "0xb40cd5561893653a9cc8f47244b1c4dbd3e9df7f05b0d150f468688b568b08de", transactionIndex: "10", from: "0x6cdb5584f22586a1d08b5a91e71dc0d378d27f3d", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "104912", gasPrice: "20768701208", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "402141", gasUsed: "87427", confirmations: "4041123"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "4"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "4", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1494847535 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "4"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x6cdb5584f22586a1d08b5a91e71dc0d378d27f3d"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "22535812141107902" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"4\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3710646", timeStamp: "1494847950", hash: "0xf48830a8133191505d1da2d9e5d6a225b1759d5361b8e44dddc95de76531f2c5", nonce: "446", blockHash: "0x46186d92d64ae0dc5b65f3cdcd5451e19554d273fec99f62ef86a595c2dbd38c", transactionIndex: "9", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20768701208", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "838812", gasUsed: "57427", confirmations: "4041097"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "4"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "4", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1494847950 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "4"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"4\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3710793", timeStamp: "1494850431", hash: "0xff3488539fffa8428d6a132e31f22adc8cbcf4b0d60bd7d1da22818db59b42d6", nonce: "111", blockHash: "0x3680a73a82cc3868b3dc6ac3702f3928334dbdef0dd05ca1f2abcc9bdfb6df38", transactionIndex: "39", from: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1897760", gasUsed: "57427", confirmations: "4040950"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "4"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "4", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1494850431 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "4"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "135800168937804909" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: executeProposal( \"3\", \"0x3ccfd60b\" )", async function( ) {
		const txOriginal = {blockNumber: "3711188", timeStamp: "1494856612", hash: "0x409a828902333d84b1a957647aa95599f633544de4e37dbfe3541b13ef61fb2f", nonce: "447", blockHash: "0xf052b0e1109ea1f4b92862d492b1526b5363e32356b002738fc7ad81d4f4523a", transactionIndex: "17", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "110664", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x237e94920000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000043ccfd60b00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "995373", gasUsed: "65904", confirmations: "4040555"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "3"}, {type: "bytes", name: "transactionBytecode", value: "0x3ccfd60b"}], name: "executeProposal", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeProposal(uint256,bytes)" ]( "3", "0x3ccfd60b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1494856612 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "quorum", type: "uint256"}, {indexed: true, name: "active", type: "bool"}], name: "ProposalTallied", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ProposalTallied", events: [{name: "proposal", type: "uint256", value: "3"}, {name: "quorum", type: "uint256", value: "3"}, {name: "active", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "amount", type: "uint256"}], name: "ReceivedEther", type: "event"} ;
		console.error( "eventCallOriginal[30,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReceivedEther", events: [{name: "sender", type: "address", value: "0x32fabade1d0e05f98c8bbe89e66c40db040cbe8e"}, {name: "amount", type: "uint256", value: "6640000000000000000"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[30,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"4\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3711595", timeStamp: "1494862895", hash: "0xf26bb9b5ebe70980d2e895d1e8cfe5cd2e240fd31e31559cec9ee4e06ea734b3", nonce: "75", blockHash: "0xc55bca73df467b213724bf4e128c35d09fcf27df23b05a9443ae622d25741c84", transactionIndex: "12", from: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "632973", gasUsed: "57427", confirmations: "4040148"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "4"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "4", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1494862895 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "4"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "175042264157609202" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: executeProposal( \"4\", \"0xb604ad72000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3711728", timeStamp: "1494864850", hash: "0x6cff8d46b363f20422c7bfa4516df303177b86b0b1cb7b0efb68d4fdd482ed45", nonce: "448", blockHash: "0x7f5a4aeca1e543f6fc03732154076e9433d27b7d1d2acc20c678d19a11923099", transactionIndex: "2", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "854273", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x237e9492000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000124b604ad7200000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ab9800000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000001052656865617273616c20416972202332000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003524132000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "743205", gasUsed: "680181", confirmations: "4040015"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "4"}, {type: "bytes", name: "transactionBytecode", value: "0xb604ad7200000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ab9800000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000001052656865617273616c204169722023320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000035241320000000000000000000000000000000000000000000000000000000000"}], name: "executeProposal", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeProposal(uint256,bytes)" ]( "4", "0xb604ad7200000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ab9800000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000001052656865617273616c204169722023320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000035241320000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1494864850 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "quorum", type: "uint256"}, {indexed: true, name: "active", type: "bool"}], name: "ProposalTallied", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ProposalTallied", events: [{name: "proposal", type: "uint256", value: "4"}, {name: "quorum", type: "uint256", value: "4"}, {name: "active", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: newProposal( addressList[13], \"100000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "3711815", timeStamp: "1494866351", hash: "0xaf87ed25c0bebe3b59cba71807cd794a781b9799d242cb818c0f2197e3722d1a", nonce: "449", blockHash: "0x4202d9ea522e7bd5e2bd2a3ab7f6e1e8eb565553df06c9e332851beaec0af3d0", transactionIndex: "46", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "240516", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xb1050da5000000000000000000000000e0d1c0926fd72107b866c1ba5dd2245fcb51eee7000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000354372656174652072656865617273616c2063726f776466756e64696e6720233220636f6e747261637420627920666163746f72792e000000000000000000000000000000000000000000000000000000000000000000000000000000000001c4f7efd15000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e0000000000000000000000004203bce7f488ed0cf55437ad2e5b99af51dad07a0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000000000000000000000000000000000000038ac67000000000000000000000000000000000000000000000000000000000038c3d700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000124f80000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000000e446f6373207265666572656e636500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2633622", gasUsed: "200430", confirmations: "4039928"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "beneficiary", value: addressList[13]}, {type: "uint256", name: "amount", value: "100000000000000000"}, {type: "string", name: "jobDescription", value: `Create rehearsal crowdfunding #2 contract by factory.`}, {type: "bytes", name: "transactionBytecode", value: "0xf7efd15000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e0000000000000000000000004203bce7f488ed0cf55437ad2e5b99af51dad07a0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000000000000000000000000000000000000038ac67000000000000000000000000000000000000000000000000000000000038c3d700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000124f80000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000000e446f6373207265666572656e6365000000000000000000000000000000000000"}], name: "newProposal", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newProposal(address,uint256,string,bytes)" ]( addressList[13], "100000000000000000", `Create rehearsal crowdfunding #2 contract by factory.`, "0xf7efd15000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e0000000000000000000000004203bce7f488ed0cf55437ad2e5b99af51dad07a0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000000000000000000000000000000000000038ac67000000000000000000000000000000000000000000000000000000000038c3d700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000124f80000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000000e446f6373207265666572656e6365000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1494866351 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "recipient", type: "address"}, {indexed: true, name: "amount", type: "uint256"}, {indexed: false, name: "description", type: "string"}], name: "ProposalAdded", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ProposalAdded", events: [{name: "proposal", type: "uint256", value: "5"}, {name: "recipient", type: "address", value: "0xe0d1c0926fd72107b866c1ba5dd2245fcb51eee7"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "description", type: "string", value: "Create rehearsal crowdfunding #2 contract by factory."}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"5\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3711817", timeStamp: "1494866438", hash: "0xf1b6406dd1d0d3fed8d3f3c656ee54d115136d5664def4dd5e16c74ef16480d6", nonce: "76", blockHash: "0x6c42d49d7185e214c9d83d65a1b9bdf025244f3b5040d95b03ac78e29a65bce8", transactionIndex: "49", from: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "104912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3188831", gasUsed: "87427", confirmations: "4039926"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "5"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "5", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1494866438 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "5"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "175042264157609202" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"5\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3711825", timeStamp: "1494866506", hash: "0x41587883b4857a441fb69d733656ed2fc4b31cce48946518865225442365ed2b", nonce: "450", blockHash: "0xdfb6c755ba3bad55be3d785b1950d2f802a011f262d6574e8bd8bdaf7544f0b7", transactionIndex: "12", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "104912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "574524", gasUsed: "57427", confirmations: "4039918"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "5"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "5", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1494866506 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "5"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"5\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3711832", timeStamp: "1494866675", hash: "0xed9dea7aadbf7c8fa799910f59140a92ff2d99e5677828e213857a3708f558b9", nonce: "112", blockHash: "0x8696dc6de950cc34d4ec6ffa6d713e9bcfde68fef8dc2243907175d166520e49", transactionIndex: "47", from: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2465617", gasUsed: "57427", confirmations: "4039911"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "5"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "5", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1494866675 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "5"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "135800168937804909" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: executeProposal( \"5\", \"0xf7efd150000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3712706", timeStamp: "1494880888", hash: "0x27c0a49f71c8599d9f6634e829972bb56ca4677b7ae79555d25b6fa8c6bf6283", nonce: "451", blockHash: "0xa909043f17a9e56ec8d5b49a48b80c7f3f73bc0b20cc6b3e4b82a9fa03e07eec", transactionIndex: "13", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "1037382", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x237e94920000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001c4f7efd15000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e0000000000000000000000004203bce7f488ed0cf55437ad2e5b99af51dad07a0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000000000000000000000000000000000000038ac67000000000000000000000000000000000000000000000000000000000038c3d700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000124f80000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000000e446f6373207265666572656e636500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1228143", gasUsed: "847772", confirmations: "4039037"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "5"}, {type: "bytes", name: "transactionBytecode", value: "0xf7efd15000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e0000000000000000000000004203bce7f488ed0cf55437ad2e5b99af51dad07a0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000000000000000000000000000000000000038ac67000000000000000000000000000000000000000000000000000000000038c3d700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000124f80000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000000e446f6373207265666572656e6365000000000000000000000000000000000000"}], name: "executeProposal", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeProposal(uint256,bytes)" ]( "5", "0xf7efd15000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e0000000000000000000000004203bce7f488ed0cf55437ad2e5b99af51dad07a0000000000000000000000000000000000000000000000000000000000000180000000000000000000000000000000000000000000000000000000000038ac67000000000000000000000000000000000000000000000000000000000038c3d700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000124f80000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e000000000000000000000000000000000000000000000000000000000000000e446f6373207265666572656e6365000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1494880888 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "quorum", type: "uint256"}, {indexed: true, name: "active", type: "bool"}], name: "ProposalTallied", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ProposalTallied", events: [{name: "proposal", type: "uint256", value: "5"}, {name: "quorum", type: "uint256", value: "3"}, {name: "active", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: newProposal( addressList[14], \"0\", `Set rehearsal t... )", async function( ) {
		const txOriginal = {blockNumber: "3712746", timeStamp: "1494881525", hash: "0x4fdd2f4cf123d03835162486c499ec7a310f76377cc5594fea533268977a3091", nonce: "452", blockHash: "0x03d8a41315f2e2c5b5a41cd3655fbf7cd17403151d7b25db436daab391e3a079", transactionIndex: "22", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "212552", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xb1050da50000000000000000000000004203bce7f488ed0cf55437ad2e5b99af51dad07a0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000375365742072656865617273616c20746f6b656e202332206f776e657220746f2072656865617273616c2063726f776473616c652023322e000000000000000000000000000000000000000000000000000000000000000000000000000000002413af4035000000000000000000000000399a40838258af0836cad506cc58bf7a40061ee000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2611000", gasUsed: "177127", confirmations: "4038997"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "beneficiary", value: addressList[14]}, {type: "uint256", name: "amount", value: "0"}, {type: "string", name: "jobDescription", value: `Set rehearsal token #2 owner to rehearsal crowdsale #2.`}, {type: "bytes", name: "transactionBytecode", value: "0x13af4035000000000000000000000000399a40838258af0836cad506cc58bf7a40061ee0"}], name: "newProposal", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newProposal(address,uint256,string,bytes)" ]( addressList[14], "0", `Set rehearsal token #2 owner to rehearsal crowdsale #2.`, "0x13af4035000000000000000000000000399a40838258af0836cad506cc58bf7a40061ee0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1494881525 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "recipient", type: "address"}, {indexed: true, name: "amount", type: "uint256"}, {indexed: false, name: "description", type: "string"}], name: "ProposalAdded", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ProposalAdded", events: [{name: "proposal", type: "uint256", value: "6"}, {name: "recipient", type: "address", value: "0x4203bce7f488ed0cf55437ad2e5b99af51dad07a"}, {name: "amount", type: "uint256", value: "0"}, {name: "description", type: "string", value: "Set rehearsal token #2 owner to rehearsal crowdsale #2."}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"6\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3712750", timeStamp: "1494881594", hash: "0x471016201af0ce3df2a2a0163f672d7f5721b9019b4fbf426274455996be3186", nonce: "453", blockHash: "0xa2bea21d1770c66119b4e752f5e0aa0c5ec28391b35032f00d6099d336a35426", transactionIndex: "12", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "104912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "874974", gasUsed: "87427", confirmations: "4038993"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "6"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "6", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1494881594 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "6"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"6\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3712853", timeStamp: "1494883292", hash: "0x8c14a801a15fbfa69742767010e59378e729bbb9aeba8ec36ebe77e9ee0394a2", nonce: "113", blockHash: "0xcafe8263d5aae1a9827d776b95edd9cbe12028ee23c41ebf11eb9343d9648644", transactionIndex: "1", from: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "78427", gasUsed: "57427", confirmations: "4038890"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "6"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "6", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1494883292 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "6"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x6efba8fb2ac5b6730729a972ec224426a287c3ad"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "135800168937804909" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"6\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3712865", timeStamp: "1494883554", hash: "0x796e2627b0ae5803d4aa445dfe0cc0aa1ca0eda38329420e214503e0ef661ad9", nonce: "80", blockHash: "0xd346dd5f847eb5c876837b3ce6681698849e1969b78383010992c935b575c981", transactionIndex: "75", from: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2422944", gasUsed: "57427", confirmations: "4038878"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "6"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "6", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1494883554 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "6"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "175042264157609202" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: executeProposal( \"6\", \"0x13af4035000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "3715263", timeStamp: "1494921390", hash: "0xeae7bec553236ada47d1120d38613ee32f9689bc39366b2b88852dd6b3950e14", nonce: "454", blockHash: "0x25fef2feb6bc7b73170ee21a0bbe8e2ad83d5b94eb6bc6f07022e8344f0e595c", transactionIndex: "20", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "75059", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x237e949200000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002413af4035000000000000000000000000399a40838258af0836cad506cc58bf7a40061ee000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1327210", gasUsed: "62549", confirmations: "4036480"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "6"}, {type: "bytes", name: "transactionBytecode", value: "0x13af4035000000000000000000000000399a40838258af0836cad506cc58bf7a40061ee0"}], name: "executeProposal", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeProposal(uint256,bytes)" ]( "6", "0x13af4035000000000000000000000000399a40838258af0836cad506cc58bf7a40061ee0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1494921390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "quorum", type: "uint256"}, {indexed: true, name: "active", type: "bool"}], name: "ProposalTallied", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ProposalTallied", events: [{name: "proposal", type: "uint256", value: "6"}, {name: "quorum", type: "uint256", value: "3"}, {name: "active", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: newProposal( addressList[15], \"0\", `Withdraw rehear... )", async function( ) {
		const txOriginal = {blockNumber: "3720736", timeStamp: "1495009699", hash: "0x3437a45844b00d5ffaac0a4c4d6196ee69c4a8a34d278af5acc5dcc2e384f73a", nonce: "456", blockHash: "0x39ba63c3e8ece3fb51eb75a065ccf19597acbeb12e18b7d8489a5f6eccfb46e0", transactionIndex: "5", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "209214", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xb1050da5000000000000000000000000399a40838258af0836cad506cc58bf7a40061ee00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000002357697468647261772072656865617273616c2063726f776466756e64696e672023322e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000043ccfd60b00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "325043", gasUsed: "174345", confirmations: "4031007"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "beneficiary", value: addressList[15]}, {type: "uint256", name: "amount", value: "0"}, {type: "string", name: "jobDescription", value: `Withdraw rehearsal crowdfunding #2.`}, {type: "bytes", name: "transactionBytecode", value: "0x3ccfd60b"}], name: "newProposal", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newProposal(address,uint256,string,bytes)" ]( addressList[15], "0", `Withdraw rehearsal crowdfunding #2.`, "0x3ccfd60b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1495009699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "recipient", type: "address"}, {indexed: true, name: "amount", type: "uint256"}, {indexed: false, name: "description", type: "string"}], name: "ProposalAdded", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ProposalAdded", events: [{name: "proposal", type: "uint256", value: "7"}, {name: "recipient", type: "address", value: "0x399a40838258af0836cad506cc58bf7a40061ee0"}, {name: "amount", type: "uint256", value: "0"}, {name: "description", type: "string", value: "Withdraw rehearsal crowdfunding #2."}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"7\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3720745", timeStamp: "1495009875", hash: "0x621a4eca89a2bd718b640d7cbacec560c4960210c95e7dbcd60a5b84901b4d11", nonce: "457", blockHash: "0xd511435b3143ebd42991f7d0b27819fc474dd45b17194de5aa2299e87e623bba", transactionIndex: "12", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "104912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "936151", gasUsed: "87427", confirmations: "4030998"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "7", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1495009875 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "7"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"7\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3720753", timeStamp: "1495010051", hash: "0xde982f2f8cb1fbc4c71188933c75ee4b6b184d189d4bda462459fd3ae6330959", nonce: "19", blockHash: "0x49ed99a0f5ce677929e14e33a4d6735aaf5fd9eeaa1a8510f7b92decc558c953", transactionIndex: "21", from: "0x6cdb5584f22586a1d08b5a91e71dc0d378d27f3d", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2590715", gasUsed: "57427", confirmations: "4030990"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "7", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1495010051 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "7"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x6cdb5584f22586a1d08b5a91e71dc0d378d27f3d"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "22535812141107902" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"7\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3720755", timeStamp: "1495010099", hash: "0x5914d90188a08e1735ab30b118214460959aad9a720963d1b278fcd2e706eae1", nonce: "81", blockHash: "0x17f24c2f6af59f3f8db34981f4367d5df49c4694834a4be655bfbe41fa2aefaf", transactionIndex: "16", from: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1333631", gasUsed: "57427", confirmations: "4030988"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "7"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "7", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1495010099 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "7"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "175042264157609202" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: newProposal( addressList[16], \"100000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "3720857", timeStamp: "1495011782", hash: "0x13b49f69429146ab8cc814043330cdb45aea1a24acaffa27867dd0e7d5b9e636", nonce: "462", blockHash: "0xfb97e44a01364f7d77c25d991b7b3ff643483437c414af9148125ab9829b9860", transactionIndex: "14", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "233282", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xb1050da50000000000000000000000004c3c6f5f2ef44f5e2ffcf6c20b906a91d246c9a2000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000002d4372656174652072656865617273616c2070726573616c6520636f6e747261637420627920666163746f72792e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000084a5d048d30000000000000000000000004203bce7f488ed0cf55437ad2e5b99af51dad07a000000000000000000000000000000000000000000000000000000000002ab980000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "558847", gasUsed: "194402", confirmations: "4030886"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "beneficiary", value: addressList[16]}, {type: "uint256", name: "amount", value: "100000000000000000"}, {type: "string", name: "jobDescription", value: `Create rehearsal presale contract by factory.`}, {type: "bytes", name: "transactionBytecode", value: "0xa5d048d30000000000000000000000004203bce7f488ed0cf55437ad2e5b99af51dad07a000000000000000000000000000000000000000000000000000000000002ab980000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e"}], name: "newProposal", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newProposal(address,uint256,string,bytes)" ]( addressList[16], "100000000000000000", `Create rehearsal presale contract by factory.`, "0xa5d048d30000000000000000000000004203bce7f488ed0cf55437ad2e5b99af51dad07a000000000000000000000000000000000000000000000000000000000002ab980000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000097282a7a15f9beadc854e8793aae43b089f14b4e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1495011782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "recipient", type: "address"}, {indexed: true, name: "amount", type: "uint256"}, {indexed: false, name: "description", type: "string"}], name: "ProposalAdded", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ProposalAdded", events: [{name: "proposal", type: "uint256", value: "8"}, {name: "recipient", type: "address", value: "0x4c3c6f5f2ef44f5e2ffcf6c20b906a91d246c9a2"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "description", type: "string", value: "Create rehearsal presale contract by factory."}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"8\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3720861", timeStamp: "1495011830", hash: "0x807eb0082cc14b5af2646d6bccdb24dd5919ab1818415372a33c7e8e2ce080c5", nonce: "463", blockHash: "0x5dfe973b8159f4ad0b5056b6cb75cc756ada659f9bea96548d2d27d7fb151b4d", transactionIndex: "7", from: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "104912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "259513", gasUsed: "87427", confirmations: "4030882"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "8"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "8", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1495011830 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "8"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x4af013afbadb22d8a88c92d68fc96b033b9ebb8a"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9106706000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"8\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3720872", timeStamp: "1495012041", hash: "0x04d8cde3aada35b7ba8a28f050d29947c9a80a1c3995423ae4149e775c8c4524", nonce: "20", blockHash: "0xe59b9a15a99ce3346838af2d85338e07abc2d788eaa5c429c3f2203b9529c20a", transactionIndex: "38", from: "0x6cdb5584f22586a1d08b5a91e71dc0d378d27f3d", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1187864", gasUsed: "57427", confirmations: "4030871"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "8"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "8", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1495012041 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "8"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x6cdb5584f22586a1d08b5a91e71dc0d378d27f3d"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "22535812141107902" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: vote( \"8\", true, `` )", async function( ) {
		const txOriginal = {blockNumber: "3721027", timeStamp: "1495014480", hash: "0xe4a4e094f0e2657f1e0e789e1b99895198ace70c5f3748582653464cae6ed3d9", nonce: "82", blockHash: "0x1181d053c080abb86e49ed6d9d1c9eb985415fe7662b7662d7694c8f94562636", transactionIndex: "33", from: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951", to: "0x97282a7a15f9beadc854e8793aae43b089f14b4e", value: "0", gas: "68912", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd3c0715b0000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4027955", gasUsed: "57427", confirmations: "4030716"} ;
		console.error( "txOriginal[50] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[50] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "8"}, {type: "bool", name: "supportsProposal", value: true}, {type: "string", name: "justificationText", value: ``}], name: "vote", outputs: [], type: "function"} ;
		console.error( "txCall[50] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "vote(uint256,bool,string)" ]( "8", true, ``, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 50, 1495014480 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[50] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "proposal", type: "uint256"}, {indexed: true, name: "position", type: "bool"}, {indexed: true, name: "voter", type: "address"}, {indexed: false, name: "justification", type: "string"}], name: "Voted", type: "event"} ;
		console.error( "eventCallOriginal[50,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Voted", events: [{name: "proposal", type: "uint256", value: "8"}, {name: "position", type: "bool", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "voter", type: "address", value: "0x1e5ac6a2663f1501eeef5c28b7f49bb06f2a0951"}, {name: "justification", type: "string", value: ""}], address: "0x97282a7a15f9beadc854e8793aae43b089f14b4e"}] ;
		console.error( "eventResultOriginal[50,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "175042264157609202" } ;
		console.error( "fromBalanceOriginal[50] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4664866832552059200" } ;
		console.error( "toBalanceOriginal[50] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[50] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[50] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[50,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[50,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 50", async function( ) {
		await constantFunction( 50, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
