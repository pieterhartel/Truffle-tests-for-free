const ChickenToken = artifacts.require( "./ChickenToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "ChickenToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x7d9238E1C39E91089Bfe5E72A503e32f2dAC526e", "0xBE87B792b8C1E311D24eEd1B67afa5f39d6C1F8C", "0x7332c2a5BA8BE18362E0B5D74504597bB50b9fb5", "0x6a37746Db47e4808f665ec1784351856DFcEc106", "0x2629C3648491c065bf0792d3e333d2b84b810867", "0xbB943aff95Ae90Cceab03f7fFcC24B55385841dA", "0x00231513adF1Bb1FeEb1f4eF5D18a15F5ff9E2dB", "0x5E65220DBbeAf6d2528528142D5eA2CD1044567C", "0xB482a0DC7C1F95eF89CBD23F2a57930C0365b3dD", "0x3030B94518fa058B7C464A08479823f0d792Dbef", "0x9FD730dDeaAd1063B025f6032847fc14eeA3d68D", "0xD511B3e3751008eCca9b9cdB2488bc39b70D7441", "0xb21F458F6f9245fCD7De0837bEc48577f665b274", "0x2CaEd06C459DE7fe538Ae908b35384DEB3980644", "0xB58d9445eCd5D8d3a9BCF618336bf8544A96F1DD", "0xa893e2816e3dDCc270DFEF6d0Aa771053e16a567", "0x6c2e4Cd0deb91bcCCa154F4f702503a49895F592", "0x819AA5C4bA40A5362a898C59fDdDe82b89636376", "0x3ff85784D06A124798A09eb6f27FEf4b3C879Dfd", "0xE56f77004a18D474396163Be9467DB0cAB7A1c5F", "0xEBA5175bbd03df1fF1C733Dc6bBA681cdb35a3B4", "0xfc2752e35b62A29E7D24E607c6B55eeF39ef561F", "0xb230F17085f79a65E65725a47D2baF6F6bF7a17B", "0x4Ce7294D0C31f2fb8DE83D914357a2F1f0Ea72D9", "0xafc092e6FDD10f28D93aBD00d1E427EfFdaaD39c", "0x55C556832466BccEF30486AAF3DAe0c2C6D3F77C", "0x8E155C02A1C952F991f5c044e70d6DD90A09feDD", "0x02698b5186CaaBCFa2DFD4DD252Ef96EBbcBA131", "0xd37849A8C4Df5295Dd4f94390D05Ac5221dD271d", "0x2f6D4060208fdBC1E410E96037287f6cEdE3af81", "0x58EA030FDAd59866df065fF19F00679e26d9dBA2", "0xB6d45f5236d2Fda75749cc1bAE8b658950b19202", "0x37aE8cF8D392f65a6517B1003D3596A722C6D94b", "0xe58c100b4A3E08F5cdBD954e2CbbB5b7E7a52b15", "0xcd17fFC6Fa721CBdEC1deE5Cee7B7643292699dF", "0x3097b4E6b308309A7001D111D29889630A0FD1ad", "0x1D0bD27449f08193433BE37B6bEABD79dCFcfde1", "0x2f26ae0568BD651318849c18F9Bc6776629d3bDA", "0x00347E05D7E0875f7d084DEa75A415d6B16Dc6da", "0xe4ef526473ACCbFC617451010bEB5Fbd68Fe816d", "0x5557d7fCd6D927F5b452312c02f92749F9Cb0aa6", "0x1F4eba197386D20191e2651584C99e12D5E6C6F2", "0x5D4B22F5317F1628FEb976A2f656b50764870bD5", "0xf1e5412126C18178d0C5B909CD40502d7F0652f1", "0xc8D62644DACF4e4653037D1be93C9dfA6ddF5C11", "0xEb9d8Db4A9D622ef21b68A34C2015fa364A3554e", "0x4Dc4080f2504731FfBd9B1469895dE42aC5e8188", "0xBB09c39C664B19d12e36ADF74963e11F00CE0804", "0xb772E527aD3a4F0d3f49f5048b55DD4c7f7f01E2", "0x932fB26111A80017cDf4D2dd75B79e1F4eAE9547", "0x8d2548Cec0ac6807C0131e33360AD6E1332fe929"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Transfer(address,address,uint256)", "Approval(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4492731 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4493530 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "ChickenToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "ChickenToken", function( accounts ) {

	it( "TEST: ChickenToken(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4492731", timeStamp: "1509853681", hash: "0xc4ff219bfb4b2bee0f790ac8b77350ba2896db8475cd0c5b5b5a874aa3278a91", nonce: "0", blockHash: "0x5c12583c6df33f7b9499f2a159dea9f21a184bb76c7b4f5578476785155fecfb", transactionIndex: "13", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: 0, value: "0", gas: "975093", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x94bede8b", contractAddress: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", cumulativeGasUsed: "1726959", gasUsed: "875093", confirmations: "3242138"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "ChickenToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = ChickenToken.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1509853681 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = ChickenToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493090", timeStamp: "1509858918", hash: "0xbc19a46ae7148c8d0237656843d767c695fba78830e27a2652af32d3bc736293", nonce: "1", blockHash: "0xd3940533104369a6545a7191478d47e7cbffdee6af249bce4d9272c4e9388da4", transactionIndex: "86", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000007332c2a5ba8be18362e0b5d74504597bb50b9fb5000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "4193697", gasUsed: "51915", confirmations: "3241779"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[4]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[4], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1509858918 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x7332c2a5ba8be18362e0b5d74504597bb50b9fb5"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[5], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493135", timeStamp: "1509859512", hash: "0xf03202bc581455899b58eb1f67d0cfb09d10a363974658a262599583182e5238", nonce: "2", blockHash: "0x64752f5ca81bd253f37d3e367892b5f18bb537f79d6b075fdec76573c87ffa5e", transactionIndex: "28", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000006a37746db47e4808f665ec1784351856dfcec106000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1254839", gasUsed: "51915", confirmations: "3241734"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[5]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[5], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1509859512 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x6a37746db47e4808f665ec1784351856dfcec106"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[6], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493148", timeStamp: "1509859650", hash: "0x1d7f79ee5659793f129a0b9c50924600eb2b42f5c307fd817fd08e2160dc13a6", nonce: "3", blockHash: "0x0f2ecb7f5cfc96aca61d7e0518ddf5afcc2572bc3de8281fcb831ab00d1c93a7", transactionIndex: "21", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000002629c3648491c065bf0792d3e333d2b84b810867000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "814927", gasUsed: "51915", confirmations: "3241721"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[6], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1509859650 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x2629c3648491c065bf0792d3e333d2b84b810867"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[7], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493192", timeStamp: "1509860042", hash: "0x2d0bb20fb21046814c5e3698273bc901eb90429b4ee147bfa631fe7517f40c8e", nonce: "4", blockHash: "0x4d5b27333a3fc4e0cc613fc46dda2076eac573c787c67ab309ac2fd811179a2b", transactionIndex: "24", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000bb943aff95ae90cceab03f7ffcc24b55385841da000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1024595", gasUsed: "51915", confirmations: "3241677"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[7]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[7], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1509860042 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xbb943aff95ae90cceab03f7ffcc24b55385841da"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493226", timeStamp: "1509860455", hash: "0x032406f96be1247793ada4cc5c85581d9645b9be3ee581bfabb9a34c76cddba9", nonce: "5", blockHash: "0xd483cbea6a77f0654ab1d3ac7311a11e29e649e647a88f7952847b0459140450", transactionIndex: "47", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151851", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000000231513adf1bb1feeb1f4ef5d18a15f5ff9e2db000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "2883072", gasUsed: "51851", confirmations: "3241643"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1509860455 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x00231513adf1bb1feeb1f4ef5d18a15f5ff9e2db"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[9], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493238", timeStamp: "1509860647", hash: "0x1413122a4014dbda09b3dcd65143213113052512e125fa9896f8635ad45fd0b3", nonce: "6", blockHash: "0x351836813ded3b3a397ed127740acfdb328c21f0985516885767405d12c7d55c", transactionIndex: "67", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000005e65220dbbeaf6d2528528142d5ea2cd1044567c000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "2206810", gasUsed: "51915", confirmations: "3241631"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[9], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1509860647 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x5e65220dbbeaf6d2528528142d5ea2cd1044567c"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493244", timeStamp: "1509860700", hash: "0x3cf0b92414622c15347a3770754dc80d38988fda8528e6c843ab1a2e693cfc0b", nonce: "7", blockHash: "0x81857da5cf52e3e8e49614784c5eeb1fe992ab78572b62746c7d0745166c9966", transactionIndex: "40", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000b482a0dc7c1f95ef89cbd23f2a57930c0365b3dd000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1695989", gasUsed: "51915", confirmations: "3241625"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1509860700 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xb482a0dc7c1f95ef89cbd23f2a57930c0365b3dd"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[11], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493249", timeStamp: "1509860755", hash: "0x6e97a8833fcb3f7b3b93a6e5f8e6f75d20bafc711e19412840a204885ce05a14", nonce: "8", blockHash: "0x8f507f729f5fb13c96f2333a22f7d02313ed62724f991b8cb84f0db30a311072", transactionIndex: "21", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000003030b94518fa058b7c464a08479823f0d792dbef000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "791435", gasUsed: "51915", confirmations: "3241620"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[11], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1509860755 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x3030b94518fa058b7c464a08479823f0d792dbef"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[12], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493254", timeStamp: "1509860818", hash: "0x64576ef441d749f9cea255f1ea332a98da008cfa8a3a1235b1bdbf85c4d2b6e4", nonce: "9", blockHash: "0x802e57f5f95aed26d3850d1f02870b5c77782bad52368e122903283e5b9a4f2b", transactionIndex: "58", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000009fd730ddeaad1063b025f6032847fc14eea3d68d000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1881328", gasUsed: "51915", confirmations: "3241615"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[12]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[12], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1509860818 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x9fd730ddeaad1063b025f6032847fc14eea3d68d"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[13], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493260", timeStamp: "1509860852", hash: "0xf6260a461011f5454e3431bc5a747ce4f6e4b272b84e25ed5e4b143024d3592a", nonce: "10", blockHash: "0x24702df91020127325a6e3fa21046db4ad3cf9e14e726eb0dfc62573176c92ad", transactionIndex: "12", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000d511b3e3751008ecca9b9cdb2488bc39b70d7441000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "382354", gasUsed: "51915", confirmations: "3241609"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[13], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1509860852 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xd511b3e3751008ecca9b9cdb2488bc39b70d7441"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[14], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493295", timeStamp: "1509861245", hash: "0xf58ff651ea5a6af5f3562f8d931f6dc8ab662d65ac8ab9858fe36aef7a859123", nonce: "11", blockHash: "0x644671624172232ceb9d3785a4441c080350bdaa83848161f778a131451a7a64", transactionIndex: "28", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000b21f458f6f9245fcd7de0837bec48577f665b274000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1482103", gasUsed: "51915", confirmations: "3241574"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[14]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[14], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1509861245 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xb21f458f6f9245fcd7de0837bec48577f665b274"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[15], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493296", timeStamp: "1509861254", hash: "0xb40fb929eaa4d5705f7ce211cc5cace2952e4e946c41e54ad723395f27b0c31a", nonce: "12", blockHash: "0x161c16589ebce0fd8232a11ba7850cf7913ebd74ad33f1df28a7225506e79851", transactionIndex: "10", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000002caed06c459de7fe538ae908b35384deb3980644000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "726625", gasUsed: "51915", confirmations: "3241573"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[15]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[15], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1509861254 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x2caed06c459de7fe538ae908b35384deb3980644"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[16], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493308", timeStamp: "1509861398", hash: "0xfa640b01ce6d30b8190ca99efa94c0914665d69143edcfbbdb01eddb48881806", nonce: "13", blockHash: "0x19684b2e2e83797aaa647d530eeed4f0f3bf4331a8d716bb617bca986cb79b2e", transactionIndex: "41", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000b58d9445ecd5d8d3a9bcf618336bf8544a96f1dd000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1509231", gasUsed: "51915", confirmations: "3241561"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[16]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[16], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1509861398 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xb58d9445ecd5d8d3a9bcf618336bf8544a96f1dd"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[17], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493312", timeStamp: "1509861478", hash: "0xb92fdcbd14f0307e651a511fbccfa47ffc6a672fd61a5b3346cac82adb87ee0f", nonce: "14", blockHash: "0xe22647c652a0042679253fcba3bbcd8063490e285743140a5003fa8ef6b097d1", transactionIndex: "43", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000a893e2816e3ddcc270dfef6d0aa771053e16a567000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "2364242", gasUsed: "51915", confirmations: "3241557"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[17], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1509861478 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xa893e2816e3ddcc270dfef6d0aa771053e16a567"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[18], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493312", timeStamp: "1509861478", hash: "0xff4242277ff2d3c87494ce8cfdae6d358e81e1bb9dca6f55caafd7b394ed4a88", nonce: "15", blockHash: "0xe22647c652a0042679253fcba3bbcd8063490e285743140a5003fa8ef6b097d1", transactionIndex: "103", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000006c2e4cd0deb91bccca154f4f702503a49895f592000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "6150807", gasUsed: "51915", confirmations: "3241557"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[18]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[18], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1509861478 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x6c2e4cd0deb91bccca154f4f702503a49895f592"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[19], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493314", timeStamp: "1509861515", hash: "0x41d2a58432156d5cc7fe402281f2afdf0c0a25955f6fa399e4021a3412aafbd3", nonce: "16", blockHash: "0xb4735e6da8789401d4c4d0b04acb8ef4ed9df37e24b8db57d7c5c4236851a1ad", transactionIndex: "44", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000819aa5c4ba40a5362a898c59fddde82b89636376000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "3092455", gasUsed: "51915", confirmations: "3241555"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[19]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[19], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1509861515 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x819aa5c4ba40a5362a898c59fddde82b89636376"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[20], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493317", timeStamp: "1509861582", hash: "0xe076c8e9a3ef2c22892c294868883644feef27daf1bbac9e3cf66c8ef62c664f", nonce: "17", blockHash: "0x68984a0a905968a047d8cca1ccb4c29f96d4452ef1243d000847eca7f5586bc9", transactionIndex: "59", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000003ff85784d06a124798a09eb6f27fef4b3c879dfd000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "3604261", gasUsed: "51915", confirmations: "3241552"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[20], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1509861582 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x3ff85784d06a124798a09eb6f27fef4b3c879dfd"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[21], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493322", timeStamp: "1509861642", hash: "0xc790219af1335f89b084d5360f5e36676978b889503038e62023899e51448ef6", nonce: "18", blockHash: "0x8422eb85cd0e65df5aefbd30abf974ae863051934edc08b7c04e7fdf5acff990", transactionIndex: "78", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151851", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000e56f77004a18d474396163be9467db0cab7a1c5f000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "3859696", gasUsed: "51851", confirmations: "3241547"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[21]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[21], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1509861642 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xe56f77004a18d474396163be9467db0cab7a1c5f"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493345", timeStamp: "1509861939", hash: "0x03eae6217a8a4d3ef9d5b00abe80ad2a3e7b62e4b7c0056b607a1a050c9f5395", nonce: "19", blockHash: "0xeb5cf9809b96045730f04cd61332a7aac582f7e50ba00a08efd7dc0b15882a10", transactionIndex: "39", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000eba5175bbd03df1ff1c733dc6bba681cdb35a3b4000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1162999", gasUsed: "51915", confirmations: "3241524"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1509861939 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xeba5175bbd03df1ff1c733dc6bba681cdb35a3b4"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[23], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493347", timeStamp: "1509861984", hash: "0x0f3ab042060f26887370cc030148157863a86d02c31c7f2a4327f25d9b99589f", nonce: "20", blockHash: "0x2169c838052ce0ced9466a3a3c350b65bef5f86e8de73693095b02fe4f4ad1fa", transactionIndex: "16", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000fc2752e35b62a29e7d24e607c6b55eef39ef561f000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "598458", gasUsed: "51915", confirmations: "3241522"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[23]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[23], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1509861984 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xfc2752e35b62a29e7d24e607c6b55eef39ef561f"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[24], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493352", timeStamp: "1509862107", hash: "0x138d2c53d274555d40338eb8eecb7fb2e5a28fd4c6c63b24668e01fa639156b8", nonce: "21", blockHash: "0x1c5e42554f5c3b60aaa18bd1250c57a35a03c5f5ecfc81c2797f2225b6e9da85", transactionIndex: "108", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000b230f17085f79a65e65725a47d2baf6f6bf7a17b000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "5951973", gasUsed: "51915", confirmations: "3241517"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[24], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1509862107 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xb230f17085f79a65e65725a47d2baf6f6bf7a17b"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[25], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493355", timeStamp: "1509862184", hash: "0x5639e9c06a1d8f27441076d2744bfd5e2acb65ef1bacbcafd90b7f5b44716fd9", nonce: "22", blockHash: "0xb918e0fae1e84e357af209d913f84a9e38c99e7949bc5dae5365f53268d7ba0a", transactionIndex: "98", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000004ce7294d0c31f2fb8de83d914357a2f1f0ea72d9000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "5128655", gasUsed: "51915", confirmations: "3241514"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[25]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[25], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1509862184 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x4ce7294d0c31f2fb8de83d914357a2f1f0ea72d9"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[26], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493362", timeStamp: "1509862233", hash: "0x8f374d42b8308a35ae776a83d3aad13fd3ad631b18fa605d4b216f76cd5f57de", nonce: "23", blockHash: "0x52400d68977ed5f9b99669d858d6ecc6dd462daa5927a663888ebe424d1cdc6a", transactionIndex: "16", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151851", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000afc092e6fdd10f28d93abd00d1e427effdaad39c000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "478544", gasUsed: "51851", confirmations: "3241507"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[26]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[26], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1509862233 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xafc092e6fdd10f28d93abd00d1e427effdaad39c"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[27], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493366", timeStamp: "1509862287", hash: "0x04f62a2a369a82b0ca4c86f022ee870ce0142e7d13aa3b8242a61abdc6d60b87", nonce: "24", blockHash: "0x3a74bc61c9a0b98c43af163de5bc6fd536494d1b1048ef6be67349e1ded15c05", transactionIndex: "23", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000055c556832466bccef30486aaf3dae0c2c6d3f77c000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1851580", gasUsed: "51915", confirmations: "3241503"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[27]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[27], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1509862287 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x55c556832466bccef30486aaf3dae0c2c6d3f77c"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[28], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493405", timeStamp: "1509862663", hash: "0x9ac1eba10bedd02e77dcc3da51ec486f24074bb2342b21a7e266addf50fea823", nonce: "25", blockHash: "0xb3c0a53358e7f6ffc89dde14d99c28e848b0b6b0d75448621913cd07cab4777d", transactionIndex: "53", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000008e155c02a1c952f991f5c044e70d6dd90a09fedd000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1714625", gasUsed: "51915", confirmations: "3241464"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[28]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[28], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1509862663 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x8e155c02a1c952f991f5c044e70d6dd90a09fedd"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[29], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493409", timeStamp: "1509862685", hash: "0x1df7c86190bf44a292d9e96ec5abdc59daf9a17779726e52f0c2edb14309796e", nonce: "26", blockHash: "0x3b610ec25e1df7558a0503a805659118b60a3a3e304f5585fae87dad656a0e40", transactionIndex: "16", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000002698b5186caabcfa2dfd4dd252ef96ebbcba131000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "924956", gasUsed: "51915", confirmations: "3241460"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[29], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1509862685 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x02698b5186caabcfa2dfd4dd252ef96ebbcba131"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[30], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493412", timeStamp: "1509862747", hash: "0x1fed42f3bd8f9ba0710157d5affa39e22486a0172e1e960e2b45f41deab9605a", nonce: "27", blockHash: "0xec529ecba69fd112157557f2627a26597896ba01fd798cdb9486429445b4539e", transactionIndex: "55", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000d37849a8c4df5295dd4f94390d05ac5221dd271d000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "2237679", gasUsed: "51915", confirmations: "3241457"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[30]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[30], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1509862747 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xd37849a8c4df5295dd4f94390d05ac5221dd271d"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[31], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493413", timeStamp: "1509862782", hash: "0xecc1fa21166193d31a712e6ad69004cfabfce59e50cc7bf8169789a6a79693ad", nonce: "28", blockHash: "0x432101e7b5990af5dd1b89871c47a707f45ebdaffa7d84936eef090c019aa581", transactionIndex: "37", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000002f6d4060208fdbc1e410e96037287f6cede3af81000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1576405", gasUsed: "51915", confirmations: "3241456"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[31]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[31], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1509862782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x2f6d4060208fdbc1e410e96037287f6cede3af81"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[32], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493421", timeStamp: "1509862886", hash: "0x0770910795793a8977ea92c80621488f854dba29b82fa1e97080fa6941e7aaae", nonce: "29", blockHash: "0xd851b5e3554b0267632ca4c78ff782bef55f26ab7e44af41b50a9ffeb3306b64", transactionIndex: "84", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151851", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000058ea030fdad59866df065ff19f00679e26d9dba2000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "2518361", gasUsed: "51851", confirmations: "3241448"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[32]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[32], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1509862886 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x58ea030fdad59866df065ff19f00679e26d9dba2"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[33], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493427", timeStamp: "1509862916", hash: "0x887c5b462dc0e86cf067d2d5a5fab7bb3f27a2ab1556313415adfc68a0412758", nonce: "30", blockHash: "0x3cdf702a3289301637ed7e5b989c05a548c617d4aef29b8c750b5527e01c572b", transactionIndex: "32", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151884", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000b6d45f5236d2fda75749cc1bae8b658950b19202000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "2693300", gasUsed: "51915", confirmations: "3241442"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[33]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[33], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1509862916 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xb6d45f5236d2fda75749cc1bae8b658950b19202"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[34], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493434", timeStamp: "1509863040", hash: "0xd97f37cae8d2788f4d146dd217ca1c6a4ff8be343fdb6c736bd073db7e87a56a", nonce: "31", blockHash: "0xe6bd62955500279df86e8630f370ba1e24eada436c1d5047a4026fea80a4f728", transactionIndex: "23", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151851", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000037ae8cf8d392f65a6517b1003d3596a722c6d94b000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "913091", gasUsed: "51851", confirmations: "3241435"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[34]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[34], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1509863040 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x37ae8cf8d392f65a6517b1003d3596a722c6d94b"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[35], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493438", timeStamp: "1509863081", hash: "0x3c82fd67b62bfce200cec1be0468eb776f7731eb3f2ccac33c221f28e584a55c", nonce: "32", blockHash: "0xb30b8c8e00932251b1c97dab4733c0f3382a60dbbf6b52ff785db6b7bac5036e", transactionIndex: "36", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000e58c100b4a3e08f5cdbd954e2cbbb5b7e7a52b15000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1908740", gasUsed: "51915", confirmations: "3241431"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[35]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[35], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1509863081 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xe58c100b4a3e08f5cdbd954e2cbbb5b7e7a52b15"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[36], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493447", timeStamp: "1509863173", hash: "0x5161a890a17db1fc1f05560bd4880563dabc6e1a88e05221252cb5b20aeec669", nonce: "33", blockHash: "0x7c312b87755d837576251dc232194f45012285681295691cd7f1cc03213ce18e", transactionIndex: "48", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000cd17ffc6fa721cbdec1dee5cee7b7643292699df000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1759321", gasUsed: "51915", confirmations: "3241422"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[36]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[36], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1509863173 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xcd17ffc6fa721cbdec1dee5cee7b7643292699df"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[37], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493452", timeStamp: "1509863246", hash: "0x1900265a3ec32f5ff4d59471de7ec28e2d5efd1b25d0a60023d014e7a244988d", nonce: "34", blockHash: "0xa07defe3820de0cbd4c1b13698e4bd79dca4bed66568371598500d67cca24ef3", transactionIndex: "35", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000003097b4e6b308309a7001d111d29889630a0fd1ad000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1673649", gasUsed: "51915", confirmations: "3241417"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[37]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[37], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1509863246 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x3097b4e6b308309a7001d111d29889630a0fd1ad"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[38], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493457", timeStamp: "1509863303", hash: "0xf67240d8683899344e311eaea24f04d4a861e8374a001e7faaf7da35ae6c1a3e", nonce: "35", blockHash: "0x66f552af75744a2f9f2855daec53c42169e35eed7a227554701d9bf7e3c80939", transactionIndex: "74", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000001d0bd27449f08193433be37b6beabd79dcfcfde1000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "3507076", gasUsed: "51915", confirmations: "3241412"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[38]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[38], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1509863303 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x1d0bd27449f08193433be37b6beabd79dcfcfde1"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[39], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493460", timeStamp: "1509863336", hash: "0x66c0b64356cccc51082619d8a27f2696d32b9120565d316b927e62fe577d0f15", nonce: "36", blockHash: "0xc898920701e4925c8ccf5fc380d3c857db3ee208ad735dd5fba5244d5053c600", transactionIndex: "13", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000002f26ae0568bd651318849c18f9bc6776629d3bda000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1321689", gasUsed: "51915", confirmations: "3241409"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[39]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[39], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1509863336 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x2f26ae0568bd651318849c18f9bc6776629d3bda"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[40], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493466", timeStamp: "1509863407", hash: "0x7d94c052484eff96effcbcddfb0df519d1bac30ac5b61f24415ed488d725b3be", nonce: "37", blockHash: "0x6504947c81b18f2ddb6f457dbf08bffdd2e01be71bb15f846952d0233dcb5512", transactionIndex: "20", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151851", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000000347e05d7e0875f7d084dea75a415d6b16dc6da000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "730184", gasUsed: "51851", confirmations: "3241403"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[40]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[40], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1509863407 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x00347e05d7e0875f7d084dea75a415d6b16dc6da"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[41], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493467", timeStamp: "1509863454", hash: "0xfe6c7b8d382d2ec4c7fe62336a3c88fdc9c3d879acd39be71aa0062a32e45b32", nonce: "38", blockHash: "0x9b731e00b52e7517961c3155a20cc0f361392bdb92925e976473486093b7f2ce", transactionIndex: "71", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000e4ef526473accbfc617451010beb5fbd68fe816d000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "2446035", gasUsed: "51915", confirmations: "3241402"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[41]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[41], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1509863454 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xe4ef526473accbfc617451010beb5fbd68fe816d"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[42], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493479", timeStamp: "1509863637", hash: "0xcec65901083f46adc45987565574be6ccb4637f6e67e5018ae6e5064d656b97c", nonce: "39", blockHash: "0x8b2492c53a3ca1242d3b66b3fe856e2a6fd582e6c9599dea79589d20d08d8582", transactionIndex: "37", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000005557d7fcd6d927f5b452312c02f92749f9cb0aa6000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1674243", gasUsed: "51915", confirmations: "3241390"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[42]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[42], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1509863637 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x5557d7fcd6d927f5b452312c02f92749f9cb0aa6"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[43], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493484", timeStamp: "1509863691", hash: "0x522fb2677b37a44a36759c4f99b2629fbdd9c792842acfa17afc2780f6f892b7", nonce: "40", blockHash: "0xa6e5e01de1ab22af2b62c486d6eac1ab46ae96bf3ce6da76d163ab5c76cfa2c7", transactionIndex: "42", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000001f4eba197386d20191e2651584c99e12d5e6c6f2000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1541524", gasUsed: "51915", confirmations: "3241385"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[43]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[43], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1509863691 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x1f4eba197386d20191e2651584c99e12d5e6c6f2"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[44], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493485", timeStamp: "1509863718", hash: "0x8461623a64e036d40904d7b679ef9e7d8e7a2da8bdee8097cb418f07cc964649", nonce: "41", blockHash: "0xb10e280ae8d8e9f3bbe0e03f32c90e67aff708ab4800f0de831bdbdb831e3128", transactionIndex: "30", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000005d4b22f5317f1628feb976a2f656b50764870bd5000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1441312", gasUsed: "51915", confirmations: "3241384"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[44]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[44], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1509863718 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x5d4b22f5317f1628feb976a2f656b50764870bd5"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[45], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493487", timeStamp: "1509863736", hash: "0xe66f7c4cce4763e2d82fed2f218346d749ee99720c1fbf79b04ad9868211f175", nonce: "42", blockHash: "0xc44d67c117b3241a442e67aabbd4a09aece19360b52e7c27a148234bccd477e5", transactionIndex: "22", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000f1e5412126c18178d0c5b909cd40502d7f0652f1000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1225584", gasUsed: "51915", confirmations: "3241382"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[45]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[45], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1509863736 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xf1e5412126c18178d0c5b909cd40502d7f0652f1"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[46], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493495", timeStamp: "1509863784", hash: "0x435b31b9f5771e5ae6b74ac23db0c382b0ccdeb9a98991352b8ab0994ad754c6", nonce: "43", blockHash: "0xdb4aa77af41b6a22560780e90ca416f2856e244c840c860cf1ef3ca7d58252f6", transactionIndex: "16", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000c8d62644dacf4e4653037d1be93c9dfa6ddf5c11000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "739997", gasUsed: "51915", confirmations: "3241374"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[46]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[46], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1509863784 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xc8d62644dacf4e4653037d1be93c9dfa6ddf5c11"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[47], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493500", timeStamp: "1509863852", hash: "0xdbdfebbd1be281da85d4b2c47927cf2a37de6b9bc86282287bc5e55cd96a737b", nonce: "44", blockHash: "0xf86f97c1a5ec19e4d1ca527c9cd60d7651f7cc295ea1db398b26dbef47bbe7e6", transactionIndex: "44", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000eb9d8db4a9d622ef21b68a34c2015fa364a3554e000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1647868", gasUsed: "51915", confirmations: "3241369"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[47]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[47], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1509863852 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xeb9d8db4a9d622ef21b68a34c2015fa364a3554e"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[48], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493511", timeStamp: "1509863956", hash: "0x1e10477af75c073c93ae487cd8c3d5dbd8dad6f706c70d8097532485ada65b8e", nonce: "45", blockHash: "0x18dd26bd004f0269959119f9d8324a2c07c4cd12e3cf173b8a30393a1e11b484", transactionIndex: "23", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000004dc4080f2504731ffbd9b1469895de42ac5e8188000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "827706", gasUsed: "51915", confirmations: "3241358"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[48]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[48], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1509863956 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x4dc4080f2504731ffbd9b1469895de42ac5e8188"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[49], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493518", timeStamp: "1509864046", hash: "0x2aa777eb85e9edeb86de019f1cd743f90497e6bb2009ea2f0ab6cdd58ffd3ff6", nonce: "46", blockHash: "0x3c47acf33d74643c10cc1a45b9989467b012db388ad9d6db5f84ea1675a6d257", transactionIndex: "39", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151851", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000bb09c39c664b19d12e36adf74963e11f00ce0804000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1356460", gasUsed: "51851", confirmations: "3241351"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[49]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[49], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1509864046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xbb09c39c664b19d12e36adf74963e11f00ce0804"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[50], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493526", timeStamp: "1509864170", hash: "0x1fd4220fee87e13b2d87695f1de7218dbc33253365ce0c9a9eccb76f40dcb64c", nonce: "47", blockHash: "0x6b7f28a25efd427ca50168a7f8e03e2d8c0bac648e8f1a2003177a30af0dfba1", transactionIndex: "47", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000b772e527ad3a4f0d3f49f5048b55dd4c7f7f01e2000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1747834", gasUsed: "51915", confirmations: "3241343"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[50]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[50], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1509864170 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0xb772e527ad3a4f0d3f49f5048b55dd4c7f7f01e2"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[51], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493529", timeStamp: "1509864216", hash: "0xd7574e500247729cacf6d173fa49c5d90efefc575f8e64d931dd69091747afa3", nonce: "48", blockHash: "0x3440b52d45b25343ee1b8bb62493756990bd0222d2ac9fcaf8b17551fb4fa01b", transactionIndex: "25", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151851", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000932fb26111a80017cdf4d2dd75b79e1f4eae9547000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "894077", gasUsed: "51851", confirmations: "3241340"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[51]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[51], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1509864216 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x932fb26111a80017cdf4d2dd75b79e1f4eae9547"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[52], \"1000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4493530", timeStamp: "1509864238", hash: "0x9680c0d8da0fd94363c84017089a57a062295164c34e017dac41e802bb99cdfa", nonce: "49", blockHash: "0x2e83543d7ea479237bb7b3966afe2552c0df3d10da7f2dd974f0777d6f883f1e", transactionIndex: "29", from: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c", to: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e", value: "0", gas: "151915", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000008d2548cec0ac6807c0131e33360ad6e1332fe929000000000000000000000000000000000000000000000000000000e8d4a51000", contractAddress: "", cumulativeGasUsed: "1688298", gasUsed: "51915", confirmations: "3241339"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[52]}, {type: "uint256", name: "_value", value: "1000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[52], "1000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1509864238 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xbe87b792b8c1e311d24eed1b67afa5f39d6c1f8c"}, {name: "to", type: "address", value: "0x8d2548cec0ac6807c0131e33360ad6e1332fe929"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0x7d9238e1c39e91089bfe5e72a503e32f2dac526e"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1008446025000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
