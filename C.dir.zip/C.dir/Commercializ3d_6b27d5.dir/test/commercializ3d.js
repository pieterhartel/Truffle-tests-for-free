const Commercializ3d = artifacts.require( "./Commercializ3d.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Commercializ3d" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x480D08a87e9D23704DFbDC296Afc3436fe6b27D5", "0xB3775fB83F7D12A36E0475aBdD1FCA35c091efBe", "0xB111DaBb8EdD8260B5c1E471945A62bE2eE24470", "0x008d8fF688E895A0607e4135E5e18C22f41D7885", "0xF416D2D8F2739Ca7CF6d05e2b4aD509FAfc42f78", "0x5d4d49BFfC0A0a7F640766781AD96e1ff4FBD46f", "0x4Ea6A7820bFeEc2C1DE3F2e3466f6624d6bBCB7E", "0x3674840e64A5B2176052d9F65A9AC7e8dBF7bD5F"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "totalPayments", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "nextJackpot", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "jackpot", type: "uint256"}], name: "_winnerJackpot", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "getSquarePriceAuction", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tax", type: "uint256"}], name: "_jackpotTax", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "auctionDuration", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startingRoundExtension", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getDivsBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "jackpot", type: "uint256"}], name: "_nextPotJackpot", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "startingAuctionPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tax", type: "uint256"}, {name: "hasReferrer", type: "bool"}], name: "_teamTax", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "endingAuctionPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "roundNumber", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "halvingVolume", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "numBoughtSquares", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxSquareId", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "jackpot", type: "uint256"}], name: "_landholderJackpot", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "jackpot", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tax", type: "uint256"}], name: "_totalLandholderTax", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "minSquareId", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint8"}], name: "squareToOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tax", type: "uint256"}], name: "_nextPotTax", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "curExtensionVolume", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "numSquares", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "price", type: "uint256"}], name: "_priceToTax", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "tax", type: "uint256"}, {name: "hasReferrer", type: "bool"}], name: "_referrerTax", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "roundTimeRemaining", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getP3DBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "stage", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "curRoundExtension", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint8"}], name: "squareToPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSquareValue", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "jackpot", type: "uint256"}], name: "_teamJackpot", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "tokens", type: "uint256"}], name: "_p3dSellPercentage", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "minRoundExtension", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "payments", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "roundEndTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "auctionStartTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "startingAuctionPrice", type: "uint256"}, {indexed: false, name: "endingAuctionPrice", type: "uint256"}, {indexed: false, name: "auctionDuration", type: "uint256"}, {indexed: false, name: "startTime", type: "uint256"}], name: "AuctionStarted", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "endTime", type: "uint256"}], name: "AuctionEnded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "owner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquarePriceChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "initJackpot", type: "uint256"}, {indexed: false, name: "endTime", type: "uint256"}, {indexed: false, name: "roundNumber", type: "uint256"}], name: "GameRoundStarted", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "endTime", type: "uint256"}], name: "GameRoundExtended", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "jackpot", type: "uint256"}], name: "GameRoundEnded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["SquareOwnerChanged(uint8,address,address,uint256,uint256)", "AuctionStarted(uint256,uint256,uint256,uint256)", "AuctionEnded(uint256)", "SquarePriceChanged(uint8,address,uint256,uint256)", "GameRoundStarted(uint256,uint256,uint256)", "GameRoundExtended(uint256)", "GameRoundEnded(uint256)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x4e5aa74ac1b56e2a0d691b5d2db0bd91417057e77e81073b3745ff23e4c774f1", "0xa832766a05f1bd0298b0268308621777cfe1e4eea23afe7c06beea79bc6ddd2d", "0x45806e512b1f4f10e33e8b3cb64d1d11d998d8c554a95e0841fc1c701278bd5d", "0x78a0831562a50ccc2189fcaaed893188d2402667d2592508d55d1f7d13ee3d20", "0x8dbc109f2b860f13cb31cb0e968bcd6324ad443f6cc2853fdf3ca82904a8a008", "0xe3663e221e6fb10518d40e9d9a20cd6f59853232fbfebc7de3821ed0c8fb36d2", "0x3cf3fa68b629d58f07a4aab1808a70df09365f335635faa68ce0478aee6d8abc", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6916835 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6917677 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "uint256", name: "startingStage", value: "0"}], name: "Commercializ3d", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "totalPayments", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalPayments()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "nextJackpot", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nextJackpot()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "jackpot", value: random.range( maxRandom )}], name: "_winnerJackpot", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_winnerJackpot(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getSquarePriceAuction", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getSquarePriceAuction()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tax", value: random.range( maxRandom )}], name: "_jackpotTax", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_jackpotTax(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "auctionDuration", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "auctionDuration()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startingRoundExtension", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startingRoundExtension()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getDivsBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDivsBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "jackpot", value: random.range( maxRandom )}], name: "_nextPotJackpot", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_nextPotJackpot(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startingAuctionPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startingAuctionPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tax", value: random.range( maxRandom )}, {type: "bool", name: "hasReferrer", value: ( random.range( 2 ) === 0 )}], name: "_teamTax", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_teamTax(uint256,bool)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "endingAuctionPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endingAuctionPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "roundNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "roundNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "halvingVolume", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "halvingVolume()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numBoughtSquares", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numBoughtSquares()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxSquareId", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxSquareId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "jackpot", value: random.range( maxRandom )}], name: "_landholderJackpot", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_landholderJackpot(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "jackpot", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "jackpot()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tax", value: random.range( maxRandom )}], name: "_totalLandholderTax", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_totalLandholderTax(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minSquareId", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minSquareId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint8", name: "", value: random.range( maxRandom )}], name: "squareToOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "squareToOwner(uint8)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tax", value: random.range( maxRandom )}], name: "_nextPotTax", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_nextPotTax(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "curExtensionVolume", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "curExtensionVolume()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numSquares", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numSquares()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "price", value: random.range( maxRandom )}], name: "_priceToTax", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_priceToTax(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tax", value: random.range( maxRandom )}, {type: "bool", name: "hasReferrer", value: ( random.range( 2 ) === 0 )}], name: "_referrerTax", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_referrerTax(uint256,bool)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "roundTimeRemaining", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "roundTimeRemaining()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getP3DBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getP3DBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "stage", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "stage()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "curRoundExtension", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "curRoundExtension()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint8", name: "", value: random.range( maxRandom )}], name: "squareToPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "squareToPrice(uint8)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSquareValue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSquareValue()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "jackpot", value: random.range( maxRandom )}], name: "_teamJackpot", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",33] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_teamJackpot(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",33] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tokens", value: random.range( maxRandom )}], name: "_p3dSellPercentage", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",34] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_p3dSellPercentage(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",34] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minRoundExtension", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",35] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minRoundExtension()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",35] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "payments", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",36] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "payments(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",36] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "roundEndTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",37] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "roundEndTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",37] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "auctionStartTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",38] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "auctionStartTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",38] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Commercializ3d", function( accounts ) {

	it( "TEST: Commercializ3d( \"0\" )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6916835", timeStamp: "1545251081", hash: "0x53f2a4765f6f173f26e71235c104e0dfa97c4c5fb8838ea03e468e993ef6a1a6", nonce: "36", blockHash: "0x8714ae667a88e806b66b882f806d6f15ba6a39852d706617f2eb00ac983b0031", transactionIndex: "30", from: "0x008d8ff688e895a0607e4135e5e18c22f41d7885", to: 0, value: "0", gas: "3456001", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x037134f90000000000000000000000000000000000000000000000000000000000000000", contractAddress: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", cumulativeGasUsed: "4623235", gasUsed: "3456001", confirmations: "758911"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "startingStage", value: "0"}], name: "Commercializ3d", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Commercializ3d.new( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1545251081 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Commercializ3d.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "startingAuctionPrice", type: "uint256"}, {indexed: false, name: "endingAuctionPrice", type: "uint256"}, {indexed: false, name: "auctionDuration", type: "uint256"}, {indexed: false, name: "startTime", type: "uint256"}], name: "AuctionStarted", type: "event"} ;
		console.error( "eventCallOriginal[0,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AuctionStarted", events: [{name: "startingAuctionPrice", type: "uint256", value: "100000000000000000"}, {name: "endingAuctionPrice", type: "uint256", value: "50000000000000000"}, {name: "auctionDuration", type: "uint256", value: "432000"}, {name: "startTime", type: "uint256", value: "1545251081"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[0,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "23832350582427762" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"10\", \"1000000000000000000\", address... )", async function( ) {
		const txOriginal = {blockNumber: "6916859", timeStamp: "1545251422", hash: "0x2cbea0096d0465edb2f9db931e13acf91bbffc5b0daeab8578e4faf07bf52c33", nonce: "52", blockHash: "0x0b308461f3245ecbf230a978dc4e69444277e190f0c6cd7095c6793a6816a25b", transactionIndex: "35", from: "0xf416d2d8f2739ca7cf6d05e2b4ad509fafc42f78", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "150000000000000000", gas: "414708", gasPrice: "2300000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000f416d2d8f2739ca7cf6d05e2b4ad509fafc42f78", contractAddress: "", cumulativeGasUsed: "7603940", gasUsed: "276472", confirmations: "758887"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "150000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "10"}, {type: "uint256", name: "newPrice", value: "1000000000000000000"}, {type: "address", name: "referrer", value: addressList[6]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "10", "1000000000000000000", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1545251422 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "10"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0xf416d2d8f2739ca7cf6d05e2b4ad509fafc42f78"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "1000000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "47208293927697984" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"6\", \"500000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6916880", timeStamp: "1545251749", hash: "0xbdd076a535b22716100b03435729c96f335c5c3e0d649d434268defdaa549014", nonce: "53", blockHash: "0x7bc4b04c093b4e60df95d46533b61b4c15f60140a6e6c3027a66e15ebde5fc5f", transactionIndex: "93", from: "0xf416d2d8f2739ca7cf6d05e2b4ad509fafc42f78", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "100000000000000000", gas: "275677", gasPrice: "2130000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000f416d2d8f2739ca7cf6d05e2b4ad509fafc42f78", contractAddress: "", cumulativeGasUsed: "7603220", gasUsed: "183785", confirmations: "758866"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "6"}, {type: "uint256", name: "newPrice", value: "500000000000000000"}, {type: "address", name: "referrer", value: addressList[6]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "6", "500000000000000000", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1545251749 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "6"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0xf416d2d8f2739ca7cf6d05e2b4ad509fafc42f78"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "500000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "47208293927697984" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"1\", \"400000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6916891", timeStamp: "1545251948", hash: "0xfea8d16e9fa9bbb87ce2b081412ca86126d6d0a28f26259db5f949d318f5e9e4", nonce: "17", blockHash: "0x1f632579ed93c4c9f505cf77eb9db8a4696cfd6ce341fe80a6d1a0728880b834", transactionIndex: "148", from: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "90000000000000000", gas: "316647", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000058d15e176280000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7026007", gasUsed: "211098", confirmations: "758855"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "90000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "1"}, {type: "uint256", name: "newPrice", value: "400000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "1", "400000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1545251948 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "1"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "400000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6527500912907291" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"18\", \"230000000000000000\", addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6916894", timeStamp: "1545251981", hash: "0xa9ca61669ab05a5041254aedc44da8397f3071e993a51e001f95bf9aaa8222a9", nonce: "18", blockHash: "0xcc5082e8385f71ad58110c95230d8bf6745efe2d0d89f46657e10de52452cb58", transactionIndex: "90", from: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "73000000000000000", gas: "316647", gasPrice: "3300000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000003311fc80a570000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "5578882", gasUsed: "223411", confirmations: "758852"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "73000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "18"}, {type: "uint256", name: "newPrice", value: "230000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "18", "230000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1545251981 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "18"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "230000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6527500912907291" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPayments(  )", async function( ) {
		const txOriginal = {blockNumber: "6916905", timeStamp: "1545252137", hash: "0x452cb0eb10ccf0770ffe1df55385281ee6d51d30425a9b3c15b51670f1ef1f24", nonce: "54", blockHash: "0xe5f163501e1cc83a6d7029adc03be8b98806e530b201a4882a195ffb645da84a", transactionIndex: "120", from: "0xf416d2d8f2739ca7cf6d05e2b4ad509fafc42f78", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "0", gas: "64158", gasPrice: "3080000000", isError: "0", txreceipt_status: "1", input: "0x6103d70b", contractAddress: "", cumulativeGasUsed: "6653475", gasUsed: "25521", confirmations: "758841"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPayments", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPayments()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1545252137 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "47208293927697984" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"19\", \"200000000000000000\", addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6916941", timeStamp: "1545252682", hash: "0xf237e455294e8eb05a32574a298b5a3767530d1dddc0802ee6ff0c7765b1b307", nonce: "19", blockHash: "0xad836c191e7369b97f103f1a94e8cb236b32b85ad1f20764f42c7789d3b30e64", transactionIndex: "112", from: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "70000000000000010", gas: "353586", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000001300000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "6287745", gasUsed: "235724", confirmations: "758805"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "70000000000000010" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "19"}, {type: "uint256", name: "newPrice", value: "200000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "19", "200000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1545252682 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "19"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "200000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6527500912907291" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"14\", \"200000000000000000\", addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6916944", timeStamp: "1545252725", hash: "0x799bb729d15bab7cc3da1fc8dbe44a1f6e26c917a05c85902c9f42e9615d8fa2", nonce: "20", blockHash: "0x8dfc1ef9b0f3557559eebfad7b1b6f95f286b889b7629b82276f8d2f4b3eb20a", transactionIndex: "85", from: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "70000000000000010", gas: "353586", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "4807323", gasUsed: "233037", confirmations: "758802"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "70000000000000010" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "14"}, {type: "uint256", name: "newPrice", value: "200000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "14", "200000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1545252725 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "14"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "200000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6527500912907291" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"15\", \"200000000000000000\", addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6916946", timeStamp: "1545252738", hash: "0x1004dfaa814767404c7df2fe157d25c62bd4c99b30096dc7091273a7a262c445", nonce: "21", blockHash: "0xc95106b5366adb3b170fab608bf748e156e5b230615cd8f68756e48185ae5dc9", transactionIndex: "28", from: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "70000000000000010", gas: "353586", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "2393440", gasUsed: "245350", confirmations: "758800"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "70000000000000010" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "15"}, {type: "uint256", name: "newPrice", value: "200000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "15", "200000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1545252738 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "15"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "200000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6527500912907291" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"8\", \"200000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6916948", timeStamp: "1545252748", hash: "0x4f6cf4aba324d2bff5bcea20364fc512663e389fc205386f2f4fe89336a74172", nonce: "22", blockHash: "0xd94f6f2640e124dd642ee4f3d709dccc5cd253578610d10f933089af39bd9007", transactionIndex: "24", from: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "70000000000000010", gas: "349555", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "1384306", gasUsed: "257663", confirmations: "758798"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "70000000000000010" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "8"}, {type: "uint256", name: "newPrice", value: "200000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "8", "200000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1545252748 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "8"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "200000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6527500912907291" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"12\", \"150000000000000000\", addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6916950", timeStamp: "1545252762", hash: "0x7a352fb0bd35218c83a1a220fa9146fbc004ba85bdd671573585a2c1a4344062", nonce: "23", blockHash: "0x1c49d0d89d2ae81c87836e854359708237a55fe9c8db4d9dc29a9de9b068b5c0", transactionIndex: "135", from: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "65000000000000000", gas: "349555", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000214e8348c4f0000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7131706", gasUsed: "269976", confirmations: "758796"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "65000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "12"}, {type: "uint256", name: "newPrice", value: "150000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "12", "150000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1545252762 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "12"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "150000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6527500912907291" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"2\", \"500000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6916952", timeStamp: "1545252809", hash: "0x8aa4b8e9ea008d9366fb61c4091c62387298e288adfc81c27b0fbd748ebd494c", nonce: "24", blockHash: "0xfb6a5c2840b4a14b135a9982abc733438dafef3fd7517c1a17e6621652e50819", transactionIndex: "45", from: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "100000000000000000", gas: "349555", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "2263249", gasUsed: "282289", confirmations: "758794"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "2"}, {type: "uint256", name: "newPrice", value: "500000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "2", "500000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1545252809 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "2"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "500000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6527500912907291" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"16\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6916956", timeStamp: "1545252849", hash: "0xe814a89431b8b207cb4005e1f6bc01f59457cd8ba0e5d5136d675d53d238bc4a", nonce: "25", blockHash: "0x28c55e1ede57a48b8048ed119455e6baeb5fd4dbc2f10bbd48722abeecbd68be", transactionIndex: "52", from: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "404868", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "3029087", gasUsed: "294538", confirmations: "758790"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "16"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "16", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1545252849 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "16"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x5d4d49bffc0a0a7f640766781ad96e1ff4fbd46f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6527500912907291" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPayments(  )", async function( ) {
		const txOriginal = {blockNumber: "6916968", timeStamp: "1545252974", hash: "0x336d9f0da0c172cdbbef72ffbf6c9b1dd3bdc4ac83965c5f6dd0b6970c0dd148", nonce: "55", blockHash: "0xf88cae4f202fdd56893bd563880de061c901b3e0105cc957a7013fa72666fc8c", transactionIndex: "86", from: "0xf416d2d8f2739ca7cf6d05e2b4ad509fafc42f78", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "0", gas: "64158", gasPrice: "2100000000", isError: "0", txreceipt_status: "1", input: "0x6103d70b", contractAddress: "", cumulativeGasUsed: "7920478", gasUsed: "25521", confirmations: "758778"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPayments", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPayments()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1545252974 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "47208293927697984" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"3\", \"50000000000000000\", addressLis... )", async function( ) {
		const txOriginal = {blockNumber: "6916974", timeStamp: "1545253050", hash: "0x329106587cad0936fbad494cce58a0c1fcbc986b0deabbc2350e05c04d67ba46", nonce: "14", blockHash: "0xeb610b75354d9ac15e0cbfc8d4fc1f03d0b409ee045081fcce3b5e328db2f006", transactionIndex: "25", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "482776", gasPrice: "2100000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7529966", gasUsed: "321851", confirmations: "758772"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "3"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "3", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1545253050 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "3"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"23\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6916978", timeStamp: "1545253127", hash: "0x1aa9b63ba16eccd190de939981b59f3c958505bc5cffd0d2babd3d4024dcf071", nonce: "15", blockHash: "0xc2519467b0be06cb098b5d067cc321df2dfe3e807f38e1142105a9c7698ed80c", transactionIndex: "50", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "501246", gasPrice: "2100000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000001700000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7285823", gasUsed: "334164", confirmations: "758768"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "23"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "23", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1545253127 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "23"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"21\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6916984", timeStamp: "1545253176", hash: "0xf73004f2164e4f553ed134ab7cee9e81f591bce9200418cfefbdfa890d764368", nonce: "16", blockHash: "0xcbb5197c68cb1dee20b541c8bb15a9822d71bb66d1068ec5b5e2b229b3d8ba08", transactionIndex: "10", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "501246", gasPrice: "2100000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000001500000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "6048727", gasUsed: "331477", confirmations: "758762"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "21"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "21", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1545253176 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "21"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"9\", \"50000000000000000\", addressLis... )", async function( ) {
		const txOriginal = {blockNumber: "6916984", timeStamp: "1545253176", hash: "0x945796791ab4b19d18b8e2ac29cd04e548866c91916b51cd5f97c7fc29668aa7", nonce: "17", blockHash: "0xcbb5197c68cb1dee20b541c8bb15a9822d71bb66d1068ec5b5e2b229b3d8ba08", transactionIndex: "11", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "501246", gasPrice: "2100000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "6392517", gasUsed: "343790", confirmations: "758762"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "9"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "9", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1545253176 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "9"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"4\", \"50000000000000000\", addressLis... )", async function( ) {
		const txOriginal = {blockNumber: "6916991", timeStamp: "1545253277", hash: "0xa2eae0b02b13d9c97f08c7da7a9efa1be84192617c75c041fe4086c9da1a8d93", nonce: "18", blockHash: "0x579a2f4e4bfa8f57b9c7d90c23487247a752994e157c80c49f44cb0e068241e8", transactionIndex: "155", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "534154", gasPrice: "2100000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7773144", gasUsed: "356103", confirmations: "758755"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "4"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "4", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1545253277 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "4"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"7\", \"50000000000000000\", addressLis... )", async function( ) {
		const txOriginal = {blockNumber: "6917007", timeStamp: "1545253545", hash: "0x1b2eb9cbaa306bc1e63324debad83544c0222119741377d9193007dff4fc1656", nonce: "19", blockHash: "0xe0b2b49e43684250a69cb12b81be7dd0cad82278ab50e68c43f09d125d9e914f", transactionIndex: "94", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "534154", gasPrice: "2100000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7834078", gasUsed: "368416", confirmations: "758739"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "7"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "7", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1545253545 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "7"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"11\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917023", timeStamp: "1545253735", hash: "0x707161b97bedd2861887009c0414af33655b2d50424879f8f4569715041b1c1b", nonce: "20", blockHash: "0x0048257b5c5a073ef982e7cdd048d0697f9f25851c443566f59f114b22876b75", transactionIndex: "9", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "552637", gasPrice: "3310000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7340051", gasUsed: "380729", confirmations: "758723"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "11"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "11", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1545253735 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "11"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"5\", \"50000000000000000\", addressLis... )", async function( ) {
		const txOriginal = {blockNumber: "6917049", timeStamp: "1545253990", hash: "0x01e73d37cae35e6d7e2156584cdd95d654ccf910d39265fa7677c8e767267e00", nonce: "21", blockHash: "0x1c627c1effea1821cb657e9ad7b2a53ab0cbc5f7e54283cc49d1f6dccf33d414", transactionIndex: "104", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "552624", gasPrice: "4310000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "4998168", gasUsed: "393042", confirmations: "758697"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "5"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "5", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1545253990 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "5"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"24\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917072", timeStamp: "1545254401", hash: "0xfbd863ff5687303e07f2dbca6414ecd8c11c780eee26e07bad5bb8da795f8829", nonce: "22", blockHash: "0x0a096d21eff9eb129679484756e995219df4ca6619f83e5dbf8ca1f149e803ba", transactionIndex: "22", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "552624", gasPrice: "2100000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7574773", gasUsed: "405355", confirmations: "758674"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "24"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "24", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1545254401 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "24"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"13\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917077", timeStamp: "1545254475", hash: "0x1c868971bb3e940a290402a02a56295ccfe08294aba6763dc1416ff5c1923507", nonce: "23", blockHash: "0xa77fd5ff71b748babef848d8e7f626e8e66b908a431d7da31a9837591138cf7a", transactionIndex: "17", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "552624", gasPrice: "2100000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000d00000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7589666", gasUsed: "417668", confirmations: "758669"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "13"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "13", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1545254475 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "13"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"11\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917079", timeStamp: "1545254499", hash: "0x98d11371a506999bd56dde1258c74e009546775d89d343e225d40a26a7c6ee9b", nonce: "24", blockHash: "0x998515c89a8c9c40d78ef1e79f142b76447fa11bd6a0e42a9c839e16c6bb125d", transactionIndex: "71", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "571093", gasPrice: "4100000000", isError: "1", txreceipt_status: "0", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "6480387", gasUsed: "25391", confirmations: "758667"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "11"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "11", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1545254499 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"13\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917081", timeStamp: "1545254517", hash: "0x949497dc933b76135ad995f689b2821c7174611b2e163cb06cdbd9c4b5b78881", nonce: "25", blockHash: "0x1614318eacc7688149991dcdd4020fae97516642ecb9550eaba432d2cada9090", transactionIndex: "38", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "589563", gasPrice: "4100000000", isError: "1", txreceipt_status: "0", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000d00000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "2039800", gasUsed: "25391", confirmations: "758665"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "13"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "13", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1545254517 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"5\", \"50000000000000000\", addressLis... )", async function( ) {
		const txOriginal = {blockNumber: "6917084", timeStamp: "1545254587", hash: "0xc944d1433905e90cacfc162bdd465608bc1cfa47905884c3b042f573ed326f8b", nonce: "26", blockHash: "0xecb0db11702d47ac3614f6d6d9a0b107118e6257871ef5b8d3d172d17cb4e605", transactionIndex: "95", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "589563", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "6413617", gasUsed: "25391", confirmations: "758662"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "5"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "5", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1545254587 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"20\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917084", timeStamp: "1545254587", hash: "0x9ccd0a047d905174048ff3c5cc08d66424a37dbdc2fb3be231f1fa39a93719ec", nonce: "27", blockHash: "0xecb0db11702d47ac3614f6d6d9a0b107118e6257871ef5b8d3d172d17cb4e605", transactionIndex: "96", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "589563", gasPrice: "3100000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "6843598", gasUsed: "429981", confirmations: "758662"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "20"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "20", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1545254587 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "20"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"13\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917084", timeStamp: "1545254587", hash: "0x5de9404a0838c5998d0e58aab7a926c875ea6ec4ddf0df7e5058c30f8924b961", nonce: "28", blockHash: "0xecb0db11702d47ac3614f6d6d9a0b107118e6257871ef5b8d3d172d17cb4e605", transactionIndex: "97", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "608032", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000d00000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "6868989", gasUsed: "25391", confirmations: "758662"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "13"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "13", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1545254587 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"20\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917086", timeStamp: "1545254628", hash: "0x62cfca45c6de384eda3f8ee1d8c3e06732e3268cc04dc9d1939296cd1b98be88", nonce: "29", blockHash: "0xe61ec1ae406f4f545e430750f3268b5c681af394604728744a132338bc67c8a4", transactionIndex: "100", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "608032", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "5535156", gasUsed: "25391", confirmations: "758660"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "20"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "20", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1545254628 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"17\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917086", timeStamp: "1545254628", hash: "0x413ed9941338a876631d5e8994169c5d64aa714e5202999b496e7988a34ae184", nonce: "30", blockHash: "0xe61ec1ae406f4f545e430750f3268b5c681af394604728744a132338bc67c8a4", transactionIndex: "117", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "608032", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7179142", gasUsed: "442294", confirmations: "758660"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "17"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "17", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1545254628 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "17"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPayments(  )", async function( ) {
		const txOriginal = {blockNumber: "6917167", timeStamp: "1545255838", hash: "0x781ce3e71dbddd16ae4c52f338120c1c812f42d52259a92ad52d2ce54efac1dd", nonce: "56", blockHash: "0xe4f30e894d12b1fbad19b42987aa55eff6dee990cd746df7b2820aed2669c8ce", transactionIndex: "104", from: "0xf416d2d8f2739ca7cf6d05e2b4ad509fafc42f78", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "0", gas: "64158", gasPrice: "5218750000", isError: "0", txreceipt_status: "1", input: "0x6103d70b", contractAddress: "", cumulativeGasUsed: "4047857", gasUsed: "25521", confirmations: "758579"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPayments", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPayments()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1545255838 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "47208293927697984" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"22\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917171", timeStamp: "1545255879", hash: "0x4e8d8703584369f562bf11bf24ef7096a263bb0e65fef2dc38d9abfe64bcbf98", nonce: "31", blockHash: "0x534e18fed7118908c58471c5df3e7ed2e72e8c5e077517b29802c58d0cf591e2", transactionIndex: "73", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "608032", gasPrice: "4100000000", isError: "0", txreceipt_status: "1", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "4376318", gasUsed: "556002", confirmations: "758575"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "22"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "22", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1545255879 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "22"}, {name: "oldOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "50000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "endTime", type: "uint256"}], name: "AuctionEnded", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AuctionEnded", events: [{name: "endTime", type: "uint256", value: "1545255879"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "initJackpot", type: "uint256"}, {indexed: false, name: "endTime", type: "uint256"}, {indexed: false, name: "roundNumber", type: "uint256"}], name: "GameRoundStarted", type: "event"} ;
		console.error( "eventCallOriginal[32,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameRoundStarted", events: [{name: "initJackpot", type: "uint256", value: "732600000000000016"}, {name: "endTime", type: "uint256", value: "1545342279"}, {name: "roundNumber", type: "uint256", value: "1"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[32,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "endTime", type: "uint256"}], name: "GameRoundExtended", type: "event"} ;
		console.error( "eventCallOriginal[32,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameRoundExtended", events: [{name: "endTime", type: "uint256", value: "1545342279"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[32,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"13\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917172", timeStamp: "1545255889", hash: "0x5b00bee00d595214ed6ce3737a12443bd73ba793dcdffbfd7ef71943fdec9b8d", nonce: "32", blockHash: "0x588afd415f15d2f45f1bd85c46e5dcf27e0b3a665c3321faafccadb450b74e4e", transactionIndex: "126", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "608032", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000000d00000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "3974722", gasUsed: "25004", confirmations: "758574"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "13"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "13", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1545255889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"20\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917174", timeStamp: "1545255907", hash: "0x5ae409eb5685ac807ec7a3421ca3c7ef72cf1f52cd96cb0d8ef65c996a36fef0", nonce: "33", blockHash: "0x3544e50dcb73e85a5935672becdfa990a4fba4e2b8567e0908e1f9386f362f3c", transactionIndex: "39", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "644971", gasPrice: "6100000000", isError: "1", txreceipt_status: "0", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "1420618", gasUsed: "25004", confirmations: "758572"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "20"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "20", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1545255907 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"22\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917178", timeStamp: "1545256019", hash: "0xc5add1d408292defb60b2dd518230f5ee76aff7325afa089698904874dbfdd74", nonce: "34", blockHash: "0x50aa269b1b1f76bf0b2a4b601e00d18698a0523c5189194664949c96556f0ae6", transactionIndex: "81", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "644971", gasPrice: "6100000000", isError: "1", txreceipt_status: "0", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "4181827", gasUsed: "25004", confirmations: "758568"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "22"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "22", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1545256019 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"17\", \"50000000000000000\", addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6917178", timeStamp: "1545256019", hash: "0x9307db2d38f098aa892348b63b6519579362dd941ebc7150982593a24024510a", nonce: "35", blockHash: "0x50aa269b1b1f76bf0b2a4b601e00d18698a0523c5189194664949c96556f0ae6", transactionIndex: "82", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "55000000000000000", gas: "644971", gasPrice: "6100000000", isError: "1", txreceipt_status: "0", input: "0xe6dc992d000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "4206831", gasUsed: "25004", confirmations: "758568"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "55000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "17"}, {type: "uint256", name: "newPrice", value: "50000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "17", "50000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1545256019 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPayments(  )", async function( ) {
		const txOriginal = {blockNumber: "6917180", timeStamp: "1545256045", hash: "0x97d4954adb3f0614a9054f8443aaa30d33127dc71d398e78bb2927ea9ea38723", nonce: "36", blockHash: "0xd37567bcbbcf0e2d49a713f91ce720a05111e7aeb3e3a379a254499d22a5f3ef", transactionIndex: "45", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "0", gas: "64158", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x6103d70b", contractAddress: "", cumulativeGasUsed: "1978938", gasUsed: "25521", confirmations: "758566"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPayments", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPayments()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1545256045 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buySquareAtAuction( \"22\", \"100000000000000000\", addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6917180", timeStamp: "1545256045", hash: "0xd29067153652c0a3708d386a1598f7ca096158582f0dc0fafd47c5a199f33dc2", nonce: "37", blockHash: "0xd37567bcbbcf0e2d49a713f91ce720a05111e7aeb3e3a379a254499d22a5f3ef", transactionIndex: "67", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "60000000000000000", gas: "856599", gasPrice: "5218750000", isError: "1", txreceipt_status: "0", input: "0xe6dc992d0000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "2987459", gasUsed: "25068", confirmations: "758566"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "22"}, {type: "uint256", name: "newPrice", value: "100000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquareAtAuction", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquareAtAuction(uint8,uint256,address)" ]( "22", "100000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1545256045 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buySquare( \"17\", \"10000000000000000000\", addres... )", async function( ) {
		const txOriginal = {blockNumber: "6917461", timeStamp: "1545260306", hash: "0x0ebc4ae7c822d7e80b6c99178ca8146885b18cf64fcebe87dc907e3c59a58cae", nonce: "204", blockHash: "0x3b218a1ddb96ebc1ed0c4e053bb05ab3201183ca1681505a67d6799523c0d290", transactionIndex: "52", from: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "1050000000000000000", gas: "780180", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc5ea0b4a00000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "6888163", gasUsed: "520120", confirmations: "758285"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1050000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "17"}, {type: "uint256", name: "newPrice", value: "10000000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquare", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquare(uint8,uint256,address)" ]( "17", "10000000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1545260306 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "17"}, {name: "oldOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "newOwner", type: "address", value: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "10000000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "endTime", type: "uint256"}], name: "GameRoundExtended", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameRoundExtended", events: [{name: "endTime", type: "uint256", value: "1545346706"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "246356331244899036" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buySquare( \"11\", \"10000000000000000000\", addres... )", async function( ) {
		const txOriginal = {blockNumber: "6917469", timeStamp: "1545260393", hash: "0x4a97cb24c2b93f445cd10c5eef1b3e4d5a82844df46f35bdb392fb204126800a", nonce: "205", blockHash: "0xc880035b919da2f25d143620bf1a439aacf005813f7fb5fb2961d6f8950bff38", transactionIndex: "58", from: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "1050000000000000000", gas: "780180", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc5ea0b4a000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7639725", gasUsed: "460120", confirmations: "758277"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1050000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "11"}, {type: "uint256", name: "newPrice", value: "10000000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquare", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquare(uint8,uint256,address)" ]( "11", "10000000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1545260393 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "11"}, {name: "oldOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "newOwner", type: "address", value: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "10000000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "endTime", type: "uint256"}], name: "GameRoundExtended", type: "event"} ;
		console.error( "eventCallOriginal[40,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameRoundExtended", events: [{name: "endTime", type: "uint256", value: "1545346793"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[40,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "246356331244899036" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buySquare( \"20\", \"100000000000000000\", addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6917471", timeStamp: "1545260426", hash: "0xbbeec744130525ffb340a747c43b6c3e4b0caa50fc0d72f24decb8630c4bf5b9", nonce: "206", blockHash: "0xd6c3c5acbf5fa433242265ebc4cf690f0ef65489b81bfcf44a2834feb796069b", transactionIndex: "74", from: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "60000000000000000", gas: "780180", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc5ea0b4a0000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7554293", gasUsed: "460120", confirmations: "758275"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "20"}, {type: "uint256", name: "newPrice", value: "100000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquare", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquare(uint8,uint256,address)" ]( "20", "100000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1545260426 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "20"}, {name: "oldOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "newOwner", type: "address", value: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "100000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "endTime", type: "uint256"}], name: "GameRoundExtended", type: "event"} ;
		console.error( "eventCallOriginal[41,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameRoundExtended", events: [{name: "endTime", type: "uint256", value: "1545346826"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[41,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "246356331244899036" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buySquare( \"21\", \"100000000000000000\", addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6917479", timeStamp: "1545260499", hash: "0x33a750a6120dde284e2094b9dcea98bad157ccf654a20742f0400d4310400225", nonce: "207", blockHash: "0x509a0d5b0251052f35eab84fd61d6e4017bb64abfa43f1e2a9f474670ef30551", transactionIndex: "28", from: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "60000000000000000", gas: "780180", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc5ea0b4a0000000000000000000000000000000000000000000000000000000000000015000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7248953", gasUsed: "460120", confirmations: "758267"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "21"}, {type: "uint256", name: "newPrice", value: "100000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquare", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquare(uint8,uint256,address)" ]( "21", "100000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1545260499 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "21"}, {name: "oldOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "newOwner", type: "address", value: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "100000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "endTime", type: "uint256"}], name: "GameRoundExtended", type: "event"} ;
		console.error( "eventCallOriginal[42,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameRoundExtended", events: [{name: "endTime", type: "uint256", value: "1545346899"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[42,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "246356331244899036" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buySquare( \"22\", \"100000000000000000\", addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6917488", timeStamp: "1545260614", hash: "0x80df0d8c18fda9808d1d4f1b2a3f0ffb81159ed6fb66151de78deecdb1a12f3f", nonce: "208", blockHash: "0xa37a5b9ab676ac013a623cbf6e904f13e3bf14a698dfaa26e05cbf9dd2eb479b", transactionIndex: "75", from: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "60000000000000000", gas: "780180", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc5ea0b4a0000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "7044817", gasUsed: "460120", confirmations: "758258"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "22"}, {type: "uint256", name: "newPrice", value: "100000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquare", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquare(uint8,uint256,address)" ]( "22", "100000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1545260614 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "22"}, {name: "oldOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "newOwner", type: "address", value: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "100000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "endTime", type: "uint256"}], name: "GameRoundExtended", type: "event"} ;
		console.error( "eventCallOriginal[43,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameRoundExtended", events: [{name: "endTime", type: "uint256", value: "1545347014"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[43,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "246356331244899036" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPayments(  )", async function( ) {
		const txOriginal = {blockNumber: "6917583", timeStamp: "1545261943", hash: "0x18251b0fa2809ddfa941c544e7d3df8346050b05275f0ede9bc0ab4d59564a57", nonce: "209", blockHash: "0x9bcf523e19f627a13db129e4e46720999bb0285d61f7fbe2f795195066b12699", transactionIndex: "99", from: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "0", gas: "64158", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x6103d70b", contractAddress: "", cumulativeGasUsed: "7911021", gasUsed: "25521", confirmations: "758163"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPayments", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPayments()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1545261943 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "246356331244899036" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buySquare( \"5\", \"25000000000000000000\", address... )", async function( ) {
		const txOriginal = {blockNumber: "6917592", timeStamp: "1545262087", hash: "0xbf231915ba5a79c231a50a2e3bf533c2f7fd5fbacd691150ae1b58fdcb6885fa", nonce: "210", blockHash: "0x45f2f212f4c07be34c9c68834391f931eb9a769a9ccd9418809944b1206e783a", transactionIndex: "29", from: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "2550000000000000000", gas: "690276", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xc5ea0b4a00000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000015af1d78b58c40000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "3172518", gasUsed: "475184", confirmations: "758154"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "2550000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "5"}, {type: "uint256", name: "newPrice", value: "25000000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "buySquare", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buySquare(uint8,uint256,address)" ]( "5", "25000000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1545262087 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "oldOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquareOwnerChanged", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SquareOwnerChanged", events: [{name: "squareId", type: "uint8", value: "5"}, {name: "oldOwner", type: "address", value: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e"}, {name: "newOwner", type: "address", value: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f"}, {name: "oldPrice", type: "uint256", value: "50000000000000000"}, {name: "newPrice", type: "uint256", value: "25000000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "endTime", type: "uint256"}], name: "GameRoundExtended", type: "event"} ;
		console.error( "eventCallOriginal[45,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameRoundExtended", events: [{name: "endTime", type: "uint256", value: "1545348487"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[45,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "246356331244899036" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPayments(  )", async function( ) {
		const txOriginal = {blockNumber: "6917598", timeStamp: "1545262174", hash: "0xd00d6c1446deded0c8724b18775ddb7dbf514449a0e8d19da1650fb972e79ec8", nonce: "211", blockHash: "0x26e2cb28d915373661c19f2afcb4dc0c5d6d04b91fd1cf1ecc334d8d9498c8dd", transactionIndex: "30", from: "0x3674840e64a5b2176052d9f65a9ac7e8dbf7bd5f", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "0", gas: "64158", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x6103d70b", contractAddress: "", cumulativeGasUsed: "1944255", gasUsed: "25521", confirmations: "758148"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPayments", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPayments()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1545262174 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "246356331244899036" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPayments(  )", async function( ) {
		const txOriginal = {blockNumber: "6917628", timeStamp: "1545262614", hash: "0x0928c3457b93f6c06379c6edaeac05663f2e3b561fc467a7ee58b03277bd5865", nonce: "57", blockHash: "0x906dc1f05cd7e119943ef774c4fd46c5bb91100bbedd671cdbd72a9a917f87fc", transactionIndex: "143", from: "0xf416d2d8f2739ca7cf6d05e2b4ad509fafc42f78", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "0", gas: "64158", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x6103d70b", contractAddress: "", cumulativeGasUsed: "7098286", gasUsed: "25521", confirmations: "758118"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPayments", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPayments()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1545262614 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "47208293927697984" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPayments(  )", async function( ) {
		const txOriginal = {blockNumber: "6917634", timeStamp: "1545262731", hash: "0x8426114b7a0163709d3b5263c27a2f3e4e484321f909ccfc1f1b177b1a8e25ac", nonce: "38", blockHash: "0x2d48a159e49c214eed7e1ace3ede9b5dd87f3f80b8d5fbf79577fc655dfda4c2", transactionIndex: "17", from: "0x4ea6a7820bfeec2c1de3f2e3466f6624d6bbcb7e", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "0", gas: "64278", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x6103d70b", contractAddress: "", cumulativeGasUsed: "1282754", gasUsed: "25521", confirmations: "758112"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdrawPayments", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPayments()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1545262731 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "5121538377690444" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: setSquarePrice( \"10\", \"5000000000000000000\", address... )", async function( ) {
		const txOriginal = {blockNumber: "6917677", timeStamp: "1545263367", hash: "0xcbc24e01aa67323353ac0885092985534ed34322ed1c8df21d526b6aaa6e85df", nonce: "58", blockHash: "0x05ba56b5f1bb528342d9f0eeac18e9ce5ad5d3bcd6c770eb3e45cf5a36d55c59", transactionIndex: "89", from: "0xf416d2d8f2739ca7cf6d05e2b4ad509fafc42f78", to: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5", value: "500000000000000000", gas: "732138", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x9ee06759000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000b111dabb8edd8260b5c1e471945a62be2ee24470", contractAddress: "", cumulativeGasUsed: "6551503", gasUsed: "488092", confirmations: "758069"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "squareId", value: "10"}, {type: "uint256", name: "newPrice", value: "5000000000000000000"}, {type: "address", name: "referrer", value: addressList[4]}], name: "setSquarePrice", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setSquarePrice(uint8,uint256,address)" ]( "10", "5000000000000000000", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1545263367 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "squareId", type: "uint8"}, {indexed: true, name: "owner", type: "address"}, {indexed: false, name: "oldPrice", type: "uint256"}, {indexed: false, name: "newPrice", type: "uint256"}], name: "SquarePriceChanged", type: "event"} ;
		console.error( "eventCallOriginal[49,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SquarePriceChanged", events: [{name: "squareId", type: "uint8", value: "10"}, {name: "owner", type: "address", value: "0xf416d2d8f2739ca7cf6d05e2b4ad509fafc42f78"}, {name: "oldPrice", type: "uint256", value: "1000000000000000000"}, {name: "newPrice", type: "uint256", value: "5000000000000000000"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[49,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "endTime", type: "uint256"}], name: "GameRoundExtended", type: "event"} ;
		console.error( "eventCallOriginal[49,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameRoundExtended", events: [{name: "endTime", type: "uint256", value: "1545349767"}], address: "0x480d08a87e9d23704dfbdc296afc3436fe6b27d5"}] ;
		console.error( "eventResultOriginal[49,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "47208293927697984" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1675554596861118425" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
