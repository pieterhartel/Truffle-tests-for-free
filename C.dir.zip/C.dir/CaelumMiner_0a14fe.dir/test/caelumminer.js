const CaelumMiner = artifacts.require( "./CaelumMiner.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "CaelumMiner" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xA38FcEdd23dE2191Dc27f9a0240ac170BE0A14fE", "0xdb93CE3cCA2444CE5DA5522a85758af79Af0092D", "0xdf33254137Ec363F6E0076fF6eAc58Ca1ECB409E", "0xc2981fc938A0e9D8de03e6f48740562B9e429D65", "0xbBAf778404f29dAfaBFB07981E3Cf3faE29cE385", "0xfd53570b7FD5Af2e89e822dB74636F99d16303E7", "0xe0c8b2EC96e88D703271953f4b443c8F63764838", "0x6696722C5Cad75664A7DfE99fa2f9B0693c6De39"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "TARGET_DIVISOR", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMiningRewardForPool", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_contract_miner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "masternodeInterface", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMiningDifficulty", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "difficulty", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "MAX_ADJUSTMENT_PERCENT", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rewardEra", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMiningTarget", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "MINING_RATE_FACTOR", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "MAX_REWARD_ERA", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMiningReward", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getChallengeNumber", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxSupplyForEra", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "baseMiningReward", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokensMinted", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "contractProgress", outputs: [{name: "epoch", type: "uint256"}, {name: "candidate", type: "uint256"}, {name: "round", type: "uint256"}, {name: "miningepoch", type: "uint256"}, {name: "globalreward", type: "uint256"}, {name: "powreward", type: "uint256"}, {name: "masternodereward", type: "uint256"}, {name: "usercounter", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "nonce", type: "uint256"}, {name: "challenge_digest", type: "bytes32"}, {name: "challenge_number", type: "bytes32"}, {name: "testTarget", type: "uint256"}], name: "checkMintSolution", outputs: [{name: "success", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_contract_voting", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "epochCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ACTIVE_STATE", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_MAXIMUM_TARGET", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "challengeNumber", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "statistics", outputs: [{name: "lastRewardTo", type: "address"}, {name: "lastRewardAmount", type: "uint256"}, {name: "lastRewardEthBlockNumber", type: "uint256"}, {name: "lastRewardTimestamp", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "gasPriceLimit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "nonce", type: "uint256"}, {name: "challenge_digest", type: "bytes32"}, {name: "challenge_number", type: "bytes32"}], name: "getMintDigest", outputs: [{name: "digesttest", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_contract_masternode", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "QUOTIENT_LIMIT", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_contract_token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_internalMod", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "latestDifficultyPeriodStarted", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "blocksPerReadjustment", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_MINIMUM_TARGET", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokenInterface", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "_gasPrice", type: "uint8"}], name: "GasPriceSet", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["GasPriceSet(uint8)", "Mint(address,uint256,uint256,bytes32)", "RewardMasternode(address,uint256)", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xdfd0de69153615d091009f6a203a3188c76f7dbdccfcdb30ae401af52279dd48", "0xcf6fbb9dcea7d07263ab4f5c3a92f53af33dffc421d9d121e1c74b307e68189d", "0x8f9a423c71e43ad001bebf147d969f424a8fac4e5970a367c5e53abb17cbe710", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6631031 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6633127 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "CaelumMiner", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "TARGET_DIVISOR", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "TARGET_DIVISOR()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMiningRewardForPool", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMiningRewardForPool()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_contract_miner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_contract_miner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "masternodeInterface", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "masternodeInterface()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMiningDifficulty", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMiningDifficulty()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "difficulty", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "difficulty()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MAX_ADJUSTMENT_PERCENT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MAX_ADJUSTMENT_PERCENT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rewardEra", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rewardEra()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMiningTarget", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMiningTarget()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MINING_RATE_FACTOR", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MINING_RATE_FACTOR()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MAX_REWARD_ERA", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MAX_REWARD_ERA()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMiningReward", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMiningReward()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getChallengeNumber", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getChallengeNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxSupplyForEra", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxSupplyForEra()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "baseMiningReward", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "baseMiningReward()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensMinted", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensMinted()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "contractProgress", outputs: [{name: "epoch", type: "uint256"}, {name: "candidate", type: "uint256"}, {name: "round", type: "uint256"}, {name: "miningepoch", type: "uint256"}, {name: "globalreward", type: "uint256"}, {name: "powreward", type: "uint256"}, {name: "masternodereward", type: "uint256"}, {name: "usercounter", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contractProgress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "nonce", value: random.range( maxRandom )}, {type: "bytes32", name: "challenge_digest", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "bytes32", name: "challenge_number", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "uint256", name: "testTarget", value: random.range( maxRandom )}], name: "checkMintSolution", outputs: [{name: "success", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkMintSolution(uint256,bytes32,bytes32,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value,methodCall.inputs[ 3 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_contract_voting", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_contract_voting()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "epochCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "epochCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ACTIVE_STATE", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ACTIVE_STATE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_MAXIMUM_TARGET", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_MAXIMUM_TARGET()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "challengeNumber", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "challengeNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "statistics", outputs: [{name: "lastRewardTo", type: "address"}, {name: "lastRewardAmount", type: "uint256"}, {name: "lastRewardEthBlockNumber", type: "uint256"}, {name: "lastRewardTimestamp", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "statistics()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gasPriceLimit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gasPriceLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "nonce", value: random.range( maxRandom )}, {type: "bytes32", name: "challenge_digest", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "bytes32", name: "challenge_number", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getMintDigest", outputs: [{name: "digesttest", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMintDigest(uint256,bytes32,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_contract_masternode", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_contract_masternode()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "QUOTIENT_LIMIT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "QUOTIENT_LIMIT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_contract_token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_contract_token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_internalMod", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_internalMod()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "latestDifficultyPeriodStarted", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",33] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "latestDifficultyPeriodStarted()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",33] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "blocksPerReadjustment", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",34] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "blocksPerReadjustment()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",34] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_MINIMUM_TARGET", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",35] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_MINIMUM_TARGET()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",35] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokenInterface", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",36] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenInterface()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",36] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "CaelumMiner", function( accounts ) {

	it( "TEST: CaelumMiner(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6631031", timeStamp: "1541181297", hash: "0xbed627b1cb6d81052d917c3249aa385e7c75220d68810363bb9f20d581ce620c", nonce: "194", blockHash: "0xae23f98c73f395062b158e3a4d423e64ec58b65619f081548e4d218ec774f40a", transactionIndex: "7", from: "0xdb93ce3cca2444ce5da5522a85758af79af0092d", to: 0, value: "0", gas: "2348075", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xd866af37", contractAddress: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", cumulativeGasUsed: "3394271", gasUsed: "2348075", confirmations: "1092176"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "CaelumMiner", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = CaelumMiner.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541181297 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = CaelumMiner.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setModifierContract( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6631044", timeStamp: "1541181471", hash: "0x15498248b135b1a05ecffbd66a098fa6e982f884fd3b4817c4aae21d5df9aece", nonce: "195", blockHash: "0xa8a54926ffe8eb7a41452b358780df428c148ee0f257ab1cc2c02cc6c19fa52e", transactionIndex: "64", from: "0xdb93ce3cca2444ce5da5522a85758af79af0092d", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "90501", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x1dfb396f000000000000000000000000df33254137ec363f6e0076ff6eac58ca1ecb409e", contractAddress: "", cumulativeGasUsed: "2938103", gasUsed: "90501", confirmations: "1092163"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_contract", value: addressList[4]}], name: "setModifierContract", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setModifierContract(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541181471 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: getDataFromContract( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6631047", timeStamp: "1541181518", hash: "0xa5fef8cd545d2274b1a99a087d6a44dfbf7691da17792caf0f626334f3ff6e4e", nonce: "196", blockHash: "0x09e864cdbce31e584391a1229d6ddda441202d657870e92cbc7a90fe6a6516ae", transactionIndex: "22", from: "0xdb93ce3cca2444ce5da5522a85758af79af0092d", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "94902", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x29a7922d000000000000000000000000c2981fc938a0e9d8de03e6f48740562b9e429d65", contractAddress: "", cumulativeGasUsed: "1293886", gasUsed: "94902", confirmations: "1092160"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_previous_contract", value: addressList[5]}], name: "getDataFromContract", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getDataFromContract(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541181518 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"29616636044561638559824699825500422349... )", async function( ) {
		const txOriginal = {blockNumber: "6631107", timeStamp: "1541182409", hash: "0xed460cd96ee8c68e91ce19b04ea2dbf58e4f1f2512370c1b88ddda631c6be928", nonce: "16171", blockHash: "0xd2e1a063377d4922d13c4899614e050673d20bde92e70a432eaebca3f6dbacdc", transactionIndex: "107", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "236840", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5417a6c05caa585014290cfeeb183dea7a4fd04000d4a976462caa840beb1505a000000000003b80d913c82c860333298f59958c7704a5937e617b9a06c156feb", contractAddress: "", cumulativeGasUsed: "7605066", gasUsed: "236840", confirmations: "1092100"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "29616636044561638559824699825500422349968033925563689257326704494076593524826"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000003b80d913c82c860333298f59958c7704a5937e617b9a06c156feb"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "29616636044561638559824699825500422349968033925563689257326704494076593524826", "0x000000000003b80d913c82c860333298f59958c7704a5937e617b9a06c156feb", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541182409 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19714"}, {name: "newChallengeNumber", type: "bytes32", value: "0xd646d8438a933a8421bf1af0704ddde6e5adde9bdbb4d2c2bbbfff2b6944ea05"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[3,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x321be43d5bad6991ae4ce6792aff46c08f7b0ed9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[3,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"45579455012601169353477197724002294269... )", async function( ) {
		const txOriginal = {blockNumber: "6631124", timeStamp: "1541182680", hash: "0xb79ea300a04fd8b01a9e366a5024e48bbbd1f594ded267fb49a9219677dc4bfb", nonce: "508", blockHash: "0x21ea61bb3d2723cd87641b5da83f847ef23114d2ed1f82b75207719e54e9d387", transactionIndex: "43", from: "0xfd53570b7fd5af2e89e822db74636f99d16303e7", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "1704624", gasPrice: "5500000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe564c50eacc6f72768d4fe6065c050d2e49f010000267e7ddc8ac3525f00587c1600000000001116ddfd7743738434d34be3db172070c8a7e9add9d401441b33fd", contractAddress: "", cumulativeGasUsed: "4610957", gasUsed: "176712", confirmations: "1092083"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "45579455012601169353477197724002294269226877377826414094144661723480644418582"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000001116ddfd7743738434d34be3db172070c8a7e9add9d401441b33fd"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "45579455012601169353477197724002294269226877377826414094144661723480644418582", "0x00000000001116ddfd7743738434d34be3db172070c8a7e9add9d401441b33fd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541182680 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xfd53570b7fd5af2e89e822db74636f99d16303e7"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19715"}, {name: "newChallengeNumber", type: "bytes32", value: "0xc46b39e8d7d35996fdd5df55c00c4848892d959564999d5184aca682def1929b"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x321be43d5bad6991ae4ce6792aff46c08f7b0ed9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3736809729504285" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"90462569716653277908548986609333315608... )", async function( ) {
		const txOriginal = {blockNumber: "6631183", timeStamp: "1541183533", hash: "0xd687b0c6a01083211401fdfa89621f8a27e512719eadad44202b9515f61df576", nonce: "16172", blockHash: "0xac2aa046b6a8902012870c8a0115e04ef2c08379b35dee271a67d7ec65a428ce", transactionIndex: "59", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176328", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe502000000000000005f62a5255854d2aea620000033a752721cae3cf31682af08000000000002c21c4456ff7024778c0c45b5c2e13a234a31516cceb6e1a9719f", contractAddress: "", cumulativeGasUsed: "5594067", gasUsed: "176328", confirmations: "1092024"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "904625697166532779085489866093333156087646974381004515770790852598106861320"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000002c21c4456ff7024778c0c45b5c2e13a234a31516cceb6e1a9719f"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "904625697166532779085489866093333156087646974381004515770790852598106861320", "0x000000000002c21c4456ff7024778c0c45b5c2e13a234a31516cceb6e1a9719f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541183533 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19716"}, {name: "newChallengeNumber", type: "bytes32", value: "0x6bf50b73edfb5ded616f4cbdfb8a98651d176894ff1774bcc41537a3bf3bf79c"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x357f54b5d4f5552f2283f05edab11236e865f8fb"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"10487327482764133926296714160262095719... )", async function( ) {
		const txOriginal = {blockNumber: "6631313", timeStamp: "1541185281", hash: "0xa7e9a4b79c1d8fd5ce316a2c18a10caaf23492d5a1ea3b6f7774be287e952b07", nonce: "509", blockHash: "0xc25d360a9c59950747e43f1ea55b3938ddafe2f783fea8b6f10da8d0228e8d77", transactionIndex: "56", from: "0xfd53570b7fd5af2e89e822db74636f99d16303e7", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "1704624", gasPrice: "5099999904", isError: "0", txreceipt_status: "1", input: "0x1801fbe5e7dc2b88558ddab3f191d5700645ad93ba01000085d7fd8acfee60677df6ab780000000000099a2193594752d890c09125bc9fcebd1c62ffbcbc446fce196294", contractAddress: "", cumulativeGasUsed: "3361712", gasUsed: "176776", confirmations: "1091894"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "104873274827641339262967141602620957196241898362874512380747739737005091105656"}, {type: "bytes32", name: "challenge_digest", value: "0x0000000000099a2193594752d890c09125bc9fcebd1c62ffbcbc446fce196294"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "104873274827641339262967141602620957196241898362874512380747739737005091105656", "0x0000000000099a2193594752d890c09125bc9fcebd1c62ffbcbc446fce196294", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541185281 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xfd53570b7fd5af2e89e822db74636f99d16303e7"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19717"}, {name: "newChallengeNumber", type: "bytes32", value: "0x16e708f54e4bceb890d57f8bed087f865cad56be96a71b866b500c14e940c5ed"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x5760b91b7f91d06ccbe6e935d6efbc8e8d69768b"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3736809729504285" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"45047379204873492532180197433145014575... )", async function( ) {
		const txOriginal = {blockNumber: "6631342", timeStamp: "1541185661", hash: "0x0352c128f2e804b79914e34580039e27e9270de0a36b1733fe0cd53c9d748fc0", nonce: "16173", blockHash: "0xfbbc1533bb0fdd56a49853ab327ab2955bebfa8b865b3b7fdab46becf24ef1d2", transactionIndex: "57", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176648", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe56397e9c030ceb3641ed340948f241f010000000089f98dd8decdcb408fd168ac0000000000039089913f5e01eed4514ed9c873025d1697cc6309da27a49422f3", contractAddress: "", cumulativeGasUsed: "2648247", gasUsed: "176648", confirmations: "1091865"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "45047379204873492532180197433145014575927321512452286810048405042497003284652"}, {type: "bytes32", name: "challenge_digest", value: "0x0000000000039089913f5e01eed4514ed9c873025d1697cc6309da27a49422f3"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "45047379204873492532180197433145014575927321512452286810048405042497003284652", "0x0000000000039089913f5e01eed4514ed9c873025d1697cc6309da27a49422f3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541185661 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19718"}, {name: "newChallengeNumber", type: "bytes32", value: "0xb4e11919c26ce68a65bd847c4d5016f11483c5aa11af4b2365266de8146ed17c"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x6136e93494534f55e33ad085bef8f1810f2b09d9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"90462569716653277865300594593370491511... )", async function( ) {
		const txOriginal = {blockNumber: "6631384", timeStamp: "1541186318", hash: "0x994e981f5a5ba166634e0e1a04a08d4191528094b04c1d90279cdc65331a5ac1", nonce: "16174", blockHash: "0xa381a6130c52c264f4ec51fa9341b0af12aaef21f23267f554e1a7ceb899e6bf", transactionIndex: "126", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176392", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe502000000000000004dbf4d62eab92e07ddc20200c05578dfe60d18e46626434300000000001a49184e440a4e080cf6f68586ddbd43385646c813619d66e49093", contractAddress: "", cumulativeGasUsed: "7327475", gasUsed: "176392", confirmations: "1091823"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "904625697166532778653005945933704915111020451935661333620345246091112235843"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000001a49184e440a4e080cf6f68586ddbd43385646c813619d66e49093"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "904625697166532778653005945933704915111020451935661333620345246091112235843", "0x00000000001a49184e440a4e080cf6f68586ddbd43385646c813619d66e49093", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541186318 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19719"}, {name: "newChallengeNumber", type: "bytes32", value: "0x5dd882823fa168a1ad3e5eb8d9a6bbbcd16d649f5a4efa0b84ef9405abf418ad"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x6cb9ad9ad3395debe26bbf0fb0af6c8b593eb456"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"90462569716653277876028689453747878676... )", async function( ) {
		const txOriginal = {blockNumber: "6631419", timeStamp: "1541186846", hash: "0x3734fb5de84bddca7bdd40cd50221f5de48f066b1afbb32739da0e23e42cdcb2", nonce: "16175", blockHash: "0xc76b36c9ab75108731f04aed3476167cf63a7de5abfb9ab93cad40401bba2860", transactionIndex: "16", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176328", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe50200000000000000521f5e1eb0f21308920200004e9e45fa928e7c80bc20d96d00000000000b68eceb2a03730a23b6466958804e1db1a973785bcb121f70da8b", contractAddress: "", cumulativeGasUsed: "995666", gasUsed: "176328", confirmations: "1091788"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "904625697166532778760286894537478786760613029649110664118208657592472885613"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000000b68eceb2a03730a23b6466958804e1db1a973785bcb121f70da8b"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "904625697166532778760286894537478786760613029649110664118208657592472885613", "0x00000000000b68eceb2a03730a23b6466958804e1db1a973785bcb121f70da8b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541186846 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19720"}, {name: "newChallengeNumber", type: "bytes32", value: "0xc43c32349d5234b876cd37d0503655120b4809d279f821d9f749c94b2dc15fa7"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x207e99a1d1481ba497d5a4bfe55a52bc823be410"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"10487327482764133926296714160307009370... )", async function( ) {
		const txOriginal = {blockNumber: "6631429", timeStamp: "1541186919", hash: "0x267a739090e18cfe4b76295681e941eaa5d3d876cef853ffcd455607162480f7", nonce: "510", blockHash: "0x148a4a6905f80aa5e23ddadde0cce651a9f291143ce6810e92f17a2753e69f30", transactionIndex: "143", from: "0xfd53570b7fd5af2e89e822db74636f99d16303e7", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "1704624", gasPrice: "5099999904", isError: "0", txreceipt_status: "1", input: "0x1801fbe5e7dc2b88558ddab3f191d57054f1a7db470a000085d7fd8acfee60677df6ab7800000000000547b8c2274468f18070966066d64d0ca2c1e504595db45bb17159", contractAddress: "", cumulativeGasUsed: "3506667", gasUsed: "176776", confirmations: "1091778"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "104873274827641339262967141603070093706214105451847592724443171420161598466936"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000000547b8c2274468f18070966066d64d0ca2c1e504595db45bb17159"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "104873274827641339262967141603070093706214105451847592724443171420161598466936", "0x00000000000547b8c2274468f18070966066d64d0ca2c1e504595db45bb17159", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541186919 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xfd53570b7fd5af2e89e822db74636f99d16303e7"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19721"}, {name: "newChallengeNumber", type: "bytes32", value: "0xa3fe589aede269f95a2034b263db4339ce8b9c1634012c69aabb91dba3f28720"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[10,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x74267eedbedabf6643ede15818d20f1ef2f2edcd"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[10,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3736809729504285" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"54623456930753865770676842653375047180... )", async function( ) {
		const txOriginal = {blockNumber: "6631462", timeStamp: "1541187333", hash: "0xbd8b8dbb48b747d31c88b7ef811d960c9c83aae1612fc882f3244d089a46b8de", nonce: "16176", blockHash: "0xc8513a6f6e6bbd5eb84e72fb024e37dd5a04bed17c2837ca855c5f690790d1aa", transactionIndex: "11", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176520", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe50c1393fe6b5b49bf68bc578b471b9f00000000001cb3423c24d8db8f572c30db000000000000eedb47fb5d753b3014eb1767ef155680420cf6516d4ccc508c51", contractAddress: "", cumulativeGasUsed: "3994879", gasUsed: "176520", confirmations: "1091745"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "5462345693075386577067684265337504718036506838201923019620509670228194242779"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000000eedb47fb5d753b3014eb1767ef155680420cf6516d4ccc508c51"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "5462345693075386577067684265337504718036506838201923019620509670228194242779", "0x000000000000eedb47fb5d753b3014eb1767ef155680420cf6516d4ccc508c51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541187333 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19722"}, {name: "newChallengeNumber", type: "bytes32", value: "0x8bf5f8748879d55279a9374471b9d8750c449ccb1495c7f3bef9c93452acb848"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x74267eedbedabf6643ede15818d20f1ef2f2edcd"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"94142574360332888886567041022948491710... )", async function( ) {
		const txOriginal = {blockNumber: "6631483", timeStamp: "1541187527", hash: "0x667ac74b0a4fa0b5981dac348faf42caf4337218b416fd986a75145d379f477f", nonce: "16177", blockHash: "0xa4292e0be7d472428491324620f5b2a5f6e6b58eec7a05eea41c0b80b9af5894", transactionIndex: "93", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "256631", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5d022cf0e96c538c12f110492026712010000000026fc3d8269fe3e0ffa7faa410000000000012d2b54a6e7010af195364216e7c77580f680dfba0ebf2a36e2c5", contractAddress: "", cumulativeGasUsed: "7440947", gasUsed: "241631", confirmations: "1091724"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "94142574360332888886567041022948491710051950426488136042028516026649151515201"}, {type: "bytes32", name: "challenge_digest", value: "0x0000000000012d2b54a6e7010af195364216e7c77580f680dfba0ebf2a36e2c5"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "94142574360332888886567041022948491710051950426488136042028516026649151515201", "0x0000000000012d2b54a6e7010af195364216e7c77580f680dfba0ebf2a36e2c5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541187527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19723"}, {name: "newChallengeNumber", type: "bytes32", value: "0xbb1aedd8eeed6ca8738f88645a8a7dcc8c10b7d4bc948d9aa52032dea9505e1a"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x1ba4b0280163889e7ee4ab5269c442971f48d13e"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"10487327482764133926296714160334736227... )", async function( ) {
		const txOriginal = {blockNumber: "6631552", timeStamp: "1541188428", hash: "0xad2234cef946baf48bbe2470d4919620af01ef65cadf8398264a247a81171017", nonce: "511", blockHash: "0xb03fad6c8513bf4387a166fa568116ebd7e3ed36f54413df9e0f3a30897f651a", transactionIndex: "121", from: "0xfd53570b7fd5af2e89e822db74636f99d16303e7", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "1704624", gasPrice: "5099999904", isError: "0", txreceipt_status: "1", input: "0x1801fbe5e7dc2b88558ddab3f191d5708582ceeabc11000085d7fd8acfee60677df6ab7800000000001953adba8baaa705b1678564baeac4807937a23aec6f18e89452e7", contractAddress: "", cumulativeGasUsed: "3222259", gasUsed: "176776", confirmations: "1091655"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "104873274827641339262967141603347362273906379553414847380932853348542904183672"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000001953adba8baaa705b1678564baeac4807937a23aec6f18e89452e7"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "104873274827641339262967141603347362273906379553414847380932853348542904183672", "0x00000000001953adba8baaa705b1678564baeac4807937a23aec6f18e89452e7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541188428 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xfd53570b7fd5af2e89e822db74636f99d16303e7"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19724"}, {name: "newChallengeNumber", type: "bytes32", value: "0xadf134b692c7516744e745db1a87594466eb8f69f169656f5096f3af492894ae"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x321be43d5bad6991ae4ce6792aff46c08f7b0ed9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3736809729504285" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"10487327482764133926296714160402626299... )", async function( ) {
		const txOriginal = {blockNumber: "6631560", timeStamp: "1541188528", hash: "0x85e4d7a57a93ea9fa8b4357c0d7aeb0ee466399130fd20c65f958776580877a0", nonce: "512", blockHash: "0xfb37e30864941ee02b02329e2bfd056e2f5bcf97c1e1b3d4684a1818f397870c", transactionIndex: "60", from: "0xfd53570b7fd5af2e89e822db74636f99d16303e7", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "1704624", gasPrice: "5099999904", isError: "0", txreceipt_status: "1", input: "0x1801fbe5e7dc2b88558ddab3f191d570fc6dc4f23612000085d7fd8acfee60677df6ab78000000000013f7c25ee29df6bf9ea9290e5ab9c474f2e1f07c1d53310ae6f92b", contractAddress: "", cumulativeGasUsed: "3694192", gasUsed: "176776", confirmations: "1091647"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "104873274827641339262967141604026262991406535572339340301633607636415753399160"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000013f7c25ee29df6bf9ea9290e5ab9c474f2e1f07c1d53310ae6f92b"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "104873274827641339262967141604026262991406535572339340301633607636415753399160", "0x000000000013f7c25ee29df6bf9ea9290e5ab9c474f2e1f07c1d53310ae6f92b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541188528 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xfd53570b7fd5af2e89e822db74636f99d16303e7"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19725"}, {name: "newChallengeNumber", type: "bytes32", value: "0x9766e250ac7cc8c1c4f519e5f5a0dfb2a43daa8e64a6d5aede39f0d98dde7f47"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0xaba247e0cb09939a28378336afb257b4b3286e0b"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3736809729504285" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"84856165121779156202312305501411637360... )", async function( ) {
		const txOriginal = {blockNumber: "6631579", timeStamp: "1541188777", hash: "0x600f36b9ffc3e81666645603c3f87a1a97855db7458f1c219793a40ae3e98b02", nonce: "16178", blockHash: "0xbf70cb2e1840fbbaf02c3c64281c2d3b53a78bd1329b5b00ac3b47a6acf0da0b", transactionIndex: "41", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176648", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe512c2b05197ec625fa5724b6b05b21f01000000008687986510486e5bc3439e4d0000000000108794344b866a0fa4594f09f27a7ad1c1259bdde3042042ebbe09", contractAddress: "", cumulativeGasUsed: "2719815", gasUsed: "176648", confirmations: "1091628"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "8485616512177915620231230550141163736008542264053925930866991365124302020173"}, {type: "bytes32", name: "challenge_digest", value: "0x0000000000108794344b866a0fa4594f09f27a7ad1c1259bdde3042042ebbe09"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "8485616512177915620231230550141163736008542264053925930866991365124302020173", "0x0000000000108794344b866a0fa4594f09f27a7ad1c1259bdde3042042ebbe09", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541188777 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19726"}, {name: "newChallengeNumber", type: "bytes32", value: "0x73edd58916ad66484a135d57fe6db94124bcdbbbf7e16a14fb0a9af5599fc4ff"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0xaba247e0cb09939a28378336afb257b4b3286e0b"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"90462569716653277723650364599558529442... )", async function( ) {
		const txOriginal = {blockNumber: "6631628", timeStamp: "1541189468", hash: "0xead1fe58b4896b47403fd726f80ccedef8e9d00de9f565a141c322e35acafb41", nonce: "16179", blockHash: "0x566ce5418d90d098e5af9ba9051d3177ba2b7e9c9e576c47b5795ec249bb131a", transactionIndex: "116", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176264", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5020000000000000013fa540700bdb5a0e603000057691266ac84af05af222add0000000000162841cda86b5112c958aecd3576478cf701d816fb4be1df3fa12c", contractAddress: "", cumulativeGasUsed: "6352171", gasUsed: "176264", confirmations: "1091579"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "904625697166532777236503645995585294426324562894376958368588986452329769693"}, {type: "bytes32", name: "challenge_digest", value: "0x0000000000162841cda86b5112c958aecd3576478cf701d816fb4be1df3fa12c"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "904625697166532777236503645995585294426324562894376958368588986452329769693", "0x0000000000162841cda86b5112c958aecd3576478cf701d816fb4be1df3fa12c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541189468 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19727"}, {name: "newChallengeNumber", type: "bytes32", value: "0x8966b74a217f0c248e80fcb9eba58eef6ca8ebcddcb4b1dfc4954dd237de77ef"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x321be43d5bad6991ae4ce6792aff46c08f7b0ed9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"29616636044561638559824699825514216679... )", async function( ) {
		const txOriginal = {blockNumber: "6631723", timeStamp: "1541190648", hash: "0x4f10bb3df3a99d5cc41c8d86ec8ad6bf11251fa051f6cec784a6edd5a7f069f0", nonce: "16183", blockHash: "0x9ac69d91d3fd7e331f57b8788d52bcb0906bc37a2fecdcc92265d61634d2c9e1", transactionIndex: "75", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176840", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5417a6c05caa585014290cfeeb3ee6dcb642805000d4a976462caa840beb1505a0000000000167802c3b765735b7b542acae69b0e806ba1e18018c6689e213e66", contractAddress: "", cumulativeGasUsed: "3833165", gasUsed: "176840", confirmations: "1091484"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "29616636044561638559824699825514216679721602770855520552619265687572815368282"}, {type: "bytes32", name: "challenge_digest", value: "0x0000000000167802c3b765735b7b542acae69b0e806ba1e18018c6689e213e66"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "29616636044561638559824699825514216679721602770855520552619265687572815368282", "0x0000000000167802c3b765735b7b542acae69b0e806ba1e18018c6689e213e66", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541190648 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19728"}, {name: "newChallengeNumber", type: "bytes32", value: "0xfcbea16da41136087a3c9a02037ff2a05457417f8d20dc1d10cdd5229014f16a"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x321be43d5bad6991ae4ce6792aff46c08f7b0ed9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"68221442626348015091341161616298169210... )", async function( ) {
		const txOriginal = {blockNumber: "6631776", timeStamp: "1541191308", hash: "0x2aacfa18c40e4ff71445628c4816c03707972e979a870b7791ffbfd6f5867041", nonce: "16184", blockHash: "0x9e2873c677e39f96aa296a467fd2687f52cf137eb673fbf5fe9be2f13c967bdf", transactionIndex: "69", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176648", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe596d3f7d9fbf3ef0518ff3fbdc59f2a01000000000ea6439371907022bac6e1250000000000018662918d30d6d467a682556b62890cf937cc7531e6be96f79233", contractAddress: "", cumulativeGasUsed: "3273953", gasUsed: "176648", confirmations: "1091431"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "68221442626348015091341161616298169210750008554467301551673270721020657328421"}, {type: "bytes32", name: "challenge_digest", value: "0x0000000000018662918d30d6d467a682556b62890cf937cc7531e6be96f79233"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "68221442626348015091341161616298169210750008554467301551673270721020657328421", "0x0000000000018662918d30d6d467a682556b62890cf937cc7531e6be96f79233", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541191308 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19729"}, {name: "newChallengeNumber", type: "bytes32", value: "0xf8d5be576065aded9a876e04d05248cddf325578a15328c968979771e775b64e"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x321be43d5bad6991ae4ce6792aff46c08f7b0ed9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"90462569716653278279309555874500810810... )", async function( ) {
		const txOriginal = {blockNumber: "6631782", timeStamp: "1541191395", hash: "0x4f3e0dfc65b4bafe8ca62418873ac62d9da03e03a3c79d4059210779727fc8f4", nonce: "16185", blockHash: "0x34cd0d94122963b6e7efdf066d0c7aea80c100af1f3e0f88fc7af8ed811332d0", transactionIndex: "129", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176392", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe50200000000000000f697daccd5ac8fa8d20f0300c9839f9e1de0c5bd51d091c4000000000002ad37097d303436e59bd4d6f473ffc1468292ca96b43c30fdc772", contractAddress: "", cumulativeGasUsed: "7469287", gasUsed: "176392", confirmations: "1091425"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "904625697166532782793095558745008108100303773679755895933654528760183034308"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000002ad37097d303436e59bd4d6f473ffc1468292ca96b43c30fdc772"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "904625697166532782793095558745008108100303773679755895933654528760183034308", "0x000000000002ad37097d303436e59bd4d6f473ffc1468292ca96b43c30fdc772", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541191395 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19730"}, {name: "newChallengeNumber", type: "bytes32", value: "0x8b663471870e3d52c7494f203541085e3f54404bdb1332d783ed138d7df0b439"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x321be43d5bad6991ae4ce6792aff46c08f7b0ed9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"29616636044561638559824699824840830223... )", async function( ) {
		const txOriginal = {blockNumber: "6631798", timeStamp: "1541191617", hash: "0x1a10fce1537fce7380a88490120c957349a5adb2d8fb2c183f87128be9f6a66a", nonce: "16186", blockHash: "0xf038252a2493159ab1e901580bab9b850f843f7b10a29a155245106cdcaebdd1", transactionIndex: "101", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176840", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5417a6c05caa585014290cfee3dfabc61762d05000d4a976462caa840beb1505a000000000015f796e8f82739734c049fb670f968158a6512b94bf47b8e9e27d0", contractAddress: "", cumulativeGasUsed: "5413957", gasUsed: "176840", confirmations: "1091409"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "29616636044561638559824699824840830223531381855322137119679139255417801101402"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000015f796e8f82739734c049fb670f968158a6512b94bf47b8e9e27d0"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "29616636044561638559824699824840830223531381855322137119679139255417801101402", "0x000000000015f796e8f82739734c049fb670f968158a6512b94bf47b8e9e27d0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541191617 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19731"}, {name: "newChallengeNumber", type: "bytes32", value: "0x05d2297ffa1d8489fef0c68c86deb2040010b91cf29f9e79ebd4776953d844af"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x357f54b5d4f5552f2283f05edab11236e865f8fb"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"22623181325128119760875114107993362541... )", async function( ) {
		const txOriginal = {blockNumber: "6631802", timeStamp: "1541191680", hash: "0x99e8e63fae53c8bbc0522cac44c1b48a636e5bf8569c12d7f4105376c1443a38", nonce: "16187", blockHash: "0x8a59ea06c268ea4f087a6f849f7aecdd29a475a534a7dde79452f88ce39c83dc", transactionIndex: "33", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176648", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe532044451315cabd2fbe684b7e5a63d0100000000feb674785f952002cbe0e811000000000010c63c1f1b34189a4452fcb66bea56de53980f8eae6ffa576175ba", contractAddress: "", cumulativeGasUsed: "2958741", gasUsed: "176648", confirmations: "1091405"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "22623181325128119760875114107993362541052202921878489693026236998561719969809"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000010c63c1f1b34189a4452fcb66bea56de53980f8eae6ffa576175ba"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "22623181325128119760875114107993362541052202921878489693026236998561719969809", "0x000000000010c63c1f1b34189a4452fcb66bea56de53980f8eae6ffa576175ba", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541191680 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19732"}, {name: "newChallengeNumber", type: "bytes32", value: "0x4aaf70b2a999dec04234595f793dcd5f4b6b2e80e32b9f778b92bfb1155af61b"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x5760b91b7f91d06ccbe6e935d6efbc8e8d69768b"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"10487327482764133926296714160374200493... )", async function( ) {
		const txOriginal = {blockNumber: "6631810", timeStamp: "1541191875", hash: "0x7b2583609585e1cc741e9ce93f1d9abf88c96f7735e9c91f3ce806b55d5a8ea7", nonce: "513", blockHash: "0x9c5f8389193b3609b76f43cbf3efd965143109ded0a5f61ac0c0aa8964934817", transactionIndex: "64", from: "0xfd53570b7fd5af2e89e822db74636f99d16303e7", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "1704624", gasPrice: "5099999904", isError: "0", txreceipt_status: "1", input: "0x1801fbe5e7dc2b88558ddab3f191d570caa3327db422000085d7fd8acfee60677df6ab78000000000014d343dbc144b8d33014af6f1cdf5ebae1f2c2e7f2996d1af32f71", contractAddress: "", cumulativeGasUsed: "5285048", gasUsed: "176776", confirmations: "1091397"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "104873274827641339262967141603742004935066847087250151361454211358911565835128"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000014d343dbc144b8d33014af6f1cdf5ebae1f2c2e7f2996d1af32f71"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "104873274827641339262967141603742004935066847087250151361454211358911565835128", "0x000000000014d343dbc144b8d33014af6f1cdf5ebae1f2c2e7f2996d1af32f71", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541191875 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xfd53570b7fd5af2e89e822db74636f99d16303e7"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19733"}, {name: "newChallengeNumber", type: "bytes32", value: "0x7ee9c22cfef4a4be2ff63ab04a06c3a195e4594e02f00fd97e6c8afec49fc6f9"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x6136e93494534f55e33ad085bef8f1810f2b09d9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3736809729504285" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"10229625548915773537311377341123747922... )", async function( ) {
		const txOriginal = {blockNumber: "6631829", timeStamp: "1541192153", hash: "0xea1ff5c0e393a3f6271d6735ef661a589e44eb1cb7d0077b2c0dc846d3dc6cf2", nonce: "16188", blockHash: "0x3267bd476728067ad0fde0618b737c8ddfb7835543aa58994167e55e4bf0897c", transactionIndex: "49", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176584", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5169dc34c0d7c28abf874c36a25bf3e0000000000926facac951874713caf42cf00000000000e0bd32f63ddf44b7a84ca0eb92f6ff2414cd4319198aaf4fbc79f", contractAddress: "", cumulativeGasUsed: "3167350", gasUsed: "176584", confirmations: "1091378"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "10229625548915773537311377341123747922284676200314646181627671672983280108239"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000000e0bd32f63ddf44b7a84ca0eb92f6ff2414cd4319198aaf4fbc79f"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "10229625548915773537311377341123747922284676200314646181627671672983280108239", "0x00000000000e0bd32f63ddf44b7a84ca0eb92f6ff2414cd4319198aaf4fbc79f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541192153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19734"}, {name: "newChallengeNumber", type: "bytes32", value: "0xa37927b66037b8643bf5c3908cf6d0b9f56b833dc60a0a637b1a39e3f37ada71"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x6cb9ad9ad3395debe26bbf0fb0af6c8b593eb456"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"10487327482764133926296714160276664460... )", async function( ) {
		const txOriginal = {blockNumber: "6631900", timeStamp: "1541193112", hash: "0xa2e899f09e57de5bedbb48fb94140e24641c8fb17d136c56319c92c665f9faf6", nonce: "514", blockHash: "0x06b9dc2b788870225647c0c7787ccf7bbe2ab81d2d6c1e0e922de4439a7a13a4", transactionIndex: "21", from: "0xfd53570b7fd5af2e89e822db74636f99d16303e7", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "1704624", gasPrice: "5099999904", isError: "0", txreceipt_status: "1", input: "0x1801fbe5e7dc2b88558ddab3f191d5701fca8706e128000085d7fd8acfee60677df6ab7800000000000455ddc9e9c94c816dec90d9ebfd93d8044f4b2a0eb5b204fcc82b", contractAddress: "", cumulativeGasUsed: "1545671", gasUsed: "176776", confirmations: "1091307"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "104873274827641339262967141602766644606429262172529563885499711903310955326328"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000000455ddc9e9c94c816dec90d9ebfd93d8044f4b2a0eb5b204fcc82b"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "104873274827641339262967141602766644606429262172529563885499711903310955326328", "0x00000000000455ddc9e9c94c816dec90d9ebfd93d8044f4b2a0eb5b204fcc82b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541193112 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xfd53570b7fd5af2e89e822db74636f99d16303e7"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19735"}, {name: "newChallengeNumber", type: "bytes32", value: "0x528357afefde56c2d10fe5cce0c78e4c4c8eb65f329db71a3fdbd585d259faf2"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x207e99a1d1481ba497d5a4bfe55a52bc823be410"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3736809729504285" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"10487327482764133926296714160353214533... )", async function( ) {
		const txOriginal = {blockNumber: "6632016", timeStamp: "1541194546", hash: "0x740d083ddfb0d4cdff0464665f83d5b5e88d03e41967d928af21628f9bbf31bf", nonce: "515", blockHash: "0x849c2f490b49597ec27fd4c073e8e7e6556b5e61ad7bb66082ce048e74c333ec", transactionIndex: "13", from: "0xfd53570b7fd5af2e89e822db74636f99d16303e7", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "1704624", gasPrice: "5099999904", isError: "0", txreceipt_status: "1", input: "0x1801fbe5e7dc2b88558ddab3f191d570a5e0c476f12f000085d7fd8acfee60677df6ab7800000000001148bbac11597f308ff68bcd4eaf846586220c2dd817aae827756b", contractAddress: "", cumulativeGasUsed: "924425", gasUsed: "176776", confirmations: "1091191"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "104873274827641339262967141603532145338096395269016640700642325873654458919800"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000001148bbac11597f308ff68bcd4eaf846586220c2dd817aae827756b"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "104873274827641339262967141603532145338096395269016640700642325873654458919800", "0x00000000001148bbac11597f308ff68bcd4eaf846586220c2dd817aae827756b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541194546 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xfd53570b7fd5af2e89e822db74636f99d16303e7"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19736"}, {name: "newChallengeNumber", type: "bytes32", value: "0x4003736527a3b5f75c40189c4db91b6b50535677931ce1a29eca8e71dc262009"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x74267eedbedabf6643ede15818d20f1ef2f2edcd"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3736809729504285" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"29616636044561638559824699825832861229... )", async function( ) {
		const txOriginal = {blockNumber: "6632037", timeStamp: "1541194854", hash: "0xcd68ffcd643f0348e96fb5968c640abf9d7275d2364484a957c0f38a9402a015", nonce: "16189", blockHash: "0xbe93aa3cf05dc7df328bb7b125042dc957dda8acaf18c05ab19e13220f807d20", transactionIndex: "63", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176840", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5417a6c05caa585014290cfeeebbef1d5343e05000d4a976462caa840beb1505a0000000000093c1715b74616cc5d6db7129cbfb85bd31d57307a4e4d3edc7686", contractAddress: "", cumulativeGasUsed: "3202622", gasUsed: "176840", confirmations: "1091170"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "29616636044561638559824699825832861229279086262596936688595790817425133490266"}, {type: "bytes32", name: "challenge_digest", value: "0x0000000000093c1715b74616cc5d6db7129cbfb85bd31d57307a4e4d3edc7686"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "29616636044561638559824699825832861229279086262596936688595790817425133490266", "0x0000000000093c1715b74616cc5d6db7129cbfb85bd31d57307a4e4d3edc7686", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541194854 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19737"}, {name: "newChallengeNumber", type: "bytes32", value: "0xa53b9594a066c86ba0bcdbbed667ad19877625858666c1f65a88c92cbb1845ce"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x74267eedbedabf6643ede15818d20f1ef2f2edcd"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"29616636044561638559824699824695394291... )", async function( ) {
		const txOriginal = {blockNumber: "6632051", timeStamp: "1541195037", hash: "0xc0c6b5876128d4a2132c4f05483d876a2c83786fa8fe187333c5df879b37de44", nonce: "16190", blockHash: "0x3a40a97d5c158b6bf9faf4a65d694d174a6947d8205a19861d4e17197b863590", transactionIndex: "65", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176776", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5417a6c05caa585014290cfee248129c1483f05000d4a976462caa840beb1505a00000000000075a79e6e1c27d4276c6a62ecafe7683d02a38eea16e6b511f764", contractAddress: "", cumulativeGasUsed: "3774584", gasUsed: "176776", confirmations: "1091156"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "29616636044561638559824699824695394291191787891007365636337673155346747707482"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000000075a79e6e1c27d4276c6a62ecafe7683d02a38eea16e6b511f764"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "29616636044561638559824699824695394291191787891007365636337673155346747707482", "0x00000000000075a79e6e1c27d4276c6a62ecafe7683d02a38eea16e6b511f764", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541195037 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19738"}, {name: "newChallengeNumber", type: "bytes32", value: "0x1df71c1b37a655cb49af11963fde7e924e6f4840ca6462e0bf6f7e1ceb40d2b6"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[27,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x6cb9ad9ad3395debe26bbf0fb0af6c8b593eb456"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[27,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"52039858673514283493858349921840754594... )", async function( ) {
		const txOriginal = {blockNumber: "6632078", timeStamp: "1541195469", hash: "0xf8a43c13e7fdaf350414450e55886ab908a6154f0d1c9d8eb532ffad6de99878", nonce: "16191", blockHash: "0x3a391a5744e39be7016f276ebb690e00e80c9d9be252cfae69a97a05eb69368d", transactionIndex: "130", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176648", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5730d8426ba1edb6b759f85c1833c1c01000000002ef23a97a3cb0be026434d5a0000000000114caf1c14e9af587ae37fea2d3809130778f05e4950439debbbb9", contractAddress: "", cumulativeGasUsed: "7067824", gasUsed: "176648", confirmations: "1091129"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "52039858673514283493858349921840754594929851089270986604733228155704654908762"}, {type: "bytes32", name: "challenge_digest", value: "0x0000000000114caf1c14e9af587ae37fea2d3809130778f05e4950439debbbb9"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "52039858673514283493858349921840754594929851089270986604733228155704654908762", "0x0000000000114caf1c14e9af587ae37fea2d3809130778f05e4950439debbbb9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541195469 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19739"}, {name: "newChallengeNumber", type: "bytes32", value: "0xf32fa306669ea531624babe037d6f8d3fa34914728f68953b2e785ee8c8e0437"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0xd9a3ea0acdb41a12e871482a8eef99a017e38bf4"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"13678099458433655552075271602167798438... )", async function( ) {
		const txOriginal = {blockNumber: "6632101", timeStamp: "1541195838", hash: "0x073f173759853acbb732318ac9877f413e3f448371e7a017ebd64c13dd4fbd74", nonce: "16192", blockHash: "0xc407093ede55d971e7f4ffd1898a0593a630166f0dbb9ad729d1f134eb88fd3c", transactionIndex: "86", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176584", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe51e3d87aa68cc14b0e307ddffba7a690000000000197f04b0fceaf9186c78a9780000000000130d292d4b4c627cd102ddf1cc483d91b9400ee297277e12165c35", contractAddress: "", cumulativeGasUsed: "4132802", gasUsed: "176584", confirmations: "1091106"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "13678099458433655552075271602167798438101053743871960327419937587337362975096"}, {type: "bytes32", name: "challenge_digest", value: "0x0000000000130d292d4b4c627cd102ddf1cc483d91b9400ee297277e12165c35"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "13678099458433655552075271602167798438101053743871960327419937587337362975096", "0x0000000000130d292d4b4c627cd102ddf1cc483d91b9400ee297277e12165c35", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541195838 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19740"}, {name: "newChallengeNumber", type: "bytes32", value: "0x76d22c0be6d7bc25025c89518ce3beffc44fd14915f47dcddab3e9e9e4163089"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x6cb9ad9ad3395debe26bbf0fb0af6c8b593eb456"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"29616636044561638559824699825629891302... )", async function( ) {
		const txOriginal = {blockNumber: "6632145", timeStamp: "1541196508", hash: "0xc69599dc06e3e48460e0669c3f0f3565108f769bc6675c7cd599982d841ab66c", nonce: "16193", blockHash: "0x260d2ea0346b511930582395ee0cd1b855d970fad0ea2501ef31191994709fc3", transactionIndex: "30", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176840", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5417a6c05caa585014290cfeec8317557d04605000d4a976462caa840beb1505a00000000000fa6cf3b0874a8484704d68b5267315d3c0b42e7b71a9d1704f192", contractAddress: "", cumulativeGasUsed: "1791230", gasUsed: "176840", confirmations: "1091062"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "29616636044561638559824699825629891302635626396794304693641701374280674136154"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000000fa6cf3b0874a8484704d68b5267315d3c0b42e7b71a9d1704f192"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "29616636044561638559824699825629891302635626396794304693641701374280674136154", "0x00000000000fa6cf3b0874a8484704d68b5267315d3c0b42e7b71a9d1704f192", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541196508 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19741"}, {name: "newChallengeNumber", type: "bytes32", value: "0x072e40c465a0d391d66cc26367383f341e07b6bcd7c3cc70ffa27209433c552f"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x6cb9ad9ad3395debe26bbf0fb0af6c8b593eb456"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"47961567530161462297756675699302441577... )", async function( ) {
		const txOriginal = {blockNumber: "6632197", timeStamp: "1541197299", hash: "0x74296ab4ee2be2ea6ddd107aa0ebb654741e7fa962b2cf0503e465e70912882a", nonce: "16194", blockHash: "0x92c300af8c62f075d0d37db955efc948ada000d98195c1956b5da175e738ff84", transactionIndex: "29", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176584", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe56a094904cb7b4c6df92334bc9154bb0000000000d99de4da95c0472468bf4815000000000014a864b5d2750b4abab65f484573c7ed66d39103198d33f6dd44ad", contractAddress: "", cumulativeGasUsed: "2702777", gasUsed: "176584", confirmations: "1091010"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "47961567530161462297756675699302441577572715085574708952554245233774556039189"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000014a864b5d2750b4abab65f484573c7ed66d39103198d33f6dd44ad"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "47961567530161462297756675699302441577572715085574708952554245233774556039189", "0x000000000014a864b5d2750b4abab65f484573c7ed66d39103198d33f6dd44ad", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541197299 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19742"}, {name: "newChallengeNumber", type: "bytes32", value: "0xbb89a470fe1393a9ecee54fac1ade79e0e3b987a924626c40f708311b0506ce2"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x6cb9ad9ad3395debe26bbf0fb0af6c8b593eb456"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"37341358477971607806863848393459136544... )", async function( ) {
		const txOriginal = {blockNumber: "6632219", timeStamp: "1541197621", hash: "0x2eb7fe281624e24578341af6a6ca67a92dfc9d901679a87c280c08927beb311a", nonce: "16195", blockHash: "0xfff171cdf5bf908d2345ba9f9b9d27192d8ab8ee0ff184eef07adf288d4fc52a", transactionIndex: "60", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176584", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5528e75bd6a480a7440fad582e93c6200000000000b8310cbc0a49fcc158b7ce9000000000012f434179595430740777ec47775a9cdb1e46e49060e3a9b3893d7", contractAddress: "", cumulativeGasUsed: "3169545", gasUsed: "176584", confirmations: "1090988"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "37341358477971607806863848393459136544694160876496545315369156129854939954409"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000012f434179595430740777ec47775a9cdb1e46e49060e3a9b3893d7"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "37341358477971607806863848393459136544694160876496545315369156129854939954409", "0x000000000012f434179595430740777ec47775a9cdb1e46e49060e3a9b3893d7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541197621 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19743"}, {name: "newChallengeNumber", type: "bytes32", value: "0x9047d47229eb73757a3562202803067c00156e4141696245ed17e42db47ae2d5"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x9f5f1dfdcfcf2a372ed8b3cda388d27c664454c1"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"10487327482764133926296714160265151836... )", async function( ) {
		const txOriginal = {blockNumber: "6632289", timeStamp: "1541198540", hash: "0x8c646e09ed11e1ec436d97d34e605bc68d26ce933c0060d3ee146b2f91e48e1f", nonce: "516", blockHash: "0xf741837a1385a54273b6d866c17606290da7633fb455150f64c9273dc24be727", transactionIndex: "39", from: "0xfd53570b7fd5af2e89e822db74636f99d16303e7", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "1704624", gasPrice: "5099999904", isError: "0", txreceipt_status: "1", input: "0x1801fbe5e7dc2b88558ddab3f191d5700ba0169f5f43000085d7fd8acfee60677df6ab78000000000014a6913aae00afcad2f4b9b73074a8971428dc89001fe4a3fec97c", contractAddress: "", cumulativeGasUsed: "3791133", gasUsed: "176648", confirmations: "1090918"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "104873274827641339262967141602651518367916679498431811726040447617651243920248"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000014a6913aae00afcad2f4b9b73074a8971428dc89001fe4a3fec97c"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "104873274827641339262967141602651518367916679498431811726040447617651243920248", "0x000000000014a6913aae00afcad2f4b9b73074a8971428dc89001fe4a3fec97c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541198540 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xfd53570b7fd5af2e89e822db74636f99d16303e7"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19744"}, {name: "newChallengeNumber", type: "bytes32", value: "0xc443cbddc6443ec756b914f521d5da3dcdee6414673a91b84d7dd01b90229194"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x09216dcd39cc9e81fbf1dcdbac0942bbfb0d9f0e"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "3736809729504285" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"11323661794144677616639873263878669715... )", async function( ) {
		const txOriginal = {blockNumber: "6632349", timeStamp: "1541199243", hash: "0xedb230f9ba303dab65048bf32101264775c2f1676b4292122008af573954e1dc", nonce: "16196", blockHash: "0xaf90b9c47c9f776408c9263c068d36d8a2f73b2a8b84de9259f14f32a8df13df", transactionIndex: "34", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176520", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5fa59a78d83ba3367b60d52539dc02d0000000000607cc96cea52007e3c44050f000000000001e2976daaeecfe38726d8812447965dd3d6877cfa64d0f6514e9f", contractAddress: "", cumulativeGasUsed: "3509666", gasUsed: "176520", confirmations: "1090858"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "113236617941446776166398732638786697155755114663704432074271724710998512502031"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000001e2976daaeecfe38726d8812447965dd3d6877cfa64d0f6514e9f"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "113236617941446776166398732638786697155755114663704432074271724710998512502031", "0x000000000001e2976daaeecfe38726d8812447965dd3d6877cfa64d0f6514e9f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541199243 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19745"}, {name: "newChallengeNumber", type: "bytes32", value: "0xe3045b49c01816b8c43f4082223a752c59979e163764125c4f5c1c89c55c281e"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x9f5f1dfdcfcf2a372ed8b3cda388d27c664454c1"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"29616636044561638559824699824970389632... )", async function( ) {
		const txOriginal = {blockNumber: "6632380", timeStamp: "1541199682", hash: "0x95e6bb234c7f5c52b865f27249a11e1175a68224a4848e670b706341cb744996", nonce: "16197", blockHash: "0xd96b9dfe78551b412fe1b4a6d32c5384d21543b66cd47c7d97294bee576ef309", transactionIndex: "44", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176840", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5417a6c05caa585014290cfee54ac6176215705000d4a976462caa840beb1505a000000000018c2cc9d9fe288211beb8f55b58ac20575f7f1dacd1acfce0d5874", contractAddress: "", cumulativeGasUsed: "2750253", gasUsed: "176840", confirmations: "1090827"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "29616636044561638559824699824970389632949988387758063146362812942084423635034"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000018c2cc9d9fe288211beb8f55b58ac20575f7f1dacd1acfce0d5874"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "29616636044561638559824699824970389632949988387758063146362812942084423635034", "0x000000000018c2cc9d9fe288211beb8f55b58ac20575f7f1dacd1acfce0d5874", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541199682 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19746"}, {name: "newChallengeNumber", type: "bytes32", value: "0x4d1aa32a65d4e3c18995b7ecb23631812fde262338b1a993a308a5d19eac36f6"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x9f5f1dfdcfcf2a372ed8b3cda388d27c664454c1"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"90462569716653277824816381354628716757... )", async function( ) {
		const txOriginal = {blockNumber: "6632403", timeStamp: "1541200047", hash: "0x8b2bea1b400ba2129f2a142ec9e8d51abfa70c73114f4b61e91d21cf4f6bb2bc", nonce: "16198", blockHash: "0xdc6f9e28b740889480ff00a15415975b6b31c24e158f2398f32ff095067c5f5e", transactionIndex: "118", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176328", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe502000000000000003d3c8d9f2daa0d082dc902003e308bd12b0b4dd292d43c6d00000000001071e8dcd701e02cc46834e73ab0c58df50b8037d4fb0067dd92b5", contractAddress: "", cumulativeGasUsed: "7472602", gasUsed: "176328", confirmations: "1090804"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "904625697166532778248163813546287167579219714482661799727573374690986835053"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000001071e8dcd701e02cc46834e73ab0c58df50b8037d4fb0067dd92b5"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "904625697166532778248163813546287167579219714482661799727573374690986835053", "0x00000000001071e8dcd701e02cc46834e73ab0c58df50b8037d4fb0067dd92b5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541200047 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19747"}, {name: "newChallengeNumber", type: "bytes32", value: "0xf1c8d07180484977e6b68624adaaa71b7eca9cd1d40116691dbe13f6056f7452"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x207e99a1d1481ba497d5a4bfe55a52bc823be410"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"29616636044561638559824699824713032139... )", async function( ) {
		const txOriginal = {blockNumber: "6632419", timeStamp: "1541200242", hash: "0x68181dccdac2fbaa3af5be2df98b35fc5582d69278ca9d0dfb417ad23f4105c9", nonce: "16199", blockHash: "0x823e7bb137f724430a5e1ce426dcf466e7b8248766ce9dbaa1b8c7cf2ff80077", transactionIndex: "25", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "279638", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5417a6c05caa585014290cfee279812544d5a05000d4a976462caa840beb1505a000000000016808e6504ab1f88a05710f3f15b8f4291009f9ad3867f3cad9542", contractAddress: "", cumulativeGasUsed: "2324942", gasUsed: "264638", confirmations: "1090788"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "29616636044561638559824699824713032139977257521038460019344306599686304780378"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000016808e6504ab1f88a05710f3f15b8f4291009f9ad3867f3cad9542"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "29616636044561638559824699824713032139977257521038460019344306599686304780378", "0x000000000016808e6504ab1f88a05710f3f15b8f4291009f9ad3867f3cad9542", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541200242 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19748"}, {name: "newChallengeNumber", type: "bytes32", value: "0x6c16efbfd71ab19ee5f9138f651a780aafb2d47d093df78905ad96a9939537a4"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x321be43d5bad6991ae4ce6792aff46c08f7b0ed9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"90686787535585551603758752336347102159... )", async function( ) {
		const txOriginal = {blockNumber: "6632439", timeStamp: "1541200567", hash: "0x34158c8fad8f6e85981a1c97e0bbac5215b1d5014d2380dfdd727e4b1076ded1", nonce: "16200", blockHash: "0xc7991c070c2d26ecf7d0ba1064227138729405b235a217b6aa5621e39dd9b11d", transactionIndex: "75", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176584", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5c87ee71d217a586164f5b34110bda500000000007c544a205f9e1329b19b6eba00000000001474c35230edf30f8d26f52e37ed9dbae73c66f058b9cee827dafe", contractAddress: "", cumulativeGasUsed: "6213864", gasUsed: "176584", confirmations: "1090768"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "90686787535585551603758752336347102159198931104893631772888629840618406506170"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000001474c35230edf30f8d26f52e37ed9dbae73c66f058b9cee827dafe"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "90686787535585551603758752336347102159198931104893631772888629840618406506170", "0x00000000001474c35230edf30f8d26f52e37ed9dbae73c66f058b9cee827dafe", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541200567 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19749"}, {name: "newChallengeNumber", type: "bytes32", value: "0xf5b74d064373ec8a6bdbaa9796cd5b20da669943b4eed1d3e6c285b80897009c"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0xaba247e0cb09939a28378336afb257b4b3286e0b"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"29616638622374889448075693381034379974... )", async function( ) {
		const txOriginal = {blockNumber: "6632746", timeStamp: "1541205188", hash: "0x77a3904d9bd93fa45aadf375afa0ea767c41fd7020a7e13e23e9a8aa2805df7b", nonce: "44", blockHash: "0x3547a1728f7b750bc124ace7467dd78d90bd5bf8373dd4c1cd484ac9f83a415b", transactionIndex: "47", from: "0xe0c8b2ec96e88d703271953f4b443c8f63764838", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "191776", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5417a6c656872696145b9e76ce3566378e5020000718d2258c19467bf3295a67a00000000001282130d2a3da01a29a41847eeaf19b5ea38c00d2776500460a5bd", contractAddress: "", cumulativeGasUsed: "1347995", gasUsed: "191776", confirmations: "1090461"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "29616638622374889448075693381034379974811276800935041968373449653837362472570"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000001282130d2a3da01a29a41847eeaf19b5ea38c00d2776500460a5bd"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "29616638622374889448075693381034379974811276800935041968373449653837362472570", "0x00000000001282130d2a3da01a29a41847eeaf19b5ea38c00d2776500460a5bd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541205188 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xe0c8b2ec96e88d703271953f4b443c8f63764838"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19750"}, {name: "newChallengeNumber", type: "bytes32", value: "0xf4c507c8c8c709503f4e086f087d7d934710a3eb3f020c941f2c830b39a0f6f3"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[39,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0xaba247e0cb09939a28378336afb257b4b3286e0b"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[39,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "3262210500000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"16690408346250494640040675351946321281... )", async function( ) {
		const txOriginal = {blockNumber: "6632841", timeStamp: "1541206513", hash: "0x7feb1f3b3e303f177853c96dc6678ab34793e3515be7e16fabe47829fb5ad740", nonce: "16201", blockHash: "0x03d4a1cdc0916742c96f7ac9fef0c3f21535b30415c232196f49990a6ec44f66", transactionIndex: "97", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176584", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe524e66fb4f437620e147d4519c7c87200000000001985f03b97fd49b798e2880500000000000d243bcd8280a66dbad661a5d04769d4a3fa3c1270230ff3966cdc", contractAddress: "", cumulativeGasUsed: "6991207", gasUsed: "176584", confirmations: "1090366"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "16690408346250494640040675351946321281883568782210732730733205475866745931781"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000000d243bcd8280a66dbad661a5d04769d4a3fa3c1270230ff3966cdc"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "16690408346250494640040675351946321281883568782210732730733205475866745931781", "0x00000000000d243bcd8280a66dbad661a5d04769d4a3fa3c1270230ff3966cdc", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541206513 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19751"}, {name: "newChallengeNumber", type: "bytes32", value: "0x617f9a1bb79bbc26decd5c3d8a909963d67a0285e84a6bda071da1e61e3a57d3"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x321be43d5bad6991ae4ce6792aff46c08f7b0ed9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"37144547952900803826884540980675522317... )", async function( ) {
		const txOriginal = {blockNumber: "6632851", timeStamp: "1541206710", hash: "0xa5a02f3e117cfbc897040e36a05c6cfd381020fb79feb04aaf53f80892d55adc", nonce: "16202", blockHash: "0x1c9b5426ea7eb0f446714ebd7b5c9446dab63d5e6598cdfa1b23099830888daf", transactionIndex: "86", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176584", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5521f11b150649dcfc1fd951a8a8e85000000000048a85ab842af90420438311900000000000bd873315dff2a12b67f729df2f9ef759b4816d1da6dd6b232baad", contractAddress: "", cumulativeGasUsed: "6072649", gasUsed: "176584", confirmations: "1090356"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "37144547952900803826884540980675522317336656325117543370855454283984092541209"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000000bd873315dff2a12b67f729df2f9ef759b4816d1da6dd6b232baad"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "37144547952900803826884540980675522317336656325117543370855454283984092541209", "0x00000000000bd873315dff2a12b67f729df2f9ef759b4816d1da6dd6b232baad", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541206710 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19752"}, {name: "newChallengeNumber", type: "bytes32", value: "0x0b2a64e0b94d1748530d1aa3fc71f4db452206eb52d82ffa6804c9b56ac65e6d"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x321be43d5bad6991ae4ce6792aff46c08f7b0ed9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"90462569716653277753671955763089795425... )", async function( ) {
		const txOriginal = {blockNumber: "6632886", timeStamp: "1541207252", hash: "0x62b76d28eb06ba2f1470b7d2ddb94e36d9bba679cb580f3191ba3a488c845287", nonce: "16203", blockHash: "0x8725ad5c6d036cae2a00f8da3227a36e28ce56d67fe990c68d1e7765af67fead", transactionIndex: "73", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176392", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe502000000000000002038ba85794bbebbc2eb02001f0d811a6473f02d44c65fea0000000000085642143fd334c3a8b290dd38d7f8fe90784060d738755b14701d", contractAddress: "", cumulativeGasUsed: "7341520", gasUsed: "176392", confirmations: "1090321"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "904625697166532777536719557630897954256635444792018706939220088479130476522"}, {type: "bytes32", name: "challenge_digest", value: "0x0000000000085642143fd334c3a8b290dd38d7f8fe90784060d738755b14701d"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "904625697166532777536719557630897954256635444792018706939220088479130476522", "0x0000000000085642143fd334c3a8b290dd38d7f8fe90784060d738755b14701d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541207252 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19753"}, {name: "newChallengeNumber", type: "bytes32", value: "0xeec2d735f61444ae3714d1b6e957c364ae61dffe0866649b036a51bd5477447f"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x321be43d5bad6991ae4ce6792aff46c08f7b0ed9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"87056399849764170083204529053395799613... )", async function( ) {
		const txOriginal = {blockNumber: "6632917", timeStamp: "1541207727", hash: "0x7d104c2c16e508a2f20ccab61a8bd4f42a2ab995da6f8c44d402ea54af732a05", nonce: "16204", blockHash: "0x2aa99d5355ca2d56b48c49d827c43096b87a874c9c55ef92624de8e989d555db", transactionIndex: "54", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176584", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe5133f37b5c789f452127b39d86179b500000000006522cb8c2424d5a480037ada00000000000b7909c67291ddf2c5e336622bc411d94cf4d2f9c0ce6de8c788f1", contractAddress: "", cumulativeGasUsed: "4723050", gasUsed: "176584", confirmations: "1090290"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "8705639984976417008320452905339579961352253916824422460928952365672539847386"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000000b7909c67291ddf2c5e336622bc411d94cf4d2f9c0ce6de8c788f1"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "8705639984976417008320452905339579961352253916824422460928952365672539847386", "0x00000000000b7909c67291ddf2c5e336622bc411d94cf4d2f9c0ce6de8c788f1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541207727 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19754"}, {name: "newChallengeNumber", type: "bytes32", value: "0x93c212f34eb6831d7363be3e6c51a3df387bd3897500eb03cc21fd82102dd919"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x321be43d5bad6991ae4ce6792aff46c08f7b0ed9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"71446057027200210524438487817798290025... )", async function( ) {
		const txOriginal = {blockNumber: "6632929", timeStamp: "1541207958", hash: "0x4216ad51ee23a544445c5fe3839fa1365ef9d94eeea2888323b6bc3c52cc61f5", nonce: "289", blockHash: "0x217e62965b0b84e4e5543a59509125615fc08966cc8c928d342556b4ee69cd10", transactionIndex: "43", from: "0x6696722c5cad75664a7dfe99fa2f9b0693c6de39", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "200000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe59df50905ad32916a32610a3b793ed3000000000081db64ed93dc9bd2af39938b0000000000116ece7433864f470684030146ccc6e419b243f66d565b29a8d8a4", contractAddress: "", cumulativeGasUsed: "2215966", gasUsed: "191584", confirmations: "1090278"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "71446057027200210524438487817798290025686754725739156823940234016955024642955"}, {type: "bytes32", name: "challenge_digest", value: "0x0000000000116ece7433864f470684030146ccc6e419b243f66d565b29a8d8a4"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "71446057027200210524438487817798290025686754725739156823940234016955024642955", "0x0000000000116ece7433864f470684030146ccc6e419b243f66d565b29a8d8a4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541207958 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0x6696722c5cad75664a7dfe99fa2f9b0693c6de39"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19755"}, {name: "newChallengeNumber", type: "bytes32", value: "0x7ce8e1ece7573e71a78aaef232daf889aff88d2f809b93a65b62251c0e0c0e64"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x357f54b5d4f5552f2283f05edab11236e865f8fb"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "156771332700000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"90462569716653278004647111524419393447... )", async function( ) {
		const txOriginal = {blockNumber: "6632936", timeStamp: "1541208082", hash: "0x8698a79eb23e2d765afa8be69fa5ed13fbc857913f67a8866c7594c3d8860740", nonce: "16205", blockHash: "0xdfc9be56d72067f8757b20ade0af24ca983b19ef017c7e89dd73882d1951bc49", transactionIndex: "95", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176392", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe502000000000000008693c1ea69564876a6170300aa625faaf6b8f36983f6ca7600000000000b98d55bc31cb60e109fe9b9ca556a643c486088091f55e6077c92", contractAddress: "", cumulativeGasUsed: "7757091", gasUsed: "176392", confirmations: "1090271"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "904625697166532780046471115244193934475055060116140913193192487099087374966"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000000b98d55bc31cb60e109fe9b9ca556a643c486088091f55e6077c92"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "904625697166532780046471115244193934475055060116140913193192487099087374966", "0x00000000000b98d55bc31cb60e109fe9b9ca556a643c486088091f55e6077c92", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1541208082 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19756"}, {name: "newChallengeNumber", type: "bytes32", value: "0xd87eef85d10bb9bddac30ea58b5216b4136c61e793bc8c914f4d613e90abfd2a"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x5760b91b7f91d06ccbe6e935d6efbc8e8d69768b"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"90462569716653277768044885054475091910... )", async function( ) {
		const txOriginal = {blockNumber: "6632998", timeStamp: "1541208905", hash: "0x67356e0e3d744d7788e6b2238f88918e233eb1b9e1d2761da26cd0e41317f7de", nonce: "16206", blockHash: "0x9b680b528043c21c4ab7e0572a536c6d3a07dd300d671b2746692dde43fc4211", transactionIndex: "43", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176264", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe502000000000000002615551a71214fe94614000022078c1039d3323e94505162000000000011eaba8636bff156172e367f5b5b979f864efa5673605c980017e5", contractAddress: "", cumulativeGasUsed: "2349768", gasUsed: "176264", confirmations: "1090209"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "904625697166532777680448850544750919107293347751414656993457384992061542754"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000011eaba8636bff156172e367f5b5b979f864efa5673605c980017e5"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "904625697166532777680448850544750919107293347751414656993457384992061542754", "0x000000000011eaba8636bff156172e367f5b5b979f864efa5673605c980017e5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541208905 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19757"}, {name: "newChallengeNumber", type: "bytes32", value: "0x3f2a4b84ba94a56ae5f28336a1ea92024c0510346efb5771836915181883311a"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x6136e93494534f55e33ad085bef8f1810f2b09d9"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"41887647506550964266138233971367748189... )", async function( ) {
		const txOriginal = {blockNumber: "6633059", timeStamp: "1541209813", hash: "0x7f1ea063f28a4cf85cc8ce9a1bdc8036f76b9b7911797784670fd15c888b67bf", nonce: "16207", blockHash: "0x59ce5ce1abb7cceb1545d47ae5aece915bdef9bd5e3a123636fef77bdd3f5833", transactionIndex: "84", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176584", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe50942c1bfc4e56815bb8c19b64a2a3000000000002cb6b35f4d8d9d9ad269f836000000000013be756e18b2bca09175318d4173c617e61316852946ac8ecc6636", contractAddress: "", cumulativeGasUsed: "5967754", gasUsed: "176584", confirmations: "1090148"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "4188764750655096426613823397136774818933757577352521513062046123813788842038"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000013be756e18b2bca09175318d4173c617e61316852946ac8ecc6636"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "4188764750655096426613823397136774818933757577352521513062046123813788842038", "0x000000000013be756e18b2bca09175318d4173c617e61316852946ac8ecc6636", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541209813 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19758"}, {name: "newChallengeNumber", type: "bytes32", value: "0xc8325ea337401f5200d4f222e3a830fa9e98d4e82e2957ac9bfe935c83df07a7"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x6cb9ad9ad3395debe26bbf0fb0af6c8b593eb456"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"21325122217018399426691255813973798423... )", async function( ) {
		const txOriginal = {blockNumber: "6633090", timeStamp: "1541210244", hash: "0x8a21a36344acbda3f397f43aab35b65518ba0cfecc10b5bffc840b226d52277a", nonce: "16208", blockHash: "0x24c001b895d511afa61fec5ea86730a0d45b704fa29822066c503441cd7c6189", transactionIndex: "22", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176520", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe52f259768ea4e3c1e0a09dd78df20d100000000008f4ab1745754d662a6f4484100000000001446240d111350007c30f2f1cc4cff8ba6d375c46172bf0242dc60", contractAddress: "", cumulativeGasUsed: "1214940", gasUsed: "176520", confirmations: "1090117"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "21325122217018399426691255813973798423144627493006935594243293111436778424385"}, {type: "bytes32", name: "challenge_digest", value: "0x00000000001446240d111350007c30f2f1cc4cff8ba6d375c46172bf0242dc60"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "21325122217018399426691255813973798423144627493006935594243293111436778424385", "0x00000000001446240d111350007c30f2f1cc4cff8ba6d375c46172bf0242dc60", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541210244 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19759"}, {name: "newChallengeNumber", type: "bytes32", value: "0x11170d3cb9ee51d831c67c63500da70526a3d5f0646ec58521f520ccfe5449ac"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x207e99a1d1481ba497d5a4bfe55a52bc823be410"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: mint( \"90462569716653278099089170952758924416... )", async function( ) {
		const txOriginal = {blockNumber: "6633127", timeStamp: "1541210781", hash: "0x3a5f156b1578c8b6be57660cbcc55f25cb6a5156ff808fd8e96dd91f75f2c24c", nonce: "16209", blockHash: "0x086360fbf837372620e98852a43ece2c1da3ddc13b96a4c6accb187c6b82f26d", transactionIndex: "21", from: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385", to: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe", value: "0", gas: "176392", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1801fbe50200000000000000ad17f7f39917fa4e69ed02002460d5ec72ed0bf3a5c37a10000000000018083135d741ed70242f6c3a66de03477d7a8a97af172d44eba110", contractAddress: "", cumulativeGasUsed: "5068463", gasUsed: "176392", confirmations: "1090080"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "nonce", value: "904625697166532780990891709527589244166120195022412758836741296486271384080"}, {type: "bytes32", name: "challenge_digest", value: "0x000000000018083135d741ed70242f6c3a66de03477d7a8a97af172d44eba110"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(uint256,bytes32)" ]( "904625697166532780990891709527589244166120195022412758836741296486271384080", "0x000000000018083135d741ed70242f6c3a66de03477d7a8a97af172d44eba110", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541210781 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: false, name: "reward_amount", type: "uint256"}, {indexed: false, name: "epochCount", type: "uint256"}, {indexed: false, name: "newChallengeNumber", type: "bytes32"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "from", type: "address", value: "0xbbaf778404f29dafabfb07981e3cf3fae29ce385"}, {name: "reward_amount", type: "uint256", value: "3000000000"}, {name: "epochCount", type: "uint256", value: "19760"}, {name: "newChallengeNumber", type: "bytes32", value: "0xd19ae36fe2c6231965936bcfc51daa22705824770182dba1001dde9d27ca8597"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "candidate", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "RewardMasternode", type: "event"} ;
		console.error( "eventCallOriginal[49,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RewardMasternode", events: [{name: "candidate", type: "address", value: "0x74267eedbedabf6643ede15818d20f1ef2f2edcd"}, {name: "amount", type: "uint256", value: "2000000000"}], address: "0xa38fcedd23de2191dc27f9a0240ac170be0a14fe"}] ;
		console.error( "eventResultOriginal[49,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
