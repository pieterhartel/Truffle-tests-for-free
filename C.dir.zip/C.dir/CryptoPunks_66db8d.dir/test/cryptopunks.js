const CryptoPunks = artifacts.require( "./CryptoPunks.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "CryptoPunks" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x6Ba6f2207e343923BA692e5Cae646Fb0F566DB8D", "0xC352B534e8b987e036A93539Fd6897F53488e56a", "0x000001f568875F378Bf6d170B790967FE429C81A", "0x00000217d2795F1Da57e392D2a5bC87125BAA38D", "0x000003e1E88A1110E961f135dF8cdEa4b1FFA81a", "0xFf6492F6d2a2d1194061751c6b350e4fA5ff34f2", "0x88810436096CbCa24b61C76153D19CfEdd0Da35B", "0x8884F2Af43bCbd9ab81f7A4aC35f421Df1926810", "0x88822756Ec33b3a18341966C3AB7a201856371d9", "0x8883B11C7cC85ca85279c70c69ECCc8D32CBE08A", "0x8885224cF8ee256634F628BFEf326948faf78Ba3", "0xBB69b1DBecfBafF7E4F8c9636b322b7a85c58479", "0x5b098b00621EDa6a96b7a476220661ad265F083f", "0x01486C3891761E93e5107890286ABdC1834fC6d7"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "punksOfferedForSale", outputs: [{name: "isForSale", type: "bool"}, {name: "punkIndex", type: "uint256"}, {name: "seller", type: "address"}, {name: "minValue", type: "uint256"}, {name: "onlySellTo", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "imageHash", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "nextPunkIndexToAssign", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "punkIndexToAddress", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "standard", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "numberOfPunksToReserve", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "numberOfPunksReserved", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "punksRemainingToAssign", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "pendingWithdrawals", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "PunkTransfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "punkIndex", type: "uint256"}, {indexed: false, name: "minValue", type: "uint256"}, {indexed: true, name: "toAddress", type: "address"}], name: "PunkOffered", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "punkIndex", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}, {indexed: true, name: "fromAddress", type: "address"}, {indexed: true, name: "toAddress", type: "address"}], name: "PunkBought", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "punkIndex", type: "uint256"}], name: "PunkNoLongerForSale", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Assign(address,uint256)", "Transfer(address,address,uint256)", "PunkTransfer(address,address,uint256)", "PunkOffered(uint256,uint256,address)", "PunkBought(uint256,uint256,address,address)", "PunkNoLongerForSale(uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x8a0e37b73a0d9c82e205d4d1a3ff3d0b57ce5f4d7bccf6bac03336dc101cb7ba", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x05af636b70da6819000c49f85b21fa82081c632069bb626f30932034099107d8", "0x3c7b682d5da98001a9b8cbda6c647d2c63d698a4184fd1d55e2ce7b66f5d21eb", "0x58e5d5a525e3b40bc15abaa38b5882678db1ee68befd2f60bafe3a7fd06db9e3", "0xb0e0a660b4e50f26f0b7ce75c24655fc76cc66e3334a54ff410277229fa10bd4"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3842489 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 3846510 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "CryptoPunks", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "punksOfferedForSale", outputs: [{name: "isForSale", type: "bool"}, {name: "punkIndex", type: "uint256"}, {name: "seller", type: "address"}, {name: "minValue", type: "uint256"}, {name: "onlySellTo", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "punksOfferedForSale(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "imageHash", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "imageHash()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "nextPunkIndexToAssign", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nextPunkIndexToAssign()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "punkIndexToAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "punkIndexToAddress(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "standard", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "standard()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numberOfPunksToReserve", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numberOfPunksToReserve()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numberOfPunksReserved", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numberOfPunksReserved()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "punksRemainingToAssign", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "punksRemainingToAssign()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "pendingWithdrawals", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pendingWithdrawals(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "CryptoPunks", function( accounts ) {

	it( "TEST: CryptoPunks(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "3842489", timeStamp: "1496967770", hash: "0x9fef127966d59d440c70f28c8e6f1eac3af0d91f94384e207deb3c98ff9c3088", nonce: "0", blockHash: "0x1b7c4285230a5f57417b861f1971283aca0d34958b008062499e281456055d18", transactionIndex: "11", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: 0, value: "0", gas: "1509221", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0x5fdbefb7", contractAddress: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", cumulativeGasUsed: "1864836", gasUsed: "1409220", confirmations: "3833663"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "CryptoPunks", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = CryptoPunks.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1496967770 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = CryptoPunks.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3842600", timeStamp: "1496969313", hash: "0xfc1d055116893979c349fdf1cbf7c93a514b36243f3a323090c5e9f6316db7e2", nonce: "1", blockHash: "0xd87cd6bdac02454ce55e115128d2f9327c374078bfdc841812f8a2bf6b9ddf9a", transactionIndex: "45", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "90000", gasPrice: "1000000000", isError: "1", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3434207", gasUsed: "90000", confirmations: "3833552"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3842612", timeStamp: "1496969625", hash: "0x49dbdf0355bec55f16e211a0b8cfbadc7723b535a025c6c30bda8b62fc1b0996", nonce: "2", blockHash: "0x836cf1a09a904be4ffae5100372284f2937f042e5d2776dc552b87cafca59570", transactionIndex: "30", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "1000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3777467", gasUsed: "1482964", confirmations: "3833540"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1496969625 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "0"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "1"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "2"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "3"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "4"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "5"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "6"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "7"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "8"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "9"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "10"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "11"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "12"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "13"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "14"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "15"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "16"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "17"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "18"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "19"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "20"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "21"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "22"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "23"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "24"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "25"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "26"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "27"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "28"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "29"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "30"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "31"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "32"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "33"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "34"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "35"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "36"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "37"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "38"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "39"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "40"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "41"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "42"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "43"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "44"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "45"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "46"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "47"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "48"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "49"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3842648", timeStamp: "1496970121", hash: "0xb1387d84fc7a207e25d0dccf6d37457a7addb8b57ef8e42e24d2a10a7ae72442", nonce: "3", blockHash: "0x4ab2a7ffae5e576b0f2d4f3d3d6926e26bb94ce4e6814725b89d34a8edb6be57", transactionIndex: "43", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "1000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "4080570", gasUsed: "1437964", confirmations: "3833504"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1496970121 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "50"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "51"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "52"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "53"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "54"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "55"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "56"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "57"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "58"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "59"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "60"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "61"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "62"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "63"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "64"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "65"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "66"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "67"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "68"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "69"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "70"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "71"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "72"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "73"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "74"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "75"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "76"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "77"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "78"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "79"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "80"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "81"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "82"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "83"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "84"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "85"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "86"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "87"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "88"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "89"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "90"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "91"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "92"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "93"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "94"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "95"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "96"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "97"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "98"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "99"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3842752", timeStamp: "1496971763", hash: "0xd1edb119ba4a96f4ccc0c750bf080e0ec3552ea435096786ffae2a65c62d62fd", nonce: "4", blockHash: "0xd3833047bd8c82e126fda7bb917f67c97191e30fcba82368f9e6e78e351aeb09", transactionIndex: "19", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "1000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3102400", gasUsed: "1437964", confirmations: "3833400"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1496971763 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "100"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "101"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "102"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "103"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "104"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "105"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "106"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "107"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "108"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "109"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "110"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "111"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "112"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "113"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "114"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "115"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "116"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "117"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "118"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "119"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "120"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "121"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "122"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "123"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "124"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "125"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "126"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "127"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "128"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "129"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "130"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "131"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "132"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "133"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "134"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "135"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "136"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "137"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "138"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "139"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "140"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "141"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "142"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "143"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "144"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "145"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "146"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "147"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "148"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "149"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3842758", timeStamp: "1496971836", hash: "0x55ed702c2e49e1347ba356843e425e0df2d57a1d50963e6db9874f1e94152c00", nonce: "5", blockHash: "0x580e3a96f03e7d8698208a1c618ee54df23e958c8515cf90113fd28d5ec5df81", transactionIndex: "27", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "1000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3743974", gasUsed: "1437964", confirmations: "3833394"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1496971836 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "150"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "151"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "152"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "153"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "154"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "155"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "156"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "157"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "158"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "159"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "160"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "161"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "162"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "163"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "164"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "165"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "166"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "167"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "168"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "169"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "170"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "171"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "172"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "173"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "174"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "175"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "176"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "177"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "178"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "179"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "180"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "181"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "182"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "183"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "184"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "185"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "186"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "187"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "188"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "189"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "190"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "191"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "192"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "193"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "194"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "195"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "196"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "197"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "198"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "199"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3842783", timeStamp: "1496972319", hash: "0x743b808a3d2ddf95285db7ed05753b21d4d8bbdc440142e9b4516fb5651c75e8", nonce: "6", blockHash: "0x114b1edb8bc617f6af0090f1f246ea6ac2de4848c8fc37c418e4348c14c8a46a", transactionIndex: "47", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3124806", gasUsed: "1437964", confirmations: "3833369"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1496972319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "200"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "201"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "202"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "203"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "204"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "205"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "206"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "207"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "208"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "209"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "210"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "211"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "212"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "213"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "214"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "215"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "216"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "217"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "218"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "219"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "220"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "221"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "222"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "223"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "224"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "225"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "226"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "227"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "228"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "229"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "230"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "231"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "232"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "233"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "234"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "235"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "236"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "237"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "238"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "239"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "240"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "241"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "242"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "243"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "244"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "245"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "246"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "247"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "248"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "249"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3842785", timeStamp: "1496972339", hash: "0xe996ebbe6df8c24821b64b59413ba89f424c49cd615fecf14494301fab544aa6", nonce: "7", blockHash: "0x7a79dfbfbb563acf85c4bf606ed5ecbd963f793e008f1cb5e9bed25e41a43829", transactionIndex: "17", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "2151951", gasUsed: "1437964", confirmations: "3833367"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1496972339 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "250"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "251"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "252"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "253"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "254"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "255"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "256"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "257"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "258"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "259"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "260"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "261"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "262"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "263"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "264"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "265"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "266"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "267"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "268"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "269"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "270"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "271"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "272"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "273"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "274"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "275"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "276"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "277"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "278"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "279"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "280"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "281"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "282"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "283"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "284"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "285"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "286"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "287"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "288"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "289"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "290"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "291"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "292"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "293"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "294"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "295"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "296"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "297"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "298"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "299"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3842785", timeStamp: "1496972339", hash: "0x1b1efa7017b977562f740e536176911d8cf4e09d7137ac0c33a3fadf7ae98a5a", nonce: "8", blockHash: "0x7a79dfbfbb563acf85c4bf606ed5ecbd963f793e008f1cb5e9bed25e41a43829", transactionIndex: "18", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3589915", gasUsed: "1437964", confirmations: "3833367"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1496972339 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "300"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "301"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "302"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "303"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "304"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "305"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "306"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "307"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "308"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "309"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "310"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "311"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "312"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "313"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "314"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "315"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "316"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "317"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "318"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "319"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "320"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "321"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "322"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "323"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "324"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "325"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "326"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "327"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "328"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "329"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "330"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "331"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "332"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "333"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "334"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "335"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "336"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "337"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "338"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "339"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "340"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "341"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "342"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "343"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "344"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "345"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "346"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "347"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "348"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "349"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3842845", timeStamp: "1496973370", hash: "0x921c495910684d0143ff63d9b2e4e28765c966965f3ee61aeb6ba898eda58502", nonce: "9", blockHash: "0x889fc7660e8ed5051ad06acc07cfbd0f98df639268af09272eea59909b8403c2", transactionIndex: "17", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "4041583", gasUsed: "1437964", confirmations: "3833307"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1496973370 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "350"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "351"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "352"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "353"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "354"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "355"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "356"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "357"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "358"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "359"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "360"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "361"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "362"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "363"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "364"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "365"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "366"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "367"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "368"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "369"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "370"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "371"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "372"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "373"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "374"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "375"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "376"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "377"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "378"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "379"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "380"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "381"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "382"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "383"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "384"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "385"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "386"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "387"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "388"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "389"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "390"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "391"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "392"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "393"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "394"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "395"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "396"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "397"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "398"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "399"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3842873", timeStamp: "1496973851", hash: "0x028d742f5e3ffd2ce42dbb78af1a034da283b9b737fb7a2dabc89ac2d3904fdc", nonce: "10", blockHash: "0x0d010f1e0664cfeeed8fdb61001c2baa53aa689d89ec527a0a649774618c5712", transactionIndex: "23", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "1973840", gasUsed: "1437964", confirmations: "3833279"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1496973851 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "400"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "401"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "402"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "403"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "404"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "405"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "406"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "407"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "408"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "409"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "410"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "411"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "412"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "413"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "414"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "415"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "416"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "417"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "418"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "419"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "420"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "421"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "422"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "423"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "424"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "425"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "426"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "427"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "428"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "429"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "430"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "431"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "432"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "433"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "434"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "435"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "436"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "437"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "438"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "439"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "440"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "441"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "442"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "443"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "444"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "445"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "446"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "447"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "448"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "449"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3842873", timeStamp: "1496973851", hash: "0x1415e8a7fc34b68890a57463153156656290f56c206bba0b5a50baafcf75dae0", nonce: "11", blockHash: "0x0d010f1e0664cfeeed8fdb61001c2baa53aa689d89ec527a0a649774618c5712", transactionIndex: "24", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3411804", gasUsed: "1437964", confirmations: "3833279"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1496973851 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "450"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "451"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "452"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "453"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "454"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "455"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "456"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "457"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "458"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "459"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "460"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "461"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "462"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "463"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "464"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "465"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "466"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "467"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "468"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "469"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "470"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "471"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "472"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "473"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "474"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "475"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "476"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "477"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "478"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "479"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "480"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "481"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "482"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "483"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "484"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "485"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "486"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "487"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "488"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "489"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "490"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "491"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "492"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "493"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "494"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "495"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "496"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "497"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "498"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "499"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3842925", timeStamp: "1496974773", hash: "0x63b4a99cfa19af55bb265ff2306ae5a2853d64d761747783adae32b0b18c92da", nonce: "12", blockHash: "0x0cb3e0cf832359b999aaef1310b58c5572912c70c106665a50fac1f0262ebd4a", transactionIndex: "15", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3950264", gasUsed: "1437964", confirmations: "3833227"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1496974773 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "500"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "501"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "502"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "503"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "504"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "505"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "506"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "507"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "508"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "509"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "510"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "511"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "512"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "513"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "514"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "515"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "516"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "517"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "518"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "519"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "520"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "521"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "522"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "523"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "524"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "525"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "526"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "527"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "528"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "529"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "530"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "531"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "532"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "533"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "534"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "535"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "536"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "537"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "538"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "539"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "540"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "541"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "542"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "543"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "544"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "545"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "546"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "547"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "548"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "549"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3843009", timeStamp: "1496976213", hash: "0x84e36cbc855083728f4e83b7c46f510b84bb0d490eda1e31a9df65a6a36e667d", nonce: "13", blockHash: "0x4718508d997be99cba79ecd767a2d9beaf69f76dab17f0986c17172376f6e5e8", transactionIndex: "72", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "4136800", gasUsed: "1437964", confirmations: "3833143"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1496976213 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "550"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "551"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "552"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "553"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "554"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "555"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "556"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "557"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "558"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "559"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "560"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "561"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "562"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "563"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "564"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "565"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "566"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "567"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "568"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "569"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "570"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "571"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "572"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "573"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "574"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "575"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "576"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "577"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "578"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "579"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "580"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "581"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "582"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "583"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "584"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "585"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "586"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "587"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "588"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "589"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "590"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "591"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "592"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "593"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "594"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "595"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "596"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "597"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "598"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "599"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3843012", timeStamp: "1496976231", hash: "0x6164d167ca9c2bec7ba2a84029b0a17ba9b1ad6be724bc77a370f44ba7a1fd88", nonce: "14", blockHash: "0x452a0d058bbae568da5017108a777bd85f0db1cd205c0c32612fd784f853e29b", transactionIndex: "12", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3523318", gasUsed: "1437964", confirmations: "3833140"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1496976231 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "600"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "601"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "602"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "603"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "604"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "605"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "606"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "607"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "608"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "609"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "610"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "611"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "612"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "613"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "614"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "615"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "616"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "617"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "618"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "619"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "620"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "621"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "622"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "623"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "624"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "625"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "626"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "627"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "628"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "629"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "630"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "631"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "632"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "633"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "634"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "635"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "636"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "637"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "638"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "639"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "640"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "641"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "642"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "643"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "644"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "645"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "646"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "647"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "648"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "649"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3843025", timeStamp: "1496976409", hash: "0x5db4d803556037af87b7d32d132ec233004e3cc60ea31f3c9bae89cd14f90deb", nonce: "15", blockHash: "0x5c8dae06d63d4186dec07c9b94716d311273954c0606f2686785ebf44ce37c87", transactionIndex: "6", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "1889492", gasUsed: "1437964", confirmations: "3833127"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1496976409 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "650"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "651"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "652"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "653"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "654"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "655"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "656"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "657"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "658"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "659"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "660"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "661"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "662"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "663"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "664"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "665"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "666"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "667"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "668"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "669"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "670"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "671"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "672"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "673"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "674"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "675"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "676"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "677"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "678"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "679"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "680"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "681"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "682"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "683"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "684"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "685"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "686"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "687"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "688"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "689"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "690"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "691"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "692"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "693"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "694"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "695"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "696"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "697"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "698"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "699"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3843025", timeStamp: "1496976409", hash: "0x4981aa23eaf9f3452a23602a6746c1d5548da01394ba7906dba562274ef8de7d", nonce: "16", blockHash: "0x5c8dae06d63d4186dec07c9b94716d311273954c0606f2686785ebf44ce37c87", transactionIndex: "7", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3327456", gasUsed: "1437964", confirmations: "3833127"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1496976409 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "700"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "701"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "702"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "703"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "704"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "705"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "706"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "707"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "708"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "709"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "710"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "711"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "712"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "713"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "714"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "715"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "716"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "717"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "718"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "719"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "720"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "721"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "722"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "723"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "724"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "725"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "726"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "727"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "728"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "729"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "730"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "731"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "732"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "733"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "734"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "735"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "736"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "737"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "738"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "739"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "740"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "741"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "742"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "743"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "744"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "745"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "746"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "747"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "748"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "749"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3843058", timeStamp: "1496976891", hash: "0x9a0d0c25e07d36f7fb75c3c536a906fe4f1abe339a5685f846686f75d5073915", nonce: "17", blockHash: "0x422481f5f390b17c71d9be47415792d2d5b9c420363970ad01b57bee6812992c", transactionIndex: "12", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3814083", gasUsed: "1437964", confirmations: "3833094"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1496976891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "750"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "751"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "752"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "753"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "754"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "755"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "756"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "757"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "758"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "759"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "760"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "761"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "762"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "763"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "764"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "765"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "766"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "767"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "768"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "769"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "770"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "771"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "772"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "773"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "774"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "775"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "776"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "777"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "778"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "779"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "780"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "781"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "782"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "783"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "784"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "785"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "786"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "787"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "788"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "789"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "790"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "791"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "792"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "793"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "794"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "795"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "796"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "797"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "798"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "799"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3843188", timeStamp: "1496979401", hash: "0x89feb13adfe287bc9447a4b13a7771325c53c73c01a635fa129d4d6d7487b5f5", nonce: "18", blockHash: "0xaa62c630343206e9bbb02c76c9db478475ed939a4559531d72a31eb61173aaf9", transactionIndex: "40", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3854081", gasUsed: "1437964", confirmations: "3832964"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1496979401 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "800"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "801"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "802"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "803"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "804"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "805"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "806"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "807"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "808"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "809"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "810"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "811"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "812"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "813"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "814"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "815"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "816"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "817"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "818"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "819"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "820"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "821"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "822"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "823"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "824"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "825"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "826"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "827"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "828"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "829"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "830"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "831"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "832"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "833"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "834"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "835"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "836"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "837"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "838"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "839"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "840"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "841"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "842"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "843"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "844"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "845"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "846"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "847"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "848"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "849"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3843256", timeStamp: "1496980446", hash: "0x8c38348601590b4ba2953a7e8ed4540c77954cf56e5b613607379d3a24b18dba", nonce: "19", blockHash: "0x7f5010a9ba25ceb6a18d4f67476f8022e77a8fede9bfad745f600632b37ef7ee", transactionIndex: "41", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "2939501", gasUsed: "1437964", confirmations: "3832896"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1496980446 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "850"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "851"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "852"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "853"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "854"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "855"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "856"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "857"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "858"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "859"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "860"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "861"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "862"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "863"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "864"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "865"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "866"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "867"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "868"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "869"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "870"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "871"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "872"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "873"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "874"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "875"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "876"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "877"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "878"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "879"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "880"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "881"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "882"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "883"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "884"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "885"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "886"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "887"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "888"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "889"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "890"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "891"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "892"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "893"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "894"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "895"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "896"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "897"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "898"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "899"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3843262", timeStamp: "1496980641", hash: "0x898fd1e7fa9c7a76f14becd0595e7b1be761162ca4f151c87d1554c496b98add", nonce: "20", blockHash: "0xeba190198a0ca725180bf4f729482f0ca9355846c9d91a1f0195fe2b432819a6", transactionIndex: "18", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "3313456", gasUsed: "1437964", confirmations: "3832890"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1496980641 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "900"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "901"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "902"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "903"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "904"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "905"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "906"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "907"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "908"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "909"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "910"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "911"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "912"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "913"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "914"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "915"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "916"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "917"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "918"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "919"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "920"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "921"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "922"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "923"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "924"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "925"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "926"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "927"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "928"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "929"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "930"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "931"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "932"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "933"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "934"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "935"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "936"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "937"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "938"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "939"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "940"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "941"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "942"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "943"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "944"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "945"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "946"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "947"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "948"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "949"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: reservePunksForOwner( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "3843272", timeStamp: "1496980765", hash: "0x386b1efb35c87e7ae66e1c408d8750faa1340561b4b26524417f1d72f8abbddf", nonce: "21", blockHash: "0x46a44d9e2ecb051d3fcf8d2f1e43f47221889394f316a974bf8de602c6596cae", transactionIndex: "24", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "2000000", gasPrice: "2000000000", isError: "0", txreceipt_status: "", input: "0x08573a0b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "2387431", gasUsed: "1437964", confirmations: "3832880"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "maxForThisRun", value: "50"}], name: "reservePunksForOwner", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reservePunksForOwner(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1496980765 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "950"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "951"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "952"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "953"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "954"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "955"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "956"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "957"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "958"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "959"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "960"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "961"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "962"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "963"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "964"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "965"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "966"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "967"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "968"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "969"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "970"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "971"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "972"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "973"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "974"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "975"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "976"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "977"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "978"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "979"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "980"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "981"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "982"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "983"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "984"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "985"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "986"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "987"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "988"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "989"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "990"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "991"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "992"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "993"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "994"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "995"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "996"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "997"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "998"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}, {name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "999"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"5056\" )", async function( ) {
		const txOriginal = {blockNumber: "3843337", timeStamp: "1496981719", hash: "0x84335404c17162119b47fddf56f08e9b1a10a593aa35ad53664a733f935898eb", nonce: "22", blockHash: "0xb43592e4a77110464f2201945e3ab2eccbb1fb76f7334c74586ff5fa82ccd4c2", transactionIndex: "11", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "155047", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b00000000000000000000000000000000000000000000000000000000000013c0", contractAddress: "", cumulativeGasUsed: "976581", gasUsed: "55046", confirmations: "3832815"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "5056"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "5056", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1496981719 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "5056"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"4549\" )", async function( ) {
		const txOriginal = {blockNumber: "3843338", timeStamp: "1496981739", hash: "0xfe2b408feea80dfb97f330fcdb2ddb279bcb537f089321dcfbc2da016b8a4931", nonce: "23", blockHash: "0xdb51b18494e352bd3c60080a5a27b311cd6c8191e9b00e18b627bc32404fdbe1", transactionIndex: "21", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "155047", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b00000000000000000000000000000000000000000000000000000000000011c5", contractAddress: "", cumulativeGasUsed: "1887949", gasUsed: "55046", confirmations: "3832814"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "4549"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "4549", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1496981739 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "4549"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"5835\" )", async function( ) {
		const txOriginal = {blockNumber: "3843346", timeStamp: "1496981885", hash: "0xb32ef5c017974cc70d7ed9ff4f9fa79f84eb9186bbe68aa925d751b5039e7d2b", nonce: "24", blockHash: "0xd361ee92ca7796a03586345ba8bf474dc675652aa036f2746c774e5aca638609", transactionIndex: "61", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "155047", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b00000000000000000000000000000000000000000000000000000000000016cb", contractAddress: "", cumulativeGasUsed: "2144957", gasUsed: "55046", confirmations: "3832806"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "5835"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "5835", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1496981885 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "5835"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"4949\" )", async function( ) {
		const txOriginal = {blockNumber: "3843346", timeStamp: "1496981885", hash: "0x481f9a16dd98598165e60c9cfc55dbc7ad9ef75bec465d38e60f1b0e3f2352e6", nonce: "25", blockHash: "0xd361ee92ca7796a03586345ba8bf474dc675652aa036f2746c774e5aca638609", transactionIndex: "75", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "155047", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000001355", contractAddress: "", cumulativeGasUsed: "3169489", gasUsed: "55046", confirmations: "3832806"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "4949"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "4949", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1496981885 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "4949"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"4530\" )", async function( ) {
		const txOriginal = {blockNumber: "3843365", timeStamp: "1496982163", hash: "0xb01dbdd986088aca71e0a9afb8ec94f0a48c6db08435dbe95e287b18b37c6b4c", nonce: "26", blockHash: "0x12ca4417de85f24504d021e4822668b36cc573c03dea8226b67f0369e1141cee", transactionIndex: "16", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "155047", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b00000000000000000000000000000000000000000000000000000000000011b2", contractAddress: "", cumulativeGasUsed: "603844", gasUsed: "55046", confirmations: "3832787"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "4530"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "4530", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1496982163 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "4530"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"5539\" )", async function( ) {
		const txOriginal = {blockNumber: "3843367", timeStamp: "1496982215", hash: "0x1f02ece89ac7e087da2e6681dcbda342ba84c8cdc5a4bf821f8dc759edb7fe71", nonce: "27", blockHash: "0x0a082309b02d4a43cf87cea823069b9a556b53393bd81389c05f4c1b3ca5bb8a", transactionIndex: "38", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "155047", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b00000000000000000000000000000000000000000000000000000000000015a3", contractAddress: "", cumulativeGasUsed: "2263352", gasUsed: "55046", confirmations: "3832785"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "5539"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "5539", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1496982215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "5539"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"5160\" )", async function( ) {
		const txOriginal = {blockNumber: "3843373", timeStamp: "1496982286", hash: "0x630e46bfec912f886ef3f52ce14f60fb33ca1759b5398de51dc7183c089f9aba", nonce: "28", blockHash: "0x91d8346e31435d4e2e26713e7c625e1070d12a25601086f65fadcb7007be2306", transactionIndex: "17", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "155047", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000001428", contractAddress: "", cumulativeGasUsed: "1044268", gasUsed: "55046", confirmations: "3832779"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "5160"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "5160", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1496982286 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "5160"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"6053\" )", async function( ) {
		const txOriginal = {blockNumber: "3843398", timeStamp: "1496982698", hash: "0x21e0b596e4e1976fee6f2ed5884c31f3dc28bf2e01474f7415582bff47ca7a5b", nonce: "29", blockHash: "0xdb991b97a5ed0ce6bb27189c90583b6775c1e8e17f080fb7a2b6cb91975ed230", transactionIndex: "44", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "155047", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b00000000000000000000000000000000000000000000000000000000000017a5", contractAddress: "", cumulativeGasUsed: "1598488", gasUsed: "55046", confirmations: "3832754"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "6053"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "6053", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1496982698 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xc352b534e8b987e036a93539fd6897f53488e56a"}, {name: "punkIndex", type: "uint256", value: "6053"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: offerPunkForSale( \"5056\", \"100000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "3843406", timeStamp: "1496982851", hash: "0x98e9d0f2ef4bcd752c4bf6d6d10d55d11e8b7236040af7ae1a73417704551aa1", nonce: "30", blockHash: "0xeaa682e7997296cac564fe4dbb5e75289b8547ca95f9dd9ef0a8773aca0cd374", transactionIndex: "25", from: "0xc352b534e8b987e036a93539fd6897f53488e56a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "210897", gasPrice: "8000000000", isError: "0", txreceipt_status: "", input: "0xc44193c300000000000000000000000000000000000000000000000000000000000013c0000000000000000000000000000000000000000000000000016345785d8a0000", contractAddress: "", cumulativeGasUsed: "920845", gasUsed: "110896", confirmations: "3832746"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "5056"}, {type: "uint256", name: "minSalePriceInWei", value: "100000000000000000"}], name: "offerPunkForSale", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "offerPunkForSale(uint256,uint256)" ]( "5056", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1496982851 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "punkIndex", type: "uint256"}, {indexed: false, name: "minValue", type: "uint256"}, {indexed: true, name: "toAddress", type: "address"}], name: "PunkOffered", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PunkOffered", events: [{name: "punkIndex", type: "uint256", value: "5056"}, {name: "minValue", type: "uint256", value: "100000000000000000"}, {name: "toAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "9852714355330745835" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"3983\" )", async function( ) {
		const txOriginal = {blockNumber: "3845526", timeStamp: "1497018388", hash: "0x513bc420c2ca2149c4472677cd5e28cff044dfda478312d24d1b22fb9d95b2ec", nonce: "134", blockHash: "0x0e916925873f433fd22af7cf61188d8db2cf0d3562743b8ab945ef9cb5095acd", transactionIndex: "98", from: "0x000001f568875f378bf6d170b790967fe429c81a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "170047", gasPrice: "7000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000000f8f", contractAddress: "", cumulativeGasUsed: "2909724", gasUsed: "70046", confirmations: "3830626"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "3983"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "3983", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1497018388 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x000001f568875f378bf6d170b790967fe429c81a"}, {name: "punkIndex", type: "uint256", value: "3983"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "18137651754529620090" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"4947\" )", async function( ) {
		const txOriginal = {blockNumber: "3845545", timeStamp: "1497018711", hash: "0x16f547b92b57eadca36afd241cdf163d1766f93258e42475ff3545635d454445", nonce: "32", blockHash: "0xc2f541f3c6c1a03efb28b59976d335a332c3059e795660107e965732888608f0", transactionIndex: "87", from: "0x00000217d2795f1da57e392d2a5bc87125baa38d", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "170047", gasPrice: "7000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000001353", contractAddress: "", cumulativeGasUsed: "4464227", gasUsed: "70046", confirmations: "3830607"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "4947"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "4947", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1497018711 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x00000217d2795f1da57e392d2a5bc87125baa38d"}, {name: "punkIndex", type: "uint256", value: "4947"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "2802348419136970084" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"4850\" )", async function( ) {
		const txOriginal = {blockNumber: "3845545", timeStamp: "1497018711", hash: "0xaafd5dced6ddc63bb8d1f00c9a35a9c0dce98179a7f5a1565cbad9f634041a34", nonce: "1", blockHash: "0xc2f541f3c6c1a03efb28b59976d335a332c3059e795660107e965732888608f0", transactionIndex: "88", from: "0x000003e1e88a1110e961f135df8cdea4b1ffa81a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "170047", gasPrice: "7000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b00000000000000000000000000000000000000000000000000000000000012f2", contractAddress: "", cumulativeGasUsed: "4534273", gasUsed: "70046", confirmations: "3830607"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "4850"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "4850", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1497018711 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x000003e1e88a1110e961f135df8cdea4b1ffa81a"}, {name: "punkIndex", type: "uint256", value: "4850"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "48798558000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buyPunk( \"1006\" )", async function( ) {
		const txOriginal = {blockNumber: "3845587", timeStamp: "1497019455", hash: "0xbd0bd87da299674df2c3e9f207887356a0d2ed42cf8910c7721c29db6f07ec91", nonce: "2", blockHash: "0x7710bc0d6b0bb46d49f6a49005d1418e67b30e282fcc865b2394c2ff5f14512d", transactionIndex: "138", from: "0xff6492f6d2a2d1194061751c6b350e4fa5ff34f2", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "100000000000000", gas: "21528", gasPrice: "14000000000", isError: "1", txreceipt_status: "", input: "0x8264fe9800000000000000000000000000000000000000000000000000000000000003ee", contractAddress: "", cumulativeGasUsed: "4696772", gasUsed: "21528", confirmations: "3830565"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "1006"}], name: "buyPunk", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1505075000000004" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buyPunk( \"1001\" )", async function( ) {
		const txOriginal = {blockNumber: "3845593", timeStamp: "1497019528", hash: "0x9084264391d7adfa3a04fd5c494d069ae05c769223cfdbd30fe9794122069de5", nonce: "3", blockHash: "0x83577f37a861998cfe093118ba9a208522dc5e9f47616aa844d6310aff1db78f", transactionIndex: "38", from: "0xff6492f6d2a2d1194061751c6b350e4fa5ff34f2", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "100000000000000", gas: "21528", gasPrice: "14000000000", isError: "1", txreceipt_status: "", input: "0x8264fe9800000000000000000000000000000000000000000000000000000000000003e9", contractAddress: "", cumulativeGasUsed: "2501179", gasUsed: "21528", confirmations: "3830559"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "1001"}], name: "buyPunk", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1505075000000004" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buyPunk( \"1001\" )", async function( ) {
		const txOriginal = {blockNumber: "3845597", timeStamp: "1497019591", hash: "0x011ef46a5741ca1af9f49dd3d67a3917e2667c695ffdbce5a1857282bbe40868", nonce: "4", blockHash: "0x681da98f7ac78874a2d93b44b03a0b293896401cb3db1f6b29dcdef29e3acdcd", transactionIndex: "45", from: "0xff6492f6d2a2d1194061751c6b350e4fa5ff34f2", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "100000000000000", gas: "86112", gasPrice: "14000000000", isError: "1", txreceipt_status: "", input: "0x8264fe9800000000000000000000000000000000000000000000000000000000000003e9", contractAddress: "", cumulativeGasUsed: "2047471", gasUsed: "86112", confirmations: "3830555"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "1001"}], name: "buyPunk", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1505075000000004" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"1001\" )", async function( ) {
		const txOriginal = {blockNumber: "3845604", timeStamp: "1497019801", hash: "0x320d9f74644e1af104e8677957ffc3a17dbf9cbb8e67bf54c7efa50c47adf3cb", nonce: "5", blockHash: "0xd1fff5834146eedcd1b9d8f07ef60c72b331fc955f06fdf8150fabc9f35798bd", transactionIndex: "120", from: "0xff6492f6d2a2d1194061751c6b350e4fa5ff34f2", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "170047", gasPrice: "14000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b00000000000000000000000000000000000000000000000000000000000003e9", contractAddress: "", cumulativeGasUsed: "4546613", gasUsed: "70046", confirmations: "3830548"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "1001"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "1001", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1497019801 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xff6492f6d2a2d1194061751c6b350e4fa5ff34f2"}, {name: "punkIndex", type: "uint256", value: "1001"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1505075000000004" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"4353\" )", async function( ) {
		const txOriginal = {blockNumber: "3845630", timeStamp: "1497020221", hash: "0x9098535402b28e026f2c3cc5654ee20f77de5f775ac1d79d0340b75ed16178a6", nonce: "2", blockHash: "0x05671ec73850be769741db31d6e224b55c5ef737cd2339391b824f660de30d04", transactionIndex: "24", from: "0x88810436096cbca24b61c76153d19cfedd0da35b", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "170047", gasPrice: "7000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000001101", contractAddress: "", cumulativeGasUsed: "815578", gasUsed: "70046", confirmations: "3830522"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "4353"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "4353", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1497020221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x88810436096cbca24b61c76153d19cfedd0da35b"}, {name: "punkIndex", type: "uint256", value: "4353"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "27800191546000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"3443\" )", async function( ) {
		const txOriginal = {blockNumber: "3845641", timeStamp: "1497020465", hash: "0x1077a00643b22143d8fbce5718af1df88183e56f17b769650b0984baa4d7f5c8", nonce: "1", blockHash: "0xae01ba3ee84beba9719af20c0350f829719628cb5f6e5ac7674fbf70d1d03bd1", transactionIndex: "81", from: "0x8884f2af43bcbd9ab81f7a4ac35f421df1926810", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "170047", gasPrice: "7000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000000d73", contractAddress: "", cumulativeGasUsed: "4352025", gasUsed: "70046", confirmations: "3830511"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "3443"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "3443", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1497020465 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x8884f2af43bcbd9ab81f7a4ac35f421df1926810"}, {name: "punkIndex", type: "uint256", value: "3443"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "27801396218000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"3271\" )", async function( ) {
		const txOriginal = {blockNumber: "3845641", timeStamp: "1497020465", hash: "0xc485628997d43b4e7708b5179d2eec1d7791e93c2c4bd2fd835cbbe2df5919c9", nonce: "2", blockHash: "0xae01ba3ee84beba9719af20c0350f829719628cb5f6e5ac7674fbf70d1d03bd1", transactionIndex: "82", from: "0x88822756ec33b3a18341966c3ab7a201856371d9", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "170047", gasPrice: "7000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000000cc7", contractAddress: "", cumulativeGasUsed: "4422071", gasUsed: "70046", confirmations: "3830511"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "3271"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "3271", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1497020465 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x88822756ec33b3a18341966c3ab7a201856371d9"}, {name: "punkIndex", type: "uint256", value: "3271"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "27801624522000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"4060\" )", async function( ) {
		const txOriginal = {blockNumber: "3845641", timeStamp: "1497020465", hash: "0xec77667be583dd1b80471342c8e283200cc543da0956145a97bab93e7bc84b06", nonce: "1", blockHash: "0xae01ba3ee84beba9719af20c0350f829719628cb5f6e5ac7674fbf70d1d03bd1", transactionIndex: "84", from: "0x8883b11c7cc85ca85279c70c69eccc8d32cbe08a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "170047", gasPrice: "7000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000000fdc", contractAddress: "", cumulativeGasUsed: "4513117", gasUsed: "70046", confirmations: "3830511"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "4060"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "4060", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1497020465 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x8883b11c7cc85ca85279c70c69eccc8d32cbe08a"}, {name: "punkIndex", type: "uint256", value: "4060"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "27802399542000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"4062\" )", async function( ) {
		const txOriginal = {blockNumber: "3845650", timeStamp: "1497020678", hash: "0xfe090f204e25c282bf8ad198064c3a00aa2437c4acc050e1d8f4118f068b3154", nonce: "1", blockHash: "0xce1c0c9068605a6ae965826a57d8f867ca0ae6b77c040fb71ffadbd511b2d6b0", transactionIndex: "66", from: "0x8885224cf8ee256634f628bfef326948faf78ba3", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "170047", gasPrice: "7000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000000fde", contractAddress: "", cumulativeGasUsed: "4495010", gasUsed: "70046", confirmations: "3830502"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "4062"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "4062", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1497020678 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x8885224cf8ee256634f628bfef326948faf78ba3"}, {name: "punkIndex", type: "uint256", value: "4062"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "27800911725500000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"5555\" )", async function( ) {
		const txOriginal = {blockNumber: "3845663", timeStamp: "1497020928", hash: "0x1c037974a95612253c757f388b53833c20ed5a27fb301ce6e39d135109eba7eb", nonce: "435", blockHash: "0x9b0d998fda577a37a0dc05d9c3319e66ad4c11cd3d7e0a0bf79cc3a24e2d6b99", transactionIndex: "19", from: "0xbb69b1dbecfbaff7e4f8c9636b322b7a85c58479", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "170047", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b00000000000000000000000000000000000000000000000000000000000015b3", contractAddress: "", cumulativeGasUsed: "578579", gasUsed: "70046", confirmations: "3830489"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "5555"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "5555", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1497020928 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0xbb69b1dbecfbaff7e4f8c9636b322b7a85c58479"}, {name: "punkIndex", type: "uint256", value: "5555"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "128383971415051865" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"4472\" )", async function( ) {
		const txOriginal = {blockNumber: "3845796", timeStamp: "1497023318", hash: "0xcb723428c2e2258cf76a5ceb82cdf6bd6a616b44690e36becc3ca66503b1fd75", nonce: "135", blockHash: "0x5db59a179cc5fac4bd5ee066c8ed1884bbd87fc3b5f660a6543c40a28c1f7992", transactionIndex: "59", from: "0x000001f568875f378bf6d170b790967fe429c81a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "155047", gasPrice: "7000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000001178", contractAddress: "", cumulativeGasUsed: "3250839", gasUsed: "55046", confirmations: "3830356"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "4472"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "4472", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1497023318 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x000001f568875f378bf6d170b790967fe429c81a"}, {name: "punkIndex", type: "uint256", value: "4472"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "18137651754529620090" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"4199\" )", async function( ) {
		const txOriginal = {blockNumber: "3845799", timeStamp: "1497023358", hash: "0x6ce3dae4a6e1250fde2c696f354cb351949871bba7915922f461387fbb0cf6f5", nonce: "136", blockHash: "0xbcacd614439e8c26fc748f5e1cf128a83324bb789cc7836042ca4278a71b0370", transactionIndex: "18", from: "0x000001f568875f378bf6d170b790967fe429c81a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "155047", gasPrice: "7000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000001067", contractAddress: "", cumulativeGasUsed: "1371912", gasUsed: "55046", confirmations: "3830353"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "4199"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "4199", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1497023358 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x000001f568875f378bf6d170b790967fe429c81a"}, {name: "punkIndex", type: "uint256", value: "4199"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "18137651754529620090" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"4076\" )", async function( ) {
		const txOriginal = {blockNumber: "3845812", timeStamp: "1497023648", hash: "0x5a8fef1a64315d16c7457b7ededa419d6d6b83ea2df7a6e068bec8f2a0771d6c", nonce: "137", blockHash: "0x95ee18c67a3eb9c41c9eae5865e2bf2661d719fe28b4573013bd898cf8db0d51", transactionIndex: "90", from: "0x000001f568875f378bf6d170b790967fe429c81a", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "155047", gasPrice: "7000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000000fec", contractAddress: "", cumulativeGasUsed: "3769646", gasUsed: "55046", confirmations: "3830340"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "4076"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "4076", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1497023648 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x000001f568875f378bf6d170b790967fe429c81a"}, {name: "punkIndex", type: "uint256", value: "4076"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "18137651754529620090" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"9265\" )", async function( ) {
		const txOriginal = {blockNumber: "3846085", timeStamp: "1497027941", hash: "0x1d27a4851888b6d3ad3908ef4e7835c621c351924bdb4147644dd83b3e47fb4a", nonce: "0", blockHash: "0x0e0d4adb8355720723875920afc0da7177e1aa33de4496162a3ab13863fd988b", transactionIndex: "4", from: "0x5b098b00621eda6a96b7a476220661ad265f083f", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "170047", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000002431", contractAddress: "", cumulativeGasUsed: "217532", gasUsed: "70046", confirmations: "3830067"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "9265"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "9265", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1497027941 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x5b098b00621eda6a96b7a476220661ad265f083f"}, {name: "punkIndex", type: "uint256", value: "9265"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "822634686907224330" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"2924\" )", async function( ) {
		const txOriginal = {blockNumber: "3846476", timeStamp: "1497034083", hash: "0x534f6fec07806f744c2c3a3dcb76dfed73b7a2563836bbf78d273d4b7200013c", nonce: "215", blockHash: "0xdbf78e4c80ccc100b2b67730da573308a03a1d980d0bf040bcd6f035c135dc53", transactionIndex: "7", from: "0x01486c3891761e93e5107890286abdc1834fc6d7", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "170047", gasPrice: "22000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b0000000000000000000000000000000000000000000000000000000000000b6c", contractAddress: "", cumulativeGasUsed: "448366", gasUsed: "70046", confirmations: "3829676"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "2924"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "2924", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1497034083 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x01486c3891761e93e5107890286abdc1834fc6d7"}, {name: "punkIndex", type: "uint256", value: "2924"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "120518965374363564588" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: getPunk( \"1802\" )", async function( ) {
		const txOriginal = {blockNumber: "3846510", timeStamp: "1497034419", hash: "0xa66d2e5fbdeadf41fdcca6af43f7c2dd889b69eae8dff32fa79385dc4089352f", nonce: "216", blockHash: "0xc22ba3d18b0200d7ad8f6d63fb0986f3ac667eafd5df0f7fd33d30cfe48ec04c", transactionIndex: "7", from: "0x01486c3891761e93e5107890286abdc1834fc6d7", to: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d", value: "0", gas: "155047", gasPrice: "22000000000", isError: "0", txreceipt_status: "", input: "0xc81d1d5b000000000000000000000000000000000000000000000000000000000000070a", contractAddress: "", cumulativeGasUsed: "261046", gasUsed: "55046", confirmations: "3829642"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "punkIndex", value: "1802"}], name: "getPunk", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPunk(uint256)" ]( "1802", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1497034419 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "punkIndex", type: "uint256"}], name: "Assign", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Assign", events: [{name: "to", type: "address", value: "0x01486c3891761e93e5107890286abdc1834fc6d7"}, {name: "punkIndex", type: "uint256", value: "1802"}], address: "0x6ba6f2207e343923ba692e5cae646fb0f566db8d"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "120518965374363564588" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1000000000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
