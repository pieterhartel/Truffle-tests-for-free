const FoMo3DLong = artifacts.require( "./FoMo3DLong.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "FoMo3DLong" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x7c90000d161EA9605bC5a84d3683A0971475315f", "0x82cFeBf0F80B9617b8D13368eFC9B76C48F096d4", "0x62199eaFD8f0DA50bE2176d49D3DB3Aff2A9B771", "0x6ab7A52127ab31d48BBF1B5aE7E97A5052814511", "0xfA9049C632fA18880cDE19257116801E91A05Cbe", "0x03A029c841fA2f22f02B791a824D70b13f135c9f", "0xf22eabc3F1275b43194A2883d88c8c83139D233A", "0x13897C6Cd2a86c89B842f642508d65642B6718aE", "0xe534f3F81E34677eeDDb8c2a3139CA0181CAcF87", "0x4b04ffA80bBDf34b4c40437a2dc83C89C6025fd8", "0x27c086d6d68C76D5B6C47492247e9ea600959368"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "getBuyPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalVolume_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "priceCntThreshould_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "pIDxAddr_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "result_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}], name: "plyrNames_", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "coscNum_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "pIDxName_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "cosdNum_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ttlSply", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_keyType", type: "string"}], name: "isCosd", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "rID_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_eth", type: "uint256"}], name: "howManyKeysCanBuy", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "pIDCom_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalVltCosd_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "price_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_keys", type: "uint256"}], name: "iWantXKeys", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "plyr_", outputs: [{name: "addr", type: "address"}, {name: "name", type: "bytes32"}, {name: "laff", type: "uint256"}, {name: "eth", type: "uint256"}, {name: "cosd", type: "uint256"}, {name: "cosc", type: "uint256"}, {name: "hldVltCosd", type: "uint256"}, {name: "affCosd", type: "uint256"}, {name: "affCosc", type: "uint256"}, {name: "totalHldVltCosd", type: "uint256"}, {name: "totalAffCos", type: "uint256"}, {name: "totalWinCos", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "plyNum_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_addr", type: "address"}], name: "getPlayerInfoByAddress", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "pCosd", type: "uint256"}, {indexed: false, name: "pCosc", type: "uint256"}, {indexed: false, name: "comCosd", type: "uint256"}, {indexed: false, name: "comCosc", type: "uint256"}, {indexed: false, name: "affVltCosd", type: "uint256"}, {indexed: false, name: "affVltCosc", type: "uint256"}, {indexed: false, name: "keyNums", type: "uint256"}], name: "onBuyAndDistribute", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "pCosd", type: "uint256"}, {indexed: false, name: "pCosc", type: "uint256"}, {indexed: false, name: "keyNums", type: "uint256"}], name: "onSellAndDistribute", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "plyr_cosd", type: "uint256"}, {indexed: false, name: "plyr_hldVltCosd", type: "uint256"}], name: "onWithdrawHoldVault", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "plyr_cosd", type: "uint256"}, {indexed: false, name: "plyr_cosc", type: "uint256"}, {indexed: false, name: "plyr_affVltCosd", type: "uint256"}, {indexed: false, name: "plyr_affVltCosc", type: "uint256"}], name: "onWithdrawAffVault", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "plyr_cosd", type: "uint256"}, {indexed: false, name: "plyr_cosc", type: "uint256"}, {indexed: false, name: "plyr_affVltCosd", type: "uint256"}], name: "onWithdrawWonCosFromGame", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["OwnershipRenounced(address)", "OwnershipTransferred(address,address)", "onNewName(uint256,address,bytes32,bool,uint256,address,bytes32,uint256,uint256)", "onBuyAndDistribute(address,bytes32,uint256,uint256,uint256,uint256,uint256,uint256,uint256)", "onRecHldVltCosd(address,bytes32,uint256)", "onSellAndDistribute(address,bytes32,uint256,uint256,uint256)", "onWithdrawHoldVault(uint256,address,bytes32,uint256,uint256)", "onWithdrawAffVault(uint256,address,bytes32,uint256,uint256,uint256,uint256)", "onWithdrawWonCosFromGame(uint256,address,bytes32,uint256,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0", "0xdd6176433ff5026bbce96b068584b7bbe3514227e72df9c630b749ae87e64442", "0x663f31661059574e52bf4e9cb6f087cbf6103b43817ee102529c51e0c61ba38b", "0x428c2fa17489ac1a57a982abba29a8bb7317c4881293ad0ff047c309bc85b25e", "0x8f98d20acd2ef400b3f96303d2cba65f91686d7a8e8dd5a2710f480dbca7b0f2", "0x411924ad38b9442e7a9fb931d5e68cb74b17a204e0aaa79ae0fd2c1cb91e59ba", "0x8c3e1a42b6494d9e6d999b5f65f4459b681a67137cda3b1b7ef7d6e80266b6f4", "0x40b4bec84697582547d9bab27b577bbead01cb0e1e05af88386ba2a884a9968d"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6689745 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6755231 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "FoMo3DLong", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "getBuyPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBuyPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalVolume_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalVolume_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "priceCntThreshould_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "priceCntThreshould_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "pIDxAddr_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pIDxAddr_(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "result_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "result_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "plyrNames_", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyrNames_(uint256,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "coscNum_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "coscNum_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "pIDxName_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pIDxName_(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cosdNum_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cosdNum_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ttlSply", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ttlSply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "string", name: "_keyType", value: random.string( maxRandom )}], name: "isCosd", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isCosd(string)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rID_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rID_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_eth", value: random.range( maxRandom )}], name: "howManyKeysCanBuy", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "howManyKeysCanBuy(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "pIDCom_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pIDCom_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalVltCosd_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalVltCosd_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "price_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "price_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_keys", value: random.range( maxRandom )}], name: "iWantXKeys", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "iWantXKeys(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "plyr_", outputs: [{name: "addr", type: "address"}, {name: "name", type: "bytes32"}, {name: "laff", type: "uint256"}, {name: "eth", type: "uint256"}, {name: "cosd", type: "uint256"}, {name: "cosc", type: "uint256"}, {name: "hldVltCosd", type: "uint256"}, {name: "affCosd", type: "uint256"}, {name: "affCosc", type: "uint256"}, {name: "totalHldVltCosd", type: "uint256"}, {name: "totalAffCos", type: "uint256"}, {name: "totalWinCos", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyr_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "plyNum_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyNum_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getPlayerInfoByAddress", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerInfoByAddress(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "FoMo3DLong", function( accounts ) {

	it( "TEST: FoMo3DLong(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6689745", timeStamp: "1542012524", hash: "0x34326bf2e12c3784d71f46748dcab6ec90dc50652aaf9e0d01b1a8f191a9ef64", nonce: "55", blockHash: "0xfcd15a72f1ad6fbe0e59a60cc4de171074bfab91cbc73f4bfa2f487072923b46", transactionIndex: "90", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: 0, value: "0", gas: "5371048", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfe57f14c", contractAddress: "0x7c90000d161ea9605bc5a84d3683a0971475315f", cumulativeGasUsed: "7688862", gasUsed: "5371048", confirmations: "1027013"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "FoMo3DLong", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = FoMo3DLong.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1542012524 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = FoMo3DLong.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXaddr( `fdasfdsaf13`, addressList[4], true )", async function( ) {
		const txOriginal = {blockNumber: "6689817", timeStamp: "1542013739", hash: "0x4f1a9bb90b17d6eed4a7514aa4b20c74b5f212272e225e61704d4d2045eac53d", nonce: "1", blockHash: "0x4a1f8336bd16c4d0851daed46cb0c7aac2482ed56873fca739e6227eabbc2bb9", transactionIndex: "29", from: "0x6ab7a52127ab31d48bbf1b5ae7e97a5052814511", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "598939", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3ddd4698000000000000000000000000000000000000000000000000000000000000006000000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000b6664617366647361663133000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4467749", gasUsed: "398354", confirmations: "1026941"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `fdasfdsaf13`}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "bool", name: "_all", value: true}], name: "registerNameXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXaddr(string,address,bool)" ]( `fdasfdsaf13`, addressList[4], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1542013739 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[1,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "4"}, {name: "playerAddress", type: "address", value: "0x6ab7a52127ab31d48bbf1b5ae7e97a5052814511"}, {name: "playerName", type: "bytes32", value: "0x6664617366647361663133000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: false}, {name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "affiliateName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "0"}, {name: "timeStamp", type: "uint256", value: "1542013739"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[1,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1798770000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXaddr( `adsf123`, addressList[4], true )", async function( ) {
		const txOriginal = {blockNumber: "6689868", timeStamp: "1542014516", hash: "0x710211c4c67048ff6a1704d1c2f972eb11d20b901b27549f5ac79a61c2d6f0bc", nonce: "2", blockHash: "0x90db03b9053edba85871ff194a4bb00c428e1f4b86fa561ef68a432b168ee0cb", transactionIndex: "85", from: "0x6ab7a52127ab31d48bbf1b5ae7e97a5052814511", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "478933", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3ddd4698000000000000000000000000000000000000000000000000000000000000006000000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b771000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000076164736631323300000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4828470", gasUsed: "319289", confirmations: "1026890"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `adsf123`}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "bool", name: "_all", value: true}], name: "registerNameXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXaddr(string,address,bool)" ]( `adsf123`, addressList[4], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1542014516 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[2,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "4"}, {name: "playerAddress", type: "address", value: "0x6ab7a52127ab31d48bbf1b5ae7e97a5052814511"}, {name: "playerName", type: "bytes32", value: "0x6164736631323300000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: false}, {name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "affiliateName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "0"}, {name: "timeStamp", type: "uint256", value: "1542014516"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[2,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1798770000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXaddr( `dafdas133`, addressList[4], true )", async function( ) {
		const txOriginal = {blockNumber: "6689928", timeStamp: "1542015480", hash: "0x5b701e270d85b3200600760ed0b8e7456742d052a7ed24f62bcf2db7b672891d", nonce: "0", blockHash: "0x6df4a04caa12d47c1a3ee4e0e47ff6cbce8e9d44104f46c63e223a8a2e1f412d", transactionIndex: "31", from: "0xfa9049c632fa18880cde19257116801e91a05cbe", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "1088296", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3ddd4698000000000000000000000000000000000000000000000000000000000000006000000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b771000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000096461666461733133330000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4173398", gasUsed: "724704", confirmations: "1026830"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `dafdas133`}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "bool", name: "_all", value: true}], name: "registerNameXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXaddr(string,address,bool)" ]( `dafdas133`, addressList[4], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1542015480 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[3,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "5"}, {name: "playerAddress", type: "address", value: "0xfa9049c632fa18880cde19257116801e91a05cbe"}, {name: "playerName", type: "bytes32", value: "0x6461666461733133330000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "affiliateName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "0"}, {name: "timeStamp", type: "uint256", value: "1542015480"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[3,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "3477664000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[6], addressList[4], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "6689945", timeStamp: "1542015666", hash: "0x0f36932990ea040889bb8dd1afc0126731f6fd1284804f2e5ed3078c0758e47f", nonce: "58", blockHash: "0xb2d487666d8f91eb74e2e7a78ae6ae2fe8817bdf440a363cc623193b5907cf81", transactionIndex: "105", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "160354", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc73000000000000000000000000fa9049c632fa18880cde19257116801e91a05cbe00000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b771000000000000000000000000000000000000000000000000016345785d8a000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000004636f736400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5689677", gasUsed: "106903", confirmations: "1026813"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[6]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "100000000000000000"}, {type: "string", name: "_keyType", value: `cosd`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[6], addressList[4], "100000000000000000", `cosd`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1542015666 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXaddr( `cosgameuser3`, addressList[4], true )", async function( ) {
		const txOriginal = {blockNumber: "6690020", timeStamp: "1542016618", hash: "0xa65fe34b6bac72f6b2ca8f1e053caad9b633ae67e2e4e76df0791a3719fa9205", nonce: "1", blockHash: "0xb5bb8e5ddc48a49c86dfd778616193317702ec0288e60998c08253c87e1c7360", transactionIndex: "28", from: "0x03a029c841fa2f22f02b791a824d70b13f135c9f", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "90000", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x3ddd4698000000000000000000000000000000000000000000000000000000000000006000000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000c636f7367616d6575736572330000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1018509", gasUsed: "89213", confirmations: "1026738"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `cosgameuser3`}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "bool", name: "_all", value: true}], name: "registerNameXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXaddr(string,address,bool)" ]( `cosgameuser3`, addressList[4], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1542016618 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1746220000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXaddr( `cosgameuser3`, addressList[4], true )", async function( ) {
		const txOriginal = {blockNumber: "6690061", timeStamp: "1542017169", hash: "0xa699235600ad180faad332f629c88c353b047f0475ebe3a194972ffd552f4558", nonce: "3", blockHash: "0x8122efe994ee6dfb6de97bfab8c809e4dd7acd70c68d5a5dc42b9a5e84872b77", transactionIndex: "70", from: "0x03a029c841fa2f22f02b791a824d70b13f135c9f", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "90000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x3ddd4698000000000000000000000000000000000000000000000000000000000000006000000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000c636f7367616d6575736572330000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3155076", gasUsed: "89213", confirmations: "1026697"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `cosgameuser3`}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "bool", name: "_all", value: true}], name: "registerNameXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXaddr(string,address,bool)" ]( `cosgameuser3`, addressList[4], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1542017169 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1746220000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXaddr( `cosgameuser3`, addressList[4], true )", async function( ) {
		const txOriginal = {blockNumber: "6690139", timeStamp: "1542018192", hash: "0xfb80afd9598dd4d9ce1ef77ae4eb163fc64e11532eadcc9dee1fd7cd6be0e7a8", nonce: "5", blockHash: "0x1081bfb151fe7da65b163ce2ca03dc25141e679fdd0628661abceb054501ba95", transactionIndex: "130", from: "0x03a029c841fa2f22f02b791a824d70b13f135c9f", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "90000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x3ddd4698000000000000000000000000000000000000000000000000000000000000006000000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000c636f7367616d6575736572330000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5735914", gasUsed: "89213", confirmations: "1026619"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `cosgameuser3`}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "bool", name: "_all", value: true}], name: "registerNameXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXaddr(string,address,bool)" ]( `cosgameuser3`, addressList[4], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1542018192 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1746220000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXaddr( `cosgameuser3`, addressList[4], true )", async function( ) {
		const txOriginal = {blockNumber: "6690164", timeStamp: "1542018554", hash: "0x80a6faaf16a9289fe5a502f58b75a23838534848cb915308a0f037a1b329a8c0", nonce: "7", blockHash: "0x987146d1843002f159193f14e92d4d23bd1954bac873d68a101ea1f00efa15e4", transactionIndex: "57", from: "0x03a029c841fa2f22f02b791a824d70b13f135c9f", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "90000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x3ddd4698000000000000000000000000000000000000000000000000000000000000006000000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000c636f7367616d6575736572330000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3331366", gasUsed: "89213", confirmations: "1026594"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `cosgameuser3`}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "bool", name: "_all", value: true}], name: "registerNameXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXaddr(string,address,bool)" ]( `cosgameuser3`, addressList[4], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1542018554 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1746220000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXaddr( `cosgameuser3`, addressList[4], true )", async function( ) {
		const txOriginal = {blockNumber: "6690214", timeStamp: "1542019250", hash: "0x6c20c9cc82637f027e7105423bcf8b102621c8a7240fd2a3ac98c6e8b15356c2", nonce: "9", blockHash: "0x6746ff766eac7eb2af53f9239e26daaf0ff14050af753dec671c1093464425fc", transactionIndex: "52", from: "0x03a029c841fa2f22f02b791a824d70b13f135c9f", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3ddd4698000000000000000000000000000000000000000000000000000000000000006000000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000c636f7367616d6575736572330000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2650439", gasUsed: "727313", confirmations: "1026544"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `cosgameuser3`}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "bool", name: "_all", value: true}], name: "registerNameXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXaddr(string,address,bool)" ]( `cosgameuser3`, addressList[4], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1542019250 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "6"}, {name: "playerAddress", type: "address", value: "0x03a029c841fa2f22f02b791a824d70b13f135c9f"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572330000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "affiliateName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "0"}, {name: "timeStamp", type: "uint256", value: "1542019250"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1746220000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[7], addressList[4], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "6690241", timeStamp: "1542019542", hash: "0x3f549c68010c9a81c611a7fb1f3709921e7b11f1522a72bb04fea5ea3fa64db6", nonce: "59", blockHash: "0x5aeaf294ec0049bc11a06f8f1d56dad1ec9dfdc48a280e775d740f7e5dec069b", transactionIndex: "9", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "90000", gasPrice: "15000000000", isError: "1", txreceipt_status: "0", input: "0x2171dc7300000000000000000000000003a029c841fa2f22f02b791a824d70b13f135c9f00000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "559323", gasUsed: "90000", confirmations: "1026517"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[7]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "10000000000000000000"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[7], addressList[4], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "6690247", timeStamp: "1542019637", hash: "0x7f86235fd5ed64a3fd2d8bdb7d9dcde4a275fc2a31ff71c1a2d32455355f63a1", nonce: "60", blockHash: "0xe833fd759e16c4805b58ca08f8196cbbcf581858bdecc5de97689ed930f00ce6", transactionIndex: "69", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "1000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc7300000000000000000000000003a029c841fa2f22f02b791a824d70b13f135c9f00000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3541335", gasUsed: "248023", confirmations: "1026511"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[7]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "10000000000000000000"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[7], addressList[4], "10000000000000000000", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1542019637 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "0"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sellKeys( \"6\", \"100\", `636f7364` )", async function( ) {
		const txOriginal = {blockNumber: "6690263", timeStamp: "1542019973", hash: "0x3f6ace3c5e4b987c4113615e24233049c4ff903d0eb8ac6a944ec1e506f3a652", nonce: "61", blockHash: "0x4598eaa991ba1d26712a769d0e2451f6f077c000ffa0865e60aaf245a0dc815b", transactionIndex: "50", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xd826853e00000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2552148", gasUsed: "125948", confirmations: "1026495"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "6"}, {type: "uint256", name: "_keys", value: "100"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "sellKeys", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellKeys(uint256,uint256,string)" ]( "6", "100", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1542019973 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[12,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "20"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[12,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: sellKeys( \"6\", \"100\", `636f7364` )", async function( ) {
		const txOriginal = {blockNumber: "6690278", timeStamp: "1542020159", hash: "0xbd78f8c81eb3c1582581b7d83835f9760470b650fa120810d6a2a7701ab6a788", nonce: "62", blockHash: "0x90bc4b1534cb213c027ff9ae8414c565f2ec361d087fc2817cd4909dbe32eb0b", transactionIndex: "36", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xd826853e00000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2545664", gasUsed: "95948", confirmations: "1026480"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "6"}, {type: "uint256", name: "_keys", value: "100"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "sellKeys", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellKeys(uint256,uint256,string)" ]( "6", "100", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1542020159 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "40"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: sellKeys( \"6\", \"100\", `636f7364` )", async function( ) {
		const txOriginal = {blockNumber: "6690297", timeStamp: "1542020344", hash: "0x950ff7fb23b6e0989cfa59ab868fbec63ca54763cb3dba7d74f664ef76b83fea", nonce: "63", blockHash: "0xf2a9ed1b291c5d9def27bee977271a282c68129d9c284ba299d98219289f4239", transactionIndex: "11", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xd826853e00000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "503002", gasUsed: "95948", confirmations: "1026461"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "6"}, {type: "uint256", name: "_keys", value: "100"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "sellKeys", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellKeys(uint256,uint256,string)" ]( "6", "100", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1542020344 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "60"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: sellKeys( \"6\", \"100\", `636f7364` )", async function( ) {
		const txOriginal = {blockNumber: "6690301", timeStamp: "1542020456", hash: "0xf80912dbb173f2c6d4085e14ccc35fa74de0f325dcb9ba99ad4d46b328535a5b", nonce: "64", blockHash: "0x57f10b235b659ab5e2879427993839014ea3a8a86b4ee090a20d5010bd1b2c04", transactionIndex: "39", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xd826853e00000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2424980", gasUsed: "95948", confirmations: "1026457"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "6"}, {type: "uint256", name: "_keys", value: "100"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "sellKeys", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellKeys(uint256,uint256,string)" ]( "6", "100", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1542020456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[15,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "80"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[15,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawETH( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6690303", timeStamp: "1542020467", hash: "0x5b9a759a6f2db0f9d28864f8676fc310953cb98d1cb4cdfe67c017209c9719ae", nonce: "65", blockHash: "0xd6160b54a1ce88ac88e43405780622aaa569b919920abea7263bf9f218731caf", transactionIndex: "17", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xf14210a60000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "726856", gasUsed: "14075", confirmations: "1026455"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "6"}], name: "withdrawETH", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawETH(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1542020467 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transferToAnotherAddr( addressList[6], addressList[7], \"2\", `... )", async function( ) {
		const txOriginal = {blockNumber: "6690393", timeStamp: "1542021851", hash: "0x5b6fa4e3098fb2ada4a763b9f5476e82fde41652d9d8e7b1d000f3535f6831a4", nonce: "66", blockHash: "0xf69601c7fc4999322718d4b7fee201b9daf2ecd62caf7241174285f6c131ed2c", transactionIndex: "22", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "79362", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0eac7a0e000000000000000000000000fa9049c632fa18880cde19257116801e91a05cbe00000000000000000000000003a029c841fa2f22f02b791a824d70b13f135c9f000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000004636f736400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "712937", gasUsed: "52908", confirmations: "1026365"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[6]}, {type: "address", name: "_to", value: addressList[7]}, {type: "uint256", name: "_keys", value: "2"}, {type: "string", name: "_keyType", value: `cosd`}], name: "transferToAnotherAddr", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferToAnotherAddr(address,address,uint256,string)" ]( addressList[6], addressList[7], "2", `cosd`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1542021851 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: winCosFromGame( \"6\", \"100\", `c` )", async function( ) {
		const txOriginal = {blockNumber: "6690398", timeStamp: "1542021897", hash: "0x941b3d056d6b5eae63896198ab480a752a271993a1c5296f40fcf917f3857275", nonce: "67", blockHash: "0xa442c58bcee5918877ea9f0d4d65b731cd0a76070fe2149dea944d9c34f666d3", transactionIndex: "8", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "73992", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4a522e4e00000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000016300000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "306900", gasUsed: "49328", confirmations: "1026360"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "6"}, {type: "uint256", name: "_keys", value: "100"}, {type: "string", name: "_keyType", value: `c`}], name: "winCosFromGame", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "winCosFromGame(uint256,uint256,string)" ]( "6", "100", `c`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1542021897 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: addCosToGame( \"6\", \"100\", `c` )", async function( ) {
		const txOriginal = {blockNumber: "6690405", timeStamp: "1542021957", hash: "0x58cc161484a4370213539ef0bc19ddac4bf97c1905e9d17e8ef8b1075dbee4f8", nonce: "68", blockHash: "0x69ba1cce7ddcef6ee3599305a35d03ce7abb718f0b55bf4a3791b14421dfb4c0", transactionIndex: "73", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "44571", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb69f917d00000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000016300000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3994416", gasUsed: "29714", confirmations: "1026353"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "6"}, {type: "uint256", name: "_keys", value: "100"}, {type: "string", name: "_keyType", value: `c`}], name: "addCosToGame", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addCosToGame(uint256,uint256,string)" ]( "6", "100", `c`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1542021957 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[7], addressList[4], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "6690428", timeStamp: "1542022269", hash: "0x121964869ec995bd357cad84ab0db7ce26b75ba3c976ad75219639441f7b4bcd", nonce: "69", blockHash: "0xe2a8bc659b7461540c67df608f26f3d09b2927dca03427ea272cc122997edb3e", transactionIndex: "48", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "130204", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc7300000000000000000000000003a029c841fa2f22f02b791a824d70b13f135c9f00000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000016300000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1667653", gasUsed: "86803", confirmations: "1026330"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[7]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "1000000000000000000"}, {type: "string", name: "_keyType", value: `c`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[7], addressList[4], "1000000000000000000", `c`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1542022269 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXaddr( `cosgameuser1`, addressList[4], true )", async function( ) {
		const txOriginal = {blockNumber: "6694059", timeStamp: "1542072490", hash: "0xa8ba18b93e46f45972165714ed57f9bdb79916059a6309ebf4bec6a3d8699f8f", nonce: "30", blockHash: "0xa4e0975cc99e9b02813b5a72a73ff36b67b0f5fffdaf0398a924e7f65770253d", transactionIndex: "24", from: "0xf22eabc3f1275b43194a2883d88c8c83139d233a", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3ddd4698000000000000000000000000000000000000000000000000000000000000006000000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000c636f7367616d6575736572310000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1812519", gasUsed: "727313", confirmations: "1022699"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `cosgameuser1`}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "bool", name: "_all", value: true}], name: "registerNameXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXaddr(string,address,bool)" ]( `cosgameuser1`, addressList[4], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1542072490 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "7"}, {name: "playerAddress", type: "address", value: "0xf22eabc3f1275b43194a2883d88c8c83139d233a"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572310000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "affiliateName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "0"}, {name: "timeStamp", type: "uint256", value: "1542072490"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1523400000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[8], addressList[4], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "6694073", timeStamp: "1542072683", hash: "0x00c606e68e492423efa85f8c62f1daa2128e3fcc0dcfbdd56f58fe65d9401ec3", nonce: "70", blockHash: "0xcf6de71141e22fcc1372636290b83b0db1def1c4bd228a9d2c51c3c47620aa16", transactionIndex: "76", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc73000000000000000000000000f22eabc3f1275b43194a2883d88c8c83139d233a00000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4110565", gasUsed: "200755", confirmations: "1022685"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[8]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "10000000000000000000"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[8], addressList[4], "10000000000000000000", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1542072683 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "134"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[8], addressList[4], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "6694079", timeStamp: "1542072803", hash: "0x3452ff0f4d8555cd4eda27187dec475045a03fc4b47c750e54b07d15f1189ec8", nonce: "71", blockHash: "0xec4f0477b83c0b07cd76b24a30e72dfda50bd9b7aa2854d1680b5700ead763cb", transactionIndex: "11", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc73000000000000000000000000f22eabc3f1275b43194a2883d88c8c83139d233a00000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "561237", gasUsed: "181115", confirmations: "1022679"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[8]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "10000000000000000000"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[8], addressList[4], "10000000000000000000", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1542072803 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "174"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[8], addressList[4], \"120000... )", async function( ) {
		const txOriginal = {blockNumber: "6694083", timeStamp: "1542072863", hash: "0x79caa6ef0f2e57677f1527e5ce839bb442a785f6aa86438b5543b8b1c29ee5e2", nonce: "72", blockHash: "0x73e945d9b99109e11e1e56d4a78a66c80e0e4f501b2414de946e3becfbee37f4", transactionIndex: "6", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc73000000000000000000000000f22eabc3f1275b43194a2883d88c8c83139d233a00000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b771000000000000000000000000000000000000000000000000a688906bd8b000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a3633366637333633363300000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "355805", gasUsed: "211535", confirmations: "1022675"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[8]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "12000000000000000000"}, {type: "string", name: "_keyType", value: `636f736363`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[8], addressList[4], "12000000000000000000", `636f736363`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1542072863 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: addCosToGame( \"7\", \"100\", `636f7364` )", async function( ) {
		const txOriginal = {blockNumber: "6694095", timeStamp: "1542073073", hash: "0x71fcbe5f3064a68beade883748448ee3d1f582656109287b65c62987058022b6", nonce: "73", blockHash: "0x45533bdf814806c26622ba7e18c7c6b7e5375f13f346f7e7adc20d8294c91f2a", transactionIndex: "24", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xb69f917d00000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "739729", gasUsed: "56505", confirmations: "1022663"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "7"}, {type: "uint256", name: "_keys", value: "100"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "addCosToGame", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addCosToGame(uint256,uint256,string)" ]( "7", "100", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1542073073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "179"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[7], addressList[4], \"500000... )", async function( ) {
		const txOriginal = {blockNumber: "6694100", timeStamp: "1542073207", hash: "0x5cf4b0176fa3238b426884a0c3117d8a443c5e5782d611b07e3e31948850dbbd", nonce: "74", blockHash: "0x120184deeb6189ff70fd8d42055b738cac4872b00ec93d1948ac4b86e03e9e90", transactionIndex: "163", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc7300000000000000000000000003a029c841fa2f22f02b791a824d70b13f135c9f00000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b771000000000000000000000000000000000000000000000002b5e3af16b18800000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a3633366637333633363300000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5184495", gasUsed: "514519", confirmations: "1022658"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[7]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "50000000000000000000"}, {type: "string", name: "_keyType", value: `636f736363`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[7], addressList[4], "50000000000000000000", `636f736363`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542073207 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: addCosToGame( \"6\", \"200\", `636f736363` )", async function( ) {
		const txOriginal = {blockNumber: "6694107", timeStamp: "1542073320", hash: "0xc5cb1cc81d16fe355d94dcc3b850d9624f83d5888f10baef31b1478e334b469f", nonce: "75", blockHash: "0x7e2e771bf48266cbdfd89b14eb052952a6b1f186b3f8c229605029f090bb7b00", transactionIndex: "8", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xb69f917d000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000c80000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000a3633366637333633363300000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "290929", gasUsed: "30290", confirmations: "1022651"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "6"}, {type: "uint256", name: "_keys", value: "200"}, {type: "string", name: "_keyType", value: `636f736363`}], name: "addCosToGame", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addCosToGame(uint256,uint256,string)" ]( "6", "200", `636f736363`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542073320 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXaddr( `cosgameuser4`, addressList[4], true )", async function( ) {
		const txOriginal = {blockNumber: "6694278", timeStamp: "1542075528", hash: "0x42776f094be5017053e8b30faab4558cf3d2df4d107d304d1990abc740c6738d", nonce: "0", blockHash: "0xb4912164c5526793c1cab349d544c276463dabaad84abac341aacc72c39aaa82", transactionIndex: "27", from: "0x13897c6cd2a86c89b842f642508d65642b6718ae", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3ddd4698000000000000000000000000000000000000000000000000000000000000006000000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000c636f7367616d6575736572340000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1668213", gasUsed: "727313", confirmations: "1022480"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `cosgameuser4`}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "bool", name: "_all", value: true}], name: "registerNameXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXaddr(string,address,bool)" ]( `cosgameuser4`, addressList[4], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542075528 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "8"}, {name: "playerAddress", type: "address", value: "0x13897c6cd2a86c89b842f642508d65642b6718ae"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572340000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "affiliateName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "0"}, {name: "timeStamp", type: "uint256", value: "1542075528"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2306870000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[9], addressList[4], \"150000... )", async function( ) {
		const txOriginal = {blockNumber: "6694292", timeStamp: "1542075674", hash: "0xc23b4bd79738659f9c864c05e905aff095a5ecaa22a3a7163abe48d2ec6f6c89", nonce: "77", blockHash: "0x86cd4913c8c890571965b310a60eff660b99d332a2f321abb9e7994b8bc14df7", transactionIndex: "9", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc7300000000000000000000000013897c6cd2a86c89b842f642508d65642b6718ae00000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b771000000000000000000000000000000000000000000000000d02ab486cedc0000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "732125", gasUsed: "240534", confirmations: "1022466"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[9]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "15000000000000000000"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[9], addressList[4], "15000000000000000000", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542075674 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "183"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x03a029c841fa2f22f02b791a824d70b13f135c9f"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572330000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "28"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: addCosToGame( \"8\", \"150\", `636f7364` )", async function( ) {
		const txOriginal = {blockNumber: "6694296", timeStamp: "1542075702", hash: "0xda599b0e607f42ff7b549025fb410b7262db06448962b94faab2229c4c4202ea", nonce: "78", blockHash: "0x8ecffda3964a67e4d88d4ca93c2284a125d9eb14cce121ef2f2594fd7365247f", transactionIndex: "42", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xb69f917d00000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000096000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1660068", gasUsed: "66668", confirmations: "1022462"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "8"}, {type: "uint256", name: "_keys", value: "150"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "addCosToGame", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addCosToGame(uint256,uint256,string)" ]( "8", "150", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542075702 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[30,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "184"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x03a029c841fa2f22f02b791a824d70b13f135c9f"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572330000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "34"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[30,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXaddr( `cosgameuser12`, addressList[4], true )", async function( ) {
		const txOriginal = {blockNumber: "6694330", timeStamp: "1542076151", hash: "0x307d72c713d5c573c41fa7682889fc935148242ba1d37a264d605ee133b23892", nonce: "0", blockHash: "0xd70fdfe8877b06e290349680576b21ca4c0062af45dccd15037fbbcf559b3dbb", transactionIndex: "21", from: "0xe534f3f81e34677eeddb8c2a3139ca0181cacf87", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3ddd4698000000000000000000000000000000000000000000000000000000000000006000000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000d636f7367616d6575736572313200000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2106941", gasUsed: "728216", confirmations: "1022428"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `cosgameuser12`}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "bool", name: "_all", value: true}], name: "registerNameXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXaddr(string,address,bool)" ]( `cosgameuser12`, addressList[4], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542076151 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "9"}, {name: "playerAddress", type: "address", value: "0xe534f3f81e34677eeddb8c2a3139ca0181cacf87"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572313200000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "affiliateName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "0"}, {name: "timeStamp", type: "uint256", value: "1542076151"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12717840000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[10], addressList[4], \"10000... )", async function( ) {
		const txOriginal = {blockNumber: "6694333", timeStamp: "1542076205", hash: "0x888bf10e97d2d559784ea7d092a8707fb5496585036f6f69a2910636b3ea240a", nonce: "79", blockHash: "0xaab7806b0b3ae445c492561e99375007892fe5307cc8532978f5a7c66f3cca8a", transactionIndex: "17", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc73000000000000000000000000e534f3f81e34677eeddb8c2a3139ca0181cacf8700000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000056bc75e2d631000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a3633366637333633363300000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1361769", gasUsed: "806643", confirmations: "1022425"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[10]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "100000000000000000000"}, {type: "string", name: "_keyType", value: `636f736363`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[10], addressList[4], "100000000000000000000", `636f736363`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1542076205 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: addCosToGame( \"9\", \"250\", `636f736363` )", async function( ) {
		const txOriginal = {blockNumber: "6694337", timeStamp: "1542076254", hash: "0xb96b9b546e21d33c63c2e9650c6f6ccf89cfa52ebf5777d9f718a9bfbb25ff07", nonce: "80", blockHash: "0x73bb95aeeeae7958547bbba3614dca568aaa9a1040d77406041f3fedbf04adf9", transactionIndex: "13", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xb69f917d000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000fa0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000a3633366637333633363300000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "391679", gasUsed: "30290", confirmations: "1022421"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "9"}, {type: "uint256", name: "_keys", value: "250"}, {type: "string", name: "_keyType", value: `636f736363`}], name: "addCosToGame", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addCosToGame(uint256,uint256,string)" ]( "9", "250", `636f736363`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542076254 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: addCosToGame( \"9\", \"300\", `636f736363` )", async function( ) {
		const txOriginal = {blockNumber: "6700121", timeStamp: "1542158353", hash: "0x00cf228dd033188085a0ae8ac97c4ca77acd8a8435cf9cb53a57fe6d953aa65a", nonce: "81", blockHash: "0xda243d5a2c7d0819f8e1f2e23dcd3eb6cc6503bb1904a539b507ea9eba679f40", transactionIndex: "28", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xb69f917d0000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000012c0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000a3633366637333633363300000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1466576", gasUsed: "30354", confirmations: "1016637"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "9"}, {type: "uint256", name: "_keys", value: "300"}, {type: "string", name: "_keyType", value: `636f736363`}], name: "addCosToGame", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addCosToGame(uint256,uint256,string)" ]( "9", "300", `636f736363`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542158353 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: addCosToGame( \"8\", \"150\", `636f7364` )", async function( ) {
		const txOriginal = {blockNumber: "6700124", timeStamp: "1542158408", hash: "0x55736adcd13fffe068ffdf169319ca73b39b796079d0abe5621a4966f021a4d3", nonce: "82", blockHash: "0x3641fcecfa4a04ab0731a57f6dc27a07d4d5e7bd01306343e49ede4cfcf227aa", transactionIndex: "17", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xb69f917d00000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000096000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "674894", gasUsed: "91831", confirmations: "1016634"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "8"}, {type: "uint256", name: "_keys", value: "150"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "addCosToGame", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addCosToGame(uint256,uint256,string)" ]( "8", "150", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542158408 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "184"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x03a029c841fa2f22f02b791a824d70b13f135c9f"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572330000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "35"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0xf22eabc3f1275b43194a2883d88c8c83139d233a"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572310000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "5"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: addCosToGame( \"7\", \"150\", `636f7364` )", async function( ) {
		const txOriginal = {blockNumber: "6700128", timeStamp: "1542158468", hash: "0xa8cdcab15162d8ffa34289b53db909ad1e1dbca58764db8c791e5eeb36c6e96a", nonce: "83", blockHash: "0x75a58c735b63d791271875d83eefa7a7d78d93bafbad4cf5f4346f63ced65e57", transactionIndex: "21", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xb69f917d00000000000000000000000000000000000000000000000000000000000000070000000000000000000000000000000000000000000000000000000000000096000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "763001", gasUsed: "76831", confirmations: "1016630"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "7"}, {type: "uint256", name: "_keys", value: "150"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "addCosToGame", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addCosToGame(uint256,uint256,string)" ]( "7", "150", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1542158468 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[36,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "184"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x03a029c841fa2f22f02b791a824d70b13f135c9f"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572330000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "36"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0xf22eabc3f1275b43194a2883d88c8c83139d233a"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572310000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "9"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[36,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: addCosToGame( \"6\", \"200\", `636f736363` )", async function( ) {
		const txOriginal = {blockNumber: "6700136", timeStamp: "1542158587", hash: "0x1a1610b8db103b6fb56381b2331425ae5f066c3b3d4aeb94112f7ce8951cdd2c", nonce: "84", blockHash: "0x3d44862585c19bb7e9a7b9150962d182ce1983c8496059823ea920b40223166c", transactionIndex: "46", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xb69f917d000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000c80000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000a3633366637333633363300000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4276149", gasUsed: "30290", confirmations: "1016622"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "6"}, {type: "uint256", name: "_keys", value: "200"}, {type: "string", name: "_keyType", value: `636f736363`}], name: "addCosToGame", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addCosToGame(uint256,uint256,string)" ]( "6", "200", `636f736363`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542158587 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: winCosFromGame( \"6\", \"830\", `636f736363` )", async function( ) {
		const txOriginal = {blockNumber: "6700603", timeStamp: "1542165224", hash: "0x074e692a7d30a66682745e5c38da981b37e74fd66c1b37181c03377ddd2214f2", nonce: "85", blockHash: "0x8ba28c948c5a657778856a7bc1a182906a84161907b6ff00d3d9647ec15d611d", transactionIndex: "23", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x4a522e4e0000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000033e0000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000a3633366637333633363300000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1099668", gasUsed: "34968", confirmations: "1016155"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "6"}, {type: "uint256", name: "_keys", value: "830"}, {type: "string", name: "_keyType", value: `636f736363`}], name: "winCosFromGame", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "winCosFromGame(uint256,uint256,string)" ]( "6", "830", `636f736363`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542165224 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: winCosFromGame( \"7\", \"622\", `636f7364` )", async function( ) {
		const txOriginal = {blockNumber: "6700608", timeStamp: "1542165285", hash: "0xea8febd657aeadfd22e608af7e662a3b347dc1cf0342937b83609d49d73ef988", nonce: "86", blockHash: "0x46e3edd77899dfd813a60d8a4225a64727ce9bd6ab6b3ee26e851211beb1c9d9", transactionIndex: "26", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x4a522e4e0000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000026e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "882061", gasUsed: "49860", confirmations: "1016150"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "7"}, {type: "uint256", name: "_keys", value: "622"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "winCosFromGame", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "winCosFromGame(uint256,uint256,string)" ]( "7", "622", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542165285 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: winCosFromGame( \"8\", \"484\", `636f7364` )", async function( ) {
		const txOriginal = {blockNumber: "6700618", timeStamp: "1542165408", hash: "0x30fea766c82d027cea34d21e8a564a909b7835f3b66fbf2ea058a800a14bc7a8", nonce: "87", blockHash: "0x7d23403b829c1eed16d788e2a7fcf7cfad59ec9f746b027a095373bdfe7f70fa", transactionIndex: "53", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x4a522e4e000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000001e4000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3370438", gasUsed: "49860", confirmations: "1016140"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_pID", value: "8"}, {type: "uint256", name: "_keys", value: "484"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "winCosFromGame", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "winCosFromGame(uint256,uint256,string)" ]( "8", "484", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1542165408 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: transferToAnotherAddr( addressList[9], addressList[11], \"230\"... )", async function( ) {
		const txOriginal = {blockNumber: "6700767", timeStamp: "1542167809", hash: "0xd4e0dd16a588443c3b6ba0c6411c8f8f89690d26a516bcb09d56fb87d18ef2fd", nonce: "88", blockHash: "0x499035129b12c6a5aceb8db1c5fd1509a997da5afe9b845c8f1bafa31408b70b", transactionIndex: "171", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "1", txreceipt_status: "0", input: "0x0eac7a0e00000000000000000000000013897c6cd2a86c89b842f642508d65642b6718ae0000000000000000000000004b04ffa80bbdf34b4c40437a2dc83c89c6025fd800000000000000000000000000000000000000000000000000000000000000e6000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5128338", gasUsed: "26746", confirmations: "1015991"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[9]}, {type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_keys", value: "230"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "transferToAnotherAddr", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferToAnotherAddr(address,address,uint256,string)" ]( addressList[9], addressList[11], "230", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1542167809 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[10], addressList[4], \"10000... )", async function( ) {
		const txOriginal = {blockNumber: "6701940", timeStamp: "1542184845", hash: "0xd5a8666998ee8d6231ab94dc8d3dd0f22004c22bf2e2f1c570263ab1646d44d1", nonce: "89", blockHash: "0x4716fe208bf10f6cefe3318f0c16fd1a69a8671b55eed74ece2173452860c8e7", transactionIndex: "124", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc73000000000000000000000000e534f3f81e34677eeddb8c2a3139ca0181cacf8700000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5080194", gasUsed: "177697", confirmations: "1014818"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[10]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "10000000000000000000"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[10], addressList[4], "10000000000000000000", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1542184845 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "184"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x03a029c841fa2f22f02b791a824d70b13f135c9f"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572330000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "39"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0xf22eabc3f1275b43194a2883d88c8c83139d233a"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572310000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "22"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[9], addressList[4], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "6701974", timeStamp: "1542185442", hash: "0xb730156c5d269e9d66982d8b151599e822ddc9cc815305958f3f80c0b67be626", nonce: "90", blockHash: "0x332da3bfbf5b9b2272872133b407ad602a5282e4c1f0f508c840da8268cbfb2a", transactionIndex: "145", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "124108", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc7300000000000000000000000013897c6cd2a86c89b842f642508d65642b6718ae00000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a3078363336663733363400000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7187174", gasUsed: "82739", confirmations: "1014784"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[9]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "1000000000000000000"}, {type: "string", name: "_keyType", value: `0x636f7364`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[9], addressList[4], "1000000000000000000", `0x636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1542185442 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[10], addressList[4], \"10000... )", async function( ) {
		const txOriginal = {blockNumber: "6702101", timeStamp: "1542187070", hash: "0xfb268f6f81892910157fa8bacdc9387b036881d6dc97d4a04a06e61c6dca203a", nonce: "91", blockHash: "0xbe9031c94c89ac006dcec859834ebe5160b21282a7b6c27fd0ace216827cf328", transactionIndex: "82", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "145737", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc73000000000000000000000000e534f3f81e34677eeddb8c2a3139ca0181cacf8700000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b771000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3860803", gasUsed: "97158", confirmations: "1014657"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[10]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "100000000000000000"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[10], addressList[4], "100000000000000000", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1542187070 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[44,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "184"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x03a029c841fa2f22f02b791a824d70b13f135c9f"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572330000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "39"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0xf22eabc3f1275b43194a2883d88c8c83139d233a"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572310000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "22"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[44,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXaddr( `asd123156`, addressList[4], true )", async function( ) {
		const txOriginal = {blockNumber: "6702375", timeStamp: "1542191142", hash: "0xf9dbf379666a5dd847b52a8823a46312980a8c5750e72cfe1936a361269cceb8", nonce: "0", blockHash: "0x1655587174cc200ead2f012faad430c6fcd656c9e82bc5b8667e993415b662a8", transactionIndex: "102", from: "0x27c086d6d68c76d5b6c47492247e9ea600959368", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "1088386", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3ddd4698000000000000000000000000000000000000000000000000000000000000006000000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b771000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000096173643132333135360000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4741907", gasUsed: "724764", confirmations: "1014383"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `asd123156`}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "bool", name: "_all", value: true}], name: "registerNameXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXaddr(string,address,bool)" ]( `asd123156`, addressList[4], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1542191142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "10"}, {name: "playerAddress", type: "address", value: "0x27c086d6d68c76d5b6c47492247e9ea600959368"}, {name: "playerName", type: "bytes32", value: "0x6173643132333135360000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "affiliateName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "0"}, {name: "timeStamp", type: "uint256", value: "1542191142"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "3201888000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[12], addressList[4], \"10000... )", async function( ) {
		const txOriginal = {blockNumber: "6702384", timeStamp: "1542191361", hash: "0x044645018454f771f79364d448815acc57615ffac0921e93a4fae7bec367bf7b", nonce: "93", blockHash: "0x6985dce723370b472da8d2c33a86ccbc636ec741e9d15f2f1d828fae46f3f78f", transactionIndex: "117", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "124012", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc7300000000000000000000000027c086d6d68c76d5b6c47492247e9ea60095936800000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a3078363336663733363400000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7728499", gasUsed: "82675", confirmations: "1014374"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[12]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "1000000000000000000"}, {type: "string", name: "_keyType", value: `0x636f7364`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[12], addressList[4], "1000000000000000000", `0x636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1542191361 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[12], addressList[4], \"10000... )", async function( ) {
		const txOriginal = {blockNumber: "6702398", timeStamp: "1542191564", hash: "0x0295c88a0df83c762ec2a61fc69de401a22377a2becc32dcf58404140768b794", nonce: "94", blockHash: "0xd11fb2e8dceeed31f948b39d59792f23c1a4f904aecbf01ce32224b26d5f28ec", transactionIndex: "94", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "302280", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc7300000000000000000000000027c086d6d68c76d5b6c47492247e9ea60095936800000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7333200", gasUsed: "201520", confirmations: "1014360"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[12]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "10000000000000000000"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[12], addressList[4], "10000000000000000000", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1542191564 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "184"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x03a029c841fa2f22f02b791a824d70b13f135c9f"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572330000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "41"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0xf22eabc3f1275b43194a2883d88c8c83139d233a"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572310000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "30"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x13897c6cd2a86c89b842f642508d65642b6718ae"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572340000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "4"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: transferToAnotherAddr( addressList[10], addressList[9], \"10\",... )", async function( ) {
		const txOriginal = {blockNumber: "6708116", timeStamp: "1542272082", hash: "0x2a004e304a5a43f37b86d868aaef9ed4cdc84f13c952a2131df72d59924e24c3", nonce: "95", blockHash: "0xcda1634dc3bbb6f1bed68e32d52a63e826275d7292d09642fb9871c2429f2918", transactionIndex: "12", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "57438", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x0eac7a0e000000000000000000000000e534f3f81e34677eeddb8c2a3139ca0181cacf8700000000000000000000000013897c6cd2a86c89b842f642508d65642b6718ae000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a3078363336663733363400000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "752001", gasUsed: "38292", confirmations: "1008642"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[10]}, {type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_keys", value: "10"}, {type: "string", name: "_keyType", value: `0x636f7364`}], name: "transferToAnotherAddr", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferToAnotherAddr(address,address,uint256,string)" ]( addressList[10], addressList[9], "10", `0x636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1542272082 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[8], addressList[4], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "6755231", timeStamp: "1542940036", hash: "0x68d5237d62d4db2d9d72e6421f579ec52915c320eedea80dab9302f6b72f4c45", nonce: "96", blockHash: "0xa6956a9b85784133ab9e0173e274e534c175c856ca53027ff2131e7cee3885af", transactionIndex: "35", from: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771", to: "0x7c90000d161ea9605bc5a84d3683a0971475315f", value: "0", gas: "200000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x2171dc73000000000000000000000000f22eabc3f1275b43194a2883d88c8c83139d233a00000000000000000000000062199eafd8f0da50be2176d49d3db3aff2a9b7710000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000083633366637333634000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1397614", gasUsed: "170656", confirmations: "961527"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pAddr", value: addressList[8]}, {type: "address", name: "_affCode", value: addressList[4]}, {type: "uint256", name: "_eth", value: "10000000000000000000"}, {type: "string", name: "_keyType", value: `636f7364`}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,address,uint256,string)" ]( addressList[8], addressList[4], "10000000000000000000", `636f7364`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1542940036 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "hldVltCosd", type: "uint256"}], name: "onRecHldVltCosd", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x62199eafd8f0da50be2176d49d3db3aff2a9b771"}, {name: "playerName", type: "bytes32", value: "0x6d65726375727900000000000000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "184"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x03a029c841fa2f22f02b791a824d70b13f135c9f"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572330000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "43"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0xf22eabc3f1275b43194a2883d88c8c83139d233a"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572310000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "40"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}, {name: "onRecHldVltCosd", events: [{name: "playerAddress", type: "address", value: "0x13897c6cd2a86c89b842f642508d65642b6718ae"}, {name: "playerName", type: "bytes32", value: "0x636f7367616d6575736572340000000000000000000000000000000000000000"}, {name: "hldVltCosd", type: "uint256", value: "8"}], address: "0x7c90000d161ea9605bc5a84d3683a0971475315f"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "226754362080000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
