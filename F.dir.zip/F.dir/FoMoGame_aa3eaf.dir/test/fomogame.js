const FoMoGame = artifacts.require( "./FoMoGame.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "FoMoGame" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x58DB9E7a4aFCA731d824eeeFa55CE37666aa3eAf", "0xfE373e4c13eD07962fFA546D1f0BE2298D5493b0", "0x463a61560e0EFF1a7ec771eeb9fd1c93fb075c2E", "0x7298EFD119A830edab6C442632EEff14292609B0", "0x937328B032B7d9A972D5EB8CbDC0D3c9B0EB379D", "0x9aC45D299d3FB8E31C37714963f7D1FE4838fD0b", "0x7C83097eaFd71176eBf2c0352924fB74df929869", "0x61F090f0b4F420256988e4149f2F132F97012b0D", "0x852c99eff5F738036d3DF058384fd37a7244Edab", "0xb820b87523A0768663b56d1448b1169305FF3fF4", "0x064fd3d828D84434b09327BF93615db20117b7A3", "0xC9207966F8bE7F60390F66ec3Ec936c75034ACcA", "0x2176596Ef0E65834d45e30b5CeAB97c0cD41dDF5", "0x885163648ca7e6eda046551bA836056dCc7c56B7", "0xe0f213Dc2B5866036041749f5Fb30A79Ea2c96a3", "0x34cFbB3A8664F099228ff55a41BAB96B0b947419", "0x1D6179B28b09aB2B8cab3bbb4C4ab4e0d3b6674e", "0x4B9634a430Fb6edCD527c65C7733159ed716b400", "0x80f8784096F2A9e2F4f15daAC3623161e878AcBE", "0x7241239d34Cc5fB599A40EEb9F58Ea9767e178C6", "0x91715D86D18b6406989884F6E1aa16eCF870eB4f"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "getBuyPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "pIDxAddr_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "airDropTracker_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "round_", outputs: [{name: "plyr", type: "uint256"}, {name: "team", type: "uint256"}, {name: "end", type: "uint256"}, {name: "ended", type: "bool"}, {name: "strt", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "eth", type: "uint256"}, {name: "pot", type: "uint256"}, {name: "mask", type: "uint256"}, {name: "ico", type: "uint256"}, {name: "icoGen", type: "uint256"}, {name: "icoAvg", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}], name: "plyrNames_", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "fees_", outputs: [{name: "gen", type: "uint256"}, {name: "p3d", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "pIDxName_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], name: "rndTmEth_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rID_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_pID", type: "uint256"}], name: "getPlayerVaults", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentRoundInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "address"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], name: "plyrRnds_", outputs: [{name: "eth", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "mask", type: "uint256"}, {name: "ico", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "potSplit_", outputs: [{name: "gen", type: "uint256"}, {name: "p3d", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getTimeLeft", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_rID", type: "uint256"}, {name: "_eth", type: "uint256"}], name: "calcKeysReceived", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_keys", type: "uint256"}], name: "iWantXKeys", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "activated_", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "airDropPot_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "plyr_", outputs: [{name: "addr", type: "address"}, {name: "name", type: "bytes32"}, {name: "win", type: "uint256"}, {name: "gen", type: "uint256"}, {name: "aff", type: "uint256"}, {name: "lrnd", type: "uint256"}, {name: "laff", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_addr", type: "address"}], name: "getPlayerInfoByAddress", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}], name: "onWithdrawAndDistribute", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}], name: "onBuyAndDistribute", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}], name: "onReLoadAndDistribute", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "roundID", type: "uint256"}, {indexed: false, name: "amountAddedToPot", type: "uint256"}], name: "onPotSwapDeposit", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["onNewName(uint256,address,bytes32,bool,uint256,address,bytes32,uint256,uint256)", "onEndTx(uint256,uint256,bytes32,address,uint256,uint256,address,bytes32,uint256,uint256,uint256,uint256,uint256,uint256)", "onWithdraw(uint256,address,bytes32,uint256,uint256)", "onWithdrawAndDistribute(address,bytes32,uint256,uint256,uint256,address,bytes32,uint256,uint256,uint256,uint256)", "onBuyAndDistribute(address,bytes32,uint256,uint256,uint256,address,bytes32,uint256,uint256,uint256,uint256)", "onReLoadAndDistribute(address,bytes32,uint256,uint256,address,bytes32,uint256,uint256,uint256,uint256)", "onAffiliatePayout(uint256,address,bytes32,uint256,uint256,uint256,uint256)", "onPotSwapDeposit(uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xdd6176433ff5026bbce96b068584b7bbe3514227e72df9c630b749ae87e64442", "0x500e72a0e114930aebdbcb371ccdbf43922c49f979794b5de4257ff7e310c746", "0x8f36579a548bc439baa172a6521207464154da77f411e2da3db2f53affe6cc3a", "0x0bd0dba8ab932212fa78150cdb7b0275da72e255875967b5cad11464cf71bedc", "0xa7801a70b37e729a11492aad44fd3dba89b4149f0609dc0f6837bf9e57e2671a", "0x88261ac70d02d5ea73e54fa6da17043c974de1021109573ec1f6f57111c823dd", "0x590bbc0fc16915a85269a48f74783c39842b7ae9eceb7c295c95dbe8b3ec7331", "0x74b1d2f771e0eff1b2c36c38499febdbea80fe4013bdace4fc4b653322c2895c"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6663622 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6706644 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "FoMoGame", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "getBuyPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBuyPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "pIDxAddr_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pIDxAddr_(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "airDropTracker_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "airDropTracker_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "round_", outputs: [{name: "plyr", type: "uint256"}, {name: "team", type: "uint256"}, {name: "end", type: "uint256"}, {name: "ended", type: "bool"}, {name: "strt", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "eth", type: "uint256"}, {name: "pot", type: "uint256"}, {name: "mask", type: "uint256"}, {name: "ico", type: "uint256"}, {name: "icoGen", type: "uint256"}, {name: "icoAvg", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "round_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "plyrNames_", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyrNames_(uint256,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "fees_", outputs: [{name: "gen", type: "uint256"}, {name: "p3d", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fees_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "pIDxName_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pIDxName_(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "rndTmEth_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rndTmEth_(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rID_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rID_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_pID", value: random.range( maxRandom )}], name: "getPlayerVaults", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerVaults(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentRoundInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "address"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentRoundInfo()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "plyrRnds_", outputs: [{name: "eth", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "mask", type: "uint256"}, {name: "ico", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyrRnds_(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "potSplit_", outputs: [{name: "gen", type: "uint256"}, {name: "p3d", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "potSplit_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getTimeLeft", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTimeLeft()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_rID", value: random.range( maxRandom )}, {type: "uint256", name: "_eth", value: random.range( maxRandom )}], name: "calcKeysReceived", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calcKeysReceived(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_keys", value: random.range( maxRandom )}], name: "iWantXKeys", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "iWantXKeys(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "activated_", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "activated_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "airDropPot_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "airDropPot_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "plyr_", outputs: [{name: "addr", type: "address"}, {name: "name", type: "bytes32"}, {name: "win", type: "uint256"}, {name: "gen", type: "uint256"}, {name: "aff", type: "uint256"}, {name: "lrnd", type: "uint256"}, {name: "laff", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyr_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getPlayerInfoByAddress", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerInfoByAddress(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "FoMoGame", function( accounts ) {

	it( "TEST: FoMoGame(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6663622", timeStamp: "1541642392", hash: "0xf0f6ec817e64efb720974fb54f46686a2b9a5ac75d5878f047fcf49505e6367c", nonce: "27", blockHash: "0x516ec39ea949bab680d4e611417f54513f219975b42add7f8d54635d11b3cefb", transactionIndex: "1", from: "0x937328b032b7d9a972d5eb8cbdc0d3c9b0eb379d", to: 0, value: "0", gas: "6076165", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x8c6a9734", contractAddress: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", cumulativeGasUsed: "7949140", gasUsed: "6076165", confirmations: "1056311"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "FoMoGame", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = FoMoGame.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541642392 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = FoMoGame.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "86599076489407999" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: activate(  )", async function( ) {
		const txOriginal = {blockNumber: "6688391", timeStamp: "1541993189", hash: "0xf09d831efd0fc78c925a82c28bbcadf6fb3b85766b51a7e6145d01ded1c5fc66", nonce: "29", blockHash: "0xdd3858490d5d961b9ed39d6c766bf8316eed05ddcc56f8b1ea77521d8d40d42c", transactionIndex: "93", from: "0x937328b032b7d9a972d5eb8cbdc0d3c9b0eb379d", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "153759", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x0f15f4c0", contractAddress: "", cumulativeGasUsed: "5179829", gasUsed: "102506", confirmations: "1031542"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "activate", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activate()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541993189 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "86599076489407999" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6688398", timeStamp: "1541993318", hash: "0x81fdce42e6347f9c12bd8ea3334686699ae5d8366314bb632eb5db072439144a", nonce: "36", blockHash: "0x2769a22e0928befae8cab4709ef867d83a2266d85d2163fdb160e9df78c54616", transactionIndex: "138", from: "0x7c83097eafd71176ebf2c0352924fb74df929869", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "100000000000000000", gas: "787666", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "6781932", gasUsed: "525111", confirmations: "1031535"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541993318 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541993318000000000000001111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000003"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x7c83097eafd71176ebf2c0352924fb74df929869"}, {name: "ethIn", type: "uint256", value: "100000000000000000"}, {name: "keysBought", type: "uint256", value: "1331487990852298917347"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "65999999999999571"}, {name: "potAmount", type: "uint256", value: "20000000000000000"}, {name: "airDropPot", type: "uint256", value: "1000000000000000"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "997437156966767" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `ZBC`, \"0x00000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6688403", timeStamp: "1541993411", hash: "0x69c9784bcd23c26510d69d57271bba7e96bf88a761ba9c5f29d66b54909341d2", nonce: "0", blockHash: "0xeb0b15cc1bd8f209dbcde9c9ed8ab6fd1aa352c1686671951d7ee9ced248c1ab", transactionIndex: "116", from: "0x61f090f0b4f420256988e4149f2f132f97012b0d", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "10000000000000000", gas: "463815", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x685ffd8300000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000035a42430000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7740656", gasUsed: "309210", confirmations: "1031530"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `ZBC`}, {type: "bytes32", name: "_affCode", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `ZBC`, "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541993411 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "4"}, {name: "playerAddress", type: "address", value: "0x61f090f0b4f420256988e4149f2f132f97012b0d"}, {name: "playerName", type: "bytes32", value: "0x7a62630000000000000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "0"}, {name: "affiliateAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "affiliateName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1541993411"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "721769238833078" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6688406", timeStamp: "1541993440", hash: "0xcc3eb93beb8a01bafa1a5bf5d795acc48dbb10e78f9555e1df69cb28a6401422", nonce: "37", blockHash: "0x1f36a6cad2f36c85b3a7be8fb7e3f594fbe4496e52e1c9136ec9f1b19f0bf146", transactionIndex: "61", from: "0x7c83097eafd71176ebf2c0352924fb74df929869", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "1100000000000000000", gas: "330093", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5270222", gasUsed: "220062", confirmations: "1031527"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "1100000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541993440 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541993440000000000000002100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000003"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x7c83097eafd71176ebf2c0352924fb74df929869"}, {name: "ethIn", type: "uint256", value: "900000000000000000"}, {name: "keysBought", type: "uint256", value: "11821645582415765405614"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "593999999999993803"}, {name: "potAmount", type: "uint256", value: "180000000000000000"}, {name: "airDropPot", type: "uint256", value: "10000000000000000"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "997437156966767" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6688409", timeStamp: "1541993516", hash: "0x542ae4994dfa2fc7ed2461a5f20daa12a8f60470894af25f707e1a6766d3060c", nonce: "2", blockHash: "0x3fa661a6d9a776e9a5ffaaa947a09199db1d9cdd0f35e2031cc8780097d4c9bb", transactionIndex: "45", from: "0x852c99eff5f738036d3df058384fd37a7244edab", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "8486759899582313606", gas: "559084", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5117254", gasUsed: "372723", confirmations: "1031524"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "8486759899582313606" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541993516 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541993516000000000000003111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000005"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x852c99eff5f738036d3df058384fd37a7244edab"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "12811317712048308857343"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "659999999999985388"}, {name: "potAmount", type: "uint256", value: "200000000000000000"}, {name: "airDropPot", type: "uint256", value: "20000000000000000"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1049648996082458" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x7a6263000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6688414", timeStamp: "1541993581", hash: "0x2391aa3a471b764e612832a04f9c5c883cbfc6234f50f7747c75e677762e8161", nonce: "0", blockHash: "0xc1b93f0b8b570efb59b1503da01602ade06fe62bd32205d31ff8f4a3d815f863", transactionIndex: "80", from: "0xb820b87523a0768663b56d1448b1169305ff3ff4", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "2025249809708267183", gas: "614484", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xa65b37a17a626300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "3996856", gasUsed: "409656", confirmations: "1031519"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "2025249809708267183" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x7a62630000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_team", value: "2"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32,uint256)" ]( "0x7a62630000000000000000000000000000000000000000000000000000000000", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541993581 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541993581000000000000004111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000006"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xb820b87523a0768663b56d1448b1169305ff3ff4"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "12494841677297001764040"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "659999999999964718"}, {name: "potAmount", type: "uint256", value: "200000000000000000"}, {name: "airDropPot", type: "uint256", value: "30000000000000000"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[6,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "4"}, {name: "affiliateAddress", type: "address", value: "0x61f090f0b4f420256988e4149f2f132f97012b0d"}, {name: "affiliateName", type: "bytes32", value: "0x7a62630000000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "6"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "timeStamp", type: "uint256", value: "1541993581"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[6,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6688426", timeStamp: "1541993762", hash: "0x7dbefb4f1834bd6481853df19c9806a7d401d82001097e0a8b4a46643f648412", nonce: "2", blockHash: "0x7c7d5d3e4d5da070c57cdacb58db875b08b729c2bc76507618dd1a9d1b93d00e", transactionIndex: "77", from: "0x064fd3d828d84434b09327bf93615db20117b7a3", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "817904364004083499", gas: "527653", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5236941", gasUsed: "351769", confirmations: "1031507"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "817904364004083499" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541993762 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541993762000000000000005111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000007"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x064fd3d828d84434b09327bf93615db20117b7a3"}, {name: "ethIn", type: "uint256", value: "817904364004083499"}, {name: "keysBought", type: "uint256", value: "10000000000000001218934"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "539816880242647753"}, {name: "potAmount", type: "uint256", value: "163580872800816701"}, {name: "airDropPot", type: "uint256", value: "38179043640040834"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "10570536276953834712" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x7a6263000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6688493", timeStamp: "1541994676", hash: "0x173f47b889a5034d6f147ad0ac28c51efdb1403ab5b6d339b284208acfe1bf2a", nonce: "53", blockHash: "0x2c277cb429841e41228faa1726107185738c5a8aeb10b97cddcf559f833977c0", transactionIndex: "62", from: "0xc9207966f8be7f60390f66ec3ec936c75034acca", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "79134992388330784", gas: "571870", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xa65b37a17a626300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7387110", gasUsed: "366247", confirmations: "1031440"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "79134992388330784" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x7a62630000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_team", value: "2"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32,uint256)" ]( "0x7a62630000000000000000000000000000000000000000000000000000000000", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541994676 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541994676000000000000005111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000008"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xc9207966f8be7f60390f66ec3ec936c75034acca"}, {name: "ethIn", type: "uint256", value: "79134992388330784"}, {name: "keysBought", type: "uint256", value: "957511812818434320882"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "52229094976258545"}, {name: "potAmount", type: "uint256", value: "15826998477666158"}, {name: "airDropPot", type: "uint256", value: "38970393563924141"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[8,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "4"}, {name: "affiliateAddress", type: "address", value: "0x61f090f0b4f420256988e4149f2f132f97012b0d"}, {name: "affiliateName", type: "bytes32", value: "0x7a62630000000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "8"}, {name: "amount", type: "uint256", value: "7913499238833078"}, {name: "timeStamp", type: "uint256", value: "1541994676"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[8,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "612426103008445" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6688577", timeStamp: "1541995857", hash: "0x82230f2f42dbabe37e14793c8eda90edb103fed328d15472f3a64315d8c1041e", nonce: "27", blockHash: "0xccbcb4c3586b267f32726d4b2d9da3b5a380294e2ef6861d642bb3e2224a832d", transactionIndex: "76", from: "0x2176596ef0e65834d45e30b5ceab97c0cd41ddf5", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "1000944796740319102", gas: "559084", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4674925", gasUsed: "372723", confirmations: "1031356"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "1000944796740319102" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541995857 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541995857000000000000006111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000009"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x2176596ef0e65834d45e30b5ceab97c0cd41ddf5"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "11953830863830158975740"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "659999999999961288"}, {name: "potAmount", type: "uint256", value: "200000000000000000"}, {name: "airDropPot", type: "uint256", value: "48970393563924141"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1037144339694386591" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6688684", timeStamp: "1541997441", hash: "0xaf02411816a9c27c357eef13ce8b35c7b22226bb547168de8be1779d74953274", nonce: "3", blockHash: "0x2a289fc00a3fb4dcaeffcf1cad5a48638e64ccfa972739f9f45ea94dd0143d68", transactionIndex: "110", from: "0x852c99eff5f738036d3df058384fd37a7244edab", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "94185", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "4504351", gasUsed: "47790", confirmations: "1031249"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541997441 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[10,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "5"}, {name: "playerAddress", type: "address", value: "0x852c99eff5f738036d3df058384fd37a7244edab"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "8326300990288576854"}, {name: "timeStamp", type: "uint256", value: "1541997441"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[10,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1049648996082458" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6688756", timeStamp: "1541998547", hash: "0xa50dd109b69c82318dde48dc7a4385ae8823b125a887bed7624476a07bef3e75", nonce: "0", blockHash: "0x7efd7d5bdab031ae7ded666ddcd0b617a319c6ef14da9e68776fdeb26132be87", transactionIndex: "96", from: "0x885163648ca7e6eda046551ba836056dcc7c56b7", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "1000386810465525888", gas: "559084", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2517956", gasUsed: "372723", confirmations: "1031177"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1000386810465525888" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541998547 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201541998547000000000000007111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000010"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x885163648ca7e6eda046551ba836056dcc7c56b7"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "11695523900428582481541"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "659999999999959929"}, {name: "potAmount", type: "uint256", value: "200000000000000000"}, {name: "airDropPot", type: "uint256", value: "58970393563924141"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "93158028881443" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6688777", timeStamp: "1541998803", hash: "0x0b032fa890cb0cd9f7269fe665fd68da8a115dcd22573ba83a4909924b283ada", nonce: "7", blockHash: "0xb02e560fba05439a771c58d2096c84f85b0b4ff6314aa12a3219d0244c569b09", transactionIndex: "132", from: "0x852c99eff5f738036d3df058384fd37a7244edab", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "116685", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7692197", gasUsed: "62790", confirmations: "1031156"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541998803 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "5"}, {name: "playerAddress", type: "address", value: "0x852c99eff5f738036d3df058384fd37a7244edab"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "115723472305373352"}, {name: "timeStamp", type: "uint256", value: "1541998803"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1049648996082458" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6688778", timeStamp: "1541998816", hash: "0xf3a8054106ac3cce10c19c1705918805b4bd2ab645a96b3b3e7e0b06affad74d", nonce: "4", blockHash: "0xe5991570a31ded6e5792508f6ae353fe7769977943c99d92b26510fff7425c9f", transactionIndex: "120", from: "0x61f090f0b4f420256988e4149f2f132f97012b0d", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "77604", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "5055873", gasUsed: "36736", confirmations: "1031155"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541998816 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "4"}, {name: "playerAddress", type: "address", value: "0x61f090f0b4f420256988e4149f2f132f97012b0d"}, {name: "playerName", type: "bytes32", value: "0x7a62630000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "107913499238833078"}, {name: "timeStamp", type: "uint256", value: "1541998816"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "721769238833078" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6688778", timeStamp: "1541998816", hash: "0x404eb90f90d0ad9017f81cbd6450f3d1ddc5ea2a9d9763554c6bbbd70bc951d6", nonce: "1", blockHash: "0xe5991570a31ded6e5792508f6ae353fe7769977943c99d92b26510fff7425c9f", transactionIndex: "137", from: "0x885163648ca7e6eda046551ba836056dcc7c56b7", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "94185", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "5528366", gasUsed: "47790", confirmations: "1031155"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541998816 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "10"}, {name: "playerAddress", type: "address", value: "0x885163648ca7e6eda046551ba836056dcc7c56b7"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "106031418351195628"}, {name: "timeStamp", type: "uint256", value: "1541998816"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "93158028881443" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6689038", timeStamp: "1542002293", hash: "0xb04d63ad7e2f83214daa799ea78603529ef457892cb2467865b3548e45c87230", nonce: "38", blockHash: "0x5971949f5b83ffd7cc365e80529e03d8428c6377af3f838429b677e014ed1234", transactionIndex: "49", from: "0x7c83097eafd71176ebf2c0352924fb74df929869", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "94185", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2109597", gasUsed: "47790", confirmations: "1030895"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1542002293 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "3"}, {name: "playerAddress", type: "address", value: "0x7c83097eafd71176ebf2c0352924fb74df929869"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "1840751760085156480"}, {name: "timeStamp", type: "uint256", value: "1542002293"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "997437156966767" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6689388", timeStamp: "1542007272", hash: "0xa81027f02c77ded89cf9a5b6df03bb2fba033a39ee1aa3d7b298509e6e08defb", nonce: "0", blockHash: "0xc414d11cd1da7fcaa330e43fe3c262efa9ea81ef4671c1b42abdff7327ad95dd", transactionIndex: "68", from: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "43227785901538425", gas: "516471", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4876445", gasUsed: "344314", confirmations: "1030545"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "43227785901538425" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1542007272 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542007272000000000000007111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000011"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3"}, {name: "ethIn", type: "uint256", value: "43227785901538425"}, {name: "keysBought", type: "uint256", value: "500000000000001163420"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "28530338694988562"}, {name: "potAmount", type: "uint256", value: "8645557180307686"}, {name: "airDropPot", type: "uint256", value: "59402671422939525"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "500226704195655" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6689583", timeStamp: "1542010114", hash: "0x265883503ae5b860742dcfc691853d77d7caace4ba85455e63b788c823cc3942", nonce: "1", blockHash: "0x83052482f535feb4d7b553b00e8d836bc7536b2d07f276dbd12726a780f0b9d4", transactionIndex: "41", from: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "190666320466768728", gas: "278521", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5818300", gasUsed: "185681", confirmations: "1030350"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "190666320466768728" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1542010114 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542010114000000000000008100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000011"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3"}, {name: "ethIn", type: "uint256", value: "190666320466768728"}, {name: "keysBought", type: "uint256", value: "2200000000000001155827"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "125839771508016990"}, {name: "potAmount", type: "uint256", value: "38133264093353747"}, {name: "airDropPot", type: "uint256", value: "61309334627607212"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "500226704195655" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6691103", timeStamp: "1542031804", hash: "0x0c80c7876ba513d7ee1675194a65a00ae92c4a3c6faebcdb019a94994f12c31f", nonce: "0", blockHash: "0xdac56f260396c4e70a5fb1b3a62c20b31055b16c3d51a268478183a2928776ca", transactionIndex: "191", from: "0x34cfbb3a8664f099228ff55a41bab96b0b947419", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "39652409472196104", gas: "200000", gasPrice: "1000000000", isError: "1", txreceipt_status: "0", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7222896", gasUsed: "200000", confirmations: "1028830"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "39652409472196104" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "39592100000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6693964", timeStamp: "1542071154", hash: "0x35ffc5efc2c61e7a095e65ef553943f9fb53ea3863aba38942a7ff490eb317f3", nonce: "2", blockHash: "0x9a903d236aeb73fdd53492056d9e9ba54d5f3b005cd8f3f30a9d8aa18375324b", transactionIndex: "117", from: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "8684619680307765", gas: "267243", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6231192", gasUsed: "178162", confirmations: "1025969"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "8684619680307765" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1542071154 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542071154000000000000008100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000011"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3"}, {name: "ethIn", type: "uint256", value: "8684619680307765"}, {name: "keysBought", type: "uint256", value: "100000000000001152390"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "5731848988967585"}, {name: "potAmount", type: "uint256", value: "1736923936061554"}, {name: "airDropPot", type: "uint256", value: "61396180824410289"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "500226704195655" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6694281", timeStamp: "1542075558", hash: "0xdbd7053d13f08dc739667f49731e50b40f7d135e8b6727dc0e8653198184c9af", nonce: "3", blockHash: "0x51d3a6e504ec95d34bdb65eb50406fdf484a238d995714867ebd10858a0a0367", transactionIndex: "30", from: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "3474285372123166", gas: "267243", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6734574", gasUsed: "178162", confirmations: "1025652"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "3474285372123166" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1542075558 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542075558000000000000008100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000011"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3"}, {name: "ethIn", type: "uint256", value: "3474285372123166"}, {name: "keysBought", type: "uint256", value: "40000000000001151605"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "2293028345567489"}, {name: "potAmount", type: "uint256", value: "694857074424634"}, {name: "airDropPot", type: "uint256", value: "61430923678131520"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "500226704195655" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `coco`, \"0x0000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6695141", timeStamp: "1542087600", hash: "0xdc464b20bb8ce86e00e3506d01e59125ca2bcc1a399613a40e6d9a7d728162cd", nonce: "0", blockHash: "0xfa08934d1d2605401eab9cd576870c1c8f0fddef3dd4903524deae0da65dec91", transactionIndex: "41", from: "0x1d6179b28b09ab2b8cab3bbb4c4ab4e0d3b6674e", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "10000000000000000", gas: "471862", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x685ffd830000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000004636f636f00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5337415", gasUsed: "314575", confirmations: "1024792"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `coco`}, {type: "bytes32", name: "_affCode", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `coco`, "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1542087600 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "12"}, {name: "playerAddress", type: "address", value: "0x1d6179b28b09ab2b8cab3bbb4c4ab4e0d3b6674e"}, {name: "playerName", type: "bytes32", value: "0x636f636f00000000000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "0"}, {name: "affiliateAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "affiliateName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1542087600"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "158514631321823" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `newbee`, \"0x00000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6695267", timeStamp: "1542089704", hash: "0x887355add05dcb23b38900ea39db7e3861a2244f71c08002a67f1768518bd52d", nonce: "54", blockHash: "0xe0167fb831fcca42edf382f8f587805abb792b69ce7a5876c192cdfd826f4bbb", transactionIndex: "62", from: "0xc9207966f8be7f60390f66ec3ec936c75034acca", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "10000000000000000", gas: "356599", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x685ffd8300000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000066e65776265650000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7248857", gasUsed: "222733", confirmations: "1024666"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `newbee`}, {type: "bytes32", name: "_affCode", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `newbee`, "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1542089704 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "8"}, {name: "playerAddress", type: "address", value: "0xc9207966f8be7f60390f66ec3ec936c75034acca"}, {name: "playerName", type: "bytes32", value: "0x6e65776265650000000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: false}, {name: "affiliateID", type: "uint256", value: "0"}, {name: "affiliateAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "affiliateName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1542089704"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "612426103008445" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6695276", timeStamp: "1542089788", hash: "0xc230ccc947288c596a76cd59140248d231b65c90bf8b6d82d86aef163a4b86f7", nonce: "55", blockHash: "0x208623974022fd475cf94f1d311a52711c0904ebf922f3c4cb9b76926ae7d3ef", transactionIndex: "49", from: "0xc9207966f8be7f60390f66ec3ec936c75034acca", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "13899641488492364", gas: "274855", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "3174692", gasUsed: "183237", confirmations: "1024657"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "13899641488492364" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1542089788 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542089788000000000000008100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000008"}, {name: "playerName", type: "bytes32", value: "0x6e65776265650000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xc9207966f8be7f60390f66ec3ec936c75034acca"}, {name: "ethIn", type: "uint256", value: "13899641488492364"}, {name: "keysBought", type: "uint256", value: "160000000000001151931"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "9173763382390421"}, {name: "potAmount", type: "uint256", value: "2779928297698474"}, {name: "airDropPot", type: "uint256", value: "61569920093016443"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "612426103008445" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6695365", timeStamp: "1542090997", hash: "0xa2950c72317615c8d2cae983d885f49c30bc87a43bf34b79a975e0fbfcef2014", nonce: "56", blockHash: "0xeaddaebed6246bef8281c188293368493619df22e431bb12fabea2d1243ac677", transactionIndex: "176", from: "0xc9207966f8be7f60390f66ec3ec936c75034acca", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "26159541253351172", gas: "267243", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7808621", gasUsed: "178162", confirmations: "1024568"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "26159541253351172" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1542090997 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542090997000000000000008100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000008"}, {name: "playerName", type: "bytes32", value: "0x6e65776265650000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xc9207966f8be7f60390f66ec3ec936c75034acca"}, {name: "ethIn", type: "uint256", value: "26159541253351172"}, {name: "keysBought", type: "uint256", value: "301000000000001155582"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "17265297227190412"}, {name: "potAmount", type: "uint256", value: "5231908250670235"}, {name: "airDropPot", type: "uint256", value: "61831515505549954"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "612426103008445" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6695783", timeStamp: "1542096683", hash: "0x4e8024f4a9856238f9dc3fd9df3e8c629274713b801b5ce2c033716d29f13000", nonce: "57", blockHash: "0x3ba82fd4552ffb16220561003d60aa7a5eb140f7d02d16b4d45d9b183249f78a", transactionIndex: "59", from: "0xc9207966f8be7f60390f66ec3ec936c75034acca", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "52274525450524167", gas: "267243", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2550647", gasUsed: "178162", confirmations: "1024150"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "52274525450524167" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1542096683 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542096683000000000000008100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000008"}, {name: "playerName", type: "bytes32", value: "0x6e65776265650000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xc9207966f8be7f60390f66ec3ec936c75034acca"}, {name: "ethIn", type: "uint256", value: "52274525450524167"}, {name: "keysBought", type: "uint256", value: "601000000000001154319"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "34501186797327088"}, {name: "potAmount", type: "uint256", value: "10454905090104834"}, {name: "airDropPot", type: "uint256", value: "62354260760055195"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "612426103008445" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6697828", timeStamp: "1542126849", hash: "0xd20be9c67a00c5dcb0daf9080d8a439bcca8225a7992c36a59c718e8328067e2", nonce: "1", blockHash: "0x63ec2ed99d10ed11e1e9d6ad854865fdc388089d892a81f7c0eee26ce784bf31", transactionIndex: "14", from: "0x4b9634a430fb6edcd527c65c7733159ed716b400", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "218053773257691726", gas: "527557", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2442472", gasUsed: "351705", confirmations: "1022105"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "218053773257691726" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542126849 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542126849000000000000009111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000013"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x4b9634a430fb6edcd527c65c7733159ed716b400"}, {name: "ethIn", type: "uint256", value: "218053773257691726"}, {name: "keysBought", type: "uint256", value: "2500000000000001155265"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "143915490350018557"}, {name: "potAmount", type: "uint256", value: "43610754651538346"}, {name: "airDropPot", type: "uint256", value: "64534798492632112"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "168114387455784" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6699841", timeStamp: "1542154428", hash: "0xd005b613c86ca5c0eda804cafd8bfefe2b24cd37a5d01a442bd664e930126a9e", nonce: "1", blockHash: "0x5610e323634e01c111c6e9cd66e786aebcfd09d84aabe9f8d9ff0552e287aed9", transactionIndex: "74", from: "0x1d6179b28b09ab2b8cab3bbb4c4ab4e0d3b6674e", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "86932368678177", gas: "373762", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6026059", gasUsed: "237414", confirmations: "1020092"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "86932368678177" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542154428 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542154428000000000000009010"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000012"}, {name: "playerName", type: "bytes32", value: "0x636f636f00000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x1d6179b28b09ab2b8cab3bbb4c4ab4e0d3b6674e"}, {name: "ethIn", type: "uint256", value: "86932368678177"}, {name: "keysBought", type: "uint256", value: "994457240880534336"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "57375363269965"}, {name: "potAmount", type: "uint256", value: "17386473735637"}, {name: "airDropPot", type: "uint256", value: "64535667816318893"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "158514631321823" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6700269", timeStamp: "1542160400", hash: "0x232bb1f3c86d8efcf76c58f84373f63d979ee90a600839f31ffa3dc3f4a7a454", nonce: "2", blockHash: "0x8dcd6a8bd0e79142928835b7cc500a72787581f427b41d8b7dedc2b67d7a65a3", transactionIndex: "66", from: "0x885163648ca7e6eda046551ba836056dcc7c56b7", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "116685", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "3369793", gasUsed: "62790", confirmations: "1019664"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542160400 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "10"}, {name: "playerAddress", type: "address", value: "0x885163648ca7e6eda046551ba836056dcc7c56b7"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "55683785196810057"}, {name: "timeStamp", type: "uint256", value: "1542160400"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "93158028881443" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6702777", timeStamp: "1542197058", hash: "0x67f303322bfe05d2e87f32c7b872afca1f1c734a585da7ac59bde0d31c9ca5e7", nonce: "1", blockHash: "0x4db1553761a74c93fd4579deca8b54547c4e9f5559adca9834c17c82fad69278", transactionIndex: "78", from: "0x80f8784096f2a9e2f4f15daac3623161e878acbe", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "8742478968702154", gas: "100000", gasPrice: "12000000000", isError: "1", txreceipt_status: "0", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4491502", gasUsed: "100000", confirmations: "1017156"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "8742478968702154" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "70120000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6702788", timeStamp: "1542197211", hash: "0x7d434eda135592b2097f1f1a6dd2fee1467017ba7788dfbc11dd5ae05358b95a", nonce: "2", blockHash: "0xd53a1a94ed7029a5c9c4498752441f23a13f94436b040b4802a5b537221bc1fe", transactionIndex: "73", from: "0x80f8784096f2a9e2f4f15daac3623161e878acbe", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "8742478968702154", gas: "210000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "3538960", gasUsed: "210000", confirmations: "1017145"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "8742478968702154" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "70120000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6702793", timeStamp: "1542197266", hash: "0x7c4abf5eb6c9b9c4d206edf4ae6e798401eb9393d741f53a23f3222dcfef6141", nonce: "4", blockHash: "0xd3c20b26b4ae63af7e2d2ab8e161cf5b0b9d76425a7441e843cb9bafe60fd300", transactionIndex: "66", from: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "8742478968702154", gas: "210000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4198454", gasUsed: "183237", confirmations: "1017140"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "8742478968702154" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542197266 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542197266000000000000009100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000011"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3"}, {name: "ethIn", type: "uint256", value: "8742478968702154"}, {name: "keysBought", type: "uint256", value: "100000000000001146291"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "5770036119331401"}, {name: "potAmount", type: "uint256", value: "1748495793740432"}, {name: "airDropPot", type: "uint256", value: "64623092606005914"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "500226704195655" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6702798", timeStamp: "1542197356", hash: "0x0095034c1c2f55a6b181b2b6459236821b3bff4b6a0647630d2b3cf8a9058fdf", nonce: "0", blockHash: "0x359e2d2538e3745629c4a9cdf1be039d2cde89032e1fc72f56301b85d076c0f2", transactionIndex: "36", from: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "43735832343510369", gas: "210000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2000358", gasUsed: "210000", confirmations: "1017135"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "43735832343510369" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "658209574107725" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6702805", timeStamp: "1542197487", hash: "0x6304ff9b8146fc79f7fe2f3f0750cd3672c92e41f08123497ce9ba3c615a2231", nonce: "1", blockHash: "0x9fd4092b69ef30aafdcec525d1405ac929e9746169c7ba07d3bb706f30b75459", transactionIndex: "100", from: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "43735832343510369", gas: "210000", gasPrice: "12000000000", isError: "1", txreceipt_status: "0", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4789328", gasUsed: "210000", confirmations: "1017128"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "43735832343510369" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "658209574107725" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6702809", timeStamp: "1542197546", hash: "0x726775f3fe81442126bcdf1c8add92b459e073f8ca0d60629a17d023ff722562", nonce: "2", blockHash: "0x6e6e9565103634fc82b3e636dd00c436019fa6ce22bec06dc2d7da4d4b036535", transactionIndex: "86", from: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "43735832343510369", gas: "516375", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5389191", gasUsed: "344250", confirmations: "1017124"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "43735832343510369" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542197546 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542197546000000000000009111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000014"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6"}, {name: "ethIn", type: "uint256", value: "43735832343510369"}, {name: "keysBought", type: "uint256", value: "500000000000001143018"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "28865649346684234"}, {name: "potAmount", type: "uint256", value: "8747166468702075"}, {name: "airDropPot", type: "uint256", value: "65060450929441017"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "658209574107725" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6702816", timeStamp: "1542197622", hash: "0xc7fcaef6be7dbe47f94043cf04b95cf291c9acdadb1b8a058e073a38b90808e1", nonce: "3", blockHash: "0x2b50184e5ce28f9819b31872a19a8958fc64d8c3c8c0c9b5ab9b7ca58b47aaa5", transactionIndex: "45", from: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "43774894843510370", gas: "267243", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2387942", gasUsed: "178162", confirmations: "1017117"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "43774894843510370" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542197622 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542197622000000000000009100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000014"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6"}, {name: "ethIn", type: "uint256", value: "43774894843510370"}, {name: "keysBought", type: "uint256", value: "500000000000001152397"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "28891430596647469"}, {name: "potAmount", type: "uint256", value: "8754978968702075"}, {name: "airDropPot", type: "uint256", value: "65498199877876120"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "658209574107725" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6702873", timeStamp: "1542198305", hash: "0x974f8213e97478d6e7577d940917d0ccf23beb311ea214a189b34499944e7e4f", nonce: "5", blockHash: "0xfa8d104e45e4c87987df0ece603f07de9124801a979aad9f8110b255362abd56", transactionIndex: "36", from: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "8759666468702154", gas: "274855", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2197820", gasUsed: "183237", confirmations: "1017060"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "8759666468702154" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1542198305 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542198305000000000000009100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000011"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3"}, {name: "ethIn", type: "uint256", value: "8759666468702154"}, {name: "keysBought", type: "uint256", value: "100000000000001143428"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "5781379869304079"}, {name: "potAmount", type: "uint256", value: "1751933293740432"}, {name: "airDropPot", type: "uint256", value: "65585796542563141"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "500226704195655" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `eric`, \"0x636f636f00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6702967", timeStamp: "1542199648", hash: "0xa559720f477f7b3420fcaacb6c18c3a8417e51c8395a8b574c0a575dbb56b11d", nonce: "58", blockHash: "0x2644332ee1019afad5d6aa6ca647460287855d342f6007b937f913fff0821e6a", transactionIndex: "117", from: "0x91715d86d18b6406989884f6e1aa16ecf870eb4f", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "10000000000000000", gas: "533826", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x685ffd830000000000000000000000000000000000000000000000000000000000000060636f636f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000046572696300000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7025671", gasUsed: "355581", confirmations: "1016966"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `eric`}, {type: "bytes32", name: "_affCode", value: "0x636f636f00000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `eric`, "0x636f636f00000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542199648 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "15"}, {name: "playerAddress", type: "address", value: "0x91715d86d18b6406989884f6e1aa16ecf870eb4f"}, {name: "playerName", type: "bytes32", value: "0x6572696300000000000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "12"}, {name: "affiliateAddress", type: "address", value: "0x1d6179b28b09ab2b8cab3bbb4c4ab4e0d3b6674e"}, {name: "affiliateName", type: "bytes32", value: "0x636f636f00000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1542199648"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "8957824230184209" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x657269630000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6703001", timeStamp: "1542200075", hash: "0x7d9ae2f4d4fadcc00494a72ccd36b7c6607be073b73da3900b65f9ca1a73c86a", nonce: "59", blockHash: "0xee9ab907d1099dd19a79beebae5437f86fc0cf32f987ed7eddea3d0ea115c16c", transactionIndex: "118", from: "0x91715d86d18b6406989884f6e1aa16ecf870eb4f", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "8848849149014175", gas: "398703", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xa65b37a165726963000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6682187", gasUsed: "265802", confirmations: "1016932"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "8848849149014175" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x6572696300000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_team", value: "2"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32,uint256)" ]( "0x6572696300000000000000000000000000000000000000000000000000000000", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542200075 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542200075000000000000009110"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000015"}, {name: "playerName", type: "bytes32", value: "0x6572696300000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x91715d86d18b6406989884f6e1aa16ecf870eb4f"}, {name: "ethIn", type: "uint256", value: "8848849149014175"}, {name: "keysBought", type: "uint256", value: "101000000000001148285"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "5840240438282810"}, {name: "potAmount", type: "uint256", value: "1769769829802836"}, {name: "airDropPot", type: "uint256", value: "65674285034053282"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[38,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "12"}, {name: "affiliateAddress", type: "address", value: "0x1d6179b28b09ab2b8cab3bbb4c4ab4e0d3b6674e"}, {name: "affiliateName", type: "bytes32", value: "0x636f636f00000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "15"}, {name: "amount", type: "uint256", value: "884884914901417"}, {name: "timeStamp", type: "uint256", value: "1542200075"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[38,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "8957824230184209" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6704902", timeStamp: "1542226756", hash: "0x2edaf3ceda13378e9c179c2108dc6dd32780cef05aa6f8b39c9ecd33dba37d85", nonce: "4", blockHash: "0xa2c88da26dd225da7e70614d96dc28479bd0bd89c971611a89279739e1b7cb15", transactionIndex: "61", from: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "876210396870306", gas: "210000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6517252", gasUsed: "183237", confirmations: "1015031"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "876210396870306" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542226756 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542226756000000000000009100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000014"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6"}, {name: "ethIn", type: "uint256", value: "876210396870306"}, {name: "keysBought", type: "uint256", value: "10000000000001148268"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "578298861921317"}, {name: "potAmount", type: "uint256", value: "175242079374063"}, {name: "airDropPot", type: "uint256", value: "65683047138021985"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "658209574107725" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6706301", timeStamp: "1542246947", hash: "0xc1f3c473c350cadc92d62ea216139551858370bd312ce045eb66c832ded95156", nonce: "5", blockHash: "0x1adcf5316ba80b7bbe9c827b48be68ab9c61b38bc9b440d73ee09b9e71f16951", transactionIndex: "112", from: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "116685", gasPrice: "12000000000", isError: "1", txreceipt_status: "0", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "6312963", gasUsed: "116685", confirmations: "1013632"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "658209574107725" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6706338", timeStamp: "1542247501", hash: "0x6fc38c18cba92131ae6097b745665604cdf6b0eef712824f6a4371088880c5d3", nonce: "6", blockHash: "0x71a22272259377e4f5fb10e6ff6802dd85dd9b3db190e8e508a9179a66ed163d", transactionIndex: "56", from: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "344331", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "4824825", gasUsed: "199554", confirmations: "1013595"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1542247501 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}], name: "onWithdrawAndDistribute", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdrawAndDistribute", events: [{name: "playerAddress", type: "address", value: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "637817222348091214"}, {name: "compressedData", type: "uint256", value: "1542247501001542246904000000"}, {name: "compressedIDs", type: "uint256", value: "1400000000200000000000000014"}, {name: "winnerAddr", type: "address", value: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "630557252525381859"}, {name: "newPot", type: "uint256", value: "131366094276173389"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "525464377104432715"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "658209574107725" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[0], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6706344", timeStamp: "1542247606", hash: "0xbd62c00c502fba705178d6ebbfa1c95464b0439b107295661cc00870888e25e1", nonce: "7", blockHash: "0xf5187d0840503193c8c3baff4f2cf9dba7c3fedce7039d104577901690ca1caf", transactionIndex: "137", from: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "750007031250100", gas: "473416", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x98a0871d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6659390", gasUsed: "315611", confirmations: "1013589"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "750007031250100" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[0]}, {type: "uint256", name: "_team", value: "2"}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address,uint256)" ]( addressList[0], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1542247606 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "airDropPot", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "201542247606000000000000009110"}, {name: "compressedIDs", type: "uint256", value: "20000000000000000000000000000000000000000000000000014"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6"}, {name: "ethIn", type: "uint256", value: "750007031250100"}, {name: "keysBought", type: "uint256", value: "10000000000001333306"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "495004640625065"}, {name: "potAmount", type: "uint256", value: "150001406250020"}, {name: "airDropPot", type: "uint256", value: "65690547208334486"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "658209574107725" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6706401", timeStamp: "1542248324", hash: "0x65981c6d3e910502d140c554cc99d69260a12314d1f4d7ea6ac1c1dd14db39f5", nonce: "6", blockHash: "0x9e1e7d726e8edbb83326776c911c62d674850a65a3347ce3defc7bbf46a2199a", transactionIndex: "38", from: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "116685", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2357051", gasUsed: "62790", confirmations: "1013532"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1542248324 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "11"}, {name: "playerAddress", type: "address", value: "0xe0f213dc2b5866036041749f5fb30a79ea2c96a3"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "34940138562338047"}, {name: "timeStamp", type: "uint256", value: "1542248324"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "500226704195655" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6706419", timeStamp: "1542248598", hash: "0xfa2bb1984c0da092adb3d6b32994c3fc2841dd4d8e60898c8b7220ba230db9dc", nonce: "3", blockHash: "0x8cd2cb54ad6e89b40dbf49060083a008f7f43655222e819201544282cc69b396", transactionIndex: "66", from: "0x4b9634a430fb6edcd527c65c7733159ed716b400", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "116685", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "3505064", gasUsed: "62790", confirmations: "1013514"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1542248598 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "13"}, {name: "playerAddress", type: "address", value: "0x4b9634a430fb6edcd527c65c7733159ed716b400"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "23148312645147510"}, {name: "timeStamp", type: "uint256", value: "1542248598"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "168114387455784" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6706609", timeStamp: "1542251223", hash: "0x46ed09aaf2c84dd89f4b45cdca419bf238e050a09ebff8809ebca77a2eb218de", nonce: "3", blockHash: "0xd94dcba40bd784ec0c81d11f463634dd7806081673dc52d57fa6dbede2ec9e2b", transactionIndex: "112", from: "0x064fd3d828d84434b09327bf93615db20117b7a3", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "116685", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7109559", gasUsed: "62790", confirmations: "1013324"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1542251223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "7"}, {name: "playerAddress", type: "address", value: "0x064fd3d828d84434b09327bf93615db20117b7a3"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "441924819097220054"}, {name: "timeStamp", type: "uint256", value: "1542251223"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "10570536276953834712" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6706624", timeStamp: "1542251415", hash: "0x45717456cfcdc5c1ac0aae9fcbd0650d122fa8411dca8612726d6bf910c29404", nonce: "4", blockHash: "0x1d2753f5c70b1c74f55f51da1d9b77738694c3a44a985f87849b0bbabde4ceef", transactionIndex: "88", from: "0x064fd3d828d84434b09327bf93615db20117b7a3", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "43264", gasPrice: "8000000000", isError: "1", txreceipt_status: "0", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7970620", gasUsed: "43264", confirmations: "1013309"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "10570536276953834712" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6706628", timeStamp: "1542251464", hash: "0xc06f09d14ba584591b71f85c6f04440044caa4be2eb4e28ce95d7b46efa5ae67", nonce: "5", blockHash: "0x277ae9d826883a26d865b133f24f2570c223ab738db5d6d6de00b0f0ddc5082a", transactionIndex: "88", from: "0x064fd3d828d84434b09327bf93615db20117b7a3", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "116685", gasPrice: "8000000000", isError: "1", txreceipt_status: "0", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "6224260", gasUsed: "116685", confirmations: "1013305"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "10570536276953834712" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6706641", timeStamp: "1542251576", hash: "0x42ba8717fc8ae0d4b5706f42a32807b489036062c3a86eda3f602de4f00034a2", nonce: "40", blockHash: "0x53c66b60d85808d32077ddc4c4d41b86dab0fa28e24d95d86dc3cff8cc2ad84c", transactionIndex: "66", from: "0x7c83097eafd71176ebf2c0352924fb74df929869", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "344331", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7110298", gasUsed: "214554", confirmations: "1013292"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1542251576 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "P3DAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}], name: "onWithdrawAndDistribute", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdrawAndDistribute", events: [{name: "playerAddress", type: "address", value: "0x7c83097eafd71176ebf2c0352924fb74df929869"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "160583179747991562"}, {name: "compressedData", type: "uint256", value: "1542251576001542251401000000"}, {name: "compressedIDs", type: "uint256", value: "1400000000200000000000000003"}, {name: "winnerAddr", type: "address", value: "0x7241239d34cc5fb599a40eeb9f58ea9767e178c6"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "63127725927563236"}, {name: "newPot", type: "uint256", value: "13151609568242352"}, {name: "P3DAmount", type: "uint256", value: "0"}, {name: "genAmount", type: "uint256", value: "52606438272969354"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "997437156966767" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6706644", timeStamp: "1542251614", hash: "0x393367a95d329620f6c6cc73f7594600a423bc2510f192486b83d46c3020cb9c", nonce: "1", blockHash: "0x8eb10a4aa7031af4859e3afb102b97239b0042c31ef9823f4f7978a60e449ea2", transactionIndex: "131", from: "0xb820b87523a0768663b56d1448b1169305ff3ff4", to: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf", value: "0", gas: "321831", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "5088038", gasUsed: "47790", confirmations: "1013289"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1542251614 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[49,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "6"}, {name: "playerAddress", type: "address", value: "0xb820b87523a0768663b56d1448b1169305ff3ff4"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "1791851876389970359"}, {name: "timeStamp", type: "uint256", value: "1542251614"}], address: "0x58db9e7a4afca731d824eeefa55ce37666aa3eaf"}] ;
		console.error( "eventResultOriginal[49,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "505900266977679386" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
