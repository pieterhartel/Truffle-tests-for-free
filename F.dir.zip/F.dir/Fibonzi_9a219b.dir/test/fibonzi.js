const Fibonzi = artifacts.require( "./Fibonzi.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Fibonzi" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xc352ADd7Ad8CaC8baa839d8C88e7e9d7Df9a219B", "0xd229dbDa0D510d3937604a0EDf254004b495a9F0", "0x46F0b48B3d61Ddb65893Dd0978209fAb5AEF8d7D", "0xc43c1C4523EF357FD47121C1fa3c3255A1587AFC", "0xD5682eAeDFB9084788fD6C53cD59D875cfccC3a3", "0xB7EA04e597b9dd087B649913F49E5D57D9Dac03b", "0x7AE3e1C0f679A1Fb1CE369Fea21A2c3429966FAE", "0x5Dc31201f1167ec3f51347b29C719D322457FE8A"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "fibonacciIndex", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getPlayersFibokens", outputs: [{name: "", type: "uint256[]"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getPoolPrices", outputs: [{name: "", type: "uint256[]"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "playersList", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "fibokenCreatedCount", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getFibonziPlayers", outputs: [{name: "", type: "address[]"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "fibokenUsedCount", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "playersCount", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getPoolIds", outputs: [{name: "", type: "uint8[]"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "poolsToCreate", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getPlayersBalances", outputs: [{name: "", type: "uint256[]"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "poolCount", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getPoolOwners", outputs: [{name: "", type: "address[]"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "transactionsCount", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerCreated", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolCreated", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["PlayerCreated(address,uint256)", "PlayerBalance(address,uint256,uint256)", "FibokenCreated(uint8,address,uint256)", "FibokenUsed(uint8,address,uint256)", "PoolCreated(uint8,uint256,uint256)", "PoolJoined(uint8,address,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xb31ba5904c24da7a4eeed78a7e073540fbf64788e158b6f3f55fae6d475ced95", "0xa9f844a8edeecd163f173529afc48454c2de63ddf49eea5c20c89345982a6297", "0xdf4879626a41c3caf302065ed5748ef28361a2ef06350568d691b9571fe1062e", "0x6be050d2f9173d512d058b49f0ce4246b94817d6517cd3e581657ce75a1e4dff", "0xe21f44f416893fb2606f870ee2fa50025879fd7667ed7ea6198b974a040e3f92", "0x050df9f7887afb3b95db34241d555e44fe1c9348fa8b7f007ac5b05fba0208e1"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4224860 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4235631 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Fibonzi", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "fibonacciIndex", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fibonacciIndex()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getPlayersFibokens", outputs: [{name: "", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayersFibokens()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getPoolPrices", outputs: [{name: "", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPoolPrices()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "playersList", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "playersList(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "fibokenCreatedCount", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fibokenCreatedCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getFibonziPlayers", outputs: [{name: "", type: "address[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFibonziPlayers()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "fibokenUsedCount", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fibokenUsedCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "playersCount", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "playersCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getPoolIds", outputs: [{name: "", type: "uint8[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPoolIds()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "poolsToCreate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "poolsToCreate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getPlayersBalances", outputs: [{name: "", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayersBalances()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "poolCount", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "poolCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getPoolOwners", outputs: [{name: "", type: "address[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPoolOwners()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "transactionsCount", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "transactionsCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Fibonzi", function( accounts ) {

	it( "TEST: Fibonzi(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4224860", blockHash: "0xd66a5584f597a7b13497f8a1f5cde9cc562ccb0fa352f5c93ade5edf1f621e7e", timeStamp: "1504219666", hash: "0x13fce9b51b4c3d8b8df20f66869aa0a1360240062deb99a3c1fdd34c488403f4", nonce: "42", transactionIndex: "68", from: "0xd229dbda0d510d3937604a0edf254004b495a9f0", to: 0, value: "0", gas: "3000000", gasPrice: "5000000000", input: "0x00dff399", contractAddress: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", cumulativeGasUsed: "5713173", txreceipt_status: "", gasUsed: "2317752", confirmations: "3479060", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Fibonzi", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Fibonzi.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1504219666 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Fibonzi.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerCreated", type: "event"} ;
		console.error( "eventCallOriginal[0,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PlayerCreated", events: [{name: "wallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "timestamp", type: "uint256", value: "1504219666"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[0,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolCreated", type: "event"} ;
		console.error( "eventCallOriginal[0,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "1"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504219666"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[0,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4225268", blockHash: "0xa57623291757364de42c0a73a9b7dfb16b6c67deb78d5fdbaef61f8d3b2b8e89", timeStamp: "1504229785", hash: "0x473fcc6b0226190c7f742860dbf38413e19ef5809f13d0107bd6e4a901f7f87a", nonce: "11", transactionIndex: "50", from: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "300765", gasPrice: "2000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5846976", txreceipt_status: "", gasUsed: "200509", confirmations: "3478652", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "1"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1504229785 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerCreated", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PlayerCreated", events: [{name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504229785"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "playerBalance", type: "uint256", value: "200000000000000"}, {name: "timestamp", type: "uint256", value: "1504229785"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[1,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "1"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504229785"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[1,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[1,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "1"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "price", type: "uint256", value: "2000000000000000"}, {name: "timestamp", type: "uint256", value: "1504229785"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[1,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "7055997848074661" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4225382", blockHash: "0x630cff30d00ad31d62bf647e7d17af4ce462a26f0cfb6a469b3358a1bb78f0e8", timeStamp: "1504232675", hash: "0xb4c5e67d17b4cdb7e4964a476b0d5fa428d5fb07c402a56dc9e05f055555c911", nonce: "269", transactionIndex: "89", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "300765", gasPrice: "2000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6526450", txreceipt_status: "", gasUsed: "300765", confirmations: "3478538", isError: "1"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "1"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4225383", blockHash: "0x1490b7034b7bfb4baf71f09be295ddd797b7a09ddefe9a5b55e77adfa4b9119a", timeStamp: "1504232691", hash: "0x6ef2890d2188f270fc2a6c92e38d4533639977edfdf6336f9c840a0d48199616", nonce: "270", transactionIndex: "31", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "300765", gasPrice: "5000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2407194", txreceipt_status: "", gasUsed: "300765", confirmations: "3478537", isError: "1"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "1"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4225383", blockHash: "0x1490b7034b7bfb4baf71f09be295ddd797b7a09ddefe9a5b55e77adfa4b9119a", timeStamp: "1504232691", hash: "0x232fdfc152497683cfdc8769037f7227f5f59b339b0669415acdfbdbc5b93b9f", nonce: "271", transactionIndex: "51", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "300765", gasPrice: "9000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3957426", txreceipt_status: "", gasUsed: "300765", confirmations: "3478537", isError: "1"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "1"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4225386", blockHash: "0xafe9adb6fd34e5e36af71566027b07cd21aa3767c59a3884d0472b675173195e", timeStamp: "1504232739", hash: "0x11c91db5afe83f1fdfb3d663fabad6d238bd0af5191387d8bc6a4955c1f33269", nonce: "272", transactionIndex: "22", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "300765", gasPrice: "26781250000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3910610", txreceipt_status: "", gasUsed: "300765", confirmations: "3478534", isError: "1"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "1"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4225386", blockHash: "0xafe9adb6fd34e5e36af71566027b07cd21aa3767c59a3884d0472b675173195e", timeStamp: "1504232739", hash: "0xacdf369b20dbb824bfd54eb67f61d104b9dd6d465416af8fe65074e41d0b36e3", nonce: "273", transactionIndex: "26", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "200753", gasPrice: "5000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4921146", txreceipt_status: "", gasUsed: "200753", confirmations: "3478534", isError: "1"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "1"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4225386", blockHash: "0xafe9adb6fd34e5e36af71566027b07cd21aa3767c59a3884d0472b675173195e", timeStamp: "1504232739", hash: "0xf4680cae157b29f73e1f7f1dd8b924d4165d57e867652e09b76ccd6a9d1f5676", nonce: "274", transactionIndex: "27", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "2000000000000000", gas: "539670", gasPrice: "5000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5280925", txreceipt_status: "", gasUsed: "359779", confirmations: "3478534", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "1"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1504232739 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerCreated", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PlayerCreated", events: [{name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504232739"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "400000000000000"}, {name: "timestamp", type: "uint256", value: "1504232739"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "2"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504232739"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "3"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504232739"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolCreated", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "2"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504232739"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[7,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "1"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504232739"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[7,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4225399", blockHash: "0xfe416d467eb4b14e4a380d0a674ab0808215a047f4d2c42668bea951937692fc", timeStamp: "1504233037", hash: "0x787e28793bfe743c4ec96c9b7256dd0ae5c4c7e2c6530d6223d1a47af916acdc", nonce: "275", transactionIndex: "79", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "303400", gasPrice: "5000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "3689627", txreceipt_status: "", gasUsed: "202266", confirmations: "3478521", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "2"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1504233037 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "4"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504233037"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "2"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504233037"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolCreated", type: "event"} ;
		console.error( "eventCallOriginal[8,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "3"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504233037"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[8,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[8,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "2"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504233037"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[8,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4227067", blockHash: "0x1e8da95339a80dc8f0d8a289f0895b16d46a2b784807a91dbaa3c1644d64c762", timeStamp: "1504273325", hash: "0xa3e391e25990120b84f415cc31e630eed4066f8310fdc64db5dba632e877fecd", nonce: "12", transactionIndex: "94", from: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "122506", gasPrice: "2000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "3320633", txreceipt_status: "", gasUsed: "81670", confirmations: "3476853", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "3"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1504273325 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "1"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504273325"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[9,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "3"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504273325"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[9,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "7055997848074661" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4227086", blockHash: "0xb77c7c7bdbfea7dce387c2fb013323272d446c4ba36b82a156290dedc0393569", timeStamp: "1504273727", hash: "0x0ea18cb437fc9d912fcba7c22bb203a9b5d8611c5652eb699e9c89758a8befa2", nonce: "13", transactionIndex: "107", from: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "4000000000000000", gas: "559143", gasPrice: "2000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5604314", txreceipt_status: "", gasUsed: "372761", confirmations: "3476834", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "2"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1504273727 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "playerBalance", type: "uint256", value: "800000000000000"}, {name: "timestamp", type: "uint256", value: "1504273727"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[10,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "5"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504273727"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "6"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504273727"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "7"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504273727"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[10,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolCreated", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "4"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504273727"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "5"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504273727"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[10,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "2"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "price", type: "uint256", value: "8000000000000000"}, {name: "timestamp", type: "uint256", value: "1504273727"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[10,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "7055997848074661" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "4227133", blockHash: "0x642c4f8fd0a9b1001959509550c0277cb77aae7ee3e21819bec06d0a0ff29cb0", timeStamp: "1504274973", hash: "0xcd9894d9771623d1137ebdd5e7d50b9cf8d59f4c43dc16ed3d63be13779ec571", nonce: "276", transactionIndex: "49", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "133510", gasPrice: "2000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "1581182", txreceipt_status: "", gasUsed: "89006", confirmations: "3476787", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "4"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1504274973 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[11,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "3"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504274973"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[11,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[11,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "4"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504274973"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[11,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "4227151", blockHash: "0xd5eee4c0e7cce728079ab4b521eb8f24185fefbcf19d827412fd252d073cf9fb", timeStamp: "1504275417", hash: "0x63ff7b237610deeed20bfe9864c9c43b61b9cfd716566ab0c66c3cb0b8e9ac40", nonce: "277", transactionIndex: "76", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "122253", gasPrice: "2000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "4072559", txreceipt_status: "", gasUsed: "81501", confirmations: "3476769", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "5"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1504275417 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "4"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504275417"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[12,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "5"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504275417"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[12,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "4227151", blockHash: "0xd5eee4c0e7cce728079ab4b521eb8f24185fefbcf19d827412fd252d073cf9fb", timeStamp: "1504275417", hash: "0xf7e2e9602d2c74a1bb27844501747d679d0049ef30fd64d35ee6b4840f19abc0", nonce: "14", transactionIndex: "79", from: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "125763", gasPrice: "2000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "4330684", txreceipt_status: "", gasUsed: "125763", confirmations: "3476769", isError: "1"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "5"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "7055997848074661" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "4227182", blockHash: "0x3af5151149e3b56805aeb9337758f53525cc61b4b9d60946e6727d0d75d68b74", timeStamp: "1504276158", hash: "0x3e26e1b27707057e19d1a0b146c6a627473c24407a4489ea49ad5ea8da76d2e4", nonce: "15", transactionIndex: "42", from: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "4000000000000000", gas: "805896", gasPrice: "2000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "4730847", txreceipt_status: "", gasUsed: "537263", confirmations: "3476738", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "5"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1504276158 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "1199999999999998"}, {name: "timestamp", type: "uint256", value: "1504276158"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "8"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504276158"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "9"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504276158"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "10"}, {name: "wallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "timestamp", type: "uint256", value: "1504276158"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "11"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504276158"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "12"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504276158"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolCreated", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "6"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504276158"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "7"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504276158"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "8"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504276158"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[14,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "5"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "price", type: "uint256", value: "8000000000000000"}, {name: "timestamp", type: "uint256", value: "1504276158"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[14,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "7055997848074661" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "4227192", blockHash: "0xd50a6dc899ff304a6ee5158f014aa3e2b056720a0e9e042038715807f594d1f7", timeStamp: "1504276432", hash: "0x4d9eedd705551a9e6982338eb268b3ffce6f76aae0be42c762992720656f1c60", nonce: "16", transactionIndex: "30", from: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "4000000000000000", gas: "805896", gasPrice: "2000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "5872707", txreceipt_status: "", gasUsed: "156193", confirmations: "3476728", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "4"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1504276432 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "playerBalance", type: "uint256", value: "300000000000000"}, {name: "timestamp", type: "uint256", value: "1504276432"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "1899999999999998"}, {name: "timestamp", type: "uint256", value: "1504276432"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "13"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504276432"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[15,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "4"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "price", type: "uint256", value: "8000000000000000"}, {name: "timestamp", type: "uint256", value: "1504276432"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[15,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "7055997848074661" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4227264", blockHash: "0xdc52fb84aee40306dc11deb0282e4ec3cd55ea3217f8ac6b7299f2e494e6c9fb", timeStamp: "1504278171", hash: "0x2c5783b1bcd27f5937783f21c1ac47c526fafe833c7b9594d77cf22e32c1f815", nonce: "278", transactionIndex: "119", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "4000000000000000", gas: "223588", gasPrice: "5000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "3646490", txreceipt_status: "", gasUsed: "149058", confirmations: "3476656", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "3"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1504278171 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "playerBalance", type: "uint256", value: "388888888888888"}, {name: "timestamp", type: "uint256", value: "1504278171"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "2611111111111102"}, {name: "timestamp", type: "uint256", value: "1504278171"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "14"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504278171"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[16,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "3"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "8000000000000000"}, {name: "timestamp", type: "uint256", value: "1504278171"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[16,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4227279", blockHash: "0x5c2499e5f4d6f2a36c889bf3757f4980ed28e16a56edabde7861e7fa41c4b3ba", timeStamp: "1504278601", hash: "0x802b486025122b208eec340b6a81536e5be6a6385fb1968f583cdeb7a4eede4b", nonce: "279", transactionIndex: "53", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "130855", gasPrice: "2000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "1615483", txreceipt_status: "", gasUsed: "87236", confirmations: "3476641", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "6"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1504278601 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[17,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "14"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504278601"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[17,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[17,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "6"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504278601"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[17,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "4227311", blockHash: "0x966386d161db39375ecfc9e21b66e14e21a8f87c9d8387112c0350b64a1d5eae", timeStamp: "1504279283", hash: "0xe52d6eb4ec60e0481cb1c3dfe89de7a7611af916e45d9b23e9e653606f35cb38", nonce: "17", transactionIndex: "95", from: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "148306", gasPrice: "2000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "2497675", txreceipt_status: "", gasUsed: "98870", confirmations: "3476609", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "7"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1504279283 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[18,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "5"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504279283"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[18,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[18,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "7"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504279283"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[18,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "7055997848074661" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "4227314", blockHash: "0x34a34e7811b2b9eeffa3e04822c498dbea2c0bf312064ffcb659b82df9294d8a", timeStamp: "1504279313", hash: "0xf6cdd090bf8c4ef481a7318a7b74ab4a7b56f20c05e3024c8500a01c7c1c187c", nonce: "18", transactionIndex: "44", from: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "1080406", gasPrice: "2000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000008", contractAddress: "", cumulativeGasUsed: "2982262", txreceipt_status: "", gasUsed: "720270", confirmations: "3476606", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "8"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1504279313 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "15"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504279313"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "16"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504279313"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "17"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504279313"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "18"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504279313"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "19"}, {name: "wallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "timestamp", type: "uint256", value: "1504279313"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "20"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504279313"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[19,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "6"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504279313"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[19,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolCreated", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "9"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504279313"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "10"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504279313"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "11"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504279313"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "12"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504279313"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "13"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504279313"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[19,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "8"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504279313"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[19,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "7055997848074661" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"13\" )", async function( ) {
		const txOriginal = {blockNumber: "4227412", blockHash: "0x3520c4bc5dc70aeeb8d592057edada0d27a3cf38dde39187faefec21b3762765", timeStamp: "1504281998", hash: "0xdf14913a7b837cc00a65c092a4e09b4104f14303cacb0179fa6c50697477a196", nonce: "19", transactionIndex: "93", from: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "188506", gasPrice: "2000000000", input: "0xc83a981c000000000000000000000000000000000000000000000000000000000000000d", contractAddress: "", cumulativeGasUsed: "3201240", txreceipt_status: "", gasUsed: "125670", confirmations: "3476508", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "13"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "13", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1504281998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "7"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "timestamp", type: "uint256", value: "1504281998"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[20,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "13"}, {name: "wallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504281998"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[20,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "7055997848074661" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "4227445", blockHash: "0x9ed698e16c385407e1992a240322802376241846116f41d97a70aafde0642a2f", timeStamp: "1504282712", hash: "0x26e994f8ca7c7e20ed06882c4306510ed297d2d2792aaf54ac47f11ecdf1e3a1", nonce: "280", transactionIndex: "26", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "4000000000000000", gas: "258514", gasPrice: "3000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000008", contractAddress: "", cumulativeGasUsed: "1944703", txreceipt_status: "", gasUsed: "162752", confirmations: "3476475", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "8"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1504282712 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "playerBalance", type: "uint256", value: "522222222222220"}, {name: "timestamp", type: "uint256", value: "1504282712"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "3277777777777762"}, {name: "timestamp", type: "uint256", value: "1504282712"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "21"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504282712"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[21,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "8"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "8000000000000000"}, {name: "timestamp", type: "uint256", value: "1504282712"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[21,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4227445", blockHash: "0x9ed698e16c385407e1992a240322802376241846116f41d97a70aafde0642a2f", timeStamp: "1504282712", hash: "0xba062ba0977742c4427b8de668952275f3a0a637009ea0f2dfa374fcf32ef6d1", nonce: "1", transactionIndex: "29", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "4000000000000000", gas: "384234", gasPrice: "2000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2564263", txreceipt_status: "", gasUsed: "257051", confirmations: "3476475", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "1"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1504282712 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerCreated", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PlayerCreated", events: [{name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504282712"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "playerBalance", type: "uint256", value: "645299145299142"}, {name: "timestamp", type: "uint256", value: "1504282712"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "3893162393162372"}, {name: "timestamp", type: "uint256", value: "1504282712"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "playerBalance", type: "uint256", value: "861538461538461"}, {name: "timestamp", type: "uint256", value: "1504282712"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "22"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504282712"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[22,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "1"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "8000000000000000"}, {name: "timestamp", type: "uint256", value: "1504282712"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[22,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "4227463", blockHash: "0xcd7df4ccafdc1a1f0420b4b254cc15207a7ee053ae4c762d46f82cea3d1b68a7", timeStamp: "1504283150", hash: "0xec06ad075c6aba072202de511c086c86865609bc1b74b73c8abc823cbd28581a", nonce: "281", transactionIndex: "156", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "144484", gasPrice: "2000000000", input: "0xc83a981c000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "4443402", txreceipt_status: "", gasUsed: "96322", confirmations: "3476457", isError: "0"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "10"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1504283150 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[23,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "21"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504283150"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[23,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[23,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "10"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504283150"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[23,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "4227477", blockHash: "0x56abd53c9a84f35f8ee82becf03667ecd0524a896ebeffcfd1873ecfd0c2b10b", timeStamp: "1504283563", hash: "0xedf3e834ccb84c843f50926e2e1e16191944e7dbe89c390ea67471d538cf404e", nonce: "2", transactionIndex: "99", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "130708", gasPrice: "3000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "3377187", txreceipt_status: "", gasUsed: "87138", confirmations: "3476443", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "9"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1504283563 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "22"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504283563"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[24,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "9"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504283563"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[24,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4227488", blockHash: "0x706a94215e38438c36cb20c2bc5f0a4dfe64b32d115ab1593bd1e2889d4e3c09", timeStamp: "1504283690", hash: "0xd646c3b6333082e614d0518afec4153a78d3af819dd17af6e6740b2b61b35221", nonce: "3", transactionIndex: "112", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "4000000000000000", gas: "251340", gasPrice: "3000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "5520183", txreceipt_status: "", gasUsed: "167559", confirmations: "3476432", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "6"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1504283690 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "playerBalance", type: "uint256", value: "778632478632474"}, {name: "timestamp", type: "uint256", value: "1504283690"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "4559829059829032"}, {name: "timestamp", type: "uint256", value: "1504283690"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "23"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504283690"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[25,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "6"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "8000000000000000"}, {name: "timestamp", type: "uint256", value: "1504283690"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[25,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"12\" )", async function( ) {
		const txOriginal = {blockNumber: "4227502", blockHash: "0x2b0a2814d12f5eecdbfbd6a883c030bf8681d41ab18659fed15fa2cf32f5723e", timeStamp: "1504284079", hash: "0x0246992a962bfed034d1837aaf921636fd3a88f78101fee2f405371a434aa1b6", nonce: "4", transactionIndex: "86", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "134152", gasPrice: "2000000000", input: "0xc83a981c000000000000000000000000000000000000000000000000000000000000000c", contractAddress: "", cumulativeGasUsed: "2630194", txreceipt_status: "", gasUsed: "89434", confirmations: "3476418", isError: "0"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "12"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1504284079 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[26,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "23"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504284079"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[26,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[26,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "12"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504284079"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[26,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"13\" )", async function( ) {
		const txOriginal = {blockNumber: "4227567", blockHash: "0xaec4dba7ef5b205195c0f581f347bab0d090bbdf3f36db990fae4b4cef99e242", timeStamp: "1504285587", hash: "0x1053d63ad0689bc16d76363c7bf9b4f2076e9bbdeee567a65e7d8a5a2e96d984", nonce: "5", transactionIndex: "73", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "4000000000000000", gas: "1699371", gasPrice: "3000000000", input: "0xb149ece0000000000000000000000000000000000000000000000000000000000000000d", contractAddress: "", cumulativeGasUsed: "5045236", txreceipt_status: "", gasUsed: "1132913", confirmations: "3476353", isError: "0"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "13"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "13", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1504285587 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "playerBalance", type: "uint256", value: "911965811965806"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "5226495726495692"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[27,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "24"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "25"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "26"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "27"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "28"}, {name: "wallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "29"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "30"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "31"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "32"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "33"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[27,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolCreated", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "14"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "15"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "16"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "17"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "18"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "19"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "20"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "21"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[27,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "13"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "8000000000000000"}, {name: "timestamp", type: "uint256", value: "1504285587"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[27,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"17\" )", async function( ) {
		const txOriginal = {blockNumber: "4228489", blockHash: "0x15057147b0daff23fd44b8d9a604c529680cb42a456fbec0e2fcd93a8dbc6e55", timeStamp: "1504308592", hash: "0xa779b27f333d6bf08dc8267fa9580282058204a7b505efba4ca9aa123ce94450", nonce: "6", transactionIndex: "46", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "196593", gasPrice: "2000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000011", contractAddress: "", cumulativeGasUsed: "5883885", txreceipt_status: "", gasUsed: "131061", confirmations: "3475431", isError: "0"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "17"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1504308592 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[28,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "24"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504308592"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[28,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[28,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "17"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504308592"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[28,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"16\" )", async function( ) {
		const txOriginal = {blockNumber: "4228494", blockHash: "0x968bc80f513774fdfa6e38672ed488199f3774f3c48bfac31e768d927eae270f", timeStamp: "1504308655", hash: "0x5ce72e3529ea87289ff59c33da5441b05e65f4ce3838c339ab82f6028d775cd0", nonce: "7", transactionIndex: "22", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "179056", gasPrice: "2000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000010", contractAddress: "", cumulativeGasUsed: "714103", txreceipt_status: "", gasUsed: "119370", confirmations: "3475426", isError: "0"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "16"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "16", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1504308655 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[29,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "25"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504308655"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[29,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[29,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "16"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504308655"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[29,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "4228494", blockHash: "0x968bc80f513774fdfa6e38672ed488199f3774f3c48bfac31e768d927eae270f", timeStamp: "1504308655", hash: "0xff80dd28558a34feb4de7fdb45dc602f111858583cedbd758ea44dba4054185c", nonce: "8", transactionIndex: "36", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "179023", gasPrice: "2000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000012", contractAddress: "", cumulativeGasUsed: "1508545", txreceipt_status: "", gasUsed: "119348", confirmations: "3475426", isError: "0"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "18"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1504308655 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "26"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504308655"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[30,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "18"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504308655"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[30,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"15\" )", async function( ) {
		const txOriginal = {blockNumber: "4228501", blockHash: "0xb767a52dab59cad1cdaae53d893eba411dbeca0cd3e2b4d966c8e879637d4e95", timeStamp: "1504308929", hash: "0x261f5c2656a9550ac93b8fdca80aef5a79004cb1e3879aa2a680a49d179dcdd8", nonce: "9", transactionIndex: "53", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "178990", gasPrice: "2000000000", input: "0xc83a981c000000000000000000000000000000000000000000000000000000000000000f", contractAddress: "", cumulativeGasUsed: "1542123", txreceipt_status: "", gasUsed: "119326", confirmations: "3475419", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "15"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "15", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1504308929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[31,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "27"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504308929"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[31,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[31,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "15"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504308929"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[31,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"12\" )", async function( ) {
		const txOriginal = {blockNumber: "4229878", blockHash: "0x4f2c9403bdecf361d6bc720b04184e500b911524e1684031d9a9a223eee196f3", timeStamp: "1504342237", hash: "0x2a0b012957353fac736327c58425474878eef29c580bb8a33a301de30f3387de", nonce: "101", transactionIndex: "7", from: "0xb7ea04e597b9dd087b649913f49e5d57d9dac03b", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "6407492", gasPrice: "1000000000", input: "0xc83a981c000000000000000000000000000000000000000000000000000000000000000c", contractAddress: "", cumulativeGasUsed: "6584414", txreceipt_status: "", gasUsed: "6407492", confirmations: "3474042", isError: "1"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "12"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "13011317000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "4231033", blockHash: "0x1637b6eba45fa43ba638efb61fee89ff16bf2a251b0de216bc25a6d0e3596936", timeStamp: "1504371063", hash: "0xd0531f062a0a5ab43407cc7d31ee34c6198e5079af15db72fce4df707cede928", nonce: "282", transactionIndex: "116", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "4000000000000000", gas: "320434", gasPrice: "2000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "6376510", txreceipt_status: "", gasUsed: "213622", confirmations: "3472887", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "9"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1504371063 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "playerBalance", type: "uint256", value: "1045299145299138"}, {name: "timestamp", type: "uint256", value: "1504371063"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "5670940170940132"}, {name: "timestamp", type: "uint256", value: "1504371063"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "playerBalance", type: "uint256", value: "222222222222220"}, {name: "timestamp", type: "uint256", value: "1504371063"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "34"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504371063"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[33,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "9"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "8000000000000000"}, {name: "timestamp", type: "uint256", value: "1504371063"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[33,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "4231043", blockHash: "0xeb6c38d810d6531eda0127e471b77c0a346f53ec3b5575110edb21d40e0f4fee", timeStamp: "1504371241", hash: "0xc0b736356f3ae8f10b1396cef2b603b2cfe8a9f7ebe30163ba1b807987d563e8", nonce: "10", transactionIndex: "72", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "4000000000000000", gas: "313663", gasPrice: "28000000000", input: "0xb149ece0000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "3841422", txreceipt_status: "", gasUsed: "209108", confirmations: "3472877", isError: "0"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "10"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1504371241 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "playerBalance", type: "uint256", value: "1171614934772820"}, {name: "timestamp", type: "uint256", value: "1504371241"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "6091992802519072"}, {name: "timestamp", type: "uint256", value: "1504371241"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "playerBalance", type: "uint256", value: "903643724696355"}, {name: "timestamp", type: "uint256", value: "1504371241"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "playerBalance", type: "uint256", value: "432748538011690"}, {name: "timestamp", type: "uint256", value: "1504371241"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "35"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504371241"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[34,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "10"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "8000000000000000"}, {name: "timestamp", type: "uint256", value: "1504371241"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[34,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "4231055", blockHash: "0x6d2ac7d18ff34edcb3e385702ac3a4d632f8b8dc0b8a5833258ecd7339f06925", timeStamp: "1504371522", hash: "0x2cdf1f715ca971d87fb3807f270169ce4d69c752555a6868e22cf3ab0ee2b24b", nonce: "11", transactionIndex: "47", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "8000000000000000", gas: "382248", gasPrice: "2000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "3244249", txreceipt_status: "", gasUsed: "254831", confirmations: "3472865", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "8000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "9"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1504371522 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "playerBalance", type: "uint256", value: "1411614934772820"}, {name: "timestamp", type: "uint256", value: "1504371522"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "6891992802519072"}, {name: "timestamp", type: "uint256", value: "1504371522"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "playerBalance", type: "uint256", value: "983643724696355"}, {name: "timestamp", type: "uint256", value: "1504371522"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "playerBalance", type: "uint256", value: "912748538011690"}, {name: "timestamp", type: "uint256", value: "1504371522"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "36"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504371522"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "37"}, {name: "wallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "timestamp", type: "uint256", value: "1504371522"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[35,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "9"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "16000000000000000"}, {name: "timestamp", type: "uint256", value: "1504371522"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[35,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"17\" )", async function( ) {
		const txOriginal = {blockNumber: "4231067", blockHash: "0x0b243f0811719937541162714843c2a92de61feab404fef6f4a6349d9f522607", timeStamp: "1504371746", hash: "0x82e37a5b3681bdc506a972b318be166b5255c22b8545c1dbf5c4ebe9073bdc4a", nonce: "283", transactionIndex: "68", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "4000000000000000", gas: "318852", gasPrice: "2000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000011", contractAddress: "", cumulativeGasUsed: "3723065", txreceipt_status: "", gasUsed: "212567", confirmations: "3472853", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "17"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1504371746 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "playerBalance", type: "uint256", value: "1557069480227364"}, {name: "timestamp", type: "uint256", value: "1504371746"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "7255629166155432"}, {name: "timestamp", type: "uint256", value: "1504371746"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "playerBalance", type: "uint256", value: "1020007361059991"}, {name: "timestamp", type: "uint256", value: "1504371746"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "playerBalance", type: "uint256", value: "1167293992557142"}, {name: "timestamp", type: "uint256", value: "1504371746"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "38"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504371746"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[36,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "17"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "8000000000000000"}, {name: "timestamp", type: "uint256", value: "1504371746"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[36,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"16\" )", async function( ) {
		const txOriginal = {blockNumber: "4231093", blockHash: "0x9938100badd9fb86612d302fc972041fe9bea3629f5108ae2717328a2a32df7e", timeStamp: "1504372577", hash: "0x60298d53f4c2de63213ba4753463a8aa180cd20048e77e4cc2d4b1242e031258", nonce: "284", transactionIndex: "101", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "4000000000000000", gas: "320581", gasPrice: "2000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000010", contractAddress: "", cumulativeGasUsed: "4158153", txreceipt_status: "", gasUsed: "213720", confirmations: "3472827", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "16"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "16", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1504372577 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "playerBalance", type: "uint256", value: "1696199915009972"}, {name: "timestamp", type: "uint256", value: "1504372577"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "7603455253111952"}, {name: "timestamp", type: "uint256", value: "1504372577"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "playerBalance", type: "uint256", value: "1089572578451295"}, {name: "timestamp", type: "uint256", value: "1504372577"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "playerBalance", type: "uint256", value: "1410772253426706"}, {name: "timestamp", type: "uint256", value: "1504372577"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "39"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504372577"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[37,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "16"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "8000000000000000"}, {name: "timestamp", type: "uint256", value: "1504372577"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[37,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "4231109", blockHash: "0x6fd788c526f9f9912e7396bfd1335f8d66da32a937348891c59bc79a55adf606", timeStamp: "1504372971", hash: "0xc4c1b9c2a6f06f1454f40f9ee26979c01abcf9ac55a1ed8206bc965026c82729", nonce: "12", transactionIndex: "146", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "185911", gasPrice: "2000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "5100536", txreceipt_status: "", gasUsed: "123940", confirmations: "3472811", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "20"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1504372971 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[38,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "29"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504372971"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[38,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[38,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "20"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504372971"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[38,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"14\" )", async function( ) {
		const txOriginal = {blockNumber: "4231114", blockHash: "0x2bf8417b313a1c73618c519e597a9c81ed6608d3705d2924c505deff71d1c3a4", timeStamp: "1504373111", hash: "0x4623b512945fbfd09a85ca39e6305056013718a0d437be842634e4b7f95753dd", nonce: "13", transactionIndex: "69", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "185878", gasPrice: "2000000000", input: "0xc83a981c000000000000000000000000000000000000000000000000000000000000000e", contractAddress: "", cumulativeGasUsed: "4534037", txreceipt_status: "", gasUsed: "123918", confirmations: "3472806", isError: "0"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "14"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "14", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1504373111 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[39,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "30"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373111"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[39,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "14"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373111"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"11\" )", async function( ) {
		const txOriginal = {blockNumber: "4231118", blockHash: "0x16276fa0a4e5e51fd6ee4534e6484533ba376112de4f8159a16b90bfc58b2308", timeStamp: "1504373194", hash: "0xea6cf958b50b3fe00107bc05fe492bb22e2d59e22ff8d9898f22c041dc38f20e", nonce: "14", transactionIndex: "45", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "185878", gasPrice: "2000000000", input: "0xc83a981c000000000000000000000000000000000000000000000000000000000000000b", contractAddress: "", cumulativeGasUsed: "3945505", txreceipt_status: "", gasUsed: "123896", confirmations: "3472802", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "11"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "11", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1504373194 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "31"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373194"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[40,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "11"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373194"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[40,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"21\" )", async function( ) {
		const txOriginal = {blockNumber: "4231121", blockHash: "0xb0f66e80c5d20df3650b14380640abd92d14f7998a814c7452238af5ce45e09e", timeStamp: "1504373221", hash: "0x0d079b8da82d21be52a0d7d5ed3a08045709d6e41ae1fb86806273aec56a3709", nonce: "15", transactionIndex: "32", from: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "2489124", gasPrice: "2000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000015", contractAddress: "", cumulativeGasUsed: "4115466", txreceipt_status: "", gasUsed: "1659415", confirmations: "3472799", isError: "0"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "21"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "21", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1504373221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "40"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "41"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "42"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "43"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "44"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "45"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "46"}, {name: "wallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "47"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "48"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "49"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "50"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "51"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "52"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "53"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "32"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolCreated", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "22"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "23"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "24"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "25"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "26"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "27"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "28"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "29"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "30"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "31"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "32"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "33"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PoolCreated", events: [{name: "poolId", type: "uint8", value: "34"}, {name: "price", type: "uint256", value: "1000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[41,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "21"}, {name: "wallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504373221"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[41,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "21273000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"26\" )", async function( ) {
		const txOriginal = {blockNumber: "4231594", blockHash: "0xa5fe537093899a795fffb9b52fdf66a70f6118bd2631863071b3710c6cc6445c", timeStamp: "1504384021", hash: "0xa55c906765e3288740e4987f95f03254c36c4a1168cef4d8a2aab53e5e17c935", nonce: "285", transactionIndex: "48", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "213330", gasPrice: "1000000000", input: "0xc83a981c000000000000000000000000000000000000000000000000000000000000001a", contractAddress: "", cumulativeGasUsed: "5763707", txreceipt_status: "", gasUsed: "142219", confirmations: "3472326", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "26"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "26", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1504384021 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[42,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "34"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504384021"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[42,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[42,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "26"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504384021"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[42,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"24\" )", async function( ) {
		const txOriginal = {blockNumber: "4231594", blockHash: "0xa5fe537093899a795fffb9b52fdf66a70f6118bd2631863071b3710c6cc6445c", timeStamp: "1504384021", hash: "0x4db7132f4ba5c03243bbe59133b54e090d6d9ff72f6b135114a149de25d65b3e", nonce: "286", transactionIndex: "56", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "190722", gasPrice: "1000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000018", contractAddress: "", cumulativeGasUsed: "6323042", txreceipt_status: "", gasUsed: "127147", confirmations: "3472326", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "24"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "24", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1504384021 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[43,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "38"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504384021"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[43,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[43,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "24"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504384021"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[43,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: joinPool( \"24\" )", async function( ) {
		const txOriginal = {blockNumber: "4234585", blockHash: "0xa6cad98d49de3ac436504ea3e61cbe79011ecc416cf375d82be3ebf763b18027", timeStamp: "1504457692", hash: "0xb9de45c38429a6235cc61994ca519e74d86b28f2ef6f698daa9142c35b9ac538", nonce: "20", transactionIndex: "75", from: "0x7ae3e1c0f679a1fb1ce369fea21a2c3429966fae", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "4000000000000000", gas: "564478", gasPrice: "1000000000", input: "0xb149ece00000000000000000000000000000000000000000000000000000000000000018", contractAddress: "", cumulativeGasUsed: "4354023", txreceipt_status: "", gasUsed: "376318", confirmations: "3469335", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "24"}], name: "joinPool", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "joinPool(uint8)" ]( "24", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1504457692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerCreated", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "PlayerCreated", events: [{name: "wallet", type: "address", value: "0x7ae3e1c0f679a1fb1ce369fea21a2c3429966fae"}, {name: "timestamp", type: "uint256", value: "1504457692"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerWallet", type: "address"}, {indexed: false, name: "playerBalance", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PlayerBalance", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "playerBalance", type: "uint256", value: "1821199915009972"}, {name: "timestamp", type: "uint256", value: "1504457692"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0x46f0b48b3d61ddb65893dd0978209fab5aef8d7d"}, {name: "playerBalance", type: "uint256", value: "7853455253111952"}, {name: "timestamp", type: "uint256", value: "1504457692"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "playerBalance", type: "uint256", value: "1114572578451295"}, {name: "timestamp", type: "uint256", value: "1504457692"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "PlayerBalance", events: [{name: "playerWallet", type: "address", value: "0xd5682eaedfb9084788fd6c53cd59d875cfccc3a3"}, {name: "playerBalance", type: "uint256", value: "1810772253426706"}, {name: "timestamp", type: "uint256", value: "1504457692"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "54"}, {name: "wallet", type: "address", value: "0x7ae3e1c0f679a1fb1ce369fea21a2c3429966fae"}, {name: "timestamp", type: "uint256", value: "1504457692"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}, {name: "FibokenCreated", events: [{name: "tokenId", type: "uint8", value: "55"}, {name: "wallet", type: "address", value: "0xd229dbda0d510d3937604a0edf254004b495a9f0"}, {name: "timestamp", type: "uint256", value: "1504457692"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[44,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "24"}, {name: "wallet", type: "address", value: "0x7ae3e1c0f679a1fb1ce369fea21a2c3429966fae"}, {name: "price", type: "uint256", value: "8000000000000000"}, {name: "timestamp", type: "uint256", value: "1504457692"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[44,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "3676325067944000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"34\" )", async function( ) {
		const txOriginal = {blockNumber: "4234592", blockHash: "0x63a5a65756299c9475f40ed04bdec4fe75a5b2e925d4b89fdc6d77b2289790be", timeStamp: "1504457826", hash: "0xc1a3b113531cab6e4604e5d64acff626cc413dca47955ae24647e833c37ecfe6", nonce: "21", transactionIndex: "36", from: "0x7ae3e1c0f679a1fb1ce369fea21a2c3429966fae", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "168249", gasPrice: "1000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000022", contractAddress: "", cumulativeGasUsed: "1363593", txreceipt_status: "", gasUsed: "112165", confirmations: "3469328", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "34"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "34", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1504457826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "54"}, {name: "wallet", type: "address", value: "0x7ae3e1c0f679a1fb1ce369fea21a2c3429966fae"}, {name: "timestamp", type: "uint256", value: "1504457826"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[45,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "34"}, {name: "wallet", type: "address", value: "0x7ae3e1c0f679a1fb1ce369fea21a2c3429966fae"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504457826"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[45,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "3676325067944000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"32\" )", async function( ) {
		const txOriginal = {blockNumber: "4234613", blockHash: "0x4bdea881decd1fce23ee46fd04012c92b2775e07496b417baecb25b64a5148c9", timeStamp: "1504458296", hash: "0x706b6734c900010b81222c4ffc7c7cada68d0a9e0545f42f0ec529e63c3d3f87", nonce: "287", transactionIndex: "52", from: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "192357", gasPrice: "1000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000020", contractAddress: "", cumulativeGasUsed: "2622627", txreceipt_status: "", gasUsed: "128237", confirmations: "3469307", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "32"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openPool(uint8)" ]( "32", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1504458296 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint8"}, {indexed: false, name: "wallet", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "FibokenUsed", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FibokenUsed", events: [{name: "tokenId", type: "uint8", value: "39"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "timestamp", type: "uint256", value: "1504458296"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "poolId", type: "uint8"}, {indexed: true, name: "wallet", type: "address"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}], name: "PoolJoined", type: "event"} ;
		console.error( "eventCallOriginal[46,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PoolJoined", events: [{name: "poolId", type: "uint8", value: "32"}, {name: "wallet", type: "address", value: "0xc43c1c4523ef357fd47121c1fa3c3255a1587afc"}, {name: "price", type: "uint256", value: "4000000000000000"}, {name: "timestamp", type: "uint256", value: "1504458296"}], address: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b"}] ;
		console.error( "eventResultOriginal[46,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "84875479012315375" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"23\" )", async function( ) {
		const txOriginal = {blockNumber: "4235594", blockHash: "0x214fc8b8a48dd1d3aef5d3f697a6d76364834b47c3807b5a717810f68617efbb", timeStamp: "1504482194", hash: "0x18f398d87ee3244b12170b437697eaefceecd30ebc84964c6a7dc39527c2e704", nonce: "0", transactionIndex: "47", from: "0x5dc31201f1167ec3f51347b29c719d322457fe8a", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "100000", gasPrice: "21000000000", input: "0xc83a981c0000000000000000000000000000000000000000000000000000000000000017", contractAddress: "", cumulativeGasUsed: "1431977", txreceipt_status: "", gasUsed: "100000", confirmations: "3468326", isError: "1"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "23"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "3550154738693400" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"28\" )", async function( ) {
		const txOriginal = {blockNumber: "4235611", blockHash: "0xfbb738756ddee6e4083dc182b326f6933473e174414c6d9b6cd651f5411deaa0", timeStamp: "1504482468", hash: "0xd8ef1bdd7273e0f20c85fbe9322c7d46afc7ce3735525625cc488052fc8d782f", nonce: "1", transactionIndex: "85", from: "0x5dc31201f1167ec3f51347b29c719d322457fe8a", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "100000", gasPrice: "10000000000", input: "0xc83a981c000000000000000000000000000000000000000000000000000000000000001c", contractAddress: "", cumulativeGasUsed: "2717315", txreceipt_status: "", gasUsed: "100000", confirmations: "3468309", isError: "1"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "28"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "3550154738693400" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: openPool( \"30\" )", async function( ) {
		const txOriginal = {blockNumber: "4235631", blockHash: "0xdfffac6fcfd9bc0546ba8c427ef0183d1c4a0b1485932ae94e7a03fa938ee73f", timeStamp: "1504482986", hash: "0x4e2b62d7d20aeab907e94cdc52be1e69242ec9fd5883642632158076a3dc976f", nonce: "2", transactionIndex: "33", from: "0x5dc31201f1167ec3f51347b29c719d322457fe8a", to: "0xc352add7ad8cac8baa839d8c88e7e9d7df9a219b", value: "1000000000000000", gas: "193000", gasPrice: "15000000000", input: "0xc83a981c000000000000000000000000000000000000000000000000000000000000001e", contractAddress: "", cumulativeGasUsed: "1292729", txreceipt_status: "", gasUsed: "193000", confirmations: "3468289", isError: "1"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "poolId", value: "30"}], name: "openPool", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "3550154738693400" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "54200000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
