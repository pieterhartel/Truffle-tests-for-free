var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "FluxDelta"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0x1F3C3c8fE087f4c330b3C89d155C7265bcd9aBa0","0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed","0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1","0xB7A07BcF2Ba2f2703b24C0691b5278999C59AC7e","0x146500cfd35B22E4A392Fe0aDc06De1a1368Ed48","0x6f485C8BF6fc43eA212E93BBF8ce046C7f1cb475","0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF","0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA","0xb7909CA16B666a6c4f31d2a7c76aCF0D3e3300c0","0x96a4ed03206667017777f010DEA4445823aCb0fC","0x61Ec2AD2219eFD7B68e26790FCbccbe36728CBC8","0x0B0eFad4aE088a88fFDC50BCe5Fb63c6936b9220","0xF4e5e695D1c7285CAD1EFb9830A4fd18302A6Bf3","0x47Ec1A1636c29079c8d9704172b739B03F1A3DeA","0x7253ba8c85EFC0681a021E884ee08B9fF953BBe2","0xc454c4be786e8ad7610d6113C06E4A608Af303Cb","0x849790fFcD68B6Da405D9eecc56D832daf5ECE30","0x862412dd2d38F649041828e19Aa2546f3e4D5DdF","0x3189c2ba96c7643Eb3E39a02Ade92555c69b029E","0xC00eDFa98C782c580B335E414Cd62597670a5E5c","0x754Ef5A27c49F8f59F53597cBB28256392f0Ee04","0x391939867C24924b7dCE21C05bebC609B37e9EB1","0xC20B0367b14DdC1f261459a9e95194Fab09b579a","0x4656753A99422adaaF535414584328915Df4C6D0","0xB74D5f0a81Ce99aC1857133E489bC2b4954935fF","0x14f225dD5D5cccc3045655EcBf4Df078D9ab454d"]
addressListOriginal.length = 28
methodPrototypeListOriginal = [{"constant":true,"inputs":[{"name":"_user","type":"address"},{"name":"_onlyVisible","type":"bool"}],"name":"getAllCostsInfoOf","outputs":[{"name":"indexes","type":"uint256[]"},{"name":"baseCosts","type":"uint256[]"},{"name":"myScalars","type":"uint256[]"},{"name":"myCosts","type":"uint256[]"},{"name":"isShorting","type":"bool[]"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"getTotalCoinPairs","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_onlyVisible","type":"bool"}],"name":"getAllCoinPairs","outputs":[{"name":"indexes","type":"uint256[]"},{"name":"addresses","type":"address[]"},{"name":"fromSyms","type":"bytes32[]"},{"name":"toSyms","type":"bytes32[]"},{"name":"totalShares","type":"uint256[]"},{"name":"totalPots","type":"uint256[]"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_user","type":"address"},{"name":"_onlyVisible","type":"bool"}],"name":"getAllSharesInfoOf","outputs":[{"name":"indexes","type":"uint256[]"},{"name":"userShares","type":"uint256[]"},{"name":"lastPrices","type":"uint256[]"},{"name":"lastPriceTimes","type":"uint256[]"},{"name":"withdrawables","type":"uint256[]"}],"payable":false,"stateMutability":"view","type":"function"}]
eventPrototypeListOriginal = []
eventSignatureListOriginal = []
topicListOriginal = []
nBlocksOriginal = 50
fromBlockOriginal = 6781258
toBlockOriginal = 6837470
constructorPrototypeOriginal = {"inputs":[{"type":"address","name":"_P4D_address","value":11}],"name":"FluxDelta","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"6781258","timeStamp":"1543308495","hash":"0x9fade86d58aca127fd1cdaa40ff696bd7d8d985c0be79ff4b3e77705f68e01bd","nonce":"5","blockHash":"0x14bb671a162a32a4ec97383fd8f8bd6f12d09fba4b1c525351f46cc8bc792cda","transactionIndex":"25","from":"0xb7909ca16b666a6c4f31d2a7c76acf0d3e3300c0","to":0,"value":"0","gas":"5079976","gasPrice":"6000000000","isError":"0","txreceipt_status":"1","input":"0x4ca89aa400000000000000000000000096a4ed03206667017777f010dea4445823acb0fc","contractAddress":"0x1f3c3c8fe087f4c330b3c89d155c7265bcd9aba0","cumulativeGasUsed":"6265072","gasUsed":"5079976","confirmations":"921254"}
txOptions[0] = {"from":"0x28a8746e75304c0780E011BEd21C72cD78cd535E","to":0,"value":"0"}
txCall[0] = {"inputs":[{"type":"address","name":"_P4D_address","value":"0xACa94ef8bD5ffEE41947b4585a84BdA5a3d3DA6E"}],"name":"FluxDelta","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
