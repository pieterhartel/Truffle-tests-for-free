const FaceToken = artifacts.require( "./FaceToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "FaceToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x7Ed58877581d07bB4238a8B4D341E54C609b73c2", "0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed", "0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1", "0xB7A07BcF2Ba2f2703b24C0691b5278999C59AC7e", "0x6f485C8BF6fc43eA212E93BBF8ce046C7f1cb475", "0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF", "0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA", "0x253C5dD0dF7e67E9c75A2A0075CFE3D382530A39", "0xCCe6DA2086DD9348010a2813be49E58530852b46", "0x26588a9301b0428d95e6Fc3A5024fcE8BEc12D51", "0xC491Fd37F4528e0D139c8d85470cD221B6cAfcd5", "0x12387fb64838b0De21505Ae89611e78F1d411ae9", "0xC1639a863381b265A076A862162A1a3CDC97b0Fb", "0x042910c61bf20D5B1BD15A166db5b37459F8Ea98", "0xdD41a4108D31830BD4e8A9B9e453585227A5f295", "0x7bf6926bcf01507D5A5600F49D1650540cDAad48", "0xb47bCadEC4A4cF6A62b17B80f18a6724E3fcBa29", "0xb5883450020f247f9333A090813652d01928ebbA", "0x3e48c1f346f1e70EEb011Ca816A7E7acDB9C113B", "0xd3B2F5d61226152410d6219d23544651B85D3f46", "0x6AF0474ae538cEea2B8dA5Cd368E111b89784A35", "0xC9e1202a20593aE7dFaB0c6B5E9463d2Ab66a2D4", "0x67c82083315e0a76B80508b932aBca9550C76B36", "0xb0105aD402F83be5c73Bd8F3617723B6830cC907", "0x0264c47270eed9859A6852548D142D0d7Dbd5fb6", "0x75e16A0a5eFa7f0d3be945173dc9C3548381Aa98", "0x771d4bB5cb9E2256582bB08C2D161D25cc9CC210", "0x236911357d06CEDb309F94981BF9734112bCbC26", "0xB7850981565650371B8b36E9354BbFbe1cDa3d25", "0xf96023AbBBCC062Bdf42800Ba9A7b10eC3Bf0723", "0x4744C4FfaFFc6c98FAe4E33bB8993d7C87f29F3F"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "members", outputs: [{name: "addr", type: "address"}, {name: "referrer", type: "address"}, {name: "approved", type: "bool"}, {name: "id", type: "bytes32"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "addr", type: "address"}, {name: "level", type: "uint256"}], name: "level_referrals_count_by_address", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isOpened", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getTransactionPrice", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "startSpreadingBlock", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "addr", type: "address"}], name: "all_referrals_count_by_address", outputs: [{name: "count", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "maxSupply", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Transfer(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3495452 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 3516769 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "FaceToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "members", outputs: [{name: "addr", type: "address"}, {name: "referrer", type: "address"}, {name: "approved", type: "bool"}, {name: "id", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "members(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "level", value: random.range( maxRandom )}], name: "level_referrals_count_by_address", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "level_referrals_count_by_address(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isOpened", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isOpened()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getTransactionPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTransactionPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startSpreadingBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startSpreadingBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "all_referrals_count_by_address", outputs: [{name: "count", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "all_referrals_count_by_address(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "FaceToken", function( accounts ) {

	it( "TEST: FaceToken(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "3495452", timeStamp: "1491601357", hash: "0xfa88d25c14970fe71042b2750d5dbf450a2131ab5150fec22aec60d21b506311", nonce: "0", blockHash: "0x9cb37304afe1206f633d81fed9299da026c2e6ca6e9e68b17215acadcca56929", transactionIndex: "0", from: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39", to: 0, value: "0", gas: "4247813", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x61c05c07", contractAddress: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", cumulativeGasUsed: "2314743", gasUsed: "2314743", confirmations: "4178961"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "FaceToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = FaceToken.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1491601357 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = FaceToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "53705140000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAKp4HPlVSSGvYiUapHRb00wWYq... )", async function( ) {
		const txOriginal = {blockNumber: "3510013", timeStamp: "1491816275", hash: "0xebe0429b207c16e118fd1c8692f554f020f1a7694db0b5154b0b68bcc8581c1e", nonce: "36", blockHash: "0x04ba0f8c18131af1908b1be3d81fc4e05df7463bc8d103bd673b15def09b46a5", transactionIndex: "9", from: "0xcce6da2086dd9348010a2813be49e58530852b46", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "403060", gasPrice: "22080762937", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000253c5dd0df7e67e9c75a2a0075cfe3d382530a3900000000000000000000000000000000000000000000000000000000000000b04541415962453345394d504142414b703448506c565353477659695561704852623030775759714c6172504130526f7a415762584e31756f5a41777779366c733071595a416557673654755a4170766f415a43574b644d6e4a74655338306e446743316e7558516e336234533049797a734b69776d6d3851566867694144466937515056315270634439714c39514d4c7a5149693575535631725374645a416e304a62354f626c6f45766c675a445a4400000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "535459", gasUsed: "268706", confirmations: "4164400"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAKp4HPlVSSGvYiUapHRb00wWYqLarPA0RozAWbXN1uoZAwwy6ls0qYZAeWg6TuZApvoAZCWKdMnJteS80nDgC1nuXQn3b4S0IyzsKiwmm8QVhgiADFi7QPV1RpcD9qL9QMLzQIi5uSV1rStdZAn0Jb5ObloEvlgZDZD`}, {type: "address", name: "referrer", value: addressList[9]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAKp4HPlVSSGvYiUapHRb00wWYqLarPA0RozAWbXN1uoZAwwy6ls0qYZAeWg6TuZApvoAZCWKdMnJteS80nDgC1nuXQn3b4S0IyzsKiwmm8QVhgiADFi7QPV1RpcD9qL9QMLzQIi5uSV1rStdZAn0Jb5ObloEvlgZDZD`, addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1491816275 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "3345022589545574" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x0decd9ed7b3352d0788cf566081ea647fa60... )", async function( ) {
		const txOriginal = {blockNumber: "3510015", timeStamp: "1491816322", hash: "0xf731373e33b6c04d2c6e0f4808ff54ba5511df01ab195d7a7866e0859352160c", nonce: "75281", blockHash: "0xabdc25cd34a39f25b124c5cca1305bad38e0ca43fb0de3a01a6eb5b78dd84497", transactionIndex: "37", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e0decd9ed7b3352d0788cf566081ea647fa60fda5b57b229db1fb8e86e43e03d2000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000103134333533393338383331393839303100000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1666032", gasUsed: "216361", confirmations: "4164398"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x0decd9ed7b3352d0788cf566081ea647fa60fda5b57b229db1fb8e86e43e03d2"}, {type: "string", name: "result", value: `1435393883198901`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x0decd9ed7b3352d0788cf566081ea647fa60fda5b57b229db1fb8e86e43e03d2", `1435393883198901`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1491816322 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xcce6da2086dd9348010a2813be49e58530852b46"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABALijM0FDOEuwVFzRZBxcwWzZAL... )", async function( ) {
		const txOriginal = {blockNumber: "3510023", timeStamp: "1491816460", hash: "0x884dda4e8d2671652f15923a3e5f6c4db7934cc2d78dbef29b13be6ed04f8865", nonce: "1", blockHash: "0x174ae0e39c3b80e5f133a5795d9f7a7ec363b1d3e150840dcce38ba7cc0e4b0e", transactionIndex: "0", from: "0xc491fd37f4528e0d139c8d85470cd221b6cafcd5", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "374202", gasPrice: "23122068211", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000cce6da2086dd9348010a2813be49e58530852b4600000000000000000000000000000000000000000000000000000000000000a74541415962453345394d504142414c696a4d3046444f45757756467a525a42786377577a5a414c67687276427a726f755a4233647479326332574e6f6764525a416d614d554734736647766c47306347503355554b774655583152625a41593455743336396c355a41766f6357364c503431564d5661355a4177666f474939325a4146357a564e5a436d683662673452657174564f367a6132424a7634656b716a35746e305a4400000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "249467", gasUsed: "249467", confirmations: "4164390"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABALijM0FDOEuwVFzRZBxcwWzZALghrvBzrouZB3dty2c2WNogdRZAmaMUG4sfGvlG0cGP3UUKwFUX1RbZAY4Ut369l5ZAvocW6LP41VMVa5ZAwfoGI92ZAF5zVNZCmh6bg4ReqtVO6za2BJv4ekqj5tn0ZD`}, {type: "address", name: "referrer", value: addressList[10]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABALijM0FDOEuwVFzRZBxcwWzZALghrvBzrouZB3dty2c2WNogdRZAmaMUG4sfGvlG0cGP3UUKwFUX1RbZAY4Ut369l5ZAvocW6LP41VMVa5ZAwfoGI92ZAF5zVNZCmh6bg4ReqtVO6za2BJv4ekqj5tn0ZD`, addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1491816460 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "6973276054850718" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x9dd471ee30f4d12b73aa5de6b9b8321ed6cd... )", async function( ) {
		const txOriginal = {blockNumber: "3510027", timeStamp: "1491816514", hash: "0xd6bf0d9b43ec3bb09526bd4cd437da7ab6f231f1c292759f6c17fca1a3782fe7", nonce: "75282", blockHash: "0x2496c3b9e13f31c4609eb57102df4010b7be89cd5513f277e59a06c5cbc2b584", transactionIndex: "31", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e9dd471ee30f4d12b73aa5de6b9b8321ed6cd60f92a7d0526ce15c7e6f7bdaa970000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000f3238373833323030343937343832360000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1571113", gasUsed: "221866", confirmations: "4164386"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x9dd471ee30f4d12b73aa5de6b9b8321ed6cd60f92a7d0526ce15c7e6f7bdaa97"}, {type: "string", name: "result", value: `287832004974826`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x9dd471ee30f4d12b73aa5de6b9b8321ed6cd60f92a7d0526ce15c7e6f7bdaa97", `287832004974826`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1491816514 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc491fd37f4528e0d139c8d85470cd221b6cafcd5"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xcce6da2086dd9348010a2813be49e58530852b46"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "25000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAEpMvez0R7iHiAS3aSBDkZCUhc... )", async function( ) {
		const txOriginal = {blockNumber: "3510045", timeStamp: "1491816789", hash: "0x387252853ce43822647d789b9748dc7a92da5c88d491d6a796e49350b96451ce", nonce: "18", blockHash: "0x7bb5ff1ab851bf56c9142208aef8d6109d7530e07c3e786ccbc54c67c519c198", transactionIndex: "11", from: "0x12387fb64838b0de21505ae89611e78f1d411ae9", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "382092", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000c491fd37f4528e0d139c8d85470cd221b6cafcd500000000000000000000000000000000000000000000000000000000000000b24541415962453345394d5041424145704d76657a305237694869415333615342446b5a4355686338744261766e5a41424d676235584f3653737431624e317873497a335778396d644248685243477a48684d34744b5a43654a6734465150306b4a7a68414f723557754d52614e337564676d31695a4152476e74697855533555305a4159636952764159385a43575a4351795049704634544432776c35435644434765755677754f414f624647775a445a440000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "516583", gasUsed: "254727", confirmations: "4164368"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAEpMvez0R7iHiAS3aSBDkZCUhc8tBavnZABMgb5XO6Sst1bN1xsIz3Wx9mdBHhRCGzHhM4tKZCeJg4FQP0kJzhAOr5WuMRaN3udgm1iZARGntixUS5U0ZAYciRvAY8ZCWZCQyPIpF4TD2wl5CVDCGeuVwuOAObFGwZDZD`}, {type: "address", name: "referrer", value: addressList[12]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAEpMvez0R7iHiAS3aSBDkZCUhc8tBavnZABMgb5XO6Sst1bN1xsIz3Wx9mdBHhRCGzHhM4tKZCeJg4FQP0kJzhAOr5WuMRaN3udgm1iZARGntixUS5U0ZAYciRvAY8ZCWZCQyPIpF4TD2wl5CVDCGeuVwuOAObFGwZDZD`, addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1491816789 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "188304285402252933" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x06a3325f101260308e0d1b1d43136e0e89ad... )", async function( ) {
		const txOriginal = {blockNumber: "3510047", timeStamp: "1491816810", hash: "0x54c67b4e4c576ddf6c0e4db84c8d860b5d99dd2b90506160d2b38c54855287ba", nonce: "75283", blockHash: "0x84abc9ee1dc7bcef2b4cc6c50e77d7e71a02d0769c7e221cc4ab127c62bcccce", transactionIndex: "3", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e06a3325f101260308e0d1b1d43136e0e89ad33cdfd0f99270c3b07d172636b10000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000103137393337353033333039353439343300000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "320500", gasUsed: "257500", confirmations: "4164366"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x06a3325f101260308e0d1b1d43136e0e89ad33cdfd0f99270c3b07d172636b10"}, {type: "string", name: "result", value: `1793750330954943`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x06a3325f101260308e0d1b1d43136e0e89ad33cdfd0f99270c3b07d172636b10", `1793750330954943`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1491816810 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x12387fb64838b0de21505ae89611e78f1d411ae9"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc491fd37f4528e0d139c8d85470cd221b6cafcd5"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xcce6da2086dd9348010a2813be49e58530852b46"}, {name: "value", type: "uint256", value: "25000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "12500000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAJEzZCmBqJvc7XD6AjbBaoJdf9... )", async function( ) {
		const txOriginal = {blockNumber: "3510057", timeStamp: "1491816960", hash: "0x9e3bc69ee056a931fefe7942cdcea81c9851d2184bee1a1fba00cd3188d78a66", nonce: "0", blockHash: "0x7f6d74fa7f66f295ae51162bfbd14cf7ce979444e7e05a218283e41178f1479e", transactionIndex: "7", from: "0xc1639a863381b265a076a862162a1a3cdc97b0fb", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "382809", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d644069000000000000000000000000000000000000000000000000000000000000004000000000000000000000000012387fb64838b0de21505ae89611e78f1d411ae900000000000000000000000000000000000000000000000000000000000000b34541415962453345394d504142414a457a5a436d42714a766337584436416a6242616f4a64663976324e386e6b6361677a31796e4c737945524b61594b795a4133654a6c4c38745a4155596d514242676d6a31365a427870486d446d7864424d523563495932477a56526a507a7872674653745134715a427178444c4b70476b796162447365315662646458596e34574c46484173487a68555a4364434e6c4a5151346f5a41764a685a434b4a61515a445a4400000000000000000000000000", contractAddress: "", cumulativeGasUsed: "558970", gasUsed: "255205", confirmations: "4164356"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAJEzZCmBqJvc7XD6AjbBaoJdf9v2N8nkcagz1ynLsyERKaYKyZA3eJlL8tZAUYmQBBgmj16ZBxpHmDmxdBMR5cIY2GzVRjPzxrgFStQ4qZBqxDLKpGkyabDse1VbddXYn4WLFHAsHzhUZCdCNlJQQ4oZAvJhZCKJaQZDZD`}, {type: "address", name: "referrer", value: addressList[13]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAJEzZCmBqJvc7XD6AjbBaoJdf9v2N8nkcagz1ynLsyERKaYKyZA3eJlL8tZAUYmQBBgmj16ZBxpHmDmxdBMR5cIY2GzVRjPzxrgFStQ4qZBqxDLKpGkyabDse1VbddXYn4WLFHAsHzhUZCdCNlJQQ4oZAvJhZCKJaQZDZD`, addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1491816960 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "4563232002661350" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xcf615215924d060e93e0bc8b92c3aedf4d91... )", async function( ) {
		const txOriginal = {blockNumber: "3510062", timeStamp: "1491817030", hash: "0xff2b195219996afaa04aaf490208b3e2620c4caf5508bbd0d6ad348595e3a037", nonce: "75285", blockHash: "0x5ecc2c6b25664d268bf411ba6e360e5c75426088c1bcb46a588237df259afdfb", transactionIndex: "13", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297ecf615215924d060e93e0bc8b92c3aedf4d916693164edab1ff0b7bb962a61a34000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000103136323133363333363738393139393200000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "814887", gasUsed: "293069", confirmations: "4164351"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xcf615215924d060e93e0bc8b92c3aedf4d916693164edab1ff0b7bb962a61a34"}, {type: "string", name: "result", value: `1621363367891992`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xcf615215924d060e93e0bc8b92c3aedf4d916693164edab1ff0b7bb962a61a34", `1621363367891992`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1491817030 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc1639a863381b265a076a862162a1a3cdc97b0fb"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x12387fb64838b0de21505ae89611e78f1d411ae9"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc491fd37f4528e0d139c8d85470cd221b6cafcd5"}, {name: "value", type: "uint256", value: "25000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xcce6da2086dd9348010a2813be49e58530852b46"}, {name: "value", type: "uint256", value: "12500000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "6250000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAECGjDpII2FcFdPL9sxRAVLZAM... )", async function( ) {
		const txOriginal = {blockNumber: "3510330", timeStamp: "1491820842", hash: "0x659fcc22612c8b52e3ad3ff53f711efd39c0ae3c3f61df385495d82acee65bae", nonce: "0", blockHash: "0x1dde70946cb0e8b01e72d7a0a823b053e1dddf7b001af09e6277741a88d15cd8", transactionIndex: "4", from: "0x042910c61bf20d5b1bd15a166db5b37459f8ea98", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "381375", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000c1639a863381b265a076a862162a1a3cdc97b0fb00000000000000000000000000000000000000000000000000000000000000b14541415962453345394d504142414543476a447049493246634664504c3973785241564c5a414d617433744c6749707255396876397a6e6d4a4e4f7a4d5a426a5474547841636c4d43564248466f766c3932356e536c584b415a42494c544d6a67446673366a4d5a426367365845696b6e366e6471396c6b715a4359734d4d7a7578794e64306d4c556d4937785954733953664f4f753669416e5a4263397869794f77734b46743772703731415a445a44000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "354459", gasUsed: "254249", confirmations: "4164083"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAECGjDpII2FcFdPL9sxRAVLZAMat3tLgIprU9hv9znmJNOzMZBjTtTxAclMCVBHFovl925nSlXKAZBILTMjgDfs6jMZBcg6XEikn6ndq9lkqZCYsMMzuxyNd0mLUmI7xYTs9SfOOu6iAnZBc9xiyOwsKFt7rp71AZDZD`}, {type: "address", name: "referrer", value: addressList[14]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAECGjDpII2FcFdPL9sxRAVLZAMat3tLgIprU9hv9znmJNOzMZBjTtTxAclMCVBHFovl925nSlXKAZBILTMjgDfs6jMZBcg6XEikn6ndq9lkqZCYsMMzuxyNd0mLUmI7xYTs9SfOOu6iAnZBc9xiyOwsKFt7rp71AZDZD`, addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1491820842 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "4582352002661350" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x9f9521f57a6cc7c23c65dff1f7d9e248381a... )", async function( ) {
		const txOriginal = {blockNumber: "3510334", timeStamp: "1491820895", hash: "0xcaad3bd6b6ed02b8092f0ef6c877a849a16e0c642d3a72f3f5e724452d927f59", nonce: "75287", blockHash: "0x9f5095dacf15a12d6009f16eef6f08c4ce83e74403eb82acf5814e2743d94b91", transactionIndex: "9", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e9f9521f57a6cc7c23c65dff1f7d9e248381af20c872be1b045e008e6eb5c19ff000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000103133373036313235373633333939303900000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "592675", gasUsed: "328347", confirmations: "4164079"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x9f9521f57a6cc7c23c65dff1f7d9e248381af20c872be1b045e008e6eb5c19ff"}, {type: "string", name: "result", value: `1370612576339909`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x9f9521f57a6cc7c23c65dff1f7d9e248381af20c872be1b045e008e6eb5c19ff", `1370612576339909`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1491820895 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x042910c61bf20d5b1bd15a166db5b37459f8ea98"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc1639a863381b265a076a862162a1a3cdc97b0fb"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x12387fb64838b0de21505ae89611e78f1d411ae9"}, {name: "value", type: "uint256", value: "25000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc491fd37f4528e0d139c8d85470cd221b6cafcd5"}, {name: "value", type: "uint256", value: "12500000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xcce6da2086dd9348010a2813be49e58530852b46"}, {name: "value", type: "uint256", value: "6250000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "3125000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAGVc5J57qKVrDNpryfeJr5OToz... )", async function( ) {
		const txOriginal = {blockNumber: "3511372", timeStamp: "1491836335", hash: "0x8c2f698404fe5492fd10648841e49858825fd4dc204239baac02329939a7b474", nonce: "11", blockHash: "0x560043b1998a347e2db9b7cf2731d950a632730c70219fc3f43c48ee449f0523", transactionIndex: "5", from: "0xdd41a4108d31830bd4e8a9b9e453585227a5f295", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "369267", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000253c5dd0df7e67e9c75a2a0075cfe3d382530a3900000000000000000000000000000000000000000000000000000000000000a14541415962453345394d50414241475663354a3537714b5672444e70727966654a72354f546f7a706777766e4651643552446c4e43346543546f3656386534784f41525957515a41716150445a426f67646c4c65696b4d41393053556630346239716251386174514d3477714a3654744856454f31306a677a6a45347842306c314b4b4f4531516c58554b6f6a73465a43434262694e594a65474b6b6936675a4400000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "382072", gasUsed: "246177", confirmations: "4163041"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAGVc5J57qKVrDNpryfeJr5OTozpgwvnFQd5RDlNC4eCTo6V8e4xOARYWQZAqaPDZBogdlLeikMA90SUf04b9qbQ8atQM4wqJ6TtHVEO10jgzjE4xB0l1KKOE1QlXUKojsFZCCBbiNYJeGKki6gZD`}, {type: "address", name: "referrer", value: addressList[9]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAGVc5J57qKVrDNpryfeJr5OTozpgwvnFQd5RDlNC4eCTo6V8e4xOARYWQZAqaPDZBogdlLeikMA90SUf04b9qbQ8atQM4wqJ6TtHVEO10jgzjE4xB0l1KKOE1QlXUKojsFZCCBbiNYJeGKki6gZD`, addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1491836335 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "586360652137014433" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xcb14d05253bc491838d06abb08652cec9915... )", async function( ) {
		const txOriginal = {blockNumber: "3511374", timeStamp: "1491836371", hash: "0xfb0f60d51ecdc3a25345a3d43a83ca0b8a73f41141f83021713278e96bb0d4ef", nonce: "75309", blockHash: "0x5bcbd790d36f2f51cdce7de6f5b73917457864edcacdf59ea7505cf0e10e67bc", transactionIndex: "21", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297ecb14d05253bc491838d06abb08652cec9915a7870c43e96af4480e114dda36a6000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000113130323038323439393635343232303334000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "672713", gasUsed: "171425", confirmations: "4163039"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xcb14d05253bc491838d06abb08652cec9915a7870c43e96af4480e114dda36a6"}, {type: "string", name: "result", value: `10208249965422034`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xcb14d05253bc491838d06abb08652cec9915a7870c43e96af4480e114dda36a6", `10208249965422034`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1491836371 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xdd41a4108d31830bd4e8a9b9e453585227a5f295"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABABnH1Hr2uLWSfPuU0ZCUWFvVop... )", async function( ) {
		const txOriginal = {blockNumber: "3511580", timeStamp: "1491839586", hash: "0x3c5ce0ebe235211713f498cc7582bf37dfbc19a6ca4eb1ae2849ce18268339da", nonce: "149", blockHash: "0x3baa48589784bed6092d532ea86768c11413a6eb97d404eaf647ab744487d460", transactionIndex: "5", from: "0x7bf6926bcf01507d5a5600f49d1650540cdaad48", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "381996", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000253c5dd0df7e67e9c75a2a0075cfe3d382530a3900000000000000000000000000000000000000000000000000000000000000b24541415962453345394d50414241426e4831487232754c575366507555305a4355574676566f704962344e4c38676856663071756c6d5a415852576a71343363386c5655584d5837754d544c724c5a4239464f694a4a7a77684963583255784e3041496f5143417572726c4c395a4343367a6777526456317471386d6f777074454b6577386a784c344e6e4a71706c6576575954536c5a434f6962325a42555275465147365a427839446e5257775a445a440000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "457994", gasUsed: "254663", confirmations: "4162833"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABABnH1Hr2uLWSfPuU0ZCUWFvVopIb4NL8ghVf0qulmZAXRWjq43c8lVUXMX7uMTLrLZB9FOiJJzwhIcX2UxN0AIoQCAurrlL9ZCC6zgwRdV1tq8mowptEKew8jxL4NnJqplevWYTSlZCOib2ZBURuFQG6ZBx9DnRWwZDZD`}, {type: "address", name: "referrer", value: addressList[9]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABABnH1Hr2uLWSfPuU0ZCUWFvVopIb4NL8ghVf0qulmZAXRWjq43c8lVUXMX7uMTLrLZB9FOiJJzwhIcX2UxN0AIoQCAurrlL9ZCC6zgwRdV1tq8mowptEKew8jxL4NnJqplevWYTSlZCOib2ZBURuFQG6ZBx9DnRWwZDZD`, addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1491839586 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "68059682525881054" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xefe1b1abbf46d0b10daf65889b1f20e533c1... )", async function( ) {
		const txOriginal = {blockNumber: "3511584", timeStamp: "1491839647", hash: "0x9dac274f3d41baf3c29f2d9b8e498b47d8aa0a9adedf6bf86e67f0a0bcf6aa8a", nonce: "75311", blockHash: "0x17882a118d23ed5377ad39fdbea36a8358012fc8339d5995e54459a6ebe17336", transactionIndex: "10", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297eefe1b1abbf46d0b10daf65889b1f20e533c189096d8489b81ae852af9d8d78050000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000f3436363334303138333731303232340000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "573767", gasUsed: "171297", confirmations: "4162829"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xefe1b1abbf46d0b10daf65889b1f20e533c189096d8489b81ae852af9d8d7805"}, {type: "string", name: "result", value: `466340183710224`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xefe1b1abbf46d0b10daf65889b1f20e533c189096d8489b81ae852af9d8d7805", `466340183710224`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1491839647 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x7bf6926bcf01507d5a5600f49d1650540cdaad48"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAOZA2yrP7oXtugQYdpsvVdzO0j... )", async function( ) {
		const txOriginal = {blockNumber: "3512183", timeStamp: "1491849039", hash: "0x3aab772cc05f74beaf96a35eabf959fd42ff053eb52c9c1b789f991084a59132", nonce: "0", blockHash: "0x95ee5566d0a8187363e04da3133835d4c477b22ca7709fc42d6c437194811451", transactionIndex: "16", from: "0xb47bcadec4a4cf6a62b17b80f18a6724e3fcba29", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "371238", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000253c5dd0df7e67e9c75a2a0075cfe3d382530a3900000000000000000000000000000000000000000000000000000000000000a34541415962453345394d504142414f5a4132797250376f5874756751596470737656647a4f306a594d776f785a4367684564434b5677657074734545314f57567262614a543358364c3370474a66487768774b4f65306b757a7371563679447642415a434d537938594d786f4256316841484d53796b566a7a767178597856686c795a43674e58567a585a423865617a38765553556b35594e437469616c66536f5a440000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "745769", gasUsed: "247491", confirmations: "4162230"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAOZA2yrP7oXtugQYdpsvVdzO0jYMwoxZCghEdCKVweptsEE1OWVrbaJT3X6L3pGJfHwhwKOe0kuzsqV6yDvBAZCMSy8YMxoBV1hAHMSykVjzvqxYxVhlyZCgNXVzXZB8eaz8vUSUk5YNCtialfSoZD`}, {type: "address", name: "referrer", value: addressList[9]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAOZA2yrP7oXtugQYdpsvVdzO0jYMwoxZCghEdCKVweptsEE1OWVrbaJT3X6L3pGJfHwhwKOe0kuzsqV6yDvBAZCMSy8YMxoBV1hAHMSykVjzvqxYxVhlyZCgNXVzXZB8eaz8vUSUk5YNCtialfSoZD`, addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1491849039 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "429359335802661350" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xe30fa1403978911fdd0b44a00ea72f8f7349... )", async function( ) {
		const txOriginal = {blockNumber: "3512186", timeStamp: "1491849074", hash: "0x2397da64e354e489f747f2ac6066844df09231d67bf58577970011a3a4897d45", nonce: "75334", blockHash: "0x32a31d04105898774faa899cc278c7ec93d24566e1f7c8180a31b24cfb3e3308", transactionIndex: "7", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297ee30fa1403978911fdd0b44a00ea72f8f734901bddfb48abcd8a275a8810f277b000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000113130313036333733323236343435303138000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "377687", gasUsed: "171425", confirmations: "4162227"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xe30fa1403978911fdd0b44a00ea72f8f734901bddfb48abcd8a275a8810f277b"}, {type: "string", name: "result", value: `10106373226445018`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xe30fa1403978911fdd0b44a00ea72f8f734901bddfb48abcd8a275a8810f277b", `10106373226445018`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1491849074 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb47bcadec4a4cf6a62b17b80f18a6724e3fcba29"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABABvHrNqdAPKGZBzm7muqegj8di... )", async function( ) {
		const txOriginal = {blockNumber: "3513037", timeStamp: "1491861717", hash: "0x477a25c349ef7420f14864dd49442dbe2b6ece896498cd067eb96c3c81be79a4", nonce: "0", blockHash: "0x238fd505d88e581d8465c24307056d41337b41420292d545b1dabb305ee64946", transactionIndex: "6", from: "0xb5883450020f247f9333a090813652d01928ebba", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "382092", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d644069000000000000000000000000000000000000000000000000000000000000004000000000000000000000000012387fb64838b0de21505ae89611e78f1d411ae900000000000000000000000000000000000000000000000000000000000000b24541415962453345394d50414241427648724e716441504b475a427a6d376d757165676a3864693072345432784d346466754e577976435a43437844736e667143504c786f59673964377674554b4355655a43487845484d4367614b4c37416f3061794d34677935504235385a43515864684b506f4d515a4351665a41715a41436f5177584573673843434645687073324a79713834787549506f5479794a4573765553356b6872354f4c676b675a445a440000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "731143", gasUsed: "254727", confirmations: "4161376"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABABvHrNqdAPKGZBzm7muqegj8di0r4T2xM4dfuNWyvCZCCxDsnfqCPLxoYg9d7vtUKCUeZCHxEHMCgaKL7Ao0ayM4gy5PB58ZCQXdhKPoMQZCQfZAqZACoQwXEsg8CCFEhps2Jyq84xuIPoTyyJEsvUS5khr5OLgkgZDZD`}, {type: "address", name: "referrer", value: addressList[13]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABABvHrNqdAPKGZBzm7muqegj8di0r4T2xM4dfuNWyvCZCCxDsnfqCPLxoYg9d7vtUKCUeZCHxEHMCgaKL7Ao0ayM4gy5PB58ZCQXdhKPoMQZCQfZAqZACoQwXEsg8CCFEhps2Jyq84xuIPoTyyJEsvUS5khr5OLgkgZDZD`, addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1491861717 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "13226240002661247" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x5f762f81d5406efe71bf29c2ca2bcdedc384... )", async function( ) {
		const txOriginal = {blockNumber: "3513039", timeStamp: "1491861741", hash: "0x5fef89ddcff7f031878363f72b92248587e85297ddb1c65ed8cda41695a390fc", nonce: "75337", blockHash: "0x35ef2f95aec80dce0a63e82f76217781f0e1028ea94282cebb56fc088e0d6df9", transactionIndex: "5", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e5f762f81d5406efe71bf29c2ca2bcdedc38427371b45bed705fd977088565e580000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000f3132323137383639313635393930320000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "654548", gasUsed: "233005", confirmations: "4161374"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x5f762f81d5406efe71bf29c2ca2bcdedc38427371b45bed705fd977088565e58"}, {type: "string", name: "result", value: `122178691659902`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x5f762f81d5406efe71bf29c2ca2bcdedc38427371b45bed705fd977088565e58", `122178691659902`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1491861741 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb5883450020f247f9333a090813652d01928ebba"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x12387fb64838b0de21505ae89611e78f1d411ae9"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc491fd37f4528e0d139c8d85470cd221b6cafcd5"}, {name: "value", type: "uint256", value: "25000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xcce6da2086dd9348010a2813be49e58530852b46"}, {name: "value", type: "uint256", value: "12500000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "6250000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "3513381", timeStamp: "1491866688", hash: "0xeb810c965c1d0a0fd6c139a205eaad62af12496756c9b13829264d97a24a518d", nonce: "0", blockHash: "0x6c65ae028a1efdf09ecf47386559bdcab3c37594d2bb22f253626901af77540c", transactionIndex: "0", from: "0x3e48c1f346f1e70eeb011ca816a7e7acdb9c113b", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10000000000000000", gas: "4019748", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x3e48c1f346f1e70eeb011ca816a7e7acdb9c113b", contractAddress: "", cumulativeGasUsed: "4019748", gasUsed: "4019748", confirmations: "4161032"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "264487028506358" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAD5L0gpAlmpzMPtKOuxpz6WXz3... )", async function( ) {
		const txOriginal = {blockNumber: "3513934", timeStamp: "1491874759", hash: "0x47b7988f333fc8add9003180be50c8ac817b0c2b115f43d28c9b69ed1b4c7ec3", nonce: "92", blockHash: "0x9668f0eb0f97d402f7552c83450984844e9cb322074363b58b198fc0ebb8f22d", transactionIndex: "12", from: "0xd3b2f5d61226152410d6219d23544651b85d3f46", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "387016", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000253c5dd0df7e67e9c75a2a0075cfe3d382530a3900000000000000000000000000000000000000000000000000000000000000b94541415962453345394d5041424144354c306770416c6d707a4d50744b4f7578707a3657587a33424957684a644d7274515a42494576576c586f33466b71477a534c396c4e5753374f356d59506b456845346555365a425331765a433233613144754b7835355a415576646c3943705a4346727658696b4472506d324a7377324459595674764f594f7232756b724c416f5a41384d43376a78504b735a42427a4d334250754c52736f6573484c6e5a43356d634e5547736a4900000000000000", contractAddress: "", cumulativeGasUsed: "767555", gasUsed: "258010", confirmations: "4160479"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAD5L0gpAlmpzMPtKOuxpz6WXz3BIWhJdMrtQZBIEvWlXo3FkqGzSL9lNWS7O5mYPkEhE4eU6ZBS1vZC23a1DuKx55ZAUvdl9CpZCFrvXikDrPm2Jsw2DYYVtvOYOr2ukrLAoZA8MC7jxPKsZBBzM3BPuLRsoesHLnZC5mcNUGsjI`}, {type: "address", name: "referrer", value: addressList[9]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAD5L0gpAlmpzMPtKOuxpz6WXz3BIWhJdMrtQZBIEvWlXo3FkqGzSL9lNWS7O5mYPkEhE4eU6ZBS1vZC23a1DuKx55ZAUvdl9CpZCFrvXikDrPm2Jsw2DYYVtvOYOr2ukrLAoZA8MC7jxPKsZBBzM3BPuLRsoesHLnZC5mcNUGsjI`, addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1491874759 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "477260000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x4725e889ce1c1ada5c404a9ecb0bf76811a3... )", async function( ) {
		const txOriginal = {blockNumber: "3513938", timeStamp: "1491874838", hash: "0x4c33aeeb841ba9dae4725461504f4910728762bcd20aba2dbaa1550f11000bfa", nonce: "75346", blockHash: "0x03770b34e4729dd6c64d0f1b0e2cd3d8af9d0e941ae487158d72035aa72898c8", transactionIndex: "9", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e4725e889ce1c1ada5c404a9ecb0bf76811a3b251d01363a79d2fc960ec05b82e000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000103138333632343430343333363730313500000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "438257", gasUsed: "171361", confirmations: "4160475"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x4725e889ce1c1ada5c404a9ecb0bf76811a3b251d01363a79d2fc960ec05b82e"}, {type: "string", name: "result", value: `1836244043367015`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x4725e889ce1c1ada5c404a9ecb0bf76811a3b251d01363a79d2fc960ec05b82e", `1836244043367015`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1491874838 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd3b2f5d61226152410d6219d23544651b85d3f46"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAHP6z3jSTD1tvluZBgjqth2H4v... )", async function( ) {
		const txOriginal = {blockNumber: "3514061", timeStamp: "1491876699", hash: "0x7b097ca64301cb9a2af964ba8a65d12986d8f14d35f33317db97a572c73a09a7", nonce: "122", blockHash: "0xdf6b9ad6b5226e4a3876037338e6f2a75f2b541b33f3f5f8744870913254a613", transactionIndex: "0", from: "0x6af0474ae538ceea2b8da5cd368e111b89784a35", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "4092847", gasPrice: "21714488424", isError: "1", txreceipt_status: "", input: "0x5d64406900000000000000000000000000000000000000000000000000000000000000400000000000000000000000006af0474ae538ceea2b8da5cd368e111b89784a3500000000000000000000000000000000000000000000000000000000000000bc4541415962453345394d504142414850367a336a5354443174766c755a42676a7174683248347641536f6d505458646c4c565449536e304d32507a4f3277556a6e50737a385a416e64534544426d4772464c41795734466d39315a41326f586863694352554379494330427742725a414667566d625a436c487739795a4330676a416d6f5065416e5a4255704a4b6b7739575a414e794c6e5a41376561745a41715164645a416c556f384f6d6d4648443973614778584775684d443600000000", contractAddress: "", cumulativeGasUsed: "4092847", gasUsed: "4092847", confirmations: "4160352"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAHP6z3jSTD1tvluZBgjqth2H4vASomPTXdlLVTISn0M2PzO2wUjnPsz8ZAndSEDBmGrFLAyW4Fm91ZA2oXhciCRUCyIC0BwBrZAFgVmbZClHw9yZC0gjAmoPeAnZBUpJKkw9WZANyLnZA7eatZAqQddZAlUo8OmmFHD9saGxXGuhMD6`}, {type: "address", name: "referrer", value: addressList[22]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "4658385596965804" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[2], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "3514971", timeStamp: "1491890030", hash: "0x9ce88c139a52f744f45cda5b7d36c2d3ae2691cbd3ae15dd03974cca6e48fe46", nonce: "2", blockHash: "0x570a45fa9c421ba92ec8f3207e87edc3469f58e5295e8376d0e67da350edfaa3", transactionIndex: "10", from: "0x3e48c1f346f1e70eeb011ca816a7e7acdb9c113b", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "55039", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000007ed58877581d07bb4238a8b4d341e54c609b73c20000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "434735", gasUsed: "36692", confirmations: "4159442"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[2]}, {type: "uint256", name: "amount", value: "0"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[2], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1491890030 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x3e48c1f346f1e70eeb011ca816a7e7acdb9c113b"}, {name: "to", type: "address", value: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "value", type: "uint256", value: "0"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "264487028506358" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[23], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "3514986", timeStamp: "1491890293", hash: "0x1651ce20e7a9e5d0f93b4258064c27a7f3fa0dc19c7ff8dc458e931a05cbb29e", nonce: "3", blockHash: "0x78e708e1c21925761aedc9bbf3f25011762b77103b1677f02f576481fc8c1471", transactionIndex: "1", from: "0x3e48c1f346f1e70eeb011ca816a7e7acdb9c113b", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "55039", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000c9e1202a20593ae7dfab0c6b5e9463d2ab66a2d40000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "73838", gasUsed: "36692", confirmations: "4159427"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[23]}, {type: "uint256", name: "amount", value: "0"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[23], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1491890293 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x3e48c1f346f1e70eeb011ca816a7e7acdb9c113b"}, {name: "to", type: "address", value: "0xc9e1202a20593ae7dfab0c6b5e9463d2ab66a2d4"}, {name: "value", type: "uint256", value: "0"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "264487028506358" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[24], \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "3515125", timeStamp: "1491892349", hash: "0xcad712c1a336301e47f6ff630d970b339a570ad10870e7fdd18f0577a18d628a", nonce: "0", blockHash: "0xf785c563b29401936b460a374d581ccb6dc1ae6631ad3d23674dabee9ecef9a2", transactionIndex: "0", from: "0x67c82083315e0a76b80508b932abca9550c76b36", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "4064529", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000067c82083315e0a76b80508b932abca9550c76b360000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4064529", gasUsed: "4064529", confirmations: "4159288"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[24]}, {type: "uint256", name: "amount", value: "1"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "289420000000016" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAEpMvez0R7iHiAS3aSBDkZCUhc... )", async function( ) {
		const txOriginal = {blockNumber: "3515402", timeStamp: "1491896585", hash: "0xadda3f1b9218dcf88a1a6d8fa85577af414c25d6019783c25b7f5fe0dcc12a5f", nonce: "1", blockHash: "0x07882cff9e494f815a823915c94e600ccc4a3869c760385b2d8498e70607395a", transactionIndex: "25", from: "0xb0105ad402f83be5c73bd8f3617723b6830cc907", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "382092", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000c491fd37f4528e0d139c8d85470cd221b6cafcd500000000000000000000000000000000000000000000000000000000000000b24541415962453345394d5041424145704d76657a305237694869415333615342446b5a4355686338744261766e5a41424d676235584f3653737431624e317873497a335778396d644248685243477a48684d34744b5a43654a6734465150306b4a7a68414f723557754d52614e337564676d31695a4152476e74697855533555305a4159636952764159385a43575a4351795049704634544432776c35435644434765755677754f414f624647775a445a440000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "877353", gasUsed: "254727", confirmations: "4159011"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAEpMvez0R7iHiAS3aSBDkZCUhc8tBavnZABMgb5XO6Sst1bN1xsIz3Wx9mdBHhRCGzHhM4tKZCeJg4FQP0kJzhAOr5WuMRaN3udgm1iZARGntixUS5U0ZAYciRvAY8ZCWZCQyPIpF4TD2wl5CVDCGeuVwuOAObFGwZDZD`}, {type: "address", name: "referrer", value: addressList[12]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAEpMvez0R7iHiAS3aSBDkZCUhc8tBavnZABMgb5XO6Sst1bN1xsIz3Wx9mdBHhRCGzHhM4tKZCeJg4FQP0kJzhAOr5WuMRaN3udgm1iZARGntixUS5U0ZAYciRvAY8ZCWZCQyPIpF4TD2wl5CVDCGeuVwuOAObFGwZDZD`, addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1491896585 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "12279414005322700" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x22b77b753356167642fe5887d7512d4a2c3e... )", async function( ) {
		const txOriginal = {blockNumber: "3515406", timeStamp: "1491896657", hash: "0x2457a01b6ad4f76b4150c8732ed69f244bd15b39005a8d26f335d34694f08958", nonce: "75391", blockHash: "0x49a3cb3707884966b11255ba98dd67bc2c36b24161cdf2499f3df8a9541c084c", transactionIndex: "5", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e22b77b753356167642fe5887d7512d4a2c3e808a40d13e757b0b73d65ce02b99000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000103137393337353033333039353439343300000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "134701", gasUsed: "29701", confirmations: "4159007"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x22b77b753356167642fe5887d7512d4a2c3e808a40d13e757b0b73d65ce02b99"}, {type: "string", name: "result", value: `1793750330954943`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x22b77b753356167642fe5887d7512d4a2c3e808a40d13e757b0b73d65ce02b99", `1793750330954943`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1491896657 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAATOgR2yj3hkbfX0nN7AolbYFZ... )", async function( ) {
		const txOriginal = {blockNumber: "3515582", timeStamp: "1491899379", hash: "0x5ef1da9eb5c91b37f6774c5960d2773900cb91ecea5332585aafb3fff9aec3e3", nonce: "1", blockHash: "0x1d73dfd80aac507faf7d43df395baeb0a8abc87cc63294d52d420031eda7b43c", transactionIndex: "4", from: "0x0264c47270eed9859a6852548d142d0d7dbd5fb6", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "382809", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000c491fd37f4528e0d139c8d85470cd221b6cafcd500000000000000000000000000000000000000000000000000000000000000b34541415962453345394d5041424141544f675232796a33686b626658306e4e37416f6c6259465a41465a43436b4e4446524a58335a4254615a414f4c38306b3469364837693166305267536b36725250415a42735637384d507a5a4247757565615a434d534d6a36663950494a5142586c52796959524763716e79366f6342346b655051504930464336684c434a486b715a426c725149344e6576693533526e46734f7853614258414c7a72626d515a445a4400000000000000000000000000", contractAddress: "", cumulativeGasUsed: "402476", gasUsed: "255205", confirmations: "4158831"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAATOgR2yj3hkbfX0nN7AolbYFZAFZCCkNDFRJX3ZBTaZAOL80k4i6H7i1f0RgSk6rRPAZBsV78MPzZBGuueaZCMSMj6f9PIJQBXlRyiYRGcqny6ocB4kePQPI0FC6hLCJHkqZBlrQI4Nevi53RnFsOxSaBXALzrbmQZDZD`}, {type: "address", name: "referrer", value: addressList[12]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAATOgR2yj3hkbfX0nN7AolbYFZAFZCCkNDFRJX3ZBTaZAOL80k4i6H7i1f0RgSk6rRPAZBsV78MPzZBGuueaZCMSMj6f9PIJQBXlRyiYRGcqny6ocB4kePQPI0FC6hLCJHkqZBlrQI4Nevi53RnFsOxSaBXALzrbmQZDZD`, addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1491899379 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "120443896034883" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xa073f009189835e1821968cc688ff391ef3e... )", async function( ) {
		const txOriginal = {blockNumber: "3515590", timeStamp: "1491899460", hash: "0xbd91a60cf3b6276adb9191043ba8d50d3597762b3179e761d96a0708e1f47d0f", nonce: "75398", blockHash: "0x55577723451338bdb8d414a1d1076164215489fdefbedbd75202e75d1c934996", transactionIndex: "2", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297ea073f009189835e1821968cc688ff391ef3e4034520a832b2c6da7af6a05c42a000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000103137393337353033333039353439343300000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "81117", gasUsed: "29701", confirmations: "4158823"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xa073f009189835e1821968cc688ff391ef3e4034520a832b2c6da7af6a05c42a"}, {type: "string", name: "result", value: `1793750330954943`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xa073f009189835e1821968cc688ff391ef3e4034520a832b2c6da7af6a05c42a", `1793750330954943`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1491899460 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAIu3WIXi3mKfPyyqZBXiFw3YDZ... )", async function( ) {
		const txOriginal = {blockNumber: "3515616", timeStamp: "1491899740", hash: "0x36edb5464ceee9bc49947bd258cc48f5887a4179a33158c2087ea695396f3542", nonce: "2", blockHash: "0x45b332661819557f36e9017e713ea75d0a666d5f095873d6328c6c9cb1d649d3", transactionIndex: "4", from: "0x0264c47270eed9859a6852548d142d0d7dbd5fb6", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "384960", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000c491fd37f4528e0d139c8d85470cd221b6cafcd500000000000000000000000000000000000000000000000000000000000000b64541415962453345394d5041424149753357495869336d4b66507979715a42586946773359445a41456953506439337a5366503370645a4130377959505670584646556e744e5976777552657a796b4a706946755a426265365557787658676366585632613945555a4232785a4235553841465a4139366567545a4151473848674c4639764e384f664a5a436561795842707a5468776a4f645a4256504f47474939613562435136505665425a426d416f415a445a4400000000000000000000", contractAddress: "", cumulativeGasUsed: "1014271", gasUsed: "256639", confirmations: "4158797"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAIu3WIXi3mKfPyyqZBXiFw3YDZAEiSPd93zSfP3pdZA07yYPVpXFFUntNYvwuRezykJpiFuZBbe6UWxvXgcfXV2a9EUZB2xZB5U8AFZA96egTZAQG8HgLF9vN8OfJZCeayXBpzThwjOdZBVPOGGI9a5bCQ6PVeBZBmAoAZDZD`}, {type: "address", name: "referrer", value: addressList[12]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAIu3WIXi3mKfPyyqZBXiFw3YDZAEiSPd93zSfP3pdZA07yYPVpXFFUntNYvwuRezykJpiFuZBbe6UWxvXgcfXV2a9EUZB2xZB5U8AFZA96egTZAQG8HgLF9vN8OfJZCeayXBpzThwjOdZBVPOGGI9a5bCQ6PVeBZBmAoAZDZD`, addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1491899740 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "120443896034883" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xf82d9c340bd91071061f1d965e1969f94d55... )", async function( ) {
		const txOriginal = {blockNumber: "3515622", timeStamp: "1491899829", hash: "0x268bf6bbb7a1148ebee46e794a00b89247086135927a92a5b1ecd0e7d779be37", nonce: "75399", blockHash: "0x0aaf009e01519f22b30899c8d2bb3e29824f2fb0eca85764af8eed057fdeb626", transactionIndex: "5", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297ef82d9c340bd91071061f1d965e1969f94d5592d9a504bf1b6a7bec6c486b5a6d000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000103134333533393338383331393839303100000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "154445", gasUsed: "29701", confirmations: "4158791"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xf82d9c340bd91071061f1d965e1969f94d5592d9a504bf1b6a7bec6c486b5a6d"}, {type: "string", name: "result", value: `1435393883198901`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xf82d9c340bd91071061f1d965e1969f94d5592d9a504bf1b6a7bec6c486b5a6d", `1435393883198901`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1491899829 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABABAQjZCZBUcJ96pq0TPvdkfweA... )", async function( ) {
		const txOriginal = {blockNumber: "3515699", timeStamp: "1491900811", hash: "0x77b5007f530cc3d3b7b5d7639e3c59e66266ce6f30f30fc8df6bff7b3bcad4cc", nonce: "3", blockHash: "0x336478496a1ba837e0be4aeee15392574d76cca7c8b2b4fc9294443a7e09423f", transactionIndex: "3", from: "0x75e16a0a5efa7f0d3be945173dc9c3548381aa98", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "381996", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000253c5dd0df7e67e9c75a2a0075cfe3d382530a3900000000000000000000000000000000000000000000000000000000000000b24541415962453345394d504142414241516a5a435a4255634a3936707130545076646b6677654139536466644f5a4363757234364d3132304e6c526942326d76676973666957714637446434585a427a3239466a6a6664495a4276646b4b4644615a4342546b4345593378494e716a7255534f49464d47397057616771355546536d464e373964546f35646c5349383333634a53336c364b3869617a5339357663323034344b5a4154746b6476775a445a440000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "495109", gasUsed: "254663", confirmations: "4158714"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABABAQjZCZBUcJ96pq0TPvdkfweA9SdfdOZCcur46M120NlRiB2mvgisfiWqF7Dd4XZBz29FjjfdIZBvdkKFDaZCBTkCEY3xINqjrUSOIFMG9pWagq5UFSmFN79dTo5dlSI833cJS3l6K8iazS95vc2044KZATtkdvwZDZD`}, {type: "address", name: "referrer", value: addressList[9]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABABAQjZCZBUcJ96pq0TPvdkfweA9SdfdOZCcur46M120NlRiB2mvgisfiWqF7Dd4XZBz29FjjfdIZBvdkKFDaZCBTkCEY3xINqjrUSOIFMG9pWagq5UFSmFN79dTo5dlSI833cJS3l6K8iazS95vc2044KZATtkdvwZDZD`, addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1491900811 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "8855123239139482" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x1680631539a6981dc7a5267af7a6c3bfc1cb... )", async function( ) {
		const txOriginal = {blockNumber: "3515704", timeStamp: "1491900875", hash: "0x07f8eaa9ebd47ffcf1beb85d763c7bb4c797ac85e51ad0230fafe070e3417f14", nonce: "75404", blockHash: "0x38fa744dde3f938c34ea68aa77ea9ea656475a3c4f5b13f511f6e7d41dbef6ef", transactionIndex: "2", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e1680631539a6981dc7a5267af7a6c3bfc1cbbfa3cc03fd889f082f16d0dd57bf000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000103137353930323933323737363030353800000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "356815", gasUsed: "171361", confirmations: "4158709"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x1680631539a6981dc7a5267af7a6c3bfc1cbbfa3cc03fd889f082f16d0dd57bf"}, {type: "string", name: "result", value: `1759029327760058`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x1680631539a6981dc7a5267af7a6c3bfc1cbbfa3cc03fd889f082f16d0dd57bf", `1759029327760058`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1491900875 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x75e16a0a5efa7f0d3be945173dc9c3548381aa98"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[26], \"13300000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "3515737", timeStamp: "1491901366", hash: "0xb3c99934aa8c26bd613692ed2a69c104d93c90bb3247429a16c17550b8cf89a2", nonce: "4", blockHash: "0x5d0cc4ccf3414383c25f895d390b56e46c241d8d9b05e1a1a51e69868fc582da", transactionIndex: "5", from: "0x75e16a0a5efa7f0d3be945173dc9c3548381aa98", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "136693", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000000264c47270eed9859a6852548d142d0d7dbd5fb6000000000000000000000000000000000000000000000000b893178898b20000", contractAddress: "", cumulativeGasUsed: "201449", gasUsed: "52076", confirmations: "4158676"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[26]}, {type: "uint256", name: "amount", value: "13300000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[26], "13300000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1491901366 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x75e16a0a5efa7f0d3be945173dc9c3548381aa98"}, {name: "to", type: "address", value: "0x0264c47270eed9859a6852548d142d0d7dbd5fb6"}, {name: "value", type: "uint256", value: "13300000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "8855123239139482" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABALijM0FDOEuwVFzRZBxcwWzZAL... )", async function( ) {
		const txOriginal = {blockNumber: "3515886", timeStamp: "1491903581", hash: "0xc1f0b48940ff332f6912a85f262f65fab02a13555826d9d06718053ce8e52dfd", nonce: "0", blockHash: "0x436f8b9e8122e81e2314af5e541b898d54866bd9b78a99575d5fe92e4d9472c4", transactionIndex: "10", from: "0x771d4bb5cb9e2256582bb08c2d161d25cc9cc210", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "374202", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000c491fd37f4528e0d139c8d85470cd221b6cafcd500000000000000000000000000000000000000000000000000000000000000a74541415962453345394d504142414c696a4d3046444f45757756467a525a42786377577a5a414c67687276427a726f755a4233647479326332574e6f6764525a416d614d554734736647766c47306347503355554b774655583152625a41593455743336396c355a41766f6357364c503431564d5661355a4177666f474939325a4146357a564e5a436d683662673452657174564f367a6132424a7634656b716a35746e305a4400000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "734713", gasUsed: "249467", confirmations: "4158527"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABALijM0FDOEuwVFzRZBxcwWzZALghrvBzrouZB3dty2c2WNogdRZAmaMUG4sfGvlG0cGP3UUKwFUX1RbZAY4Ut369l5ZAvocW6LP41VMVa5ZAwfoGI92ZAF5zVNZCmh6bg4ReqtVO6za2BJv4ekqj5tn0ZD`}, {type: "address", name: "referrer", value: addressList[12]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABALijM0FDOEuwVFzRZBxcwWzZALghrvBzrouZB3dty2c2WNogdRZAmaMUG4sfGvlG0cGP3UUKwFUX1RbZAY4Ut369l5ZAvocW6LP41VMVa5ZAwfoGI92ZAF5zVNZCmh6bg4ReqtVO6za2BJv4ekqj5tn0ZD`, addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1491903581 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "21677992002661350" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x7095a5529739e509e717cb2cf50d08688ac2... )", async function( ) {
		const txOriginal = {blockNumber: "3515889", timeStamp: "1491903621", hash: "0x5ab0b415fe09910c08c43df94611a448ebcf8b41018dadd645aaeb3e47f13eda", nonce: "75412", blockHash: "0xded137c524c779fd47caeb8175c92bdaa39ad1417eaaff77ac619c4e9c347260", transactionIndex: "10", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e7095a5529739e509e717cb2cf50d08688ac26beed152c7bdba75e01e66ad76d40000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000f3238373833323030343937343832360000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "264016", gasUsed: "29669", confirmations: "4158524"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x7095a5529739e509e717cb2cf50d08688ac26beed152c7bdba75e01e66ad76d4"}, {type: "string", name: "result", value: `287832004974826`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x7095a5529739e509e717cb2cf50d08688ac26beed152c7bdba75e01e66ad76d4", `287832004974826`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1491903621 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAIqvlkjcjPhZCvXyX7qvqnUCWA... )", async function( ) {
		const txOriginal = {blockNumber: "3516364", timeStamp: "1491910733", hash: "0x7720e0c9a204eb47f825cd1513edf796fdf3e491a247c30b06ab7bfdc80a4d14", nonce: "0", blockHash: "0x58a68b4580075f1fe1687ef94236ad476ade51e0f64e1021ae1c0842d0ba99bd", transactionIndex: "0", from: "0x236911357d06cedb309f94981bf9734112bcbc26", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "382713", gasPrice: "21982848484", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000253c5dd0df7e67e9c75a2a0075cfe3d382530a3900000000000000000000000000000000000000000000000000000000000000b34541415962453345394d504142414971766c6b6a636a50685a4376587958377176716e55435741313966515954663845656a644c7a46616e3874427a4f76435a426b455230506935335a434a54587177647a6e4a36306c6c536b725a4354356678475537784c68334a6d304a5155764f304f5864433145733858383433534276443537575a435a415854436f4f454250775a436430357861414f714c716a544652523477544173325a4241376832415a445a4400000000000000000000000000", contractAddress: "", cumulativeGasUsed: "255141", gasUsed: "255141", confirmations: "4158049"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAIqvlkjcjPhZCvXyX7qvqnUCWA19fQYTf8EejdLzFan8tBzOvCZBkER0Pi53ZCJTXqwdznJ60llSkrZCT5fxGU7xLh3Jm0JQUvO0OXdC1Es8X843SBvD57WZCZAXTCoOEBPwZCd05xaAOqLqjTFRR4wTAs2ZBA7h2AZDZD`}, {type: "address", name: "referrer", value: addressList[9]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAIqvlkjcjPhZCvXyX7qvqnUCWA19fQYTf8EejdLzFan8tBzOvCZBkER0Pi53ZCJTXqwdznJ60llSkrZCT5fxGU7xLh3Jm0JQUvO0OXdC1Es8X843SBvD57WZCZAXTCoOEBPwZCd05xaAOqLqjTFRR4wTAs2ZBA7h2AZDZD`, addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1491910733 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "6760081653518840" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x221646af1331604727ab961fc570ee33bc59... )", async function( ) {
		const txOriginal = {blockNumber: "3516368", timeStamp: "1491910796", hash: "0xadd5dfcc2d844546fe5dd39873dbb6f0e1cf76f11127d7b2aa60ed117258f347", nonce: "75436", blockHash: "0x4751f3449dfe09e4d062b89630911c9b8d3af6f9cbafe799aad80854601d1f66", transactionIndex: "10", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e221646af1331604727ab961fc570ee33bc59915471a27123efaba79e50f8cdb8000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000103131323430303935393433393531313400000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "913178", gasUsed: "171361", confirmations: "4158045"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x221646af1331604727ab961fc570ee33bc59915471a27123efaba79e50f8cdb8"}, {type: "string", name: "result", value: `1124009594395114`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x221646af1331604727ab961fc570ee33bc59915471a27123efaba79e50f8cdb8", `1124009594395114`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1491910796 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x236911357d06cedb309f94981bf9734112bcbc26"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAD0LBHEfmZAIfQvG0IPZCzdriD... )", async function( ) {
		const txOriginal = {blockNumber: "3516440", timeStamp: "1491911664", hash: "0x15598b8f8c34ed6b86f2ee165fa6fc0d0a2ad0ae70164f4695db84bca3633e9c", nonce: "0", blockHash: "0x258a2aaf2d3471ec0c38b74620931d73ff6e745f3ef2e2332bde3307886ecfc5", transactionIndex: "5", from: "0xb7850981565650371b8b36e9354bbfbe1cda3d25", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "374824", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000253c5dd0df7e67e9c75a2a0075cfe3d382530a3900000000000000000000000000000000000000000000000000000000000000a84541415962453345394d5041424144304c424845666d5a4149665176473049505a437a647269446b4652775a41614e52346263334755517659444a3030394c78724f43505245763830655a42723967636f35555a4156584b4a59674d77545658473056505454594a395a43783254486f5a435a41333958334a5844574138485a4164653876564e5056426b784d6a686835514c3650676272355479766b595a427559484b766f5a44000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "380442", gasUsed: "249882", confirmations: "4157973"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAD0LBHEfmZAIfQvG0IPZCzdriDkFRwZAaNR4bc3GUQvYDJ009LxrOCPREv80eZBr9gco5UZAVXKJYgMwTVXG0VPTTYJ9ZCx2THoZCZA39X3JXDWA8HZAde8vVNPVBkxMjhh5QL6Pgbr5TyvkYZBuYHKvoZD`}, {type: "address", name: "referrer", value: addressList[9]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAD0LBHEfmZAIfQvG0IPZCzdriDkFRwZAaNR4bc3GUQvYDJ009LxrOCPREv80eZBr9gco5UZAVXKJYgMwTVXG0VPTTYJ9ZCx2THoZCZA39X3JXDWA8HZAde8vVNPVBkxMjhh5QL6Pgbr5TyvkYZBuYHKvoZD`, addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1491911664 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "249692002661350" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xde71643b64c2a9349dacdeccebc43b8b34a2... )", async function( ) {
		const txOriginal = {blockNumber: "3516443", timeStamp: "1491911735", hash: "0xfa6eddb396efa95f8c74731ace48bc7c2948e40332c5e05085c8acc8e614a3c2", nonce: "75439", blockHash: "0x462893785a0f5fee950c01a1245232052bf7f3300dc929bbd781cfdb9d9997f4", transactionIndex: "24", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297ede71643b64c2a9349dacdeccebc43b8b34a2a0283dc9a9fb1b24cf74fd82e24a000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000113130313538343934383131383035373136000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "745502", gasUsed: "171425", confirmations: "4157970"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xde71643b64c2a9349dacdeccebc43b8b34a2a0283dc9a9fb1b24cf74fd82e24a"}, {type: "string", name: "result", value: `10158494811805716`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xde71643b64c2a9349dacdeccebc43b8b34a2a0283dc9a9fb1b24cf74fd82e24a", `10158494811805716`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1491911735 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb7850981565650371b8b36e9354bbfbe1cda3d25"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAJm4ARZA9UR3TiIizGmrs81Cs4... )", async function( ) {
		const txOriginal = {blockNumber: "3516472", timeStamp: "1491912054", hash: "0xba085a99547fb9fff41e0d1232902da934fdc98ee1eae197e603d356147b700c", nonce: "0", blockHash: "0x6067b123ad99cfa76f559b070aa6d2f4a9620d9ae273070abdcbdb3a3cc5c144", transactionIndex: "6", from: "0xf96023abbbcc062bdf42800ba9a7b10ec3bf0723", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "371334", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000b7850981565650371b8b36e9354bbfbe1cda3d2500000000000000000000000000000000000000000000000000000000000000a34541415962453345394d504142414a6d3441525a4139555233546949697a476d72733831437334324264303642384d6c57564b62425839716e5374493332474b624e564179636273744f70393058463542545a41465a423165706550366278534a4165715743436a39624938576a4a6d78466b484c446b305974624c7178775265564a307572453362445a4238616236316151635a42434e316f666273794278345a440000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "396393", gasUsed: "247555", confirmations: "4157941"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAJm4ARZA9UR3TiIizGmrs81Cs42Bd06B8MlWVKbBX9qnStI32GKbNVAycbstOp90XF5BTZAFZB1epeP6bxSJAeqWCCj9bI8WjJmxFkHLDk0YtbLqxwReVJ0urE3bDZB8ab61aQcZBCN1ofbsyBx4ZD`}, {type: "address", name: "referrer", value: addressList[30]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAJm4ARZA9UR3TiIizGmrs81Cs42Bd06B8MlWVKbBX9qnStI32GKbNVAycbstOp90XF5BTZAFZB1epeP6bxSJAeqWCCj9bI8WjJmxFkHLDk0YtbLqxwReVJ0urE3bDZB8ab61aQcZBCN1ofbsyBx4ZD`, addressList[30], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1491912054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "4716232002661350" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x669e2219e63e7afde28239843da873bf4f77... )", async function( ) {
		const txOriginal = {blockNumber: "3516479", timeStamp: "1491912222", hash: "0x27c6f1a34541f07b984737fcd883b7736f2f4f803525c82590d94bf26d612222", nonce: "75441", blockHash: "0x9a4be2da9e51365ed15b4cb8797261fb7aa3778c81890682a9701fd42cd49cc3", transactionIndex: "8", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e669e2219e63e7afde28239843da873bf4f77ba5ccfba7385c7ef6ed9e4b185f50000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000f3430393235363033363131383837320000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "519524", gasUsed: "206866", confirmations: "4157934"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x669e2219e63e7afde28239843da873bf4f77ba5ccfba7385c7ef6ed9e4b185f5"}, {type: "string", name: "result", value: `409256036118872`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x669e2219e63e7afde28239843da873bf4f77ba5ccfba7385c7ef6ed9e4b185f5", `409256036118872`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1491912222 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf96023abbbcc062bdf42800ba9a7b10ec3bf0723"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb7850981565650371b8b36e9354bbfbe1cda3d25"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "25000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABAHkHWBcaw7SjSFzJwAldreqekn... )", async function( ) {
		const txOriginal = {blockNumber: "3516688", timeStamp: "1491915190", hash: "0x6db694f39e08ab5e23cc597d23424d81922cdddb2a71eedf105dcded9ae251fd", nonce: "4", blockHash: "0xfe9291f7b6bd6f6dc3fa69421c0082baa21442bc40184617c23b226cf26daa88", transactionIndex: "14", from: "0x3e48c1f346f1e70eeb011ca816a7e7acdb9c113b", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "367630", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000253c5dd0df7e67e9c75a2a0075cfe3d382530a39000000000000000000000000000000000000000000000000000000000000009f4541415962453345394d50414241486b48574263617737536a53467a4a77416c64726571656b6e586561776d4b545247526d43575872416532344c474e48435454544a6375786569444b69635770514255417a6b3259474a77784971385348476a635a42584271586453624d6f6f7238414b5968534c544d417664544962614866764c304c7833537949664e786e4a7666365930317472504d784944675a4400", contractAddress: "", cumulativeGasUsed: "739551", gasUsed: "245086", confirmations: "4157725"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABAHkHWBcaw7SjSFzJwAldreqeknXeawmKTRGRmCWXrAe24LGNHCTTTJcuxeiDKicWpQBUAzk2YGJwxIq8SHGjcZBXBqXdSbMoor8AKYhSLTMAvdTIbaHfvL0Lx3SyIfNxnJvf6Y01trPMxIDgZD`}, {type: "address", name: "referrer", value: addressList[9]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABAHkHWBcaw7SjSFzJwAldreqeknXeawmKTRGRmCWXrAe24LGNHCTTTJcuxeiDKicWpQBUAzk2YGJwxIq8SHGjcZBXBqXdSbMoor8AKYhSLTMAvdTIbaHfvL0Lx3SyIfNxnJvf6Y01trPMxIDgZD`, addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1491915190 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "264487028506358" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x2c8a27fa9412277443108800cea24f21a4d7... )", async function( ) {
		const txOriginal = {blockNumber: "3516691", timeStamp: "1491915246", hash: "0xa52cefebab65e0ad62652f76e6e0bd1f75d2ff21e9e0db6674566e6f87e90881", nonce: "75451", blockHash: "0x873a04c7c3abef9fbf283e57281273f0359a26c9a8c2c013987ad83672072032", transactionIndex: "23", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297e2c8a27fa9412277443108800cea24f21a4d7b3135daef8f3817e59393d6488a1000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000103135353832303138313432313434373100000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "873819", gasUsed: "171297", confirmations: "4157722"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x2c8a27fa9412277443108800cea24f21a4d7b3135daef8f3817e59393d6488a1"}, {type: "string", name: "result", value: `1558201814214471`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0x2c8a27fa9412277443108800cea24f21a4d7b3135daef8f3817e59393d6488a1", `1558201814214471`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1491915246 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x3e48c1f346f1e70eeb011ca816a7e7acdb9c113b"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABALb5R3fse8lmVXnLJFSopngVZB... )", async function( ) {
		const txOriginal = {blockNumber: "3516769", timeStamp: "1491916370", hash: "0xdd2e306d904a33ed6fc1c5379da5da2f59200698ed499b14109fd67fe22b435a", nonce: "24", blockHash: "0x467e4ebe4db67e02cd9f57bb7142ef822e8c1b64411202cc9486085bc5d79719", transactionIndex: "20", from: "0x4744c4ffaffc6c98fae4e33bb8993d7c87f29f3f", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "374106", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000253c5dd0df7e67e9c75a2a0075cfe3d382530a3900000000000000000000000000000000000000000000000000000000000000a74541415962453345394d504142414c62355233667365386c6d56586e4c4a46536f706e67565a42335a436d5a43726149524a556b7570654c413462684b544669564d366f555a435a434351386a556e736c3948764c365155306d3664346f634e37643853347769734d6b56347a6e6374443576634c564951645a436439493651483956636c613555506a325a414c7463735854656248465a423844345a4261656c375444555a4400000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "940549", gasUsed: "249403", confirmations: "4157644"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABALb5R3fse8lmVXnLJFSopngVZB3ZCmZCraIRJUkupeLA4bhKTFiVM6oUZCZCCQ8jUnsl9HvL6QU0m6d4ocN7d8S4wisMkV4znctD5vcLVIQdZCd9I6QH9Vcla5UPj2ZALtcsXTebHFZB8D4ZBael7TDUZD`}, {type: "address", name: "referrer", value: addressList[9]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "request_face_proof(string,address)" ]( `EAAYbE3E9MPABALb5R3fse8lmVXnLJFSopngVZB3ZCmZCraIRJUkupeLA4bhKTFiVM6oUZCZCCQ8jUnsl9HvL6QU0m6d4ocN7d8S4wisMkV4znctD5vcLVIQdZCd9I6QH9Vcla5UPj2ZALtcsXTebHFZB8D4ZBael7TDUZD`, addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1491916370 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABALb5R3fse8lmVXnLJFSopngVZB... )", async function( ) {
		const txOriginal = {blockNumber: "3516769", timeStamp: "1491916370", hash: "0x4965da7a5914f6e8a8a347cf84cc3babc1e6699e722ab402f043f4db8ee1fb75", nonce: "25", blockHash: "0x467e4ebe4db67e02cd9f57bb7142ef822e8c1b64411202cc9486085bc5d79719", transactionIndex: "24", from: "0x4744c4ffaffc6c98fae4e33bb8993d7c87f29f3f", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "374106", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000253c5dd0df7e67e9c75a2a0075cfe3d382530a3900000000000000000000000000000000000000000000000000000000000000a74541415962453345394d504142414c62355233667365386c6d56586e4c4a46536f706e67565a42335a436d5a43726149524a556b7570654c413462684b544669564d366f555a435a434351386a556e736c3948764c365155306d3664346f634e37643853347769734d6b56347a6e6374443576634c564951645a436439493651483956636c613555506a325a414c7463735854656248465a423844345a4261656c375444555a4400000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1448293", gasUsed: "374106", confirmations: "4157644"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABALb5R3fse8lmVXnLJFSopngVZB3ZCmZCraIRJUkupeLA4bhKTFiVM6oUZCZCCQ8jUnsl9HvL6QU0m6d4ocN7d8S4wisMkV4znctD5vcLVIQdZCd9I6QH9Vcla5UPj2ZALtcsXTebHFZB8D4ZBael7TDUZD`}, {type: "address", name: "referrer", value: addressList[9]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABALb5R3fse8lmVXnLJFSopngVZB... )", async function( ) {
		const txOriginal = {blockNumber: "3516769", timeStamp: "1491916370", hash: "0xcb9edea0e0642f20fff99041e3eea736aab90c8f7a1bb58114a8d534d1aafe5a", nonce: "26", blockHash: "0x467e4ebe4db67e02cd9f57bb7142ef822e8c1b64411202cc9486085bc5d79719", transactionIndex: "31", from: "0x4744c4ffaffc6c98fae4e33bb8993d7c87f29f3f", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "374106", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000253c5dd0df7e67e9c75a2a0075cfe3d382530a3900000000000000000000000000000000000000000000000000000000000000a74541415962453345394d504142414c62355233667365386c6d56586e4c4a46536f706e67565a42335a436d5a43726149524a556b7570654c413462684b544669564d366f555a435a434351386a556e736c3948764c365155306d3664346f634e37643853347769734d6b56347a6e6374443576634c564951645a436439493651483956636c613555506a325a414c7463735854656248465a423844345a4261656c375444555a4400000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2027881", gasUsed: "374106", confirmations: "4157644"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABALb5R3fse8lmVXnLJFSopngVZB3ZCmZCraIRJUkupeLA4bhKTFiVM6oUZCZCCQ8jUnsl9HvL6QU0m6d4ocN7d8S4wisMkV4znctD5vcLVIQdZCd9I6QH9Vcla5UPj2ZALtcsXTebHFZB8D4ZBael7TDUZD`}, {type: "address", name: "referrer", value: addressList[9]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xfba1b017aad9a139c2a133f65c1dfd186677... )", async function( ) {
		const txOriginal = {blockNumber: "3516769", timeStamp: "1491916370", hash: "0x127a82a55168ff1fb76900c01cd6976d4eb70290c641c6b8289dab93dc6f9e48", nonce: "75456", blockHash: "0x467e4ebe4db67e02cd9f57bb7142ef822e8c1b64411202cc9486085bc5d79719", transactionIndex: "37", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x27dc297efba1b017aad9a139c2a133f65c1dfd18667724494f6ca2e33c44e50930767610000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000113130313534353335343431383135373533000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2381822", gasUsed: "171425", confirmations: "4157644"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xfba1b017aad9a139c2a133f65c1dfd18667724494f6ca2e33c44e50930767610"}, {type: "string", name: "result", value: `10154535441815753`}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string)" ]( "0xfba1b017aad9a139c2a133f65c1dfd18667724494f6ca2e33c44e50930767610", `10154535441815753`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1491916370 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x4744c4ffaffc6c98fae4e33bb8993d7c87f29f3f"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: request_face_proof( `EAAYbE3E9MPABALb5R3fse8lmVXnLJFSopngVZB... )", async function( ) {
		const txOriginal = {blockNumber: "3516769", timeStamp: "1491916370", hash: "0x97e720726cf884582122339f3f82cebfe0091ce2340ee2481a261951c6ea08ce", nonce: "27", blockHash: "0x467e4ebe4db67e02cd9f57bb7142ef822e8c1b64411202cc9486085bc5d79719", transactionIndex: "45", from: "0x4744c4ffaffc6c98fae4e33bb8993d7c87f29f3f", to: "0x7ed58877581d07bb4238a8b4d341e54c609b73c2", value: "10332667997338650", gas: "374106", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x5d6440690000000000000000000000000000000000000000000000000000000000000040000000000000000000000000253c5dd0df7e67e9c75a2a0075cfe3d382530a3900000000000000000000000000000000000000000000000000000000000000a74541415962453345394d504142414c62355233667365386c6d56586e4c4a46536f706e67565a42335a436d5a43726149524a556b7570654c413462684b544669564d366f555a435a434351386a556e736c3948764c365155306d3664346f634e37643853347769734d6b56347a6e6374443576634c564951645a436439493651483956636c613555506a325a414c7463735854656248465a423844345a4261656c375444555a4400000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2920644", gasUsed: "374106", confirmations: "4157644"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "10332667997338650" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "facebook_user_access_token", value: `EAAYbE3E9MPABALb5R3fse8lmVXnLJFSopngVZB3ZCmZCraIRJUkupeLA4bhKTFiVM6oUZCZCCQ8jUnsl9HvL6QU0m6d4ocN7d8S4wisMkV4znctD5vcLVIQdZCd9I6QH9Vcla5UPj2ZALtcsXTebHFZB8D4ZBael7TDUZD`}, {type: "address", name: "referrer", value: addressList[9]}], name: "request_face_proof", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "62609793139810" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
