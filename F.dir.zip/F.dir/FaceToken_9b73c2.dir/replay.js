var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "FaceToken"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0x7Ed58877581d07bB4238a8B4D341E54C609b73c2","0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed","0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1","0xB7A07BcF2Ba2f2703b24C0691b5278999C59AC7e","0x6f485C8BF6fc43eA212E93BBF8ce046C7f1cb475","0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF","0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA","0x253C5dD0dF7e67E9c75A2A0075CFE3D382530A39","0xCCe6DA2086DD9348010a2813be49E58530852b46","0x26588a9301b0428d95e6Fc3A5024fcE8BEc12D51","0xC491Fd37F4528e0D139c8d85470cD221B6cAfcd5","0x12387fb64838b0De21505Ae89611e78F1d411ae9","0xC1639a863381b265A076A862162A1a3CDC97b0Fb","0x042910c61bf20D5B1BD15A166db5b37459F8Ea98","0xdD41a4108D31830BD4e8A9B9e453585227A5f295","0x7bf6926bcf01507D5A5600F49D1650540cDAad48","0xb47bCadEC4A4cF6A62b17B80f18a6724E3fcBa29","0xb5883450020f247f9333A090813652d01928ebbA","0x3e48c1f346f1e70EEb011Ca816A7E7acDB9C113B","0xd3B2F5d61226152410d6219d23544651B85D3f46","0x6AF0474ae538cEea2B8dA5Cd368E111b89784A35","0xC9e1202a20593aE7dFaB0c6B5E9463d2Ab66a2D4","0x67c82083315e0a76B80508b932aBca9550C76B36","0xb0105aD402F83be5c73Bd8F3617723B6830cC907","0x0264c47270eed9859A6852548D142D0d7Dbd5fb6","0x75e16A0a5eFa7f0d3be945173dc9C3548381Aa98","0x771d4bB5cb9E2256582bB08C2D161D25cc9CC210","0x236911357d06CEDb309F94981BF9734112bCbC26","0xB7850981565650371B8b36E9354BbFbe1cDa3d25","0xf96023AbBBCC062Bdf42800Ba9A7b10eC3Bf0723","0x4744C4FfaFFc6c98FAe4E33bB8993d7C87f29F3F"]
addressListOriginal.length = 33
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"members","outputs":[{"name":"addr","type":"address"},{"name":"referrer","type":"address"},{"name":"approved","type":"bool"},{"name":"id","type":"bytes32"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"addr","type":"address"},{"name":"level","type":"uint256"}],"name":"level_referrals_count_by_address","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"isOpened","outputs":[{"name":"","type":"bool"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"getTransactionPrice","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"startSpreadingBlock","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"addr","type":"address"}],"name":"all_referrals_count_by_address","outputs":[{"name":"count","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"balanceOf","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"maxSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"}]
eventPrototypeListOriginal = [{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"}]
eventSignatureListOriginal = ["Transfer(address,address,uint256)"]
topicListOriginal = ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"]
nBlocksOriginal = 50
fromBlockOriginal = 3495452
toBlockOriginal = 3516769
constructorPrototypeOriginal = {"inputs":[],"name":"FaceToken","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"3495452","timeStamp":"1491601357","hash":"0xfa88d25c14970fe71042b2750d5dbf450a2131ab5150fec22aec60d21b506311","nonce":"0","blockHash":"0x9cb37304afe1206f633d81fed9299da026c2e6ca6e9e68b17215acadcca56929","transactionIndex":"0","from":"0x253c5dd0df7e67e9c75a2a0075cfe3d382530a39","to":0,"value":"0","gas":"4247813","gasPrice":"20000000000","isError":"0","txreceipt_status":"","input":"0x61c05c07","contractAddress":"0x7ed58877581d07bb4238a8b4d341e54c609b73c2","cumulativeGasUsed":"2314743","gasUsed":"2314743","confirmations":"4178961"}
txOptions[0] = {"from":"0x3E5e9111Ae8eB78Fe1CC3bb8915d5D461F3Ef9A9","to":0,"value":"0"}
txCall[0] = {"inputs":[],"name":"FaceToken","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
