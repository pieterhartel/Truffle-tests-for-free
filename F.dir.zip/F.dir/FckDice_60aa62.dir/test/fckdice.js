const FckDice = artifacts.require( "./FckDice.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "FckDice" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x0bE3e6E3d9E99036CcCE4fD0b692016DE860aA62", "0x08a6268b1362b02f6473ec22Fac93795353F5173", "0xd81f6028509B1C38C48abD2e5Ca6F28889EBBD4D", "0x5a5f158fb01B03A9df99337386516eBCbD1B93eB", "0x01FD2b8c9C81044D37352704F1ce9adA7E1b6AE2", "0x088900C93556a2D1a92ecE502D7A7414b2B79177", "0x9b21000EA7055223005d07d30791c8493f62BE59", "0x60F4c86457c1954c0ca963dc03534C3311967bEB"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "JACKPOT_MODULO", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "MIN_JACKPOT_BET", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "secretSigner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner2", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "HOUSE_EDGE_OF_TEN_THOUSAND", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "jackpotSize", outputs: [{name: "", type: "uint128"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "croupier", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner1", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "commit", type: "uint256"}], name: "getBetInfo", outputs: [{name: "amount", type: "uint256"}, {name: "modulo", type: "uint8"}, {name: "rollUnder", type: "uint8"}, {name: "placeBlockNumber", type: "uint40"}, {name: "mask", type: "uint240"}, {name: "gambler", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxProfit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "HOUSE_EDGE_MINIMUM_AMOUNT", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "JACKPOT_FEE", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "lockedInBets", outputs: [{name: "", type: "uint128"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "FailedPayment", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "JackpotPayment", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["FailedPayment(address,uint256)", "Payment(address,uint256)", "JackpotPayment(address,uint256)", "Commit(uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xac464fe4d3a86b9121261ac0a01dd981bfe0777c7c9d9c8f4473d31a9c0f9d2d", "0xd4f43975feb89f48dd30cabbb32011045be187d1e11c8ea9faa43efc35282519", "0xc388db0e8aa560a59633c094a0d0aa21322cd6234836fd5bac00fc5ae63b5783", "0x5bdd2fc99022530157777690475b670d3872f32262eb1d47d9ba8000dad58f87"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6615939 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6616140 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_owner1", value: 3}, {type: "address", name: "_owner2", value: 4}, {type: "address", name: "_secretSigner", value: 5}, {type: "address", name: "_croupier", value: 6}, {type: "uint256", name: "_maxProfit", value: "5000000000000000000"}], name: "FckDice", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "JACKPOT_MODULO", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "JACKPOT_MODULO()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MIN_JACKPOT_BET", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MIN_JACKPOT_BET()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "secretSigner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "secretSigner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner2", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner2()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "HOUSE_EDGE_OF_TEN_THOUSAND", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "HOUSE_EDGE_OF_TEN_THOUSAND()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "jackpotSize", outputs: [{name: "", type: "uint128"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "jackpotSize()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "croupier", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "croupier()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner1", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner1()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "commit", value: random.range( maxRandom )}], name: "getBetInfo", outputs: [{name: "amount", type: "uint256"}, {name: "modulo", type: "uint8"}, {name: "rollUnder", type: "uint8"}, {name: "placeBlockNumber", type: "uint40"}, {name: "mask", type: "uint240"}, {name: "gambler", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBetInfo(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxProfit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "HOUSE_EDGE_MINIMUM_AMOUNT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "HOUSE_EDGE_MINIMUM_AMOUNT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "JACKPOT_FEE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "JACKPOT_FEE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "lockedInBets", outputs: [{name: "", type: "uint128"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lockedInBets()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "FckDice", function( accounts ) {

	it( "TEST: FckDice( addressList[3], addressList[4], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6615939", timeStamp: "1540966336", hash: "0xdc67987596018df5356c59b6f171b1e5c27c7da672a4772be11274b10eba8dbb", nonce: "175", blockHash: "0x03b807f6d23812d9fab9e33a5cb10c59b29bf27c7f39dd9fdcf6455f45de72a6", transactionIndex: "6", from: "0x08a6268b1362b02f6473ec22fac93795353f5173", to: 0, value: "10000000000000000000", gas: "7000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x66a50aee00000000000000000000000008a6268b1362b02f6473ec22fac93795353f5173000000000000000000000000d81f6028509b1c38c48abd2e5ca6f28889ebbd4d0000000000000000000000005a5f158fb01b03a9df99337386516ebcbd1b93eb00000000000000000000000001fd2b8c9c81044d37352704f1ce9ada7e1b6ae20000000000000000000000000000000000000000000000004563918244f40000", contractAddress: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", cumulativeGasUsed: "2600063", gasUsed: "2409478", confirmations: "1115936"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "10000000000000000000" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_owner1", value: addressList[3]}, {type: "address", name: "_owner2", value: addressList[4]}, {type: "address", name: "_secretSigner", value: addressList[5]}, {type: "address", name: "_croupier", value: addressList[6]}, {type: "uint256", name: "_maxProfit", value: "5000000000000000000"}], name: "FckDice", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = FckDice.new( addressList[3], addressList[4], addressList[5], addressList[6], "5000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540966336 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = FckDice.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "12442003389975195" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6615986", timeStamp: "1540966938", hash: "0xac636977c8de5b83cc8b4b7943b2994ed6984f48d13b58cf2a18b64974ada9bd", nonce: "177", blockHash: "0x1d2e7d9cb41fc627b13c199121c0d4fb9f05221988044e641adccc7c805abe0d", transactionIndex: "218", from: "0x08a6268b1362b02f6473ec22fac93795353f5173", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "329000000000000000000", gas: "31560", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "7350633", gasUsed: "21040", confirmations: "1115889"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "329000000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540966938 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "12442003389975195" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"1\", \"6\", \"6616233\", \"11522911670... )", async function( ) {
		const txOriginal = {blockNumber: "6615990", timeStamp: "1540967010", hash: "0xd4d20b7edf88d92e9fdcfe69286f583d110edcb82ad8ad48063ca1d7d6f2b042", nonce: "178", blockHash: "0x6c13d72b82b100a3e69e31388b6faa44761f07228a469198081aedfe38a03d79", transactionIndex: "63", from: "0x08a6268b1362b02f6473ec22fac93795353f5173", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "100000000000000000", gas: "150000", gasPrice: "9860000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000064f4a91979bca46a07f78e34d4989598581bd7a2c05f3351b7b40fac4c110e1a36f74d5aeba2aeb5e887d71af9a938da54de4821984fd81358d15a09a2591909dc454b0f2ddafd5a5cec2d422c784d6c099ccfd6dc4f0cbcf2a5e0c58f492305f311f3", contractAddress: "", cumulativeGasUsed: "3250225", gasUsed: "138600", confirmations: "1115885"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "1"}, {type: "uint256", name: "modulo", value: "6"}, {type: "uint256", name: "commitLastBlock", value: "6616233"}, {type: "uint256", name: "commit", value: "11522911670330674608092798302399043281650699242431624273410004717661123442509"}, {type: "bytes32", name: "r", value: "0x5aeba2aeb5e887d71af9a938da54de4821984fd81358d15a09a2591909dc454b"}, {type: "bytes32", name: "s", value: "0x0f2ddafd5a5cec2d422c784d6c099ccfd6dc4f0cbcf2a5e0c58f492305f311f3"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "1", "6", "6616233", "11522911670330674608092798302399043281650699242431624273410004717661123442509", "0x5aeba2aeb5e887d71af9a938da54de4821984fd81358d15a09a2591909dc454b", "0x0f2ddafd5a5cec2d422c784d6c099ccfd6dc4f0cbcf2a5e0c58f492305f311f3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540967010 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "11522911670330674608092798302399043281650699242431624273410004717661123442509"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "12442003389975195" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0xb91cce1438285c6a10188eb1ea0032b660d4... )", async function( ) {
		const txOriginal = {blockNumber: "6615993", timeStamp: "1540967030", hash: "0x81b14e8f0781bd9524f024a6846f0a5b50e606148dc510b1a39e4458ee693d58", nonce: "12990", blockHash: "0x9abc3ea5b722e9852a1511a117a517c391084ea1f1edc73566bb56fd99024374", transactionIndex: "33", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10621093750", isError: "0", txreceipt_status: "1", input: "0xe163b75bb91cce1438285c6a10188eb1ea0032b660d450e8000000000000000000000000a48fbb03a15cc2fb3636d8ddfe7f26d7dd5c0b760000000000000000000000006c13d72b82b100a3e69e31388b6faa44761f07228a469198081aedfe38a03d79", contractAddress: "", cumulativeGasUsed: "1767402", gasUsed: "36281", confirmations: "1115882"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0xb91cce1438285c6a10188eb1ea0032b660d450e8"}, {type: "bytes20", name: "reveal2", value: "0xa48fbb03a15cc2fb3636d8ddfe7f26d7dd5c0b76"}, {type: "bytes32", name: "blockHash", value: "0x6c13d72b82b100a3e69e31388b6faa44761f07228a469198081aedfe38a03d79"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0xb91cce1438285c6a10188eb1ea0032b660d450e8", "0xa48fbb03a15cc2fb3636d8ddfe7f26d7dd5c0b76", "0x6c13d72b82b100a3e69e31388b6faa44761f07228a469198081aedfe38a03d79", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540967030 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x08a6268b1362b02f6473ec22fac93795353f5173"}, {name: "amount", type: "uint256", value: "0"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"1\", \"2\", \"6616264\", \"94052829834... )", async function( ) {
		const txOriginal = {blockNumber: "6616023", timeStamp: "1540967451", hash: "0x350e09b870df29d8f4bebf612c0dee60cd3aacd2ba6e105938f5f24a12f2e070", nonce: "0", blockHash: "0x6fcc45b4265cf8f4ee89f58278902fe1d0e100e15bef230bbbccd28930249eb4", transactionIndex: "134", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "400000000000000000", gas: "150000", gasPrice: "9450000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f4c8cff003e5209820fee3ed7be346a5badb70141d15b21ffd1cc6d0b2c50a967eb4d9e8c70b3ccd12b2a62dde9ced5ff7cd01e6a09306385c242d091a25272208505e84ef2d1dd90462076b3645da16ede75110a3cb3980bd0be1a9996da1f16886", contractAddress: "", cumulativeGasUsed: "5660685", gasUsed: "123600", confirmations: "1115852"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "1"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616264"}, {type: "uint256", name: "commit", value: "94052829834782357310128030968953814781321932181854483006726563082483935903412"}, {type: "bytes32", name: "r", value: "0xd9e8c70b3ccd12b2a62dde9ced5ff7cd01e6a09306385c242d091a2527220850"}, {type: "bytes32", name: "s", value: "0x5e84ef2d1dd90462076b3645da16ede75110a3cb3980bd0be1a9996da1f16886"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "1", "2", "6616264", "94052829834782357310128030968953814781321932181854483006726563082483935903412", "0xd9e8c70b3ccd12b2a62dde9ced5ff7cd01e6a09306385c242d091a2527220850", "0x5e84ef2d1dd90462076b3645da16ede75110a3cb3980bd0be1a9996da1f16886", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540967451 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[4,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "94052829834782357310128030968953814781321932181854483006726563082483935903412"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[4,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x0116f0f942e13b7f99e816d71a4f675ea310... )", async function( ) {
		const txOriginal = {blockNumber: "6616026", timeStamp: "1540967504", hash: "0x467a4e8aeee29d29c5a46f7fde0f2a155d771fd3181993f131c28ea7011cf8c3", nonce: "12991", blockHash: "0x1ded7583f6a249ae55f21cb9a73855e96ed4bf9ee4f2905631d71fb054cf1166", transactionIndex: "26", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75b0116f0f942e13b7f99e816d71a4f675ea3101b410000000000000000000000002802c06e86d657e8698356a574128963d16403a80000000000000000000000006fcc45b4265cf8f4ee89f58278902fe1d0e100e15bef230bbbccd28930249eb4", contractAddress: "", cumulativeGasUsed: "1014862", gasUsed: "36319", confirmations: "1115849"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x0116f0f942e13b7f99e816d71a4f675ea3101b41"}, {type: "bytes20", name: "reveal2", value: "0x2802c06e86d657e8698356a574128963d16403a8"}, {type: "bytes32", name: "blockHash", value: "0x6fcc45b4265cf8f4ee89f58278902fe1d0e100e15bef230bbbccd28930249eb4"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x0116f0f942e13b7f99e816d71a4f675ea3101b41", "0x2802c06e86d657e8698356a574128963d16403a8", "0x6fcc45b4265cf8f4ee89f58278902fe1d0e100e15bef230bbbccd28930249eb4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540967504 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "790160000000000000"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"1\", \"2\", \"6616270\", \"53449193817... )", async function( ) {
		const txOriginal = {blockNumber: "6616031", timeStamp: "1540967571", hash: "0xc2390483360d6c014cf8adce7553bfa29bf14a43254ae7bcb253c09e036a4416", nonce: "1", blockHash: "0x4ce56173b6f5938c6e7ccf70fdfe1d8520041eb01bec8b3c0e3d6a592f56e677", transactionIndex: "64", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "150000000000000000", gas: "150000", gasPrice: "7950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f4ce762b2bf0902dc2b6348c4ace0b7989554621cab4a41a6fdc8299511bf4dbf865d25c7f76118eb23117d93b7d4ff3deeef7c7b7f4cc5ff3558a89e88298dff3e21e58020c9b755221c5d678fb32c61c7d39b9359c070c82ff16d33772276b6283", contractAddress: "", cumulativeGasUsed: "2874765", gasUsed: "123600", confirmations: "1115844"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "150000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "1"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616270"}, {type: "uint256", name: "commit", value: "53449193817274811280864417260328380564119077651528232194600433154795209750629"}, {type: "bytes32", name: "r", value: "0xd25c7f76118eb23117d93b7d4ff3deeef7c7b7f4cc5ff3558a89e88298dff3e2"}, {type: "bytes32", name: "s", value: "0x1e58020c9b755221c5d678fb32c61c7d39b9359c070c82ff16d33772276b6283"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "1", "2", "6616270", "53449193817274811280864417260328380564119077651528232194600433154795209750629", "0xd25c7f76118eb23117d93b7d4ff3deeef7c7b7f4cc5ff3558a89e88298dff3e2", "0x1e58020c9b755221c5d678fb32c61c7d39b9359c070c82ff16d33772276b6283", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540967571 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[6,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "53449193817274811280864417260328380564119077651528232194600433154795209750629"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[6,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x5ea69d25e07bb3e64daf1773f3813e85fee0... )", async function( ) {
		const txOriginal = {blockNumber: "6616035", timeStamp: "1540967604", hash: "0x84d2dfa6031a734a254c6ea6077b2c7948f0a5065b6e682b1b844cdd006e90fc", nonce: "12992", blockHash: "0x61a68b5f9d75ab088fa0c60dd6ecab1d5e0fece8b6843bd7fd8908bc9c08bc4b", transactionIndex: "24", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75b5ea69d25e07bb3e64daf1773f3813e85fee01601000000000000000000000000634f2d64930cef63fb0e58748639532658f8c47f0000000000000000000000004ce56173b6f5938c6e7ccf70fdfe1d8520041eb01bec8b3c0e3d6a592f56e677", contractAddress: "", cumulativeGasUsed: "1322511", gasUsed: "36409", confirmations: "1115840"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x5ea69d25e07bb3e64daf1773f3813e85fee01601"}, {type: "bytes20", name: "reveal2", value: "0x634f2d64930cef63fb0e58748639532658f8c47f"}, {type: "bytes32", name: "blockHash", value: "0x4ce56173b6f5938c6e7ccf70fdfe1d8520041eb01bec8b3c0e3d6a592f56e677"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x5ea69d25e07bb3e64daf1773f3813e85fee01601", "0x634f2d64930cef63fb0e58748639532658f8c47f", "0x4ce56173b6f5938c6e7ccf70fdfe1d8520041eb01bec8b3c0e3d6a592f56e677", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540967604 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "0"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"38\", \"100\", \"6616277\", \"46487629... )", async function( ) {
		const txOriginal = {blockNumber: "6616036", timeStamp: "1540967621", hash: "0x9c565b54aa46c40937012553f42f9d7de220ce24ab4d6fcbb7456a61bf29aef9", nonce: "1417", blockHash: "0x43d979c834d5e0ca062f8d16ed4edde86af77048b6660ce04863a327352f6c4c", transactionIndex: "41", from: "0x9b21000ea7055223005d07d30791c8493f62be59", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "580000000000000000", gas: "150000", gasPrice: "9050000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000260000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000064f4d50a471b4a28d39c9ee122123cd75b53bd6a8e1258740e204dd3fe5a9c292d1b87f65d454c330630edf79a59233b409e70aaec199fc74d5eaed7ffc77c2df0f30a413498a3c771d4e6bf7005a920573680d5b0f97599974b1bdb52c72926e11187", contractAddress: "", cumulativeGasUsed: "1895251", gasUsed: "108682", confirmations: "1115839"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "580000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "38"}, {type: "uint256", name: "modulo", value: "100"}, {type: "uint256", name: "commitLastBlock", value: "6616277"}, {type: "uint256", name: "commit", value: "4648762973918889597281468272101610141033658056188554757821785124824494709639"}, {type: "bytes32", name: "r", value: "0xf65d454c330630edf79a59233b409e70aaec199fc74d5eaed7ffc77c2df0f30a"}, {type: "bytes32", name: "s", value: "0x413498a3c771d4e6bf7005a920573680d5b0f97599974b1bdb52c72926e11187"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "38", "100", "6616277", "4648762973918889597281468272101610141033658056188554757821785124824494709639", "0xf65d454c330630edf79a59233b409e70aaec199fc74d5eaed7ffc77c2df0f30a", "0x413498a3c771d4e6bf7005a920573680d5b0f97599974b1bdb52c72926e11187", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540967621 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "4648762973918889597281468272101610141033658056188554757821785124824494709639"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x5f5ce7e45bddcfddabbe4e6efdba0b9a5976... )", async function( ) {
		const txOriginal = {blockNumber: "6616040", timeStamp: "1540967645", hash: "0x0f2203f737bb0105a9d31ea4868c21b2fa4eb8adab2807a6a0919e3233a9e697", nonce: "12993", blockHash: "0xa6217b1361ab51052d519f7c58b6b90cf88c5763e6c59a124f01047d197675b0", transactionIndex: "14", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75b5f5ce7e45bddcfddabbe4e6efdba0b9a5976c9df00000000000000000000000008d17e354b42220faa094897e5124316dbf8bef200000000000000000000000043d979c834d5e0ca062f8d16ed4edde86af77048b6660ce04863a327352f6c4c", contractAddress: "", cumulativeGasUsed: "1013189", gasUsed: "35926", confirmations: "1115835"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x5f5ce7e45bddcfddabbe4e6efdba0b9a5976c9df"}, {type: "bytes20", name: "reveal2", value: "0x08d17e354b42220faa094897e5124316dbf8bef2"}, {type: "bytes32", name: "blockHash", value: "0x43d979c834d5e0ca062f8d16ed4edde86af77048b6660ce04863a327352f6c4c"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x5f5ce7e45bddcfddabbe4e6efdba0b9a5976c9df", "0x08d17e354b42220faa094897e5124316dbf8bef2", "0x43d979c834d5e0ca062f8d16ed4edde86af77048b6660ce04863a327352f6c4c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540967645 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x9b21000ea7055223005d07d30791c8493f62be59"}, {name: "amount", type: "uint256", value: "0"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"1\", \"2\", \"6616282\", \"22283886784... )", async function( ) {
		const txOriginal = {blockNumber: "6616041", timeStamp: "1540967660", hash: "0x230eeb02c14395d901f6eaabe348a3a86e0900990a91035035d3193075e8d51e", nonce: "2", blockHash: "0xba6ff3732cdbb734b8e4cb5b75d3ce4d91803c3999d9326d36bbbedfecd018bd", transactionIndex: "31", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "200000000000000000", gas: "150000", gasPrice: "10950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f4da31443ba33c68f92b81136be15f32730a0e2edd0d89a72d0b33be18912381bed36d6d2bf84b5f083f8c1a43132bfcf91c4b2b8f57bf3c38948d0edd59f14ac0835bc8cbc2ec861ff7d153bdd55835059a64e1144926ac601fbf4e01e52dc0b820", contractAddress: "", cumulativeGasUsed: "1502983", gasUsed: "123600", confirmations: "1115834"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "1"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616282"}, {type: "uint256", name: "commit", value: "22283886784852671572779401927502185699623946986335696221322030331572688895699"}, {type: "bytes32", name: "r", value: "0x6d6d2bf84b5f083f8c1a43132bfcf91c4b2b8f57bf3c38948d0edd59f14ac083"}, {type: "bytes32", name: "s", value: "0x5bc8cbc2ec861ff7d153bdd55835059a64e1144926ac601fbf4e01e52dc0b820"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "1", "2", "6616282", "22283886784852671572779401927502185699623946986335696221322030331572688895699", "0x6d6d2bf84b5f083f8c1a43132bfcf91c4b2b8f57bf3c38948d0edd59f14ac083", "0x5bc8cbc2ec861ff7d153bdd55835059a64e1144926ac601fbf4e01e52dc0b820", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540967660 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "22283886784852671572779401927502185699623946986335696221322030331572688895699"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"1\", \"2\", \"6616287\", \"84342705495... )", async function( ) {
		const txOriginal = {blockNumber: "6616043", timeStamp: "1540967663", hash: "0xe6a9c09a563320388b8c53ea9dbcdb88041d4641d11fb518bc2bc502046891a9", nonce: "3", blockHash: "0x9516fd1eda687f8bc5ee4276411ad69d1eaf0f15fd4994d59b1f196f97ebf47c", transactionIndex: "96", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "200000000000000000", gas: "150000", gasPrice: "11950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f4dfba784793e3d593cfedc91cf0550b9af47355f8b15a464460e6cf7c51a4910339bd4ba3794d767cafd198e46b621c8a593054da57a06eab9474879fb708ad97115ae04691c284e5521b9c426590c89004569cb9fab173ee9ee24f2f9a9947ca2d", contractAddress: "", cumulativeGasUsed: "5576469", gasUsed: "123600", confirmations: "1115832"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "1"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616287"}, {type: "uint256", name: "commit", value: "84342705495357487409684133971452195557032201699739114621854847990002244191033"}, {type: "bytes32", name: "r", value: "0xbd4ba3794d767cafd198e46b621c8a593054da57a06eab9474879fb708ad9711"}, {type: "bytes32", name: "s", value: "0x5ae04691c284e5521b9c426590c89004569cb9fab173ee9ee24f2f9a9947ca2d"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "1", "2", "6616287", "84342705495357487409684133971452195557032201699739114621854847990002244191033", "0xbd4ba3794d767cafd198e46b621c8a593054da57a06eab9474879fb708ad9711", "0x5ae04691c284e5521b9c426590c89004569cb9fab173ee9ee24f2f9a9947ca2d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540967663 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[11,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "84342705495357487409684133971452195557032201699739114621854847990002244191033"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[11,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"9\", \"100\", \"6616287\", \"473861563... )", async function( ) {
		const txOriginal = {blockNumber: "6616043", timeStamp: "1540967663", hash: "0xa7663a19b1b49c00d0522e97fd51ba89fbf26a0736e3ce5d3d0bdc10acbc1589", nonce: "1418", blockHash: "0x9516fd1eda687f8bc5ee4276411ad69d1eaf0f15fd4994d59b1f196f97ebf47c", transactionIndex: "97", from: "0x9b21000ea7055223005d07d30791c8493f62be59", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "350000000000000000", gas: "150000", gasPrice: "11950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000064f4df68c39d3250812de04aeae52d87e4a782975eb824d2bf4c3c7bd8bd9a968634ebdc70de521d304135ca485906d7d8b970756f61c588428a2f81aa0dbfff8ea7126df5791c37f68e80de6e9e82aa2487c1fc177f04dd9e92026c06ead93345d61e", contractAddress: "", cumulativeGasUsed: "5685151", gasUsed: "108682", confirmations: "1115832"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "350000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "9"}, {type: "uint256", name: "modulo", value: "100"}, {type: "uint256", name: "commitLastBlock", value: "6616287"}, {type: "uint256", name: "commit", value: "47386156360943393386719010087603043494046183083488221675812432568570345829611"}, {type: "bytes32", name: "r", value: "0xdc70de521d304135ca485906d7d8b970756f61c588428a2f81aa0dbfff8ea712"}, {type: "bytes32", name: "s", value: "0x6df5791c37f68e80de6e9e82aa2487c1fc177f04dd9e92026c06ead93345d61e"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "9", "100", "6616287", "47386156360943393386719010087603043494046183083488221675812432568570345829611", "0xdc70de521d304135ca485906d7d8b970756f61c588428a2f81aa0dbfff8ea712", "0x6df5791c37f68e80de6e9e82aa2487c1fc177f04dd9e92026c06ead93345d61e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540967663 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "47386156360943393386719010087603043494046183083488221675812432568570345829611"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0xcd497b710dcbe0c0b682de541867f76fdb9c... )", async function( ) {
		const txOriginal = {blockNumber: "6616043", timeStamp: "1540967663", hash: "0xddb6b092ad1f51b40d913f4809e0b92fe9a19b37c379faeffacca40a40a9a700", nonce: "12994", blockHash: "0x9516fd1eda687f8bc5ee4276411ad69d1eaf0f15fd4994d59b1f196f97ebf47c", transactionIndex: "102", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75bcd497b710dcbe0c0b682de541867f76fdb9c21bc0000000000000000000000000275c80759c9e820bd09606d30b150c26965c403000000000000000000000000ba6ff3732cdbb734b8e4cb5b75d3ce4d91803c3999d9326d36bbbedfecd018bd", contractAddress: "", cumulativeGasUsed: "5826804", gasUsed: "36383", confirmations: "1115832"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0xcd497b710dcbe0c0b682de541867f76fdb9c21bc"}, {type: "bytes20", name: "reveal2", value: "0x0275c80759c9e820bd09606d30b150c26965c403"}, {type: "bytes32", name: "blockHash", value: "0xba6ff3732cdbb734b8e4cb5b75d3ce4d91803c3999d9326d36bbbedfecd018bd"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0xcd497b710dcbe0c0b682de541867f76fdb9c21bc", "0x0275c80759c9e820bd09606d30b150c26965c403", "0xba6ff3732cdbb734b8e4cb5b75d3ce4d91803c3999d9326d36bbbedfecd018bd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540967663 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "394080000000000000"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0xa0800adbf8ae1dea4c5d98531ad7f802e79b... )", async function( ) {
		const txOriginal = {blockNumber: "6616046", timeStamp: "1540967756", hash: "0xa03bbcb58642d4cb30caa2a17ecc1261434f19d76d6e144f9ad9248f68bcb3d3", nonce: "12995", blockHash: "0x1e1b47846dffe3f57e5889631cbbd41ff9b306f0adf573a2a6d4f249b6a07387", transactionIndex: "83", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75ba0800adbf8ae1dea4c5d98531ad7f802e79b164a000000000000000000000000a16d11ce52b93ed6d661aa4be683e2781bee57740000000000000000000000009516fd1eda687f8bc5ee4276411ad69d1eaf0f15fd4994d59b1f196f97ebf47c", contractAddress: "", cumulativeGasUsed: "4950555", gasUsed: "36383", confirmations: "1115829"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0xa0800adbf8ae1dea4c5d98531ad7f802e79b164a"}, {type: "bytes20", name: "reveal2", value: "0xa16d11ce52b93ed6d661aa4be683e2781bee5774"}, {type: "bytes32", name: "blockHash", value: "0x9516fd1eda687f8bc5ee4276411ad69d1eaf0f15fd4994d59b1f196f97ebf47c"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0xa0800adbf8ae1dea4c5d98531ad7f802e79b164a", "0xa16d11ce52b93ed6d661aa4be683e2781bee5774", "0x9516fd1eda687f8bc5ee4276411ad69d1eaf0f15fd4994d59b1f196f97ebf47c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540967756 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "394080000000000000"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x69f2fb00cefc329e96310507b286c438d329... )", async function( ) {
		const txOriginal = {blockNumber: "6616046", timeStamp: "1540967756", hash: "0x0b6d4fc7c21e34cadafd1222466b3ee855b7faf0c4fdbd46da92e164ade6003e", nonce: "12996", blockHash: "0x1e1b47846dffe3f57e5889631cbbd41ff9b306f0adf573a2a6d4f249b6a07387", transactionIndex: "124", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75b69f2fb00cefc329e96310507b286c438d329888f000000000000000000000000b06573c935cca98f35322832cfb27bbd688b2c420000000000000000000000009516fd1eda687f8bc5ee4276411ad69d1eaf0f15fd4994d59b1f196f97ebf47c", contractAddress: "", cumulativeGasUsed: "6191609", gasUsed: "35862", confirmations: "1115829"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x69f2fb00cefc329e96310507b286c438d329888f"}, {type: "bytes20", name: "reveal2", value: "0xb06573c935cca98f35322832cfb27bbd688b2c42"}, {type: "bytes32", name: "blockHash", value: "0x9516fd1eda687f8bc5ee4276411ad69d1eaf0f15fd4994d59b1f196f97ebf47c"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x69f2fb00cefc329e96310507b286c438d329888f", "0xb06573c935cca98f35322832cfb27bbd688b2c42", "0x9516fd1eda687f8bc5ee4276411ad69d1eaf0f15fd4994d59b1f196f97ebf47c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540967756 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x9b21000ea7055223005d07d30791c8493f62be59"}, {name: "amount", type: "uint256", value: "0"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"2\", \"2\", \"6616289\", \"22179560278... )", async function( ) {
		const txOriginal = {blockNumber: "6616048", timeStamp: "1540967767", hash: "0x3e0d6735d1bacbda517eeee2a42b3d9d4cda33a70d17f99fca3a00c4b13a0fbc", nonce: "4", blockHash: "0x67eb0ac93ca50c920a1257dbdbef3984debd7e74591676e07c8ca15c97ad63e3", transactionIndex: "14", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "200000000000000000", gas: "150000", gasPrice: "13950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f4e131092fae0eaf3a38cda8ad81993ae719d29ebdedae91816c9a25beae0e8065f11bfa1b373aa6b63e92f33e026620d77784f741074cc66fdfba166741fb28b045537b98dab43c90f2b70bbc02e8727ddf69c560cbe50a47300db8d5ee1805652b", contractAddress: "", cumulativeGasUsed: "833812", gasUsed: "123600", confirmations: "1115827"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "2"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616289"}, {type: "uint256", name: "commit", value: "22179560278818534196678076307229466566733933889704878839534183746242206524913"}, {type: "bytes32", name: "r", value: "0x1bfa1b373aa6b63e92f33e026620d77784f741074cc66fdfba166741fb28b045"}, {type: "bytes32", name: "s", value: "0x537b98dab43c90f2b70bbc02e8727ddf69c560cbe50a47300db8d5ee1805652b"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "2", "2", "6616289", "22179560278818534196678076307229466566733933889704878839534183746242206524913", "0x1bfa1b373aa6b63e92f33e026620d77784f741074cc66fdfba166741fb28b045", "0x537b98dab43c90f2b70bbc02e8727ddf69c560cbe50a47300db8d5ee1805652b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540967767 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "22179560278818534196678076307229466566733933889704878839534183746242206524913"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"9\", \"100\", \"6616289\", \"344015994... )", async function( ) {
		const txOriginal = {blockNumber: "6616048", timeStamp: "1540967767", hash: "0x4ea7a6d4823b6f5c5735db66ca6ecf8d071bcb5379b84e11352c8c92e2f25c80", nonce: "1419", blockHash: "0x67eb0ac93ca50c920a1257dbdbef3984debd7e74591676e07c8ca15c97ad63e3", transactionIndex: "15", from: "0x9b21000ea7055223005d07d30791c8493f62be59", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "350000000000000000", gas: "150000", gasPrice: "13950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000064f4e14c0e9d8317833242807c9f4d3c3e21da3f2bf0072ad5b7febda4a1e336a0599bcbfe528669ba566b87a8a7318cd2d112e3f39c8a925700bba437a5d976d5433f18199c2c222e528b1c6fa00b291b8205812cc1f68941e91670dfb252b79c10df", contractAddress: "", cumulativeGasUsed: "942430", gasUsed: "108618", confirmations: "1115827"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "350000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "9"}, {type: "uint256", name: "modulo", value: "100"}, {type: "uint256", name: "commitLastBlock", value: "6616289"}, {type: "uint256", name: "commit", value: "34401599459640756159205742284458622837993436378274157364702282388117257214363"}, {type: "bytes32", name: "r", value: "0xcbfe528669ba566b87a8a7318cd2d112e3f39c8a925700bba437a5d976d5433f"}, {type: "bytes32", name: "s", value: "0x18199c2c222e528b1c6fa00b291b8205812cc1f68941e91670dfb252b79c10df"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "9", "100", "6616289", "34401599459640756159205742284458622837993436378274157364702282388117257214363", "0xcbfe528669ba566b87a8a7318cd2d112e3f39c8a925700bba437a5d976d5433f", "0x18199c2c222e528b1c6fa00b291b8205812cc1f68941e91670dfb252b79c10df", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540967767 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[17,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "34401599459640756159205742284458622837993436378274157364702282388117257214363"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[17,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x0439b28dbc39e6956fb83f35079fcf9fc4a3... )", async function( ) {
		const txOriginal = {blockNumber: "6616051", timeStamp: "1540967810", hash: "0x4f241bfc0b895035571078d9abd0f12cebee4ce50e4b1ab3bd676027ff6a5c66", nonce: "12997", blockHash: "0x5d763e6c2319d1f8e18ff1c63fcafc4f5c3286cd4152020871b3b4ad8476bec8", transactionIndex: "57", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10500200000", isError: "0", txreceipt_status: "1", input: "0xe163b75b0439b28dbc39e6956fb83f35079fcf9fc4a3f3f50000000000000000000000007ef126f240457db770152471c8fb8427fb09dcbc00000000000000000000000067eb0ac93ca50c920a1257dbdbef3984debd7e74591676e07c8ca15c97ad63e3", contractAddress: "", cumulativeGasUsed: "3742941", gasUsed: "36433", confirmations: "1115824"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x0439b28dbc39e6956fb83f35079fcf9fc4a3f3f5"}, {type: "bytes20", name: "reveal2", value: "0x7ef126f240457db770152471c8fb8427fb09dcbc"}, {type: "bytes32", name: "blockHash", value: "0x67eb0ac93ca50c920a1257dbdbef3984debd7e74591676e07c8ca15c97ad63e3"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x0439b28dbc39e6956fb83f35079fcf9fc4a3f3f5", "0x7ef126f240457db770152471c8fb8427fb09dcbc", "0x67eb0ac93ca50c920a1257dbdbef3984debd7e74591676e07c8ca15c97ad63e3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540967810 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "394080000000000000"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x0fac5ef163bd08e27b64bbc4b199bde6344c... )", async function( ) {
		const txOriginal = {blockNumber: "6616051", timeStamp: "1540967810", hash: "0xa61fb904e480618be8d8b999d359409c88e1c7463bc5337523362c69982ab622", nonce: "12998", blockHash: "0x5d763e6c2319d1f8e18ff1c63fcafc4f5c3286cd4152020871b3b4ad8476bec8", transactionIndex: "58", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10500200000", isError: "0", txreceipt_status: "1", input: "0xe163b75b0fac5ef163bd08e27b64bbc4b199bde6344cc42a000000000000000000000000bd51b60796829154a940c99cd5da2c1400b40fa200000000000000000000000067eb0ac93ca50c920a1257dbdbef3984debd7e74591676e07c8ca15c97ad63e3", contractAddress: "", cumulativeGasUsed: "3778803", gasUsed: "35862", confirmations: "1115824"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x0fac5ef163bd08e27b64bbc4b199bde6344cc42a"}, {type: "bytes20", name: "reveal2", value: "0xbd51b60796829154a940c99cd5da2c1400b40fa2"}, {type: "bytes32", name: "blockHash", value: "0x67eb0ac93ca50c920a1257dbdbef3984debd7e74591676e07c8ca15c97ad63e3"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x0fac5ef163bd08e27b64bbc4b199bde6344cc42a", "0xbd51b60796829154a940c99cd5da2c1400b40fa2", "0x67eb0ac93ca50c920a1257dbdbef3984debd7e74591676e07c8ca15c97ad63e3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540967810 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x9b21000ea7055223005d07d30791c8493f62be59"}, {name: "amount", type: "uint256", value: "0"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"9\", \"100\", \"6616298\", \"345985223... )", async function( ) {
		const txOriginal = {blockNumber: "6616056", timeStamp: "1540967885", hash: "0x2b355b38fb6eddaf40751e471878763bb00b2b99cbb392ed5efe861fb1f140b3", nonce: "1420", blockHash: "0xeae413c8d38d161d0904cd720227ea7f4129e01efc17c6ac2d14d08d49298561", transactionIndex: "13", from: "0x9b21000ea7055223005d07d30791c8493f62be59", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "410000000000000000", gas: "150000", gasPrice: "11950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000064f4ea4c7e11d55ba7a2b4aadb8368050e6f39981028740489561dec93df50850391e893fbaa60f8f305957f0dde3e60bd01d4d84b5e4e772db4aac17d3fb1d4da67bf2f7e044c902df323c33c794754ecd96a5e0e4e1b716e448d37f8267c7ce7a19e", contractAddress: "", cumulativeGasUsed: "923756", gasUsed: "108682", confirmations: "1115819"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "410000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "9"}, {type: "uint256", name: "modulo", value: "100"}, {type: "uint256", name: "commitLastBlock", value: "6616298"}, {type: "uint256", name: "commit", value: "34598522304299237299708554051084154605841159672070755296261358469060936045032"}, {type: "bytes32", name: "r", value: "0x93fbaa60f8f305957f0dde3e60bd01d4d84b5e4e772db4aac17d3fb1d4da67bf"}, {type: "bytes32", name: "s", value: "0x2f7e044c902df323c33c794754ecd96a5e0e4e1b716e448d37f8267c7ce7a19e"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "9", "100", "6616298", "34598522304299237299708554051084154605841159672070755296261358469060936045032", "0x93fbaa60f8f305957f0dde3e60bd01d4d84b5e4e772db4aac17d3fb1d4da67bf", "0x2f7e044c902df323c33c794754ecd96a5e0e4e1b716e448d37f8267c7ce7a19e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540967885 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "34598522304299237299708554051084154605841159672070755296261358469060936045032"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"1\", \"2\", \"6616298\", \"90849886213... )", async function( ) {
		const txOriginal = {blockNumber: "6616058", timeStamp: "1540967914", hash: "0xfd5ac123c21570b3b261f10d04cd88a3bbbff56b203481a9f55cf923fec12123", nonce: "5", blockHash: "0x8227baf08c23c4eee79c399e35ad3a06a6cd7edd523300e4bb0ced108829de50", transactionIndex: "95", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "100000000000000000", gas: "150000", gasPrice: "11950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f4eac8db369f556c55314ce8f8517b8f66b290f5185599eac4ddb8d554abd7e650e48fb59a96111c0dc8220479a40b4e584bd71dd342f20f96973a214053c3bbc75407648ccc4a480d4acbc116fb2d475b0e491112c66a90a976417bf6d90d5e6908", contractAddress: "", cumulativeGasUsed: "5658384", gasUsed: "123600", confirmations: "1115817"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "1"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616298"}, {type: "uint256", name: "commit", value: "90849886213770100924312432170092547522570053145070332739445279071425958138084"}, {type: "bytes32", name: "r", value: "0x8fb59a96111c0dc8220479a40b4e584bd71dd342f20f96973a214053c3bbc754"}, {type: "bytes32", name: "s", value: "0x07648ccc4a480d4acbc116fb2d475b0e491112c66a90a976417bf6d90d5e6908"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "1", "2", "6616298", "90849886213770100924312432170092547522570053145070332739445279071425958138084", "0x8fb59a96111c0dc8220479a40b4e584bd71dd342f20f96973a214053c3bbc754", "0x07648ccc4a480d4acbc116fb2d475b0e491112c66a90a976417bf6d90d5e6908", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540967914 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[21,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "90849886213770100924312432170092547522570053145070332739445279071425958138084"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[21,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x425fe4d8ad089a9b7cbcf6fe16f1dac9d0c0... )", async function( ) {
		const txOriginal = {blockNumber: "6616059", timeStamp: "1540967925", hash: "0xef70701a5d2d48f6afdcade7bbc440a77cf68a0463ed5f8dd8c3f1d12ece3bde", nonce: "12999", blockHash: "0xa5bda7dabca1c8ebb04533b428a5ac34cac0b63d64a7b044c5deaab107b4d9db", transactionIndex: "56", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10500200000", isError: "0", txreceipt_status: "1", input: "0xe163b75b425fe4d8ad089a9b7cbcf6fe16f1dac9d0c0191a00000000000000000000000097d4e7a0e5aed6f98d8b230cc21de0e80924b348000000000000000000000000eae413c8d38d161d0904cd720227ea7f4129e01efc17c6ac2d14d08d49298561", contractAddress: "", cumulativeGasUsed: "2365141", gasUsed: "35950", confirmations: "1115816"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x425fe4d8ad089a9b7cbcf6fe16f1dac9d0c0191a"}, {type: "bytes20", name: "reveal2", value: "0x97d4e7a0e5aed6f98d8b230cc21de0e80924b348"}, {type: "bytes32", name: "blockHash", value: "0xeae413c8d38d161d0904cd720227ea7f4129e01efc17c6ac2d14d08d49298561"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x425fe4d8ad089a9b7cbcf6fe16f1dac9d0c0191a", "0x97d4e7a0e5aed6f98d8b230cc21de0e80924b348", "0xeae413c8d38d161d0904cd720227ea7f4129e01efc17c6ac2d14d08d49298561", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540967925 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x9b21000ea7055223005d07d30791c8493f62be59"}, {name: "amount", type: "uint256", value: "4499800000000000000"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0xae94ef77a247227ea241bcee782816c2bd6b... )", async function( ) {
		const txOriginal = {blockNumber: "6616061", timeStamp: "1540967994", hash: "0x4346f2845b6ec2fcc83b3488c8aa8627b53071d0ad8aeb375fdecdc44c0a0c53", nonce: "13000", blockHash: "0xaae67cf3b1ad09769bf9fb17d06185098367ae52af41843a8275ff604554a460", transactionIndex: "41", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10500200000", isError: "0", txreceipt_status: "1", input: "0xe163b75bae94ef77a247227ea241bcee782816c2bd6b05310000000000000000000000004bddec16c166f461984f711f9c9de9da116698ec0000000000000000000000008227baf08c23c4eee79c399e35ad3a06a6cd7edd523300e4bb0ced108829de50", contractAddress: "", cumulativeGasUsed: "1867696", gasUsed: "36319", confirmations: "1115814"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0xae94ef77a247227ea241bcee782816c2bd6b0531"}, {type: "bytes20", name: "reveal2", value: "0x4bddec16c166f461984f711f9c9de9da116698ec"}, {type: "bytes32", name: "blockHash", value: "0x8227baf08c23c4eee79c399e35ad3a06a6cd7edd523300e4bb0ced108829de50"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0xae94ef77a247227ea241bcee782816c2bd6b0531", "0x4bddec16c166f461984f711f9c9de9da116698ec", "0x8227baf08c23c4eee79c399e35ad3a06a6cd7edd523300e4bb0ced108829de50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540967994 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "196040000000000000"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"2\", \"2\", \"6616307\", \"70417327363... )", async function( ) {
		const txOriginal = {blockNumber: "6616064", timeStamp: "1540968058", hash: "0x3fead2900d327579bff73b08e45516095b8c8bd9b728e873e1d7e7d83171fc7e", nonce: "6", blockHash: "0x6db6986b0d7276536c659ec6bd90953372506ebe6d5872c1b8506f04ddefcdc9", transactionIndex: "93", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "100000000000000000", gas: "150000", gasPrice: "11950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f4f39baecb7db7bf3f9d0e470eacb323c367de196e1c2761c3e4252d17e6cabbb7ccb4f3e0f7430c6ea8032efd9392ec87b72df26cbca689a6d43a796b791c2014e4329ccd1878d1e6035113e09fda44511945edd772109a73a1a9e37f53bd73b4b5", contractAddress: "", cumulativeGasUsed: "5145633", gasUsed: "123600", confirmations: "1115811"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "2"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616307"}, {type: "uint256", name: "commit", value: "70417327363530285390401460650292748751070857204252308207724994112388587042764"}, {type: "bytes32", name: "r", value: "0xb4f3e0f7430c6ea8032efd9392ec87b72df26cbca689a6d43a796b791c2014e4"}, {type: "bytes32", name: "s", value: "0x329ccd1878d1e6035113e09fda44511945edd772109a73a1a9e37f53bd73b4b5"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "2", "2", "6616307", "70417327363530285390401460650292748751070857204252308207724994112388587042764", "0xb4f3e0f7430c6ea8032efd9392ec87b72df26cbca689a6d43a796b791c2014e4", "0x329ccd1878d1e6035113e09fda44511945edd772109a73a1a9e37f53bd73b4b5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540968058 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "70417327363530285390401460650292748751070857204252308207724994112388587042764"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"2\", \"2\", \"6616307\", \"69055371548... )", async function( ) {
		const txOriginal = {blockNumber: "6616067", timeStamp: "1540968100", hash: "0x790418f5add2a91f8c011f0991b2dd93e5371bab95d7b19189d133ff27127c22", nonce: "7", blockHash: "0x56b37001ec93e1639e09da5a1aad31091635e1e7778e2cf187b97967b3d65a3d", transactionIndex: "86", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "100000000000000000", gas: "150000", gasPrice: "11950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f4f398abf488d6e9b236c337242f8d9ed739510cb45be3128e2193038825ab346cb9a0221c27fa26610ece6241b47906bcaa8ea4b9c831b1b3fa8eba2a2d6b546c48237839af358aa934018ce3f00470ea81ee1fabe4889fe36d64590aeb6233aed2", contractAddress: "", cumulativeGasUsed: "4302327", gasUsed: "123600", confirmations: "1115808"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "2"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616307"}, {type: "uint256", name: "commit", value: "69055371548027925819412399972761200670795440341148501223925968086433631857849"}, {type: "bytes32", name: "r", value: "0xa0221c27fa26610ece6241b47906bcaa8ea4b9c831b1b3fa8eba2a2d6b546c48"}, {type: "bytes32", name: "s", value: "0x237839af358aa934018ce3f00470ea81ee1fabe4889fe36d64590aeb6233aed2"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "2", "2", "6616307", "69055371548027925819412399972761200670795440341148501223925968086433631857849", "0xa0221c27fa26610ece6241b47906bcaa8ea4b9c831b1b3fa8eba2a2d6b546c48", "0x237839af358aa934018ce3f00470ea81ee1fabe4889fe36d64590aeb6233aed2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540968100 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[25,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "69055371548027925819412399972761200670795440341148501223925968086433631857849"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[25,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x03883007e71107448436f389c485e60f6fb0... )", async function( ) {
		const txOriginal = {blockNumber: "6616067", timeStamp: "1540968100", hash: "0xb6a8ec89c513fd5c5f768a28f10e15c117320316294841b1ce6d8bf75d683566", nonce: "13001", blockHash: "0x56b37001ec93e1639e09da5a1aad31091635e1e7778e2cf187b97967b3d65a3d", transactionIndex: "92", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10500200000", isError: "0", txreceipt_status: "1", input: "0xe163b75b03883007e71107448436f389c485e60f6fb01d63000000000000000000000000e1b045ed70c7f14b8b1e1440455874bb26f0640e0000000000000000000000006db6986b0d7276536c659ec6bd90953372506ebe6d5872c1b8506f04ddefcdc9", contractAddress: "", cumulativeGasUsed: "4553063", gasUsed: "36359", confirmations: "1115808"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x03883007e71107448436f389c485e60f6fb01d63"}, {type: "bytes20", name: "reveal2", value: "0xe1b045ed70c7f14b8b1e1440455874bb26f0640e"}, {type: "bytes32", name: "blockHash", value: "0x6db6986b0d7276536c659ec6bd90953372506ebe6d5872c1b8506f04ddefcdc9"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x03883007e71107448436f389c485e60f6fb01d63", "0xe1b045ed70c7f14b8b1e1440455874bb26f0640e", "0x6db6986b0d7276536c659ec6bd90953372506ebe6d5872c1b8506f04ddefcdc9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540968100 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "0"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"2\", \"2\", \"6616310\", \"20551945967... )", async function( ) {
		const txOriginal = {blockNumber: "6616069", timeStamp: "1540968135", hash: "0xd35d7baf4db90d6ac8ef4cc1133529d25c94c692bb82c929f9fd19ce9272d29a", nonce: "8", blockHash: "0xa4d3121629408fd4feed4d740589c3a965d66b5ee2c54c693536e9dc7327fda4", transactionIndex: "89", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "400000000000000000", gas: "150000", gasPrice: "11950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f4f62d6ffd3bed2c584b607f25214bd463b2f3dab0ae3c6f2c4e859b5b94e42e3774882acf165c442a4fda215b44a765b151308e8fda09544588a83019a27786547307fadb7a57ac0b5a3b8e1889d936a9f3c62069127dbe7431b9a4bdbd96f8c9ea", contractAddress: "", cumulativeGasUsed: "4979316", gasUsed: "123600", confirmations: "1115806"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "2"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616310"}, {type: "uint256", name: "commit", value: "20551945967877235071184504794875115541861962016808315504708184648694125967220"}, {type: "bytes32", name: "r", value: "0x882acf165c442a4fda215b44a765b151308e8fda09544588a83019a277865473"}, {type: "bytes32", name: "s", value: "0x07fadb7a57ac0b5a3b8e1889d936a9f3c62069127dbe7431b9a4bdbd96f8c9ea"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "2", "2", "6616310", "20551945967877235071184504794875115541861962016808315504708184648694125967220", "0x882acf165c442a4fda215b44a765b151308e8fda09544588a83019a277865473", "0x07fadb7a57ac0b5a3b8e1889d936a9f3c62069127dbe7431b9a4bdbd96f8c9ea", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540968135 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "20551945967877235071184504794875115541861962016808315504708184648694125967220"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x95bdfcecba751c96f1ac753b2afc2c70024f... )", async function( ) {
		const txOriginal = {blockNumber: "6616070", timeStamp: "1540968175", hash: "0x09a1767ae9865fb3741e337be92370a448b7d663380ea4528aafd57c5bfd1053", nonce: "13002", blockHash: "0x7df8f3a07392cbf95fcfc16e1d9a3aa6c2f8440b9bb93769f7fe8a5019b575bc", transactionIndex: "76", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10500200000", isError: "0", txreceipt_status: "1", input: "0xe163b75b95bdfcecba751c96f1ac753b2afc2c70024f15c8000000000000000000000000f2b523dbe53ebc322838dd53c43b65c8e0a2fe3300000000000000000000000056b37001ec93e1639e09da5a1aad31091635e1e7778e2cf187b97967b3d65a3d", contractAddress: "", cumulativeGasUsed: "3531382", gasUsed: "36359", confirmations: "1115805"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x95bdfcecba751c96f1ac753b2afc2c70024f15c8"}, {type: "bytes20", name: "reveal2", value: "0xf2b523dbe53ebc322838dd53c43b65c8e0a2fe33"}, {type: "bytes32", name: "blockHash", value: "0x56b37001ec93e1639e09da5a1aad31091635e1e7778e2cf187b97967b3d65a3d"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x95bdfcecba751c96f1ac753b2afc2c70024f15c8", "0xf2b523dbe53ebc322838dd53c43b65c8e0a2fe33", "0x56b37001ec93e1639e09da5a1aad31091635e1e7778e2cf187b97967b3d65a3d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540968175 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "0"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"2\", \"2\", \"6616313\", \"45464162008... )", async function( ) {
		const txOriginal = {blockNumber: "6616072", timeStamp: "1540968201", hash: "0x18fc56234eb43f072e1cf2f9eaef6ff13eefbceeeeebd735ba59c4b6b3eae4d8", nonce: "9", blockHash: "0xc12a7a06a7874fb8462c6fe4578d4a04abf4e0286407585260090dd88c0d6b6c", transactionIndex: "45", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "500000000000000000", gas: "150000", gasPrice: "11950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f4f96483cdc5985870683848b21c40dc86a4ebd68602f5766ef3768a6c66864c48a59c9963b9023c8ec353028d91f98fbe0da0749214d29906daf206335f4ba029002495fe94b64908c77ed2b4637fb3915fda2e2c2fe60bace470fd4d7a950183a9", contractAddress: "", cumulativeGasUsed: "1889205", gasUsed: "123536", confirmations: "1115803"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "2"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616313"}, {type: "uint256", name: "commit", value: "45464162008967042743901666937655066891696250841079757607957194411084685789349"}, {type: "bytes32", name: "r", value: "0x9c9963b9023c8ec353028d91f98fbe0da0749214d29906daf206335f4ba02900"}, {type: "bytes32", name: "s", value: "0x2495fe94b64908c77ed2b4637fb3915fda2e2c2fe60bace470fd4d7a950183a9"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "2", "2", "6616313", "45464162008967042743901666937655066891696250841079757607957194411084685789349", "0x9c9963b9023c8ec353028d91f98fbe0da0749214d29906daf206335f4ba02900", "0x2495fe94b64908c77ed2b4637fb3915fda2e2c2fe60bace470fd4d7a950183a9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540968201 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[29,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "45464162008967042743901666937655066891696250841079757607957194411084685789349"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[29,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x0ae1b098ebdfdaac2098e17db814592e5323... )", async function( ) {
		const txOriginal = {blockNumber: "6616072", timeStamp: "1540968201", hash: "0xd505d340a8536cc020f2fcb2271b4e304099b9b3e17d1d6d0110b8e68a3b7a68", nonce: "13003", blockHash: "0xc12a7a06a7874fb8462c6fe4578d4a04abf4e0286407585260090dd88c0d6b6c", transactionIndex: "52", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10620475000", isError: "0", txreceipt_status: "1", input: "0xe163b75b0ae1b098ebdfdaac2098e17db814592e53236fe3000000000000000000000000f6eef7c6f9ef5fbb23240068e8f5407bef771f16000000000000000000000000a4d3121629408fd4feed4d740589c3a965d66b5ee2c54c693536e9dc7327fda4", contractAddress: "", cumulativeGasUsed: "2161001", gasUsed: "36369", confirmations: "1115803"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x0ae1b098ebdfdaac2098e17db814592e53236fe3"}, {type: "bytes20", name: "reveal2", value: "0xf6eef7c6f9ef5fbb23240068e8f5407bef771f16"}, {type: "bytes32", name: "blockHash", value: "0xa4d3121629408fd4feed4d740589c3a965d66b5ee2c54c693536e9dc7327fda4"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x0ae1b098ebdfdaac2098e17db814592e53236fe3", "0xf6eef7c6f9ef5fbb23240068e8f5407bef771f16", "0xa4d3121629408fd4feed4d740589c3a965d66b5ee2c54c693536e9dc7327fda4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540968201 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "790160000000000000"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x1cf8c9def599ecdb42733a7a4fe4e700b9e9... )", async function( ) {
		const txOriginal = {blockNumber: "6616077", timeStamp: "1540968265", hash: "0x6d54d122ec934d2def253595d8b7b9a25e5637ca9424c9f88374e33d491641b4", nonce: "13004", blockHash: "0x977bb32b6dfafb46014e979bcb8ddc402f59f296c5e05b11329c803715cba575", transactionIndex: "16", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "10730000000", isError: "0", txreceipt_status: "1", input: "0xe163b75b1cf8c9def599ecdb42733a7a4fe4e700b9e9467d000000000000000000000000ff75b7c55376fea61ab774fb0366bd224c2f0443000000000000000000000000c12a7a06a7874fb8462c6fe4578d4a04abf4e0286407585260090dd88c0d6b6c", contractAddress: "", cumulativeGasUsed: "1527893", gasUsed: "36295", confirmations: "1115798"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x1cf8c9def599ecdb42733a7a4fe4e700b9e9467d"}, {type: "bytes20", name: "reveal2", value: "0xff75b7c55376fea61ab774fb0366bd224c2f0443"}, {type: "bytes32", name: "blockHash", value: "0xc12a7a06a7874fb8462c6fe4578d4a04abf4e0286407585260090dd88c0d6b6c"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x1cf8c9def599ecdb42733a7a4fe4e700b9e9467d", "0xff75b7c55376fea61ab774fb0366bd224c2f0443", "0xc12a7a06a7874fb8462c6fe4578d4a04abf4e0286407585260090dd88c0d6b6c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540968265 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "0"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"2\", \"2\", \"6616325\", \"35216180577... )", async function( ) {
		const txOriginal = {blockNumber: "6616083", timeStamp: "1540968325", hash: "0xa0b0ebee72b59058dc612f7717786abfe3cca99c8cc78546cb16d8adac42b990", nonce: "10", blockHash: "0xe5071d2e95c9a7d8e07332f0df796999961b54257e08196de385256edee7798b", transactionIndex: "47", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "300000000000000000", gas: "150000", gasPrice: "9950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f50507c92a499a5a3458b137f8c26c406cfb6ec1dfc38e8b1dec6f982c21d9ddbb3a61f9c598b4901496f2a69182341b370a361ea0012f4b97f28c755adeb53e072c2d4d014db35c2ded8ac54694c7d8e1874876829892173525e2294f7db7ccfc7e", contractAddress: "", cumulativeGasUsed: "3516379", gasUsed: "123600", confirmations: "1115792"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "2"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616325"}, {type: "uint256", name: "commit", value: "3521618057781192761541465655488252050025015207677852754829197872604999695162"}, {type: "bytes32", name: "r", value: "0x61f9c598b4901496f2a69182341b370a361ea0012f4b97f28c755adeb53e072c"}, {type: "bytes32", name: "s", value: "0x2d4d014db35c2ded8ac54694c7d8e1874876829892173525e2294f7db7ccfc7e"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "2", "2", "6616325", "3521618057781192761541465655488252050025015207677852754829197872604999695162", "0x61f9c598b4901496f2a69182341b370a361ea0012f4b97f28c755adeb53e072c", "0x2d4d014db35c2ded8ac54694c7d8e1874876829892173525e2294f7db7ccfc7e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540968325 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[32,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "3521618057781192761541465655488252050025015207677852754829197872604999695162"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[32,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0xf3ba502d012fa5b8ef519dcab2d1f71c6c85... )", async function( ) {
		const txOriginal = {blockNumber: "6616087", timeStamp: "1540968359", hash: "0x63e511e088e681cf3916a6b5c804fcaf21e3cb9a69d38e6a6bfbd60baee05061", nonce: "13005", blockHash: "0xcddca7542b0f3d48ae975ff28bb19c3149648f9a4b624b8bea115f2aaba7c0c5", transactionIndex: "17", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "11500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75bf3ba502d012fa5b8ef519dcab2d1f71c6c851b2c000000000000000000000000f107b39965b5f3f20ccbc1da2b7173944bab133f000000000000000000000000e5071d2e95c9a7d8e07332f0df796999961b54257e08196de385256edee7798b", contractAddress: "", cumulativeGasUsed: "762654", gasUsed: "36433", confirmations: "1115788"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0xf3ba502d012fa5b8ef519dcab2d1f71c6c851b2c"}, {type: "bytes20", name: "reveal2", value: "0xf107b39965b5f3f20ccbc1da2b7173944bab133f"}, {type: "bytes32", name: "blockHash", value: "0xe5071d2e95c9a7d8e07332f0df796999961b54257e08196de385256edee7798b"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0xf3ba502d012fa5b8ef519dcab2d1f71c6c851b2c", "0xf107b39965b5f3f20ccbc1da2b7173944bab133f", "0xe5071d2e95c9a7d8e07332f0df796999961b54257e08196de385256edee7798b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540968359 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "592120000000000000"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"2\", \"2\", \"6616331\", \"12430332712... )", async function( ) {
		const txOriginal = {blockNumber: "6616088", timeStamp: "1540968396", hash: "0x75a7e74b7e1258acd5882decc59c26dfaec3b18a14698f83849c99b20fdd8df3", nonce: "11", blockHash: "0x2eda5e2cd3b5d46201f36bbb0c2d05c366724ef6d70407960faa4cf055bc158d", transactionIndex: "88", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "200000000000000000", gas: "150000", gasPrice: "11150000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f50b1b7b51a985568297b3cce84e4e7c4ea11c6ee7b8d3294d8ec5c7e6b216909a105278565e653088b0d0e4dbf20f0d27448fa06cfff9801764ac6461ffecb0d4af325543d3b74f54cf9126a14b835b0d56d59da6401fac4daebd7782b837b9b223", contractAddress: "", cumulativeGasUsed: "6137123", gasUsed: "123600", confirmations: "1115787"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "2"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616331"}, {type: "uint256", name: "commit", value: "12430332712443133536840726367667262482044295040428354186337912782815612672528"}, {type: "bytes32", name: "r", value: "0x5278565e653088b0d0e4dbf20f0d27448fa06cfff9801764ac6461ffecb0d4af"}, {type: "bytes32", name: "s", value: "0x325543d3b74f54cf9126a14b835b0d56d59da6401fac4daebd7782b837b9b223"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "2", "2", "6616331", "12430332712443133536840726367667262482044295040428354186337912782815612672528", "0x5278565e653088b0d0e4dbf20f0d27448fa06cfff9801764ac6461ffecb0d4af", "0x325543d3b74f54cf9126a14b835b0d56d59da6401fac4daebd7782b837b9b223", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540968396 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[34,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "12430332712443133536840726367667262482044295040428354186337912782815612672528"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[34,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0xa63643333d1ad179ece105df540d28b722ed... )", async function( ) {
		const txOriginal = {blockNumber: "6616091", timeStamp: "1540968454", hash: "0x64cb2b42eacfa064634b5d0e9cdb7c0a7eee350326d9ed52574175f8706bfd0f", nonce: "13006", blockHash: "0xd6af824320e4f88d477c4c7d59f812f450c246c86ded7e710069193383935dd3", transactionIndex: "21", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "11500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75ba63643333d1ad179ece105df540d28b722ed9b4a0000000000000000000000005fe27b396f55e7875f226cb410a1f747a2a781f60000000000000000000000002eda5e2cd3b5d46201f36bbb0c2d05c366724ef6d70407960faa4cf055bc158d", contractAddress: "", cumulativeGasUsed: "907085", gasUsed: "36433", confirmations: "1115784"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0xa63643333d1ad179ece105df540d28b722ed9b4a"}, {type: "bytes20", name: "reveal2", value: "0x5fe27b396f55e7875f226cb410a1f747a2a781f6"}, {type: "bytes32", name: "blockHash", value: "0x2eda5e2cd3b5d46201f36bbb0c2d05c366724ef6d70407960faa4cf055bc158d"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0xa63643333d1ad179ece105df540d28b722ed9b4a", "0x5fe27b396f55e7875f226cb410a1f747a2a781f6", "0x2eda5e2cd3b5d46201f36bbb0c2d05c366724ef6d70407960faa4cf055bc158d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540968454 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "394080000000000000"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"1\", \"2\", \"6616336\", \"23397856932... )", async function( ) {
		const txOriginal = {blockNumber: "6616092", timeStamp: "1540968460", hash: "0x9a6e64895c2cd42ab569ed6bbb684e65c9a44934671142c30f31b83738841704", nonce: "12", blockHash: "0xbacde8dc0e528a3f6b19f9a8d3af0b31d911f1fedff049555bd6595b0d630ab3", transactionIndex: "172", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "200000000000000000", gas: "150000", gasPrice: "11150000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f51033bab7bc7c787994f7af7ded77e8ed28c26ef1504ce160d0586e8309a673b60da7f189f68ebacee78175279620df0c6b690b00e4b4c8bb3afa95829d27630b9b7636096c4a965a60802c9bc08c80e1cabfad9d654e2b40bfca9fbde2df7466bd", contractAddress: "", cumulativeGasUsed: "7560829", gasUsed: "123536", confirmations: "1115783"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "1"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616336"}, {type: "uint256", name: "commit", value: "23397856932955086068043778132010998573331227791577491726653162234855690581517"}, {type: "bytes32", name: "r", value: "0xa7f189f68ebacee78175279620df0c6b690b00e4b4c8bb3afa95829d27630b9b"}, {type: "bytes32", name: "s", value: "0x7636096c4a965a60802c9bc08c80e1cabfad9d654e2b40bfca9fbde2df7466bd"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "1", "2", "6616336", "23397856932955086068043778132010998573331227791577491726653162234855690581517", "0xa7f189f68ebacee78175279620df0c6b690b00e4b4c8bb3afa95829d27630b9b", "0x7636096c4a965a60802c9bc08c80e1cabfad9d654e2b40bfca9fbde2df7466bd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540968460 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[36,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "23397856932955086068043778132010998573331227791577491726653162234855690581517"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[36,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0xa5adad39c85b54b11112b52629eb88e2aeec... )", async function( ) {
		const txOriginal = {blockNumber: "6616095", timeStamp: "1540968489", hash: "0x67071cb8a122899cda3779744165c9a750736f3e6c3e59bc3c3c265c52616c59", nonce: "13007", blockHash: "0x7cff44c53a141d54a0593e23270733439e296fb404e780eb7b7644cc1dbb00d5", transactionIndex: "29", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "11500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75ba5adad39c85b54b11112b52629eb88e2aeecb43a0000000000000000000000001dc425bdf94a35f6b95f43d5b2d984f740cf09d8000000000000000000000000bacde8dc0e528a3f6b19f9a8d3af0b31d911f1fedff049555bd6595b0d630ab3", contractAddress: "", cumulativeGasUsed: "2034464", gasUsed: "36409", confirmations: "1115780"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0xa5adad39c85b54b11112b52629eb88e2aeecb43a"}, {type: "bytes20", name: "reveal2", value: "0x1dc425bdf94a35f6b95f43d5b2d984f740cf09d8"}, {type: "bytes32", name: "blockHash", value: "0xbacde8dc0e528a3f6b19f9a8d3af0b31d911f1fedff049555bd6595b0d630ab3"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0xa5adad39c85b54b11112b52629eb88e2aeecb43a", "0x1dc425bdf94a35f6b95f43d5b2d984f740cf09d8", "0xbacde8dc0e528a3f6b19f9a8d3af0b31d911f1fedff049555bd6595b0d630ab3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540968489 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "0"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"1\", \"2\", \"6616340\", \"10783536608... )", async function( ) {
		const txOriginal = {blockNumber: "6616097", timeStamp: "1540968523", hash: "0xb99a3f6f19c6024b237703f8cf5d7c5031a78701430c827fdc6ebde6fd4ffe0d", nonce: "13", blockHash: "0xabdc74dde387de2baec36bc317187a6b8b28af45f60cd411f265626016ca6b83", transactionIndex: "52", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "500000000000000000", gas: "150000", gasPrice: "11150000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f51417d743f320bdb26d9b53afa99c3d8f9e1d1777530aaed4a5aa92b71a085419864445f1438668c4c3e6551cc3b038c2d267adc174bcd691d04752a94aa7b59c8e1541fb5ff4123c2b1fdf1217ab580611e0db81c0665461473bd32183d01a086d", contractAddress: "", cumulativeGasUsed: "2833368", gasUsed: "123600", confirmations: "1115778"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "1"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616340"}, {type: "uint256", name: "commit", value: "10783536608062784795537921582128670032798038900849496857381317628058454464902"}, {type: "bytes32", name: "r", value: "0x4445f1438668c4c3e6551cc3b038c2d267adc174bcd691d04752a94aa7b59c8e"}, {type: "bytes32", name: "s", value: "0x1541fb5ff4123c2b1fdf1217ab580611e0db81c0665461473bd32183d01a086d"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "1", "2", "6616340", "10783536608062784795537921582128670032798038900849496857381317628058454464902", "0x4445f1438668c4c3e6551cc3b038c2d267adc174bcd691d04752a94aa7b59c8e", "0x1541fb5ff4123c2b1fdf1217ab580611e0db81c0665461473bd32183d01a086d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540968523 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[38,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "10783536608062784795537921582128670032798038900849496857381317628058454464902"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[38,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0xa173ed49831da69ccd47d34ea43d4670f930... )", async function( ) {
		const txOriginal = {blockNumber: "6616100", timeStamp: "1540968549", hash: "0x47903d3a7976c316f8f0db889a6954f78e9d8ace1b7beb824d11bc08603ca8c8", nonce: "13008", blockHash: "0x39e381d8417be23b1f9b57e872da3725639241140628a4ffd3e05204a41daba1", transactionIndex: "29", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "11500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75ba173ed49831da69ccd47d34ea43d4670f930a6ee000000000000000000000000018c736927955726329d2a1f531fd2520594a69b000000000000000000000000abdc74dde387de2baec36bc317187a6b8b28af45f60cd411f265626016ca6b83", contractAddress: "", cumulativeGasUsed: "1174270", gasUsed: "36383", confirmations: "1115775"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0xa173ed49831da69ccd47d34ea43d4670f930a6ee"}, {type: "bytes20", name: "reveal2", value: "0x018c736927955726329d2a1f531fd2520594a69b"}, {type: "bytes32", name: "blockHash", value: "0xabdc74dde387de2baec36bc317187a6b8b28af45f60cd411f265626016ca6b83"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0xa173ed49831da69ccd47d34ea43d4670f930a6ee", "0x018c736927955726329d2a1f531fd2520594a69b", "0xabdc74dde387de2baec36bc317187a6b8b28af45f60cd411f265626016ca6b83", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540968549 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "988200000000000000"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"1\", \"2\", \"6616347\", \"64804518771... )", async function( ) {
		const txOriginal = {blockNumber: "6616106", timeStamp: "1540968618", hash: "0x87fcc16bea886e7bea401c89bdfe41f952c5c20ff47f73356e1e92b29e9d0528", nonce: "738", blockHash: "0x3400f4046f3db2a97f91875d57468f0e792e4c4c3bde54a78258b0abc20da335", transactionIndex: "89", from: "0x60f4c86457c1954c0ca963dc03534c3311967beb", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "10000000000000000", gas: "150000", gasPrice: "9170000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f51b8f460ecc3643723566949c90014e2a7b4ca159196512a3c8831943bdd5bf10d278e4f34c4f235822ca551e8b59a6662fc70b72628f9618645963fa1fce44978c650b8eb45f06482c936582a96431ab10eced6e18fea2bc5863d7dda594890418", contractAddress: "", cumulativeGasUsed: "2588515", gasUsed: "123615", confirmations: "1115769"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "1"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616347"}, {type: "uint256", name: "commit", value: "64804518771934165084655650597620292910521358645782748623502978715760426160338"}, {type: "bytes32", name: "r", value: "0x78e4f34c4f235822ca551e8b59a6662fc70b72628f9618645963fa1fce44978c"}, {type: "bytes32", name: "s", value: "0x650b8eb45f06482c936582a96431ab10eced6e18fea2bc5863d7dda594890418"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "1", "2", "6616347", "64804518771934165084655650597620292910521358645782748623502978715760426160338", "0x78e4f34c4f235822ca551e8b59a6662fc70b72628f9618645963fa1fce44978c", "0x650b8eb45f06482c936582a96431ab10eced6e18fea2bc5863d7dda594890418", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540968618 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "64804518771934165084655650597620292910521358645782748623502978715760426160338"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "39858961602084294" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0xc1a42f2927a71fc92494eca0ac627593d28e... )", async function( ) {
		const txOriginal = {blockNumber: "6616110", timeStamp: "1540968683", hash: "0xcd8c1878250a6a40f3eaa7a02c0c872f6609346bc76da9dafd0d1e16ab65649c", nonce: "13009", blockHash: "0x647d098e069ae334b79ffa7a4341056c8f981314fd409ff6f31e1917500baa77", transactionIndex: "41", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "11500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75bc1a42f2927a71fc92494eca0ac627593d28ebbfe0000000000000000000000000219438f4c8bb6f1cf35c40167a311dfc66839e50000000000000000000000003400f4046f3db2a97f91875d57468f0e792e4c4c3bde54a78258b0abc20da335", contractAddress: "", cumulativeGasUsed: "1381458", gasUsed: "36068", confirmations: "1115765"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0xc1a42f2927a71fc92494eca0ac627593d28ebbfe"}, {type: "bytes20", name: "reveal2", value: "0x0219438f4c8bb6f1cf35c40167a311dfc66839e5"}, {type: "bytes32", name: "blockHash", value: "0x3400f4046f3db2a97f91875d57468f0e792e4c4c3bde54a78258b0abc20da335"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0xc1a42f2927a71fc92494eca0ac627593d28ebbfe", "0x0219438f4c8bb6f1cf35c40167a311dfc66839e5", "0x3400f4046f3db2a97f91875d57468f0e792e4c4c3bde54a78258b0abc20da335", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1540968683 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x60f4c86457c1954c0ca963dc03534c3311967beb"}, {name: "amount", type: "uint256", value: "0"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"6\", \"100\", \"6616355\", \"764130776... )", async function( ) {
		const txOriginal = {blockNumber: "6616113", timeStamp: "1540968723", hash: "0xbf2f6eb0f21cca673f30fdb19c44b2de24a58a9dccb1f05b94b127276d1a4075", nonce: "1421", blockHash: "0x70949860909bbe70e20d7ff52fd359b6b748d97c266635c700c0df522ff04515", transactionIndex: "23", from: "0x9b21000ea7055223005d07d30791c8493f62be59", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "30000000000000000", gas: "150000", gasPrice: "9050000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000064f523a8f044ef23be5739ff1e3f6fcddfeb2f8ed56752bf64726340bf618f345a408cb7dfe8bbde3d36955cdb85ef980888ad51f08467b5100af378e4fd0e0ac48d6406ac1c889aef74894ff1951921d40ab53ef3fdd2488d15cfc4df627bb8b79efd", contractAddress: "", cumulativeGasUsed: "1504417", gasUsed: "108697", confirmations: "1115762"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "6"}, {type: "uint256", name: "modulo", value: "100"}, {type: "uint256", name: "commitLastBlock", value: "6616355"}, {type: "uint256", name: "commit", value: "76413077623478632535691294041941623664383940882629857738746863175722807738508"}, {type: "bytes32", name: "r", value: "0xb7dfe8bbde3d36955cdb85ef980888ad51f08467b5100af378e4fd0e0ac48d64"}, {type: "bytes32", name: "s", value: "0x06ac1c889aef74894ff1951921d40ab53ef3fdd2488d15cfc4df627bb8b79efd"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "6", "100", "6616355", "76413077623478632535691294041941623664383940882629857738746863175722807738508", "0xb7dfe8bbde3d36955cdb85ef980888ad51f08467b5100af378e4fd0e0ac48d64", "0x06ac1c889aef74894ff1951921d40ab53ef3fdd2488d15cfc4df627bb8b79efd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540968723 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[42,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "76413077623478632535691294041941623664383940882629857738746863175722807738508"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[42,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"1\", \"2\", \"6616355\", \"33934643737... )", async function( ) {
		const txOriginal = {blockNumber: "6616113", timeStamp: "1540968723", hash: "0x7ab544dbf040a7b7e96d7525467241c7e38fcff8a380b93c5f3ae075c34d16c4", nonce: "739", blockHash: "0x70949860909bbe70e20d7ff52fd359b6b748d97c266635c700c0df522ff04515", transactionIndex: "24", from: "0x60f4c86457c1954c0ca963dc03534c3311967beb", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "20000000000000000", gas: "150000", gasPrice: "9050000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f52300c01032ed66707b85413df6cd33d780fe330be73ffc594efd5d95f7a22521f2a4d9e02ef79f08f293085ea8a81c44ee32e5f99e0d1b6d189040192350e7a28e12f6aaec92efd6ca217c05e2b0efd7d31e51cedf769da89d2d15c7d8fb352aba", contractAddress: "", cumulativeGasUsed: "1627968", gasUsed: "123551", confirmations: "1115762"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "1"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616355"}, {type: "uint256", name: "commit", value: "339346437377486041904195728149159791084447193511349234075959926566196421106"}, {type: "bytes32", name: "r", value: "0xa4d9e02ef79f08f293085ea8a81c44ee32e5f99e0d1b6d189040192350e7a28e"}, {type: "bytes32", name: "s", value: "0x12f6aaec92efd6ca217c05e2b0efd7d31e51cedf769da89d2d15c7d8fb352aba"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "1", "2", "6616355", "339346437377486041904195728149159791084447193511349234075959926566196421106", "0xa4d9e02ef79f08f293085ea8a81c44ee32e5f99e0d1b6d189040192350e7a28e", "0x12f6aaec92efd6ca217c05e2b0efd7d31e51cedf769da89d2d15c7d8fb352aba", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540968723 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[43,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "339346437377486041904195728149159791084447193511349234075959926566196421106"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[43,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "39858961602084294" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0xaf45ef1485bd1f4b8e0ed2748e18f11372bc... )", async function( ) {
		const txOriginal = {blockNumber: "6616116", timeStamp: "1540968780", hash: "0x4f5649a7944457d07c537a8e9def2b5eab125bb8c3dd0a15900ba35bcff279ec", nonce: "13010", blockHash: "0xc463c1cb8df45f08fbb51d5b715ea32177549da9d99fb498e9ebce6f520fb9b4", transactionIndex: "42", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "11500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75baf45ef1485bd1f4b8e0ed2748e18f11372bc991a000000000000000000000000624d04b1e48a42701dba1065f6c2691dc9fceb0600000000000000000000000070949860909bbe70e20d7ff52fd359b6b748d97c266635c700c0df522ff04515", contractAddress: "", cumulativeGasUsed: "3393500", gasUsed: "35585", confirmations: "1115759"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0xaf45ef1485bd1f4b8e0ed2748e18f11372bc991a"}, {type: "bytes20", name: "reveal2", value: "0x624d04b1e48a42701dba1065f6c2691dc9fceb06"}, {type: "bytes32", name: "blockHash", value: "0x70949860909bbe70e20d7ff52fd359b6b748d97c266635c700c0df522ff04515"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0xaf45ef1485bd1f4b8e0ed2748e18f11372bc991a", "0x624d04b1e48a42701dba1065f6c2691dc9fceb06", "0x70949860909bbe70e20d7ff52fd359b6b748d97c266635c700c0df522ff04515", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540968780 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x9b21000ea7055223005d07d30791c8493f62be59"}, {name: "amount", type: "uint256", value: "0"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x5813a77ab5d06d5937c23fda73e021c70495... )", async function( ) {
		const txOriginal = {blockNumber: "6616116", timeStamp: "1540968780", hash: "0x67a72cc9f5485feec94c29ab783c8fa122df059beda3eb1e73181deb71a26f7f", nonce: "13011", blockHash: "0xc463c1cb8df45f08fbb51d5b715ea32177549da9d99fb498e9ebce6f520fb9b4", transactionIndex: "43", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "11500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75b5813a77ab5d06d5937c23fda73e021c7049541720000000000000000000000001240dafe19ae8848d840b1c015def07462bd710200000000000000000000000070949860909bbe70e20d7ff52fd359b6b748d97c266635c700c0df522ff04515", contractAddress: "", cumulativeGasUsed: "3429542", gasUsed: "36042", confirmations: "1115759"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x5813a77ab5d06d5937c23fda73e021c704954172"}, {type: "bytes20", name: "reveal2", value: "0x1240dafe19ae8848d840b1c015def07462bd7102"}, {type: "bytes32", name: "blockHash", value: "0x70949860909bbe70e20d7ff52fd359b6b748d97c266635c700c0df522ff04515"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x5813a77ab5d06d5937c23fda73e021c704954172", "0x1240dafe19ae8848d840b1c015def07462bd7102", "0x70949860909bbe70e20d7ff52fd359b6b748d97c266635c700c0df522ff04515", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540968780 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x60f4c86457c1954c0ca963dc03534c3311967beb"}, {name: "amount", type: "uint256", value: "39400000000000000"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"1\", \"2\", \"6616376\", \"43250296784... )", async function( ) {
		const txOriginal = {blockNumber: "6616133", timeStamp: "1540969080", hash: "0xf2c3699874e52de09288453eb23f8a8d4cbaeb174f2938fece5215c56800330d", nonce: "14", blockHash: "0x0b3e86cda8492d5a706bf91310bcbc3b48771c27ffe09b341081e34fac9c2d54", transactionIndex: "83", from: "0x088900c93556a2d1a92ece502d7a7414b2b79177", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "100000000000000000", gas: "150000", gasPrice: "11950000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f5385f9eccec848164a68f77e13c5a59b8fbbf151c30fb9700ed152c7817becc401ea0e246abddc7837f408f480e3f4ed3c005c790ba19839860e74f275c43009fff471a4d8281a08ca867753c1065ca754ce511aacfc239b04622bdc0d7e72cdb5a", contractAddress: "", cumulativeGasUsed: "3808971", gasUsed: "123472", confirmations: "1115742"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "1"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616376"}, {type: "uint256", name: "commit", value: "43250296784401902103647887970784425189775034130431071802420564573704168423454"}, {type: "bytes32", name: "r", value: "0xa0e246abddc7837f408f480e3f4ed3c005c790ba19839860e74f275c43009fff"}, {type: "bytes32", name: "s", value: "0x471a4d8281a08ca867753c1065ca754ce511aacfc239b04622bdc0d7e72cdb5a"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "1", "2", "6616376", "43250296784401902103647887970784425189775034130431071802420564573704168423454", "0xa0e246abddc7837f408f480e3f4ed3c005c790ba19839860e74f275c43009fff", "0x471a4d8281a08ca867753c1065ca754ce511aacfc239b04622bdc0d7e72cdb5a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540969080 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "43250296784401902103647887970784425189775034130431071802420564573704168423454"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x1a4d9472e514e1233bd1437a7a19af846a95... )", async function( ) {
		const txOriginal = {blockNumber: "6616136", timeStamp: "1540969117", hash: "0xeef5eb84b1e9d469ff4b437b33d94b090d0ce31bb536a3b9eab074b685550eda", nonce: "13012", blockHash: "0x158d648c89d67711f10ff3d48a5114c4ef2877d9747f7f609a6a69b6462e7732", transactionIndex: "52", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "12500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75b1a4d9472e514e1233bd1437a7a19af846a95dfa40000000000000000000000004085bb2f3d4afe4e6c7bffa2f5f9b9c0ed3b59060000000000000000000000000b3e86cda8492d5a706bf91310bcbc3b48771c27ffe09b341081e34fac9c2d54", contractAddress: "", cumulativeGasUsed: "3054428", gasUsed: "36383", confirmations: "1115739"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x1a4d9472e514e1233bd1437a7a19af846a95dfa4"}, {type: "bytes20", name: "reveal2", value: "0x4085bb2f3d4afe4e6c7bffa2f5f9b9c0ed3b5906"}, {type: "bytes32", name: "blockHash", value: "0x0b3e86cda8492d5a706bf91310bcbc3b48771c27ffe09b341081e34fac9c2d54"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x1a4d9472e514e1233bd1437a7a19af846a95dfa4", "0x4085bb2f3d4afe4e6c7bffa2f5f9b9c0ed3b5906", "0x0b3e86cda8492d5a706bf91310bcbc3b48771c27ffe09b341081e34fac9c2d54", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540969117 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x088900c93556a2d1a92ece502d7a7414b2b79177"}, {name: "amount", type: "uint256", value: "196040000000000000"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: placeBet( \"2\", \"2\", \"6616379\", \"11360853049... )", async function( ) {
		const txOriginal = {blockNumber: "6616137", timeStamp: "1540969125", hash: "0xf0aba3e1817fd85bf5d5d47e18a9f2febd42666f56566bb5374d0cd8cf118de2", nonce: "740", blockHash: "0xb226429c6345267d1f91b2c8f63f8c659389bcbb3ea3227d44bff50be0c71208", transactionIndex: "17", from: "0x60f4c86457c1954c0ca963dc03534c3311967beb", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "10000000000000000", gas: "150000", gasPrice: "13850000000", isError: "0", txreceipt_status: "1", input: "0x5e83b46300000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000064f53bfb2c2648db9825e04d86ead0bed8829661e7783c2108fa443563c5293b4c3f1948c9d7574323d60940224040461b5842e48916ccdaecc930e29f6055320435a646a244c839836106a7edbf27f54d5f76979803a182319395a8017645fafaf198", contractAddress: "", cumulativeGasUsed: "860511", gasUsed: "123615", confirmations: "1115738"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betMask", value: "2"}, {type: "uint256", name: "modulo", value: "2"}, {type: "uint256", name: "commitLastBlock", value: "6616379"}, {type: "uint256", name: "commit", value: "113608530495853432381747630071597623114674596651377036348750599083913365962521"}, {type: "bytes32", name: "r", value: "0x48c9d7574323d60940224040461b5842e48916ccdaecc930e29f6055320435a6"}, {type: "bytes32", name: "s", value: "0x46a244c839836106a7edbf27f54d5f76979803a182319395a8017645fafaf198"}], name: "placeBet", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "placeBet(uint256,uint256,uint256,uint256,bytes32,bytes32)" ]( "2", "2", "6616379", "113608530495853432381747630071597623114674596651377036348750599083913365962521", "0x48c9d7574323d60940224040461b5842e48916ccdaecc930e29f6055320435a6", "0x46a244c839836106a7edbf27f54d5f76979803a182319395a8017645fafaf198", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540969125 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "commit", type: "uint256"}], name: "Commit", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Commit", events: [{name: "commit", type: "uint256", value: "113608530495853432381747630071597623114674596651377036348750599083913365962521"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "39858961602084294" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: settleBet( \"0x4e1ab9a23329525defe1f2cff1fd4564e74e... )", async function( ) {
		const txOriginal = {blockNumber: "6616140", timeStamp: "1540969155", hash: "0xff827acf23b69b7455062914949cd70fb5c3a0f245f5f6af35b00750bd0a1eb9", nonce: "13013", blockHash: "0xeffdcca89dcfc29e57a547a2cad5f320d71e9ed9a6bf9fa1bbe3538caac229b7", transactionIndex: "124", from: "0x01fd2b8c9c81044d37352704f1ce9ada7e1b6ae2", to: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62", value: "0", gas: "65000", gasPrice: "12500000000", isError: "0", txreceipt_status: "1", input: "0xe163b75b4e1ab9a23329525defe1f2cff1fd4564e74ed265000000000000000000000000b009f2297754a3c0db612e8423d2779df64f928d000000000000000000000000b226429c6345267d1f91b2c8f63f8c659389bcbb3ea3227d44bff50be0c71208", contractAddress: "", cumulativeGasUsed: "3502627", gasUsed: "36082", confirmations: "1115735"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes20", name: "reveal1", value: "0x4e1ab9a23329525defe1f2cff1fd4564e74ed265"}, {type: "bytes20", name: "reveal2", value: "0xb009f2297754a3c0db612e8423d2779df64f928d"}, {type: "bytes32", name: "blockHash", value: "0xb226429c6345267d1f91b2c8f63f8c659389bcbb3ea3227d44bff50be0c71208"}], name: "settleBet", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "settleBet(bytes20,bytes20,bytes32)" ]( "0x4e1ab9a23329525defe1f2cff1fd4564e74ed265", "0xb009f2297754a3c0db612e8423d2779df64f928d", "0xb226429c6345267d1f91b2c8f63f8c659389bcbb3ea3227d44bff50be0c71208", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540969155 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Payment", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Payment", events: [{name: "beneficiary", type: "address", value: "0x60f4c86457c1954c0ca963dc03534c3311967beb"}, {name: "amount", type: "uint256", value: "0"}], address: "0x0be3e6e3d9e99036ccce4fd0b692016de860aa62"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "60000000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
