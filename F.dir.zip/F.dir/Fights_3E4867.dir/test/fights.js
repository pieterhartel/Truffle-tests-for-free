const Fights = artifacts.require( "./Fights.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Fights" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xFE4E742F7AaF30186A3A3B290304eB8D613E4867", "0xEdbBdf2c29ccf6A0272b36B10eaDC1B17b8D7e67", "0xd2BaE9A30A40376d25353773010FFe52dBa0D688", "0x04C271ef0E8dD18A24C194aE7E72d74398B3B4b0", "0x759C2712e1D390fE66493a5fC7aec0ff8bb021b7", "0xe9601d9A1F804e7b983bD58E454FCD69165223dd", "0x913A367b57E17c2fCD28B8b1D7761971D608248d", "0x72F6A6b22427F33b99B39Fa504697C9ED56afb2D", "0x4189f423E18877bdbb1E48723A3e4a7FA7503D5D", "0x6915ac44aBD61065EDE89c49a8c61a1595ef867F", "0x753a9080D9F9bEf59E89852C68CcCB82782548Ca"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_fightId", type: "uint256"}], name: "getFightRaces", outputs: [{name: "", type: "uint256[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentFightId", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minBetsLevel", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "coin", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "fightsCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "heroes", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentFight", outputs: [{name: "fightId", type: "uint256"}, {name: "startedAt", type: "uint256"}, {name: "finishedAt", type: "uint256"}, {name: "startCheckedAt", type: "uint256"}, {name: "finishCheckedAt", type: "uint256"}, {name: "fightersCount", type: "uint256"}, {name: "raceCount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_fightId", type: "uint256"}, {name: "_tokenId", type: "uint256"}], name: "getFightFighter", outputs: [{name: "index", type: "uint256"}, {name: "race", type: "uint256"}, {name: "level", type: "uint256"}, {name: "enemyRace", type: "uint256"}, {name: "finished", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "characterLastFight", outputs: [{name: "index", type: "uint256"}, {name: "race", type: "uint256"}, {name: "level", type: "uint256"}, {name: "enemyRace", type: "uint256"}, {name: "finished", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_fightId", type: "uint256"}, {name: "_tokenId", type: "uint256"}], name: "getFightResult", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_fightId", type: "uint256"}, {name: "_race", type: "uint256"}], name: "getFightRace", outputs: [{name: "index", type: "uint256"}, {name: "count", type: "uint256"}, {name: "enemyCount", type: "uint256"}, {name: "result", type: "int32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "fightsList", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentFightInterval", outputs: [{name: "fightId", type: "uint256"}, {name: "currentTime", type: "uint256"}, {name: "applicationStartAt", type: "uint256"}, {name: "betsStartAt", type: "uint256"}, {name: "fightStartAt", type: "uint256"}, {name: "fightFinishAt", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], name: "characterFights", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_fightId", type: "uint256"}, {name: "_race", type: "uint256"}, {name: "_level", type: "uint256"}], name: "getFightRaceLevelStat", outputs: [{name: "levelCount", type: "uint256"}, {name: "levelSum", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_fightId", type: "uint256"}], name: "getFight", outputs: [{name: "startedAt", type: "uint256"}, {name: "finishedAt", type: "uint256"}, {name: "startCheckedAt", type: "uint256"}, {name: "finishCheckedAt", type: "uint256"}, {name: "fightersCount", type: "uint256"}, {name: "raceCount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_fightId", type: "uint256"}, {name: "_fighterIndex", type: "uint256"}], name: "getFightArenaFighter", outputs: [{name: "tokenId", type: "uint256"}, {name: "race", type: "uint256"}, {name: "level", type: "uint256"}, {name: "enemyRace", type: "uint256"}, {name: "finished", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tokenId", type: "uint256"}], name: "isAllowed", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getNextFightId", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "allowEnterDuringBets", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "FightEpoch", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getNextFight", outputs: [{name: "fightId", type: "uint256"}, {name: "startedAt", type: "uint256"}, {name: "finishedAt", type: "uint256"}, {name: "startCheckedAt", type: "uint256"}, {name: "finishCheckedAt", type: "uint256"}, {name: "fightersCount", type: "uint256"}, {name: "raceCount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "characterFightsCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getNextFightInterval", outputs: [{name: "fightId", type: "uint256"}, {name: "currentTime", type: "uint256"}, {name: "applicationStartAt", type: "uint256"}, {name: "betsStartAt", type: "uint256"}, {name: "fightStartAt", type: "uint256"}, {name: "fightFinishAt", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentIntervals", outputs: [{name: "fightsInterval", type: "uint256"}, {name: "fightPeriod", type: "uint256"}, {name: "applicationPeriod", type: "uint256"}, {name: "betsPeriod", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "intervalHistory", outputs: [{name: "fightsInterval", type: "uint256"}, {name: "startsFrom", type: "uint256"}, {name: "fightsCount", type: "uint256"}, {name: "betsPeriod", type: "uint256"}, {name: "applicationPeriod", type: "uint256"}, {name: "fightPeriod", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "characterLastFightId", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "account", type: "address"}], name: "isService", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "startsFrom", type: "uint256"}, {indexed: false, name: "pastFightsCount", type: "uint256"}, {indexed: false, name: "fightsInterval", type: "uint256"}, {indexed: false, name: "fightPeriod", type: "uint256"}, {indexed: false, name: "applicationPeriod", type: "uint256"}, {indexed: false, name: "betsPeriod", type: "uint256"}], name: "SetFightInterval", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "ChangeEnemy", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}, {indexed: false, name: "level", type: "uint256"}], name: "LeaveArena", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startAt", type: "uint256"}], name: "StartFight", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}], name: "RemoveFight", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "races", type: "uint256[]"}, {indexed: false, name: "values", type: "uint256[]"}], name: "FightResult", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "finishedAt", type: "uint256"}, {indexed: false, name: "startCheckedAt", type: "uint256"}, {indexed: false, name: "finishCheckedAt", type: "uint256"}], name: "FinishFight", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ServiceAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ServiceRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["SetFightInterval(uint256,uint256,uint256,uint256,uint256,uint256)", "EnterArena(uint256,uint256,uint256,uint256,uint256)", "ChangeEnemy(uint256,uint256,uint256)", "LeaveArena(uint256,uint256,uint8,uint256)", "StartFight(uint256,uint256)", "RemoveFight(uint256)", "FightResult(uint256,uint256[],uint256[])", "FinishFight(uint256,uint256,uint256,uint256,uint256)", "ServiceAdded(address)", "ServiceRemoved(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x4866753a4625576d8b01981204276f4356057877cabf1897c1e1d9a60944c09b", "0x6563ab3e87e07fafec12460b17de576dc62a63fb581399b22f819819013bcdcb", "0x96361fd78374e8db7f54e7905f14be4f83a8acd1146261af063ac3162806ed0c", "0x8ab6d2fc25ebf1b30b51a24e8dc05f2026e6b35cd0ea2fbca00c3b8686425fb9", "0x741d6830bd6bee6083baeb087fa1fafcce39d4cfc39dbee7aeba78828fd8f87b", "0x2d2b43a12d43408023d28376ada9be8b6b0082eff051f50b9468bd3b0aaab56b", "0xd6755b591b94d60783c6751a704837c5ee9dd14f8083706986e1675603ffc74a", "0x0593fc07b92f4bc56df604a5a9522f2562a79b38c5fb2a4250c1fea6b8163120", "0xc917ab672aa101ddaa2e4db6de34f67d180098d502a2ed9e199f79b4c4333a6b", "0x29d546abb6e94f4f04d5bdccb6682316f597d43776078f47e273f000e77b2a91", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6841286 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6853586 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_heroes", value: 4}, {type: "address", name: "_coin", value: 5}], name: "Fights", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "_fightId", value: random.range( maxRandom )}], name: "getFightRaces", outputs: [{name: "", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFightRaces(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentFightId", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentFightId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minBetsLevel", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minBetsLevel()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "coin", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "coin()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "fightsCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fightsCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "heroes", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "heroes()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentFight", outputs: [{name: "fightId", type: "uint256"}, {name: "startedAt", type: "uint256"}, {name: "finishedAt", type: "uint256"}, {name: "startCheckedAt", type: "uint256"}, {name: "finishCheckedAt", type: "uint256"}, {name: "fightersCount", type: "uint256"}, {name: "raceCount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentFight()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_fightId", value: random.range( maxRandom )}, {type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "getFightFighter", outputs: [{name: "index", type: "uint256"}, {name: "race", type: "uint256"}, {name: "level", type: "uint256"}, {name: "enemyRace", type: "uint256"}, {name: "finished", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFightFighter(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "characterLastFight", outputs: [{name: "index", type: "uint256"}, {name: "race", type: "uint256"}, {name: "level", type: "uint256"}, {name: "enemyRace", type: "uint256"}, {name: "finished", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "characterLastFight(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_fightId", value: random.range( maxRandom )}, {type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "getFightResult", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFightResult(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_fightId", value: random.range( maxRandom )}, {type: "uint256", name: "_race", value: random.range( maxRandom )}], name: "getFightRace", outputs: [{name: "index", type: "uint256"}, {name: "count", type: "uint256"}, {name: "enemyCount", type: "uint256"}, {name: "result", type: "int32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFightRace(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "fightsList", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fightsList(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentFightInterval", outputs: [{name: "fightId", type: "uint256"}, {name: "currentTime", type: "uint256"}, {name: "applicationStartAt", type: "uint256"}, {name: "betsStartAt", type: "uint256"}, {name: "fightStartAt", type: "uint256"}, {name: "fightFinishAt", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentFightInterval()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "characterFights", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "characterFights(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_fightId", value: random.range( maxRandom )}, {type: "uint256", name: "_race", value: random.range( maxRandom )}, {type: "uint256", name: "_level", value: random.range( maxRandom )}], name: "getFightRaceLevelStat", outputs: [{name: "levelCount", type: "uint256"}, {name: "levelSum", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFightRaceLevelStat(uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_fightId", value: random.range( maxRandom )}], name: "getFight", outputs: [{name: "startedAt", type: "uint256"}, {name: "finishedAt", type: "uint256"}, {name: "startCheckedAt", type: "uint256"}, {name: "finishCheckedAt", type: "uint256"}, {name: "fightersCount", type: "uint256"}, {name: "raceCount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFight(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_fightId", value: random.range( maxRandom )}, {type: "uint256", name: "_fighterIndex", value: random.range( maxRandom )}], name: "getFightArenaFighter", outputs: [{name: "tokenId", type: "uint256"}, {name: "race", type: "uint256"}, {name: "level", type: "uint256"}, {name: "enemyRace", type: "uint256"}, {name: "finished", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFightArenaFighter(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tokenId", value: random.range( maxRandom )}], name: "isAllowed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isAllowed(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getNextFightId", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNextFightId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "allowEnterDuringBets", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowEnterDuringBets()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "FightEpoch", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "FightEpoch()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getNextFight", outputs: [{name: "fightId", type: "uint256"}, {name: "startedAt", type: "uint256"}, {name: "finishedAt", type: "uint256"}, {name: "startCheckedAt", type: "uint256"}, {name: "finishCheckedAt", type: "uint256"}, {name: "fightersCount", type: "uint256"}, {name: "raceCount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNextFight()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "characterFightsCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "characterFightsCount(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getNextFightInterval", outputs: [{name: "fightId", type: "uint256"}, {name: "currentTime", type: "uint256"}, {name: "applicationStartAt", type: "uint256"}, {name: "betsStartAt", type: "uint256"}, {name: "fightStartAt", type: "uint256"}, {name: "fightFinishAt", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNextFightInterval()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentIntervals", outputs: [{name: "fightsInterval", type: "uint256"}, {name: "fightPeriod", type: "uint256"}, {name: "applicationPeriod", type: "uint256"}, {name: "betsPeriod", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentIntervals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "intervalHistory", outputs: [{name: "fightsInterval", type: "uint256"}, {name: "startsFrom", type: "uint256"}, {name: "fightsCount", type: "uint256"}, {name: "betsPeriod", type: "uint256"}, {name: "applicationPeriod", type: "uint256"}, {name: "fightPeriod", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "intervalHistory(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "characterLastFightId", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "characterLastFightId(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "account", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isService", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isService(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Fights", function( accounts ) {

	it( "TEST: Fights( addressList[4], addressList[5] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6841286", blockHash: "0x0a0ee32351c3a40ede41a30aceb7c1fc5b5c9740bb58f1d8832d878e274afdf0", timeStamp: "1544166713", hash: "0x72ee48cee8f3e9410c8383bb50dcf7f1fe6075143e0e4d06b6255f5d9b6d294f", nonce: "1899", transactionIndex: "69", from: "0xedbbdf2c29ccf6a0272b36b10eadc1b17b8d7e67", to: 0, value: "0", gas: "3970026", gasPrice: "5000000000", input: "0x13a95d55000000000000000000000000d2bae9a30a40376d25353773010ffe52dba0d68800000000000000000000000004c271ef0e8dd18a24c194ae7e72d74398b3b4b0", contractAddress: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", cumulativeGasUsed: "6835756", txreceipt_status: "1", gasUsed: "3970026", confirmations: "838233", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_heroes", value: addressList[4]}, {type: "address", name: "_coin", value: addressList[5]}], name: "Fights", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Fights.new( addressList[4], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1544166713 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Fights.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ServiceAdded", type: "event"} ;
		console.error( "eventCallOriginal[0,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ServiceAdded", events: [{name: "account", type: "address", value: "0xedbbdf2c29ccf6a0272b36b10eadc1b17b8d7e67"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[0,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"} ;
		console.error( "eventCallOriginal[0,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnershipTransferred", events: [{name: "previousOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0xedbbdf2c29ccf6a0272b36b10eadc1b17b8d7e67"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[0,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "54006985835754189" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"609\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6841773", blockHash: "0x043328904dce6886cfa4d2431b8e411e375f2040b7f0323adc702faf13a0e7b1", timeStamp: "1544173716", hash: "0xf0c493f2e46ea76fcb0a6ca02429885f90bf23bb85f1d2fa4efc0dafd09835b6", nonce: "1906", transactionIndex: "168", from: "0xedbbdf2c29ccf6a0272b36b10eadc1b17b8d7e67", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "540550", gasPrice: "5000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002610000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7659879", txreceipt_status: "1", gasUsed: "540550", confirmations: "837746", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "609"}, {type: "uint256", name: "_enemyRace", value: "1"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "609", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1544173716 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "609"}, {name: "fightId", type: "uint256", value: "45"}, {name: "startsAt", type: "uint256", value: "1544184000"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "1"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startAt", type: "uint256"}], name: "StartFight", type: "event"} ;
		console.error( "eventCallOriginal[1,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartFight", events: [{name: "fightId", type: "uint256", value: "45"}, {name: "startAt", type: "uint256", value: "1544184000"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[1,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "54006985835754189" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: addService( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6842157", blockHash: "0xc1a9b576914d2be17e3f84f5e45b20fc9d3b8c8e84b57f6f389a2fc5d5332ec6", timeStamp: "1544179475", hash: "0xdc2c79451c477a7beeb7e0a11b32de7395553b046b59b57e5f97c834d96e35a7", nonce: "1909", transactionIndex: "58", from: "0xedbbdf2c29ccf6a0272b36b10eadc1b17b8d7e67", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "46015", gasPrice: "5000000000", input: "0x5372a9ce000000000000000000000000759c2712e1d390fe66493a5fc7aec0ff8bb021b7", contractAddress: "", cumulativeGasUsed: "7148733", txreceipt_status: "1", gasUsed: "46015", confirmations: "837362", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "account", value: addressList[6]}], name: "addService", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addService(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1544179475 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "ServiceAdded", type: "event"} ;
		console.error( "eventCallOriginal[2,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ServiceAdded", events: [{name: "account", type: "address", value: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[2,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "54006985835754189" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"716\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6843461", blockHash: "0x4fd662eebeac9b2756a128863273387948e2256106ef92c562feff9bb793300f", timeStamp: "1544198086", hash: "0x6700390fb0c13866f5ec3cda95c57544068fae82c7be3dc2111a5d4f33e3ab69", nonce: "67", transactionIndex: "20", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "510550", gasPrice: "9000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002cc0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1998268", txreceipt_status: "1", gasUsed: "510550", confirmations: "836058", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "716"}, {type: "uint256", name: "_enemyRace", value: "1"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "716", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1544198086 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "716"}, {name: "fightId", type: "uint256", value: "46"}, {name: "startsAt", type: "uint256", value: "1544227200"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "1"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startAt", type: "uint256"}], name: "StartFight", type: "event"} ;
		console.error( "eventCallOriginal[3,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartFight", events: [{name: "fightId", type: "uint256", value: "46"}, {name: "startAt", type: "uint256", value: "1544227200"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[3,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"714\", \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6843463", blockHash: "0x31667da656d8f380942bc268c7e602923af50b894ccc56aea7aca85a886a78f4", timeStamp: "1544198106", hash: "0xd1640630f6db9f61faad19711bdb00bb0ad749313f4b7aba9a548d09b4f9a776", nonce: "68", transactionIndex: "63", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "525550", gasPrice: "9000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002ca0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "3922940", txreceipt_status: "1", gasUsed: "478965", confirmations: "836056", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "714"}, {type: "uint256", name: "_enemyRace", value: "6"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "714", "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1544198106 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "714"}, {name: "fightId", type: "uint256", value: "46"}, {name: "startsAt", type: "uint256", value: "1544227200"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "6"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"719\", \"12\" )", async function( ) {
		const txOriginal = {blockNumber: "6843465", blockHash: "0x2567fdff86e43ee44dfdab22081a05120c25180cca8fc3dbba59e1bd6f1ca48b", timeStamp: "1544198117", hash: "0x26d8f670a29c295f26eabb03da1fc648d945cf202c7c4427bde00beeeae41272", nonce: "70", transactionIndex: "23", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "510550", gasPrice: "9000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002cf000000000000000000000000000000000000000000000000000000000000000c", contractAddress: "", cumulativeGasUsed: "1462459", txreceipt_status: "1", gasUsed: "463965", confirmations: "836054", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "719"}, {type: "uint256", name: "_enemyRace", value: "12"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "719", "12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1544198117 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "719"}, {name: "fightId", type: "uint256", value: "46"}, {name: "startsAt", type: "uint256", value: "1544227200"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "12"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"715\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6843557", blockHash: "0x3153618b5254f47b3994c1f20a1c79e3cb9afb64790eb39bb70b868490644962", timeStamp: "1544199592", hash: "0x419bc916c56b0f2f82c21858cd3ea8b23aa5b667c52db8f4a647f3f8ab6c9d4e", nonce: "71", transactionIndex: "126", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "383421", gasPrice: "9000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002cb0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7282074", txreceipt_status: "1", gasUsed: "383421", confirmations: "835962", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "715"}, {type: "uint256", name: "_enemyRace", value: "1"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "715", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1544199592 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "715"}, {name: "fightId", type: "uint256", value: "46"}, {name: "startsAt", type: "uint256", value: "1544227200"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "1"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setFightResult( \"45\", \"2\", [\"17179869185\"], [\"184... )", async function( ) {
		const txOriginal = {blockNumber: "6843851", blockHash: "0xa744474521ba4a45491af5f6af87ec332fdc897e218ecaaabf7d08277966eeff", timeStamp: "1544203661", hash: "0x4084cc5d11a15f8cf43b6c6c6c07cec0ce03e8b0e448d1cc1baf910056d79397", nonce: "0", transactionIndex: "51", from: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "3000000", gasPrice: "6000000000", input: "0x8600ac74000000000000000000000000000000000000000000000000000000000000002d0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000004000000010000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000fffca0b8fffb156c", contractAddress: "", cumulativeGasUsed: "3094016", txreceipt_status: "1", gasUsed: "70217", confirmations: "835668", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "fightId", value: "45"}, {type: "uint256", name: "count", value: "2"}, {type: "uint256[]", name: "packedRaces", value: ["17179869185"]}, {type: "uint256[]", name: "packedResults", value: ["18445794890231780716"]}], name: "setFightResult", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFightResult(uint256,uint256,uint256[],uint256[])" ]( "45", "2", ["17179869185"], ["18445794890231780716"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1544203661 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "races", type: "uint256[]"}, {indexed: false, name: "values", type: "uint256[]"}], name: "FightResult", type: "event"} ;
		console.error( "eventCallOriginal[7,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FightResult", events: [{name: "fightId", type: "uint256", value: "45"}, {name: "races", type: "uint256[]", value: [{s: 1, e: 10, c: [17179869185]}]}, {name: "values", type: "uint256[]", value: [{s: 1, e: 19, c: [184457, 94890231780716]}]}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[7,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "52648748186315318" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"704\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6843856", blockHash: "0xf34285f23a59e00e4c10bbd52174892721d3b5dab9f8805102f22c0e322222e8", timeStamp: "1544203711", hash: "0xf031e5dd6627331d34832c46048573fffcc04d86986f27659cd7674db9f7e808", nonce: "7", transactionIndex: "85", from: "0x913a367b57e17c2fcd28b8b1d7761971d608248d", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "363117", gasPrice: "4000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002c00000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6922072", txreceipt_status: "1", gasUsed: "363117", confirmations: "835663", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "704"}, {type: "uint256", name: "_enemyRace", value: "2"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "704", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1544203711 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "704"}, {name: "fightId", type: "uint256", value: "46"}, {name: "startsAt", type: "uint256", value: "1544227200"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "2"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "956242000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: finishFight( \"45\", \"1544184028\", \"1544202018\" )", async function( ) {
		const txOriginal = {blockNumber: "6843862", blockHash: "0x3efa1cc1801a150af0bf762f26831a190fa75b0c835b7e4e5e97e95f37603193", timeStamp: "1544203794", hash: "0x468bf35b046c61106efc4ef9f635937ee04a4260b4bc5a630f7c88f4e800110d", nonce: "1", transactionIndex: "30", from: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "3000000", gasPrice: "6000000000", input: "0x1255479f000000000000000000000000000000000000000000000000000000000000002d000000000000000000000000000000000000000000000000000000005c0a60dc000000000000000000000000000000000000000000000000000000005c0aa722", contractAddress: "", cumulativeGasUsed: "1881557", txreceipt_status: "1", gasUsed: "89592", confirmations: "835657", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "fightId", value: "45"}, {type: "uint256", name: "startCheckedAt", value: "1544184028"}, {type: "uint256", name: "finishCheckedAt", value: "1544202018"}], name: "finishFight", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "finishFight(uint256,uint256,uint256)" ]( "45", "1544184028", "1544202018", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1544203794 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "finishedAt", type: "uint256"}, {indexed: false, name: "startCheckedAt", type: "uint256"}, {indexed: false, name: "finishCheckedAt", type: "uint256"}], name: "FinishFight", type: "event"} ;
		console.error( "eventCallOriginal[9,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FinishFight", events: [{name: "fightId", type: "uint256", value: "45"}, {name: "startedAt", type: "uint256", value: "1544184000"}, {name: "finishedAt", type: "uint256", value: "1544203794"}, {name: "startCheckedAt", type: "uint256", value: "1544184028"}, {name: "finishCheckedAt", type: "uint256", value: "1544202018"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[9,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "52648748186315318" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"727\", \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6843983", blockHash: "0xf5f702dc184a384c2e478e4b6a1de69d87bc61e08422e586b169c2b29f1749c2", timeStamp: "1544205378", hash: "0x8b9900de6f271309827ddee7ef1b9ff235819a8bad6d14271fdb8f4a71ce3250", nonce: "41", transactionIndex: "18", from: "0x72f6a6b22427f33b99b39fa504697c9ed56afb2d", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "317877", gasPrice: "6000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002d70000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "1416784", txreceipt_status: "1", gasUsed: "317877", confirmations: "835536", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "727"}, {type: "uint256", name: "_enemyRace", value: "5"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "727", "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1544205378 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "727"}, {name: "fightId", type: "uint256", value: "46"}, {name: "startsAt", type: "uint256", value: "1544227200"}, {name: "level", type: "uint256", value: "29"}, {name: "enemyRace", type: "uint256", value: "5"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "35043747347150832" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"688\", \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6843991", blockHash: "0x97140d7e9ba8242b2acb17ea20f33db0703a72191080add59491f4d4a4733d64", timeStamp: "1544205505", hash: "0x912ed3e58430af46cbfdd5e72dd3d1d377608a66afca61031c81ed55ac9ef5df", nonce: "42", transactionIndex: "126", from: "0x72f6a6b22427f33b99b39fa504697c9ed56afb2d", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "317877", gasPrice: "6000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002b00000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "6866043", txreceipt_status: "1", gasUsed: "317877", confirmations: "835528", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "688"}, {type: "uint256", name: "_enemyRace", value: "4"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "688", "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1544205505 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "688"}, {name: "fightId", type: "uint256", value: "46"}, {name: "startsAt", type: "uint256", value: "1544227200"}, {name: "level", type: "uint256", value: "29"}, {name: "enemyRace", type: "uint256", value: "4"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "35043747347150832" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: leaveArena( \"609\", false )", async function( ) {
		const txOriginal = {blockNumber: "6843992", blockHash: "0x3f99c44ce34d2903b74e0fec0ea2e898f2f04e6f0ff0482e3854ee16ddfe8abb", timeStamp: "1544205512", hash: "0x6ebce202c9d441a70a4be5ef0e832d6bb2621d7ae17f1c59c66b648dc433e3b4", nonce: "1984", transactionIndex: "66", from: "0xedbbdf2c29ccf6a0272b36b10eadc1b17b8d7e67", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "109149", gasPrice: "4000000000", input: "0xbd2c940a00000000000000000000000000000000000000000000000000000000000002610000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7832094", txreceipt_status: "1", gasUsed: "79149", confirmations: "835527", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "609"}, {type: "bool", name: "_useCoin", value: false}], name: "leaveArena", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "leaveArena(uint256,bool)" ]( "609", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1544205512 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}, {indexed: false, name: "level", type: "uint256"}], name: "LeaveArena", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LeaveArena", events: [{name: "tokenId", type: "uint256", value: "609"}, {name: "fightId", type: "uint256", value: "45"}, {name: "result", type: "uint8", value: "1"}, {name: "level", type: "uint256", value: "30"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "54006985835754189" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"734\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6848083", blockHash: "0xd5d6d47b230733b76e193d15ad4f3b40da81f98cc42554e1747f8ac117ec3647", timeStamp: "1544264565", hash: "0x44bdc04fb978bdef77e03ca21b856c7280d5196066bdd2c4b705ac1462b79dad", nonce: "144", transactionIndex: "156", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "510550", gasPrice: "5000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002de0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7994230", txreceipt_status: "1", gasUsed: "510550", confirmations: "831436", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "734"}, {type: "uint256", name: "_enemyRace", value: "1"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "734", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1544264565 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "734"}, {name: "fightId", type: "uint256", value: "47"}, {name: "startsAt", type: "uint256", value: "1544270400"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "1"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startAt", type: "uint256"}], name: "StartFight", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartFight", events: [{name: "fightId", type: "uint256", value: "47"}, {name: "startAt", type: "uint256", value: "1544270400"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"183\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6848087", blockHash: "0x2258ac42b3f6ad5186338f77eefedc0036826d7dfcd1f67d9b0cd482ebda904e", timeStamp: "1544264594", hash: "0x01fb6fb7fab99eda049d8456ed004e1c478887416b9c5c3ccf4eef0515169c16", nonce: "145", transactionIndex: "16", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "478901", gasPrice: "5000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000000b70000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "2360900", txreceipt_status: "1", gasUsed: "478901", confirmations: "831432", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "183"}, {type: "uint256", name: "_enemyRace", value: "2"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "183", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1544264594 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "183"}, {name: "fightId", type: "uint256", value: "47"}, {name: "startsAt", type: "uint256", value: "1544270400"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "2"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: setFightResult( \"46\", \"8\", [\"3235193600623015931647... )", async function( ) {
		const txOriginal = {blockNumber: "6849853", blockHash: "0x960477cb04e97433dd60ae0f07a2ccc2beb6030249d736dcce7761e9b24b12af", timeStamp: "1544289838", hash: "0x2600d65b964059869d0bec936463338b1213102489f0f9ff49fcf2dd92ff7b7a", nonce: "2", transactionIndex: "68", from: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "3000000", gasPrice: "6000000000", input: "0x8600ac74000000000000000000000000000000000000000000000000000000000000002e0000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000010000000c000000090000000700000006000000050000000400000002000000010000000000000000000000000000000000000000000000000000000000000001002e26df0005686d0007b97a0001511e00011a7b00022c940004de4b0002ef59", contractAddress: "", cumulativeGasUsed: "4876657", txreceipt_status: "1", gasUsed: "196449", confirmations: "829666", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "fightId", value: "46"}, {type: "uint256", name: "count", value: "8"}, {type: "uint256[]", name: "packedRaces", value: ["323519360062301593164714819382115687521862296237847406219872918568961"]}, {type: "uint256[]", name: "packedResults", value: ["81543243411315181635511878010760457066474585561411215775492302840147406681"]}], name: "setFightResult", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFightResult(uint256,uint256,uint256[],uint256[])" ]( "46", "8", ["323519360062301593164714819382115687521862296237847406219872918568961"], ["81543243411315181635511878010760457066474585561411215775492302840147406681"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1544289838 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "races", type: "uint256[]"}, {indexed: false, name: "values", type: "uint256[]"}], name: "FightResult", type: "event"} ;
		console.error( "eventCallOriginal[15,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FightResult", events: [{name: "fightId", type: "uint256", value: "46"}, {name: "races", type: "uint256[]", value: [{s: 1, e: 68, c: [3235193600623, 1593164714819, 38211568752186, 22962378474062, 19872918568961]}]}, {name: "values", type: "uint256[]", value: [{s: 1, e: 73, c: [8154, 32434113151816, 35511878010760, 45706647458556, 14112157754923, 2840147406681]}]}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[15,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "52648748186315318" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: finishFight( \"46\", \"1544227212\", \"1544245219\" )", async function( ) {
		const txOriginal = {blockNumber: "6849902", blockHash: "0xa64dbeec9ea184eb819988a2c20ba6fd58e5d5bc4295da52757234d8fbdac2d0", timeStamp: "1544290510", hash: "0xf7ff80ecfd4b08f067432574e77081de0476d61b7ee4cbd33c811c0969d7a0ad", nonce: "3", transactionIndex: "18", from: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "100000", gasPrice: "6000000000", input: "0x1255479f000000000000000000000000000000000000000000000000000000000000002e000000000000000000000000000000000000000000000000000000005c0b098c000000000000000000000000000000000000000000000000000000005c0b4fe3", contractAddress: "", cumulativeGasUsed: "2123351", txreceipt_status: "1", gasUsed: "89592", confirmations: "829617", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "fightId", value: "46"}, {type: "uint256", name: "startCheckedAt", value: "1544227212"}, {type: "uint256", name: "finishCheckedAt", value: "1544245219"}], name: "finishFight", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "finishFight(uint256,uint256,uint256)" ]( "46", "1544227212", "1544245219", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1544290510 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "finishedAt", type: "uint256"}, {indexed: false, name: "startCheckedAt", type: "uint256"}, {indexed: false, name: "finishCheckedAt", type: "uint256"}], name: "FinishFight", type: "event"} ;
		console.error( "eventCallOriginal[16,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FinishFight", events: [{name: "fightId", type: "uint256", value: "46"}, {name: "startedAt", type: "uint256", value: "1544227200"}, {name: "finishedAt", type: "uint256", value: "1544290510"}, {name: "startCheckedAt", type: "uint256", value: "1544227212"}, {name: "finishCheckedAt", type: "uint256", value: "1544245219"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[16,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "52648748186315318" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: finishFight( \"47\", \"1544270403\", \"1544288401\" )", async function( ) {
		const txOriginal = {blockNumber: "6849921", blockHash: "0x6f3c872b98981e3fb47edaef738e5ef56d4f21137ac9338e774b4539d884dec4", timeStamp: "1544290786", hash: "0xe6d26678e51f8f3bdd5b44368093d8b8a9859dadc6b000c9840c70b962213615", nonce: "4", transactionIndex: "81", from: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "100000", gasPrice: "4800000000", input: "0x1255479f000000000000000000000000000000000000000000000000000000000000002f000000000000000000000000000000000000000000000000000000005c0bb243000000000000000000000000000000000000000000000000000000005c0bf891", contractAddress: "", cumulativeGasUsed: "4194646", txreceipt_status: "1", gasUsed: "89592", confirmations: "829598", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "fightId", value: "47"}, {type: "uint256", name: "startCheckedAt", value: "1544270403"}, {type: "uint256", name: "finishCheckedAt", value: "1544288401"}], name: "finishFight", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "finishFight(uint256,uint256,uint256)" ]( "47", "1544270403", "1544288401", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1544290786 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "finishedAt", type: "uint256"}, {indexed: false, name: "startCheckedAt", type: "uint256"}, {indexed: false, name: "finishCheckedAt", type: "uint256"}], name: "FinishFight", type: "event"} ;
		console.error( "eventCallOriginal[17,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FinishFight", events: [{name: "fightId", type: "uint256", value: "47"}, {name: "startedAt", type: "uint256", value: "1544270400"}, {name: "finishedAt", type: "uint256", value: "1544290786"}, {name: "startCheckedAt", type: "uint256", value: "1544270403"}, {name: "finishCheckedAt", type: "uint256", value: "1544288401"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[17,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "52648748186315318" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"609\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6850254", blockHash: "0x7a60dd7a1ed1fda229cefa596aecb246feaf1577b7faa5d7e79ff93a3011a0b8", timeStamp: "1544295392", hash: "0xdacec1411a97af25f3d6562cc41312d1a77347494a18da5078037b8695c668d8", nonce: "1985", transactionIndex: "22", from: "0xedbbdf2c29ccf6a0272b36b10eadc1b17b8d7e67", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "511470", gasPrice: "3300000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002610000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3180281", txreceipt_status: "1", gasUsed: "511470", confirmations: "829265", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "609"}, {type: "uint256", name: "_enemyRace", value: "1"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "609", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1544295392 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "609"}, {name: "fightId", type: "uint256", value: "48"}, {name: "startsAt", type: "uint256", value: "1544313600"}, {name: "level", type: "uint256", value: "31"}, {name: "enemyRace", type: "uint256", value: "1"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startAt", type: "uint256"}], name: "StartFight", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartFight", events: [{name: "fightId", type: "uint256", value: "48"}, {name: "startAt", type: "uint256", value: "1544313600"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "54006985835754189" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"482\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6850462", blockHash: "0x7de38ddc936c8f509d6aed5e484c4ddd76d1f4773769201eb9aaca6d46e18b40", timeStamp: "1544298081", hash: "0x25021a4d1b7ae0ed23dbfb10e46510b61343349f8b3d1aab8576b7958f6cdd9c", nonce: "15", transactionIndex: "173", from: "0x6915ac44abd61065ede89c49a8c61a1595ef867f", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "525550", gasPrice: "3000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000001e20000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7644844", txreceipt_status: "1", gasUsed: "413421", confirmations: "829057", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "482"}, {type: "uint256", name: "_enemyRace", value: "2"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "482", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1544298081 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "482"}, {name: "fightId", type: "uint256", value: "48"}, {name: "startsAt", type: "uint256", value: "1544313600"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "2"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "8127633275000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: leaveArena( \"719\", false )", async function( ) {
		const txOriginal = {blockNumber: "6850467", blockHash: "0x0b3f9bcd5ed3c1d069897aa59adbd5a72f1c102bd9201011c30ca87d112af913", timeStamp: "1544298143", hash: "0x36a6ddab5cd7f536dd49775bf867d47dfdf79fc8d9ca66a36dadf1d7c5578b7d", nonce: "91", transactionIndex: "35", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "109971", gasPrice: "5000000000", input: "0xbd2c940a00000000000000000000000000000000000000000000000000000000000002cf0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1364916", txreceipt_status: "1", gasUsed: "79971", confirmations: "829052", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "719"}, {type: "bool", name: "_useCoin", value: false}], name: "leaveArena", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "leaveArena(uint256,bool)" ]( "719", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1544298143 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}, {indexed: false, name: "level", type: "uint256"}], name: "LeaveArena", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LeaveArena", events: [{name: "tokenId", type: "uint256", value: "719"}, {name: "fightId", type: "uint256", value: "46"}, {name: "result", type: "uint8", value: "2"}, {name: "level", type: "uint256", value: "30"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: leaveArena( \"716\", true )", async function( ) {
		const txOriginal = {blockNumber: "6850469", blockHash: "0x82648956a2f2c3d2947c83a5dd48857dcddaefeabb08b2f1c7ec21cfe8e23068", timeStamp: "1544298181", hash: "0x0ca8505d9a20e30ffc8f70aa8ffe213740a98709a81d4a8c3fea6ee97e833637", nonce: "92", transactionIndex: "268", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "130789", gasPrice: "3000000000", input: "0xbd2c940a00000000000000000000000000000000000000000000000000000000000002cc0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7880052", txreceipt_status: "1", gasUsed: "100789", confirmations: "829050", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "716"}, {type: "bool", name: "_useCoin", value: true}], name: "leaveArena", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "leaveArena(uint256,bool)" ]( "716", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1544298181 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}, {indexed: false, name: "level", type: "uint256"}], name: "LeaveArena", type: "event"} ;
		console.error( "eventCallOriginal[21,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LeaveArena", events: [{name: "tokenId", type: "uint256", value: "716"}, {name: "fightId", type: "uint256", value: "46"}, {name: "result", type: "uint8", value: "2"}, {name: "level", type: "uint256", value: "30"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[21,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: leaveArena( \"715\", true )", async function( ) {
		const txOriginal = {blockNumber: "6850481", blockHash: "0xec4d4139c20d08d667fb07865bf1ece27570b6f6101c9b900e7e975445638fe2", timeStamp: "1544298299", hash: "0x61aaeb2f13b471d87ba6191ad73763376616d36d2708db872c4daf6e57d1ca27", nonce: "93", transactionIndex: "96", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "109213", gasPrice: "3000000000", input: "0xbd2c940a00000000000000000000000000000000000000000000000000000000000002cb0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6518004", txreceipt_status: "1", gasUsed: "79213", confirmations: "829038", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "715"}, {type: "bool", name: "_useCoin", value: true}], name: "leaveArena", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "leaveArena(uint256,bool)" ]( "715", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1544298299 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}, {indexed: false, name: "level", type: "uint256"}], name: "LeaveArena", type: "event"} ;
		console.error( "eventCallOriginal[22,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LeaveArena", events: [{name: "tokenId", type: "uint256", value: "715"}, {name: "fightId", type: "uint256", value: "46"}, {name: "result", type: "uint8", value: "1"}, {name: "level", type: "uint256", value: "30"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[22,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"711\", \"11\" )", async function( ) {
		const txOriginal = {blockNumber: "6850712", blockHash: "0x9b58dd31504eb5ef0fd4beff9b6dbc4e7cd41863f8beccad1a036bc67e807cf5", timeStamp: "1544301378", hash: "0xecdd8ac23d54e03f133631dfbed431718d52cc65002c8acc86e8553ac1707f58", nonce: "15", transactionIndex: "59", from: "0x753a9080d9f9bef59e89852c68cccb82782548ca", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "413421", gasPrice: "3000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002c7000000000000000000000000000000000000000000000000000000000000000b", contractAddress: "", cumulativeGasUsed: "7970633", txreceipt_status: "0", gasUsed: "413421", confirmations: "828807", isError: "1"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "711"}, {type: "uint256", name: "_enemyRace", value: "11"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "934607747247746" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: leaveArena( \"714\", true )", async function( ) {
		const txOriginal = {blockNumber: "6850745", blockHash: "0x24441bc094a677ad66c82df6af91ba31a8145a68a8e7fd1bbae3b65166fb7e50", timeStamp: "1544301958", hash: "0x2fefc21748f9f88cace193e5f2a105f45c31e3953cc22429d934d1702d5464d5", nonce: "94", transactionIndex: "60", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "109213", gasPrice: "3000000000", input: "0xbd2c940a00000000000000000000000000000000000000000000000000000000000002ca0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6059807", txreceipt_status: "1", gasUsed: "79213", confirmations: "828774", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "714"}, {type: "bool", name: "_useCoin", value: true}], name: "leaveArena", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "leaveArena(uint256,bool)" ]( "714", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1544301958 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}, {indexed: false, name: "level", type: "uint256"}], name: "LeaveArena", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LeaveArena", events: [{name: "tokenId", type: "uint256", value: "714"}, {name: "fightId", type: "uint256", value: "46"}, {name: "result", type: "uint8", value: "1"}, {name: "level", type: "uint256", value: "30"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"719\", \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6850745", blockHash: "0x24441bc094a677ad66c82df6af91ba31a8145a68a8e7fd1bbae3b65166fb7e50", timeStamp: "1544301958", hash: "0x3c0c0511d1421cf7cb348221bd17f5d2009c8a6761a122e0c2e1408386075828", nonce: "95", transactionIndex: "61", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "464885", gasPrice: "3000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002cf0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "6524692", txreceipt_status: "1", gasUsed: "464885", confirmations: "828774", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "719"}, {type: "uint256", name: "_enemyRace", value: "6"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "719", "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1544301958 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "719"}, {name: "fightId", type: "uint256", value: "48"}, {name: "startsAt", type: "uint256", value: "1544313600"}, {name: "level", type: "uint256", value: "29"}, {name: "enemyRace", type: "uint256", value: "6"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"711\", \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6850773", blockHash: "0x81bf13bf2d24aafc9645d25209df1954e82128f6cefa66b93f6746c9a26afaea", timeStamp: "1544302334", hash: "0xbece5fa247f24362538c9584c0f747d89e7ab5c6196c17cd9f6cfd348bad43f0", nonce: "16", transactionIndex: "84", from: "0x753a9080d9f9bef59e89852c68cccb82782548ca", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "413421", gasPrice: "3000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002c70000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "7459723", txreceipt_status: "1", gasUsed: "413421", confirmations: "828746", isError: "0"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "711"}, {type: "uint256", name: "_enemyRace", value: "4"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "711", "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1544302334 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "711"}, {name: "fightId", type: "uint256", value: "48"}, {name: "startsAt", type: "uint256", value: "1544313600"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "4"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "934607747247746" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"718\", \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6850872", blockHash: "0x73469f4bde2a683d3d7fe717ca91b66ee9d50b811440aa0371c6da894971ca2d", timeStamp: "1544303939", hash: "0xe513229be51c1494fc61b1c25c9725dddce53293d49d64976fe3ccc1a13aad11", nonce: "96", transactionIndex: "68", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "398421", gasPrice: "3000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002ce0000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "7047970", txreceipt_status: "1", gasUsed: "383421", confirmations: "828647", isError: "0"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "718"}, {type: "uint256", name: "_enemyRace", value: "4"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "718", "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1544303939 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "718"}, {name: "fightId", type: "uint256", value: "48"}, {name: "startsAt", type: "uint256", value: "1544313600"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "4"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"716\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6850884", blockHash: "0x019690933f012482873ca714724f46cbf003913397d5c1e5c9e6e5e579afdafb", timeStamp: "1544304096", hash: "0x650139257846cb3d6d7eb5fb831afe56917594c27956989c81ccfeb69a771ed4", nonce: "97", transactionIndex: "32", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "288797", gasPrice: "3000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002cc0000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7854885", txreceipt_status: "1", gasUsed: "288797", confirmations: "828635", isError: "0"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "716"}, {type: "uint256", name: "_enemyRace", value: "2"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "716", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1544304096 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "716"}, {name: "fightId", type: "uint256", value: "48"}, {name: "startsAt", type: "uint256", value: "1544313600"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "2"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"715\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6850885", blockHash: "0x4ee742f73271225387c63b59256221ea61b776de9753fa158f5bef7af184c7b6", timeStamp: "1544304116", hash: "0x40bb4315d6d36826f04643ba4bf16a857abb11918b00346319deee39d6a10627", nonce: "98", transactionIndex: "84", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "384341", gasPrice: "3000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002cb0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7866252", txreceipt_status: "1", gasUsed: "384341", confirmations: "828634", isError: "0"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "715"}, {type: "uint256", name: "_enemyRace", value: "1"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "715", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1544304116 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "715"}, {name: "fightId", type: "uint256", value: "48"}, {name: "startsAt", type: "uint256", value: "1544313600"}, {name: "level", type: "uint256", value: "31"}, {name: "enemyRace", type: "uint256", value: "1"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: leaveArena( \"714\", true )", async function( ) {
		const txOriginal = {blockNumber: "6850887", blockHash: "0x0e47ea2e0a733b5ed88224dc80bf430ac4f49c7f8476f14999a905c0c15a0611", timeStamp: "1544304151", hash: "0xb4e64c3f9a10c1b3ed7c3b52ea9b83338f32455c3a06769052edc841a64a3d89", nonce: "99", transactionIndex: "94", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "109213", gasPrice: "3000000000", input: "0xbd2c940a00000000000000000000000000000000000000000000000000000000000002ca0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7898277", txreceipt_status: "0", gasUsed: "27809", confirmations: "828632", isError: "1"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "714"}, {type: "bool", name: "_useCoin", value: true}], name: "leaveArena", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "leaveArena(uint256,bool)" ]( "714", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1544304151 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"714\", \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6850890", blockHash: "0x252348d0100c232387303ba9d8bda701d0d0e0306ae4220ad2c8a151fa123363", timeStamp: "1544304181", hash: "0x32fa50300ae0c6080d81515c7a31a57c932086e8767654c7f2dc3a15f37bbffa", nonce: "100", transactionIndex: "28", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "384341", gasPrice: "4000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002ca0000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "3660444", txreceipt_status: "1", gasUsed: "384341", confirmations: "828629", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "714"}, {type: "uint256", name: "_enemyRace", value: "6"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "714", "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1544304181 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "714"}, {name: "fightId", type: "uint256", value: "48"}, {name: "startsAt", type: "uint256", value: "1544313600"}, {name: "level", type: "uint256", value: "31"}, {name: "enemyRace", type: "uint256", value: "6"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: setFightResult( \"48\", \"9\", [\"2965594133951509533700... )", async function( ) {
		const txOriginal = {blockNumber: "6852795", blockHash: "0x7e6101cfe086ab63212f1cbe7f66250cefed7564c18c3837d34cc20e52e9efcb", timeStamp: "1544331624", hash: "0xbf5928b331e55830710084cc41bef592691542f434b7b947dca9ca548ed747d2", nonce: "5", transactionIndex: "245", from: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "350000", gasPrice: "6000000000", input: "0x8600ac7400000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000020000000b00000009000000070000000600000005000000040000000200000001000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000200006e0400033acf00016a1f0001b23700018a0a000040fe0002f9d00000c69800000000000000000000000000000000000000000000000000000000ffffdd38", contractAddress: "", cumulativeGasUsed: "7414622", txreceipt_status: "1", gasUsed: "218201", confirmations: "826724", isError: "0"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "fightId", value: "48"}, {type: "uint256", name: "count", value: "9"}, {type: "uint256[]", name: "packedRaces", value: ["296559413395150953370047804295096056848225151815306833738769308319745","12"]}, {type: "uint256[]", name: "packedResults", value: ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"]}], name: "setFightResult", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFightResult(uint256,uint256,uint256[],uint256[])" ]( "48", "9", ["296559413395150953370047804295096056848225151815306833738769308319745","12"], ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1544331624 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "races", type: "uint256[]"}, {indexed: false, name: "values", type: "uint256[]"}], name: "FightResult", type: "event"} ;
		console.error( "eventCallOriginal[32,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FightResult", events: [{name: "fightId", type: "uint256", value: "48"}, {name: "races", type: "uint256[]", value: [{s: 1, e: 68, c: [2965594133951, 50953370047804, 29509605684822, 51518153068337, 38769308319745]}, {s: 1, e: 1, c: [12]}]}, {name: "values", type: "uint256[]", value: [{s: 1, e: 71, c: [75, 92999392622608, 3929638409749, 90771583551368, 75210992042772, 12006978733720]}, {s: 1, e: 9, c: [4294958392]}]}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[32,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "52648748186315318" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: setFightResult( \"48\", \"9\", [\"2965594133951509533700... )", async function( ) {
		const txOriginal = {blockNumber: "6852804", blockHash: "0xc0893b69e238ba7c137bd3e9356fbeb2d4e5df91948b884cc80b105d36dfe7bd", timeStamp: "1544331717", hash: "0x0d3e7ab1a590bf4c225e85fca9d172a5b07f946af5baea27066135a2fc89d3a3", nonce: "6", transactionIndex: "103", from: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "350000", gasPrice: "6000000000", input: "0x8600ac7400000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000020000000b00000009000000070000000600000005000000040000000200000001000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000200006e0400033acf00016a1f0001b23700018a0a000040fe0002f9d00000c69800000000000000000000000000000000000000000000000000000000ffffdd38", contractAddress: "", cumulativeGasUsed: "6588581", txreceipt_status: "1", gasUsed: "83201", confirmations: "826715", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "fightId", value: "48"}, {type: "uint256", name: "count", value: "9"}, {type: "uint256[]", name: "packedRaces", value: ["296559413395150953370047804295096056848225151815306833738769308319745","12"]}, {type: "uint256[]", name: "packedResults", value: ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"]}], name: "setFightResult", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFightResult(uint256,uint256,uint256[],uint256[])" ]( "48", "9", ["296559413395150953370047804295096056848225151815306833738769308319745","12"], ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1544331717 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "races", type: "uint256[]"}, {indexed: false, name: "values", type: "uint256[]"}], name: "FightResult", type: "event"} ;
		console.error( "eventCallOriginal[33,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FightResult", events: [{name: "fightId", type: "uint256", value: "48"}, {name: "races", type: "uint256[]", value: [{s: 1, e: 68, c: [2965594133951, 50953370047804, 29509605684822, 51518153068337, 38769308319745]}, {s: 1, e: 1, c: [12]}]}, {name: "values", type: "uint256[]", value: [{s: 1, e: 71, c: [75, 92999392622608, 3929638409749, 90771583551368, 75210992042772, 12006978733720]}, {s: 1, e: 9, c: [4294958392]}]}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[33,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "52648748186315318" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: setFightResult( \"48\", \"9\", [\"2965594133951509533700... )", async function( ) {
		const txOriginal = {blockNumber: "6852808", blockHash: "0xb03f381216570bbd40120301d8a53f06f15e85968661a1e6ef3f49dc1b79a6f3", timeStamp: "1544331790", hash: "0x57d4eac001abcbe3760f54c57f23059014fd77d22263e2ca8b40c9bb62186855", nonce: "7", transactionIndex: "44", from: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "350000", gasPrice: "6000000000", input: "0x8600ac7400000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000020000000b00000009000000070000000600000005000000040000000200000001000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000200006e0400033acf00016a1f0001b23700018a0a000040fe0002f9d00000c69800000000000000000000000000000000000000000000000000000000ffffdd38", contractAddress: "", cumulativeGasUsed: "1938618", txreceipt_status: "1", gasUsed: "83201", confirmations: "826711", isError: "0"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "fightId", value: "48"}, {type: "uint256", name: "count", value: "9"}, {type: "uint256[]", name: "packedRaces", value: ["296559413395150953370047804295096056848225151815306833738769308319745","12"]}, {type: "uint256[]", name: "packedResults", value: ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"]}], name: "setFightResult", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFightResult(uint256,uint256,uint256[],uint256[])" ]( "48", "9", ["296559413395150953370047804295096056848225151815306833738769308319745","12"], ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1544331790 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "races", type: "uint256[]"}, {indexed: false, name: "values", type: "uint256[]"}], name: "FightResult", type: "event"} ;
		console.error( "eventCallOriginal[34,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FightResult", events: [{name: "fightId", type: "uint256", value: "48"}, {name: "races", type: "uint256[]", value: [{s: 1, e: 68, c: [2965594133951, 50953370047804, 29509605684822, 51518153068337, 38769308319745]}, {s: 1, e: 1, c: [12]}]}, {name: "values", type: "uint256[]", value: [{s: 1, e: 71, c: [75, 92999392622608, 3929638409749, 90771583551368, 75210992042772, 12006978733720]}, {s: 1, e: 9, c: [4294958392]}]}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[34,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "52648748186315318" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: setFightResult( \"48\", \"9\", [\"2965594133951509533700... )", async function( ) {
		const txOriginal = {blockNumber: "6852815", blockHash: "0x4787c2d485d4f92b11f9b23d5cd939804cbedb2e25070167d3c027ff6e9cd23d", timeStamp: "1544331917", hash: "0x9b30594a5bdbaee1a1962f6580a3efa77bc66ea51d99708896208f34b142e7cb", nonce: "8", transactionIndex: "103", from: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "350000", gasPrice: "6000000000", input: "0x8600ac7400000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000020000000b00000009000000070000000600000005000000040000000200000001000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000200006e0400033acf00016a1f0001b23700018a0a000040fe0002f9d00000c69800000000000000000000000000000000000000000000000000000000ffffdd38", contractAddress: "", cumulativeGasUsed: "4922310", txreceipt_status: "1", gasUsed: "83201", confirmations: "826704", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "fightId", value: "48"}, {type: "uint256", name: "count", value: "9"}, {type: "uint256[]", name: "packedRaces", value: ["296559413395150953370047804295096056848225151815306833738769308319745","12"]}, {type: "uint256[]", name: "packedResults", value: ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"]}], name: "setFightResult", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFightResult(uint256,uint256,uint256[],uint256[])" ]( "48", "9", ["296559413395150953370047804295096056848225151815306833738769308319745","12"], ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1544331917 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "races", type: "uint256[]"}, {indexed: false, name: "values", type: "uint256[]"}], name: "FightResult", type: "event"} ;
		console.error( "eventCallOriginal[35,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FightResult", events: [{name: "fightId", type: "uint256", value: "48"}, {name: "races", type: "uint256[]", value: [{s: 1, e: 68, c: [2965594133951, 50953370047804, 29509605684822, 51518153068337, 38769308319745]}, {s: 1, e: 1, c: [12]}]}, {name: "values", type: "uint256[]", value: [{s: 1, e: 71, c: [75, 92999392622608, 3929638409749, 90771583551368, 75210992042772, 12006978733720]}, {s: 1, e: 9, c: [4294958392]}]}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[35,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "52648748186315318" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: setFightResult( \"48\", \"9\", [\"2965594133951509533700... )", async function( ) {
		const txOriginal = {blockNumber: "6852818", blockHash: "0x9ae702faeee9525988735bbf556488d38cbd5a6ba725c4a2eb20da3aa148dfac", timeStamp: "1544331974", hash: "0x7a74176e80d91c153a07faa0de3fadb6951fdf60f96e323070adbb7f69af04ed", nonce: "9", transactionIndex: "29", from: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "350000", gasPrice: "6000000000", input: "0x8600ac7400000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000020000000b00000009000000070000000600000005000000040000000200000001000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000200006e0400033acf00016a1f0001b23700018a0a000040fe0002f9d00000c69800000000000000000000000000000000000000000000000000000000ffffdd38", contractAddress: "", cumulativeGasUsed: "6638698", txreceipt_status: "1", gasUsed: "83201", confirmations: "826701", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "fightId", value: "48"}, {type: "uint256", name: "count", value: "9"}, {type: "uint256[]", name: "packedRaces", value: ["296559413395150953370047804295096056848225151815306833738769308319745","12"]}, {type: "uint256[]", name: "packedResults", value: ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"]}], name: "setFightResult", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFightResult(uint256,uint256,uint256[],uint256[])" ]( "48", "9", ["296559413395150953370047804295096056848225151815306833738769308319745","12"], ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1544331974 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "races", type: "uint256[]"}, {indexed: false, name: "values", type: "uint256[]"}], name: "FightResult", type: "event"} ;
		console.error( "eventCallOriginal[36,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FightResult", events: [{name: "fightId", type: "uint256", value: "48"}, {name: "races", type: "uint256[]", value: [{s: 1, e: 68, c: [2965594133951, 50953370047804, 29509605684822, 51518153068337, 38769308319745]}, {s: 1, e: 1, c: [12]}]}, {name: "values", type: "uint256[]", value: [{s: 1, e: 71, c: [75, 92999392622608, 3929638409749, 90771583551368, 75210992042772, 12006978733720]}, {s: 1, e: 9, c: [4294958392]}]}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[36,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "52648748186315318" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: setFightResult( \"48\", \"9\", [\"2965594133951509533700... )", async function( ) {
		const txOriginal = {blockNumber: "6852822", blockHash: "0xdf7bd57dfdd408a0b29adf95413d450961999ab8c298cd1281fb5e7c3bda4661", timeStamp: "1544332071", hash: "0x9a9a34898e8267d631766119422324af5d6e8f79fab40dca3ef44d5f91fd48bb", nonce: "10", transactionIndex: "125", from: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "350000", gasPrice: "6000000000", input: "0x8600ac7400000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000020000000b00000009000000070000000600000005000000040000000200000001000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000200006e0400033acf00016a1f0001b23700018a0a000040fe0002f9d00000c69800000000000000000000000000000000000000000000000000000000ffffdd38", contractAddress: "", cumulativeGasUsed: "7001478", txreceipt_status: "1", gasUsed: "83201", confirmations: "826697", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "fightId", value: "48"}, {type: "uint256", name: "count", value: "9"}, {type: "uint256[]", name: "packedRaces", value: ["296559413395150953370047804295096056848225151815306833738769308319745","12"]}, {type: "uint256[]", name: "packedResults", value: ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"]}], name: "setFightResult", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFightResult(uint256,uint256,uint256[],uint256[])" ]( "48", "9", ["296559413395150953370047804295096056848225151815306833738769308319745","12"], ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1544332071 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "races", type: "uint256[]"}, {indexed: false, name: "values", type: "uint256[]"}], name: "FightResult", type: "event"} ;
		console.error( "eventCallOriginal[37,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FightResult", events: [{name: "fightId", type: "uint256", value: "48"}, {name: "races", type: "uint256[]", value: [{s: 1, e: 68, c: [2965594133951, 50953370047804, 29509605684822, 51518153068337, 38769308319745]}, {s: 1, e: 1, c: [12]}]}, {name: "values", type: "uint256[]", value: [{s: 1, e: 71, c: [75, 92999392622608, 3929638409749, 90771583551368, 75210992042772, 12006978733720]}, {s: 1, e: 9, c: [4294958392]}]}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[37,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "52648748186315318" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: setFightResult( \"48\", \"9\", [\"2965594133951509533700... )", async function( ) {
		const txOriginal = {blockNumber: "6852828", blockHash: "0x93bf88f16f5eb279ada4a186c531d0eb8623f9cd9f5db7228c06e6d76c2b2386", timeStamp: "1544332236", hash: "0xd4ca52a1a8152cb63ff59d173649266a415e0ebe6aeb105c71ddae2b682167c4", nonce: "11", transactionIndex: "58", from: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "350000", gasPrice: "6000000000", input: "0x8600ac7400000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000009000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000020000000b00000009000000070000000600000005000000040000000200000001000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000200006e0400033acf00016a1f0001b23700018a0a000040fe0002f9d00000c69800000000000000000000000000000000000000000000000000000000ffffdd38", contractAddress: "", cumulativeGasUsed: "3445106", txreceipt_status: "1", gasUsed: "83201", confirmations: "826691", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "fightId", value: "48"}, {type: "uint256", name: "count", value: "9"}, {type: "uint256[]", name: "packedRaces", value: ["296559413395150953370047804295096056848225151815306833738769308319745","12"]}, {type: "uint256[]", name: "packedResults", value: ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"]}], name: "setFightResult", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFightResult(uint256,uint256,uint256[],uint256[])" ]( "48", "9", ["296559413395150953370047804295096056848225151815306833738769308319745","12"], ["759299939262260803929638409749907715835513687521099204277212006978733720","4294958392"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1544332236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "races", type: "uint256[]"}, {indexed: false, name: "values", type: "uint256[]"}], name: "FightResult", type: "event"} ;
		console.error( "eventCallOriginal[38,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FightResult", events: [{name: "fightId", type: "uint256", value: "48"}, {name: "races", type: "uint256[]", value: [{s: 1, e: 68, c: [2965594133951, 50953370047804, 29509605684822, 51518153068337, 38769308319745]}, {s: 1, e: 1, c: [12]}]}, {name: "values", type: "uint256[]", value: [{s: 1, e: 71, c: [75, 92999392622608, 3929638409749, 90771583551368, 75210992042772, 12006978733720]}, {s: 1, e: 9, c: [4294958392]}]}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[38,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "52648748186315318" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: finishFight( \"48\", \"1544313603\", \"1544331602\" )", async function( ) {
		const txOriginal = {blockNumber: "6852863", blockHash: "0x070a397f70c2d4fce4df46b76a7cce336ff7f9051d3f3ef8e67c527d960d51d0", timeStamp: "1544332769", hash: "0x586a8bf29a819df11cdc8cc7b272ff30ae79719cc328e686bbdfcefd43e9a441", nonce: "12", transactionIndex: "112", from: "0x759c2712e1d390fe66493a5fc7aec0ff8bb021b7", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "100000", gasPrice: "3000000000", input: "0x1255479f0000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000005c0c5b03000000000000000000000000000000000000000000000000000000005c0ca152", contractAddress: "", cumulativeGasUsed: "7684624", txreceipt_status: "1", gasUsed: "89592", confirmations: "826656", isError: "0"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "fightId", value: "48"}, {type: "uint256", name: "startCheckedAt", value: "1544313603"}, {type: "uint256", name: "finishCheckedAt", value: "1544331602"}], name: "finishFight", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "finishFight(uint256,uint256,uint256)" ]( "48", "1544313603", "1544331602", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1544332769 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "finishedAt", type: "uint256"}, {indexed: false, name: "startCheckedAt", type: "uint256"}, {indexed: false, name: "finishCheckedAt", type: "uint256"}], name: "FinishFight", type: "event"} ;
		console.error( "eventCallOriginal[39,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FinishFight", events: [{name: "fightId", type: "uint256", value: "48"}, {name: "startedAt", type: "uint256", value: "1544313600"}, {name: "finishedAt", type: "uint256", value: "1544332769"}, {name: "startCheckedAt", type: "uint256", value: "1544313603"}, {name: "finishCheckedAt", type: "uint256", value: "1544331602"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[39,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "52648748186315318" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: leaveArena( \"183\", false )", async function( ) {
		const txOriginal = {blockNumber: "6852876", blockHash: "0xe703f8403f2b930472a3646d9b3ff243bb9d5237dae5d3a98d318e935d4f3218", timeStamp: "1544332986", hash: "0x075b7fd1b1a4aecc30e8754dca819a7c8d4d59297d751eb83ecf31418826ac99", nonce: "146", transactionIndex: "50", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "76374", gasPrice: "3000000000", input: "0xbd2c940a00000000000000000000000000000000000000000000000000000000000000b70000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6820058", txreceipt_status: "1", gasUsed: "46374", confirmations: "826643", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "183"}, {type: "bool", name: "_useCoin", value: false}], name: "leaveArena", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "leaveArena(uint256,bool)" ]( "183", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1544332986 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}, {indexed: false, name: "level", type: "uint256"}], name: "LeaveArena", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LeaveArena", events: [{name: "tokenId", type: "uint256", value: "183"}, {name: "fightId", type: "uint256", value: "47"}, {name: "result", type: "uint8", value: "3"}, {name: "level", type: "uint256", value: "30"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: leaveArena( \"734\", false )", async function( ) {
		const txOriginal = {blockNumber: "6852883", blockHash: "0xf1c479df8dd4a598207b20f98bea99af2d4b62c078096e765425d702dfb7b13d", timeStamp: "1544333075", hash: "0xc7d4739da01e07186443ee168f531be82178a7264bf34d1cd59b853c8f81b510", nonce: "147", transactionIndex: "45", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "76438", gasPrice: "3000000000", input: "0xbd2c940a00000000000000000000000000000000000000000000000000000000000002de0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7402017", txreceipt_status: "1", gasUsed: "46438", confirmations: "826636", isError: "0"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "734"}, {type: "bool", name: "_useCoin", value: false}], name: "leaveArena", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "leaveArena(uint256,bool)" ]( "734", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1544333075 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}, {indexed: false, name: "level", type: "uint256"}], name: "LeaveArena", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LeaveArena", events: [{name: "tokenId", type: "uint256", value: "734"}, {name: "fightId", type: "uint256", value: "47"}, {name: "result", type: "uint8", value: "3"}, {name: "level", type: "uint256", value: "30"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"734\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6852933", blockHash: "0x9bd89f28c176ee78316039bacea917f5db91716565c8b050926485f067bad14f", timeStamp: "1544333836", hash: "0x10ed6d57afb921a958de645fb7a26cfa4c0b6d2665081209df667db7d3f65a17", nonce: "150", transactionIndex: "35", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "511470", gasPrice: "4000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002de0000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "3142669", txreceipt_status: "1", gasUsed: "511470", confirmations: "826586", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "734"}, {type: "uint256", name: "_enemyRace", value: "2"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "734", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1544333836 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "734"}, {name: "fightId", type: "uint256", value: "49"}, {name: "startsAt", type: "uint256", value: "1544356800"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "2"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startAt", type: "uint256"}], name: "StartFight", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartFight", events: [{name: "fightId", type: "uint256", value: "49"}, {name: "startAt", type: "uint256", value: "1544356800"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"733\", \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "6853440", blockHash: "0x44f21b5a8a0018f63369b1a724ad7ada3a6515b4bb4b232e42604874b2c8cd20", timeStamp: "1544340737", hash: "0xc1d3e503fab445486723b9c05389cc0d8cc75ece73ea324646c6cd305ede822c", nonce: "151", transactionIndex: "49", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "398421", gasPrice: "3000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002dd0000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "7239702", txreceipt_status: "1", gasUsed: "398421", confirmations: "826079", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "733"}, {type: "uint256", name: "_enemyRace", value: "7"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "733", "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1544340737 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "733"}, {name: "fightId", type: "uint256", value: "49"}, {name: "startsAt", type: "uint256", value: "1544356800"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "7"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: leaveArena( \"719\", true )", async function( ) {
		const txOriginal = {blockNumber: "6853544", blockHash: "0xe1d01009e07aeca1b0afbcf686ace96991d539a006f4eabaad5564ccee8d52b7", timeStamp: "1544342221", hash: "0x24d87a9c2b190451aac9f5970bd32004a3931cafd972304701996c43e4999388", nonce: "104", transactionIndex: "75", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "115789", gasPrice: "3000000000", input: "0xbd2c940a00000000000000000000000000000000000000000000000000000000000002cf0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7728655", txreceipt_status: "1", gasUsed: "85789", confirmations: "825975", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "719"}, {type: "bool", name: "_useCoin", value: true}], name: "leaveArena", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "leaveArena(uint256,bool)" ]( "719", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1544342221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}, {indexed: false, name: "level", type: "uint256"}], name: "LeaveArena", type: "event"} ;
		console.error( "eventCallOriginal[44,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LeaveArena", events: [{name: "tokenId", type: "uint256", value: "719"}, {name: "fightId", type: "uint256", value: "48"}, {name: "result", type: "uint8", value: "2"}, {name: "level", type: "uint256", value: "29"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[44,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: leaveArena( \"718\", true )", async function( ) {
		const txOriginal = {blockNumber: "6853552", blockHash: "0x8e7bcd55d90e0286a8ab8b70088d3ab4a8956f73942dbd8a1de89a36a9251132", timeStamp: "1544342346", hash: "0x47f7c2f1123cb9652d3a9b9b45f6c5e625083090d2098403ee24211c2fddbf6f", nonce: "105", transactionIndex: "188", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "109213", gasPrice: "3000000000", input: "0xbd2c940a00000000000000000000000000000000000000000000000000000000000002ce0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7717147", txreceipt_status: "1", gasUsed: "79213", confirmations: "825967", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "718"}, {type: "bool", name: "_useCoin", value: true}], name: "leaveArena", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "leaveArena(uint256,bool)" ]( "718", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1544342346 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}, {indexed: false, name: "level", type: "uint256"}], name: "LeaveArena", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LeaveArena", events: [{name: "tokenId", type: "uint256", value: "718"}, {name: "fightId", type: "uint256", value: "48"}, {name: "result", type: "uint8", value: "1"}, {name: "level", type: "uint256", value: "30"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: leaveArena( \"716\", true )", async function( ) {
		const txOriginal = {blockNumber: "6853552", blockHash: "0x8e7bcd55d90e0286a8ab8b70088d3ab4a8956f73942dbd8a1de89a36a9251132", timeStamp: "1544342346", hash: "0xe981a3d16af4f97ea5a0a2574aa9704c226c07fa5f2b50e8dd8ae0238679b9a1", nonce: "106", transactionIndex: "189", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "115789", gasPrice: "3000000000", input: "0xbd2c940a00000000000000000000000000000000000000000000000000000000000002cc0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7802936", txreceipt_status: "1", gasUsed: "85789", confirmations: "825967", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "716"}, {type: "bool", name: "_useCoin", value: true}], name: "leaveArena", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "leaveArena(uint256,bool)" ]( "716", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1544342346 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}, {indexed: false, name: "level", type: "uint256"}], name: "LeaveArena", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LeaveArena", events: [{name: "tokenId", type: "uint256", value: "716"}, {name: "fightId", type: "uint256", value: "48"}, {name: "result", type: "uint8", value: "2"}, {name: "level", type: "uint256", value: "30"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: leaveArena( \"715\", true )", async function( ) {
		const txOriginal = {blockNumber: "6853552", blockHash: "0x8e7bcd55d90e0286a8ab8b70088d3ab4a8956f73942dbd8a1de89a36a9251132", timeStamp: "1544342346", hash: "0xc89c61aea5916df0b5330274af6fc00255bff751f7878ebf1d30f53c69ccf4ad", nonce: "107", transactionIndex: "190", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "94213", gasPrice: "3000000000", input: "0xbd2c940a00000000000000000000000000000000000000000000000000000000000002cb0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7867149", txreceipt_status: "1", gasUsed: "64213", confirmations: "825967", isError: "0"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "715"}, {type: "bool", name: "_useCoin", value: true}], name: "leaveArena", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "leaveArena(uint256,bool)" ]( "715", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544342346 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}, {indexed: false, name: "level", type: "uint256"}], name: "LeaveArena", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LeaveArena", events: [{name: "tokenId", type: "uint256", value: "715"}, {name: "fightId", type: "uint256", value: "48"}, {name: "result", type: "uint8", value: "1"}, {name: "level", type: "uint256", value: "31"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: leaveArena( \"714\", true )", async function( ) {
		const txOriginal = {blockNumber: "6853558", blockHash: "0x58e52e20733f62325e0fc0a49a6fff1a7729f008a494dd82d4cd18ade650dc3b", timeStamp: "1544342387", hash: "0x74dbdb29009fa6ed9743a3017f64c4069c0b6b5a987454fb7bfe7ba8d776474f", nonce: "108", transactionIndex: "43", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "130789", gasPrice: "3000000000", input: "0xbd2c940a00000000000000000000000000000000000000000000000000000000000002ca0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5841592", txreceipt_status: "1", gasUsed: "100789", confirmations: "825961", isError: "0"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "714"}, {type: "bool", name: "_useCoin", value: true}], name: "leaveArena", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "leaveArena(uint256,bool)" ]( "714", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1544342387 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "result", type: "uint8"}, {indexed: false, name: "level", type: "uint256"}], name: "LeaveArena", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LeaveArena", events: [{name: "tokenId", type: "uint256", value: "714"}, {name: "fightId", type: "uint256", value: "48"}, {name: "result", type: "uint8", value: "2"}, {name: "level", type: "uint256", value: "31"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: enterArena( \"716\", \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "6853586", blockHash: "0x9080d9f44cfdad5f36bf1e27c02215debb4df3df74ccb975c281241d278027d6", timeStamp: "1544342663", hash: "0xef88b0227dbc9f95e153c0a3e6fb48f5f1b734d272e040d6bd28eee9f55bcb0b", nonce: "109", transactionIndex: "107", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867", value: "0", gas: "268493", gasPrice: "4000000000", input: "0xb97c2a8b00000000000000000000000000000000000000000000000000000000000002cc0000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "4977984", txreceipt_status: "1", gasUsed: "268493", confirmations: "825933", isError: "0"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokenId", value: "716"}, {type: "uint256", name: "_enemyRace", value: "7"}], name: "enterArena", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enterArena(uint256,uint256)" ]( "716", "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544342663 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "tokenId", type: "uint256"}, {indexed: false, name: "fightId", type: "uint256"}, {indexed: false, name: "startsAt", type: "uint256"}, {indexed: false, name: "level", type: "uint256"}, {indexed: false, name: "enemyRace", type: "uint256"}], name: "EnterArena", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EnterArena", events: [{name: "tokenId", type: "uint256", value: "716"}, {name: "fightId", type: "uint256", value: "49"}, {name: "startsAt", type: "uint256", value: "1544356800"}, {name: "level", type: "uint256", value: "30"}, {name: "enemyRace", type: "uint256", value: "7"}], address: "0xfe4e742f7aaf30186a3a3b290304eb8d613e4867"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
