const FountainToken = artifacts.require( "./FountainToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "FountainToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x82Cf44bE0768A3600c4BDeA58607783A3A7c51AE", "0x1D76324F495591b003C8a73aA64e0F9A5E9727e1", "0xB4698bB1133fbFb0E2a092a910C78c9f19C8fB8D", "0x148A6c3c4f53594bd7D23494FCaaB2460561f266", "0xBe643E42B7fE7e5CE2AB1D51bf9896305e027e1d", "0x939dB03bba71DBb292C4400258bBD28cF34a2a17", "0xC84901BFd3Be8a6ceACF7180Ce3ba0968a90b9b0", "0x5eCDeD59d436af5a4eD2A89DD23E13CCF868A5E2", "0x5d37c7e396dA9F2e26c2F8E249ADE617756Ab3Ba", "0x6c093b68104D56323444dD9c6b77476Fb241D893", "0xC881AF3864276104B77BBF225CEaa1901CEEE0cc", "0xbFaf9ef45C07A9CB49c52a60a53740f587762A1b", "0x08C1fF4E253f7436A1a3c6CC4d19cB06B51a09B4", "0x5ACB6D754037463319A8407fEEB3c38c6db1FEe1", "0x3293072676BbDe0C688C5D3D21b765e127ee1Cc7", "0x05d4d45707af4171f8668AC75eBC6cC95Ba84abB", "0xD246Ef8C4aA0Cd01c3F939279c61c0d0B00E1f2A", "0xf2Ec6f70Dfdc02AA2B72e4B90f593Fe5A7817057", "0x92D74811f935D07dfC851fC5976b3A22B628E4Ef", "0xd4554679BC0CEf5E6Ec7dE2238B8D33759fB0675", "0x1477e12f9399B425c152F2bc247ED5DF1813383a", "0xdbF90119AC951b93DC547D9309782F3ffd65B0Ee", "0x772080AF1e3652b4e8159c892519f344699aFd4a", "0xC9Cd046f0E888bEDdEC5e62f6F3C828073747d91", "0x35036D6CFE2E2AC3A8f1F34aF59F3f55688508f2", "0xE59d70c37b2c8a8658905424fd5ded55589C1c8B", "0x33436e3cD600243e7788A5b74eEB5A33A597a47D", "0xB3Fa5fa1f8ac98Ffa2AA42fB8cFae52abfeB1b3e", "0xDb06ca5CEe06D87c4F51D6673E5Bb54914610799", "0xf4dfCD61C36FC3aC374E52206C43253e14C2fFe2", "0x02eEe01722e2Af5D50853A06764bF9bb01b3ae8F", "0x9c94F51EB62F8fc31Da66190fc1D8695CFD4932b", "0xdE001F4F21BBaB01A750BdcE9b0992B1ccFaCBC1", "0x8432f5F4EA2957E7A159720aE0f987e0E07dD73A", "0x0eBEAf28Aba6461735Bb5e0c71fB0095431b9cE9", "0x44bed8ECc2Eb08d16796987185AE9f023335B192", "0x867152803F4E604636c931ac12ffA6a36CcD7160", "0x5944E37E1112e6643cE9A5734382A963f6A75CeE", "0xc3Fd2bcB524af31963b3E3bB670F28bA14718244", "0x58117505D3E4C10278fF80F93A0A48e47B86CCA7", "0x59A95882D01f37B02aA8FCc7dc0b67283bB13055", "0x638d03A6Fe0D931101D13446821082365b782758", "0x517649273390c2368CE133D13B05bE5b75bff123", "0x24E8eFF10C78baB3694C36bC05EFFc2A4520d5f3", "0xd0a155714Aaebe681dE21ce090757247AeB99188", "0x17bBD40f985ee0D34535FE3506206Bb5bb624792", "0xd25973D59e445Ba224Eb2B04e405Ba2D95841B54", "0xFFE628e582ef032cE40b2cB7829Dc9e2d173D55F", "0x5bdB3170E6F59746eD081a637B21906C29Ecda15", "0xc16AB2E7515c537B6E71bAac739657cC565dD3Cb", "0xFe7Da83affB7b6C4267b2b661F4389785d6E9962", "0xc61241a3314cD2C58ae805670813400840509dfF", "0x9A1645f0663d88515f2119f305BB340c7C708D12"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "forge_running", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "uint256"}], name: "lockbins", outputs: [{name: "start", type: "uint256"}, {name: "finish", type: "uint256"}, {name: "duration", type: "uint256"}, {name: "amount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "investor", type: "address"}], name: "getLockedToken", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "amount", type: "uint256"}], name: "canMint", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "user", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "releaseStart", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "wallets", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalFountainSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "address"}], name: "warrants", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "forceStopInvest", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "investor", type: "address"}], name: "getInvestedToken", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token_foundation_cap", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token_foundation_created", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "user", type: "address"}], name: "availableWallet", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "owner", type: "address"}, {name: "delegator", type: "address"}], name: "allowance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token_created", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token_cap", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "releaseDuration", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [], name: "InvestStart", type: "event"}, {anonymous: false, inputs: [], name: "InvestStop", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "release_start", type: "uint256"}, {indexed: false, name: "release_duration", type: "uint256"}], name: "NewInvest", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Burn", type: "event"}, {anonymous: false, inputs: [], name: "ContractPause", type: "event"}, {anonymous: false, inputs: [], name: "ContractResume", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "from", type: "uint256"}, {indexed: false, name: "to", type: "uint256"}], name: "ContractPauseSchedule", type: "event"}, {anonymous: false, inputs: [], name: "ForgeStart", type: "event"}, {anonymous: false, inputs: [], name: "ForgeStop", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "oldone", type: "address"}, {indexed: true, name: "newone", type: "address"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "oldFoundationOwner", type: "address"}, {indexed: true, name: "newFoundationOwner", type: "address"}], name: "FoundationOwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["InvestStart()", "InvestStop()", "NewInvest(uint256,uint256)", "Mint(address,uint256)", "Burn(address,uint256)", "ContractPause()", "ContractResume()", "ContractPauseSchedule(uint256,uint256)", "ForgeStart()", "ForgeStop()", "OwnershipTransferred(address,address)", "FoundationOwnershipTransferred(address,address)", "Approval(address,address,uint256)", "Transfer(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x14245ee125d3810a2a28f6b656b676516364a51e95a688ddf08af4194fc3db12", "0xcd16c719d9bfc829719d0e728b877ea1f29c77fd759480f077f4f6bc2a26e025", "0x4a1179f4d7ff6354606313c42f6054383e9549f9db56ac4b66b424bc940f79ed", "0x0f6798a560793a54c3bcfe86a93cde1e73087d944c0ea20544137d4121396885", "0xcc16f5dbb4873280815c1ee09dbd06736cffcc184412cf7a71a0fdb75d397ca5", "0xb7e43176b89d4cefed0cca5fc9b2f8e752d3d192b83123ef306a0a55dcd18a6b", "0xa968378e910134ded7db0a5144e2c6a2d157f1685baa51f39de6c13a5e8ffa89", "0xac04925986d687f5e264774dac7e393e920d61c9b99e92497853eb519484e4dd", "0xa039c7af624b7305fc7002f670d116cf0c8b61a558a10ff96be611c5c2357517", "0x5f6f015054fd8937bdf17b86b7684be4ae883d459fb0bec23bc11f75a13b5944", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0", "0xfc952dd6557f6861208ba39acbc0cfe5b4f12e76e6b467ed4200003f2b0cd8b0", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6584504 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6919498 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "FountainToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "forge_running", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "forge_running()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "lockbins", outputs: [{name: "start", type: "uint256"}, {name: "finish", type: "uint256"}, {name: "duration", type: "uint256"}, {name: "amount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lockbins(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "investor", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getLockedToken", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLockedToken(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "amount", value: random.range( maxRandom )}], name: "canMint", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "canMint(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "user", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "releaseStart", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "releaseStart()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "wallets", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "wallets(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalFountainSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalFountainSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "warrants", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "warrants(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "forceStopInvest", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "forceStopInvest()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "investor", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getInvestedToken", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getInvestedToken(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token_foundation_cap", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token_foundation_cap()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token_foundation_created", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token_foundation_created()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "user", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "availableWallet", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "availableWallet(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "delegator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token_created", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token_created()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token_cap", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token_cap()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "releaseDuration", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "releaseDuration()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "FountainToken", function( accounts ) {

	it( "TEST: FountainToken(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6584504", blockHash: "0x202f4dd90e87cb03d88deac0a18c4ba9839a7d9cc2a912525a23e45af96f0def", timeStamp: "1540521547", hash: "0x4b1233007e0d3e7bf3d1e5470eb29bdb86eec05004c6a2da3b83238f4e720d8e", nonce: "0", transactionIndex: "29", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: 0, value: "0", gas: "3330139", gasPrice: "41000000000", input: "0x1636c3cd", contractAddress: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", cumulativeGasUsed: "4177714", txreceipt_status: "1", gasUsed: "3330139", confirmations: "1152193", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "FountainToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = FountainToken.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540521547 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = FountainToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[0,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1"}, {name: "amount", type: "uint256", value: "0"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[0,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[0,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1"}, {name: "value", type: "uint256", value: "0"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[0,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setInvest( \"1568592000\", \"126144000\" )", async function( ) {
		const txOriginal = {blockNumber: "6586551", blockHash: "0xdb81d5e711c2baefae2fedeff7c31c737b7027ea4b529fce47c7a5fead709e89", timeStamp: "1540550677", hash: "0x19ca77219b296cae85aba88db6e1230778aff65565917daa055133cc3f5e81a0", nonce: "1", transactionIndex: "90", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "104602", gasPrice: "9000000000", input: "0x42bb66c4000000000000000000000000000000000000000000000000000000005d7ed080000000000000000000000000000000000000000000000000000000000784ce00", contractAddress: "", cumulativeGasUsed: "4513029", txreceipt_status: "1", gasUsed: "54735", confirmations: "1150146", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "release_start", value: "1568592000"}, {type: "uint256", name: "release_duration", value: "126144000"}], name: "setInvest", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setInvest(uint256,uint256)" ]( "1568592000", "126144000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540550677 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "release_start", type: "uint256"}, {indexed: false, name: "release_duration", type: "uint256"}], name: "NewInvest", type: "event"} ;
		console.error( "eventCallOriginal[1,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewInvest", events: [{name: "release_start", type: "uint256", value: "1568592000"}, {name: "release_duration", type: "uint256", value: "126144000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[1,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setInvest( \"1571184000\", \"126144000\" )", async function( ) {
		const txOriginal = {blockNumber: "6586573", blockHash: "0xf4db4585df4f9ed21e1aca52f021ed5ea2dd0808a32e6882ebea1c1612821ae3", timeStamp: "1540550987", hash: "0x014de952d2a0518411d7d9a5885dc7f64bd8ff91850fcc71acf8fcd1d46b3fb2", nonce: "2", transactionIndex: "58", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "59602", gasPrice: "9000000000", input: "0x42bb66c4000000000000000000000000000000000000000000000000000000005da65d80000000000000000000000000000000000000000000000000000000000784ce00", contractAddress: "", cumulativeGasUsed: "2319930", txreceipt_status: "1", gasUsed: "39735", confirmations: "1150124", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "release_start", value: "1571184000"}, {type: "uint256", name: "release_duration", value: "126144000"}], name: "setInvest", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setInvest(uint256,uint256)" ]( "1571184000", "126144000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540550987 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "release_start", type: "uint256"}, {indexed: false, name: "release_duration", type: "uint256"}], name: "NewInvest", type: "event"} ;
		console.error( "eventCallOriginal[2,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewInvest", events: [{name: "release_start", type: "uint256", value: "1571184000"}, {name: "release_duration", type: "uint256", value: "126144000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[2,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[4], \"1200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6586619", blockHash: "0xfcdf9efa80de9a6fd5eb7455a6e61ce8838383b72efd41402940e42cd84b43ef", timeStamp: "1540551624", hash: "0xacb9fa0ec2ddd9bb08a5b9777dc6048bdd5fe35edf02624091e90c023237cdb3", nonce: "3", transactionIndex: "142", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "258619", gasPrice: "9000000000", input: "0xb9b8c246000000000000000000000000b4698bb1133fbfb0e2a092a910c78c9f19c8fb8d000000000000000000000000000000000000000003e09de2596099e2b0000000", contractAddress: "", cumulativeGasUsed: "5970734", txreceipt_status: "1", gasUsed: "172413", confirmations: "1150078", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[4]}, {type: "uint256", name: "amount", value: "1200000000000000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[4], "1200000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540551624 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0xb4698bb1133fbfb0e2a092a910c78c9f19c8fb8d"}, {name: "amount", type: "uint256", value: "1200000000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb4698bb1133fbfb0e2a092a910c78c9f19c8fb8d"}, {name: "value", type: "uint256", value: "1200000000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[3,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setInvest( \"1571184000\", \"63072000\" )", async function( ) {
		const txOriginal = {blockNumber: "6586641", blockHash: "0x55047b24868a26be6797092de465a27d17213b527c6a91998077d2a42641d643", timeStamp: "1540551909", hash: "0xdf6b7fcf6087337ccbf2d9ddebcae2aafd16bbff55e401a9428d0178ee3af388", nonce: "4", transactionIndex: "69", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "59602", gasPrice: "9000000000", input: "0x42bb66c4000000000000000000000000000000000000000000000000000000005da65d800000000000000000000000000000000000000000000000000000000003c26700", contractAddress: "", cumulativeGasUsed: "4662172", txreceipt_status: "1", gasUsed: "39735", confirmations: "1150056", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "release_start", value: "1571184000"}, {type: "uint256", name: "release_duration", value: "63072000"}], name: "setInvest", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setInvest(uint256,uint256)" ]( "1571184000", "63072000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540551909 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "release_start", type: "uint256"}, {indexed: false, name: "release_duration", type: "uint256"}], name: "NewInvest", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewInvest", events: [{name: "release_start", type: "uint256", value: "1571184000"}, {name: "release_duration", type: "uint256", value: "63072000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[5], \"5000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6586652", blockHash: "0x0120dd3c48826ad0d899a448888da0f21f02fed4f12c6e944ff256aba5d8dab0", timeStamp: "1540552118", hash: "0xd2b2449e0324dddb8a1b30397fb31df4c5e0af19e6ea54d16d1c804ce76eb2ac", nonce: "5", transactionIndex: "68", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "236119", gasPrice: "9000000000", input: "0xb9b8c246000000000000000000000000148a6c3c4f53594bd7d23494fcaab2460561f2660000000000000000000000000000000000000000019d971e4fe8401e74000000", contractAddress: "", cumulativeGasUsed: "3410654", txreceipt_status: "1", gasUsed: "157413", confirmations: "1150045", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[5]}, {type: "uint256", name: "amount", value: "500000000000000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[5], "500000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540552118 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[5,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0x148a6c3c4f53594bd7d23494fcaab2460561f266"}, {name: "amount", type: "uint256", value: "500000000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[5,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x148a6c3c4f53594bd7d23494fcaab2460561f266"}, {name: "value", type: "uint256", value: "500000000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[5,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setInvest( \"1555372800\", \"31536000\" )", async function( ) {
		const txOriginal = {blockNumber: "6586658", blockHash: "0x4d4d5d72f33896eaa58b7816da80da0409f62dd262d11f4ca834fe9176441fed", timeStamp: "1540552234", hash: "0xa6a95c442348fb20721e8c995f52ea0eccdbd8626a725e427a969ba9802fac89", nonce: "6", transactionIndex: "180", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "59602", gasPrice: "9000000000", input: "0x42bb66c4000000000000000000000000000000000000000000000000000000005cb51b000000000000000000000000000000000000000000000000000000000001e13380", contractAddress: "", cumulativeGasUsed: "6961920", txreceipt_status: "1", gasUsed: "39735", confirmations: "1150039", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "release_start", value: "1555372800"}, {type: "uint256", name: "release_duration", value: "31536000"}], name: "setInvest", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setInvest(uint256,uint256)" ]( "1555372800", "31536000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540552234 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "release_start", type: "uint256"}, {indexed: false, name: "release_duration", type: "uint256"}], name: "NewInvest", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewInvest", events: [{name: "release_start", type: "uint256", value: "1555372800"}, {name: "release_duration", type: "uint256", value: "31536000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[6], \"1250000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6586691", blockHash: "0x32f9e0fa95ed58215b948d2948731f0e3a1503d58edc13f36be9ca0c35e8944f", timeStamp: "1540552838", hash: "0x195beb8576f6e133a97d7065d1335ddef3fafe1fd8551f8ef2c73c1c0015a523", nonce: "7", transactionIndex: "124", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "236119", gasPrice: "9000000000", input: "0xb9b8c246000000000000000000000000be643e42b7fe7e5ce2ab1d51bf9896305e027e1d0000000000000000000000000000000000000000000a56fa5b99019a5c800000", contractAddress: "", cumulativeGasUsed: "6247405", txreceipt_status: "1", gasUsed: "157413", confirmations: "1150006", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[6]}, {type: "uint256", name: "amount", value: "12500000000000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[6], "12500000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540552838 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[7,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0xbe643e42b7fe7e5ce2ab1d51bf9896305e027e1d"}, {name: "amount", type: "uint256", value: "12500000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[7,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xbe643e42b7fe7e5ce2ab1d51bf9896305e027e1d"}, {name: "value", type: "uint256", value: "12500000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[7,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[7], \"8333333330000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6586700", blockHash: "0xf410d974ca51ab341f091e51280f36ee4e3f2906ce2dc706cd75c1c7d021c97a", timeStamp: "1540553001", hash: "0x50337d3f7f11805e6a28532e45048fdc64e44d71931205e7a63ad3541145852b", nonce: "8", transactionIndex: "133", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "236119", gasPrice: "9000000000", input: "0xb9b8c246000000000000000000000000939db03bba71dbb292c4400258bbd28cf34a2a1700000000000000000000000000000000000000000006e4a6e7af7ec0c3150000", contractAddress: "", cumulativeGasUsed: "5594748", txreceipt_status: "1", gasUsed: "157413", confirmations: "1149997", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[7]}, {type: "uint256", name: "amount", value: "8333333330000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[7], "8333333330000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540553001 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0x939db03bba71dbb292c4400258bbd28cf34a2a17"}, {name: "amount", type: "uint256", value: "8333333330000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x939db03bba71dbb292c4400258bbd28cf34a2a17"}, {name: "value", type: "uint256", value: "8333333330000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[8,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[8], \"1250000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6598342", blockHash: "0x14288409984d437feb3720129542bc016f2acabc6a02893a91e2e712f9d50b88", timeStamp: "1540717710", hash: "0x08608ba91b26c10269ef4d27a73fe7a1e096950ac87450d972672acc5e88c218", nonce: "9", transactionIndex: "310", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157413", gasPrice: "41000000000", input: "0xb9b8c246000000000000000000000000c84901bfd3be8a6ceacf7180ce3ba0968a90b9b00000000000000000000000000000000000000000000a56fa5b99019a5c800000", contractAddress: "", cumulativeGasUsed: "6825577", txreceipt_status: "1", gasUsed: "157413", confirmations: "1138355", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[8]}, {type: "uint256", name: "amount", value: "12500000000000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[8], "12500000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540717710 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0xc84901bfd3be8a6ceacf7180ce3ba0968a90b9b0"}, {name: "amount", type: "uint256", value: "12500000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc84901bfd3be8a6ceacf7180ce3ba0968a90b9b0"}, {name: "value", type: "uint256", value: "12500000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[9,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[9], \"8333333300000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6598357", blockHash: "0xbacc6ed52820c47f32cf9850d454c4238d2ac08a85faab392dfebffdebe060fd", timeStamp: "1540717871", hash: "0xdee5719d5460244c6434ed4d636f01fe62c57c6a77d9c93e198514d8ecd37965", nonce: "10", transactionIndex: "134", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157349", gasPrice: "41000000000", input: "0xb9b8c2460000000000000000000000005ecded59d436af5a4ed2a89dd23e13ccf868a5e200000000000000000000000000000000000000000000b07717207dca8b950000", contractAddress: "", cumulativeGasUsed: "4252708", txreceipt_status: "1", gasUsed: "157349", confirmations: "1138340", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[9]}, {type: "uint256", name: "amount", value: "833333330000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[9], "833333330000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540717871 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0x5ecded59d436af5a4ed2a89dd23e13ccf868a5e2"}, {name: "amount", type: "uint256", value: "833333330000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x5ecded59d436af5a4ed2a89dd23e13ccf868a5e2"}, {name: "value", type: "uint256", value: "833333330000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[10,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[10], \"125000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6598367", blockHash: "0xf378c86c096bd5b8a0c952b795cbb8f5df16c20321e6b979ea771da4aa218c30", timeStamp: "1540718011", hash: "0x969722313c720d6827c619ea7b0207e1f5efd91c7dbc00362aad0aa526d33b00", nonce: "11", transactionIndex: "91", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157413", gasPrice: "41000000000", input: "0xb9b8c2460000000000000000000000005d37c7e396da9f2e26c2f8e249ade617756ab3ba0000000000000000000000000000000000000000000a56fa5b99019a5c800000", contractAddress: "", cumulativeGasUsed: "2233563", txreceipt_status: "1", gasUsed: "157413", confirmations: "1138330", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[10]}, {type: "uint256", name: "amount", value: "12500000000000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[10], "12500000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540718011 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[11,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0x5d37c7e396da9f2e26c2f8e249ade617756ab3ba"}, {name: "amount", type: "uint256", value: "12500000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[11,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x5d37c7e396da9f2e26c2f8e249ade617756ab3ba"}, {name: "value", type: "uint256", value: "12500000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[11,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[11], \"833333333333333000000... )", async function( ) {
		const txOriginal = {blockNumber: "6622055", blockHash: "0x26ec2675f9bff26cde63734594093f9bb44c27ea2919fe5c61f175baeb1c5052", timeStamp: "1541053211", hash: "0xe51fd4cdd56ca424a560df43f923d52cd424a73341c7db43067aa9dce8fa0b10", nonce: "12", transactionIndex: "170", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157477", gasPrice: "41000000000", input: "0xb9b8c2460000000000000000000000006c093b68104d56323444dd9c6b77476fb241d89300000000000000000000000000000000000000000006e4a6e7bb566621a6b400", contractAddress: "", cumulativeGasUsed: "3862732", txreceipt_status: "1", gasUsed: "157477", confirmations: "1114642", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[11]}, {type: "uint256", name: "amount", value: "8333333333333330000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[11], "8333333333333330000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541053211 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0x6c093b68104d56323444dd9c6b77476fb241d893"}, {name: "amount", type: "uint256", value: "8333333333333330000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x6c093b68104d56323444dd9c6b77476fb241d893"}, {name: "value", type: "uint256", value: "8333333333333330000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[12,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[12], \"416666666666667000000... )", async function( ) {
		const txOriginal = {blockNumber: "6622080", blockHash: "0x636590ae21d4c046d17f75649b2206720bac5497f49ce5ec360b8069115af1a6", timeStamp: "1541053522", hash: "0x11133063934f554bfe8fbbeb76b0681c9cd109bfdf78749f63cf6c5de8e0e0d1", nonce: "13", transactionIndex: "15", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157477", gasPrice: "41000000000", input: "0xb9b8c246000000000000000000000000c881af3864276104b77bbf225ceaa1901ceee0cc00000000000000000000000000000000000000000003725373ddab343ad94c00", contractAddress: "", cumulativeGasUsed: "535828", txreceipt_status: "1", gasUsed: "157477", confirmations: "1114617", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[12]}, {type: "uint256", name: "amount", value: "4166666666666670000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[12], "4166666666666670000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541053522 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[13,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0xc881af3864276104b77bbf225ceaa1901ceee0cc"}, {name: "amount", type: "uint256", value: "4166666666666670000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[13,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc881af3864276104b77bbf225ceaa1901ceee0cc"}, {name: "value", type: "uint256", value: "4166666666666670000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[13,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[13], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6627653", blockHash: "0x42710943b3cb0c8cd32aa6525099e25406f7b4d90b9016117aac17474b295d81", timeStamp: "1541133155", hash: "0xfca0e10d635b7980d0050abe568508cd4e10615d865aaa3505a8a2dbdabcfcf3", nonce: "14", transactionIndex: "60", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157349", gasPrice: "41000000000", input: "0xb9b8c246000000000000000000000000bfaf9ef45c07a9cb49c52a60a53740f587762a1b000000000000000000000000000000000000000000084595161401484a000000", contractAddress: "", cumulativeGasUsed: "2361759", txreceipt_status: "1", gasUsed: "157349", confirmations: "1109044", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[13]}, {type: "uint256", name: "amount", value: "10000000000000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[13], "10000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541133155 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[14,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0xbfaf9ef45c07a9cb49c52a60a53740f587762a1b"}, {name: "amount", type: "uint256", value: "10000000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[14,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xbfaf9ef45c07a9cb49c52a60a53740f587762a1b"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[14,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[14], \"125000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6627832", blockHash: "0x7f227795f92df52e970108f3e2021e1037a55aeb7aa67281fb1c556be78e750c", timeStamp: "1541135843", hash: "0xdfc4c26ac4f0feb4b4a0eaf0bcff9660fc310c204c3f1d098ef96c8153bc6278", nonce: "15", transactionIndex: "4", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157413", gasPrice: "41000000000", input: "0xb9b8c24600000000000000000000000008c1ff4e253f7436a1a3c6cc4d19cb06b51a09b40000000000000000000000000000000000000000000a56fa5b99019a5c800000", contractAddress: "", cumulativeGasUsed: "289648", txreceipt_status: "1", gasUsed: "157413", confirmations: "1108865", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[14]}, {type: "uint256", name: "amount", value: "12500000000000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[14], "12500000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541135843 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[15,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0x08c1ff4e253f7436a1a3c6cc4d19cb06b51a09b4"}, {name: "amount", type: "uint256", value: "12500000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[15,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x08c1ff4e253f7436a1a3c6cc4d19cb06b51a09b4"}, {name: "value", type: "uint256", value: "12500000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[15,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[15], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6627838", blockHash: "0x3521e2e37833e88d462ec6c0f190e5ef3441e7f89aad80e3a60e0fef6c30d897", timeStamp: "1541135911", hash: "0xf841ef54f0192eb5cc9166a744e6ff46b189e90b40ee94b337ea3c24ea649d80", nonce: "16", transactionIndex: "11", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157285", gasPrice: "41000000000", input: "0xb9b8c2460000000000000000000000005acb6d754037463319a8407feeb3c38c6db1fee10000000000000000000000000000000000000000000422ca8b0a00a425000000", contractAddress: "", cumulativeGasUsed: "652267", txreceipt_status: "1", gasUsed: "157285", confirmations: "1108859", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[15]}, {type: "uint256", name: "amount", value: "5000000000000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[15], "5000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541135911 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0x5acb6d754037463319a8407feeb3c38c6db1fee1"}, {name: "amount", type: "uint256", value: "5000000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x5acb6d754037463319a8407feeb3c38c6db1fee1"}, {name: "value", type: "uint256", value: "5000000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[16,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[16], \"416666666000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6627844", blockHash: "0x174203da500cf7ae6781a644d831a594de7cfcd7cf6460fef4df86dde362b941", timeStamp: "1541136000", hash: "0xfe095de5b7adc15650e3e86d23184062191cfed871bf897899d1f05d6f05e12f", nonce: "17", transactionIndex: "10", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157413", gasPrice: "41000000000", input: "0xb9b8c2460000000000000000000000003293072676bbde0c688c5d3d21b765e127ee1cc700000000000000000000000000000000000000000003725373c5fbe729aa0000", contractAddress: "", cumulativeGasUsed: "367413", txreceipt_status: "1", gasUsed: "157413", confirmations: "1108853", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[16]}, {type: "uint256", name: "amount", value: "4166666660000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[16], "4166666660000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541136000 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[17,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0x3293072676bbde0c688c5d3d21b765e127ee1cc7"}, {name: "amount", type: "uint256", value: "4166666660000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[17,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x3293072676bbde0c688c5d3d21b765e127ee1cc7"}, {name: "value", type: "uint256", value: "4166666660000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[17,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[17], \"125000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6642898", blockHash: "0x003112c65dae770eeac750e8b981d66f05ac552c8dbd1af17c44ca9a8c70b137", timeStamp: "1541348252", hash: "0x22f386739fa2b63cc1b3d5af4fe8313db8e98d107ec85f2849b13bd64e372836", nonce: "18", transactionIndex: "12", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157413", gasPrice: "41000000000", input: "0xb9b8c24600000000000000000000000005d4d45707af4171f8668ac75ebc6cc95ba84abb0000000000000000000000000000000000000000000a56fa5b99019a5c800000", contractAddress: "", cumulativeGasUsed: "499546", txreceipt_status: "1", gasUsed: "157413", confirmations: "1093799", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[17]}, {type: "uint256", name: "amount", value: "12500000000000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[17], "12500000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541348252 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[18,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0x05d4d45707af4171f8668ac75ebc6cc95ba84abb"}, {name: "amount", type: "uint256", value: "12500000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[18,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x05d4d45707af4171f8668ac75ebc6cc95ba84abb"}, {name: "value", type: "uint256", value: "12500000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[18,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[18], \"416666666000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6642908", blockHash: "0x4e4dd42645c6868dec7b21ec4982f17f618f0736e50f6ea887b67223ddcf7f70", timeStamp: "1541348435", hash: "0x18550343522adc12ea8d018e69300d45764f519d492d427032cb84ddc395f1b2", nonce: "19", transactionIndex: "17", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157413", gasPrice: "41000000000", input: "0xb9b8c246000000000000000000000000d246ef8c4aa0cd01c3f939279c61c0d0b00e1f2a00000000000000000000000000000000000000000003725373c5fbe729aa0000", contractAddress: "", cumulativeGasUsed: "687160", txreceipt_status: "1", gasUsed: "157413", confirmations: "1093789", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[18]}, {type: "uint256", name: "amount", value: "4166666660000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[18], "4166666660000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541348435 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[19,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0xd246ef8c4aa0cd01c3f939279c61c0d0b00e1f2a"}, {name: "amount", type: "uint256", value: "4166666660000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[19,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd246ef8c4aa0cd01c3f939279c61c0d0b00e1f2a"}, {name: "value", type: "uint256", value: "4166666660000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[19,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[19], \"416666666000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6642921", blockHash: "0xd1ef8140322c6f985b953afdd81dd70478ba6049d5f366db10d250320c67249d", timeStamp: "1541348597", hash: "0x045a4634ea86991d755a099ea4342ddcd193cbe1aec1f763c3260cf9b1170948", nonce: "20", transactionIndex: "0", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157413", gasPrice: "41000000000", input: "0xb9b8c246000000000000000000000000f2ec6f70dfdc02aa2b72e4b90f593fe5a781705700000000000000000000000000000000000000000003725373c5fbe729aa0000", contractAddress: "", cumulativeGasUsed: "157413", txreceipt_status: "1", gasUsed: "157413", confirmations: "1093776", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[19]}, {type: "uint256", name: "amount", value: "4166666660000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[19], "4166666660000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541348597 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0xf2ec6f70dfdc02aa2b72e4b90f593fe5a7817057"}, {name: "amount", type: "uint256", value: "4166666660000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf2ec6f70dfdc02aa2b72e4b90f593fe5a7817057"}, {name: "value", type: "uint256", value: "4166666660000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[20,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[20], \"666666666000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6647388", blockHash: "0x7b78568ae1142e32346e139af4a0cacf4ca22aeddde103a64326bbaf1919bd19", timeStamp: "1541412498", hash: "0x9a274f050808da906f8bff6c2b9aaad6b65af4e3d37a3de38a67056bf449659c", nonce: "21", transactionIndex: "91", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157413", gasPrice: "41000000000", input: "0xb9b8c24600000000000000000000000092d74811f935d07dfc851fc5976b3a22b628e4ef0000000000000000000000000000000000000000000583b8b94afc393c2a0000", contractAddress: "", cumulativeGasUsed: "6564965", txreceipt_status: "1", gasUsed: "157413", confirmations: "1089309", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[20]}, {type: "uint256", name: "amount", value: "6666666660000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[20], "6666666660000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541412498 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[21,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0x92d74811f935d07dfc851fc5976b3a22b628e4ef"}, {name: "amount", type: "uint256", value: "6666666660000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[21,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x92d74811f935d07dfc851fc5976b3a22b628e4ef"}, {name: "value", type: "uint256", value: "6666666660000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[21,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[21], \"583333333000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6647392", blockHash: "0x4cf14f0b08db2090ebe99e00bb1adae0b1b74cace2dbdb9b7178cee838703573", timeStamp: "1541412571", hash: "0xd3350bff770a3eb65fc0df77fac97db89ff9eed82cc4272ea1cbd351523aa30e", nonce: "22", transactionIndex: "14", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "157413", gasPrice: "41000000000", input: "0xb9b8c246000000000000000000000000d4554679bc0cef5e6ec7de2238b8d33759fb067500000000000000000000000000000000000000000004d341a22a7e6eb0950000", contractAddress: "", cumulativeGasUsed: "565338", txreceipt_status: "1", gasUsed: "157413", confirmations: "1089305", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[21]}, {type: "uint256", name: "amount", value: "5833333330000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[21], "5833333330000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541412571 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[22,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0xd4554679bc0cef5e6ec7de2238b8d33759fb0675"}, {name: "amount", type: "uint256", value: "5833333330000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[22,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd4554679bc0cef5e6ec7de2238b8d33759fb0675"}, {name: "value", type: "uint256", value: "5833333330000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[22,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: setFountainFoundationOwner( addressList[22] )", async function( ) {
		const txOriginal = {blockNumber: "6647458", blockHash: "0x3ec746e3a2e2e3689d7bb4794fbe5998c544e3c5b8c98e84c7b1f9bca4c80c52", timeStamp: "1541413249", hash: "0x61f19d99c3ee5016b74848a219c485f44adbf73b3e295efad5c0dcf27d9d72da", nonce: "24", transactionIndex: "18", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "43979", gasPrice: "41000000000", input: "0x73a72b180000000000000000000000001477e12f9399b425c152f2bc247ed5df1813383a", contractAddress: "", cumulativeGasUsed: "4445057", txreceipt_status: "1", gasUsed: "43979", confirmations: "1089239", isError: "0"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newFoundationOwner", value: addressList[22]}], name: "setFountainFoundationOwner", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFountainFoundationOwner(address)" ]( addressList[22], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541413249 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "oldFoundationOwner", type: "address"}, {indexed: true, name: "newFoundationOwner", type: "address"}], name: "FoundationOwnershipTransferred", type: "event"} ;
		console.error( "eventCallOriginal[23,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FoundationOwnershipTransferred", events: [{name: "oldFoundationOwner", type: "address", value: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1"}, {name: "newFoundationOwner", type: "address", value: "0x1477e12f9399b425c152f2bc247ed5df1813383a"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[23,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1"}, {name: "to", type: "address", value: "0x1477e12f9399b425c152f2bc247ed5df1813383a"}, {name: "value", type: "uint256", value: "0"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[23,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[23], \"300000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6647497", blockHash: "0x4c5c035585859d885dd59262a8041958d758e09b8d2ac97acf5258834a323b49", timeStamp: "1541413856", hash: "0x1f2ead29d2b37d03e8c6d7fe1257778140951e4ab96e5e542df70cbe33bd25f4", nonce: "0", transactionIndex: "11", from: "0x1477e12f9399b425c152f2bc247ed5df1813383a", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "77015", gasPrice: "41000000000", input: "0x40c10f19000000000000000000000000dbf90119ac951b93dc547d9309782f3ffd65b0ee000000000000000000000000000000000000000000f8277896582678ac000000", contractAddress: "", cumulativeGasUsed: "511444", txreceipt_status: "1", gasUsed: "77015", confirmations: "1089200", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[23]}, {type: "uint256", name: "amount", value: "300000000000000000000000000"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256)" ]( addressList[23], "300000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541413856 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0xdbf90119ac951b93dc547d9309782f3ffd65b0ee"}, {name: "amount", type: "uint256", value: "300000000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xdbf90119ac951b93dc547d9309782f3ffd65b0ee"}, {name: "value", type: "uint256", value: "300000000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[24,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "196842385000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[24], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6647585", blockHash: "0x5282a2e198981ad7fdd963c5e5ed7e91a0e49f2eab71ef3be6b4b9a47f3696fe", timeStamp: "1541415130", hash: "0xd76020d02a3f10ec078d10ab1c43c2ed3d92de3c62293eb912c21089c913c151", nonce: "5", transactionIndex: "50", from: "0xdbf90119ac951b93dc547d9309782f3ffd65b0ee", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "82836", gasPrice: "9000000000", input: "0xa9059cbb000000000000000000000000772080af1e3652b4e8159c892519f344699afd4a00000000000000000000000000000000000000000052b7d2dcc80cd2e4000000", contractAddress: "", cumulativeGasUsed: "7324223", txreceipt_status: "1", gasUsed: "55224", confirmations: "1089112", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[24]}, {type: "uint256", name: "value", value: "100000000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[24], "100000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541415130 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xdbf90119ac951b93dc547d9309782f3ffd65b0ee"}, {name: "to", type: "address", value: "0x772080af1e3652b4e8159c892519f344699afd4a"}, {name: "value", type: "uint256", value: "100000000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[25,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "465114387000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: batchInvests( [addressList[25],addressList[26],address... )", async function( ) {
		const txOriginal = {blockNumber: "6708331", blockHash: "0x92fcf082d29511578ff98b95d526300bb6b16e8954cacefa13d9b809b9197c9d", timeStamp: "1542275395", hash: "0x98a4ed626700245778d02594361e627e69d380ff1640bb20a71e0ad2de8f491b", nonce: "25", transactionIndex: "63", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "2163520", gasPrice: "10000000000", input: "0x6ad95317000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000c9cd046f0e888beddec5e62f6f3c828073747d9100000000000000000000000035036d6cfe2e2ac3a8f1f34af59f3f55688508f2000000000000000000000000e59d70c37b2c8a8658905424fd5ded55589c1c8b00000000000000000000000033436e3cd600243e7788a5b74eeb5a33a597a47d000000000000000000000000b3fa5fa1f8ac98ffa2aa42fb8cfae52abfeb1b3e000000000000000000000000db06ca5cee06d87c4f51d6673e5bb54914610799000000000000000000000000f4dfcd61c36fc3ac374e52206c43253e14c2ffe200000000000000000000000002eee01722e2af5d50853a06764bf9bb01b3ae8f0000000000000000000000009c94f51eb62f8fc31da66190fc1d8695cfd4932b000000000000000000000000de001f4f21bbab01a750bdce9b0992b1ccfacbc10000000000000000000000008432f5f4ea2957e7a159720ae0f987e0e07dd73a000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000215a1794693c777000000000000000000000000000000000000000000000000004c3ba39c5e41110000000000000000000000000000000000000000000000000098774738bc82220000000000000000000000000000000000000000000000000065a4da25d3016c0000000000000000000000000000000000000000000000000032d26d12e980b60000000000000000000000000000000000000000000000000032d26d12e980b60000000000000000000000000000000000000000000000000130ee8e7179044400000000000000000000000000000000000000000000000000fe1c215e8f838e00000000000000000000000000000000000000000000000000cb49b44ba602d8000000000000000000000000000000000000000000000000001969368974c05b0000000000000000000000000000000000000000000000000065a4da25d3016c000000", contractAddress: "", cumulativeGasUsed: "5031992", txreceipt_status: "1", gasUsed: "1442347", confirmations: "1028366", isError: "0"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "investors", value: [addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35]]}, {type: "uint256[]", name: "amounts", value: ["2520000000000000000000000","360000000000000000000000","720000000000000000000000","480000000000000000000000","240000000000000000000000","240000000000000000000000","1440000000000000000000000","1200000000000000000000000","960000000000000000000000","120000000000000000000000","480000000000000000000000"]}], name: "batchInvests", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchInvests(address[],uint256[])" ]( [addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35]], ["2520000000000000000000000","360000000000000000000000","720000000000000000000000","480000000000000000000000","240000000000000000000000","240000000000000000000000","1440000000000000000000000","1200000000000000000000000","960000000000000000000000","120000000000000000000000","480000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542275395 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[26,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0xc9cd046f0e888beddec5e62f6f3c828073747d91"}, {name: "amount", type: "uint256", value: "2520000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0x35036d6cfe2e2ac3a8f1f34af59f3f55688508f2"}, {name: "amount", type: "uint256", value: "360000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0xe59d70c37b2c8a8658905424fd5ded55589c1c8b"}, {name: "amount", type: "uint256", value: "720000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0x33436e3cd600243e7788a5b74eeb5a33a597a47d"}, {name: "amount", type: "uint256", value: "480000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0xb3fa5fa1f8ac98ffa2aa42fb8cfae52abfeb1b3e"}, {name: "amount", type: "uint256", value: "240000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0xdb06ca5cee06d87c4f51d6673e5bb54914610799"}, {name: "amount", type: "uint256", value: "240000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0xf4dfcd61c36fc3ac374e52206c43253e14c2ffe2"}, {name: "amount", type: "uint256", value: "1440000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0x02eee01722e2af5d50853a06764bf9bb01b3ae8f"}, {name: "amount", type: "uint256", value: "1200000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0x9c94f51eb62f8fc31da66190fc1d8695cfd4932b"}, {name: "amount", type: "uint256", value: "960000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0xde001f4f21bbab01a750bdce9b0992b1ccfacbc1"}, {name: "amount", type: "uint256", value: "120000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0x8432f5f4ea2957e7a159720ae0f987e0e07dd73a"}, {name: "amount", type: "uint256", value: "480000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[26,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc9cd046f0e888beddec5e62f6f3c828073747d91"}, {name: "value", type: "uint256", value: "2520000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x35036d6cfe2e2ac3a8f1f34af59f3f55688508f2"}, {name: "value", type: "uint256", value: "360000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe59d70c37b2c8a8658905424fd5ded55589c1c8b"}, {name: "value", type: "uint256", value: "720000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x33436e3cd600243e7788a5b74eeb5a33a597a47d"}, {name: "value", type: "uint256", value: "480000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb3fa5fa1f8ac98ffa2aa42fb8cfae52abfeb1b3e"}, {name: "value", type: "uint256", value: "240000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xdb06ca5cee06d87c4f51d6673e5bb54914610799"}, {name: "value", type: "uint256", value: "240000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf4dfcd61c36fc3ac374e52206c43253e14c2ffe2"}, {name: "value", type: "uint256", value: "1440000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x02eee01722e2af5d50853a06764bf9bb01b3ae8f"}, {name: "value", type: "uint256", value: "1200000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x9c94f51eb62f8fc31da66190fc1d8695cfd4932b"}, {name: "value", type: "uint256", value: "960000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xde001f4f21bbab01a750bdce9b0992b1ccfacbc1"}, {name: "value", type: "uint256", value: "120000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x8432f5f4ea2957e7a159720ae0f987e0e07dd73a"}, {name: "value", type: "uint256", value: "480000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[26,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6714888", blockHash: "0xb5be86b1299ee0b5dd20c55376a7c6c1dd4f8192d846c47296231df67228d97f", timeStamp: "1542367211", hash: "0x7fedfdf4b85a16ad8ecdf04434c2782dc3fd11e039e9707a97c2c8dd51252d25", nonce: "373", transactionIndex: "38", from: "0x0ebeaf28aba6461735bb5e0c71fb0095431b9ce9", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "25200", gasPrice: "10000000000", input: "0x", contractAddress: "", cumulativeGasUsed: "1306310", txreceipt_status: "0", gasUsed: "21046", confirmations: "1021809", isError: "1"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542367211 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "9171475957560993515" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[37], \"204000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6780111", blockHash: "0x72f1415e938e614dbb0b3bdb6a94954bb951a18cf1ca1d41b8339e19f9e2c745", timeStamp: "1543291492", hash: "0x15f184cc512476fad5386012aa20134cf85422db091060d5b8d85179b328ed0e", nonce: "0", transactionIndex: "128", from: "0x02eee01722e2af5d50853a06764bf9bb01b3ae8f", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "200000", gasPrice: "4000000000", input: "0xa9059cbb00000000000000000000000044bed8ecc2eb08d16796987185ae9f023335b192000000000000000000000000000000000000000000000451e2df0c2af0c00000", contractAddress: "", cumulativeGasUsed: "7124143", txreceipt_status: "0", gasUsed: "28478", confirmations: "956586", isError: "1"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[37]}, {type: "uint256", name: "value", value: "20400000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[37], "20400000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1543291492 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "7529680000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[37], \"204000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6780150", blockHash: "0xb11b11e8d4e4523a8a421abda761aee5008e86462112c1e8ebbfef96391b5727", timeStamp: "1543291933", hash: "0x0e33c381d289edf798114f26f323d8eb886b752c9d91a6d785702ef523b9ee4e", nonce: "1", transactionIndex: "2", from: "0x02eee01722e2af5d50853a06764bf9bb01b3ae8f", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "31000", gasPrice: "41000000000", input: "0xa9059cbb00000000000000000000000044bed8ecc2eb08d16796987185ae9f023335b192000000000000000000000000000000000000000000002b32dcb679ad67800000", contractAddress: "", cumulativeGasUsed: "242898", txreceipt_status: "0", gasUsed: "28478", confirmations: "956547", isError: "1"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[37]}, {type: "uint256", name: "value", value: "204000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[37], "204000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1543291933 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "7529680000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[38], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6884612", blockHash: "0xd8ce94eedf8f909298a408c34fbd60f43c5921b65412d9b402599d58d86bbb78", timeStamp: "1544784037", hash: "0x8c40ec5d767d4b57690b37c922f5fe8dc3d4b606b5c28a3634013e198a287d5f", nonce: "6", transactionIndex: "156", from: "0xdbf90119ac951b93dc547d9309782f3ffd65b0ee", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "82740", gasPrice: "5000000000", input: "0xa9059cbb000000000000000000000000867152803f4e604636c931ac12ffa6a36ccd716000000000000000000000000000000000000000000000006c6b935b8bbd400000", contractAddress: "", cumulativeGasUsed: "6461515", txreceipt_status: "1", gasUsed: "55160", confirmations: "852085", isError: "0"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[38]}, {type: "uint256", name: "value", value: "2000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[38], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1544784037 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xdbf90119ac951b93dc547d9309782f3ffd65b0ee"}, {name: "to", type: "address", value: "0x867152803f4e604636c931ac12ffa6a36ccd7160"}, {name: "value", type: "uint256", value: "2000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[30,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "465114387000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[39], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6884894", blockHash: "0x8d55a7a2da188c801b6d98c7fa7a587f25ebb06f97352f623ac18fc549e0b041", timeStamp: "1544788085", hash: "0x3589209855bfdb3b8bee284424d97bdfce488d7eb099628c90b16d67c72c5cc9", nonce: "0", transactionIndex: "113", from: "0x867152803f4e604636c931ac12ffa6a36ccd7160", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "82740", gasPrice: "5000000000", input: "0xa9059cbb0000000000000000000000005944e37e1112e6643ce9a5734382a963f6a75cee0000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "4903846", txreceipt_status: "1", gasUsed: "55160", confirmations: "851803", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[39]}, {type: "uint256", name: "value", value: "100000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[39], "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1544788085 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x867152803f4e604636c931ac12ffa6a36ccd7160"}, {name: "to", type: "address", value: "0x5944e37e1112e6643ce9a5734382a963f6a75cee"}, {name: "value", type: "uint256", value: "100000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[31,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "339181369000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: batchInvests( [addressList[25],addressList[26],address... )", async function( ) {
		const txOriginal = {blockNumber: "6886193", blockHash: "0xe976d7db66d0152576b93c05967d6c522565932dca9fbb2b33dd8675a658bcf5", timeStamp: "1544806742", hash: "0xba9306adbdb74e895df32c39acbc4c717740cb0996785e0f206b27efc1c4fdad", nonce: "26", transactionIndex: "148", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "1418523", gasPrice: "5000000000", input: "0x6ad95317000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000000000000000009000000000000000000000000c9cd046f0e888beddec5e62f6f3c828073747d9100000000000000000000000035036d6cfe2e2ac3a8f1f34af59f3f55688508f2000000000000000000000000e59d70c37b2c8a8658905424fd5ded55589c1c8b000000000000000000000000b3fa5fa1f8ac98ffa2aa42fb8cfae52abfeb1b3e000000000000000000000000db06ca5cee06d87c4f51d6673e5bb54914610799000000000000000000000000f4dfcd61c36fc3ac374e52206c43253e14c2ffe200000000000000000000000002eee01722e2af5d50853a06764bf9bb01b3ae8f000000000000000000000000c3fd2bcb524af31963b3e3bb670f28ba147182440000000000000000000000008432f5f4ea2957e7a159720ae0f987e0e07dd73a000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000b1e07dc231427d000000000000000000000000000000000000000000000000001969368974c05b0000000000000000000000000000000000000000000000000032d26d12e980b6000000000000000000000000000000000000000000000000001969368974c05b000000000000000000000000000000000000000000000000001969368974c05b000000000000000000000000000000000000000000000000004c3ba39c5e4111000000000000000000000000000000000000000000000000007f0e10af47c1c7000000000000000000000000000000000000000000000000003f870857a3e0e38000000000000000000000000000000000000000000000000065a4da25d3016c000000", contractAddress: "", cumulativeGasUsed: "7379189", txreceipt_status: "1", gasUsed: "945682", confirmations: "850504", isError: "0"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "investors", value: [addressList[25],addressList[26],addressList[27],addressList[29],addressList[30],addressList[31],addressList[32],addressList[40],addressList[35]]}, {type: "uint256[]", name: "amounts", value: ["840000000000000000000000","120000000000000000000000","240000000000000000000000","120000000000000000000000","120000000000000000000000","360000000000000000000000","600000000000000000000000","300000000000000000000000","480000000000000000000000"]}], name: "batchInvests", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchInvests(address[],uint256[])" ]( [addressList[25],addressList[26],addressList[27],addressList[29],addressList[30],addressList[31],addressList[32],addressList[40],addressList[35]], ["840000000000000000000000","120000000000000000000000","240000000000000000000000","120000000000000000000000","120000000000000000000000","360000000000000000000000","600000000000000000000000","300000000000000000000000","480000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1544806742 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[32,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0xc9cd046f0e888beddec5e62f6f3c828073747d91"}, {name: "amount", type: "uint256", value: "840000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0x35036d6cfe2e2ac3a8f1f34af59f3f55688508f2"}, {name: "amount", type: "uint256", value: "120000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0xe59d70c37b2c8a8658905424fd5ded55589c1c8b"}, {name: "amount", type: "uint256", value: "240000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0xb3fa5fa1f8ac98ffa2aa42fb8cfae52abfeb1b3e"}, {name: "amount", type: "uint256", value: "120000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0xdb06ca5cee06d87c4f51d6673e5bb54914610799"}, {name: "amount", type: "uint256", value: "120000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0xf4dfcd61c36fc3ac374e52206c43253e14c2ffe2"}, {name: "amount", type: "uint256", value: "360000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0x02eee01722e2af5d50853a06764bf9bb01b3ae8f"}, {name: "amount", type: "uint256", value: "600000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0xc3fd2bcb524af31963b3e3bb670f28ba14718244"}, {name: "amount", type: "uint256", value: "300000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0x8432f5f4ea2957e7a159720ae0f987e0e07dd73a"}, {name: "amount", type: "uint256", value: "480000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[32,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc9cd046f0e888beddec5e62f6f3c828073747d91"}, {name: "value", type: "uint256", value: "840000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x35036d6cfe2e2ac3a8f1f34af59f3f55688508f2"}, {name: "value", type: "uint256", value: "120000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe59d70c37b2c8a8658905424fd5ded55589c1c8b"}, {name: "value", type: "uint256", value: "240000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb3fa5fa1f8ac98ffa2aa42fb8cfae52abfeb1b3e"}, {name: "value", type: "uint256", value: "120000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xdb06ca5cee06d87c4f51d6673e5bb54914610799"}, {name: "value", type: "uint256", value: "120000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xf4dfcd61c36fc3ac374e52206c43253e14c2ffe2"}, {name: "value", type: "uint256", value: "360000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x02eee01722e2af5d50853a06764bf9bb01b3ae8f"}, {name: "value", type: "uint256", value: "600000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc3fd2bcb524af31963b3e3bb670f28ba14718244"}, {name: "value", type: "uint256", value: "300000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x8432f5f4ea2957e7a159720ae0f987e0e07dd73a"}, {name: "value", type: "uint256", value: "480000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[32,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: batchInvests( [addressList[41],addressList[42],address... )", async function( ) {
		const txOriginal = {blockNumber: "6902725", blockHash: "0x66a3688b7422d2132b099ee41bba7650f6a38649ce83786a72a8a15206b928cc", timeStamp: "1545043596", hash: "0xcd96c9fe46d1402fde0e637eb2aeb1f00714e16c58b2ca113498020b0a8b7cd5", nonce: "27", transactionIndex: "25", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "1394005", gasPrice: "5000000000", input: "0x6ad9531700000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000000700000000000000000000000058117505d3e4c10278ff80f93a0a48e47b86cca700000000000000000000000059a95882d01f37b02aa8fcc7dc0b67283bb13055000000000000000000000000638d03a6fe0d931101d13446821082365b782758000000000000000000000000517649273390c2368ce133d13b05be5b75bff12300000000000000000000000024e8eff10c78bab3694c36bc05effc2a4520d5f3000000000000000000000000d0a155714aaebe681de21ce090757247aeb9918800000000000000000000000017bbd40f985ee0d34535fe3506206bb5bb6247920000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000111de95815b59700000000000000000000000000000000000000000000000000563eb16b1a1405c000000000000000000000000000000000000000000000000022ee7fe0747655800000000000000000000000000000000000000000000000001b5345bd1cc75640000000000000000000000000000000000000000000000000563eb16b1a1405c0000000000000000000000000000000000000000000000000c20f02caabf097000000000000000000000000000000000000000000000000005861ff90672d7d80000", contractAddress: "", cumulativeGasUsed: "3034086", txreceipt_status: "1", gasUsed: "929337", confirmations: "833972", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "investors", value: [addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47]]}, {type: "uint256[]", name: "amounts", value: ["5052000000000000000000","25455000000000000000000","10310000000000000000000","8065000000000000000000","25455000000000000000000","57276000000000000000000","26086000000000000000000"]}], name: "batchInvests", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "batchInvests(address[],uint256[])" ]( [addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47]], ["5052000000000000000000","25455000000000000000000","10310000000000000000000","8065000000000000000000","25455000000000000000000","57276000000000000000000","26086000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1545043596 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[33,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0x58117505d3e4c10278ff80f93a0a48e47b86cca7"}, {name: "amount", type: "uint256", value: "5052000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0x59a95882d01f37b02aa8fcc7dc0b67283bb13055"}, {name: "amount", type: "uint256", value: "25455000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0x638d03a6fe0d931101d13446821082365b782758"}, {name: "amount", type: "uint256", value: "10310000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0x517649273390c2368ce133d13b05be5b75bff123"}, {name: "amount", type: "uint256", value: "8065000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0x24e8eff10c78bab3694c36bc05effc2a4520d5f3"}, {name: "amount", type: "uint256", value: "25455000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0xd0a155714aaebe681de21ce090757247aeb99188"}, {name: "amount", type: "uint256", value: "57276000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Mint", events: [{name: "user", type: "address", value: "0x17bbd40f985ee0d34535fe3506206bb5bb624792"}, {name: "amount", type: "uint256", value: "26086000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[33,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x58117505d3e4c10278ff80f93a0a48e47b86cca7"}, {name: "value", type: "uint256", value: "5052000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x59a95882d01f37b02aa8fcc7dc0b67283bb13055"}, {name: "value", type: "uint256", value: "25455000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x638d03a6fe0d931101d13446821082365b782758"}, {name: "value", type: "uint256", value: "10310000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x517649273390c2368ce133d13b05be5b75bff123"}, {name: "value", type: "uint256", value: "8065000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x24e8eff10c78bab3694c36bc05effc2a4520d5f3"}, {name: "value", type: "uint256", value: "25455000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd0a155714aaebe681de21ce090757247aeb99188"}, {name: "value", type: "uint256", value: "57276000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x17bbd40f985ee0d34535fe3506206bb5bb624792"}, {name: "value", type: "uint256", value: "26086000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[33,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[48], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6907612", blockHash: "0xefbeea05f243ac1d56221778e6d4f1fed6eb670f5eb71a96ecf6452da236f2b0", timeStamp: "1545115055", hash: "0x3fd42ff7664ab466c3a631ddececa18f42bbec4ad946a875c86eb0518b2205f9", nonce: "0", transactionIndex: "38", from: "0xd0a155714aaebe681de21ce090757247aeb99188", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "60000", gasPrice: "4971428864", input: "0xa9059cbb000000000000000000000000d25973d59e445ba224eb2b04e405ba2d95841b540000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "1987138", txreceipt_status: "0", gasUsed: "28414", confirmations: "829085", isError: "1"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[48]}, {type: "uint256", name: "value", value: "100000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[48], "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1545115055 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "115000930012635136" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[49], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6908542", blockHash: "0x91d608541e42749dcb4839b1e68ef48f197f9cf1f1a244e2a645b4f566ca2860", timeStamp: "1545129162", hash: "0x57c6712dad1191f789695a12f8bb46816d321cb530c80b223b3e694e46f8ba61", nonce: "0", transactionIndex: "40", from: "0x772080af1e3652b4e8159c892519f344699afd4a", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "55224", gasPrice: "41000000000", input: "0xa9059cbb000000000000000000000000ffe628e582ef032ce40b2cb7829dc9e2d173d55f00000000000000000000000000000000000000000000152d02c7e14af6800000", contractAddress: "", cumulativeGasUsed: "1275760", txreceipt_status: "1", gasUsed: "55224", confirmations: "828155", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[49]}, {type: "uint256", name: "value", value: "100000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[49], "100000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1545129162 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x772080af1e3652b4e8159c892519f344699afd4a"}, {name: "to", type: "address", value: "0xffe628e582ef032ce40b2cb7829dc9e2d173d55f"}, {name: "value", type: "uint256", value: "100000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[35,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "1000000000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[5], \"9990000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6908558", blockHash: "0x5675474ceb10170f3f7de7794264fec9022491183ea742d29ee9e61130058217", timeStamp: "1545129425", hash: "0x4b794ed0f9a30f6503afaff186839108cb48478db337d75114cf88bb893d863a", nonce: "1", transactionIndex: "27", from: "0x772080af1e3652b4e8159c892519f344699afd4a", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "40224", gasPrice: "41000000000", input: "0xa9059cbb000000000000000000000000148a6c3c4f53594bd7d23494fcaab2460561f26600000000000000000000000000000000000000000052a2a5da002b87ed800000", contractAddress: "", cumulativeGasUsed: "879675", txreceipt_status: "1", gasUsed: "25224", confirmations: "828139", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[5]}, {type: "uint256", name: "value", value: "99900000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[5], "99900000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1545129425 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x772080af1e3652b4e8159c892519f344699afd4a"}, {name: "to", type: "address", value: "0x148a6c3c4f53594bd7d23494fcaab2460561f266"}, {name: "value", type: "uint256", value: "99900000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[36,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "1000000000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[50], \"999000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6908604", blockHash: "0x8490eca955d4425b41f2d20c7c2d495cdf1f4cd51aecf178ef689712ef4f676a", timeStamp: "1545130039", hash: "0xf15cead31267694bb288fa0baa3d1862aa8bff112fb6b795d637104dca0dd1bb", nonce: "0", transactionIndex: "58", from: "0x148a6c3c4f53594bd7d23494fcaab2460561f266", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "84618", gasPrice: "5000000000", input: "0xa9059cbb0000000000000000000000005bdb3170e6f59746ed081a637b21906c29ecda1500000000000000000000000000000000000000000052a2a5da002b87ed800000", contractAddress: "", cumulativeGasUsed: "3903025", txreceipt_status: "1", gasUsed: "56412", confirmations: "828093", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[50]}, {type: "uint256", name: "value", value: "99900000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[50], "99900000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1545130039 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x148a6c3c4f53594bd7d23494fcaab2460561f266"}, {name: "to", type: "address", value: "0x5bdb3170e6f59746ed081a637b21906c29ecda15"}, {name: "value", type: "uint256", value: "99900000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[37,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "453572000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[51], \"10000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6912782", blockHash: "0x1e70136b8881541282b6e9b1655b1fc18dfc686a276c42e931eadeb660fe4d61", timeStamp: "1545190887", hash: "0xaf62dcc0c87128d0b77b7c5a3097015d013626d0e3faf923e7741bc851b3f248", nonce: "0", transactionIndex: "119", from: "0xffe628e582ef032ce40b2cb7829dc9e2d173d55f", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "82740", gasPrice: "41000000000", input: "0xa9059cbb000000000000000000000000c16ab2e7515c537b6e71baac739657cc565dd3cb0000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "2787174", txreceipt_status: "1", gasUsed: "55096", confirmations: "823915", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[51]}, {type: "uint256", name: "value", value: "10000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[51], "10000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1545190887 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xffe628e582ef032ce40b2cb7829dc9e2d173d55f"}, {name: "to", type: "address", value: "0xc16ab2e7515c537b6e71baac739657cc565dd3cb"}, {name: "value", type: "uint256", value: "10000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[38,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "3881512714000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[51], \"500000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6913111", blockHash: "0x72ae564cea79cc036e15dc5cc368f938d0aad3974a5f4ccbe2089739c51f33d1", timeStamp: "1545195722", hash: "0xa461b05bb6a31302b6e506f9bbe6cbef3da08d90056b45987eab397afb7147c7", nonce: "1", transactionIndex: "87", from: "0xffe628e582ef032ce40b2cb7829dc9e2d173d55f", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "82740", gasPrice: "5000000000", input: "0xa9059cbb000000000000000000000000c16ab2e7515c537b6e71baac739657cc565dd3cb00000000000000000000000000000000000000000000000006f05b59d3b20000", contractAddress: "", cumulativeGasUsed: "5606567", txreceipt_status: "1", gasUsed: "40096", confirmations: "823586", isError: "0"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[51]}, {type: "uint256", name: "value", value: "500000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[51], "500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1545195722 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xffe628e582ef032ce40b2cb7829dc9e2d173d55f"}, {name: "to", type: "address", value: "0xc16ab2e7515c537b6e71baac739657cc565dd3cb"}, {name: "value", type: "uint256", value: "500000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[39,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "3881512714000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[48], \"5000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6913320", blockHash: "0x69c8e2a041f97b056f088dd7b41bf2e03eed0fd3a221c0a2bfd0aae31888d74e", timeStamp: "1545198979", hash: "0xf7f87af2929a89c6a5c3843a5d6899f4b754142b7c23a0cb8bdffa65d180edd2", nonce: "2", transactionIndex: "18", from: "0xffe628e582ef032ce40b2cb7829dc9e2d173d55f", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "82740", gasPrice: "5000000000", input: "0xa9059cbb000000000000000000000000d25973d59e445ba224eb2b04e405ba2d95841b540000000000000000000000000000000000000000000000004563918244f40000", contractAddress: "", cumulativeGasUsed: "6646399", txreceipt_status: "1", gasUsed: "55096", confirmations: "823377", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[48]}, {type: "uint256", name: "value", value: "5000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[48], "5000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1545198979 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xffe628e582ef032ce40b2cb7829dc9e2d173d55f"}, {name: "to", type: "address", value: "0xd25973d59e445ba224eb2b04e405ba2d95841b54"}, {name: "value", type: "uint256", value: "5000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[40,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "3881512714000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[48], \"5000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6913336", blockHash: "0x56851809bdb712afa7558268491efc677755f06550ae2d3cbfaacc3c5be3bb73", timeStamp: "1545199375", hash: "0xb180d40c9d94197120a0a27d659b7ae773ba5a478fccf1d8c644ab94476d38c1", nonce: "3", transactionIndex: "103", from: "0xffe628e582ef032ce40b2cb7829dc9e2d173d55f", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "82740", gasPrice: "5000000000", input: "0xa9059cbb000000000000000000000000d25973d59e445ba224eb2b04e405ba2d95841b540000000000000000000000000000000000000000000000004563918244f40000", contractAddress: "", cumulativeGasUsed: "4393633", txreceipt_status: "1", gasUsed: "40096", confirmations: "823361", isError: "0"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[48]}, {type: "uint256", name: "value", value: "5000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[48], "5000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1545199375 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xffe628e582ef032ce40b2cb7829dc9e2d173d55f"}, {name: "to", type: "address", value: "0xd25973d59e445ba224eb2b04e405ba2d95841b54"}, {name: "value", type: "uint256", value: "5000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[41,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "3881512714000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[40], \"46000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6913392", blockHash: "0x2a590219fe7fc38b0a792df3ad83555eaadffa8e511f16b87b52d06ea6905517", timeStamp: "1545200210", hash: "0x993b76068b09677b62dc9e90f901b65fc72a587a5c85d4668a4d4a87559bb685", nonce: "4", transactionIndex: "112", from: "0xffe628e582ef032ce40b2cb7829dc9e2d173d55f", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "82740", gasPrice: "5000000000", input: "0xa9059cbb000000000000000000000000c3fd2bcb524af31963b3e3bb670f28ba147182440000000000000000000000000000000000000000000000027e60d44813f80000", contractAddress: "", cumulativeGasUsed: "2945390", txreceipt_status: "1", gasUsed: "40160", confirmations: "823305", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[40]}, {type: "uint256", name: "value", value: "46000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[40], "46000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1545200210 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xffe628e582ef032ce40b2cb7829dc9e2d173d55f"}, {name: "to", type: "address", value: "0xc3fd2bcb524af31963b3e3bb670f28ba14718244"}, {name: "value", type: "uint256", value: "46000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[42,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "3881512714000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[51], \"10000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6913591", blockHash: "0x8390e2629e561d24517fe137f0b15ff595244fb08cd34ac7b8738ef851e47eac", timeStamp: "1545203494", hash: "0xbfdfa1997a20a79f611642fe2fefac4a5fb4477cb7c4c84eaf1c66369a2db722", nonce: "39", transactionIndex: "97", from: "0xd25973d59e445ba224eb2b04e405ba2d95841b54", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "41896", gasPrice: "12500000000", input: "0xa9059cbb000000000000000000000000c16ab2e7515c537b6e71baac739657cc565dd3cb0000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "4453648", txreceipt_status: "1", gasUsed: "25096", confirmations: "823106", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[51]}, {type: "uint256", name: "value", value: "10000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[51], "10000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1545203494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xd25973d59e445ba224eb2b04e405ba2d95841b54"}, {name: "to", type: "address", value: "0xc16ab2e7515c537b6e71baac739657cc565dd3cb"}, {name: "value", type: "uint256", value: "10000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[43,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "3982024235320348341" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[48], \"495000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6913969", blockHash: "0x0694338ba7c9d17c7f01041e38750cc7e8826a75438cb07ba61c52103b60b605", timeStamp: "1545208980", hash: "0x421288161afe92eeeb705b513fb3d676f0b52733ed46ccbeffdb1c5a83f0dc1b", nonce: "5", transactionIndex: "138", from: "0xffe628e582ef032ce40b2cb7829dc9e2d173d55f", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "82740", gasPrice: "5000000000", input: "0xa9059cbb000000000000000000000000d25973d59e445ba224eb2b04e405ba2d95841b5400000000000000000000000000000000000000000000001ad5814560aa5c0000", contractAddress: "", cumulativeGasUsed: "6546978", txreceipt_status: "1", gasUsed: "55160", confirmations: "822728", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[48]}, {type: "uint256", name: "value", value: "495000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[48], "495000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1545208980 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xffe628e582ef032ce40b2cb7829dc9e2d173d55f"}, {name: "to", type: "address", value: "0xd25973d59e445ba224eb2b04e405ba2d95841b54"}, {name: "value", type: "uint256", value: "495000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[44,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "3881512714000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[52], \"495000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6914002", blockHash: "0x198c9f50bbdb712292de96ad400d4164bd03b7a993ed9e9bf4a63a43400c10df", timeStamp: "1545209410", hash: "0x14668cd8de5b83559d925b3a1e3cbb8b93a6e2d2bc560e02317763c73814d905", nonce: "40", transactionIndex: "16", from: "0xd25973d59e445ba224eb2b04e405ba2d95841b54", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "56960", gasPrice: "11042968750", input: "0xa9059cbb000000000000000000000000fe7da83affb7b6c4267b2b661f4389785d6e996200000000000000000000000000000000000000000000001ad5814560aa5c0000", contractAddress: "", cumulativeGasUsed: "712972", txreceipt_status: "1", gasUsed: "40160", confirmations: "822695", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[52]}, {type: "uint256", name: "value", value: "495000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[52], "495000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1545209410 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xd25973d59e445ba224eb2b04e405ba2d95841b54"}, {name: "to", type: "address", value: "0xfe7da83affb7b6c4267b2b661f4389785d6e9962"}, {name: "value", type: "uint256", value: "495000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[45,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "3982024235320348341" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: setInvest( \"1577145600\", \"31536000\" )", async function( ) {
		const txOriginal = {blockNumber: "6914704", blockHash: "0x3430a6d8bbee1aa212c68832255b31f3ba98943605040e36c86f2d8bd0021add", timeStamp: "1545219707", hash: "0xf0514665cd6d288934afac1f87f66373fde9593b6b1165ff0bf6089847b753cc", nonce: "28", transactionIndex: "136", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "59602", gasPrice: "5000000000", input: "0x42bb66c4000000000000000000000000000000000000000000000000000000005e0155000000000000000000000000000000000000000000000000000000000001e13380", contractAddress: "", cumulativeGasUsed: "7812618", txreceipt_status: "1", gasUsed: "39735", confirmations: "821993", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "release_start", value: "1577145600"}, {type: "uint256", name: "release_duration", value: "31536000"}], name: "setInvest", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setInvest(uint256,uint256)" ]( "1577145600", "31536000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1545219707 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "release_start", type: "uint256"}, {indexed: false, name: "release_duration", type: "uint256"}], name: "NewInvest", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewInvest", events: [{name: "release_start", type: "uint256", value: "1577145600"}, {name: "release_duration", type: "uint256", value: "31536000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: invest( addressList[53], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6914770", blockHash: "0x1ba32b59b3b2186fdf8a5360aa071382717d487252067aa83bcc9e12f1effd77", timeStamp: "1545220820", hash: "0xab206384057480196cd2083a8e2fa78d86ef18630a6694adfbf6b24aa2d75d72", nonce: "29", transactionIndex: "126", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "236023", gasPrice: "10000000000", input: "0xb9b8c246000000000000000000000000c61241a3314cd2c58ae805670813400840509dff0000000000000000000000000000000000000000000069e10de76676d0800000", contractAddress: "", cumulativeGasUsed: "6779997", txreceipt_status: "1", gasUsed: "157349", confirmations: "821927", isError: "0"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "investor", value: addressList[53]}, {type: "uint256", name: "amount", value: "500000000000000000000000"}], name: "invest", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "invest(address,uint256)" ]( addressList[53], "500000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1545220820 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Mint", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Mint", events: [{name: "user", type: "address", value: "0xc61241a3314cd2c58ae805670813400840509dff"}, {name: "amount", type: "uint256", value: "500000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xc61241a3314cd2c58ae805670813400840509dff"}, {name: "value", type: "uint256", value: "500000000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[47,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: setInvest( \"1555372800\", \"31536000\" )", async function( ) {
		const txOriginal = {blockNumber: "6914832", blockHash: "0xbf65c9ec823b9929495ec4fef449e5921f0592fb5594a8bc16cf05d87dc67ca2", timeStamp: "1545221767", hash: "0x0632c0c360573ac51b697161247752ded541dde1a62923ec2f87f02a7a70b07a", nonce: "30", transactionIndex: "50", from: "0x1d76324f495591b003c8a73aa64e0f9a5e9727e1", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "59602", gasPrice: "9000000000", input: "0x42bb66c4000000000000000000000000000000000000000000000000000000005cb51b000000000000000000000000000000000000000000000000000000000001e13380", contractAddress: "", cumulativeGasUsed: "3030725", txreceipt_status: "1", gasUsed: "39735", confirmations: "821865", isError: "0"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "release_start", value: "1555372800"}, {type: "uint256", name: "release_duration", value: "31536000"}], name: "setInvest", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setInvest(uint256,uint256)" ]( "1555372800", "31536000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1545221767 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "release_start", type: "uint256"}, {indexed: false, name: "release_duration", type: "uint256"}], name: "NewInvest", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewInvest", events: [{name: "release_start", type: "uint256", value: "1555372800"}, {name: "release_duration", type: "uint256", value: "31536000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2721226461000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[54], \"190000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6919498", blockHash: "0x1af563a69d023a99aaeae4deff58e71dab0c8752ab98af557da0cb8bf92cc284", timeStamp: "1545290681", hash: "0x597414533814292eb584dd4857d73a4cf68b4ab7387bb6bd7f85bfb6d14c31db", nonce: "1", transactionIndex: "131", from: "0x867152803f4e604636c931ac12ffa6a36ccd7160", to: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae", value: "0", gas: "82740", gasPrice: "5000000000", input: "0xa9059cbb0000000000000000000000009a1645f0663d88515f2119f305bb340c7c708d12000000000000000000000000000000000000000000000066ffcbfd5e5a300000", contractAddress: "", cumulativeGasUsed: "6702058", txreceipt_status: "1", gasUsed: "40160", confirmations: "817199", isError: "0"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[54]}, {type: "uint256", name: "value", value: "1900000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[54], "1900000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1545290681 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x867152803f4e604636c931ac12ffa6a36ccd7160"}, {name: "to", type: "address", value: "0x9a1645f0663d88515f2119f305bb340c7c708d12"}, {name: "value", type: "uint256", value: "1900000000000000000000"}], address: "0x82cf44be0768a3600c4bdea58607783a3a7c51ae"}] ;
		console.error( "eventResultOriginal[49,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "339181369000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
