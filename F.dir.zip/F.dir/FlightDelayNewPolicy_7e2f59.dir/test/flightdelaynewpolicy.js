const FlightDelayNewPolicy = artifacts.require( "./FlightDelayNewPolicy.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "FlightDelayNewPolicy" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x5f9605823c32a09BFaEB7e744784705f4b7e2F59", "0x6F692C070f3263d1c3400367832Faf5CcC6Cd2f2", "0x937251Fca959f81f7fBB7cd2f3EA7f94941a78b2", "0xFC15859AeE77be7DE9d6d45478b0265988e3C937", "0xfEe595B6B4A30bFA12604a5EC92156f1b5a1607f", "0x618Dbef763f8Da7a851719058827e01C3F8524aD", "0xe3f493dfc81d5De417aD01c05Fcc7Cc68c5fa885", "0xe5759a0d285BB2D14B82111532cf1c660Fe57481", "0x5509cE67333342e7758bF845A0897b51E062f502", "0x2718874048aBcCEbE24693e689D31B011c6101EA"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_dayMonthYear", type: "bytes32"}], name: "toUnixtime", outputs: [{name: "unixtime", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "controller", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_statistics0", type: "uint256"}, {indexed: false, name: "_statistics1", type: "uint256"}, {indexed: false, name: "_statistics2", type: "uint256"}, {indexed: false, name: "_statistics3", type: "uint256"}, {indexed: false, name: "_statistics4", type: "uint256"}, {indexed: false, name: "_statistics5", type: "uint256"}], name: "LogPolicyAccepted", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "ethAmount", type: "uint256"}], name: "LogPolicyPaidOut", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}], name: "LogPolicyExpired", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "strReason", type: "bytes32"}], name: "LogPolicyDeclined", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "strReason", type: "bytes32"}], name: "LogPolicyManualPayout", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_recipient", type: "address"}, {indexed: false, name: "_from", type: "uint8"}, {indexed: false, name: "ethAmount", type: "uint256"}], name: "LogSendFunds", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_sender", type: "address"}, {indexed: false, name: "_to", type: "uint8"}, {indexed: false, name: "ethAmount", type: "uint256"}], name: "LogReceiveFunds", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "strReason", type: "bytes32"}], name: "LogSendFail", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "hexQueryId", type: "bytes32"}, {indexed: false, name: "_oraclizeUrl", type: "string"}, {indexed: false, name: "_oraclizeTime", type: "uint256"}], name: "LogOraclizeCall", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "hexQueryId", type: "bytes32"}, {indexed: false, name: "_result", type: "string"}, {indexed: false, name: "hexProof", type: "bytes"}], name: "LogOraclizeCallback", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_policyState", type: "uint8"}, {indexed: false, name: "_stateTime", type: "uint256"}, {indexed: false, name: "_stateMessage", type: "bytes32"}], name: "LogSetState", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogPolicyApplied(uint256,address,bytes32,uint256)", "LogPolicyAccepted(uint256,uint256,uint256,uint256,uint256,uint256,uint256)", "LogPolicyPaidOut(uint256,uint256)", "LogPolicyExpired(uint256)", "LogPolicyDeclined(uint256,bytes32)", "LogPolicyManualPayout(uint256,bytes32)", "LogSendFunds(address,uint8,uint256)", "LogReceiveFunds(address,uint8,uint256)", "LogSendFail(uint256,bytes32)", "LogOraclizeCall(uint256,bytes32,string,uint256)", "LogOraclizeCallback(uint256,bytes32,string,bytes)", "LogSetState(uint256,uint8,uint256,bytes32)", "LogExternal(uint256,address,bytes32)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xa1a0ee9005fffba1f170ed11d5512d7983400e59419ceb31221f71832fa6cb2c", "0x70385f0d2eec84d8ff6456734404ae65b06b980e7360ea503ca23dcc56a1c515", "0xa4952f195dcb5d573305f9d9fe2fd0d63f66aa1149e328d2629377ababab53a7", "0x08b74d3cccbcb3894ccc99c3a75f6a6890f71ea4c039fe60eabd7bee40b1231c", "0x9ee71fae4eaec97727495a88dce95da03083cceac90064c30bd03ef65b86a3ae", "0xa868cd6faa17ac2172ea3d4f9f7910ca932112bfeb017f45ed09bd881c054030", "0x58d25b935835d1791b52774277ec18acc66c328af44c3a19fcf57cb68065611c", "0xd03e9bccd46f248f783faac581aa0546bf19c3646bb6be5ce14839513bb90391", "0xa552c8a0921dff81852c41a9081153b41b89ada680ef32d9e6ed0e8a7d296182", "0x57d5927fefa8de5620b57ca7ac0948a9ea457d8f3af2bd8867728325a6ca5d92", "0x4e010942cd8d70ef60f3bd7e17c62008722f9551f8f28dc7040004160de7e2cc", "0x0f3fb52a4b3a9f6b9191fcfe3320487160165440bcdabb6577a8bc165a87dcc8", "0x61dc648f76dcf4df63a23b1cd65ae4a116413759706ff1c99fd5e839e4765e4d"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4566106 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4649561 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_controller", value: 4}], name: "FlightDelayNewPolicy", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "bytes32", name: "_dayMonthYear", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "toUnixtime", outputs: [{name: "unixtime", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "toUnixtime(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "controller", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "controller()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "FlightDelayNewPolicy", function( accounts ) {

	it( "TEST: FlightDelayNewPolicy( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4566106", timeStamp: "1510873109", hash: "0x1b028e0e5e3868a5e13569fe955aaaf22fa64a99ace908e2d3f9c39c9090252e", nonce: "239", blockHash: "0x97b7b3826292e7fdf1caa63d8f1203a833cc237a63f8224e21b26108bf91ae8b", transactionIndex: "53", from: "0x6f692c070f3263d1c3400367832faf5ccc6cd2f2", to: 0, value: "0", gas: "4000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xc67ce6f5000000000000000000000000937251fca959f81f7fbb7cd2f3ea7f94941a78b2", contractAddress: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", cumulativeGasUsed: "4353279", gasUsed: "2226326", confirmations: "3174317"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_controller", value: addressList[4]}], name: "FlightDelayNewPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = FlightDelayNewPolicy.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510873109 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = FlightDelayNewPolicy.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "12664186522000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x534b2f333531320000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4569117", timeStamp: "1510914409", hash: "0x67272304623f406897db7e7ebf4a0792eb60e535aa001f459fab799477dd12fd", nonce: "25", blockHash: "0x0470047d2b7f27ef34b966906b192dd52a1027b97a7410370fa080a4720ad47c", transactionIndex: "60", from: "0xfc15859aee77be7de9d6d45478b0265988e3c937", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "50000000000000000", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb66534b2f33353132000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a1330bc000000000000000000000000000000000000000000000000000000005a133c7400000000000000000000000000000000000000000000000000000000000000003934366565643534396365376236323766316630333162363632623462366100", contractAddress: "", cumulativeGasUsed: "2401085", gasUsed: "817037", confirmations: "3171306"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x534b2f3335313200000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32300000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511207100"}, {type: "uint256", name: "_arrivalTime", value: "1511210100"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x3934366565643534396365376236323766316630333162363632623462366100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x534b2f3335313200000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32300000000000000000000000000000000000", "1511207100", "1511210100", "0", "0x3934366565643534396365376236323766316630333162363632623462366100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510914409 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "0"}, {name: "_customer", type: "address", value: "0xfc15859aee77be7de9d6d45478b0265988e3c937"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x534b2f3335313200000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "48510000000000000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[1,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "0"}, {name: "_address", type: "address", value: "0xfc15859aee77be7de9d6d45478b0265988e3c937"}, {name: "_externalId", type: "bytes32", value: "0x3934366565643534396365376236323766316630333162363632623462366100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[1,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "270046619655573000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x55412f393732380000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4570260", timeStamp: "1510930440", hash: "0x2fcdcab764209975597ef24d094abb051d2ab54f12e363e6e46b0f5b540e8be3", nonce: "77", blockHash: "0xaba226ab0a412c3366be27bb154d4e4af02c1a626b8cebae0e135c0481a54976", transactionIndex: "106", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6655412f39373238000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32330000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a16bbc4000000000000000000000000000000000000000000000000000000005a1765b000000000000000000000000000000000000000000000000000000000000000013730353933353635626238386335653462333231313965376634353863663900", contractAddress: "", cumulativeGasUsed: "5354067", gasUsed: "820150", confirmations: "3170163"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x55412f3937323800000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32330000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511439300"}, {type: "uint256", name: "_arrivalTime", value: "1511482800"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3730353933353635626238386335653462333231313965376634353863663900"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x55412f3937323800000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32330000000000000000000000000000000000", "1511439300", "1511482800", "1", "0x3730353933353635626238386335653462333231313965376634353863663900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1510930440 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "1"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x55412f3937323800000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[2,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "1"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3730353933353635626238386335653462333231313965376634353863663900"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[2,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4f532f353531000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4570886", timeStamp: "1510939253", hash: "0xa885ba8e0726cfe3e8e56b051905e1ef813931fe3855cb96d7eaaa890cd36d72", nonce: "21", blockHash: "0x3175300e0a52b62ceceb7f212569ea8a06f292ab1b63396434ac7a078c36f25c", transactionIndex: "40", from: "0x618dbef763f8da7a851719058827e01c3f8524ad", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "80000000000000000", gas: "1000000", gasPrice: "14700000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664f532f35353100000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a13d5f8000000000000000000000000000000000000000000000000000000005a13e8b800000000000000000000000000000000000000000000000000000000000000003964393237663034646232616264343366636265306630353134643733663100", contractAddress: "", cumulativeGasUsed: "2321335", gasUsed: "801030", confirmations: "3169537"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "80000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4f532f3535310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511249400"}, {type: "uint256", name: "_arrivalTime", value: "1511254200"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4f532f3535310000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32310000000000000000000000000000000000", "1511249400", "1511254200", "0", "0x3964393237663034646232616264343366636265306630353134643733663100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1510939253 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "2"}, {name: "_customer", type: "address", value: "0x618dbef763f8da7a851719058827e01c3f8524ad"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4f532f3535310000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "77616000000000000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[3,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "2"}, {name: "_address", type: "address", value: "0x618dbef763f8da7a851719058827e01c3f8524ad"}, {name: "_externalId", type: "bytes32", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[3,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "51037071577819234026" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f333535330000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4571018", timeStamp: "1510940780", hash: "0x80b74b744d3e438e6bc041dd08c5901dc2024da4ee94466c3476be69fc74a017", nonce: "22", blockHash: "0xb1aedf80913fbed31c736f912ed7b6bde8ff4adb9d4f3f50627853f4f7d651f2", transactionIndex: "30", from: "0x618dbef763f8da7a851719058827e01c3f8524ad", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "80000000000000000", gas: "1000000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f33353533000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a13d5f8000000000000000000000000000000000000000000000000000000005a13e8b800000000000000000000000000000000000000000000000000000000000000003964393237663034646232616264343366636265306630353134643733663100", contractAddress: "", cumulativeGasUsed: "1733495", gasUsed: "772037", confirmations: "3169405"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "80000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3335353300000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511249400"}, {type: "uint256", name: "_arrivalTime", value: "1511254200"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3335353300000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32310000000000000000000000000000000000", "1511249400", "1511254200", "0", "0x3964393237663034646232616264343366636265306630353134643733663100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1510940780 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "3"}, {name: "_customer", type: "address", value: "0x618dbef763f8da7a851719058827e01c3f8524ad"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3335353300000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "77616000000000000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[4,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "3"}, {name: "_address", type: "address", value: "0x618dbef763f8da7a851719058827e01c3f8524ad"}, {name: "_externalId", type: "bytes32", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[4,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "51037071577819234026" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f333231390000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4571159", timeStamp: "1510942739", hash: "0xe57daa2e8790233117c05fde6ec71282eb4a6338d8c1bbf3fb228523071d7771", nonce: "78", blockHash: "0xdc3e3c9942ac67b7047a4aaf149207327ad5682e0b2c7214d63d6df2660f803f", transactionIndex: "26", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f33323139000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a136dac000000000000000000000000000000000000000000000000000000005a13d85000000000000000000000000000000000000000000000000000000000000000013934366565643534396365376236323766316630333162363632623462366100", contractAddress: "", cumulativeGasUsed: "3837073", gasUsed: "790150", confirmations: "3169264"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3332313900000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511222700"}, {type: "uint256", name: "_arrivalTime", value: "1511250000"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3934366565643534396365376236323766316630333162363632623462366100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3332313900000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32310000000000000000000000000000000000", "1511222700", "1511250000", "1", "0x3934366565643534396365376236323766316630333162363632623462366100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1510942739 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "4"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3332313900000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[5,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "4"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3934366565643534396365376236323766316630333162363632623462366100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[5,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x55412f393732350000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4571160", timeStamp: "1510942762", hash: "0x18f248ba3eedcd76e9c993d60705193d087a34d58c93cbf8432da0a6b0fc0f3b", nonce: "79", blockHash: "0x057466eb6440c47878253370dfa2ac857ef48c31747a062e797d85932ffe0b26", transactionIndex: "32", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6655412f39373235000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a18e868000000000000000000000000000000000000000000000000000000005a19831800000000000000000000000000000000000000000000000000000000000000013635333537663936626233653663613738643139633131353132333964646600", contractAddress: "", cumulativeGasUsed: "2185938", gasUsed: "805150", confirmations: "3169263"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x55412f3937323500000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32350000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511581800"}, {type: "uint256", name: "_arrivalTime", value: "1511621400"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3635333537663936626233653663613738643139633131353132333964646600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x55412f3937323500000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32350000000000000000000000000000000000", "1511581800", "1511621400", "1", "0x3635333537663936626233653663613738643139633131353132333964646600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1510942762 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "5"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x55412f3937323500000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[6,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "5"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3635333537663936626233653663613738643139633131353132333964646600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[6,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x55412f393732350000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4571179", timeStamp: "1510943188", hash: "0x1c9706043b23f6c145d89feb307215f428e41fa57ceb260cef04478891002b35", nonce: "80", blockHash: "0xfe7e08d804c6c9f4f34716d96aa3f528a040ad25ba1c0052beeb90dc207969fc", transactionIndex: "47", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6655412f39373235000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32360000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a1a39e8000000000000000000000000000000000000000000000000000000005a1ad49800000000000000000000000000000000000000000000000000000000000000013635333537663936626233653663613738643139633131353132333964646600", contractAddress: "", cumulativeGasUsed: "2546253", gasUsed: "790150", confirmations: "3169244"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x55412f3937323500000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32360000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511668200"}, {type: "uint256", name: "_arrivalTime", value: "1511707800"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3635333537663936626233653663613738643139633131353132333964646600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x55412f3937323500000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32360000000000000000000000000000000000", "1511668200", "1511707800", "1", "0x3635333537663936626233653663613738643139633131353132333964646600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1510943188 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "6"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x55412f3937323500000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[7,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "6"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3635333537663936626233653663613738643139633131353132333964646600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[7,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4f532f353531000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4571206", timeStamp: "1510943591", hash: "0x71bb091f3f6584c780e213023f9ebb3828dc3ecfd5700689f083a7f4bf5d3cb6", nonce: "81", blockHash: "0x9a55a71da9b483360672bbc2914186493da925952d2d9614595ddefd18a15086", transactionIndex: "57", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "2500", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664f532f35353100000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a13d5f8000000000000000000000000000000000000000000000000000000005a13e8b800000000000000000000000000000000000000000000000000000000000000013964393237663034646232616264343366636265306630353134643733663100", contractAddress: "", cumulativeGasUsed: "2816081", gasUsed: "714121", confirmations: "3169217"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "2500" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4f532f3535310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511249400"}, {type: "uint256", name: "_arrivalTime", value: "1511254200"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4f532f3535310000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32310000000000000000000000000000000000", "1511249400", "1511254200", "1", "0x3964393237663034646232616264343366636265306630353134643733663100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1510943591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "7"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4f532f3535310000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "2426"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[8,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "7"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[8,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4f532f353631000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4571211", timeStamp: "1510943652", hash: "0x388b0148b02e4d6e3ca9e375ddf1277670669519446e4a5f48f01047d451acbb", nonce: "23", blockHash: "0x3dd8b4aefdb579c6ae00be908055057cb9afcaccdd2a2b009b372c601206099c", transactionIndex: "36", from: "0x618dbef763f8da7a851719058827e01c3f8524ad", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "80000000000000000", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664f532f35363100000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a13c338000000000000000000000000000000000000000000000000000000005a13d85000000000000000000000000000000000000000000000000000000000000000003964393237663034646232616264343366636265306630353134643733663100", contractAddress: "", cumulativeGasUsed: "1837790", gasUsed: "771030", confirmations: "3169212"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "80000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4f532f3536310000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511244600"}, {type: "uint256", name: "_arrivalTime", value: "1511250000"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4f532f3536310000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32310000000000000000000000000000000000", "1511244600", "1511250000", "0", "0x3964393237663034646232616264343366636265306630353134643733663100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1510943652 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "8"}, {name: "_customer", type: "address", value: "0x618dbef763f8da7a851719058827e01c3f8524ad"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4f532f3536310000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "77616000000000000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[9,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "8"}, {name: "_address", type: "address", value: "0x618dbef763f8da7a851719058827e01c3f8524ad"}, {name: "_externalId", type: "bytes32", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[9,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "51037071577819234026" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x55412f393732350000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4571213", timeStamp: "1510943703", hash: "0x1b31e33589f82d20d7c7f74e0bf336b60a722f1f87a416f03579f303d2b0c88a", nonce: "82", blockHash: "0x60e9a75bcda8ebd6e339ccdbd1ac345b97b42de59641869fe58c11337cb3811d", transactionIndex: "67", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "2500", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6655412f39373235000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32360000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a1a39e8000000000000000000000000000000000000000000000000000000005a1ad49800000000000000000000000000000000000000000000000000000000000000013635333537663936626233653663613738643139633131353132333964646600", contractAddress: "", cumulativeGasUsed: "5094235", gasUsed: "715128", confirmations: "3169210"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "2500" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x55412f3937323500000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32360000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511668200"}, {type: "uint256", name: "_arrivalTime", value: "1511707800"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3635333537663936626233653663613738643139633131353132333964646600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x55412f3937323500000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32360000000000000000000000000000000000", "1511668200", "1511707800", "1", "0x3635333537663936626233653663613738643139633131353132333964646600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1510943703 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "9"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x55412f3937323500000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "2426"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[10,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "9"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3635333537663936626233653663613738643139633131353132333964646600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[10,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f333535330000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4571235", timeStamp: "1510943939", hash: "0x5af85485863b708eea7799fb500436905b270fc2e35dfa8c05cb01ec03d47b38", nonce: "83", blockHash: "0x5ccdb51d832e08623cdb01aada7a843b2f5a531a33b32359fee21d9c84ca8743", transactionIndex: "59", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "2500", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f33353533000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a13d5f8000000000000000000000000000000000000000000000000000000005a13e8b800000000000000000000000000000000000000000000000000000000000000013964393237663034646232616264343366636265306630353134643733663100", contractAddress: "", cumulativeGasUsed: "3093085", gasUsed: "715128", confirmations: "3169188"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "2500" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3335353300000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511249400"}, {type: "uint256", name: "_arrivalTime", value: "1511254200"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3335353300000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32310000000000000000000000000000000000", "1511249400", "1511254200", "1", "0x3964393237663034646232616264343366636265306630353134643733663100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1510943939 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "10"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3335353300000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "2426"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[11,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "10"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[11,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x55322f323034350000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4571304", timeStamp: "1510944712", hash: "0x15e21cdd60cfa86cf0d78b486a83610930394ebd3084b5de0afd3c8789741cb8", nonce: "84", blockHash: "0x72e500311d81cb484cc511ed6fd2711f9d7f8e649a979faed25b3c3cd285cf8f", transactionIndex: "62", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1300", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6655322f32303435000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a14247c000000000000000000000000000000000000000000000000000000005a143ac000000000000000000000000000000000000000000000000000000000000000033664396237383461616236653835363964343265393363666132666162326600", contractAddress: "", cumulativeGasUsed: "2987911", gasUsed: "805150", confirmations: "3169119"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1300" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x55322f3230343500000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511269500"}, {type: "uint256", name: "_arrivalTime", value: "1511275200"}, {type: "uint8", name: "_currency", value: "3"}, {type: "bytes32", name: "_customerExternalId", value: "0x3664396237383461616236653835363964343265393363666132666162326600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x55322f3230343500000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32310000000000000000000000000000000000", "1511269500", "1511275200", "3", "0x3664396237383461616236653835363964343265393363666132666162326600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510944712 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "11"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x55322f3230343500000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1262"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[12,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "11"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3664396237383461616236653835363964343265393363666132666162326600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[12,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f333900000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4571351", timeStamp: "1510945235", hash: "0x6bfc9d754d90e1bfa81d68432591683cb041074ac5f574e9c21fb334390d3dac", nonce: "85", blockHash: "0xaaba188fb63fa376c1d581e38709598cf72210150bd5fdd8a43af4e00cf6fd38", transactionIndex: "15", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f33390000000000000000000000000000000000000000000000000000002f6465702f323031372f31312f31390000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a10ff68000000000000000000000000000000000000000000000000000000005a119a1800000000000000000000000000000000000000000000000000000000000000013036623263383466373537363863613739363761346564316133363530353000", contractAddress: "", cumulativeGasUsed: "1755517", gasUsed: "803136", confirmations: "3169072"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3339000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f31390000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511063400"}, {type: "uint256", name: "_arrivalTime", value: "1511103000"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3036623263383466373537363863613739363761346564316133363530353000"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3339000000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f31390000000000000000000000000000000000", "1511063400", "1511103000", "1", "0x3036623263383466373537363863613739363761346564316133363530353000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510945235 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "12"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3339000000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[13,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "12"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3036623263383466373537363863613739363761346564316133363530353000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[13,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x55322f323034350000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4571729", timeStamp: "1510950502", hash: "0xcd66bc724408a4513fddd27f2a510b4d4f6e838e490bad08cf34b876492f542c", nonce: "86", blockHash: "0x767742f0c3e39ecd0f5f0de4300ccf94591ed866f72511e26562fab38c846356", transactionIndex: "53", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "11025000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6655322f32303435000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a14247c000000000000000000000000000000000000000000000000000000005a143ac000000000000000000000000000000000000000000000000000000000000000016533303963393335353064386639663333363637353261613965386137616400", contractAddress: "", cumulativeGasUsed: "3267773", gasUsed: "726344", confirmations: "3168694"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x55322f3230343500000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511269500"}, {type: "uint256", name: "_arrivalTime", value: "1511275200"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x6533303963393335353064386639663333363637353261613965386137616400"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x55322f3230343500000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32310000000000000000000000000000000000", "1511269500", "1511275200", "1", "0x6533303963393335353064386639663333363637353261613965386137616400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1510950502 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "13"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x55322f3230343500000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[14,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "13"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x6533303963393335353064386639663333363637353261613965386137616400"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[14,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f333900000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4571944", timeStamp: "1510953804", hash: "0xf3701608159f4d03e319aa14782d17cbf999d0844ce64e1d6888663c27642786", nonce: "87", blockHash: "0x89ba77f3ac104f405dfc5d70aa18b13b2d7fc167d06494b094f59b93008919dd", transactionIndex: "142", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "11025000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f33390000000000000000000000000000000000000000000000000000002f6465702f323031372f31312f31390000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a10ff68000000000000000000000000000000000000000000000000000000005a119a1800000000000000000000000000000000000000000000000000000000000000013964393237663034646232616264343366636265306630353134643733663100", contractAddress: "", cumulativeGasUsed: "5081773", gasUsed: "713114", confirmations: "3168479"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3339000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f31390000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511063400"}, {type: "uint256", name: "_arrivalTime", value: "1511103000"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3339000000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f31390000000000000000000000000000000000", "1511063400", "1511103000", "1", "0x3964393237663034646232616264343366636265306630353134643733663100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510953804 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "14"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3339000000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[15,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "14"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[15,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f323135310000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4574544", timeStamp: "1510990431", hash: "0x8289439ebd697fe6647f0563a48371f1e468824eecdd5ad1c6eef85c80c0e8ea", nonce: "88", blockHash: "0xc2870ad8694c3eff4e01a33bb1c08ffdcc25ed9766ccce8ac809f7d424380562", transactionIndex: "64", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "2400", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f32313531000000000000000000000000000000000000000000000000002f6465702f323031372f31312f31390000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a11b50c000000000000000000000000000000000000000000000000000000005a11d00000000000000000000000000000000000000000000000000000000000000000013865333634613766376161383661626661353065376466623734636535386600", contractAddress: "", cumulativeGasUsed: "3416813", gasUsed: "805086", confirmations: "3165879"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "2400" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3231353100000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f31390000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511109900"}, {type: "uint256", name: "_arrivalTime", value: "1511116800"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3865333634613766376161383661626661353065376466623734636535386600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3231353100000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f31390000000000000000000000000000000000", "1511109900", "1511116800", "1", "0x3865333634613766376161383661626661353065376466623734636535386600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510990431 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "15"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3231353100000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "2329"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[16,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "15"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3865333634613766376161383661626661353065376466623734636535386600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[16,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x53552f323339300000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4581310", timeStamp: "1511083918", hash: "0xe1becad26a86402d6a4d5f3c5ca1e6fae642a43f656eea088641eb2be4444e9f", nonce: "4", blockHash: "0xa7160a110677cbe3d645f913eee74e1d004b2e85de0060cb05aba42df4b4568f", transactionIndex: "93", from: "0xe3f493dfc81d5de417ad01c05fcc7cc68c5fa885", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "80000000000000000", gas: "300000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6653552f32333930000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a128220000000000000000000000000000000000000000000000000000000005a12b80800000000000000000000000000000000000000000000000000000000000000003066643266633639333437623834383863313765346437366134633830396400", contractAddress: "", cumulativeGasUsed: "4456864", gasUsed: "163869", confirmations: "3159113"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "80000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x53552f3233393000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32300000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511162400"}, {type: "uint256", name: "_arrivalTime", value: "1511176200"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x3066643266633639333437623834383863313765346437366134633830396400"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x53552f3233393000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32300000000000000000000000000000000000", "1511162400", "1511176200", "0", "0x3066643266633639333437623834383863313765346437366134633830396400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1511083918 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "strReason", type: "bytes32"}], name: "LogPolicyDeclined", type: "event"} ;
		console.error( "eventCallOriginal[17,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPolicyDeclined", events: [{name: "_policyId", type: "uint256", value: "0"}, {name: "strReason", type: "bytes32", value: "0x496e76616c6964206172726976616c2f6465706172747572652074696d650000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[17,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "62707559915352790" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f343535000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4587583", timeStamp: "1511169803", hash: "0x2b358c0f5035612c75c37d3d239309f768e236087e06a39aff284a5cf110374b", nonce: "89", blockHash: "0x64fca05264fc288a466d4315c3dd0af521de224260e9319069d1ba44d2178a03", transactionIndex: "84", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f34353500000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a148944000000000000000000000000000000000000000000000000000000005a14a0b400000000000000000000000000000000000000000000000000000000000000013534313739333239633262633964333330333463663439373061663966356600", contractAddress: "", cumulativeGasUsed: "3735795", gasUsed: "804143", confirmations: "3152840"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3435350000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511295300"}, {type: "uint256", name: "_arrivalTime", value: "1511301300"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3534313739333239633262633964333330333463663439373061663966356600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3435350000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32310000000000000000000000000000000000", "1511295300", "1511301300", "1", "0x3534313739333239633262633964333330333463663439373061663966356600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1511169803 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "16"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3435350000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[18,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "16"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3534313739333239633262633964333330333463663439373061663966356600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[18,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f313338000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4587620", timeStamp: "1511170320", hash: "0x12d82159a00222adb7924ab020e95eacac9add559402ef811463956f76110945", nonce: "90", blockHash: "0x5e9bd29088e9be61d83f767e1eaad3d57bc18eefbe75bb04a310c3cdb8c3942e", transactionIndex: "21", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f31333800000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a149d30000000000000000000000000000000000000000000000000000000005a15414000000000000000000000000000000000000000000000000000000000000000013461333438333134646535323033306235646231366334666462313833353600", contractAddress: "", cumulativeGasUsed: "1469870", gasUsed: "804143", confirmations: "3152803"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3133380000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511300400"}, {type: "uint256", name: "_arrivalTime", value: "1511342400"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3461333438333134646535323033306235646231366334666462313833353600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3133380000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32310000000000000000000000000000000000", "1511300400", "1511342400", "1", "0x3461333438333134646535323033306235646231366334666462313833353600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1511170320 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "17"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3133380000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[19,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "17"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3461333438333134646535323033306235646231366334666462313833353600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[19,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x55412f393732350000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4587982", timeStamp: "1511175335", hash: "0xad956ba46d918f77e83a6bfc1acc99208e3addaa8aa234773b788176cff4def9", nonce: "91", blockHash: "0x1995d6965981c48b390f713ebf2eacc69870d8ed9d145ccc583c2939d9e938a0", transactionIndex: "20", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6655412f39373235000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32360000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a1a39e8000000000000000000000000000000000000000000000000000000005a1ad49800000000000000000000000000000000000000000000000000000000000000013635333537663936626233653663613738643139633131353132333964646600", contractAddress: "", cumulativeGasUsed: "1303046", gasUsed: "715128", confirmations: "3152441"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x55412f3937323500000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32360000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511668200"}, {type: "uint256", name: "_arrivalTime", value: "1511707800"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3635333537663936626233653663613738643139633131353132333964646600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x55412f3937323500000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32360000000000000000000000000000000000", "1511668200", "1511707800", "1", "0x3635333537663936626233653663613738643139633131353132333964646600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1511175335 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "18"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x55412f3937323500000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[20,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "18"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3635333537663936626233653663613738643139633131353132333964646600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[20,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f313637350000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588060", timeStamp: "1511176368", hash: "0xccafda1bad1c315683379e94cdaad54d0281694acc989a560aaf2bfe21d1ebf2", nonce: "0", blockHash: "0x5af317427bb29b759d1b993c37e418f8a5447d20a2b8a95282d37b9a1edb8ce2", transactionIndex: "40", from: "0xe5759a0d285bb2d14b82111532cf1c660fe57481", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "50000000000000000", gas: "1000000", gasPrice: "11730149376", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f31363735000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a142ddc000000000000000000000000000000000000000000000000000000005a143f7000000000000000000000000000000000000000000000000000000000000000006165623536646336653135326138623832643330303837636336306661343700", contractAddress: "", cumulativeGasUsed: "2057203", gasUsed: "802037", confirmations: "3152363"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3136373500000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511271900"}, {type: "uint256", name: "_arrivalTime", value: "1511276400"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x6165623536646336653135326138623832643330303837636336306661343700"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3136373500000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32310000000000000000000000000000000000", "1511271900", "1511276400", "0", "0x6165623536646336653135326138623832643330303837636336306661343700", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1511176368 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "19"}, {name: "_customer", type: "address", value: "0xe5759a0d285bb2d14b82111532cf1c660fe57481"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3136373500000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "48510000000000000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[21,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "19"}, {name: "_address", type: "address", value: "0xe5759a0d285bb2d14b82111532cf1c660fe57481"}, {name: "_externalId", type: "bytes32", value: "0x6165623536646336653135326138623832643330303837636336306661343700"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[21,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "735015905101329017" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f323831350000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588190", timeStamp: "1511178229", hash: "0x17062676d3aea6575d0f8c1d4a0a022a71e58648429e10b68aa1da7afbe273b6", nonce: "92", blockHash: "0xf38e767eee708143052ef5618d9319ce0498d9b580f19e0c3ee45c4c39078c5f", transactionIndex: "50", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f32383135000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a146e50000000000000000000000000000000000000000000000000000000005a147a0800000000000000000000000000000000000000000000000000000000000000013663373165646361383963633335353862613462633865336261396161646600", contractAddress: "", cumulativeGasUsed: "2378226", gasUsed: "805150", confirmations: "3152233"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3238313500000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511288400"}, {type: "uint256", name: "_arrivalTime", value: "1511291400"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3663373165646361383963633335353862613462633865336261396161646600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3238313500000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32310000000000000000000000000000000000", "1511288400", "1511291400", "1", "0x3663373165646361383963633335353862613462633865336261396161646600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1511178229 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "20"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3238313500000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[22,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "20"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3663373165646361383963633335353862613462633865336261396161646600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[22,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x574e2f333831350000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588341", timeStamp: "1511180531", hash: "0x0af9528eb617666fc058645a097d64aa0280662fc777f3abf923f2033bd8495f", nonce: "93", blockHash: "0x44ba3b993632fabeacc24455aa584aa130f51d655ab11269d482a94c3f505e7f", transactionIndex: "62", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1600", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb66574e2f33383135000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a14cf94000000000000000000000000000000000000000000000000000000005a14e4ac00000000000000000000000000000000000000000000000000000000000000013764306637623866313938643232656232663934363336623538616364666100", contractAddress: "", cumulativeGasUsed: "2488687", gasUsed: "805150", confirmations: "3152082"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1600" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x574e2f3338313500000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32320000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511313300"}, {type: "uint256", name: "_arrivalTime", value: "1511318700"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3764306637623866313938643232656232663934363336623538616364666100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x574e2f3338313500000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32320000000000000000000000000000000000", "1511313300", "1511318700", "1", "0x3764306637623866313938643232656232663934363336623538616364666100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1511180531 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "21"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x574e2f3338313500000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1553"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[23,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "21"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3764306637623866313938643232656232663934363336623538616364666100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[23,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x55412f393732350000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588862", timeStamp: "1511187530", hash: "0x16f74ef2fb2341c871626b017818b8fc7bca4714001176464c83bdd4bd809528", nonce: "94", blockHash: "0xae504a6bd274c93f20cd4c363052788c8f9a38170c48fd4fdf4816ad1e47c190", transactionIndex: "7", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6655412f39373235000000000000000000000000000000000000000000000000002f6465702f323031372f31322f30360000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a2768e8000000000000000000000000000000000000000000000000000000005a28039800000000000000000000000000000000000000000000000000000000000000013635333537663936626233653663613738643139633131353132333964646600", contractAddress: "", cumulativeGasUsed: "1115574", gasUsed: "790150", confirmations: "3151561"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x55412f3937323500000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31322f30360000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1512532200"}, {type: "uint256", name: "_arrivalTime", value: "1512571800"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3635333537663936626233653663613738643139633131353132333964646600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x55412f3937323500000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31322f30360000000000000000000000000000000000", "1512532200", "1512571800", "1", "0x3635333537663936626233653663613738643139633131353132333964646600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1511187530 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "22"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x55412f3937323500000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[24,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "22"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3635333537663936626233653663613738643139633131353132333964646600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[24,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f313638300000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588880", timeStamp: "1511187789", hash: "0xba052a7268812ee5295889a9015885d92d2a932f5dfd56d0539bfda40533a111", nonce: "95", blockHash: "0xc440b42199de71085699e63d991af76476eedb805151a83c5c467a8f6a59e74b", transactionIndex: "73", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f31363830000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a145104000000000000000000000000000000000000000000000000000000005a14616c00000000000000000000000000000000000000000000000000000000000000013862313632346132666439643631663063643534383064656138373633623000", contractAddress: "", cumulativeGasUsed: "3322770", gasUsed: "805150", confirmations: "3151543"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3136383000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511280900"}, {type: "uint256", name: "_arrivalTime", value: "1511285100"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3862313632346132666439643631663063643534383064656138373633623000"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3136383000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32310000000000000000000000000000000000", "1511280900", "1511285100", "1", "0x3862313632346132666439643631663063643534383064656138373633623000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1511187789 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "23"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3136383000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[25,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "23"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3862313632346132666439643631663063643534383064656138373633623000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[25,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x43582f363630330000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588927", timeStamp: "1511188597", hash: "0xed822519ed8ac960b16bc5d0e611e899c64827a99d9fb83bf38bae2234575edf", nonce: "96", blockHash: "0xc5e0a85ed039cc703cea976c99cc6afecef35db8d676f73b7093deb4e313992d", transactionIndex: "53", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6643582f36363033000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32330000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a1670c4000000000000000000000000000000000000000000000000000000005a16812c00000000000000000000000000000000000000000000000000000000000000013132663962643031373637343762333637356636663136353531333034636100", contractAddress: "", cumulativeGasUsed: "3422754", gasUsed: "805150", confirmations: "3151496"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x43582f3636303300000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32330000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511420100"}, {type: "uint256", name: "_arrivalTime", value: "1511424300"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3132663962643031373637343762333637356636663136353531333034636100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x43582f3636303300000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32330000000000000000000000000000000000", "1511420100", "1511424300", "1", "0x3132663962643031373637343762333637356636663136353531333034636100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1511188597 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "24"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x43582f3636303300000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[26,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "24"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3132663962643031373637343762333637356636663136353531333034636100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[26,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f313637380000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588932", timeStamp: "1511188664", hash: "0xeb918147d12eb3095197bcfee32275e66a12b47304faf2e9778188aa33ac890e", nonce: "97", blockHash: "0x5cef3ebdf05135b817c15953f8d90c39a96d8393802d30b6bbc0238a9244b560", transactionIndex: "47", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f31363738000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32330000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a1670c4000000000000000000000000000000000000000000000000000000005a16812c00000000000000000000000000000000000000000000000000000000000000013132663962643031373637343762333637356636663136353531333034636100", contractAddress: "", cumulativeGasUsed: "2459583", gasUsed: "790150", confirmations: "3151491"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3136373800000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32330000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511420100"}, {type: "uint256", name: "_arrivalTime", value: "1511424300"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3132663962643031373637343762333637356636663136353531333034636100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3136373800000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32330000000000000000000000000000000000", "1511420100", "1511424300", "1", "0x3132663962643031373637343762333637356636663136353531333034636100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1511188664 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "25"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3136373800000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[27,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "25"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3132663962643031373637343762333637356636663136353531333034636100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[27,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x43492f393633330000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4588949", timeStamp: "1511188845", hash: "0xcbb848def14480b53750ed642ac5755a1ad645217252187b0a16419a0a8fd756", nonce: "1", blockHash: "0xf82fe3e62508afeb6ab76f2ccade70360adaa3d1579e4aec9fef7f556242860c", transactionIndex: "15", from: "0xe5759a0d285bb2d14b82111532cf1c660fe57481", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "50000000000000000", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6643492f39363333000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a158fc4000000000000000000000000000000000000000000000000000000005a15a59000000000000000000000000000000000000000000000000000000000000000003365613165326233313561336334653836393465386232356631343834663000", contractAddress: "", cumulativeGasUsed: "1374210", gasUsed: "787037", confirmations: "3151474"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x43492f3936333300000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32320000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511362500"}, {type: "uint256", name: "_arrivalTime", value: "1511368080"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x3365613165326233313561336334653836393465386232356631343834663000"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x43492f3936333300000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32320000000000000000000000000000000000", "1511362500", "1511368080", "0", "0x3365613165326233313561336334653836393465386232356631343834663000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1511188845 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "26"}, {name: "_customer", type: "address", value: "0xe5759a0d285bb2d14b82111532cf1c660fe57481"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x43492f3936333300000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "48510000000000000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[28,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "26"}, {name: "_address", type: "address", value: "0xe5759a0d285bb2d14b82111532cf1c660fe57481"}, {name: "_externalId", type: "bytes32", value: "0x3365613165326233313561336334653836393465386232356631343834663000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[28,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "735015905101329017" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f333900000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4589266", timeStamp: "1511193352", hash: "0xe864d6f52f92f2ab1c8049251d9886dceb660cf1e86ba97fa6a455cf2a6bb0e2", nonce: "98", blockHash: "0xda37e64dadc400abb38311f998772c098e8db3841655fd89cfb7d6fec0de2295", transactionIndex: "51", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1700", gas: "1000000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f33390000000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32330000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a164568000000000000000000000000000000000000000000000000000000005a16e01800000000000000000000000000000000000000000000000000000000000000026361616464346366643365303963373239613063316138353231626365666600", contractAddress: "", cumulativeGasUsed: "5632715", gasUsed: "803136", confirmations: "3151157"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1700" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3339000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32330000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511409000"}, {type: "uint256", name: "_arrivalTime", value: "1511448600"}, {type: "uint8", name: "_currency", value: "2"}, {type: "bytes32", name: "_customerExternalId", value: "0x6361616464346366643365303963373239613063316138353231626365666600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3339000000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32330000000000000000000000000000000000", "1511409000", "1511448600", "2", "0x6361616464346366643365303963373239613063316138353231626365666600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1511193352 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "27"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3339000000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1650"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[29,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "27"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x6361616464346366643365303963373239613063316138353231626365666600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[29,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f313538320000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4589520", timeStamp: "1511197044", hash: "0x16cbf23d1c796c6d110a02d94b670cdff3c8d11408fbbeff44ae042fec8fcbf1", nonce: "99", blockHash: "0xfa14814e6fe79a502b11dc3e0992cba9641a8e35b3fc480c9de8c265af927c3f", transactionIndex: "27", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f31353832000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32330000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a16f080000000000000000000000000000000000000000000000000000000005a17034000000000000000000000000000000000000000000000000000000000000000013964393237663034646232616264343366636265306630353134643733663100", contractAddress: "", cumulativeGasUsed: "1756386", gasUsed: "790150", confirmations: "3150903"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3135383200000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32330000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511452800"}, {type: "uint256", name: "_arrivalTime", value: "1511457600"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3135383200000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32330000000000000000000000000000000000", "1511452800", "1511457600", "1", "0x3964393237663034646232616264343366636265306630353134643733663100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1511197044 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "28"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3135383200000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[30,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "28"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[30,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f313538320000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4589523", timeStamp: "1511197082", hash: "0xe6d2c8e030716c6bbe6978e81803e573e3233decdf05ef8b3e31a5265a3fdc15", nonce: "24", blockHash: "0x2f557f0f5837ff51f240e385d73e2199182b53287aa8939b967c728bf6fe0426", transactionIndex: "14", from: "0x618dbef763f8da7a851719058827e01c3f8524ad", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "80000000000000000", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f31353832000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32330000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a16f080000000000000000000000000000000000000000000000000000000005a17034000000000000000000000000000000000000000000000000000000000000000003964393237663034646232616264343366636265306630353134643733663100", contractAddress: "", cumulativeGasUsed: "1085952", gasUsed: "697015", confirmations: "3150900"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "80000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3135383200000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32330000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511452800"}, {type: "uint256", name: "_arrivalTime", value: "1511457600"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3135383200000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32330000000000000000000000000000000000", "1511452800", "1511457600", "0", "0x3964393237663034646232616264343366636265306630353134643733663100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1511197082 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "29"}, {name: "_customer", type: "address", value: "0x618dbef763f8da7a851719058827e01c3f8524ad"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3135383200000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "77616000000000000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[31,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "29"}, {name: "_address", type: "address", value: "0x618dbef763f8da7a851719058827e01c3f8524ad"}, {name: "_externalId", type: "bytes32", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[31,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "51037071577819234026" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f343234350000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4590995", timeStamp: "1511218365", hash: "0xc3cabbc49c509f79c2a7b9fb24a75bc4833822502fb4fcd335c860aad13e7965", nonce: "100", blockHash: "0xaf0bf9f27ec874b2c94c68056be35b2fbe2911a2ed0736500830fde88349a711", transactionIndex: "25", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "2500", gas: "1000000", gasPrice: "16500000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f34323435000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a151260000000000000000000000000000000000000000000000000000000005a1523f400000000000000000000000000000000000000000000000000000000000000013533346333636261646666306461363838366265616431333363323036333500", contractAddress: "", cumulativeGasUsed: "1452055", gasUsed: "805150", confirmations: "3149428"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "2500" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3432343500000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32320000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511330400"}, {type: "uint256", name: "_arrivalTime", value: "1511334900"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3533346333636261646666306461363838366265616431333363323036333500"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3432343500000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32320000000000000000000000000000000000", "1511330400", "1511334900", "1", "0x3533346333636261646666306461363838366265616431333363323036333500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1511218365 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "30"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3432343500000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "2426"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[32,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "30"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3533346333636261646666306461363838366265616431333363323036333500"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[32,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x55412f393732380000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4592245", timeStamp: "1511235926", hash: "0xa6d52b091bf8b5664d36d240577266b92cc8573a2c4bbfe6527e127101646df0", nonce: "101", blockHash: "0x538f16bbe5657e3854710a30b672d9c3e48f56ffad9ad441a169baed538cd513", transactionIndex: "69", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6655412f39373238000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a156a44000000000000000000000000000000000000000000000000000000005a16143000000000000000000000000000000000000000000000000000000000000000016133623963386139386466646536313630313831373364313265383137393600", contractAddress: "", cumulativeGasUsed: "3490445", gasUsed: "805150", confirmations: "3148178"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x55412f3937323800000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32320000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511352900"}, {type: "uint256", name: "_arrivalTime", value: "1511396400"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x6133623963386139386466646536313630313831373364313265383137393600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x55412f3937323800000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32320000000000000000000000000000000000", "1511352900", "1511396400", "1", "0x6133623963386139386466646536313630313831373364313265383137393600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1511235926 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "31"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x55412f3937323800000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[33,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "31"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x6133623963386139386466646536313630313831373364313265383137393600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[33,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x53512f313334380000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4594082", timeStamp: "1511261405", hash: "0x2979d44fb492cd60c1a1e2f9f95c79c85bd78aa2c597b534bfd421a80507f7b7", nonce: "3", blockHash: "0xb29ee2d9b618817140893ae541edbbd1798f44299f4ae34bdaaa162100bfc15d", transactionIndex: "132", from: "0xe5759a0d285bb2d14b82111532cf1c660fe57481", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "50000000000000000", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6653512f31333438000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32390000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a1eca44000000000000000000000000000000000000000000000000000000005a1ee01000000000000000000000000000000000000000000000000000000000000000003533313632633039393336656539376262363039393664323835656331616600", contractAddress: "", cumulativeGasUsed: "4903927", gasUsed: "787037", confirmations: "3146341"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x53512f3133343800000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32390000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511967300"}, {type: "uint256", name: "_arrivalTime", value: "1511972880"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x3533313632633039393336656539376262363039393664323835656331616600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x53512f3133343800000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32390000000000000000000000000000000000", "1511967300", "1511972880", "0", "0x3533313632633039393336656539376262363039393664323835656331616600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1511261405 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "32"}, {name: "_customer", type: "address", value: "0xe5759a0d285bb2d14b82111532cf1c660fe57481"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x53512f3133343800000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "48510000000000000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[34,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "32"}, {name: "_address", type: "address", value: "0xe5759a0d285bb2d14b82111532cf1c660fe57481"}, {name: "_externalId", type: "bytes32", value: "0x3533313632633039393336656539376262363039393664323835656331616600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[34,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "735015905101329017" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4e482f373330310000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4594114", timeStamp: "1511261789", hash: "0x6833594e2e3a72c0c562893ccedff729d9fccba05a6b28c463e906f4452a7b96", nonce: "102", blockHash: "0xd41437688e41077bb3c82f18cb49c2be82a9888fb9c3e59b3b45c2332885cb7b", transactionIndex: "29", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664e482f37333031000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32390000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a1ec0e4000000000000000000000000000000000000000000000000000000005a1ed98000000000000000000000000000000000000000000000000000000000000000013533313632633039393336656539376262363039393664323835656331616600", contractAddress: "", cumulativeGasUsed: "2008312", gasUsed: "790150", confirmations: "3146309"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4e482f3733303100000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32390000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511964900"}, {type: "uint256", name: "_arrivalTime", value: "1511971200"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3533313632633039393336656539376262363039393664323835656331616600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4e482f3733303100000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32390000000000000000000000000000000000", "1511964900", "1511971200", "1", "0x3533313632633039393336656539376262363039393664323835656331616600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1511261789 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "33"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4e482f3733303100000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[35,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "33"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3533313632633039393336656539376262363039393664323835656331616600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[35,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x57532f353531370000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4602360", timeStamp: "1511377049", hash: "0x0fc7b0bd135dccf0ebd434e0d5b0afffaa61ec9d52fa78ed7e0780dad76be560", nonce: "103", blockHash: "0xe472da0f46464725f736898590d4a6608dbac2c01141ee68f102f05ac58bc10a", transactionIndex: "75", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "2000", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6657532f35353137000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a1c15b0000000000000000000000000000000000000000000000000000000005a1c2b7c00000000000000000000000000000000000000000000000000000000000000026531666263396538373032316662353461346237396638656533626139663000", contractAddress: "", cumulativeGasUsed: "2892463", gasUsed: "805150", confirmations: "3138063"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "2000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x57532f3535313700000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32370000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511790000"}, {type: "uint256", name: "_arrivalTime", value: "1511795580"}, {type: "uint8", name: "_currency", value: "2"}, {type: "bytes32", name: "_customerExternalId", value: "0x6531666263396538373032316662353461346237396638656533626139663000"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x57532f3535313700000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32370000000000000000000000000000000000", "1511790000", "1511795580", "2", "0x6531666263396538373032316662353461346237396638656533626139663000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1511377049 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "34"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x57532f3535313700000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1941"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[36,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "34"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x6531666263396538373032316662353461346237396638656533626139663000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[36,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x42412f373137000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4606374", timeStamp: "1511432402", hash: "0xf2e1e3ac60c57fb7065a66f998c6dc3b7e768be48a42c9455f7545384d658abf", nonce: "104", blockHash: "0x4e0caff61c6d8d05dd1cc9c38cab55bf67b4568c9191252021340f066491f3da", transactionIndex: "106", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "17325000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6642412f37313700000000000000000000000000000000000000000000000000002f6465702f323031372f31322f30350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a26bca4000000000000000000000000000000000000000000000000000000005a26d54000000000000000000000000000000000000000000000000000000000000000013835626434393436323238383139663665653063303433383038633665633300", contractAddress: "", cumulativeGasUsed: "5563544", gasUsed: "804143", confirmations: "3134049"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x42412f3731370000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31322f30350000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1512488100"}, {type: "uint256", name: "_arrivalTime", value: "1512494400"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3835626434393436323238383139663665653063303433383038633665633300"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x42412f3731370000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31322f30350000000000000000000000000000000000", "1512488100", "1512494400", "1", "0x3835626434393436323238383139663665653063303433383038633665633300", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1511432402 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "35"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x42412f3731370000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[37,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "35"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3835626434393436323238383139663665653063303433383038633665633300"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[37,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f333800000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4611924", timeStamp: "1511509523", hash: "0x0947ece69bee7324086e4c99612e5b5f4a7741330439f99dfef8f7aebe08c64b", nonce: "105", blockHash: "0xeb8827b92db1f48702b3a611b0bb262be81178ec54632fe4e090387a2bd2822b", transactionIndex: "70", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f33380000000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a195ec4000000000000000000000000000000000000000000000000000000005a1a08b000000000000000000000000000000000000000000000000000000000000000013036623263383466373537363863613739363761346564316133363530353000", contractAddress: "", cumulativeGasUsed: "3408136", gasUsed: "788136", confirmations: "3128499"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3338000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32350000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511612100"}, {type: "uint256", name: "_arrivalTime", value: "1511655600"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3036623263383466373537363863613739363761346564316133363530353000"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3338000000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32350000000000000000000000000000000000", "1511612100", "1511655600", "1", "0x3036623263383466373537363863613739363761346564316133363530353000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1511509523 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "36"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3338000000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[38,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "36"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3036623263383466373537363863613739363761346564316133363530353000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[38,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x55412f323536000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4611932", timeStamp: "1511509662", hash: "0x45e90f03614c48e4027dea762fbcd2fb23d936052db6719a022e2bd630ac87d7", nonce: "0", blockHash: "0x78be65e5f71a105f3224ccd5d59e106096e662be342de0f00b5230a3464061a5", transactionIndex: "50", from: "0x5509ce67333342e7758bf845a0897b51e062f502", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "50000000000000000", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6655412f32353600000000000000000000000000000000000000000000000000002f6465702f323031372f31322f30330000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a23ee48000000000000000000000000000000000000000000000000000000005a2414f400000000000000000000000000000000000000000000000000000000000000003136326133613537633164366531386461363035313166386262663765383600", contractAddress: "", cumulativeGasUsed: "2522601", gasUsed: "801030", confirmations: "3128491"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x55412f3235360000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31322f30330000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1512304200"}, {type: "uint256", name: "_arrivalTime", value: "1512314100"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x3136326133613537633164366531386461363035313166386262663765383600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x55412f3235360000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31322f30330000000000000000000000000000000000", "1512304200", "1512314100", "0", "0x3136326133613537633164366531386461363035313166386262663765383600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1511509662 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "37"}, {name: "_customer", type: "address", value: "0x5509ce67333342e7758bf845a0897b51e062f502"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x55412f3235360000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "48510000000000000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[39,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "37"}, {name: "_address", type: "address", value: "0x5509ce67333342e7758bf845a0897b51e062f502"}, {name: "_externalId", type: "bytes32", value: "0x3136326133613537633164366531386461363035313166386262663765383600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[39,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "234234449314903957" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x53512f333100000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4612020", timeStamp: "1511510983", hash: "0x7b8ecf16340ce78f6a8b9b221697850267ead46ee37373bc2f89a9a5e8caefd9", nonce: "28", blockHash: "0x32eb19877488941c65c737767e2477a8d6fb47c72354b317bf375ca850d0bc05", transactionIndex: "22", from: "0xfc15859aee77be7de9d6d45478b0265988e3c937", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "80000000000000000", gas: "1000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6653512f33310000000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a19a898000000000000000000000000000000000000000000000000000000005a1a9fdc00000000000000000000000000000000000000000000000000000000000000003762633264363330326632636533333838373937373530333563646464643900", contractAddress: "", cumulativeGasUsed: "1763895", gasUsed: "785023", confirmations: "3128403"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "80000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x53512f3331000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32350000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511631000"}, {type: "uint256", name: "_arrivalTime", value: "1511694300"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x3762633264363330326632636533333838373937373530333563646464643900"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x53512f3331000000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32350000000000000000000000000000000000", "1511631000", "1511694300", "0", "0x3762633264363330326632636533333838373937373530333563646464643900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1511510983 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "38"}, {name: "_customer", type: "address", value: "0xfc15859aee77be7de9d6d45478b0265988e3c937"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x53512f3331000000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "77616000000000000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[40,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "38"}, {name: "_address", type: "address", value: "0xfc15859aee77be7de9d6d45478b0265988e3c937"}, {name: "_externalId", type: "bytes32", value: "0x3762633264363330326632636533333838373937373530333563646464643900"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[40,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "270046619655573000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f333800000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4612907", timeStamp: "1511523826", hash: "0x7ee13ee1b3378d160cda0c36a42cff676d9552477b3d1f5abf0d3a0d65ae77a0", nonce: "106", blockHash: "0x2ff57c9429ae0b5a9ec00f23825db17d1baf86f47f721431506ba51368fc0bef", transactionIndex: "52", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f33380000000000000000000000000000000000000000000000000000002f6465702f323031372f31322f30340000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a253c44000000000000000000000000000000000000000000000000000000005a25e63000000000000000000000000000000000000000000000000000000000000000013661363033316266393933386465303833333931353462343730356233346100", contractAddress: "", cumulativeGasUsed: "2577724", gasUsed: "803136", confirmations: "3127516"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3338000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31322f30340000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1512389700"}, {type: "uint256", name: "_arrivalTime", value: "1512433200"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3661363033316266393933386465303833333931353462343730356233346100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3338000000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31322f30340000000000000000000000000000000000", "1512389700", "1512433200", "1", "0x3661363033316266393933386465303833333931353462343730356233346100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1511523826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "39"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3338000000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[41,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "39"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3661363033316266393933386465303833333931353462343730356233346100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[41,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x444c2f383030320000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4614231", timeStamp: "1511542431", hash: "0x0935e04d7ea0ecdc96cb304ee3d293530ea2ee48aee27f63739d9712b2fecb23", nonce: "107", blockHash: "0x8baf2590944651bec60ebf5eeceb7506ae098c4d67cd4fc34429eb1281b871e9", transactionIndex: "15", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb66444c2f38303032000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a1c299c000000000000000000000000000000000000000000000000000000005a1c6fec00000000000000000000000000000000000000000000000000000000000000013737346535636138643366373861386631393166353138306436396535366600", contractAddress: "", cumulativeGasUsed: "1370074", gasUsed: "805150", confirmations: "3126192"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x444c2f3830303200000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32370000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511795100"}, {type: "uint256", name: "_arrivalTime", value: "1511813100"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3737346535636138643366373861386631393166353138306436396535366600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x444c2f3830303200000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32370000000000000000000000000000000000", "1511795100", "1511813100", "1", "0x3737346535636138643366373861386631393166353138306436396535366600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1511542431 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "40"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x444c2f3830303200000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[42,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "40"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3737346535636138643366373861386631393166353138306436396535366600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[42,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4e5a2f393832320000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4614461", timeStamp: "1511545704", hash: "0xf1d75014c1dbb4dd30a611bcbfaf81c5a5f9234e4a913cb51c5b39c1e99e6375", nonce: "108", blockHash: "0x86eb80480ddb3b885651bb42992623a01d53bb97200fe577307c77fdced78199", transactionIndex: "48", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664e5a2f39383232000000000000000000000000000000000000000000000000002f6465702f323031372f31322f31300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a2d8fe8000000000000000000000000000000000000000000000000000000005a2dd50c00000000000000000000000000000000000000000000000000000000000000013331376466306164636536393534643961363466373464356166313633616600", contractAddress: "", cumulativeGasUsed: "3522216", gasUsed: "805150", confirmations: "3125962"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4e5a2f3938323200000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31322f31300000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1512935400"}, {type: "uint256", name: "_arrivalTime", value: "1512953100"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3331376466306164636536393534643961363466373464356166313633616600"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4e5a2f3938323200000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31322f31300000000000000000000000000000000000", "1512935400", "1512953100", "1", "0x3331376466306164636536393534643961363466373464356166313633616600", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1511545704 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "41"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4e5a2f3938323200000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[43,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "41"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3331376466306164636536393534643961363466373464356166313633616600"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[43,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c482f323336360000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4625561", timeStamp: "1511699800", hash: "0x276aeac9841513846c29d4654c4332f053b3ae2b2c36c68241f10b2422ba1560", nonce: "29", blockHash: "0x1c353311ecd0b5c2b312f434e0b83bc265922919e4455b5f3b9771fb49c98413", transactionIndex: "65", from: "0xfc15859aee77be7de9d6d45478b0265988e3c937", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "50000000000000000", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c482f32333636000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32380000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a1d0718000000000000000000000000000000000000000000000000000000005a1d152800000000000000000000000000000000000000000000000000000000000000003934366565643534396365376236323766316630333162363632623462366100", contractAddress: "", cumulativeGasUsed: "2308297", gasUsed: "772037", confirmations: "3114862"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c482f3233363600000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32380000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511851800"}, {type: "uint256", name: "_arrivalTime", value: "1511855400"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x3934366565643534396365376236323766316630333162363632623462366100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c482f3233363600000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32380000000000000000000000000000000000", "1511851800", "1511855400", "0", "0x3934366565643534396365376236323766316630333162363632623462366100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1511699800 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "42"}, {name: "_customer", type: "address", value: "0xfc15859aee77be7de9d6d45478b0265988e3c937"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c482f3233363600000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "48510000000000000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[44,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "42"}, {name: "_address", type: "address", value: "0xfc15859aee77be7de9d6d45478b0265988e3c937"}, {name: "_externalId", type: "bytes32", value: "0x3934366565643534396365376236323766316630333162363632623462366100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[44,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "270046619655573000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f333800000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4626140", timeStamp: "1511707902", hash: "0xc13022983303e021870accaa3508ba0c2bccf945dc01be70c3d1862b245a7aee", nonce: "109", blockHash: "0x71836d826e5955b9d6dd80694a90e4e232879e4f7a21c5334076bcc1f9115b85", transactionIndex: "83", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f33380000000000000000000000000000000000000000000000000000002f6465702f323031372f31312f32380000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a1d5344000000000000000000000000000000000000000000000000000000005a1dfd3000000000000000000000000000000000000000000000000000000000000000013739373837623139666434356132373865303965313034656132353635383000", contractAddress: "", cumulativeGasUsed: "3729126", gasUsed: "803136", confirmations: "3114283"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3338000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31312f32380000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1511871300"}, {type: "uint256", name: "_arrivalTime", value: "1511914800"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3739373837623139666434356132373865303965313034656132353635383000"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3338000000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31312f32380000000000000000000000000000000000", "1511871300", "1511914800", "1", "0x3739373837623139666434356132373865303965313034656132353635383000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1511707902 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "43"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3338000000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[45,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "43"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3739373837623139666434356132373865303965313034656132353635383000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[45,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x55412f313834380000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4633601", timeStamp: "1511813682", hash: "0x3d6c826b6634a9362b3a311af481718585714ed59cfd04d43e8a8bdf282dc0e9", nonce: "293", blockHash: "0x8af8ca4b7b8b2a9d16aef0a2282a576dadb5cefc75eadc1253aab82d2699b04d", transactionIndex: "15", from: "0x2718874048abccebe24693e689d31b011c6101ea", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "100000000000000000", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6655412f31383438000000000000000000000000000000000000000000000000002f6465702f323031372f31322f30340000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a253c44000000000000000000000000000000000000000000000000000000005a25995000000000000000000000000000000000000000000000000000000000000000006161643636643466363138636337613661396135346439393731633737363500", contractAddress: "", cumulativeGasUsed: "1283302", gasUsed: "802037", confirmations: "3106822"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x55412f3138343800000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31322f30340000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1512389700"}, {type: "uint256", name: "_arrivalTime", value: "1512413520"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x6161643636643466363138636337613661396135346439393731633737363500"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x55412f3138343800000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31322f30340000000000000000000000000000000000", "1512389700", "1512413520", "0", "0x6161643636643466363138636337613661396135346439393731633737363500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1511813682 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "44"}, {name: "_customer", type: "address", value: "0x2718874048abccebe24693e689d31b011c6101ea"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x55412f3138343800000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "97020000000000000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[46,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "44"}, {name: "_address", type: "address", value: "0x2718874048abccebe24693e689d31b011c6101ea"}, {name: "_externalId", type: "bytes32", value: "0x6161643636643466363138636337613661396135346439393731633737363500"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[46,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "5325302225075467854" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x41412f373035000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4639270", timeStamp: "1511894171", hash: "0xd33f58de847dfd9f7123cc6c59672bcf00cd66f1d56fca5c8b85040f6055d8be", nonce: "25", blockHash: "0xf1fedd95b23c3a3ca1002b47ccba30bb43ae8a0016db3663536ffe497d9d7e47", transactionIndex: "44", from: "0x618dbef763f8da7a851719058827e01c3f8524ad", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "80000000000000000", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb6641412f37303500000000000000000000000000000000000000000000000000002f6465702f323031372f31322f30320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a226f14000000000000000000000000000000000000000000000000000000005a2370a800000000000000000000000000000000000000000000000000000000000000003964393237663034646232616264343366636265306630353134643733663100", contractAddress: "", cumulativeGasUsed: "2147701", gasUsed: "771030", confirmations: "3101153"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "80000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x41412f3730350000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31322f30320000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1512206100"}, {type: "uint256", name: "_arrivalTime", value: "1512272040"}, {type: "uint8", name: "_currency", value: "0"}, {type: "bytes32", name: "_customerExternalId", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x41412f3730350000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31322f30320000000000000000000000000000000000", "1512206100", "1512272040", "0", "0x3964393237663034646232616264343366636265306630353134643733663100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1511894171 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "45"}, {name: "_customer", type: "address", value: "0x618dbef763f8da7a851719058827e01c3f8524ad"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x41412f3730350000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "77616000000000000"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[47,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "45"}, {name: "_address", type: "address", value: "0x618dbef763f8da7a851719058827e01c3f8524ad"}, {name: "_externalId", type: "bytes32", value: "0x3964393237663034646232616264343366636265306630353134643733663100"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[47,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "51037071577819234026" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f333800000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4644458", timeStamp: "1511966661", hash: "0xaf9c3690d075a4553a66dc942cd6add2b7457750e14411352e0e1b73b61a1e4c", nonce: "110", blockHash: "0x7873222ec41a0dcd1a2981b5f5172df451a926438ef6e0ed3945d637c4917ef7", transactionIndex: "89", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f33380000000000000000000000000000000000000000000000000000002f6465702f323031372f31322f30310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a2147c4000000000000000000000000000000000000000000000000000000005a21f1b000000000000000000000000000000000000000000000000000000000000000016132373361643762396331376330393237383237633239626533363136343700", contractAddress: "", cumulativeGasUsed: "3552890", gasUsed: "803136", confirmations: "3095965"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3338000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31322f30310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1512130500"}, {type: "uint256", name: "_arrivalTime", value: "1512174000"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x6132373361643762396331376330393237383237633239626533363136343700"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3338000000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31322f30310000000000000000000000000000000000", "1512130500", "1512174000", "1", "0x6132373361643762396331376330393237383237633239626533363136343700", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1511966661 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "46"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3338000000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[48,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "46"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x6132373361643762396331376330393237383237633239626533363136343700"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[48,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: newPolicy( \"0x4c582f333800000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4649561", timeStamp: "1512039238", hash: "0xf2db8b79bdc2b0f0cdc5dc37107eda68696af82e4486057ac2f492347ea03430", nonce: "111", blockHash: "0x294151694be595a076743a0c713e7b5589c0fb5fee933995596b5ede4016f2a9", transactionIndex: "76", from: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f", to: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59", value: "1500", gas: "1000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xfba2fb664c582f33380000000000000000000000000000000000000000000000000000002f6465702f323031372f31322f30310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a2147c4000000000000000000000000000000000000000000000000000000005a21f1b000000000000000000000000000000000000000000000000000000000000000013034343663653133333262643262623066363465343336623736313261313500", contractAddress: "", cumulativeGasUsed: "3340090", gasUsed: "728114", confirmations: "3090862"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_carrierFlightNumber", value: "0x4c582f3338000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_departureYearMonthDay", value: "0x2f6465702f323031372f31322f30310000000000000000000000000000000000"}, {type: "uint256", name: "_departureTime", value: "1512130500"}, {type: "uint256", name: "_arrivalTime", value: "1512174000"}, {type: "uint8", name: "_currency", value: "1"}, {type: "bytes32", name: "_customerExternalId", value: "0x3034343663653133333262643262623066363465343336623736313261313500"}], name: "newPolicy", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newPolicy(bytes32,bytes32,uint256,uint256,uint8,bytes32)" ]( "0x4c582f3338000000000000000000000000000000000000000000000000000000", "0x2f6465702f323031372f31322f30310000000000000000000000000000000000", "1512130500", "1512174000", "1", "0x3034343663653133333262643262623066363465343336623736313261313500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1512039238 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_customer", type: "address"}, {indexed: false, name: "strCarrierFlightNumber", type: "bytes32"}, {indexed: false, name: "ethPremium", type: "uint256"}], name: "LogPolicyApplied", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogPolicyApplied", events: [{name: "_policyId", type: "uint256", value: "47"}, {name: "_customer", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "strCarrierFlightNumber", type: "bytes32", value: "0x4c582f3338000000000000000000000000000000000000000000000000000000"}, {name: "ethPremium", type: "uint256", value: "1456"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_policyId", type: "uint256"}, {indexed: false, name: "_address", type: "address"}, {indexed: false, name: "_externalId", type: "bytes32"}], name: "LogExternal", type: "event"} ;
		console.error( "eventCallOriginal[49,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogExternal", events: [{name: "_policyId", type: "uint256", value: "47"}, {name: "_address", type: "address", value: "0xfee595b6b4a30bfa12604a5ec92156f1b5a1607f"}, {name: "_externalId", type: "bytes32", value: "0x3034343663653133333262643262623066363465343336623736313261313500"}], address: "0x5f9605823c32a09bfaeb7e744784705f4b7e2f59"}] ;
		console.error( "eventResultOriginal[49,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "179336394372551801" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
