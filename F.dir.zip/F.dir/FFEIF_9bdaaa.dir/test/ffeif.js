const FFEIF = artifacts.require( "./FFEIF.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "FFEIF" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x5C68Bb8B8b000c5d750E4D70427d8a99C49bdAaA", "0x0111E8A755a4212E6E1f13e75b1EABa8f837a213", "0xFfB8ccA6D55762dF595F21E78f21CD8DfeadF1C8", "0xd80e96496cd0B3F95bB4941b1385023fBCa1E6Ba", "0x7c76A64AC61D1eeaFE2B8AF6F7f0a6a1890418F3", "0x4eD4c6741e4b94931c3ecB8090306311c7e59833", "0x21db5ce96dF3b94A9dEF892B01F8a5a061630A9E", "0x8380d1c04705AF662EcE8A3eE5255E83bB2E35CA", "0xEc31176d4df0509115abC8065A8a3F8275aafF2b", "0xaB2aA003732Ba7afACB6565AA40c45001aAc48BD", "0xAeB7e6DA9a3a9eC23A8eE220ED4Ce3Bf1f2E16B3", "0x1ecC246891e1430F8Bf297547E02887D230c39B6", "0x14f225dD5D5cccc3045655EcBf4Df078D9ab454d", "0x22f2C722d8a71cC6521d5a7cfBE167B6F6706186", "0x41fa920F6547FaBd1DBdca960f0AF13A45018b2d", "0xa043EF9fCe771Eaa194f29A8Ff1d26682aE8E438", "0x531c2a3328555f0b77f48D79613fe545d329F076", "0x2F20Fc4493bD6aDab696EE89Ac0aB035727aA2e4"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "getBuyPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rndInc_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "viewMult", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "seedingDivisor", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "pIDxAddr_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "multLinear", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "multIncFactor_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "round_", outputs: [{name: "plyr", type: "uint256"}, {name: "team", type: "uint256"}, {name: "end", type: "uint256"}, {name: "ended", type: "bool"}, {name: "strt", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "eth", type: "uint256"}, {name: "pot", type: "uint256"}, {name: "mask", type: "uint256"}, {name: "ico", type: "uint256"}, {name: "icoGen", type: "uint256"}, {name: "icoAvg", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}], name: "plyrNames_", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "seedingThreshold", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rndIncDivisor_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "fees_", outputs: [{name: "gen", type: "uint256"}, {name: "poeif", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "pIDxName_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "seedDonated", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rndInit_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "viewPot", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxMult", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "seedRoundEnd", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "multPurchase", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "linearPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "fundEIF", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], name: "rndTmEth_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "divPotPercentage", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rID_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_pID", type: "uint256"}], name: "getPlayerVaults", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "multCurrent", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentRoundInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "address"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "FundEIF", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "winnerPercentage", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "multDecayPerMinute", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "multInc_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rndMax_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalEIF", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], name: "plyrRnds_", outputs: [{name: "eth", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "mask", type: "uint256"}, {name: "ico", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "potPercentage", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "PoEIFContract", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "potNextSeedTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rndGap_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "earlyRoundLimitUntil", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "multLastChange", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "potSplit_", outputs: [{name: "gen", type: "uint256"}, {name: "poeif", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getTimeLeft", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_rID", type: "uint256"}, {name: "_eth", type: "uint256"}], name: "calcKeysReceived", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_keys", type: "uint256"}], name: "iWantXKeys", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "multAllowLast", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "seedingPot", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "activated_", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "earlyRoundLimit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "affFee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "divPercentage", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "plyr_", outputs: [{name: "addr", type: "address"}, {name: "name", type: "bytes32"}, {name: "win", type: "uint256"}, {name: "gen", type: "uint256"}, {name: "aff", type: "uint256"}, {name: "lrnd", type: "uint256"}, {name: "laff", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "nextRoundPercentage", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "potSeedRate", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "multStart", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_addr", type: "address"}], name: "getPlayerInfoByAddress", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onWithdrawAndDistribute", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onBuyAndDistribute", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onReLoadAndDistribute", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["onNewName(uint256,address,bytes32,bool,uint256,address,bytes32,uint256,uint256)", "onEndTx(uint256,uint256,bytes32,address,uint256,uint256,address,bytes32,uint256,uint256,uint256,uint256,uint256,uint256)", "onWithdraw(uint256,address,bytes32,uint256,uint256)", "onWithdrawAndDistribute(address,bytes32,uint256,uint256,uint256,address,bytes32,uint256,uint256,uint256,uint256,uint256)", "onBuyAndDistribute(address,bytes32,uint256,uint256,uint256,address,bytes32,uint256,uint256,uint256,uint256,uint256)", "onReLoadAndDistribute(address,bytes32,uint256,uint256,address,bytes32,uint256,uint256,uint256,uint256,uint256)", "onAffiliatePayout(uint256,address,bytes32,uint256,uint256,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xdd6176433ff5026bbce96b068584b7bbe3514227e72df9c630b749ae87e64442", "0x500e72a0e114930aebdbcb371ccdbf43922c49f979794b5de4257ff7e310c746", "0x8f36579a548bc439baa172a6521207464154da77f411e2da3db2f53affe6cc3a", "0xefb2dfbd8ab72420b2aad8a56a6c8972c4ce68cf0578433a79c381c5480f0eeb", "0x241355367c01f7c5158917ef0c095f5a17f1eb5b0de1f3e09b91c09ddc04c653", "0x3fbd80671c8d24826e72afac55586328935f6aaba0619b3cea4a3b2f3812ac4b", "0x590bbc0fc16915a85269a48f74783c39842b7ae9eceb7c295c95dbe8b3ec7331"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6906154 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6909937 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "FFEIF", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "getBuyPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBuyPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rndInc_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rndInc_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "viewMult", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "viewMult()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "seedingDivisor", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "seedingDivisor()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "pIDxAddr_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pIDxAddr_(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multLinear", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multLinear()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multIncFactor_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multIncFactor_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "round_", outputs: [{name: "plyr", type: "uint256"}, {name: "team", type: "uint256"}, {name: "end", type: "uint256"}, {name: "ended", type: "bool"}, {name: "strt", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "eth", type: "uint256"}, {name: "pot", type: "uint256"}, {name: "mask", type: "uint256"}, {name: "ico", type: "uint256"}, {name: "icoGen", type: "uint256"}, {name: "icoAvg", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "round_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "plyrNames_", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyrNames_(uint256,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "seedingThreshold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "seedingThreshold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rndIncDivisor_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rndIncDivisor_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "fees_", outputs: [{name: "gen", type: "uint256"}, {name: "poeif", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fees_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "pIDxName_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pIDxName_(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "seedDonated", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "seedDonated()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rndInit_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rndInit_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "viewPot", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "viewPot()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxMult", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxMult()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "seedRoundEnd", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "seedRoundEnd()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multPurchase", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multPurchase()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "linearPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "linearPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "fundEIF", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fundEIF()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "rndTmEth_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rndTmEth_(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "divPotPercentage", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "divPotPercentage()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rID_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rID_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_pID", value: random.range( maxRandom )}], name: "getPlayerVaults", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerVaults(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multCurrent", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multCurrent()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentRoundInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "address"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentRoundInfo()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "FundEIF", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "FundEIF()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "winnerPercentage", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "winnerPercentage()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multDecayPerMinute", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multDecayPerMinute()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multInc_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multInc_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rndMax_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rndMax_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalEIF", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",33] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalEIF()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",33] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",34] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",34] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "plyrRnds_", outputs: [{name: "eth", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "mask", type: "uint256"}, {name: "ico", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",35] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyrRnds_(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",35] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "potPercentage", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",36] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "potPercentage()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",36] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "PoEIFContract", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",37] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "PoEIFContract()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",37] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "potNextSeedTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",38] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "potNextSeedTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",38] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rndGap_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",39] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rndGap_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",39] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "earlyRoundLimitUntil", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",40] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "earlyRoundLimitUntil()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",40] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multLastChange", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",41] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multLastChange()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",41] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "potSplit_", outputs: [{name: "gen", type: "uint256"}, {name: "poeif", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",42] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "potSplit_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",42] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getTimeLeft", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",43] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTimeLeft()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",43] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_rID", value: random.range( maxRandom )}, {type: "uint256", name: "_eth", value: random.range( maxRandom )}], name: "calcKeysReceived", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",44] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calcKeysReceived(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",44] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_keys", value: random.range( maxRandom )}], name: "iWantXKeys", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",45] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "iWantXKeys(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",45] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multAllowLast", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",46] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multAllowLast()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",46] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "seedingPot", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",47] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "seedingPot()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",47] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "activated_", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",48] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "activated_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",48] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "earlyRoundLimit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",49] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "earlyRoundLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",49] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "affFee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",50] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "affFee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",50] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "divPercentage", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",51] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "divPercentage()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",51] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "plyr_", outputs: [{name: "addr", type: "address"}, {name: "name", type: "bytes32"}, {name: "win", type: "uint256"}, {name: "gen", type: "uint256"}, {name: "aff", type: "uint256"}, {name: "lrnd", type: "uint256"}, {name: "laff", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",52] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyr_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",52] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "nextRoundPercentage", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",53] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nextRoundPercentage()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",53] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "potSeedRate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",54] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "potSeedRate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",54] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multStart", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",55] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multStart()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",55] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getPlayerInfoByAddress", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",56] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerInfoByAddress(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",56] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "FFEIF", function( accounts ) {

	it( "TEST: FFEIF(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6906154", timeStamp: "1545093582", hash: "0xa54711416c00383b629ba6b2e09b16f22c405dda1a094e60d0df90937039c9ad", nonce: "1428", blockHash: "0xe1829df050a401527b9efeba367be28f1ac445fa5265c0e8d3938628eb7bee67", transactionIndex: "7", from: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3", to: 0, value: "0", gas: "7109923", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x425b675d", contractAddress: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", cumulativeGasUsed: "7912883", gasUsed: "7109923", confirmations: "770057"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "FFEIF", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = FFEIF.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1545093582 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = FFEIF.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "181256836166982472488" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `MikeBinZ`, \"0x706c61790000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6906255", timeStamp: "1545095315", hash: "0x831937cac1fc3d42d3d5d67b17cd5be9dd0a5c009e971c0ec0e3d6dfa6d9fad0", nonce: "15", blockHash: "0x412e19be4367c774d98d745b9cb950f8c8c0dff03d0c016ce85ac34444235adb", transactionIndex: "118", from: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "10000000000000000", gas: "150000", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0x685ffd830000000000000000000000000000000000000000000000000000000000000060706c617900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000084d696b6542696e5a000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7866714", gasUsed: "148491", confirmations: "769956"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `MikeBinZ`}, {type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `MikeBinZ`, "0x706c617900000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1545095315 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "630679033587451" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `MikeBinZ`, \"0x706c61790000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6906298", timeStamp: "1545095961", hash: "0x59e518e12374aa0ad6d7832cc1d49a77bedea2eed43dd87b76209de9e9086f40", nonce: "16", blockHash: "0xa334bb37482e0042c1b86921c3834de70f95ac6017a6013a3a7f472d7dac323c", transactionIndex: "29", from: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "10000000000000000", gas: "500000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x685ffd830000000000000000000000000000000000000000000000000000000000000060706c617900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000084d696b6542696e5a000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3458898", gasUsed: "353996", confirmations: "769913"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `MikeBinZ`}, {type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `MikeBinZ`, "0x706c617900000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1545095961 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "2"}, {name: "playerAddress", type: "address", value: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833"}, {name: "playerName", type: "bytes32", value: "0x6d696b6562696e7a000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "affiliateName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1545095961"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "630679033587451" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: seedDeposit(  )", async function( ) {
		const txOriginal = {blockNumber: "6906354", timeStamp: "1545096743", hash: "0x33aa4b574d0d76ba6528728f938d362f2a7f11513fa0f61524500b77513c11bf", nonce: "1430", blockHash: "0xea1db8c6d5e5f89bbf1ba5a80fcbc1f583f5eeb5e43bb7bd127fbf5578f9eeed", transactionIndex: "2", from: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "3000000000000000000", gas: "94621", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x9237a125", contractAddress: "", cumulativeGasUsed: "105081", gasUsed: "63081", confirmations: "769857"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "3000000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "seedDeposit", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "seedDeposit()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1545096743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "181256836166982472488" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `playnow`, \"0x706c617900000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6906402", timeStamp: "1545097368", hash: "0x32cf0e497be308880dc65f95d55d48f8cf239219d932ed670483a1561ebae068", nonce: "957", blockHash: "0x62f2604282b6ceab737a546d449fffc9550ed79e587234930991441b3a5da2d8", transactionIndex: "14", from: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "10000000000000000", gas: "338745", gasPrice: "20500000000", isError: "1", txreceipt_status: "0", input: "0x685ffd830000000000000000000000000000000000000000000000000000000000000060706c61790000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000007706c61796e6f7700000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "708734", gasUsed: "332585", confirmations: "769809"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `playnow`}, {type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `playnow`, "0x706c617900000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1545097368 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "2214320000203570552" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `playnow`, \"0x706c617900000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6906409", timeStamp: "1545097421", hash: "0xe90a7f7e25de2789dea7b287410653a3e056bd38718709a540c3b4e89de77f70", nonce: "958", blockHash: "0x6f8125a3ee3cafcbac09a526457b1972d610347f717f01426e71c4f9bb6b3fc1", transactionIndex: "6", from: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "10000000000000000", gas: "600745", gasPrice: "20500000000", isError: "0", txreceipt_status: "1", input: "0x685ffd830000000000000000000000000000000000000000000000000000000000000060706c61790000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000007706c61796e6f7700000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "529830", gasUsed: "355085", confirmations: "769802"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `playnow`}, {type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `playnow`, "0x706c617900000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1545097421 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "3"}, {name: "playerAddress", type: "address", value: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e"}, {name: "playerName", type: "bytes32", value: "0x706c61796e6f7700000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "affiliateName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1545097421"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "2214320000203570552" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: activate(  )", async function( ) {
		const txOriginal = {blockNumber: "6906486", timeStamp: "1545098353", hash: "0xc885991f0a5b4d048f3da35de66833d7fe9f5c25980ef6836b9714610fb76ca4", nonce: "1431", blockHash: "0x89f8eaea4ef0a6fdc7933c113f026238b1cad12c1f65d951273b9664d3915f69", transactionIndex: "16", from: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "0", gas: "338389", gasPrice: "27000000000", isError: "0", txreceipt_status: "1", input: "0x0f15f4c0", contractAddress: "", cumulativeGasUsed: "769660", gasUsed: "225593", confirmations: "769725"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "activate", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activate()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1545098353 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "181256836166982472488" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6906488", timeStamp: "1545098372", hash: "0xb51834c01066e5c262ba8959388ba024f9ef4883cb2901308c36c0bd3977e545", nonce: "959", blockHash: "0x8bc761cca4e3ba97acdcc9e2623d50f229c26e369404c2c19d915c60e4b097f6", transactionIndex: "114", from: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "400000000000000000", gas: "3000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3815515", gasUsed: "37360", confirmations: "769723"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1545098372 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "2214320000203570552" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61796e6f770000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6906490", timeStamp: "1545098463", hash: "0x08f3e87608f3f3df03880ef9407a617fdb11ce8f1605c1c28fbc3bc4cc6cc946", nonce: "1432", blockHash: "0x209061bd1cd93e4b2c57e8b8c747adde9b191597536fb7ce694074821230e6f6", transactionIndex: "0", from: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "999999749999999900", gas: "3000000", gasPrice: "27000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c61796e6f7700000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "461263", gasUsed: "461263", confirmations: "769721"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "999999749999999900" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c61796e6f7700000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c61796e6f7700000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1545098463 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545098463000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000001"}, {name: "playerName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "ethIn", type: "uint256", value: "999999749999999900"}, {name: "keysBought", type: "uint256", value: "13333329999999998666666"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "99999974999999990"}, {name: "genAmount", type: "uint256", value: "649999837499999934"}, {name: "potAmount", type: "uint256", value: "99999974999999990"}, {name: "seedAdd", type: "uint256", value: "99999974999999990"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[8,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "3"}, {name: "affiliateAddress", type: "address", value: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e"}, {name: "affiliateName", type: "bytes32", value: "0x706c61796e6f7700000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "1"}, {name: "amount", type: "uint256", value: "49999987499999995"}, {name: "timeStamp", type: "uint256", value: "1545098463"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[8,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "181256836166982472488" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6906499", timeStamp: "1545098554", hash: "0xf4866d96bd9df38fdc3389dd427c6573506acc27101b0fc37a0473c1a2be80e3", nonce: "18", blockHash: "0x1861f150f2583e7ffdb0c02629d22515c01aef1f17648e5f1ceddee5fc0a52b1", transactionIndex: "66", from: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "100000000000000000", gas: "500000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xaeeed0db0000000000000000000000004ed4c6741e4b94931c3ecb8090306311c7e59833", contractAddress: "", cumulativeGasUsed: "4348972", gasUsed: "225078", confirmations: "769712"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[7]}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1545098554 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545098554000000000000000010"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000002"}, {name: "playerName", type: "bytes32", value: "0x6d696b6562696e7a000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833"}, {name: "ethIn", type: "uint256", value: "100000000000000000"}, {name: "keysBought", type: "uint256", value: "1333333333333333333334"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "10000000000000000"}, {name: "genAmount", type: "uint256", value: "64999999999988030"}, {name: "potAmount", type: "uint256", value: "10000000000000000"}, {name: "seedAdd", type: "uint256", value: "10000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[9,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "2"}, {name: "amount", type: "uint256", value: "5000000000000000"}, {name: "timeStamp", type: "uint256", value: "1545098554"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[9,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "630679033587451" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6906506", timeStamp: "1545098681", hash: "0xb7d6dfa451d69f074eb951800725dedce022ee005b556de8666112a034f6a98e", nonce: "960", blockHash: "0x1de0b87525372615f30e9f20137352c84a035114285e7bf56b34356bd6d82a60", transactionIndex: "45", from: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "0", gas: "2000000", gasPrice: "19800000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2096866", gasUsed: "26067", confirmations: "769705"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1545098681 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[10,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "3"}, {name: "playerAddress", type: "address", value: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e"}, {name: "playerName", type: "bytes32", value: "0x706c61796e6f7700000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "449999987499999995"}, {name: "timeStamp", type: "uint256", value: "1545098681"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[10,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "2214320000203570552" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6906512", timeStamp: "1545098782", hash: "0x9b2128fe23fb523d18a5f034087db32b931e3503c09744d881a466805a89cf0b", nonce: "961", blockHash: "0xb7f294ed86d13e0a09b930651fed4cfa73aeee96c59e3550c15f07ad612823aa", transactionIndex: "27", from: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "400000000000000000", gas: "3000000", gasPrice: "16300000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1308816", gasUsed: "245703", confirmations: "769699"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1545098782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545098782000000000000000110"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000003"}, {name: "playerName", type: "bytes32", value: "0x706c61796e6f7700000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e"}, {name: "ethIn", type: "uint256", value: "400000000000000000"}, {name: "keysBought", type: "uint256", value: "5333333333333333333333"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "40000000000000000"}, {name: "genAmount", type: "uint256", value: "259999999999999427"}, {name: "potAmount", type: "uint256", value: "40000000000000000"}, {name: "seedAdd", type: "uint256", value: "40000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[11,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "3"}, {name: "amount", type: "uint256", value: "20000000000000000"}, {name: "timeStamp", type: "uint256", value: "1545098782"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[11,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "2214320000203570552" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6906540", timeStamp: "1545099215", hash: "0xcb2610d9e9237f1abf2eb1a11817f4d49fb43a18bac8534f58bc6315c4f767af", nonce: "19", blockHash: "0xe50ad6725eb00399e7e28870f14f385d4a804e37fb7ce516a387385a1a7baa70", transactionIndex: "144", from: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "75000000000000", gas: "210000", gasPrice: "4590837830", isError: "0", txreceipt_status: "1", input: "0xaeeed0db0000000000000000000000004ed4c6741e4b94931c3ecb8090306311c7e59833", contractAddress: "", cumulativeGasUsed: "4868994", gasUsed: "144123", confirmations: "769671"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "75000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[7]}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1545099215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545099215000000000000000000"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000002"}, {name: "playerName", type: "bytes32", value: "0x6d696b6562696e7a000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833"}, {name: "ethIn", type: "uint256", value: "75000000000000"}, {name: "keysBought", type: "uint256", value: "1000000000000000000"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "7500000000000"}, {name: "genAmount", type: "uint256", value: "48749999993941"}, {name: "potAmount", type: "uint256", value: "7500000000000"}, {name: "seedAdd", type: "uint256", value: "7500000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[12,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "2"}, {name: "amount", type: "uint256", value: "3750000000000"}, {name: "timeStamp", type: "uint256", value: "1545099215"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[12,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "630679033587451" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6906590", timeStamp: "1545100042", hash: "0xe91453e163f3a18bd1e5b409c5822c05b8e9bf0f376a3acaba7442401d4a0e50", nonce: "962", blockHash: "0xf96a0fc812ca354fbd72ac9f1841b9f1c3bee08e48a40b6b435331b72ca29218", transactionIndex: "57", from: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "500000000000000000", gas: "3000000", gasPrice: "27000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1862375", gasUsed: "154592", confirmations: "769621"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1545100042 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545100042000000000000000100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000003"}, {name: "playerName", type: "bytes32", value: "0x706c61796e6f7700000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e"}, {name: "ethIn", type: "uint256", value: "500000000000000000"}, {name: "keysBought", type: "uint256", value: "6666666666666666666667"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "50000000000000000"}, {name: "genAmount", type: "uint256", value: "324999999999987497"}, {name: "potAmount", type: "uint256", value: "50000000000000000"}, {name: "seedAdd", type: "uint256", value: "50000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[13,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "3"}, {name: "amount", type: "uint256", value: "25000000000000000"}, {name: "timeStamp", type: "uint256", value: "1545100042"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[13,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "2214320000203570552" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x6d696b6562696e7a00000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6906675", timeStamp: "1545101378", hash: "0xa5f21336efafe25ce4384622f55c36de78983e3c5f3d8689a46771e8ddf942a5", nonce: "20", blockHash: "0xdb90a0d66c3a26b70498d964555fc883f4be5a99da9dfaf44b1ed17b81d17da3", transactionIndex: "241", from: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "9999750000000000", gas: "200000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e6d696b6562696e7a000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7838053", gasUsed: "142743", confirmations: "769536"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "9999750000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x6d696b6562696e7a000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x6d696b6562696e7a000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1545101378 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545101378000000000000000000"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000002"}, {name: "playerName", type: "bytes32", value: "0x6d696b6562696e7a000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833"}, {name: "ethIn", type: "uint256", value: "9999750000000000"}, {name: "keysBought", type: "uint256", value: "133330000000000000000"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "999975000000000"}, {name: "genAmount", type: "uint256", value: "6499837499977916"}, {name: "potAmount", type: "uint256", value: "999975000000000"}, {name: "seedAdd", type: "uint256", value: "999975000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[14,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "2"}, {name: "amount", type: "uint256", value: "499987500000000"}, {name: "timeStamp", type: "uint256", value: "1545101378"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[14,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "630679033587451" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6906689", timeStamp: "1545101620", hash: "0x297d0343f61f2f5a86c6dd8dc9f8c2daa0ec07a58ea60e48223f4962a3ef96f9", nonce: "963", blockHash: "0xc59ab347b9c51826ef278f930670e4f6651a716df2e7296228aa4479cbe2da47", transactionIndex: "33", from: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "80000000000000000", gas: "3000000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1315443", gasUsed: "154592", confirmations: "769522"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "80000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1545101620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545101620000000000000000100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000003"}, {name: "playerName", type: "bytes32", value: "0x706c61796e6f7700000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e"}, {name: "ethIn", type: "uint256", value: "80000000000000000"}, {name: "keysBought", type: "uint256", value: "1066666666666666666666"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "8000000000000000"}, {name: "genAmount", type: "uint256", value: "51999999999983539"}, {name: "potAmount", type: "uint256", value: "8000000000000000"}, {name: "seedAdd", type: "uint256", value: "8000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[15,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "3"}, {name: "amount", type: "uint256", value: "4000000000000000"}, {name: "timeStamp", type: "uint256", value: "1545101620"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[15,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "2214320000203570552" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6906693", timeStamp: "1545101713", hash: "0x796d685d9ab5008c59f8cd1b6de5065d79b5523121499eace7dcc8f33bfcd07c", nonce: "964", blockHash: "0x29d9034526d5f49b35cb248478f9d2313a0899864d241cd668761bf005634f40", transactionIndex: "85", from: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "0", gas: "2000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "5231599", gasUsed: "63187", confirmations: "769518"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1545101713 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "3"}, {name: "playerAddress", type: "address", value: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e"}, {name: "playerName", type: "bytes32", value: "0x706c61796e6f7700000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "242883051487321334"}, {name: "timeStamp", type: "uint256", value: "1545101713"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "2214320000203570552" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6906784", timeStamp: "1545103243", hash: "0x1b7ac4ca50ff61194130bf023ad0089725b2f96e4bb0a544443ec32d5ff850fe", nonce: "21", blockHash: "0x9a6f6e5ad0b5849efec8599d48d576428632247ace2ce608c78be5396cd9a89a", transactionIndex: "33", from: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "300839999999999940", gas: "150000", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xaeeed0db0000000000000000000000004ed4c6741e4b94931c3ecb8090306311c7e59833", contractAddress: "", cumulativeGasUsed: "7138071", gasUsed: "150000", confirmations: "769427"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "300839999999999940" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[7]}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "630679033587451" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6906791", timeStamp: "1545103417", hash: "0xc39fce9df64a400c8a05e674f1d89266feda5a11e9abd693a3e1fcbe1557eca4", nonce: "22", blockHash: "0x903d46fd517ed02634c531d48fe7756130be24656f6aae90e67cdda0c1d63f98", transactionIndex: "65", from: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "258472500000000000", gas: "210000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xaeeed0db0000000000000000000000004ed4c6741e4b94931c3ecb8090306311c7e59833", contractAddress: "", cumulativeGasUsed: "3556485", gasUsed: "178457", confirmations: "769420"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "258472500000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[7]}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1545103417 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545103417000000000000000100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000002"}, {name: "playerName", type: "bytes32", value: "0x6d696b6562696e7a000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833"}, {name: "ethIn", type: "uint256", value: "258472500000000000"}, {name: "keysBought", type: "uint256", value: "3446300000000000000000"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "25847250000000000"}, {name: "genAmount", type: "uint256", value: "168007124999981975"}, {name: "potAmount", type: "uint256", value: "25847250000000000"}, {name: "seedAdd", type: "uint256", value: "25847250000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[18,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "2"}, {name: "amount", type: "uint256", value: "12923625000000000"}, {name: "timeStamp", type: "uint256", value: "1545103417"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[18,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "630679033587451" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6906810", timeStamp: "1545103703", hash: "0x6b64fc60b31ec0441ed61637826b028ca5da206ab1aa0dc677c3d40d8ddeae27", nonce: "2053", blockHash: "0x58771ba24d2bfe6871a81ccebba6815f2ac6bc91b6537550b454d2ea45e81b24", transactionIndex: "62", from: "0x8380d1c04705af662ece8a3ee5255e83bb2e35ca", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "100000000000000000", gas: "3000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3218666", gasUsed: "324547", confirmations: "769401"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1545103703 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545103703000000000000000011"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000004"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x8380d1c04705af662ece8a3ee5255e83bb2e35ca"}, {name: "ethIn", type: "uint256", value: "100000000000000000"}, {name: "keysBought", type: "uint256", value: "1333333333333333333334"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "10000000000000000"}, {name: "genAmount", type: "uint256", value: "64999999999976579"}, {name: "potAmount", type: "uint256", value: "10000000000000000"}, {name: "seedAdd", type: "uint256", value: "10000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[19,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "4"}, {name: "amount", type: "uint256", value: "5000000000000000"}, {name: "timeStamp", type: "uint256", value: "1545103703"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[19,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "13054001351371648" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `gosu`, \"0x6d696b6562696e7a000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6906926", timeStamp: "1545105178", hash: "0x8114d220280cd9dc5a71fd2ae3ff545aa8e614051951d80aacb44ee240304100", nonce: "503", blockHash: "0xca5bc62c40820e6b9a3d9a8c3d2d72346efc960a1cd50b638af1b9e3a363c67b", transactionIndex: "52", from: "0xec31176d4df0509115abc8065a8a3f8275aaff2b", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "10000000000000000", gas: "338745", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0x685ffd8300000000000000000000000000000000000000000000000000000000000000606d696b6562696e7a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000004676f737500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3570375", gasUsed: "332393", confirmations: "769285"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `gosu`}, {type: "bytes32", name: "_affCode", value: "0x6d696b6562696e7a000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `gosu`, "0x6d696b6562696e7a000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1545105178 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "19128331344357305771" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x676f73750000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6906966", timeStamp: "1545105682", hash: "0x812df1f3cc72519709a8f3677dfaece4b833b42162be65cce5423de9cfc2b273", nonce: "504", blockHash: "0x1cce0803b4bcc24356aa82b6add6a1993c4c8f3119f4ab19a4c433b8dbd11479", transactionIndex: "81", from: "0xec31176d4df0509115abc8065a8a3f8275aaff2b", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "40409999999999990", gas: "3000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e676f737500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3429240", gasUsed: "329841", confirmations: "769245"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "40409999999999990" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x676f737500000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x676f737500000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1545105682 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545105682000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000005"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xec31176d4df0509115abc8065a8a3f8275aaff2b"}, {name: "ethIn", type: "uint256", value: "40409999999999990"}, {name: "keysBought", type: "uint256", value: "538799999999999866666"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "6061499999999998"}, {name: "genAmount", type: "uint256", value: "26266499999986610"}, {name: "potAmount", type: "uint256", value: "4041000000000000"}, {name: "seedAdd", type: "uint256", value: "4040999999999999"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "19128331344357305771" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: setStore( `earlyRoundLimit`, \"1000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6907130", timeStamp: "1545108085", hash: "0xe8028162d55499c6c81ebb19d2aa1f319781be90d43e68f7c540320f33c39320", nonce: "1434", blockHash: "0x3056daaff46056159d0ca79c518df873074111c563bbe8a0f358e153fc1a583d", transactionIndex: "61", from: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "0", gas: "193956", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x8f8d49ac00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000056bc75e2d63100000000000000000000000000000000000000000000000000000000000000000000f6561726c79526f756e644c696d69740000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2230135", gasUsed: "129304", confirmations: "769081"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_variable", value: `earlyRoundLimit`}, {type: "uint256", name: "_value", value: "100000000000000000000"}], name: "setStore", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setStore(string,uint256)" ]( `earlyRoundLimit`, "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1545108085 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "181256836166982472488" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: payFund(  )", async function( ) {
		const txOriginal = {blockNumber: "6907137", timeStamp: "1545108176", hash: "0x02841d5498cbb4e83e69f3ce3b2c5b98cc05de0b582cbe0d1d5f6f3b051811d3", nonce: "1435", blockHash: "0xa5e8f2a4454fa9217ea474feab2dc7f41e90be985bef33eff59f98292b44a404", transactionIndex: "42", from: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "0", gas: "147900", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x8974372d", contractAddress: "", cumulativeGasUsed: "1692439", gasUsed: "83600", confirmations: "769074"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "payFund", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "payFund()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1545108176 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "181256836166982472488" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6907276", timeStamp: "1545110064", hash: "0x44e60dfc3b603f15a395357745837dd2a7a1b8fe2ab4c58155f4b8464acafa38", nonce: "965", blockHash: "0x5607579ea65cf0f722c674e71805d713393b8de7620e476d8723431ece3cc255", transactionIndex: "29", from: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "110000250000000000", gas: "3000000", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1281843", gasUsed: "196372", confirmations: "768935"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "110000250000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1545110064 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545110064000000000000000000"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000003"}, {name: "playerName", type: "bytes32", value: "0x706c61796e6f7700000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e"}, {name: "ethIn", type: "uint256", value: "20000000000000000"}, {name: "keysBought", type: "uint256", value: "266666666666666666667"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "2000000000000000"}, {name: "genAmount", type: "uint256", value: "12999999999982161"}, {name: "potAmount", type: "uint256", value: "2000000000000000"}, {name: "seedAdd", type: "uint256", value: "2000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[24,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "3"}, {name: "amount", type: "uint256", value: "1000000000000000"}, {name: "timeStamp", type: "uint256", value: "1545110064"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[24,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "2214320000203570552" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6907430", timeStamp: "1545112512", hash: "0x6cc987cec9ac70c9aa0558e98828ce0325db951c9ad9b1fccac6716ce8939da5", nonce: "1439", blockHash: "0x92aa7e97ba6ec9abbb52e4d42581685c61dab34c0dfbcbc56bdc3bdcc8a9b69d", transactionIndex: "58", from: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "0", gas: "2000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "1645114", gasUsed: "63187", confirmations: "768781"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1545112512 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "1"}, {name: "playerAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "playerName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "1260308533795752877"}, {name: "timeStamp", type: "uint256", value: "1545112512"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "181256836166982472488" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6907441", timeStamp: "1545112676", hash: "0x91b5e6c68d6287e1495a2162b21aa3700c89cccdb4763714a75013d787dcf05f", nonce: "1440", blockHash: "0x3af75551f09ef16d54ac0a224f56740d10cdb98d28a585824204358c49e91305", transactionIndex: "114", from: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "0", gas: "2000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "5043239", gasUsed: "29240", confirmations: "768770"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1545112676 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "1"}, {name: "playerAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "playerName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "0"}, {name: "timeStamp", type: "uint256", value: "1545112676"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "181256836166982472488" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6907509", timeStamp: "1545113563", hash: "0x1c3efe6d6a400b2bbbc8f76b9d58836fc7a5c3c6aa746eec6f12359f2fc054ac", nonce: "1441", blockHash: "0xb7b545944457bb7b750d4cc1ac6111ff75eb70055f8cc0776bb9080aec9cb83b", transactionIndex: "33", from: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "0", gas: "2000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "1412263", gasUsed: "46684", confirmations: "768702"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1545113563 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[27,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "1"}, {name: "playerAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "playerName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "0"}, {name: "timeStamp", type: "uint256", value: "1545113563"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[27,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "181256836166982472488" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6907894", timeStamp: "1545119394", hash: "0x08c774a381fe4becc306cd5a6d3f234417d70d12b33b60501da85c5bd975242b", nonce: "1442", blockHash: "0x36a90abc6194737677fb0bcc5f27013d75c42291632cbbc5bba158f9cdde7a60", transactionIndex: "52", from: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "0", gas: "2000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "1730632", gasUsed: "46684", confirmations: "768317"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1545119394 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "1"}, {name: "playerAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "playerName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "0"}, {name: "timeStamp", type: "uint256", value: "1545119394"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "181256836166982472488" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6908268", timeStamp: "1545125133", hash: "0xedd39cde55755fd48fe231723c68fdd093acd2e6b627f0eebf286d12314878d3", nonce: "966", blockHash: "0x5f6fea062b8507d0994e317b18a71bc6222eed802d08207e20cb8317b92eb7c2", transactionIndex: "45", from: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "0", gas: "2000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "1610215", gasUsed: "83075", confirmations: "767943"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1545125133 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "3"}, {name: "playerAddress", type: "address", value: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e"}, {name: "playerName", type: "bytes32", value: "0x706c61796e6f7700000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "201645158112802666"}, {name: "timeStamp", type: "uint256", value: "1545125133"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "2214320000203570552" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6908282", timeStamp: "1545125377", hash: "0x216b33be1d198f059340496d2c5c622fb9afa5e1172a15a90cf06252fc0676b7", nonce: "27", blockHash: "0x4b70733e7db57e89ad8beaf7f04086bac62919e0f8baacf82c8e8c820e546e9c", transactionIndex: "42", from: "0xab2aa003732ba7afacb6565aa40c45001aac48bd", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "390000000000000", gas: "3000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2844709", gasUsed: "351231", confirmations: "767929"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "390000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1545125377 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545125377000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000006"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xab2aa003732ba7afacb6565aa40c45001aac48bd"}, {name: "ethIn", type: "uint256", value: "390000000000000"}, {name: "keysBought", type: "uint256", value: "5200000000000000000"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "39000000000000"}, {name: "genAmount", type: "uint256", value: "253499999984452"}, {name: "potAmount", type: "uint256", value: "39000000000000"}, {name: "seedAdd", type: "uint256", value: "39000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[30,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "6"}, {name: "amount", type: "uint256", value: "19500000000000"}, {name: "timeStamp", type: "uint256", value: "1545125377"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[30,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "468384877382297" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6908419", timeStamp: "1545127362", hash: "0xf52b5f398dc022370d3ecae2768dc2f69d0f725fbbb8b9f8ef470cd0478b5306", nonce: "2", blockHash: "0xe568f05a1889517c715a577019b41bae9f7cfc29dd68c54702d712604a518924", transactionIndex: "31", from: "0xaeb7e6da9a3a9ec23a8ee220ed4ce3bf1f2e16b3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "50000000000000000", gas: "3000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1399649", gasUsed: "358681", confirmations: "767792"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1545127362 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545127362000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000007"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xaeb7e6da9a3a9ec23a8ee220ed4ce3bf1f2e16b3"}, {name: "ethIn", type: "uint256", value: "50000000000000000"}, {name: "keysBought", type: "uint256", value: "666666666666666666667"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "5000000000000000"}, {name: "genAmount", type: "uint256", value: "32499999999987687"}, {name: "potAmount", type: "uint256", value: "5000000000000000"}, {name: "seedAdd", type: "uint256", value: "5000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[31,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "7"}, {name: "amount", type: "uint256", value: "2500000000000000"}, {name: "timeStamp", type: "uint256", value: "1545127362"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[31,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "2201305098838814" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6908429", timeStamp: "1545127472", hash: "0xded927e7d05a571617a6605f11d0aa6199bb4cb007c9b64b0c002da4ad9067c8", nonce: "3", blockHash: "0x91110e76e95a45097d2903c4f630331b9363fc85363508f29837bb1c7248fe9e", transactionIndex: "20", from: "0xaeb7e6da9a3a9ec23a8ee220ed4ce3bf1f2e16b3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "50024999999999990", gas: "3000000", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "819657", gasUsed: "154592", confirmations: "767782"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50024999999999990" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1545127472 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545127472000000000000000100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000007"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xaeb7e6da9a3a9ec23a8ee220ed4ce3bf1f2e16b3"}, {name: "ethIn", type: "uint256", value: "50024999999999990"}, {name: "keysBought", type: "uint256", value: "666999999999999866666"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "5002499999999999"}, {name: "genAmount", type: "uint256", value: "32516249999991380"}, {name: "potAmount", type: "uint256", value: "5002500000000000"}, {name: "seedAdd", type: "uint256", value: "5002499999999999"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[32,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "7"}, {name: "amount", type: "uint256", value: "2501249999999999"}, {name: "timeStamp", type: "uint256", value: "1545127472"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[32,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "2201305098838814" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6908434", timeStamp: "1545127547", hash: "0x332c9704d7269e34cf29b9109afa01e2df21d065f62cd4188590ce648636f021", nonce: "4", blockHash: "0x544e696e46e7afcaab018641b30c2a18c8f499fadf422a47ed2926caaf07cb41", transactionIndex: "44", from: "0xaeb7e6da9a3a9ec23a8ee220ed4ce3bf1f2e16b3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "50000249999999990", gas: "3000000", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1662839", gasUsed: "142777", confirmations: "767777"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "50000249999999990" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1545127547 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545127547000000000000000000"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000007"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xaeb7e6da9a3a9ec23a8ee220ed4ce3bf1f2e16b3"}, {name: "ethIn", type: "uint256", value: "50000249999999990"}, {name: "keysBought", type: "uint256", value: "666669999999999866667"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "5000024999999999"}, {name: "genAmount", type: "uint256", value: "32500162499989477"}, {name: "potAmount", type: "uint256", value: "5000025000000000"}, {name: "seedAdd", type: "uint256", value: "5000024999999999"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[33,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "7"}, {name: "amount", type: "uint256", value: "2500012499999999"}, {name: "timeStamp", type: "uint256", value: "1545127547"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[33,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "2201305098838814" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6908679", timeStamp: "1545131118", hash: "0x234cee153647fad01bbe41d5f0a0e9204190f46ddf01c46fc0eb1e57d74ce81a", nonce: "629", blockHash: "0x48f5d085ea719ddf31aa6cbcea9793321ce61b833ad194de408a93804f8adf0f", transactionIndex: "49", from: "0x1ecc246891e1430f8bf297547e02887d230c39b6", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "10000000000000000", gas: "3000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4480643", gasUsed: "341991", confirmations: "767532"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1545131118 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545131118000000000000000011"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000008"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x1ecc246891e1430f8bf297547e02887d230c39b6"}, {name: "ethIn", type: "uint256", value: "10000000000000000"}, {name: "keysBought", type: "uint256", value: "133333333333333333333"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "1000000000000000"}, {name: "genAmount", type: "uint256", value: "6499999999978188"}, {name: "potAmount", type: "uint256", value: "1000000000000000"}, {name: "seedAdd", type: "uint256", value: "1000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[34,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "8"}, {name: "amount", type: "uint256", value: "500000000000000"}, {name: "timeStamp", type: "uint256", value: "1545131118"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[34,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "51757311428300529" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6908798", timeStamp: "1545133012", hash: "0xe65b70d8a29630a5121eb407e573fffc51c8e4ede5293836e4366084f452abef", nonce: "1443", blockHash: "0xb99387f14667a60c46d86e88c0092c3f46e91308c5ee9a5c81667dd072348436", transactionIndex: "82", from: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "0", gas: "2000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2047267", gasUsed: "48187", confirmations: "767413"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1545133012 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdraw", events: [{name: "playerID", type: "uint256", value: "1"}, {name: "playerAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "playerName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "47937677878515321"}, {name: "timeStamp", type: "uint256", value: "1545133012"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "181256836166982472488" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6908861", timeStamp: "1545133893", hash: "0x9499b494f835a2274d14d287c2e247f390095945ec8a00a5bad09b42cde167ca", nonce: "143", blockHash: "0xed5786bffda1981faff0020b65d39d37934c061ecf471127e9c1b2b0c5f10b68", transactionIndex: "198", from: "0x14f225dd5d5cccc3045655ecbf4df078d9ab454d", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "75000000000000", gas: "200000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0xaeeed0db0000000000000000000000004ed4c6741e4b94931c3ecb8090306311c7e59833", contractAddress: "", cumulativeGasUsed: "5446155", gasUsed: "200000", confirmations: "767350"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "75000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[7]}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "42843690000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6908871", timeStamp: "1545134029", hash: "0xdf43e6926ce9f7c13fa50405ab2d35ccb4b2f5ed3fcfd5b1b0fc4f9d8b3c74f4", nonce: "23", blockHash: "0x13e2003a3297ad143c33727ec7497541a4c3b5b78f9f3deb28d5b8b26eca8f97", transactionIndex: "92", from: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "75000000000000", gas: "3000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xaeeed0db0000000000000000000000004ed4c6741e4b94931c3ecb8090306311c7e59833", contractAddress: "", cumulativeGasUsed: "3745394", gasUsed: "159123", confirmations: "767340"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "75000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[7]}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1545134029 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545134029000000000000000000"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000002"}, {name: "playerName", type: "bytes32", value: "0x6d696b6562696e7a000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833"}, {name: "ethIn", type: "uint256", value: "75000000000000"}, {name: "keysBought", type: "uint256", value: "1000000000000000000"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "7500000000000"}, {name: "genAmount", type: "uint256", value: "48749999999119"}, {name: "potAmount", type: "uint256", value: "7500000000000"}, {name: "seedAdd", type: "uint256", value: "7500000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[37,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "2"}, {name: "amount", type: "uint256", value: "3750000000000"}, {name: "timeStamp", type: "uint256", value: "1545134029"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[37,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "630679033587451" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buyXaddr( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6908881", timeStamp: "1545134189", hash: "0xbc5c35228606593a15e5d1a6d350231f7e5f7fccbc0244b5cb42b7efd28ccb88", nonce: "144", blockHash: "0xb5bc0d8aa4455a125668cd03f09f471fd4a07c68ad28e04bc7fd7dcd209ee042", transactionIndex: "62", from: "0x14f225dd5d5cccc3045655ecbf4df078d9ab454d", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "75000000000000", gas: "3000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xaeeed0db0000000000000000000000004ed4c6741e4b94931c3ecb8090306311c7e59833", contractAddress: "", cumulativeGasUsed: "3793637", gasUsed: "341260", confirmations: "767330"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "75000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_affCode", value: addressList[7]}], name: "buyXaddr", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXaddr(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1545134189 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545134189000000000000000011"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000009"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x14f225dd5d5cccc3045655ecbf4df078d9ab454d"}, {name: "ethIn", type: "uint256", value: "75000000000000"}, {name: "keysBought", type: "uint256", value: "1000000000000000000"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "7500000000000"}, {name: "genAmount", type: "uint256", value: "48749999986217"}, {name: "potAmount", type: "uint256", value: "7500000000000"}, {name: "seedAdd", type: "uint256", value: "7500000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[38,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "2"}, {name: "affiliateAddress", type: "address", value: "0x4ed4c6741e4b94931c3ecb8090306311c7e59833"}, {name: "affiliateName", type: "bytes32", value: "0x6d696b6562696e7a000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "9"}, {name: "amount", type: "uint256", value: "3750000000000"}, {name: "timeStamp", type: "uint256", value: "1545134189"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[38,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "42843690000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXname( `happyhourglass`, \"0x706c61793b20756e69... )", async function( ) {
		const txOriginal = {blockNumber: "6908998", timeStamp: "1545135965", hash: "0x12b51e0a58ade1ea18bc984abcc1137a900ed044767a11b4d7e014e37ff5cb2d", nonce: "70", blockHash: "0x37599d433a9f860ce456671b966e6ceb4bbdfbc9a5b1cd2e893a25a0a3b6d95f", transactionIndex: "53", from: "0x22f2c722d8a71cc6521d5a7cfbe167b6f6706186", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "10000000000000000", gas: "338745", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x685ffd830000000000000000000000000000000000000000000000000000000000000060706c61793b20756e695f72656665727265723d706c61790000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000e6861707079686f7572676c617373000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6033760", gasUsed: "331105", confirmations: "767213"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `happyhourglass`}, {type: "bytes32", name: "_affCode", value: "0x706c61793b20756e695f72656665727265723d706c6179000000000000000000"}, {type: "bool", name: "_all", value: true}], name: "registerNameXname", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXname(string,bytes32,bool)" ]( `happyhourglass`, "0x706c61793b20756e695f72656665727265723d706c6179000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1545135965 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewName", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onNewName", events: [{name: "playerID", type: "uint256", value: "10"}, {name: "playerAddress", type: "address", value: "0x22f2c722d8a71cc6521d5a7cfbe167b6f6706186"}, {name: "playerName", type: "bytes32", value: "0x6861707079686f7572676c617373000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "affiliateID", type: "uint256", value: "0"}, {name: "affiliateAddress", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "affiliateName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1545135965"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "15935998530978442" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x6861707079686f7572676c61737300000000... )", async function( ) {
		const txOriginal = {blockNumber: "6909022", timeStamp: "1545136369", hash: "0x755f85b16161debad2e0e5c2180b37a09d628f331eed20592593093e938b64cd", nonce: "86", blockHash: "0x1a1c30f9b0d05b441091b342bca156d9f4a92d9393d20a9d6ea9c63dcf9a99ec", transactionIndex: "65", from: "0x41fa920f6547fabd1dbdca960f0af13a45018b2d", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "300000000000000000", gas: "3000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e6861707079686f7572676c617373000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3920066", gasUsed: "374321", confirmations: "767189"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x6861707079686f7572676c617373000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x6861707079686f7572676c617373000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1545136369 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545136369000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000011"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x41fa920f6547fabd1dbdca960f0af13a45018b2d"}, {name: "ethIn", type: "uint256", value: "300000000000000000"}, {name: "keysBought", type: "uint256", value: "4000000000000000000000"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "30000000000000000"}, {name: "genAmount", type: "uint256", value: "194999999999965489"}, {name: "potAmount", type: "uint256", value: "30000000000000000"}, {name: "seedAdd", type: "uint256", value: "30000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[40,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "10"}, {name: "affiliateAddress", type: "address", value: "0x22f2c722d8a71cc6521d5a7cfbe167b6f6706186"}, {name: "affiliateName", type: "bytes32", value: "0x6861707079686f7572676c617373000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "11"}, {name: "amount", type: "uint256", value: "15000000000000000"}, {name: "timeStamp", type: "uint256", value: "1545136369"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[40,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "368759710669817630" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x6861707079686f7572676c61737300000000... )", async function( ) {
		const txOriginal = {blockNumber: "6909032", timeStamp: "1545136583", hash: "0xa287f18adf8a0d1cda0754d31a4daeb429f7a81f8e006f85c110582d47801a81", nonce: "133", blockHash: "0x578c92b817ce22c77cac387148c21930a5e23413c723cc67541d23f12be119e7", transactionIndex: "85", from: "0xa043ef9fce771eaa194f29a8ff1d26682ae8e438", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "150037500000000000", gas: "3000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e6861707079686f7572676c617373000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4713584", gasUsed: "342077", confirmations: "767179"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "150037500000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x6861707079686f7572676c617373000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x6861707079686f7572676c617373000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1545136583 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545136583000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000012"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xa043ef9fce771eaa194f29a8ff1d26682ae8e438"}, {name: "ethIn", type: "uint256", value: "150037500000000000"}, {name: "keysBought", type: "uint256", value: "2000500000000000000000"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "15003750000000000"}, {name: "genAmount", type: "uint256", value: "97524374999996792"}, {name: "potAmount", type: "uint256", value: "15003750000000000"}, {name: "seedAdd", type: "uint256", value: "15003750000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[41,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "10"}, {name: "affiliateAddress", type: "address", value: "0x22f2c722d8a71cc6521d5a7cfbe167b6f6706186"}, {name: "affiliateName", type: "bytes32", value: "0x6861707079686f7572676c617373000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "12"}, {name: "amount", type: "uint256", value: "7501875000000000"}, {name: "timeStamp", type: "uint256", value: "1545136583"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[41,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "86205966976484390" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6909059", timeStamp: "1545136965", hash: "0x1b85ce71e5cb6b252e9b0f5383fe1d7b583cab5671faf1530ac52804d92af3ce", nonce: "87", blockHash: "0x9a1d2ab6817da1a5f687f4dc0383e701fee88a60d306ce823d17e1a006a018e0", transactionIndex: "150", from: "0x41fa920f6547fabd1dbdca960f0af13a45018b2d", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "250000000000000000", gas: "300000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4190525", gasUsed: "147858", confirmations: "767152"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1545136965 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545136965000000000000000000"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000011"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x41fa920f6547fabd1dbdca960f0af13a45018b2d"}, {name: "ethIn", type: "uint256", value: "250000000000000000"}, {name: "keysBought", type: "uint256", value: "3333333333333333333334"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "25000000000000000"}, {name: "genAmount", type: "uint256", value: "162499999999999938"}, {name: "potAmount", type: "uint256", value: "25000000000000000"}, {name: "seedAdd", type: "uint256", value: "25000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[42,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "11"}, {name: "amount", type: "uint256", value: "12500000000000000"}, {name: "timeStamp", type: "uint256", value: "1545136965"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[42,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "368759710669817630" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6909114", timeStamp: "1545137875", hash: "0x349988e28d278e72835fe1a9d1742d34a5885d05f7d6a8b7ebacacb518080512", nonce: "407", blockHash: "0x11e4d66d0f222ea0feb90720bce382c266ae1ffc14bd903a04611513963a1c63", transactionIndex: "86", from: "0x531c2a3328555f0b77f48d79613fe545d329f076", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "62369999999999990", gas: "3000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5103566", gasUsed: "341437", confirmations: "767097"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "62369999999999990" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1545137875 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545137875000000000000000111"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000013"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x531c2a3328555f0b77f48d79613fe545d329f076"}, {name: "ethIn", type: "uint256", value: "62369999999999990"}, {name: "keysBought", type: "uint256", value: "831599999999999866666"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "6236999999999999"}, {name: "genAmount", type: "uint256", value: "40540499999996324"}, {name: "potAmount", type: "uint256", value: "6237000000000000"}, {name: "seedAdd", type: "uint256", value: "6236999999999999"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[43,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "13"}, {name: "amount", type: "uint256", value: "3118499999999999"}, {name: "timeStamp", type: "uint256", value: "1545137875"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[43,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "3222083782550922" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61793b20756e695f7265666572726572... )", async function( ) {
		const txOriginal = {blockNumber: "6909766", timeStamp: "1545147756", hash: "0x5df6a8cf292ff844715823826c1cab148e556e4c50dda2494eb9e8fb5ec938c4", nonce: "5", blockHash: "0xb3b51577c4da43baba5311099ae247389ca6195c91374b373b26b50cf5a42f77", transactionIndex: "18", from: "0xaeb7e6da9a3a9ec23a8ee220ed4ce3bf1f2e16b3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "70000000000000010", gas: "3000000", gasPrice: "24000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c61793b20756e695f72656665727265723d706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617900000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "785769", gasUsed: "203809", confirmations: "766445"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "70000000000000010" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c61793b20756e695f72656665727265723d706c617925334220756e695f72"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c61793b20756e695f72656665727265723d706c617925334220756e695f72", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1545147756 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545147756000000000000000100"}, {name: "compressedIDs", type: "uint256", value: "10000000000000000000000000000000000000000000000000007"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xaeb7e6da9a3a9ec23a8ee220ed4ce3bf1f2e16b3"}, {name: "ethIn", type: "uint256", value: "70000000000000010"}, {name: "keysBought", type: "uint256", value: "933333333333333466667"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "10500000000000001"}, {name: "genAmount", type: "uint256", value: "45499999999989892"}, {name: "potAmount", type: "uint256", value: "7000000000000002"}, {name: "seedAdd", type: "uint256", value: "7000000000000001"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "2201305098838814" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6909873", timeStamp: "1545149177", hash: "0xc102023388335ca13ad31f16d4b599866f06e03dcc957972a56d402a9c974e5d", nonce: "29", blockHash: "0x57c2945e9de00062140e8f6a3a1fa095fa81cf2d78ec7bd86c6fbcf2d570906e", transactionIndex: "41", from: "0xab2aa003732ba7afacb6565aa40c45001aac48bd", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "0", gas: "2000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "1683227", gasUsed: "264458", confirmations: "766338"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1545149177 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onWithdrawAndDistribute", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onWithdrawAndDistribute", events: [{name: "playerAddress", type: "address", value: "0xab2aa003732ba7afacb6565aa40c45001aac48bd"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethOut", type: "uint256", value: "94904075036165"}, {name: "compressedData", type: "uint256", value: "1545149177001545148696000000"}, {name: "compressedIDs", type: "uint256", value: "700000000000000000000000006"}, {name: "winnerAddr", type: "address", value: "0xaeb7e6da9a3a9ec23a8ee220ed4ce3bf1f2e16b3"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "390226073112241067"}, {name: "newPot", type: "uint256", value: "97556518278082049"}, {name: "tokenAmount", type: "uint256", value: "78045214622448213"}, {name: "genAmount", type: "uint256", value: "117067821933628758"}, {name: "seedAdd", type: "uint256", value: "97556518278082048"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "468384877382297" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6909886", timeStamp: "1545149322", hash: "0x66433b0068694ff3931951bcd02db097a4468ae1335b340fee0e30869b1d7628", nonce: "1445", blockHash: "0xbe6f1520367e7e686f05702c5f16fae1d081aa4f2912b30c5e305ee3ac29a95e", transactionIndex: "16", from: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "2000000000000000000", gas: "3000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "829365", gasUsed: "312592", confirmations: "766325"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1545149322 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545149322000000000000000110"}, {name: "compressedIDs", type: "uint256", value: "20000000000000000000000000000000000000000000000000001"}, {name: "playerName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "ethIn", type: "uint256", value: "2000000000000000000"}, {name: "keysBought", type: "uint256", value: "26666666666666666666666"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "200000000000000000"}, {name: "genAmount", type: "uint256", value: "1299999999999999999"}, {name: "potAmount", type: "uint256", value: "200000000000000000"}, {name: "seedAdd", type: "uint256", value: "200000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[46,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "3"}, {name: "affiliateAddress", type: "address", value: "0x21db5ce96df3b94a9def892b01f8a5a061630a9e"}, {name: "affiliateName", type: "bytes32", value: "0x706c61796e6f7700000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "2"}, {name: "buyerID", type: "uint256", value: "1"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "timeStamp", type: "uint256", value: "1545149322"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[46,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "181256836166982472488" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61793b20756e695f7265666572726572... )", async function( ) {
		const txOriginal = {blockNumber: "6909909", timeStamp: "1545149576", hash: "0x142db71dc7dcc9665da71ec560c7e6b67c52ba64b4c3a517bf15200a778658bf", nonce: "30", blockHash: "0x09e3b280d11c3d95d58b8ee75e8c825986bd54467451bb03841ad089ee438362", transactionIndex: "22", from: "0xab2aa003732ba7afacb6565aa40c45001aac48bd", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "1000000000000000000", gas: "3000000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c61793b20756e695f72656665727265723d706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c617925334220756e695f7265666572726572253344706c61790000000000000000000000", contractAddress: "", cumulativeGasUsed: "893878", gasUsed: "222496", confirmations: "766302"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c61793b20756e695f72656665727265723d706c617925334220756e695f72"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c61793b20756e695f72656665727265723d706c617925334220756e695f72", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1545149576 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545149576000000000000000110"}, {name: "compressedIDs", type: "uint256", value: "20000000000000000000000000000000000000000000000000006"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0xab2aa003732ba7afacb6565aa40c45001aac48bd"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "13333333333333333333334"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "150000000000000000"}, {name: "genAmount", type: "uint256", value: "650000000000000000"}, {name: "potAmount", type: "uint256", value: "100000000000000000"}, {name: "seedAdd", type: "uint256", value: "100000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "468384877382297" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6909934", timeStamp: "1545149928", hash: "0x8e330a8da1d4e394e99787617f9071c5c812a2a7c295fed5f430d054ff5c80e1", nonce: "630", blockHash: "0xd777dcf2c387a986fad67a2834447a19c39ce336b6108f5b685173889e45f0dc", transactionIndex: "80", from: "0x1ecc246891e1430f8bf297547e02887d230c39b6", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "10000000000000000", gas: "3000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4644574", gasUsed: "221192", confirmations: "766277"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1545149928 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545149928000000000000000010"}, {name: "compressedIDs", type: "uint256", value: "20000000000000000000000000000000000000000000000000008"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x1ecc246891e1430f8bf297547e02887d230c39b6"}, {name: "ethIn", type: "uint256", value: "10000000000000000"}, {name: "keysBought", type: "uint256", value: "133333333333333333333"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "1000000000000000"}, {name: "genAmount", type: "uint256", value: "6499999999985333"}, {name: "potAmount", type: "uint256", value: "1000000000000000"}, {name: "seedAdd", type: "uint256", value: "1000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[48,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "2"}, {name: "buyerID", type: "uint256", value: "8"}, {name: "amount", type: "uint256", value: "500000000000000"}, {name: "timeStamp", type: "uint256", value: "1545149928"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[48,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "51757311428300529" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buyXname( \"0x706c61790000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6909937", timeStamp: "1545149972", hash: "0xe11c546f79fd427995897c9fa8b9153df9f0ef6c3ac7b1811772df89f18eefef", nonce: "584", blockHash: "0x966f048a294cb68d9656472e6f4c267953fd06527a4e443912373c164b7a228f", transactionIndex: "78", from: "0x2f20fc4493bd6adab696ee89ac0ab035727aa2e4", to: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa", value: "200000000000000000", gas: "3000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x438d359e706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4232624", gasUsed: "324496", confirmations: "766274"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_affCode", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}], name: "buyXname", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyXname(bytes32)" ]( "0x706c617900000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1545149972 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "compressedData", type: "uint256"}, {indexed: false, name: "compressedIDs", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}, {indexed: false, name: "winnerAddr", type: "address"}, {indexed: false, name: "winnerName", type: "bytes32"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "newPot", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "genAmount", type: "uint256"}, {indexed: false, name: "potAmount", type: "uint256"}, {indexed: false, name: "seedAdd", type: "uint256"}], name: "onEndTx", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onEndTx", events: [{name: "compressedData", type: "uint256", value: "1545149972000000000000000011"}, {name: "compressedIDs", type: "uint256", value: "20000000000000000000000000000000000000000000000000014"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "playerAddress", type: "address", value: "0x2f20fc4493bd6adab696ee89ac0ab035727aa2e4"}, {name: "ethIn", type: "uint256", value: "200000000000000000"}, {name: "keysBought", type: "uint256", value: "2666666666666666666667"}, {name: "winnerAddr", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "winnerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amountWon", type: "uint256", value: "0"}, {name: "newPot", type: "uint256", value: "0"}, {name: "tokenAmount", type: "uint256", value: "20000000000000000"}, {name: "genAmount", type: "uint256", value: "129999999999996000"}, {name: "potAmount", type: "uint256", value: "20000000000000000"}, {name: "seedAdd", type: "uint256", value: "20000000000000000"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affiliateID", type: "uint256"}, {indexed: false, name: "affiliateAddress", type: "address"}, {indexed: false, name: "affiliateName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffiliatePayout", type: "event"} ;
		console.error( "eventCallOriginal[49,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffiliatePayout", events: [{name: "affiliateID", type: "uint256", value: "1"}, {name: "affiliateAddress", type: "address", value: "0x7c76a64ac61d1eeafe2b8af6f7f0a6a1890418f3"}, {name: "affiliateName", type: "bytes32", value: "0x706c617900000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "2"}, {name: "buyerID", type: "uint256", value: "14"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1545149972"}], address: "0x5c68bb8b8b000c5d750e4d70427d8a99c49bdaaa"}] ;
		console.error( "eventResultOriginal[49,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "263341264958529079" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "243749154715362557" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
