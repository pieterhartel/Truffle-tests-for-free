const FabgToken = artifacts.require( "./FabgToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "FabgToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x6Be9894BB589E7D7656A7805040144bbF157BbAF", "0x1ea2A567ad75da94C7e9EE2c462bDf1C407e811c", "0xE49A852Bf55736d76B483632B9B78d04646CC15a"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_interfaceId", type: "bytes4"}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "getApproved", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "InterfaceId_ERC165", outputs: [{name: "", type: "bytes4"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_index", type: "uint256"}], name: "tokenOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "getTokenPriceForIncreasing", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "exists", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_index", type: "uint256"}], name: "tokenByIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "ownerOf", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "allTokensOfUsers", outputs: [{name: "", type: "uint256[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "getTokenById", outputs: [{name: "typeOfToken", type: "uint8"}, {name: "name", type: "bytes32"}, {name: "URL", type: "bytes32"}, {name: "isSnatchable", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "x", type: "bytes32"}], name: "bytes32ToString", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isPaused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "saleAgent", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "tokenURI", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "source", type: "string"}], name: "stringToBytes32", outputs: [{name: "result", type: "bytes32"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_operator", type: "address"}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "numberOfTokens", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenChanged", type: "event"}, {anonymous: false, inputs: [], name: "Paused", type: "event"}, {anonymous: false, inputs: [], name: "Unpaused", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "previousOwner", type: "address"}, {indexed: false, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_owner", type: "address"}, {indexed: false, name: "_approved", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_owner", type: "address"}, {indexed: false, name: "_operator", type: "address"}, {indexed: false, name: "_approved", type: "bool"}], name: "ApprovalForAll", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["TokenCreated(address,uint8,bytes32,bytes32,uint256,bool)", "TokenChanged(address,uint8,bytes32,bytes32,uint256,bool)", "Paused()", "Unpaused()", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)", "ApprovalForAll(address,address,bool)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x04c6b115a5a2a20550ae19065ab838ca6a4a1ead36c85bf62092016a0ade5a7b", "0xa026496083b355957faf2a29d9744321a9384caf1c4600c96bd7425c10e729fe", "0x9e87fac88ff661f02d44f95383c817fece4bce600a3dab7a54406878b965e752", "0xa45f47fdea8a1efdd9029a5691c7f759c32b7c698632b563573e155625d16933", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0x17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6662483 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6662836 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "FabgToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "bytes4", name: "_interfaceId", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "supportsInterface(bytes4)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "getApproved", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getApproved(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "InterfaceId_ERC165", outputs: [{name: "", type: "bytes4"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "InterfaceId_ERC165()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_index", value: random.range( maxRandom )}], name: "tokenOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenOfOwnerByIndex(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "getTokenPriceForIncreasing", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokenPriceForIncreasing(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "exists", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "exists(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_index", value: random.range( maxRandom )}], name: "tokenByIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenByIndex(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "ownerOf", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerOf(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allTokensOfUsers", outputs: [{name: "", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allTokensOfUsers(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "getTokenById", outputs: [{name: "typeOfToken", type: "uint8"}, {name: "name", type: "bytes32"}, {name: "URL", type: "bytes32"}, {name: "isSnatchable", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokenById(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "x", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "bytes32ToString", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bytes32ToString(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isPaused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isPaused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "saleAgent", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "saleAgent()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "tokenURI", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenURI(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "string", name: "source", value: random.string( maxRandom )}], name: "stringToBytes32", outputs: [{name: "result", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "stringToBytes32(string)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isApprovedForAll(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numberOfTokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numberOfTokens()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "FabgToken", function( accounts ) {

	it( "TEST: FabgToken(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6662483", timeStamp: "1541626699", hash: "0x6aee18c8d08f3b42a30c8cfaea4e28040e96c5be21fb681f9cd329108bd84d70", nonce: "1", blockHash: "0x4991c8e5bad38ae120e54b42e572ecf4a7a8484c7a2101838557ca3096d2b665", transactionIndex: "19", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: 0, value: "0", gas: "2422123", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x9b86ea09", contractAddress: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", cumulativeGasUsed: "3499197", gasUsed: "2422123", confirmations: "1056078"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "FabgToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = FabgToken.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541626699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = FabgToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"2000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662665", timeStamp: "1541629042", hash: "0xb174a1f1ce95f4db39defa62bb52bb9655ac8f8b8c0955285f223b588ae4ecf8", nonce: "9", blockHash: "0x6d1307282d4c1de25ca66f3d9c0278922476b03fb7dfec698c674471bb8fda69", transactionIndex: "31", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223687", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000001bc16d674ec800000000000000000000000000000000000000000000000000000000000000000000435542472048656c6d657400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2203556", gasUsed: "223687", confirmations: "1055896"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "2000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x435542472048656c6d6574000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "2000000000000000000", "0", "0x435542472048656c6d6574000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541629042 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x435542472048656c6d6574000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "0"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "0"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[1,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662672", timeStamp: "1541629194", hash: "0x3ea079ad728d6597dcc3da7cf9005c25dc42bf1c3ec8e341341bc645884afa5d", nonce: "10", blockHash: "0x90716af312117cf1da5b53ef95576df4f98e6606289b94a49f886eb80ababf1a", transactionIndex: "41", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223879", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d90000000000000000000000000000000000000000000000000000000000000000000055464f20416c69656e204d61736b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3766394", gasUsed: "223879", confirmations: "1055889"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x55464f20416c69656e204d61736b000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x55464f20416c69656e204d61736b000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541629194 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x55464f20416c69656e204d61736b000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "1"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "1"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[2,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662678", timeStamp: "1541629277", hash: "0xfc5a292ac55970fbecdabb303312142724d15ecd8cea32490fcdda38f55f8bc6", nonce: "11", blockHash: "0x230d9fbac8a3bb168231b56ec24b6e6b82b701fcb17e1bd6c467fd061a32d698", transactionIndex: "32", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223687", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d90000000000000000000000000000000000000000000000000000000000000000000042616e646974204d61736b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1913068", gasUsed: "223687", confirmations: "1055883"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x42616e646974204d61736b000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x42616e646974204d61736b000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541629277 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x42616e646974204d61736b000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "2"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "2"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[3,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662683", timeStamp: "1541629334", hash: "0x18fc830f6fc5a59a5cca15d2230c9cea1460bb42f53d82f665e717fb66f90e10", nonce: "12", blockHash: "0xac347c3259c6536b10552792c8cda9eae34cd222d25d75209329c94b0bfb14ef", transactionIndex: "62", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223687", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d900000000000000000000000000000000000000000000000000000000000000000000526f62626572204d61736b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2584622", gasUsed: "223687", confirmations: "1055878"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x526f62626572204d61736b000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x526f62626572204d61736b000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541629334 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x526f62626572204d61736b000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "3"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "3"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[4,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"1000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662686", timeStamp: "1541629360", hash: "0xe77e7c49bf284b34d11eecffae8a117c195d7a2767466493a2c2bac8b672f157", nonce: "13", blockHash: "0x48db87de5fb72b4ae6f366ab4a31f7fb825768db55b32673824b3ddff3676982", transactionIndex: "5", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223751", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000000436869636b656e204d61736b000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "401044", gasUsed: "223751", confirmations: "1055875"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "1000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x436869636b656e204d61736b0000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "1000000000000000000", "0", "0x436869636b656e204d61736b0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541629360 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x436869636b656e204d61736b0000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "4"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "4"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[5,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"1000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662688", timeStamp: "1541629408", hash: "0x29bbd0dd05199e4b29649da63aec8bcc2b811280198df8397d320c8b67b5cc6c", nonce: "14", blockHash: "0xfd82e3e427c21dd767cb896c77c60d3861a852b4eea69d8fb779638268a94b5f", transactionIndex: "18", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223623", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000000436c6f776e204d61736b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "927552", gasUsed: "223623", confirmations: "1055873"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "1000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x436c6f776e204d61736b00000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "1000000000000000000", "0", "0x436c6f776e204d61736b00000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541629408 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x436c6f776e204d61736b00000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "5"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "5"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[6,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662693", timeStamp: "1541629504", hash: "0x4a1a7e56bf3b19d4fbe827f15a708f67b8a5df45eef8876ed68e6880ea5202cc", nonce: "15", blockHash: "0x4f2fa6e6fc4dea885e754c45c784c800b14bf2b45be67db54c83f81e178707be", transactionIndex: "53", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223751", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000004275696c646572204d61736b000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4025294", gasUsed: "223751", confirmations: "1055868"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4275696c646572204d61736b0000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x4275696c646572204d61736b0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541629504 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4275696c646572204d61736b0000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "6"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "6"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[7,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662695", timeStamp: "1541629547", hash: "0xfd490b7e3d81a8b34cf2cf52758122d88e80c11bf874de5b9beab5ef7337a175", nonce: "16", blockHash: "0xde2460e7f569e37cbdf878fbd5a2deb99f2e772af0fa736610fcd3e125460f09", transactionIndex: "143", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223495", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000000000466f78204d61736b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6363395", gasUsed: "223495", confirmations: "1055866"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x466f78204d61736b000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x466f78204d61736b000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541629547 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x466f78204d61736b000000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "7"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "7"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[8,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662697", timeStamp: "1541629564", hash: "0x9c4e15e5ef2a981f88773f141233ec5afbdd249cac0d01ce8276b01b37790e1d", nonce: "17", blockHash: "0x7b4e5754c7847eab8a41daaa0c76a7415750cfadb18e263a9d24ca44c92a3afb", transactionIndex: "19", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223495", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000000000476173204d61736b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "842257", gasUsed: "223495", confirmations: "1055864"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x476173204d61736b000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x476173204d61736b000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541629564 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x476173204d61736b000000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "8"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "8"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[9,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662699", timeStamp: "1541629603", hash: "0xfa64d4e90abbad9d1e91e0f8cf4ee76a58ed465646b7c0525995e1c486ca0137", nonce: "18", blockHash: "0x426f51a4f8616c229bd04e5d35c0db7915ec0c34b3c1ffa747f0207f9fd3e84c", transactionIndex: "58", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223559", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000000000000047616e67204d61736b000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3492822", gasUsed: "223559", confirmations: "1055862"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x47616e67204d61736b0000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x47616e67204d61736b0000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541629603 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x47616e67204d61736b0000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "9"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "9"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[10,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662711", timeStamp: "1541629733", hash: "0x1ec979cd136df7eb5b039994ccda0fc2aaccc272f6327d15afde8d420d903fd3", nonce: "19", blockHash: "0xe44deea5023c872a63cf735e1d709d30aa1f087de2bf46c215bdabecde35f484", transactionIndex: "64", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223687", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000000000486f636b6579204d61736b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4582954", gasUsed: "223687", confirmations: "1055850"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x486f636b6579204d61736b000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x486f636b6579204d61736b000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541629733 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x486f636b6579204d61736b000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "10"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "10"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[11,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"1000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662713", timeStamp: "1541629752", hash: "0x8872bd9d704c996c68107674ba7eb17708d8553ac6696572577b50fb5ea9cd18", nonce: "20", blockHash: "0xc120612b2f3d45c15018fd9073314e2b0a6aea837a5e99185230b512e62e98ba", transactionIndex: "24", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223623", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000000486f727365204d61736b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1226641", gasUsed: "223623", confirmations: "1055848"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "1000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x486f727365204d61736b00000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "1000000000000000000", "0", "0x486f727365204d61736b00000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541629752 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x486f727365204d61736b00000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "11"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "11"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[12,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662722", timeStamp: "1541629880", hash: "0x1f0ae81220911ee75d85cf5de320677dc78a956a87ccd760a2200e280b8ccf8d", nonce: "21", blockHash: "0xc185fdaac86b7e6c9942aa8e353f1fc81177491ff2d6c2554a84bb1b4d80c7a2", transactionIndex: "49", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223751", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000004176656e676572204d61736b000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4478927", gasUsed: "223751", confirmations: "1055839"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4176656e676572204d61736b0000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x4176656e676572204d61736b0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541629880 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4176656e676572204d61736b0000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "12"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "12"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[13,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662722", timeStamp: "1541629880", hash: "0x9afec61151cff7064a5fee8a438caeebb2dc9caaa4ee6b6c3197e760b819cdd2", nonce: "22", blockHash: "0xc185fdaac86b7e6c9942aa8e353f1fc81177491ff2d6c2554a84bb1b4d80c7a2", transactionIndex: "50", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223623", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d90000000000000000000000000000000000000000000000000000000000000000000050616e6461204d61736b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4702550", gasUsed: "223623", confirmations: "1055839"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x50616e6461204d61736b00000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x50616e6461204d61736b00000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541629880 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x50616e6461204d61736b00000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "13"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "13"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[14,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"4000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662732", timeStamp: "1541630087", hash: "0x2c8f90771f308babb276a40291346e3fa8bd967ed26c662136f9e432754e92aa", nonce: "23", blockHash: "0x2fdfb2ca9accbfee782871b98ff1aef45704b94082391443c5220475b5be17d8", transactionIndex: "102", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223623", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000003782dace9d90000000000000000000000000000000000000000000000000000000000000000000005061706572204d61736b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4446167", gasUsed: "223623", confirmations: "1055829"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "4000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x5061706572204d61736b00000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "4000000000000000000", "0", "0x5061706572204d61736b00000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541630087 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x5061706572204d61736b00000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "14"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "14"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[15,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662735", timeStamp: "1541630121", hash: "0x6ab75c29a3b86190e8892afa4111b1ea68c1e3baef451bf85f400e75f080ea7e", nonce: "24", blockHash: "0x5d585f2fe8fc6941b4468edef7081ba15ba33bea72d705fc4df815982aa79def", transactionIndex: "36", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223559", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000004d616c65204d61736b000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3195756", gasUsed: "223559", confirmations: "1055826"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4d616c65204d61736b0000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x4d616c65204d61736b0000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541630121 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4d616c65204d61736b0000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "15"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "15"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[16,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662739", timeStamp: "1541630162", hash: "0x102580de98c32933c00c6892a523545e04f033789382993f728c5f727abd2f7f", nonce: "25", blockHash: "0x7db1d9f4a587d271bb7437fe0b64d523caa47591d28954d8e6df7292d74bf440", transactionIndex: "99", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223623", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000005a6f72726f204d61736b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3600306", gasUsed: "223623", confirmations: "1055822"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x5a6f72726f204d61736b00000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x5a6f72726f204d61736b00000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541630162 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x5a6f72726f204d61736b00000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "16"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "16"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[17,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662741", timeStamp: "1541630199", hash: "0xf5a852252d34488d2e03614a1d546bbe67c222590507d33bf7a679f395e5fa18", nonce: "26", blockHash: "0x83cc36b533d0eb6f80c99fe00f3c8a5aba65c05f18852d7c071be8b28801229c", transactionIndex: "42", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223687", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d90000000000000000000000000000000000000000000000000000000000000000000046656d616c65204d61736b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2232859", gasUsed: "223687", confirmations: "1055820"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x46656d616c65204d61736b000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x46656d616c65204d61736b000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541630199 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x46656d616c65204d61736b000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "17"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "17"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[18,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"1000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662747", timeStamp: "1541630272", hash: "0x5b28c0968704b4f2b16a3b6ad06aeb5b44f3067749df33de1fb37e3646a810b6", nonce: "27", blockHash: "0xa719d85bbfc58711372806fdba9b3ee97df7632d2facaa42475671e71fe89cb3", transactionIndex: "52", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223623", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000005469676572204d61736b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3522159", gasUsed: "223623", confirmations: "1055814"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "1000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x5469676572204d61736b00000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "1000000000000000000", "0", "0x5469676572204d61736b00000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541630272 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x5469676572204d61736b00000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "18"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "18"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[19,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"8000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662750", timeStamp: "1541630312", hash: "0xe51f9d5a79c772d63d8c1cd4eef753e08eae916bff4b94dfbf6305cda9618818", nonce: "28", blockHash: "0x52ba7f8ad6a6bd662050b3733c2607572a78bfaa772e6555df0bc1833f4ad8c1", transactionIndex: "25", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223623", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000000000000005472756d70204d61736b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1505762", gasUsed: "223623", confirmations: "1055811"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "8000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x5472756d70204d61736b00000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "8000000000000000000", "0", "0x5472756d70204d61736b00000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541630312 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x5472756d70204d61736b00000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "19"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "19"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[20,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"1000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662752", timeStamp: "1541630369", hash: "0x55abcbb258c3bebd2b4368a6ce954e07c6ddd4a246f897ba5830521f4e4ab416", nonce: "29", blockHash: "0xbc14f37e06f18b4757c2a860bf34af34e0d31b080b6611b85094afcc075c28eb", transactionIndex: "157", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223815", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000000526163696e672048656c6d65740000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6596102", gasUsed: "223815", confirmations: "1055809"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "1000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x526163696e672048656c6d657400000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "1000000000000000000", "0", "0x526163696e672048656c6d657400000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541630369 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x526163696e672048656c6d657400000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "20"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "20"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[21,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662755", timeStamp: "1541630409", hash: "0xf795fad8a03c91c4da7dd3b122efa095c6e3be90390a429e0c715dffae23469c", nonce: "30", blockHash: "0x4deb457e5bc5d7f8736e6476269108b1fbc7bb03ef056e0257b40938489fb757", transactionIndex: "16", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223943", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000004d696c69746172792048656c6d6574000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "988565", gasUsed: "223943", confirmations: "1055806"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4d696c69746172792048656c6d65740000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x4d696c69746172792048656c6d65740000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541630409 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4d696c69746172792048656c6d65740000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "21"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "21"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[22,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662761", timeStamp: "1541630487", hash: "0x93e904fb3da6adb3aed9e15bed8422b3c8e6bb0db204d41437de6ad0c0445fa8", nonce: "31", blockHash: "0x1b71d757cbaa46f1729ed1e53f217ee9be25d4291ab61172ac9ae20577e1fb06", transactionIndex: "132", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223495", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000004561726d7566667300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4509040", gasUsed: "223495", confirmations: "1055800"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4561726d75666673000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x4561726d75666673000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541630487 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4561726d75666673000000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "22"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "22"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[23,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662765", timeStamp: "1541630562", hash: "0xc64267248666a0d78e6e9afe1d698122085c9a7c23986caee67d11d51ff7d96f", nonce: "32", blockHash: "0x2863f03daa76d19f49bd670d218f9b1c02f27bcf8ab1d9ab4ace946909ce3bdc", transactionIndex: "53", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223495", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d900000000000000000000000000000000000000000000000000000000000000000000457965706174636800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2415589", gasUsed: "223495", confirmations: "1055796"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4579657061746368000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x4579657061746368000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541630562 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4579657061746368000000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "23"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "23"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[24,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662769", timeStamp: "1541630589", hash: "0x054cab33d9e9cb75bd73054a10e9b43cee4742d934376093347e9fca1aada322", nonce: "33", blockHash: "0x93ba8db66914b39d5ededf08a0afa0c776c155e0a8fe6e21301fa3e05b623aa8", transactionIndex: "9", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "224071", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000004d696c697461727920466163656d61736b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "942862", gasUsed: "224071", confirmations: "1055792"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4d696c697461727920466163656d61736b000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x4d696c697461727920466163656d61736b000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541630589 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4d696c697461727920466163656d61736b000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "24"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "24"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[25,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662771", timeStamp: "1541630603", hash: "0x120d966d984d13f510b8dc897763febec48d07596d341d23caf49067894faf19", nonce: "34", blockHash: "0x67589ffc7dda4db88b005103caf71442d71ff10b893325989ac87a37d1dcb5a6", transactionIndex: "9", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223815", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000000000000047616e6720466163656d61736b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "751467", gasUsed: "223815", confirmations: "1055790"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x47616e6720466163656d61736b00000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x47616e6720466163656d61736b00000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541630603 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x47616e6720466163656d61736b00000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "25"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "25"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[26,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662773", timeStamp: "1541630614", hash: "0x220485c6ec660cea37d0f47d9d657380bab816e786d170d57862a58bba477681", nonce: "35", blockHash: "0xa138ce47b8eabe56716d40c862e37795fb5281ef3c427028fdd8d2076f002a7f", transactionIndex: "20", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223879", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d900000000000000000000000000000000000000000000000000000000000000000000426c61636b20466163656d61736b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2116462", gasUsed: "223879", confirmations: "1055788"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x426c61636b20466163656d61736b000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x426c61636b20466163656d61736b000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541630614 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x426c61636b20466163656d61736b000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "26"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "26"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[27,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"2000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662778", timeStamp: "1541630694", hash: "0x7c7cc8e0069a972f327e45b8c723a93bc344bbe39fca97a3fd8d38c479d4565f", nonce: "36", blockHash: "0x02a14208601b9173fc3c7c2c54e891ed3f778048c44f7e0274712e015ddebab2", transactionIndex: "60", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223687", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000001bc16d674ec8000000000000000000000000000000000000000000000000000000000000000000004c6162204761736d61736b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1762463", gasUsed: "223687", confirmations: "1055783"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "2000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4c6162204761736d61736b000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "2000000000000000000", "0", "0x4c6162204761736d61736b000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541630694 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4c6162204761736d61736b000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "27"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "27"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[28,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662780", timeStamp: "1541630728", hash: "0xe4e97c23e4a3aa1c656611b0a24a717225ddf18bd52ff33d6b8f385fa99e8dc0", nonce: "37", blockHash: "0x3d0ba7f6f00438c221769343db03a009a98711cd6df79fa9c0f23aaa3142a9da", transactionIndex: "167", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223431", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d900000000000000000000000000000000000000000000000000000000000000000000476c61737365730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5122281", gasUsed: "223431", confirmations: "1055781"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x476c617373657300000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x476c617373657300000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541630728 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x476c617373657300000000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "28"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "28"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[29,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662782", timeStamp: "1541630779", hash: "0x1d9933df6db3c1fca57f467cb385d34be04095bff4795a600c591418b7192617", nonce: "38", blockHash: "0x363946f6149397156f209d2bdbecd521557d4792cdca37f157ce197aebc1fbed", transactionIndex: "43", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223431", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d90000000000000000000000000000000000000000000000000000000000000000000042616e64616e610000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1895104", gasUsed: "223431", confirmations: "1055779"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x42616e64616e6100000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x42616e64616e6100000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541630779 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x42616e64616e6100000000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "29"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "29"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[30,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662784", timeStamp: "1541630804", hash: "0x5c55d4b13e9eaccbba08de12495c32d50791479b83c7251d5141b6ef4930d545", nonce: "39", blockHash: "0x1be7d37ce430286c0abac69dd850706429718abbf17f091cacc2b36379f7cc3e", transactionIndex: "12", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223623", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000004265616e6965204861740000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1111165", gasUsed: "223623", confirmations: "1055777"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4265616e69652048617400000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x4265616e69652048617400000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541630804 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4265616e69652048617400000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "30"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "30"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[31,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"1000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662786", timeStamp: "1541630842", hash: "0x232684009c7275e8dc1d102ece24cd2b2e3899de2f9e407e842cf7f7a33ba2f9", nonce: "40", blockHash: "0x19394b4d713a10b8b97e71e7b22908391dc371c094cc537ffc2d1bcf55808ccb", transactionIndex: "7", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223495", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000000426565722048617400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "659055", gasUsed: "223495", confirmations: "1055775"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "1000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4265657220486174000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "1000000000000000000", "0", "0x4265657220486174000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541630842 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4265657220486174000000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "31"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "31"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[32,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"2000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662786", timeStamp: "1541630842", hash: "0xd34972c9dc8de8bc7db97a3d08fed8c40556ca8075436ca70c3f8ff1142a3cab", nonce: "41", blockHash: "0x19394b4d713a10b8b97e71e7b22908391dc371c094cc537ffc2d1bcf55808ccb", transactionIndex: "13", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223559", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000001bc16d674ec80000000000000000000000000000000000000000000000000000000000000000000042756e6e7920486174000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1684162", gasUsed: "223559", confirmations: "1055775"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "2000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x42756e6e79204861740000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "2000000000000000000", "0", "0x42756e6e79204861740000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541630842 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x42756e6e79204861740000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "32"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "32"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[33,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662794", timeStamp: "1541630926", hash: "0x206552055182418046c8057a75e86e6f0f45f67f9dc3543f692bc36b5e442287", nonce: "42", blockHash: "0x84e62ace4e2725eed8bf3b0300f83e110dc4dbee4f0dfad0e6287829f05eee7b", transactionIndex: "49", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223175", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d900000000000000000000000000000000000000000000000000000000000000000000436170000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3524022", gasUsed: "223175", confirmations: "1055767"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4361700000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x4361700000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541630926 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4361700000000000000000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "33"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "33"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[34,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662796", timeStamp: "1541630940", hash: "0xb7eed8bca388383dec4630bf6c3c1268a2575b09635d5cfbe598d25d9a3d7684", nonce: "43", blockHash: "0xfafc5ef5014d3b92e80ba8bd9fc0a6a85d545f609c1935ff483ba4d73a1094a1", transactionIndex: "4", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223687", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b2000000000000000000000000000000000000000000000000000000000000000000004361707461696e2048617400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "666738", gasUsed: "223687", confirmations: "1055765"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4361707461696e20486174000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x4361707461696e20486174000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541630940 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4361707461696e20486174000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "34"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "34"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[35,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662798", timeStamp: "1541630960", hash: "0x1024229ed8a1973f0575bb3bab1f7cc753ae774bb8ef06e9e640ac3c0885f135", nonce: "44", blockHash: "0xda2a8b2825f939f29a7aa361db91e3558e481f453e214f7ac85e0731b797b553", transactionIndex: "83", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223623", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000000000436f77626f79204861740000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3030693", gasUsed: "223623", confirmations: "1055763"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x436f77626f792048617400000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x436f77626f792048617400000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541630960 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x436f77626f792048617400000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "35"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "35"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[36,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"4000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662800", timeStamp: "1541630994", hash: "0x5b6db9b4fbbf3a622b612c8a1fc11b7c54762a444348c4b45f824a2892813f28", nonce: "45", blockHash: "0x8e2ca33bfbcc1dbc96054f3766464efbcde53aaba82530074fb534830863c8e4", transactionIndex: "35", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223687", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000000526f79616c2043726f776e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1282763", gasUsed: "223687", confirmations: "1055761"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "4000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x526f79616c2043726f776e000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "4000000000000000000", "0", "0x526f79616c2043726f776e000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541630994 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x526f79616c2043726f776e000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "36"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "36"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[37,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"2000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662804", timeStamp: "1541631011", hash: "0xdadb5e952a2fb62486dcef037cf8b5410034199ea8f2ddf8d073cccbc72e3a6d", nonce: "46", blockHash: "0x241225dcd600f2c1f9868623e15a622d98fd64a147306f5580dbbb2cf80a41fa", transactionIndex: "16", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223687", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000001bc16d674ec80000000000000000000000000000000000000000000000000000000000000000000043757063616b652048617400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1086286", gasUsed: "223687", confirmations: "1055757"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "2000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x43757063616b6520486174000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "2000000000000000000", "0", "0x43757063616b6520486174000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541631011 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x43757063616b6520486174000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "37"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "37"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[38,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662810", timeStamp: "1541631097", hash: "0xa55e8a0a50d8de8270d02a06a0f6334a55ffabcf9f0f61635aaa1d21cdcc7052", nonce: "47", blockHash: "0xba1614453f8955a2aafa28f683730b6596eeba2785c1886fd23de1d7056bc6bc", transactionIndex: "67", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223431", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000000000456c66204861740000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3944681", gasUsed: "223431", confirmations: "1055751"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x456c662048617400000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x456c662048617400000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541631097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x456c662048617400000000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "38"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "38"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[39,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662814", timeStamp: "1541631167", hash: "0x2569a4f22fd55607334b25ac018ffc5c55f635a6dc1220cc8508d1da8cce9210", nonce: "48", blockHash: "0xc6c924f80f0bf819466099e393dec430a8091ee43accdbbe2945020ae28757e8", transactionIndex: "16", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223431", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000000000000046657a204861740000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1197970", gasUsed: "223431", confirmations: "1055747"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x46657a2048617400000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x46657a2048617400000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541631167 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x46657a2048617400000000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "39"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "39"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[40,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662818", timeStamp: "1541631208", hash: "0xbe59c0155a24c340fbcf197b293e2ea486421edb5a11df079b6c863efb261764", nonce: "49", blockHash: "0x2540849392e1f3ddca202d41290343e012e322af5897804568a23a81aae4f206", transactionIndex: "7", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223687", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000000000466c6174546f702048617400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "615289", gasUsed: "223687", confirmations: "1055743"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x466c6174546f7020486174000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x466c6174546f7020486174000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541631208 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x466c6174546f7020486174000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "40"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "40"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[41,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662820", timeStamp: "1541631222", hash: "0xc0d96dcc96f33defd61d48a477ce1cf213d26669671c548eaddb0ced105baa93", nonce: "50", blockHash: "0x5444cef6b36096af1baa6925b96008fbf206697483d64664f42c36df40db209d", transactionIndex: "23", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223943", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000000000466f6f7462616c6c2048656c6d6574000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1920027", gasUsed: "223943", confirmations: "1055741"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x466f6f7462616c6c2048656c6d65740000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x466f6f7462616c6c2048656c6d65740000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541631222 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x466f6f7462616c6c2048656c6d65740000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "41"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "41"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[42,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"2000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662822", timeStamp: "1541631248", hash: "0x06e2c9b9ed0e8ef906058edf0843d19985f5a85534beb4cf970142f681ca0ae2", nonce: "51", blockHash: "0xd0c31363679b311002705423080eca6feff357672873ecaf012ce588156dd519", transactionIndex: "11", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223751", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000001bc16d674ec800000000000000000000000000000000000000000000000000000000000000000000496365637265616d20486174000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "790865", gasUsed: "223751", confirmations: "1055739"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "2000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x496365637265616d204861740000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "2000000000000000000", "0", "0x496365637265616d204861740000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541631248 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x496365637265616d204861740000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "42"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "42"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[43,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662823", timeStamp: "1541631252", hash: "0x36d162097dcd33f00629ef90d973475fd9537217adba6d07d1e6e160e6ca1c84", nonce: "52", blockHash: "0xf511705ea70c8d06180d3711c65579c76048b773f8abee67922abb550776833d", transactionIndex: "8", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223559", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000000000497269736820486174000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "795917", gasUsed: "223559", confirmations: "1055738"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4972697368204861740000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x4972697368204861740000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541631252 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4972697368204861740000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "43"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "43"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[44,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"1000000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "6662828", timeStamp: "1541631314", hash: "0x515bc29a7d11b817fec14f70dc6c180c869ca93bb39994361b58ee457e089466", nonce: "53", blockHash: "0x9f61aab119071b308da0c76e47b42eb7109ec54b3419a599792b345eb99f9011", transactionIndex: "13", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223815", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a0000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000004b6e696768742048656c6d65740000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "878630", gasUsed: "223815", confirmations: "1055733"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "1000000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4b6e696768742048656c6d657400000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "1000000000000000000", "0", "0x4b6e696768742048656c6d657400000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1541631314 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4b6e696768742048656c6d657400000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "44"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "44"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[45,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662832", timeStamp: "1541631361", hash: "0x005641ae2270e91de502edf7b3e953cdfa126fa6e31db250700d05ee1526ac23", nonce: "54", blockHash: "0xb8de999947b599bd47cc7af131262c71ddb7df85ba67f84d5e60270cc5c9d021", transactionIndex: "31", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223687", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b2000000000000000000000000000000000000000000000000000000000000000000004d65786963616e2048617400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1770742", gasUsed: "223687", confirmations: "1055729"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4d65786963616e20486174000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x4d65786963616e20486174000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541631361 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4d65786963616e20486174000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "45"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "45"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[46,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"250000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662834", timeStamp: "1541631387", hash: "0xee09c2eee51e4410a20e405418fb4d913a212e96822599180b8bf6757857d594", nonce: "55", blockHash: "0xb0f126276ec58e7c2304a0ab165fe58d60e2e59a917ebe186a1439ba3555e431", transactionIndex: "10", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223751", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000004d696c697461727920486174000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "832007", gasUsed: "223751", confirmations: "1055727"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "250000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x4d696c6974617279204861740000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "250000000000000000", "0", "0x4d696c6974617279204861740000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541631387 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x4d696c6974617279204861740000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "46"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "46"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[47,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662836", timeStamp: "1541631423", hash: "0x72b72a6d8b3663f10ba3ad8c129f59fd15f105c7e918558b9650d554868d7c0f", nonce: "56", blockHash: "0x3e26d524663c3d0ee9c31b25da769b17bc88631be095d53bccfbbcd99313a42f", transactionIndex: "20", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223559", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000000000506172747920486174000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1070110", gasUsed: "223559", confirmations: "1055725"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x5061727479204861740000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x5061727479204861740000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541631423 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x5061727479204861740000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "47"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "47"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[48,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: adminsTokenCreation( addressList[4], \"500000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "6662836", timeStamp: "1541631423", hash: "0x670b881113a458f060aada7baa668ece4f572412bfee407329129caeefca5c7c", nonce: "57", blockHash: "0x3e26d524663c3d0ee9c31b25da769b17bc88631be095d53bccfbbcd99313a42f", transactionIndex: "50", from: "0x1ea2a567ad75da94c7e9ee2c462bdf1c407e811c", to: "0x6be9894bb589e7d7656a7805040144bbf157bbaf", value: "0", gas: "223431", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x2e354261000000000000000000000000e49a852bf55736d76b483632b9b78d04646cc15a00000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000000000506f74204861740000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2872337", gasUsed: "223431", confirmations: "1055725"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_receiver", value: addressList[4]}, {type: "uint256", name: "_price", value: "500000000000000000"}, {type: "uint8", name: "_type", value: "0"}, {type: "bytes32", name: "_name", value: "0x506f742048617400000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_url", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bool", name: "_isSnatchable", value: true}], name: "adminsTokenCreation", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "adminsTokenCreation(address,uint256,uint8,bytes32,bytes32,bool)" ]( addressList[4], "500000000000000000", "0", "0x506f742048617400000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541631423 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "Receiver", type: "address"}, {indexed: false, name: "Type", type: "uint8"}, {indexed: false, name: "Name", type: "bytes32"}, {indexed: false, name: "URL", type: "bytes32"}, {indexed: false, name: "TokenId", type: "uint256"}, {indexed: false, name: "IsSnatchable", type: "bool"}], name: "TokenCreated", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenCreated", events: [{name: "Receiver", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "Type", type: "uint8", value: "0"}, {name: "Name", type: "bytes32", value: "0x506f742048617400000000000000000000000000000000000000000000000000"}, {name: "URL", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "TokenId", type: "uint256", value: "48"}, {name: "IsSnatchable", type: "bool", value: true}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_from", type: "address"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xe49a852bf55736d76b483632b9b78d04646cc15a"}, {name: "_tokenId", type: "uint256", value: "48"}], address: "0x6be9894bb589e7d7656a7805040144bbf157bbaf"}] ;
		console.error( "eventResultOriginal[49,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4314503613081100" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
