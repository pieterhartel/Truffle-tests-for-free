var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "FireflyRegistrar"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0x6fC21092DA55B392b045eD78F4732bff3C580e2c","0xb346D5019EeafC028CfC01A5f789399C2314ae8D","0x314159265dD8dbb310642f98f50C066173C1259b","0x5FfC014343cd971B7eb70732021E26C35B744cc4","0x32DEF047DeFd076DB21A2D759aff2A591c972248","0x8ba1f109551bD432803012645Ac136ddd64DBA72","0xA133F78c4A3fFb2350EC14E81234A1657262Ca11","0xab80d5a55a6b284DfB08FCf3518f245EAfb0e478","0x3bDcd88A9639F85818Ed5A35E2ABf6292D9b0377","0xfa80552DA6c69cAe80a3B80c1Ac832Ae79A648Ee","0x831F0aa1b671cADe0078Eee53b4408059047439d","0x2d187c89a970820Cf621ae2D20E24F1C76143808","0x1dcD555127d109ffdb9D474705C63C9fD50d02E8","0xAf9e08F3020E624c945cC446e8759602049cB176","0x527904D0E438a00e00b089547FCa3C58B7E2924A","0x0B84731242D6d1E27b284e47d599470DDb5a307f","0x8C9E984F8fF1A31DA9A7A8b2b63e0478c8BE62a0","0x2c4A945C6B09F0bED3FeED7A44fC791D295746e1","0xeaB82790AB0Ab869411DCECbc900D21804A17168","0x7B2e78D4dFaABA045A167a70dA285E30E8FcA196","0xc2Ee030e67b99c77Cb2565Bb62E7f776Aab10a49","0x47BDE6E8E49adaA0Bb9A67c1BD2C578a73be7e7F","0xe7066E2Fb60A57E4a266008F33b2311f7Dbdc736","0x0904Dac3347eA47d208F3Fd67402D039a3b99859","0xeb0ABbAa88603628fE22768cB5daD7b5AE808B81","0x9937865e1c1737EdBE561DBC728d995DD663453F","0x457183a2aD85e5dE163B9CA5b2346D12728e2BCe","0xF0451aa5A002c6Ef5Fb2ECE769df0724122dc601","0x112b8EcDDf26E4066180556d65e560d5efC5A11E","0xa72C0f5C0f21D53b35FAdF49c68F969cf6C6b14A","0xB6d09AD065909c2f46C6E500017E4B71Cb49CF57","0x18C6045651826824FEBBD39d8560584078d1b247","0x2ff4d83d13fb20B88614FBe38AACEaAdAd9d53FC"]
addressListOriginal.length = 35
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"config","outputs":[{"name":"ens","type":"address"},{"name":"nodeHash","type":"bytes32"},{"name":"admin","type":"address"},{"name":"fee","type":"uint256"},{"name":"defaultResolver","type":"address"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"nodeHash","type":"bytes32"}],"name":"donations","outputs":[{"name":"donation","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"stats","outputs":[{"name":"nameCount","type":"uint256"},{"name":"totalPaid","type":"uint256"},{"name":"balance","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"fee","outputs":[{"name":"fee","type":"uint256"}],"payable":false,"type":"function"}]
eventPrototypeListOriginal = [{"anonymous":false,"inputs":[{"indexed":false,"name":"oldAdmin","type":"address"},{"indexed":false,"name":"newAdmin","type":"address"}],"name":"adminChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"oldFee","type":"uint256"},{"indexed":false,"name":"newFee","type":"uint256"}],"name":"feeChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"oldResolver","type":"address"},{"indexed":false,"name":"newResolver","type":"address"}],"name":"defaultResolverChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"target","type":"address"},{"indexed":false,"name":"amount","type":"uint256"}],"name":"didWithdraw","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"nodeHash","type":"bytes32"},{"indexed":false,"name":"owner","type":"address"},{"indexed":false,"name":"fee","type":"uint256"}],"name":"nameRegistered","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"nodeHash","type":"bytes32"},{"indexed":false,"name":"amount","type":"uint256"}],"name":"donation","type":"event"}]
eventSignatureListOriginal = ["adminChanged(address,address)","feeChanged(uint256,uint256)","defaultResolverChanged(address,address)","didWithdraw(address,uint256)","nameRegistered(bytes32,address,uint256)","donation(bytes32,uint256)"]
topicListOriginal = ["0xbadc9a52979e89f78b7c58309537410c5e51d0f63a0a455efe8d61d2b474e698","0x854231545a00e13c316c82155f2b8610d638e9ff6ebc4930676f84a5af08a49a","0x279875333405c968e401e3bc4e71d5f8e48728c90f4e8180ce28f74efb566920","0xac375770417e1cb46c89436efcf586a74d0298fee9838f66a38d40c65959ffda","0x179ef3319e6587f6efd3157b34c8b357141528074bcb03f9903589876168fa14","0xdb7750418f9fa390aaf85d881770065aa4adbe46343bcff4ae573754c829d9af"]
nBlocksOriginal = 50
fromBlockOriginal = 4097672
toBlockOriginal = 4345521
constructorPrototypeOriginal = {"inputs":[{"type":"address","name":"ens","value":4},{"type":"bytes32","name":"nodeHash","value":"0x2cb4cccf14a67aaaa2681ac6672fdf0074d7128cfbf2cfcab889ff4623125e49"},{"type":"address","name":"defaultResolver","value":5}],"name":"FireflyRegistrar","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"4097672","timeStamp":"1501468446","hash":"0x2ddf6dd2ec23adf525dac59d7c9189b25b172d679aad951e59e232045f2c811f","nonce":"0","blockHash":"0x7a9c5e758afa0f7651020b934aca811d0caba1762feea0efb3698050a240f67f","transactionIndex":"53","from":"0xb346d5019eeafc028cfc01a5f789399c2314ae8d","to":0,"value":"0","gas":"1500000","gasPrice":"1100000000","isError":"0","txreceipt_status":"","input":"0xaaec0c03000000000000000000000000314159265dd8dbb310642f98f50c066173c1259b2cb4cccf14a67aaaa2681ac6672fdf0074d7128cfbf2cfcab889ff4623125e490000000000000000000000005ffc014343cd971b7eb70732021e26c35b744cc4","contractAddress":"0x6fc21092da55b392b045ed78f4732bff3c580e2c","cumulativeGasUsed":"3410270","gasUsed":"1002852","confirmations":"3583101"}
txOptions[0] = {"from":"0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1","to":0,"value":"0"}
txCall[0] = {"inputs":[{"type":"address","name":"ens","value":"0xFFcf8FDEE72ac11b5c542428B35EEF5769C409f0"},{"type":"bytes32","name":"nodeHash","value":"0x2cb4cccf14a67aaaa2681ac6672fdf0074d7128cfbf2cfcab889ff4623125e49"},{"type":"address","name":"defaultResolver","value":"0x22d491Bde2303f2f43325b2108D26f1eAbA1e32b"}],"name":"FireflyRegistrar","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
