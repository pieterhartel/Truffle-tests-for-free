const FireflyRegistrar = artifacts.require( "./FireflyRegistrar.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "FireflyRegistrar" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x6fC21092DA55B392b045eD78F4732bff3C580e2c", "0xb346D5019EeafC028CfC01A5f789399C2314ae8D", "0x314159265dD8dbb310642f98f50C066173C1259b", "0x5FfC014343cd971B7eb70732021E26C35B744cc4", "0x32DEF047DeFd076DB21A2D759aff2A591c972248", "0x8ba1f109551bD432803012645Ac136ddd64DBA72", "0xA133F78c4A3fFb2350EC14E81234A1657262Ca11", "0xab80d5a55a6b284DfB08FCf3518f245EAfb0e478", "0x3bDcd88A9639F85818Ed5A35E2ABf6292D9b0377", "0xfa80552DA6c69cAe80a3B80c1Ac832Ae79A648Ee", "0x831F0aa1b671cADe0078Eee53b4408059047439d", "0x2d187c89a970820Cf621ae2D20E24F1C76143808", "0x1dcD555127d109ffdb9D474705C63C9fD50d02E8", "0xAf9e08F3020E624c945cC446e8759602049cB176", "0x527904D0E438a00e00b089547FCa3C58B7E2924A", "0x0B84731242D6d1E27b284e47d599470DDb5a307f", "0x8C9E984F8fF1A31DA9A7A8b2b63e0478c8BE62a0", "0x2c4A945C6B09F0bED3FeED7A44fC791D295746e1", "0xeaB82790AB0Ab869411DCECbc900D21804A17168", "0x7B2e78D4dFaABA045A167a70dA285E30E8FcA196", "0xc2Ee030e67b99c77Cb2565Bb62E7f776Aab10a49", "0x47BDE6E8E49adaA0Bb9A67c1BD2C578a73be7e7F", "0xe7066E2Fb60A57E4a266008F33b2311f7Dbdc736", "0x0904Dac3347eA47d208F3Fd67402D039a3b99859", "0xeb0ABbAa88603628fE22768cB5daD7b5AE808B81", "0x9937865e1c1737EdBE561DBC728d995DD663453F", "0x457183a2aD85e5dE163B9CA5b2346D12728e2BCe", "0xF0451aa5A002c6Ef5Fb2ECE769df0724122dc601", "0x112b8EcDDf26E4066180556d65e560d5efC5A11E", "0xa72C0f5C0f21D53b35FAdF49c68F969cf6C6b14A", "0xB6d09AD065909c2f46C6E500017E4B71Cb49CF57", "0x18C6045651826824FEBBD39d8560584078d1b247", "0x2ff4d83d13fb20B88614FBe38AACEaAdAd9d53FC"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "config", outputs: [{name: "ens", type: "address"}, {name: "nodeHash", type: "bytes32"}, {name: "admin", type: "address"}, {name: "fee", type: "uint256"}, {name: "defaultResolver", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "nodeHash", type: "bytes32"}], name: "donations", outputs: [{name: "donation", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "stats", outputs: [{name: "nameCount", type: "uint256"}, {name: "totalPaid", type: "uint256"}, {name: "balance", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "fee", outputs: [{name: "fee", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "oldAdmin", type: "address"}, {indexed: false, name: "newAdmin", type: "address"}], name: "adminChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "oldFee", type: "uint256"}, {indexed: false, name: "newFee", type: "uint256"}], name: "feeChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "oldResolver", type: "address"}, {indexed: false, name: "newResolver", type: "address"}], name: "defaultResolverChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "target", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "didWithdraw", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["adminChanged(address,address)", "feeChanged(uint256,uint256)", "defaultResolverChanged(address,address)", "didWithdraw(address,uint256)", "nameRegistered(bytes32,address,uint256)", "donation(bytes32,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xbadc9a52979e89f78b7c58309537410c5e51d0f63a0a455efe8d61d2b474e698", "0x854231545a00e13c316c82155f2b8610d638e9ff6ebc4930676f84a5af08a49a", "0x279875333405c968e401e3bc4e71d5f8e48728c90f4e8180ce28f74efb566920", "0xac375770417e1cb46c89436efcf586a74d0298fee9838f66a38d40c65959ffda", "0x179ef3319e6587f6efd3157b34c8b357141528074bcb03f9903589876168fa14", "0xdb7750418f9fa390aaf85d881770065aa4adbe46343bcff4ae573754c829d9af"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4097672 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4345521 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "ens", value: 4}, {type: "bytes32", name: "nodeHash", value: "0x2cb4cccf14a67aaaa2681ac6672fdf0074d7128cfbf2cfcab889ff4623125e49"}, {type: "address", name: "defaultResolver", value: 5}], name: "FireflyRegistrar", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "config", outputs: [{name: "ens", type: "address"}, {name: "nodeHash", type: "bytes32"}, {name: "admin", type: "address"}, {name: "fee", type: "uint256"}, {name: "defaultResolver", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "config()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "nodeHash", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "donations", outputs: [{name: "donation", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "donations(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "stats", outputs: [{name: "nameCount", type: "uint256"}, {name: "totalPaid", type: "uint256"}, {name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "stats()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "fee", outputs: [{name: "fee", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "FireflyRegistrar", function( accounts ) {

	it( "TEST: FireflyRegistrar( addressList[4], \"0x2cb4cccf14a67aaaa268... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4097672", timeStamp: "1501468446", hash: "0x2ddf6dd2ec23adf525dac59d7c9189b25b172d679aad951e59e232045f2c811f", nonce: "0", blockHash: "0x7a9c5e758afa0f7651020b934aca811d0caba1762feea0efb3698050a240f67f", transactionIndex: "53", from: "0xb346d5019eeafc028cfc01a5f789399c2314ae8d", to: 0, value: "0", gas: "1500000", gasPrice: "1100000000", isError: "0", txreceipt_status: "", input: "0xaaec0c03000000000000000000000000314159265dd8dbb310642f98f50c066173c1259b2cb4cccf14a67aaaa2681ac6672fdf0074d7128cfbf2cfcab889ff4623125e490000000000000000000000005ffc014343cd971b7eb70732021e26c35b744cc4", contractAddress: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", cumulativeGasUsed: "3410270", gasUsed: "1002852", confirmations: "3583101"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "ens", value: addressList[4]}, {type: "bytes32", name: "nodeHash", value: "0x2cb4cccf14a67aaaa2681ac6672fdf0074d7128cfbf2cfcab889ff4623125e49"}, {type: "address", name: "defaultResolver", value: addressList[5]}], name: "FireflyRegistrar", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = FireflyRegistrar.new( addressList[4], "0x2cb4cccf14a67aaaa2681ac6672fdf0074d7128cfbf2cfcab889ff4623125e49", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1501468446 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = FireflyRegistrar.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4197067495300000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: register( `ricmoo` )", async function( ) {
		const txOriginal = {blockNumber: "4097745", timeStamp: "1501469675", hash: "0xccc90ab97a74c952fb3376c4a3efb566a58a10df62eb4d44a61e106fcf10ec61", nonce: "0", blockHash: "0x9653f180a5720f3634816eb945a6d722adee52cc47526f6357ac10adaf368135", transactionIndex: "18", from: "0x32def047defd076db21a2d759aff2a591c972248", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "110000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000067269636d6f6f0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1036884", gasUsed: "176061", confirmations: "3583028"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "110000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `ricmoo`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `ricmoo`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1501469675 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[1,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x0bcad17ecf260d6506c6b97768bdc2acfb6694445d27ffd3f9c1cfbee4a9bd6d"}, {name: "owner", type: "address", value: "0x32def047defd076db21a2d759aff2a591c972248"}, {name: "fee", type: "uint256", value: "110000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[1,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[1,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x0bcad17ecf260d6506c6b97768bdc2acfb6694445d27ffd3f9c1cfbee4a9bd6d"}, {name: "amount", type: "uint256", value: "110000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[1,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "3627972450502088317" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( addressList[6], \"110000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4097750", timeStamp: "1501469878", hash: "0xf1bedbf49b057bba396fa6a1da8b7786f2bb9e5fb6c9cc0d7c2ca4c9ae9392a1", nonce: "5", blockHash: "0x71fee04cd73cb37361a9e53a0603ddfbd5aa09c84a14af03e63074fdd4aa49d9", transactionIndex: "62", from: "0xb346d5019eeafc028cfc01a5f789399c2314ae8d", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "0", gas: "1500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xf3fef3a300000000000000000000000032def047defd076db21a2d759aff2a591c9722480000000000000000000000000000000000000000000000000186cc6acd4b0000", contractAddress: "", cumulativeGasUsed: "2252507", gasUsed: "32953", confirmations: "3583023"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[6]}, {type: "uint256", name: "amount", value: "110000000000000000"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(address,uint256)" ]( addressList[6], "110000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1501469878 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "target", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "didWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "didWithdraw", events: [{name: "target", type: "address", value: "0x32def047defd076db21a2d759aff2a591c972248"}, {name: "amount", type: "uint256", value: "110000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4197067495300000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: register( `donations` )", async function( ) {
		const txOriginal = {blockNumber: "4100390", timeStamp: "1501518321", hash: "0xed5b9dbf5c4bbe2671794a468b913cfa9006490ce4a75325e03126db8340322d", nonce: "1", blockHash: "0xd662fda6c04d70ff2dee753bc5f4766da9abbf19ce5eb208afc9005d1b467add", transactionIndex: "70", from: "0x32def047defd076db21a2d759aff2a591c972248", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000009646f6e6174696f6e730000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4103119", gasUsed: "146811", confirmations: "3580383"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `donations`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `donations`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1501518321 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[3,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x734813bb58a408806871a98fdb7f096287c7a65784c701969ab0cc03b46760fa"}, {name: "owner", type: "address", value: "0x32def047defd076db21a2d759aff2a591c972248"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[3,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[3,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x734813bb58a408806871a98fdb7f096287c7a65784c701969ab0cc03b46760fa"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[3,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "3627972450502088317" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: register( `donate` )", async function( ) {
		const txOriginal = {blockNumber: "4104781", timeStamp: "1501611291", hash: "0xa3899655252482ca3b890d30be95e310f6fb1dc7b551bf4a622835e999d061e6", nonce: "2", blockHash: "0x3f94d9a124c2b023ddfb100e3114219559b4bffa040719e8d59c81494ed85a1a", transactionIndex: "21", from: "0x32def047defd076db21a2d759aff2a591c972248", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000006646f6e6174650000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1150923", gasUsed: "146061", confirmations: "3575992"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `donate`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `donate`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1501611291 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[4,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x8df41447755660c2e2472e4492ac1a3a0c961475460977bff75c3bae48d34e24"}, {name: "owner", type: "address", value: "0x32def047defd076db21a2d759aff2a591c972248"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[4,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[4,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x8df41447755660c2e2472e4492ac1a3a0c961475460977bff75c3bae48d34e24"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[4,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "3627972450502088317" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: register( `register` )", async function( ) {
		const txOriginal = {blockNumber: "4104793", timeStamp: "1501611543", hash: "0x50cba1e176c214a2013af770bd870e0fa02835dd905cef0eed7c566cadcfcb85", nonce: "3", blockHash: "0xcf81995137dfabddcf4394161356b747004cd951c28f8562d22495e9a0311c30", transactionIndex: "31", from: "0x32def047defd076db21a2d759aff2a591c972248", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000087265676973746572000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1190485", gasUsed: "146561", confirmations: "3575980"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `register`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `register`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1501611543 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[5,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x91bf5cf2188f11630436cdce892edafc7fcfb66e65325eee62d79a04d1e81a6b"}, {name: "owner", type: "address", value: "0x32def047defd076db21a2d759aff2a591c972248"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[5,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[5,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x91bf5cf2188f11630436cdce892edafc7fcfb66e65325eee62d79a04d1e81a6b"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[5,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "3627972450502088317" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: register( `admin` )", async function( ) {
		const txOriginal = {blockNumber: "4104799", timeStamp: "1501611628", hash: "0x7b78af421fc0b56d7559edeaa76e3d771bacfeeb08cb6f37d3b3bc18ae93c6ab", nonce: "4", blockHash: "0x259f062beab7cefeba388bbfd748f837d3c5d736d8583a4a35f714b3c6d309c8", transactionIndex: "16", from: "0x32def047defd076db21a2d759aff2a591c972248", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000561646d696e000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "908689", gasUsed: "145811", confirmations: "3575974"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `admin`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `admin`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1501611628 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[6,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xb9dd04d606e713ab3286e5eea17208310967b5c57f61d8863f570e503cb88bcb"}, {name: "owner", type: "address", value: "0x32def047defd076db21a2d759aff2a591c972248"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[6,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[6,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xb9dd04d606e713ab3286e5eea17208310967b5c57f61d8863f570e503cb88bcb"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[6,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "3627972450502088317" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: register( `yuetloo` )", async function( ) {
		const txOriginal = {blockNumber: "4104804", timeStamp: "1501611775", hash: "0x81fdd4b12b9c8f7cf6add6a88f77820e602fcf0735774ab9be04b857157f641d", nonce: "5", blockHash: "0xde0e05af796b5ea09175276e688900285a13e17a5a20ef20a133940a439784a6", transactionIndex: "47", from: "0x32def047defd076db21a2d759aff2a591c972248", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000007797565746c6f6f00000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2178101", gasUsed: "146311", confirmations: "3575969"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `yuetloo`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `yuetloo`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1501611775 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x313095efbbe583dd90317ad2c7c751cd9007f499c661f798d7252580ba0269b2"}, {name: "owner", type: "address", value: "0x32def047defd076db21a2d759aff2a591c972248"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[7,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x313095efbbe583dd90317ad2c7c751cd9007f499c661f798d7252580ba0269b2"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[7,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "3627972450502088317" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: register( `yuet` )", async function( ) {
		const txOriginal = {blockNumber: "4104822", timeStamp: "1501612246", hash: "0xb8c259f53ed12a4913c01563b5173d7c51c356057db0aa64f3627e27b304dea7", nonce: "6", blockHash: "0x9a1ebfc2deccad3edd8d080eab70ed85fbacbdb6000394aca2a34650c8eff0c3", transactionIndex: "39", from: "0x32def047defd076db21a2d759aff2a591c972248", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000047975657400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1288819", gasUsed: "145561", confirmations: "3575951"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `yuet`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `yuet`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1501612246 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[8,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xd5c5c9e4918c9c04eb8c94a612ae4dae9b5bce83cb619b7b7b477f4fe34c2f48"}, {name: "owner", type: "address", value: "0x32def047defd076db21a2d759aff2a591c972248"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[8,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[8,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xd5c5c9e4918c9c04eb8c94a612ae4dae9b5bce83cb619b7b7b477f4fe34c2f48"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[8,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "3627972450502088317" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: register( `metamask` )", async function( ) {
		const txOriginal = {blockNumber: "4105099", timeStamp: "1501617746", hash: "0x2adbbda19739052c63303e2f653458922fd79d3671f19a8ef18e8985865fcf82", nonce: "0", blockHash: "0xb4d22d972dbcff4ca2d54d42c167e01cfd4ccef74fbd012269f9ccc1755cde77", transactionIndex: "93", from: "0x8ba1f109551bd432803012645ac136ddd64dba72", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "219841", gasPrice: "1100000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000086d6574616d61736b000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3514896", gasUsed: "146561", confirmations: "3575674"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `metamask`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `metamask`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1501617746 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[9,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x81cd81a6310196976fb8f6abb0461437ffc5811f3fd8fd7d714faf995a7d1f9d"}, {name: "owner", type: "address", value: "0x8ba1f109551bd432803012645ac136ddd64dba72"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[9,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[9,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x81cd81a6310196976fb8f6abb0461437ffc5811f3fd8fd7d714faf995a7d1f9d"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[9,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "9335807334305804448" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: register( `jaxx` )", async function( ) {
		const txOriginal = {blockNumber: "4105115", timeStamp: "1501618061", hash: "0xe1251835d966ea85037b3c62bf584d587e3dab237b1293af9b3985520af7850f", nonce: "0", blockHash: "0x8e6398ba23a307264b13021653578413f9c4455697f5153b23acae27c7813357", transactionIndex: "21", from: "0xa133f78c4a3ffb2350ec14e81234a1657262ca11", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000046a61787800000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "632761", gasUsed: "145561", confirmations: "3575658"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `jaxx`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `jaxx`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1501618061 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x6f1e65d4f586af95db670204f9bc808168494f7032db4f8832a43f2ee0416872"}, {name: "owner", type: "address", value: "0xa133f78c4a3ffb2350ec14e81234a1657262ca11"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[10,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x6f1e65d4f586af95db670204f9bc808168494f7032db4f8832a43f2ee0416872"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[10,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "6943219000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: register( `josh` )", async function( ) {
		const txOriginal = {blockNumber: "4105123", timeStamp: "1501618202", hash: "0x252198d7f63ece726f4ba58974db6847bb7b6ce87a4e8f390f9c5b56ac38b462", nonce: "35", blockHash: "0x63835b851e5881b22a8d818b73ca5ca507eb35895b7852dcb9ca273a6f106c03", transactionIndex: "26", from: "0xab80d5a55a6b284dfb08fcf3518f245eafb0e478", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000046a6f736800000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "967446", gasUsed: "145561", confirmations: "3575650"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `josh`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `josh`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1501618202 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x262ad9541898f8a473d3d5ade8fa7b8fea7a3b6808780b7a7df7013ab56f3572"}, {name: "owner", type: "address", value: "0xab80d5a55a6b284dfb08fcf3518f245eafb0e478"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[11,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x262ad9541898f8a473d3d5ade8fa7b8fea7a3b6808780b7a7df7013ab56f3572"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[11,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "237581273000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( addressList[3], \"500000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4105215", timeStamp: "1501619939", hash: "0x5ac42f86dea90adb14c6f287587c064342b29c57f0f5fe8ea03a21aed8a0a6ca", nonce: "6", blockHash: "0x3b9d08a50406bf461fda462d86fe54baa08b47249b86151194694da60200da0f", transactionIndex: "14", from: "0xb346d5019eeafc028cfc01a5f789399c2314ae8d", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "0", gas: "1500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf3fef3a3000000000000000000000000b346d5019eeafc028cfc01a5f789399c2314ae8d00000000000000000000000000000000000000000000000006f05b59d3b20000", contractAddress: "", cumulativeGasUsed: "521624", gasUsed: "32953", confirmations: "3575558"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "target", value: addressList[3]}, {type: "uint256", name: "amount", value: "500000000000000000"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(address,uint256)" ]( addressList[3], "500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1501619939 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "target", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "didWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "didWithdraw", events: [{name: "target", type: "address", value: "0xb346d5019eeafc028cfc01a5f789399c2314ae8d"}, {name: "amount", type: "uint256", value: "500000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4197067495300000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: register( `jeff` )", async function( ) {
		const txOriginal = {blockNumber: "4105341", timeStamp: "1501622943", hash: "0x974a204442c4e674b47bef3937fa1b9d300f1639540bc48068e893bc3712dad0", nonce: "83", blockHash: "0x8c33df6cf6e525159ac5a0248f352f8c3edb058bcfdc64d1716528d6e55211cc", transactionIndex: "99", from: "0x3bdcd88a9639f85818ed5a35e2abf6292d9b0377", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000046a65666600000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3510252", gasUsed: "145561", confirmations: "3575432"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `jeff`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `jeff`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1501622943 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x7f4ef85e44778bb314915f738d7fa9c0d3434dc1b279d56480dfc8106b5024d0"}, {name: "owner", type: "address", value: "0x3bdcd88a9639f85818ed5a35e2abf6292d9b0377"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[13,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x7f4ef85e44778bb314915f738d7fa9c0d3434dc1b279d56480dfc8106b5024d0"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[13,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "164989628692777777777" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: register( `donation` )", async function( ) {
		const txOriginal = {blockNumber: "4108036", timeStamp: "1501681237", hash: "0x860e95c630a9667da3217651fe80f44af5982b341a3ba2c1bd9efeca6e2f8d1e", nonce: "8", blockHash: "0xd2e7fa478f89da73b2544ba71f196e9799fef7d764fae59f72fa1976166a39ca", transactionIndex: "88", from: "0x32def047defd076db21a2d759aff2a591c972248", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000008646f6e6174696f6e000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3202478", gasUsed: "146561", confirmations: "3572737"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `donation`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `donation`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1501681237 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x4cd25f427b7ca64a370cb7a9673256b91006610a3891425d89602962ff239a97"}, {name: "owner", type: "address", value: "0x32def047defd076db21a2d759aff2a591c972248"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[14,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x4cd25f427b7ca64a370cb7a9673256b91006610a3891425d89602962ff239a97"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[14,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "3627972450502088317" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: register( `firefly` )", async function( ) {
		const txOriginal = {blockNumber: "4108226", timeStamp: "1501685021", hash: "0x3c35485e2e4adccc32f92676cea4c27869fb1192ac6ef0fb1d660afaf12bbbad", nonce: "23", blockHash: "0x0e7db32527c9915c2322102e931ba5671b96b61d8e18e8d027913f5608e5ddfc", transactionIndex: "2", from: "0xfa80552da6c69cae80a3b80c1ac832ae79a648ee", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "60000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000766697265666c7900000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "188311", gasUsed: "146311", confirmations: "3572547"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `firefly`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `firefly`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1501685021 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[15,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x55c0c272e42467ff5e7dfecff3b3448b487e2a84f17bc3751261169ac9d07988"}, {name: "owner", type: "address", value: "0xfa80552da6c69cae80a3b80c1ac832ae79a648ee"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[15,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[15,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x55c0c272e42467ff5e7dfecff3b3448b487e2a84f17bc3751261169ac9d07988"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[15,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "209220319564448873" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: register( `ethan` )", async function( ) {
		const txOriginal = {blockNumber: "4108254", timeStamp: "1501685750", hash: "0x79980d4923bfa5e4133345b9577287059f45955b86f827c0bb6b5c7603e0d0f0", nonce: "31", blockHash: "0x3af60828c9eea03190308a192f62697d660f5cfae41bdcb7c2b0181adfd67e4b", transactionIndex: "95", from: "0x831f0aa1b671cade0078eee53b4408059047439d", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "218718", gasPrice: "1100000000", isError: "0", txreceipt_status: "", input: "0xf2c298be00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000005657468616e000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2699726", gasUsed: "145811", confirmations: "3572519"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `ethan`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `ethan`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1501685750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[16,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x70d19c2df954823506eb06410d8606af9845d050f40ce19b96ed26a8dec47e8b"}, {name: "owner", type: "address", value: "0x831f0aa1b671cade0078eee53b4408059047439d"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[16,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[16,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x70d19c2df954823506eb06410d8606af9845d050f40ce19b96ed26a8dec47e8b"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[16,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "45339183035556575608" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: register( `info` )", async function( ) {
		const txOriginal = {blockNumber: "4108259", timeStamp: "1501685850", hash: "0x07fc25e7b22f20650f08f67ec5812a1feb3fb8887f4246ec166529bf63630be4", nonce: "32", blockHash: "0x3ef9140c0e75f99e1a2e1b006f8602c8e109e6d593fb5a83faeed5129cff0092", transactionIndex: "35", from: "0x831f0aa1b671cade0078eee53b4408059047439d", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "218343", gasPrice: "1100000000", isError: "0", txreceipt_status: "", input: "0xf2c298be00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004696e666f00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "983282", gasUsed: "145561", confirmations: "3572514"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `info`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `info`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1501685850 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[17,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x96c7dd8e33bddac3bd5da59f8c3b11eb9a37e2084d7cc28d56b48024f3e01e2b"}, {name: "owner", type: "address", value: "0x831f0aa1b671cade0078eee53b4408059047439d"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[17,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[17,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x96c7dd8e33bddac3bd5da59f8c3b11eb9a37e2084d7cc28d56b48024f3e01e2b"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[17,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "45339183035556575608" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: register( `ethereum` )", async function( ) {
		const txOriginal = {blockNumber: "4108266", timeStamp: "1501685992", hash: "0xea19ec7f5611918b9097aa05a1e4e3427cdb629156de5eb85193992d2a9facef", nonce: "33", blockHash: "0x6fe84f018f8350d03ae5a92c6a08aae7e8d3d1f7ace7f7af877383a39231caff", transactionIndex: "40", from: "0x831f0aa1b671cade0078eee53b4408059047439d", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "219841", gasPrice: "1100000000", isError: "0", txreceipt_status: "", input: "0xf2c298be00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000008657468657265756d000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1206420", gasUsed: "146561", confirmations: "3572507"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `ethereum`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `ethereum`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1501685992 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x0805cefe9685a835b23016dd66b4a784de11b78ad278c58240028787740016c8"}, {name: "owner", type: "address", value: "0x831f0aa1b671cade0078eee53b4408059047439d"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[18,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x0805cefe9685a835b23016dd66b4a784de11b78ad278c58240028787740016c8"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[18,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "45339183035556575608" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: register( `ether` )", async function( ) {
		const txOriginal = {blockNumber: "4108310", timeStamp: "1501686623", hash: "0x22b4e8096c7ecd783119d609236dc76199f9f8dc92a9484da466aaf629fbba13", nonce: "34", blockHash: "0x6a450c45ec5f1b2de95ea24f720a25162f1ac8f1fd9e21e210e9d3453d2fbb2e", transactionIndex: "31", from: "0x831f0aa1b671cade0078eee53b4408059047439d", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "218718", gasPrice: "1100000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000056574686572000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1517182", gasUsed: "145811", confirmations: "3572463"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `ether`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `ether`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1501686623 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x3b0359a22a9dc36020c34c8d82113c303e1042b782b6911aaa5768a5ae76ce3b"}, {name: "owner", type: "address", value: "0x831f0aa1b671cade0078eee53b4408059047439d"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[19,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x3b0359a22a9dc36020c34c8d82113c303e1042b782b6911aaa5768a5ae76ce3b"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[19,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "45339183035556575608" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: register( `wallet` )", async function( ) {
		const txOriginal = {blockNumber: "4108310", timeStamp: "1501686623", hash: "0x31fbe0eb17add21d799eb988f60613f516b0bcac0eb20f7882bc90975318929d", nonce: "35", blockHash: "0x6a450c45ec5f1b2de95ea24f720a25162f1ac8f1fd9e21e210e9d3453d2fbb2e", transactionIndex: "42", from: "0x831f0aa1b671cade0078eee53b4408059047439d", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "219093", gasPrice: "1100000000", isError: "0", txreceipt_status: "", input: "0xf2c298be0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000677616c6c65740000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2274489", gasUsed: "146061", confirmations: "3572463"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `wallet`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `wallet`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1501686623 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[20,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x5021f95362197eb27b57895b3896cfa459a4e354f178a93266391edf4a400ced"}, {name: "owner", type: "address", value: "0x831f0aa1b671cade0078eee53b4408059047439d"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[20,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[20,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x5021f95362197eb27b57895b3896cfa459a4e354f178a93266391edf4a400ced"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[20,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "45339183035556575608" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: register( `nestorcano` )", async function( ) {
		const txOriginal = {blockNumber: "4108553", timeStamp: "1501691590", hash: "0x2c86c3f51d2920340929ed65706d80c4995d950240210e0aa691dcf65db0d1de", nonce: "1", blockHash: "0x9872a081d15dcb59ce9621753467180b32f777de5c02c3f487a1d804891a3784", transactionIndex: "53", from: "0x2d187c89a970820cf621ae2d20e24f1c76143808", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a6e6573746f7263616e6f00000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2024865", gasUsed: "147061", confirmations: "3572220"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `nestorcano`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `nestorcano`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1501691590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xed0ff99a5e760780b3a90d61a253fc0917afdc55bd6b5d5e273c503cd5f6ff63"}, {name: "owner", type: "address", value: "0x2d187c89a970820cf621ae2d20e24f1c76143808"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[21,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xed0ff99a5e760780b3a90d61a253fc0917afdc55bd6b5d5e273c503cd5f6ff63"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[21,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "11000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: register( `john` )", async function( ) {
		const txOriginal = {blockNumber: "4108958", timeStamp: "1501700392", hash: "0xda238ea213167f4f97a2230b7cb59ed542df09b4d1a0a3be7cfb54bd2cd78989", nonce: "0", blockHash: "0x1908d265e1981315f81a8c5114b310e3e91ee3293034cdd694de5fad5a1911a5", transactionIndex: "66", from: "0x1dcd555127d109ffdb9d474705c63c9fd50d02e8", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "218343", gasPrice: "1100000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000046a6f686e00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2919163", gasUsed: "145561", confirmations: "3571815"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `john`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `john`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1501700392 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x43efbcb7b0e0b6b476f2a149aa415ff5f3def2ebb44ec44b55dc4a46cf5a788c"}, {name: "owner", type: "address", value: "0x1dcd555127d109ffdb9d474705c63c9fd50d02e8"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[22,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x43efbcb7b0e0b6b476f2a149aa415ff5f3def2ebb44ec44b55dc4a46cf5a788c"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[22,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "76975737138455789" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: register( `pamparam` )", async function( ) {
		const txOriginal = {blockNumber: "4109213", timeStamp: "1501705880", hash: "0x36b30e26cd8a59abe3f6569c24368b2c556bb23016207917bac37a738f1cebd2", nonce: "151", blockHash: "0x949fb0619ff3f77c2a4b607c3d86a74eb5c0268030e3d90cd83957f51030f4ec", transactionIndex: "31", from: "0xaf9e08f3020e624c945cc446e8759602049cb176", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "600000001", isError: "0", txreceipt_status: "", input: "0xf2c298be0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000870616d706172616d000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5390766", gasUsed: "146561", confirmations: "3571560"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `pamparam`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `pamparam`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1501705880 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xfd4e74e858c847ba550f9b6150cdc447c9da69e0da0b40e4bdb9724819a5bd46"}, {name: "owner", type: "address", value: "0xaf9e08f3020e624c945cc446e8759602049cb176"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[23,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xfd4e74e858c847ba550f9b6150cdc447c9da69e0da0b40e4bdb9724819a5bd46"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[23,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "40406291972936486" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: register( `phil` )", async function( ) {
		const txOriginal = {blockNumber: "4109978", timeStamp: "1501721579", hash: "0x77879d451e99e788f586e4805dc68af2c3dd40e618ba24d46e730c5b0091fd60", nonce: "8", blockHash: "0x36210b31dcdf08f72096e0c901a34974395c9669e6f4518248db855ee1f47539", transactionIndex: "38", from: "0x527904d0e438a00e00b089547fca3c58b7e2924a", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000047068696c00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2004720", gasUsed: "145561", confirmations: "3570795"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `phil`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `phil`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1501721579 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[24,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xc5ccb489f827ef96d75e0228a3c12d5cb04568ba279fd93a046d39f219582297"}, {name: "owner", type: "address", value: "0x527904d0e438a00e00b089547fca3c58b7e2924a"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[24,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[24,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xc5ccb489f827ef96d75e0228a3c12d5cb04568ba279fd93a046d39f219582297"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[24,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "435033102000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: register( `chris` )", async function( ) {
		const txOriginal = {blockNumber: "4110132", timeStamp: "1501725253", hash: "0xee9e8a48bbdc1ce6ae95ccdbc1c74d6113c32d3a93a747702d530330eeb23f8a", nonce: "9", blockHash: "0xbf51b6251ab43dde339e7ea66490c54185496543b1ef3900146f3f3b0e9327f6", transactionIndex: "131", from: "0x0b84731242d6d1e27b284e47d599470ddb5a307f", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "218718", gasPrice: "1000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000056368726973000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3523978", gasUsed: "145811", confirmations: "3570641"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `chris`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `chris`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1501725253 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xa6ba2185f7e11c55b21a60a0a09d68a5694134a24f98718d9cb2b88aaa849395"}, {name: "owner", type: "address", value: "0x0b84731242d6d1e27b284e47d599470ddb5a307f"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[25,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xa6ba2185f7e11c55b21a60a0a09d68a5694134a24f98718d9cb2b88aaa849395"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[25,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "7900002021701284" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: register( `yebyen` )", async function( ) {
		const txOriginal = {blockNumber: "4110248", timeStamp: "1501727822", hash: "0xb6115c7d2ea18537af9a0af192087066ecdccf85e999fe8e7b3ce37ee5b8d78a", nonce: "0", blockHash: "0xa890d1c91cb1e16d232de8415612bae1ccd4d6fca4e65d8df452a972305fa9fe", transactionIndex: "61", from: "0x8c9e984f8ff1a31da9a7a8b2b63e0478c8be62a0", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000679656279656e0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2235353", gasUsed: "146061", confirmations: "3570525"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `yebyen`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `yebyen`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1501727822 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xc3d477d055afcd85bfef943ca78dfb3bdf1546910183d716002923469c664c6a"}, {name: "owner", type: "address", value: "0x8c9e984f8ff1a31da9a7a8b2b63e0478c8be62a0"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[26,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xc3d477d055afcd85bfef943ca78dfb3bdf1546910183d716002923469c664c6a"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[26,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "187349000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: register( `thorn` )", async function( ) {
		const txOriginal = {blockNumber: "4110533", timeStamp: "1501734343", hash: "0x17017c7250e3b7fe935d273be71f942c16b58a9ee9860441d47b19d3e444ca29", nonce: "0", blockHash: "0x10967f6ada2f31fcff6347b446623c6caaf07db4edc8816b3798aa6edf216bdb", transactionIndex: "8", from: "0x2c4a945c6b09f0bed3feed7a44fc791d295746e1", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "218716", gasPrice: "1100000000", isError: "0", txreceipt_status: "", input: "0xf2c298be0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000574686f726e000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "598981", gasUsed: "145811", confirmations: "3570240"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `thorn`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `thorn`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1501734343 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xaaa2a49a5ad8d10801144a7aa8def53e938452465cfccacd212cd397156f3db9"}, {name: "owner", type: "address", value: "0x2c4a945c6b09f0bed3feed7a44fc791d295746e1"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[27,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xaaa2a49a5ad8d10801144a7aa8def53e938452465cfccacd212cd397156f3db9"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[27,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "108839607900000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: register( `lafudoci` )", async function( ) {
		const txOriginal = {blockNumber: "4110693", timeStamp: "1501738511", hash: "0xba22781a46b02f773cbf11eceec34d44c2858900c2626d05778c2194e00c785e", nonce: "13", blockHash: "0x5f3eb75a5d711bc224386d73ac0195e36ca95450757fadc9d1a9a97d7131c74b", transactionIndex: "107", from: "0xeab82790ab0ab869411dcecbc900d21804a17168", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "150000000000000000", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000086c616675646f6369000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5214285", gasUsed: "146561", confirmations: "3570080"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "150000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `lafudoci`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `lafudoci`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1501738511 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[28,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xb1774b97db8619fc02f2e583f84ba8d87d2c5376a9db0ba2c5c82bbbea825b16"}, {name: "owner", type: "address", value: "0xeab82790ab0ab869411dcecbc900d21804a17168"}, {name: "fee", type: "uint256", value: "150000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[28,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[28,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xb1774b97db8619fc02f2e583f84ba8d87d2c5376a9db0ba2c5c82bbbea825b16"}, {name: "amount", type: "uint256", value: "150000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[28,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: register( `koeppelmann` )", async function( ) {
		const txOriginal = {blockNumber: "4111131", timeStamp: "1501748490", hash: "0x008ade39cbecdfe8603ebeb38586918ab3d7937f75b7280b0bc120de5b07fa69", nonce: "183", blockHash: "0xb228062ed1326d1e701d28d982b59a82b5b12e70db05f317258c43c93ce6692b", transactionIndex: "50", from: "0x7b2e78d4dfaaba045a167a70da285e30e8fca196", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "500000000000000000", gas: "220968", gasPrice: "1100000000", isError: "0", txreceipt_status: "", input: "0xf2c298be0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b6b6f657070656c6d616e6e000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4241098", gasUsed: "147311", confirmations: "3569642"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `koeppelmann`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `koeppelmann`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1501748490 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xb6d9049785594a644aa49dcc95adb00d1ebdb73ef2bfdbc4275441ae64831875"}, {name: "owner", type: "address", value: "0x7b2e78d4dfaaba045a167a70da285e30e8fca196"}, {name: "fee", type: "uint256", value: "500000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[29,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xb6d9049785594a644aa49dcc95adb00d1ebdb73ef2bfdbc4275441ae64831875"}, {name: "amount", type: "uint256", value: "500000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[29,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "2697713149755197688" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4112734", timeStamp: "1501782102", hash: "0xec1840d837f643af021be323c6c2f674c1357a8cf0739116163198bb75a7784f", nonce: "0", blockHash: "0x7ccfe9356cf912cc8ae1573eea333b7a2bced010630033f9becebbe956b2a329", transactionIndex: "76", from: "0xc2ee030e67b99c77cb2565bb62e7f776aab10a49", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "25000", gasPrice: "4000000000", isError: "1", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "2974639", gasUsed: "25000", confirmations: "3568039"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4112741", timeStamp: "1501782281", hash: "0x5eb764437b11cdcfa482e887dffa5b72ca02c5c8ef66f33d0da4952811885933", nonce: "1", blockHash: "0x34338d14a248e5e1bf63caf6e0b3ee621c0ffc9fa989301a3c3e893f05cf57d5", transactionIndex: "59", from: "0xc2ee030e67b99c77cb2565bb62e7f776aab10a49", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "42000", gasPrice: "4000000000", isError: "1", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "2153586", gasUsed: "42000", confirmations: "3568032"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4112745", timeStamp: "1501782432", hash: "0x19e20ec572d001ec5684c76a1b25099b031797605515f3f5ae73f7b3ebb01ab9", nonce: "2", blockHash: "0x58f9fdd964267d925f49a3e5cb1399936c89f9f58f8bac821267f922e98cdc6f", transactionIndex: "46", from: "0xc2ee030e67b99c77cb2565bb62e7f776aab10a49", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "1812424", gasUsed: "42736", confirmations: "3568028"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1501782432 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[32,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[32,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: register( `kingdonb` )", async function( ) {
		const txOriginal = {blockNumber: "4113676", timeStamp: "1501801991", hash: "0x0c35632dd110cd4452990a253962c34f8664303f46ea3f1560dab67c60b98786", nonce: "1", blockHash: "0xfbb2ec6379047e09874bd0336f548f51effbe8ee0b95a3a4ebf0504ac0a7600d", transactionIndex: "46", from: "0x8c9e984f8ff1a31da9a7a8b2b63e0478c8be62a0", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "200000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000086b696e67646f6e62000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1484213", gasUsed: "146561", confirmations: "3567097"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `kingdonb`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `kingdonb`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1501801991 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[33,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x4edd765ae57bf9e902bb553df6e3e344f906b401600300f7a2528f7da43b1e00"}, {name: "owner", type: "address", value: "0x8c9e984f8ff1a31da9a7a8b2b63e0478c8be62a0"}, {name: "fee", type: "uint256", value: "200000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[33,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[33,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x4edd765ae57bf9e902bb553df6e3e344f906b401600300f7a2528f7da43b1e00"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[33,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "187349000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: register( `kingdon` )", async function( ) {
		const txOriginal = {blockNumber: "4113681", timeStamp: "1501802087", hash: "0x9fcc883e8855d733f9f2d262d484d15d96c796a466ee46889bb0946003abe28b", nonce: "2", blockHash: "0x1baea52e2a148eb2a03159302e92763fa7ac96b6ac53800a5583df36bba0ad1f", transactionIndex: "12", from: "0x8c9e984f8ff1a31da9a7a8b2b63e0478c8be62a0", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "230000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000076b696e67646f6e00000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1843104", gasUsed: "146311", confirmations: "3567092"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "230000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `kingdon`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `kingdon`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1501802087 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[34,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x952e3f00622d7fc063fe58f0a9aeff325fc67d9b67ee7b2dd72a857f41c65a94"}, {name: "owner", type: "address", value: "0x8c9e984f8ff1a31da9a7a8b2b63e0478c8be62a0"}, {name: "fee", type: "uint256", value: "230000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[34,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[34,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x952e3f00622d7fc063fe58f0a9aeff325fc67d9b67ee7b2dd72a857f41c65a94"}, {name: "amount", type: "uint256", value: "230000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[34,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "187349000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: register( `chrisremus` )", async function( ) {
		const txOriginal = {blockNumber: "4116616", timeStamp: "1501864794", hash: "0xebd2dc3e0b23f3245e97ec307135aba1b29797cc1e77caf4e7e1c99020c8c8e2", nonce: "1", blockHash: "0xb8a5e90ea92c78c8e12b476a7511325fcb336b84f4d69d854ae3bf4319833ea6", transactionIndex: "56", from: "0x47bde6e8e49adaa0bb9a67c1bd2c578a73be7e7f", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "147062", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a636872697372656d757300000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2031317", gasUsed: "147061", confirmations: "3564157"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `chrisremus`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `chrisremus`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1501864794 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x2d3f1a27e73d98768257d1fb13230cbb4b85d695f7c8bc4728600387c0fea613"}, {name: "owner", type: "address", value: "0x47bde6e8e49adaa0bb9a67c1bd2c578a73be7e7f"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[35,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x2d3f1a27e73d98768257d1fb13230cbb4b85d695f7c8bc4728600387c0fea613"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[35,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: register( `eugene` )", async function( ) {
		const txOriginal = {blockNumber: "4117060", timeStamp: "1501874491", hash: "0xd801759f6a5c1b50a6c6082044ed3c50d585bee544e1f6cc9d9f66ce7bddba74", nonce: "8", blockHash: "0x5ca5c8ce357e26643051cc9a29cf79d6498ae43837b14d321e64cebec14c0f29", transactionIndex: "26", from: "0xe7066e2fb60a57e4a266008f33b2311f7dbdc736", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "27737", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0xf2c298be00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000006657567656e650000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "923284", gasUsed: "27737", confirmations: "3563713"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `eugene`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "33448944351000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: register( `eugene` )", async function( ) {
		const txOriginal = {blockNumber: "4117071", timeStamp: "1501874851", hash: "0x02a3eaeb8ba1ad46c445da44d387845946456966d67fd84e1f54a112929aaffa", nonce: "9", blockHash: "0xf95ad2fb22ed22d0606ab9a92f540c178b31d9aae2eccc9ef9f4fe74dc822770", transactionIndex: "22", from: "0xe7066e2fb60a57e4a266008f33b2311f7dbdc736", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000006657567656e650000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "861058", gasUsed: "146061", confirmations: "3563702"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `eugene`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `eugene`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1501874851 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x04845056629fbb5a73b7d128704b7074079bba3dc3f306e2ea347852cb8d88b2"}, {name: "owner", type: "address", value: "0xe7066e2fb60a57e4a266008f33b2311f7dbdc736"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[37,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x04845056629fbb5a73b7d128704b7074079bba3dc3f306e2ea347852cb8d88b2"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[37,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "33448944351000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: register( `weka` )", async function( ) {
		const txOriginal = {blockNumber: "4119733", timeStamp: "1501932204", hash: "0xbb8e2b31a95f705e8fe18d893927406dc5035c7e32066520f0c48372a141371d", nonce: "47", blockHash: "0x0079c58bf5fb5577f07377f10ce12afc062b8c72914b81d62d2aa58c9791227f", transactionIndex: "53", from: "0x0904dac3347ea47d208f3fd67402d039a3b99859", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "218341", gasPrice: "1100000000", isError: "0", txreceipt_status: "", input: "0xf2c298be0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000477656b6100000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2623136", gasUsed: "145561", confirmations: "3561040"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `weka`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `weka`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1501932204 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x9e6944dda99c069b29d97c76969dde9361a8ce158500b5fbd68bb6b0379a38a0"}, {name: "owner", type: "address", value: "0x0904dac3347ea47d208f3fd67402d039a3b99859"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[38,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x9e6944dda99c069b29d97c76969dde9361a8ce158500b5fbd68bb6b0379a38a0"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[38,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "3408131211256658953" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: register( `sethsherman` )", async function( ) {
		const txOriginal = {blockNumber: "4121535", timeStamp: "1501970493", hash: "0x75f6d9db43d29e8717213605d1ad09bbc9b49e8db11cb26b5bcc894a95bbce90", nonce: "0", blockHash: "0x2019fc5cb84d7997ee4bddf88703949e235b2d57b655a773da37404ff2f30dac", transactionIndex: "12", from: "0xeb0abbaa88603628fe22768cb5dad7b5ae808b81", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b73657468736865726d616e000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "655818", gasUsed: "147311", confirmations: "3559238"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `sethsherman`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `sethsherman`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1501970493 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[39,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x9ddb2eef88f66fa430369e9a1d8760efefb435fd9ececf8114cbbc7e816bceb4"}, {name: "owner", type: "address", value: "0xeb0abbaa88603628fe22768cb5dad7b5ae808b81"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[39,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x9ddb2eef88f66fa430369e9a1d8760efefb435fd9ececf8114cbbc7e816bceb4"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "1290000000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: register( `ffwd` )", async function( ) {
		const txOriginal = {blockNumber: "4125313", timeStamp: "1502051075", hash: "0x69add0645f1067dd83dff98dda4ed2cd8226c595734fe45ddb4dada75f8762de", nonce: "23", blockHash: "0x6ba196c40ea2c87d8382eae0169301ba7a782469a5cd73ae9065617c9b0957d1", transactionIndex: "61", from: "0x9937865e1c1737edbe561dbc728d995dd663453f", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "218341", gasPrice: "1100000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000046666776400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3233330", gasUsed: "145561", confirmations: "3555460"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `ffwd`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `ffwd`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1502051075 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xff9d1fb29aeaca2b3422b80ddbb74f7fc5ffa3501a029a77393271074a751710"}, {name: "owner", type: "address", value: "0x9937865e1c1737edbe561dbc728d995dd663453f"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[40,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xff9d1fb29aeaca2b3422b80ddbb74f7fc5ffa3501a029a77393271074a751710"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[40,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: register( `kaiz` )", async function( ) {
		const txOriginal = {blockNumber: "4127106", timeStamp: "1502089512", hash: "0xf42dad3282fce51c75bd49e45e50168f346c57ca837dd5fa83f6c261fa633499", nonce: "20", blockHash: "0xe6e67120305cac3018df34bbe65694a1cd6f74c3c05c5eb2329ac9e839fae9e6", transactionIndex: "39", from: "0x457183a2ad85e5de163b9ca5b2346d12728e2bce", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000046b61697a00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2942915", gasUsed: "145561", confirmations: "3553667"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `kaiz`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `kaiz`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1502089512 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xc12a9b50598128878a6368282fbfb155252fcee9590ba70718c7cdd8f41d91f2"}, {name: "owner", type: "address", value: "0x457183a2ad85e5de163b9ca5b2346d12728e2bce"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[41,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xc12a9b50598128878a6368282fbfb155252fcee9590ba70718c7cdd8f41d91f2"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[41,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "70733211727026052" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: register( `sandro` )", async function( ) {
		const txOriginal = {blockNumber: "4131228", timeStamp: "1502177238", hash: "0x8be93fc5b25259b210602b8ef0153a897859420562f9f8439e0880a90dcbb158", nonce: "1", blockHash: "0x67ff1cbaf04262bebe235a3e60d9f6a6445e62ed7d3227db1d00436920e37da5", transactionIndex: "57", from: "0xf0451aa5a002c6ef5fb2ece769df0724122dc601", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "150000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000673616e64726f0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1961288", gasUsed: "146061", confirmations: "3549545"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "150000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `sandro`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `sandro`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1502177238 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xa147dca689cdfb34c0943b58415ea952dc7955cff212fdfa31d768478a9dbf19"}, {name: "owner", type: "address", value: "0xf0451aa5a002c6ef5fb2ece769df0724122dc601"}, {name: "fee", type: "uint256", value: "150000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[42,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xa147dca689cdfb34c0943b58415ea952dc7955cff212fdfa31d768478a9dbf19"}, {name: "amount", type: "uint256", value: "150000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[42,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "693393084733077936" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: register( `vitalik` )", async function( ) {
		const txOriginal = {blockNumber: "4165144", timeStamp: "1502889828", hash: "0x73652fdee83619b8ab82a625a05d9c4b5618da8caaea2c2131eabf89eba0ccb5", nonce: "6", blockHash: "0x929125355a18f53f97b0480b8f8b303ee86d672bc37669ed187947e746a3433d", transactionIndex: "84", from: "0x112b8ecddf26e4066180556d65e560d5efc5a11e", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000007766974616c696b00000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3660539", gasUsed: "146311", confirmations: "3515629"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `vitalik`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `vitalik`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1502889828 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[43,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xdd623fc0ca4d17cfa95f42e9a58fde2c6d8a74abed519c3aec8f05b3ebd61a21"}, {name: "owner", type: "address", value: "0x112b8ecddf26e4066180556d65e560d5efc5a11e"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[43,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[43,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xdd623fc0ca4d17cfa95f42e9a58fde2c6d8a74abed519c3aec8f05b3ebd61a21"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[43,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "1595760488970417044" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: register( `kuba` )", async function( ) {
		const txOriginal = {blockNumber: "4299864", timeStamp: "1506033042", hash: "0xbb843ae4c74b0d0b5c3cfab944dc565861eaffc61854b5f442faaff12c29c4d4", nonce: "0", blockHash: "0x2fedc9b240c742d03c477ef57dec3a5146fdafca386719137075a664f55ec6b4", transactionIndex: "35", from: "0xa72c0f5c0f21d53b35fadf49c68f969cf6c6b14a", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "100000", gasPrice: "1000000000", isError: "1", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000046b75626100000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6649160", gasUsed: "100000", confirmations: "3380909"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `kuba`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "10754439000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: register( `kuba` )", async function( ) {
		const txOriginal = {blockNumber: "4299892", timeStamp: "1506033583", hash: "0xeb41c126b06f27a690d2734315702030b1660322f19853e5eb6f5c74b3ed29e3", nonce: "1", blockHash: "0xcfd2acb36386e6e75ab2ff712da41300c3f57538b3722924992acdc8c4e2592c", transactionIndex: "110", from: "0xa72c0f5c0f21d53b35fadf49c68f969cf6c6b14a", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "1000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000046b75626100000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4648549", gasUsed: "145561", confirmations: "3380881"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `kuba`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `kuba`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1506033583 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x9267c81f11dbce42322aa27c98c2d804368c3525206ea727ed5709b18d8bdd33"}, {name: "owner", type: "address", value: "0xa72c0f5c0f21d53b35fadf49c68f969cf6c6b14a"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[45,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x9267c81f11dbce42322aa27c98c2d804368c3525206ea727ed5709b18d8bdd33"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[45,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "10754439000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: register( `almondelectric` )", async function( ) {
		const txOriginal = {blockNumber: "4317103", timeStamp: "1506543923", hash: "0xa8cc0f09e035bd92a3df7b278eeb6c82a459d011342c5edf8cf3717bf6e1b612", nonce: "19", blockHash: "0xceb82b029b942598c5c2cdda4d85880f35995254312caf4f5b7313879c24605c", transactionIndex: "65", from: "0xb6d09ad065909c2f46c6e500017e4b71cb49cf57", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "222093", gasPrice: "1100000000", isError: "0", txreceipt_status: "", input: "0xf2c298be0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000e616c6d6f6e64656c656374726963000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3054695", gasUsed: "148061", confirmations: "3363670"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `almondelectric`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `almondelectric`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1506543923 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0xc080546932cc489bfe9d899e844e44c4ef96038d7ce5421de1f3c51e88d7b4b8"}, {name: "owner", type: "address", value: "0xb6d09ad065909c2f46c6e500017e4b71cb49cf57"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[46,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0xc080546932cc489bfe9d899e844e44c4ef96038d7ce5421de1f3c51e88d7b4b8"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[46,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "5307839000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: register( `sticker` )", async function( ) {
		const txOriginal = {blockNumber: "4343969", timeStamp: "1507354296", hash: "0xa91fac21baaa0868a062647d7f2510bb47e41420f9e3353a0df79fa16d60806e", nonce: "520", blockHash: "0x1373da88314e246ef6053d0d48a63ca86c3ca03a35c483e45d0be955a581c53d", transactionIndex: "100", from: "0x18c6045651826824febbd39d8560584078d1b247", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "6000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000007737469636b657200000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6550393", gasUsed: "146311", confirmations: "3336804"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `sticker`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `sticker`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1507354296 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x838b486f48085713231d242731037a1d9c7dac6888d69700277d8bdd0462588d"}, {name: "owner", type: "address", value: "0x18c6045651826824febbd39d8560584078d1b247"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[47,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x838b486f48085713231d242731037a1d9c7dac6888d69700277d8bdd0462588d"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[47,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "4551954488598165552" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: register( `stickers` )", async function( ) {
		const txOriginal = {blockNumber: "4344058", timeStamp: "1507356882", hash: "0x4b0362345e16a9f3a92bf962ea72f1424492fb349c1f6e5bdae305e3ecaf84c8", nonce: "521", blockHash: "0x574151f7470494302fbc1099a28aa63c7bf376f5937af3b1531e2624ff3a50fc", transactionIndex: "58", from: "0x18c6045651826824febbd39d8560584078d1b247", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "100000000000000000", gas: "250000", gasPrice: "6000000000", isError: "0", txreceipt_status: "", input: "0xf2c298be00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000008737469636b657273000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4594814", gasUsed: "146561", confirmations: "3336715"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "label", value: `stickers`}], name: "register", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "register(string)" ]( `stickers`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1507356882 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "fee", type: "uint256"}], name: "nameRegistered", type: "event"} ;
		console.error( "eventCallOriginal[48,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "nameRegistered", events: [{name: "nodeHash", type: "bytes32", value: "0x7f9f883b17803854c3feb6a017f8ff47caa7fc23b74889bb4076998549d78e21"}, {name: "owner", type: "address", value: "0x18c6045651826824febbd39d8560584078d1b247"}, {name: "fee", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[48,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[48,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x7f9f883b17803854c3feb6a017f8ff47caa7fc23b74889bb4076998549d78e21"}, {name: "amount", type: "uint256", value: "100000000000000000"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[48,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "4551954488598165552" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: FireflyRegistrar( addressList[34], \"0x1000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4345521", timeStamp: "1507401885", hash: "0x64ead7ece0fe4b9b144ac5ff10d17041535fbecc6d6ef182f366f2e6a124bb66", nonce: "496", blockHash: "0x51fd5d65f3bcfc951832c91e4d371d9c6fb7498ed047ed958bf8421f43b342e1", transactionIndex: "26", from: "0x2ff4d83d13fb20b88614fbe38aaceaadad9d53fc", to: "0x6fc21092da55b392b045ed78f4732bff3c580e2c", value: "0", gas: "31319", gasPrice: "12000000000", isError: "0", txreceipt_status: "", input: "0xaaec0c030000000000000000000000002ff4d83d13fb20b88614fbe38aaceaadad9d53fc10000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ff4d83d13fb20b88614fbe38aaceaadad9d53fc", contractAddress: "", cumulativeGasUsed: "1100821", gasUsed: "31319", confirmations: "3335252"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "ens", value: addressList[34]}, {type: "bytes32", name: "nodeHash", value: "0x1000000000000000000000000000000000000000000000000000000000000000"}, {type: "address", name: "defaultResolver", value: addressList[34]}], name: "FireflyRegistrar", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "FireflyRegistrar(address,bytes32,address)" ]( addressList[34], "0x1000000000000000000000000000000000000000000000000000000000000000", addressList[34], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1507401885 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "nodeHash", type: "bytes32"}, {indexed: false, name: "amount", type: "uint256"}], name: "donation", type: "event"} ;
		console.error( "eventCallOriginal[49,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "donation", events: [{name: "nodeHash", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "0"}], address: "0x6fc21092da55b392b045ed78f4732bff3c580e2c"}] ;
		console.error( "eventResultOriginal[49,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "93330099993470" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1930000010000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
