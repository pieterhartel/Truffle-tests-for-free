const Fundraiser = artifacts.require( "./Fundraiser.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Fundraiser" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xCF965Cfe7C30323E9C9E41D4E398e2167506f764", "0x57F24C0E2aAca9D54A4aB0A83D2Ff8DC6473c6Ca", "0xBD26B72FB6Cbe250178A0E37FAb067781a051550", "0xE825363f3bEDAbc95b2A9d42dBc73ec7B82B57d3", "0x9A6A1826C513D93093Bee431d9d97eACf76384Ba", "0x1F7082284A1cd4f443Ff0f1b7CdE63341964de99", "0xe150b93a63c057349683b75E91173D4DC164790A", "0xD201Be7d1E614486B07DdCD0d7b68c01413ff979", "0x557E7d4CB32851A0A8770F0f4f60fD76cdB16333", "0xe31d8F73DebD2E76b662FBFBE46bb86125Ae6208", "0x2617e27779CE64C3Fe442D0AC2559423bE58f57D", "0x37B9B87Eb793e1ebB268EF75e2c50F3CEDe03D5A", "0x7531c9be16Adca014C0C0966fAc87442c645D0f4", "0xD117601fC9f62e84e1919a1a3B3f7BDFe4fC06d4", "0x005EdA47cFE617E09252EC74A941C7DE45D9Ba93", "0xFcFD771676A8C792745ce3d3Cbea2B2e946249Ad", "0x83Dc2d30FA3C87ac0547f061579388c3b629cab8", "0x2895E80999D406ad592e2b262737D35F7DB4B699", "0x78DdbEFcf64beeC6c7EDa16d73cBEaA0db522A1C", "0xd78d1f5edc360D77E625ACaE65b20bc14143c50c", "0x00De258b3b85Fe15b1F8Bf4672d54E88EBccB32C", "0x0fA38aBEc02bd4DbB87F189df50b674b9dB0b468", "0x385687abcBA639b00AD70CfcaD72Ed037ADb9cF0", "0x8E3D5dcae04b562E50A61F3E3f13778f7B57b86C", "0x25619749e040DEC6a6832d60d228F867DD77c35d", "0x2b995eB8137a184Ec07C5d18C92038441b83b55F", "0xA4c54400DA4967C8aD316E0f7209c3182C435853", "0xdE1882cB644c1d49828d39D1970CB1f0B17c862E", "0x4d50C9F79F451C56583C2F0BdB7e6B35b47Bb80E", "0xfd69FB6B987b2c28ccbF91273e232A2a42326f30", "0x73ed6d20ED33AE54705cf08099f339C3d5a7255D", "0x3CD48a0cB9c82608E743086B1ffda59741Beef3F", "0xff4194Bb163EeC65d6b24cfc9984934B0A957164", "0x8e92f61967d924729E03F950F63b814F5F5A5A82", "0x1c4f45Ac299753C6cBcd833591E5B336f88c2Fc1", "0x2d679144e7bFB692cf10aECF6E9888547F40A165", "0xBd6f63A94Eb7031658E981ab51A84E1da74d31Bb", "0x9c3315BA9A934c644e8Bb65a4A0FB8e2e32ecf6e", "0x6F70745820771DF06C2eEbAb9B665f6e30b6c2E8", "0x1926851A0457Dd9046f26c0cedDCbED749e6A55b", "0xAFF9F5a716CDd701304EaE6fC7F42C80FDEEA584", "0x391A4Df9eFf3c5987255f0F6Ea6f7B37dfF57b02", "0xe434DEe3328a1F7cf93B1E9aCAA63a2598E1a06d", "0x452B1a6257feeB054ffB77e7AcC205357f8A810d", "0xF67d9569AF280e1F8C1Aeb5377ae67659b4881D6", "0xd68ba7734753e2eE54103116323aBA2D94C78dC5", "0x60Feb295C8739A1e5Afc2Cd342743079315B5C13", "0x50C7294Bf211Fa04A4545807C3D33b0feB713830", "0x99Ad927F8Eb49C8b0522E411c7c09f876251821B", "0xC8c93fEC87C0D01432C822A1C50fD9d068Dfd920", "0x82b81F35eaA50325B95F19f1eD09033D222c1c7B", "0xeaFBd0496447667A64C55b00584891C0F92650F3", "0x92b58ad9529156C2D1d76dD9D8e4eC5271BaC22D", "0x8816F2Ff9F56028a1E31988483A17d5d04a1B61a", "0x05B93fE1F3045DC5B1C63505f80C2B819452BFD9", "0x95E628C335E74D18E87fB73cB0Dbd6628F3D167a", "0x25641fe4A8c49e0C5e45B2761b4Be89FcA53A2a3", "0x03Cb98D7aCD817dE9D886D22FaB3f1B57D92a608", "0x3736AA4f1F8C19C3c02b102C3aD1161eDA790fD6", "0x01c2bACBd2F21c736447133Dd094B92D9cF1eEe3", "0xA15913Ea3D1E2CA9Bb664Df9A3811910B2E95386", "0xc384d63B718380B3Feb4cDcaAFf08997cD05AD07", "0x9F06C670DA26C8097451BF2812e294f179b81BB3", "0xc9f3869f69712f01A97531e25Beff9B56F9D418e", "0x3f0038b2dc63649F5eAa28E81479dF35d23ca421", "0xE1D33016c59d3D867c49D1B64184143e754D8a9f", "0xe7A8e471eafB798F4554Cc6e526730FD56e62C7D", "0xD412e5D17A458f2A0E06d76662819231bA31e8E2", "0xEB0E6C25f4701F0A58782156b974a3140C2d8A25", "0x001D9C5cBc516bf5bc1Aa1Fd2C9f8d762642A949", "0x63c5c55Daa12963F022868c0E2c9b73D561AbfCE", "0x1bE7D3B06E66a0DDe4d3F7Dd1dB90cB97CE73195", "0x0088db9e97689c85A29E67d08F1F0e43BC40aE4D", "0xC24a407FBB32322ed6709F88F3B036c43C004835", "0xF80ec11b5a902C38ED6ef8D4818211c87B612790", "0x2c5681447d88db17A4D830c83f4E639621a38970", "0xA00f4Bf14a56730595bED9200549Be2253Ba608E", "0x17f3CFE4fBd8364fDC99c2Fbe1BB90C56D4610D0", "0xCF65C3a8885050E9aD25f7F9d90D851A9848fc63", "0xDdFD573d011C3391943E94C3Ef2c2E90b05CD783", "0xcb6acC95dCff369f4cCc42ecF3F8a267d2bf4D53", "0x7ad41e9d6e1FA47F1F6bcc63BD0327009590a47b", "0x85e6458CBEe932B4Be534F502cB11aCF2C61ae27", "0xBeAaDBA09aA9C60F79F760ba2296e07Eb55fFfeB", "0x93eE64b12b5668a85d90f10289ED024499365A6c", "0xF5E7700FAf36d391B64013C81b225ed2ea9D9Bc7", "0x3CD36FbC96684adAF207147472AC559776C9A7cc", "0x23785f9002e7D43dA1F617E212B2518026315943", "0xc223e225D46d8923983d7EC20Db6c32be901c038", "0x8A187e4eFdD8242317CAeB317f193F16CdbD86B3", "0xFf193cb60429183c706aA3612f0F4e2806529377", "0xE6927121A36125e2C7b708913168bc37cb0e9151", "0x13C2f6994A1E9AC8272255e1b2Ef0A21D8Dd38e0", "0x092f5C68C0C5334711421C8F66380d91eE8f693a", "0x941AEEa5f99bb68fEaA453dF338505744D0f20b8", "0x645A744a058c9825845F42C3dA12358dC81f1C31", "0xB351fA061C454B6F88c38aC4A9012184A8227d0E", "0x0Bf31b5AE2ED379D0E80991f9384Bb475AA1C8C7", "0x396679621552E9a18a1eC706572C450A45181BB8", "0xfe9d3219bE2CFFB24cb0b15C9bBB8178f3190A15", "0x8DB62Df0122f10d2864444B8930CE789A712Efc1", "0x99182d4Be7568969FC23c9F69866fC2E8Df6D753", "0x92Ab7B9687D46Ec41b40160387Ab691b90B31768", "0x61893465Ea5fe701B7b9cd3683e3265012e61a2f", "0xd9bdc7464e8b51626964d7BE820e0B4a1792cc6c", "0xDe5b2566DE9341bcbd4225b21515cD56BDBC4a96", "0x0De28Ea4b1cD1001dAe17C7e2837B53BE707A17F", "0x02fD5527548C854d13A419628A755ecFF4458b2a", "0x61141d86a7b4492BFeB807fD14e54da58B0bcbAc", "0x8ea9175EEe3e0A56EfA1aDCaA1e617BA6143e625", "0xe88052155f4cCDd09Bd5664039F767B8E3ED2182", "0xbEEF2e970F5ebf72e823995cF353D4A0c8B70F37", "0x8fD79295247fC06E14228117d4dfe4DbE7814e1b", "0xdfE8A75A23B4ce00c7C4439dF8275A54770b92E2", "0xD9ABD3B214D85283aA6f879E6Eef49620a0619df", "0x7f2083ad31BDd7d1cb6285788b8d16b4eF9a1f04", "0x2F8D6fa7655c1323B54D20DCa398dF0c28491DF6"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "endBlock", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isActive", outputs: [{name: "active", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "record", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "weiPerAtom", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "numDonations", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalAtom", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "treasury", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalWei", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "beginBlock", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isHalted", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "admin", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "dust", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"}, {anonymous: false, inputs: [], name: "Halted", type: "event"}, {anonymous: false, inputs: [], name: "Unhalted", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Received(address,address,uint256,uint256)", "Halted()", "Unhalted()"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x14432f6e1dc0e8c1f4c0d81c69cecc80c0bea817a74482492b0211392478ab9b", "0x1ee9080f6b55ca44ce58681c8162e6c1ac1c47e1da791a4a1c1ec6186d8af1f3", "0x7c46a5e7a10434913e987d799d659758880ce8e790692e13e66ddfae4cc9afca"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3484153 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 3487414 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_admin", value: 4}, {type: "address", name: "_treasury", value: 5}, {type: "uint256", name: "_beginBlock", value: "3482440"}, {type: "uint256", name: "_endBlock", value: "3571380"}, {type: "uint256", name: "_weiPerAtom", value: "2210921954455007"}], name: "Fundraiser", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "endBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isActive", outputs: [{name: "active", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isActive()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "record", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "record(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "weiPerAtom", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "weiPerAtom()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numDonations", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numDonations()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalAtom", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalAtom()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "treasury", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "treasury()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalWei", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalWei()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "beginBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "beginBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isHalted", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isHalted()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "admin", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "admin()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "dust", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dust()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Fundraiser", function( accounts ) {

	it( "TEST: Fundraiser( addressList[4], addressList[5], \"348244... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "3484153", timeStamp: "1491436268", hash: "0xa74c0574fd825b10856ff1f9764ce175b9f69e37b5ce8353f91e0703c4dca802", nonce: "18", blockHash: "0xf01d0f405e3f623f49b9321e8f10dff52ed0855e5ac0a7bc48737a21a5746e7b", transactionIndex: "4", from: "0x57f24c0e2aaca9d54a4ab0a83d2ff8dc6473c6ca", to: 0, value: "0", gas: "900000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xd818eb63000000000000000000000000bd26b72fb6cbe250178a0e37fab067781a051550000000000000000000000000e825363f3bedabc95b2a9d42dbc73ec7b82b57d300000000000000000000000000000000000000000000000000000000003523480000000000000000000000000000000000000000000000000000000000367eb40000000000000000000000000000000000000000000000000007dad261b8addf", contractAddress: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", cumulativeGasUsed: "725285", gasUsed: "630230", confirmations: "4190113"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_admin", value: addressList[4]}, {type: "address", name: "_treasury", value: addressList[5]}, {type: "uint256", name: "_beginBlock", value: "3482440"}, {type: "uint256", name: "_endBlock", value: "3571380"}, {type: "uint256", name: "_weiPerAtom", value: "2210921954455007"}], name: "Fundraiser", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Fundraiser.new( addressList[4], addressList[5], "3482440", "3571380", "2210921954455007", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1491436268 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Fundraiser.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2164658054100010001" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[7], addressList[8], \"0x93a7... )", async function( ) {
		const txOriginal = {blockNumber: "3484385", timeStamp: "1491439868", hash: "0x665cd9bd6f61f0b49d1f8c81f2cd056157339eaf3e602718ef4e9cc609e22fef", nonce: "8", blockHash: "0x4ac186c250856163bdab325534b02547e864f9cf71bdcc18b91a49b3d3efcd9d", transactionIndex: "6", from: "0x9a6a1826c513d93093bee431d9d97eacf76384ba", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "200000000000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f80000000000000000000000001f7082284a1cd4f443ff0f1b7cde63341964de99000000000000000000000000e150b93a63c057349683b75e91173d4dc164790a93a7146e", contractAddress: "", cumulativeGasUsed: "375949", gasUsed: "118459", confirmations: "4189881"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[7]}, {type: "address", name: "_returnAddress", value: addressList[8]}, {type: "bytes4", name: "checksum", value: "0x93a7146e"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[7], addressList[8], "0x93a7146e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1491439868 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x1f7082284a1cd4f443ff0f1b7cde63341964de99"}, {name: "returnAddr", type: "address", value: "0xe150b93a63c057349683b75e91173d4dc164790a"}, {name: "amount", type: "uint256", value: "200000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "234375746000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[10], addressList[11], \"0x4d... )", async function( ) {
		const txOriginal = {blockNumber: "3484777", timeStamp: "1491445512", hash: "0x44c4280348989b491d8225ec6843d4464a3a6fb62c0646739a0b4cc50b2467a1", nonce: "30", blockHash: "0x77fe8bbd180dda8c30c7074b994f6a130d83688b1f5445054b4891e5f8eab32a", transactionIndex: "11", from: "0xd201be7d1e614486b07ddcd0d7b68c01413ff979", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "200000000000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000557e7d4cb32851a0a8770f0f4f60fd76cdb16333000000000000000000000000e31d8f73debd2e76b662fbfbe46bb86125ae62084d45249f", contractAddress: "", cumulativeGasUsed: "389484", gasUsed: "73459", confirmations: "4189489"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[10]}, {type: "address", name: "_returnAddress", value: addressList[11]}, {type: "bytes4", name: "checksum", value: "0x4d45249f"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[10], addressList[11], "0x4d45249f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1491445512 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x557e7d4cb32851a0a8770f0f4f60fd76cdb16333"}, {name: "returnAddr", type: "address", value: "0xe31d8f73debd2e76b662fbfbe46bb86125ae6208"}, {name: "amount", type: "uint256", value: "200000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[10], addressList[11], \"0x4d... )", async function( ) {
		const txOriginal = {blockNumber: "3484871", timeStamp: "1491447242", hash: "0xfe0a5535a6b0db8cdb77c4a45b46b31a3d42d51e08d005cd7ab47b9c8552cddb", nonce: "31", blockHash: "0x0dcac0f7325f80e0948b8cd19581932a61822f9eeac73b215245e133254a59dd", transactionIndex: "36", from: "0xd201be7d1e614486b07ddcd0d7b68c01413ff979", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "200000000000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000557e7d4cb32851a0a8770f0f4f60fd76cdb16333000000000000000000000000e31d8f73debd2e76b662fbfbe46bb86125ae62084d45249f", contractAddress: "", cumulativeGasUsed: "1209277", gasUsed: "58459", confirmations: "4189395"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[10]}, {type: "address", name: "_returnAddress", value: addressList[11]}, {type: "bytes4", name: "checksum", value: "0x4d45249f"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[10], addressList[11], "0x4d45249f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1491447242 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x557e7d4cb32851a0a8770f0f4f60fd76cdb16333"}, {name: "returnAddr", type: "address", value: "0xe31d8f73debd2e76b662fbfbe46bb86125ae6208"}, {name: "amount", type: "uint256", value: "200000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[12], addressList[13], \"0x8a... )", async function( ) {
		const txOriginal = {blockNumber: "3485321", timeStamp: "1491453779", hash: "0xd395b6c654b8bb5e14841e88f8d4ec5fb67696b16bf23cb3d99378db877aad09", nonce: "32", blockHash: "0x1a45594a5ef6d12eac5d9952d118d02130002f8ff444b3207d0665979947477f", transactionIndex: "14", from: "0xd201be7d1e614486b07ddcd0d7b68c01413ff979", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "100000000000000000", gas: "150000", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x1c9981f80000000000000000000000002617e27779ce64c3fe442d0ac2559423be58f57d00000000000000000000000037b9b87eb793e1ebb268ef75e2c50f3cede03d5a8a8317c2", contractAddress: "", cumulativeGasUsed: "717812", gasUsed: "150000", confirmations: "4188945"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[12]}, {type: "address", name: "_returnAddress", value: addressList[13]}, {type: "bytes4", name: "checksum", value: "0x8a8317c2"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[12], addressList[13], \"0x8a... )", async function( ) {
		const txOriginal = {blockNumber: "3485326", timeStamp: "1491453877", hash: "0xb607f1dd7e581e52b8e9af3b08bb56392d9488d4ce9762875d25c15c4129da44", nonce: "33", blockHash: "0xb7f1b18f9dd279b19a68fa2272278fab91f1874625d07d80a8ac1317390a122c", transactionIndex: "9", from: "0xd201be7d1e614486b07ddcd0d7b68c01413ff979", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "200000000000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f80000000000000000000000002617e27779ce64c3fe442d0ac2559423be58f57d00000000000000000000000037b9b87eb793e1ebb268ef75e2c50f3cede03d5a8a8317c2", contractAddress: "", cumulativeGasUsed: "278689", gasUsed: "73459", confirmations: "4188940"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[12]}, {type: "address", name: "_returnAddress", value: addressList[13]}, {type: "bytes4", name: "checksum", value: "0x8a8317c2"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[12], addressList[13], "0x8a8317c2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1491453877 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x2617e27779ce64c3fe442d0ac2559423be58f57d"}, {name: "returnAddr", type: "address", value: "0x37b9b87eb793e1ebb268ef75e2c50f3cede03d5a"}, {name: "amount", type: "uint256", value: "200000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[14], addressList[15], \"0xf0... )", async function( ) {
		const txOriginal = {blockNumber: "3485393", timeStamp: "1491454907", hash: "0x26f057a2e0401e9ba2c7f44a925f5bc6865d5fbe91e1ed54d5d8577092d592f1", nonce: "34", blockHash: "0x4c2a2542cb78295956d65b7089962de88281070ba263f997bbd90a00a743c0d8", transactionIndex: "12", from: "0xd201be7d1e614486b07ddcd0d7b68c01413ff979", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "210000000000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f80000000000000000000000007531c9be16adca014c0c0966fac87442c645d0f4000000000000000000000000d117601fc9f62e84e1919a1a3b3f7bdfe4fc06d4f0b8b619", contractAddress: "", cumulativeGasUsed: "407009", gasUsed: "73459", confirmations: "4188873"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "210000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[14]}, {type: "address", name: "_returnAddress", value: addressList[15]}, {type: "bytes4", name: "checksum", value: "0xf0b8b619"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[14], addressList[15], "0xf0b8b619", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1491454907 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x7531c9be16adca014c0c0966fac87442c645d0f4"}, {name: "returnAddr", type: "address", value: "0xd117601fc9f62e84e1919a1a3b3f7bdfe4fc06d4"}, {name: "amount", type: "uint256", value: "210000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[17], addressList[18], \"0x96... )", async function( ) {
		const txOriginal = {blockNumber: "3486648", timeStamp: "1491473255", hash: "0x1542087fb99a6ac77ca222e436431c74a4cbd044d50dc3992dea8ffd3a48109a", nonce: "0", blockHash: "0x6f02255f967f863f9f70557100350606a7d1b3e346206d92cd9a2b411f580cee", transactionIndex: "0", from: "0x005eda47cfe617e09252ec74a941c7de45d9ba93", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "0", gas: "100000", gasPrice: "30865000006", isError: "1", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000fcfd771676a8c792745ce3d3cbea2b2e946249ad00000000000000000000000083dc2d30fa3c87ac0547f061579388c3b629cab8961fb0f2", contractAddress: "", cumulativeGasUsed: "100000", gasUsed: "100000", confirmations: "4187618"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[17]}, {type: "address", name: "_returnAddress", value: addressList[18]}, {type: "bytes4", name: "checksum", value: "0x961fb0f2"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[20], addressList[21], \"0xb6... )", async function( ) {
		const txOriginal = {blockNumber: "3486994", timeStamp: "1491478176", hash: "0xf1fefc75fe048fd6f9e993c902612ca3bf66157a01e8a20c567a722a7d1b0252", nonce: "18", blockHash: "0x60ddf296d8c7978975258025c4f45713ec26c3dfaa171d47c883008b85684019", transactionIndex: "1", from: "0x2895e80999d406ad592e2b262737d35f7db4b699", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "0", gas: "200000", gasPrice: "40000000000", isError: "1", txreceipt_status: "", input: "0x1c9981f800000000000000000000000078ddbefcf64beec6c7eda16d73cbeaa0db522a1c000000000000000000000000d78d1f5edc360d77e625acae65b20bc14143c50cb661a5c900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "233571", gasUsed: "200000", confirmations: "4187272"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[20]}, {type: "address", name: "_returnAddress", value: addressList[21]}, {type: "bytes4", name: "checksum", value: "0xb661a5c9"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "58954457952572000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[20], addressList[21], \"0xb6... )", async function( ) {
		const txOriginal = {blockNumber: "3487090", timeStamp: "1491479382", hash: "0x29ffa2ea7dd51a1111a1365d06e5c72ab68947732360d0d9d62bcb583370cd99", nonce: "1", blockHash: "0x94ae887cb0c47626b39eec78035e3be4b6b9e7f698fa284a67fe28b8cc8f5a80", transactionIndex: "17", from: "0x00de258b3b85fe15b1f8bf4672d54e88ebccb32c", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "0", gas: "150000", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x1c9981f800000000000000000000000078ddbefcf64beec6c7eda16d73cbeaa0db522a1c000000000000000000000000d78d1f5edc360d77e625acae65b20bc14143c50cb661a5c9", contractAddress: "", cumulativeGasUsed: "654887", gasUsed: "150000", confirmations: "4187176"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[20]}, {type: "address", name: "_returnAddress", value: addressList[21]}, {type: "bytes4", name: "checksum", value: "0xb661a5c9"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "93641640000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[24], addressList[25], \"0x7b... )", async function( ) {
		const txOriginal = {blockNumber: "3487305", timeStamp: "1491482072", hash: "0x8ddd66041e9d6b75adce00f7d51ecbc3c2e8bcf33cb7a8322a190f52e7ab74d4", nonce: "59", blockHash: "0xd5807584e8d8b1a5f1c68eb03630a2161d24b1365a24b3758531fba8d8d0b4e7", transactionIndex: "2", from: "0x0fa38abec02bd4dbb87f189df50b674b9db0b468", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "0", gas: "150000", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000385687abcba639b00ad70cfcad72ed037adb9cf00000000000000000000000008e3d5dcae04b562e50a61f3e3f13778f7b57b86c7b15ca0f", contractAddress: "", cumulativeGasUsed: "217991", gasUsed: "150000", confirmations: "4186961"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[24]}, {type: "address", name: "_returnAddress", value: addressList[25]}, {type: "bytes4", name: "checksum", value: "0x7b15ca0f"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "80451489537794165420" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "3487313", timeStamp: "1491482177", hash: "0xed97985365b166ec2e4f903d290000b715fc39e02e04c3e773f5e572c6c067d0", nonce: "115", blockHash: "0x7dc9cfb6ad5eaff50dcee5cb8b4f4a636d591eccd71136bee71d81cdd0e507d0", transactionIndex: "17", from: "0x25619749e040dec6a6832d60d228f867dd77c35d", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "0", gas: "150000", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "699780", gasUsed: "150000", confirmations: "4186953"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "2826289633628120" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[24], addressList[25], \"0x7b... )", async function( ) {
		const txOriginal = {blockNumber: "3487340", timeStamp: "1491482575", hash: "0x5f08f78881e285bee148576b0654be65a001457025322c6bc85fb9319d476646", nonce: "60", blockHash: "0x27ff2919cd20105087a27d49faede705b4f224b9a2d7b40dfd8b850407736b35", transactionIndex: "33", from: "0x0fa38abec02bd4dbb87f189df50b674b9db0b468", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "200000000000000000", gas: "150000", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000385687abcba639b00ad70cfcad72ed037adb9cf00000000000000000000000008e3d5dcae04b562e50a61f3e3f13778f7b57b86c7b15ca0f", contractAddress: "", cumulativeGasUsed: "1233331", gasUsed: "150000", confirmations: "4186926"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[24]}, {type: "address", name: "_returnAddress", value: addressList[25]}, {type: "bytes4", name: "checksum", value: "0x7b15ca0f"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "80451489537794165420" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[28], addressList[29], \"0x5c... )", async function( ) {
		const txOriginal = {blockNumber: "3487388", timeStamp: "1491483340", hash: "0xffc90d446b55bf286beee679364d5f5577f3ea5185e91969ed4732eb3fc74db0", nonce: "107", blockHash: "0x97d2ce69f0353594e09c77eb87939d881b45ba3253d759a7564859c5c91ce2a0", transactionIndex: "4", from: "0x2b995eb8137a184ec07c5d18c92038441b83b55f", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "10000000000000", gas: "150000", gasPrice: "20321904441", isError: "1", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000a4c54400da4967c8ad316e0f7209c3182c435853000000000000000000000000de1882cb644c1d49828d39d1970cb1f0b17c862e5c4ae614", contractAddress: "", cumulativeGasUsed: "250358", gasUsed: "150000", confirmations: "4186878"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[28]}, {type: "address", name: "_returnAddress", value: addressList[29]}, {type: "bytes4", name: "checksum", value: "0x5c4ae614"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "27321164039675896182" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[24], addressList[25], \"0x7b... )", async function( ) {
		const txOriginal = {blockNumber: "3487393", timeStamp: "1491483428", hash: "0x40107959100770fbea1e340a489e6c4db04dfd6f44f9e1a9fdb0f2f794c02b1a", nonce: "61", blockHash: "0xb412724223a3390e8fbcd950d61dc0697df59875433ddc837ab81e754aa77717", transactionIndex: "22", from: "0x0fa38abec02bd4dbb87f189df50b674b9db0b468", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "400000000000000000", gas: "150000", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000385687abcba639b00ad70cfcad72ed037adb9cf00000000000000000000000008e3d5dcae04b562e50a61f3e3f13778f7b57b86c7b15ca0f", contractAddress: "", cumulativeGasUsed: "638618", gasUsed: "150000", confirmations: "4186873"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[24]}, {type: "address", name: "_returnAddress", value: addressList[25]}, {type: "bytes4", name: "checksum", value: "0x7b15ca0f"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "80451489537794165420" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[31], addressList[32], \"0x03... )", async function( ) {
		const txOriginal = {blockNumber: "3487403", timeStamp: "1491483594", hash: "0xf46c156c2bd438f49f9588d20af3b9418ab3c239daf391508d09561e9b348a3c", nonce: "1", blockHash: "0xe7730b9c62278116d89e8c8aa869ded3fe36b9222a7dfc61eeda079f3a4abe3b", transactionIndex: "16", from: "0x4d50c9f79f451c56583c2f0bdb7e6b35b47bb80e", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "524123450000000000000", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000fd69fb6b987b2c28ccbf91273e232a2a42326f3000000000000000000000000073ed6d20ed33ae54705cf08099f339c3d5a7255d03f1126a", contractAddress: "", cumulativeGasUsed: "427063", gasUsed: "73459", confirmations: "4186863"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "524123450000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[31]}, {type: "address", name: "_returnAddress", value: addressList[32]}, {type: "bytes4", name: "checksum", value: "0x03f1126a"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[31], addressList[32], "0x03f1126a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1491483594 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xfd69fb6b987b2c28ccbf91273e232a2a42326f30"}, {name: "returnAddr", type: "address", value: "0x73ed6d20ed33ae54705cf08099f339c3d5a7255d"}, {name: "amount", type: "uint256", value: "524123450000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[34], addressList[35], \"0xa5... )", async function( ) {
		const txOriginal = {blockNumber: "3487406", timeStamp: "1491483615", hash: "0x3c9691bd8b657ac94538676aabc099ca41df18cb49d0cb4e4d7b29308726c501", nonce: "9", blockHash: "0x89291fc07945893cbcca1a432c74e195fbd0f5d50daad8c34827321e4e030a23", transactionIndex: "3", from: "0x3cd48a0cb9c82608e743086b1ffda59741beef3f", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "2250000000000000000000", gas: "30410", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000ff4194bb163eec65d6b24cfc9984934b0a9571640000000000000000000000008e92f61967d924729e03f950f63b814f5f5a5a82a5454bd0", contractAddress: "", cumulativeGasUsed: "119142", gasUsed: "30410", confirmations: "4186860"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "2250000000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[34]}, {type: "address", name: "_returnAddress", value: addressList[35]}, {type: "bytes4", name: "checksum", value: "0xa5454bd0"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "3999999380014268822726" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[37], addressList[38], \"0x16... )", async function( ) {
		const txOriginal = {blockNumber: "3487406", timeStamp: "1491483615", hash: "0xc129e6b9be8ae5a34d4d4e1f878f6bf7394e5ef76ffe895d3fc460f8f00eaba5", nonce: "27", blockHash: "0x89291fc07945893cbcca1a432c74e195fbd0f5d50daad8c34827321e4e030a23", transactionIndex: "10", from: "0x1c4f45ac299753c6cbcd833591e5b336f88c2fc1", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "95000000000000000000", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f80000000000000000000000002d679144e7bfb692cf10aecf6e9888547f40a165000000000000000000000000bd6f63a94eb7031658e981ab51a84e1da74d31bb1600bfb6", contractAddress: "", cumulativeGasUsed: "340313", gasUsed: "73395", confirmations: "4186860"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "95000000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[37]}, {type: "address", name: "_returnAddress", value: addressList[38]}, {type: "bytes4", name: "checksum", value: "0x1600bfb6"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[37], addressList[38], "0x1600bfb6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1491483615 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x2d679144e7bfb692cf10aecf6e9888547f40a165"}, {name: "returnAddr", type: "address", value: "0xbd6f63a94eb7031658e981ab51a84e1da74d31bb"}, {name: "amount", type: "uint256", value: "95000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[17], addressList[18], \"0x96... )", async function( ) {
		const txOriginal = {blockNumber: "3487407", timeStamp: "1491483621", hash: "0xd36d22b76d810d0f74d1334f033704fc966f5db0b33a4bb84b1d7e0b1ae92828", nonce: "1", blockHash: "0xf83d1ab102f75f144eeab14f532e77e142f9a272824305532189192c464f221c", transactionIndex: "1", from: "0x005eda47cfe617e09252ec74a941c7de45d9ba93", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "23000000000000000000", gas: "1000000", gasPrice: "40000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000fcfd771676a8c792745ce3d3cbea2b2e946249ad00000000000000000000000083dc2d30fa3c87ac0547f061579388c3b629cab8961fb0f2", contractAddress: "", cumulativeGasUsed: "94459", gasUsed: "73459", confirmations: "4186859"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "23000000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[17]}, {type: "address", name: "_returnAddress", value: addressList[18]}, {type: "bytes4", name: "checksum", value: "0x961fb0f2"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[17], addressList[18], "0x961fb0f2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1491483621 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xfcfd771676a8c792745ce3d3cbea2b2e946249ad"}, {name: "returnAddr", type: "address", value: "0x83dc2d30fa3c87ac0547f061579388c3b629cab8"}, {name: "amount", type: "uint256", value: "23000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[39], addressList[40], \"0xe9... )", async function( ) {
		const txOriginal = {blockNumber: "3487407", timeStamp: "1491483621", hash: "0xd4a7d6efeeb934e2412d2d65effe3bada4825e41564d2cfc3f4d5224854ec34c", nonce: "2", blockHash: "0xf83d1ab102f75f144eeab14f532e77e142f9a272824305532189192c464f221c", transactionIndex: "2", from: "0x00de258b3b85fe15b1f8bf4672d54e88ebccb32c", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "2500000000000000000000", gas: "200000", gasPrice: "40000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f80000000000000000000000009c3315ba9a934c644e8bb65a4a0fb8e2e32ecf6e0000000000000000000000006f70745820771df06c2eebab9b665f6e30b6c2e8e9d8cd1e", contractAddress: "", cumulativeGasUsed: "167918", gasUsed: "73459", confirmations: "4186859"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "2500000000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[39]}, {type: "address", name: "_returnAddress", value: addressList[40]}, {type: "bytes4", name: "checksum", value: "0xe9d8cd1e"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[39], addressList[40], "0xe9d8cd1e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1491483621 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x9c3315ba9a934c644e8bb65a4a0fb8e2e32ecf6e"}, {name: "returnAddr", type: "address", value: "0x6f70745820771df06c2eebab9b665f6e30b6c2e8"}, {name: "amount", type: "uint256", value: "2500000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "93641640000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[42], addressList[43], \"0x27... )", async function( ) {
		const txOriginal = {blockNumber: "3487408", timeStamp: "1491483625", hash: "0x5b17656efedfb89c4774c7b09421ec653259f3c7027b36f698e22adaf499110a", nonce: "15", blockHash: "0xe278381b76b1e400627619a9c8a79dd12314465f513caf2a4031232cf151dd42", transactionIndex: "0", from: "0x1926851a0457dd9046f26c0ceddcbed749e6a55b", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "20000000000000000000000", gas: "150000", gasPrice: "211000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000aff9f5a716cdd701304eae6fc7f42c80fdeea584000000000000000000000000391a4df9eff3c5987255f0f6ea6f7b37dff57b0227fef75e", contractAddress: "", cumulativeGasUsed: "73459", gasUsed: "73459", confirmations: "4186858"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "20000000000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[42]}, {type: "address", name: "_returnAddress", value: addressList[43]}, {type: "bytes4", name: "checksum", value: "0x27fef75e"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[42], addressList[43], "0x27fef75e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1491483625 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xaff9f5a716cdd701304eae6fc7f42c80fdeea584"}, {name: "returnAddr", type: "address", value: "0x391a4df9eff3c5987255f0f6ea6f7b37dff57b02"}, {name: "amount", type: "uint256", value: "20000000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[45], addressList[46], \"0x20... )", async function( ) {
		const txOriginal = {blockNumber: "3487408", timeStamp: "1491483625", hash: "0x33d64c846b113a1748ec07bc47f13e9f61e04b436d25b662ee407d5112aa94d0", nonce: "1", blockHash: "0xe278381b76b1e400627619a9c8a79dd12314465f513caf2a4031232cf151dd42", transactionIndex: "2", from: "0xe434dee3328a1f7cf93b1e9acaa63a2598e1a06d", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "5000000000000000000", gas: "1995300", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000452b1a6257feeb054ffb77e7acc205357f8a810d000000000000000000000000f67d9569af280e1f8c1aeb5377ae67659b4881d620ad5b0c", contractAddress: "", cumulativeGasUsed: "167918", gasUsed: "73459", confirmations: "4186858"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[44], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[45]}, {type: "address", name: "_returnAddress", value: addressList[46]}, {type: "bytes4", name: "checksum", value: "0x20ad5b0c"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[45], addressList[46], "0x20ad5b0c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1491483625 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x452b1a6257feeb054ffb77e7acc205357f8a810d"}, {name: "returnAddr", type: "address", value: "0xf67d9569af280e1f8c1aeb5377ae67659b4881d6"}, {name: "amount", type: "uint256", value: "5000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[44], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[44], balance: ( await web3.eth.getBalance( addressList[44], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[28], addressList[29], \"0x5c... )", async function( ) {
		const txOriginal = {blockNumber: "3487409", timeStamp: "1491483632", hash: "0x0e789bb8fb280880ecfbae6e765bba0c2f20f17c5a35307b79d5bfff031172e8", nonce: "108", blockHash: "0xd800b158a7a642fbee108d2f0bf286b52a24cc6d02701c1edc85e2f75b15f64a", transactionIndex: "1", from: "0x2b995eb8137a184ec07c5d18c92038441b83b55f", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "450000000000000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000a4c54400da4967c8ad316e0f7209c3182c435853000000000000000000000000de1882cb644c1d49828d39d1970cb1f0b17c862e5c4ae614", contractAddress: "", cumulativeGasUsed: "97691", gasUsed: "73395", confirmations: "4186857"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "450000000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[28]}, {type: "address", name: "_returnAddress", value: addressList[29]}, {type: "bytes4", name: "checksum", value: "0x5c4ae614"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[28], addressList[29], "0x5c4ae614", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1491483632 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xa4c54400da4967c8ad316e0f7209c3182c435853"}, {name: "returnAddr", type: "address", value: "0xde1882cb644c1d49828d39d1970cb1f0b17c862e"}, {name: "amount", type: "uint256", value: "450000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "27321164039675896182" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[48], addressList[49], \"0x29... )", async function( ) {
		const txOriginal = {blockNumber: "3487410", timeStamp: "1491483639", hash: "0x87f9ea8b3abcfbbb2f24e86e20ff34dfbbaaa312aa2b698954aad0ae4eb2ef48", nonce: "220", blockHash: "0x4c59c5020fc53df48ea4b3669ac84e6ae4a1296033c229ea4aea53618123a6b7", transactionIndex: "0", from: "0xd68ba7734753e2ee54103116323aba2d94c78dc5", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "2500000000000000000000", gas: "200000", gasPrice: "40000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f800000000000000000000000060feb295c8739a1e5afc2cd342743079315b5c1300000000000000000000000050c7294bf211fa04a4545807c3d33b0feb71383029702e6c", contractAddress: "", cumulativeGasUsed: "73459", gasUsed: "73459", confirmations: "4186856"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "2500000000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[48]}, {type: "address", name: "_returnAddress", value: addressList[49]}, {type: "bytes4", name: "checksum", value: "0x29702e6c"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[48], addressList[49], "0x29702e6c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1491483639 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x60feb295c8739a1e5afc2cd342743079315b5c13"}, {name: "returnAddr", type: "address", value: "0x50c7294bf211fa04a4545807c3d33b0feb713830"}, {name: "amount", type: "uint256", value: "2500000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "20272195069606412673" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[51], addressList[52], \"0xc5... )", async function( ) {
		const txOriginal = {blockNumber: "3487411", timeStamp: "1491483663", hash: "0x251515f6468b8e9b5cc0554f6680d33c99fb26650710ebe517d057dbccf45d56", nonce: "15", blockHash: "0xb5d8dd2813458bf2da8d965055ba636ca04df1f798bb27ff24e4a590c8c56a26", transactionIndex: "1", from: "0x99ad927f8eb49c8b0522e411c7c09f876251821b", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "1000000000000000000000", gas: "173460", gasPrice: "211000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000c8c93fec87c0d01432c822a1c50fd9d068dfd92000000000000000000000000082b81f35eaa50325b95f19f1ed09033d222c1c7bc5208a1b", contractAddress: "", cumulativeGasUsed: "94459", gasUsed: "73459", confirmations: "4186855"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[50], to: addressList[2], value: "1000000000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[51]}, {type: "address", name: "_returnAddress", value: addressList[52]}, {type: "bytes4", name: "checksum", value: "0xc5208a1b"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[51], addressList[52], "0xc5208a1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1491483663 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xc8c93fec87c0d01432c822a1c50fd9d068dfd920"}, {name: "returnAddr", type: "address", value: "0x82b81f35eaa50325b95f19f1ed09033d222c1c7b"}, {name: "amount", type: "uint256", value: "1000000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[50], balance: "22000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[50], balance: ( await web3.eth.getBalance( addressList[50], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[54], addressList[55], \"0xe2... )", async function( ) {
		const txOriginal = {blockNumber: "3487412", timeStamp: "1491483684", hash: "0x961cf4e1cd7323c9f993611fef8d2412adaaf7bfb7b23a3e115d61280c3f6c0b", nonce: "51", blockHash: "0x908670f6d1e07f9a28541aafe0a745ec42310dc82559bb1c177d4b5076a1a9a4", transactionIndex: "0", from: "0xeafbd0496447667a64c55b00584891c0f92650f3", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "1000000000000000000000", gas: "173460", gasPrice: "211000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f800000000000000000000000092b58ad9529156c2d1d76dd9d8e4ec5271bac22d0000000000000000000000008816f2ff9f56028a1e31988483a17d5d04a1b61ae238a33f", contractAddress: "", cumulativeGasUsed: "73459", gasUsed: "73459", confirmations: "4186854"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[53], to: addressList[2], value: "1000000000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[54]}, {type: "address", name: "_returnAddress", value: addressList[55]}, {type: "bytes4", name: "checksum", value: "0xe238a33f"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[54], addressList[55], "0xe238a33f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1491483684 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x92b58ad9529156c2d1d76dd9d8e4ec5271bac22d"}, {name: "returnAddr", type: "address", value: "0x8816f2ff9f56028a1e31988483a17d5d04a1b61a"}, {name: "amount", type: "uint256", value: "1000000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[53], balance: "48921452000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[53], balance: ( await web3.eth.getBalance( addressList[53], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[57], addressList[58], \"0x04... )", async function( ) {
		const txOriginal = {blockNumber: "3487413", timeStamp: "1491483723", hash: "0xde7ab53ba5dc47d21b3ef423219849d9709252b6e416469e69bf249a3213b36b", nonce: "83", blockHash: "0xbd45349ee1e249c0aa9815bc5f3e21f1e37a61276929d000d3fcfb5474247914", transactionIndex: "0", from: "0x05b93fe1f3045dc5b1c63505f80c2b819452bfd9", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "55000000000000000000", gas: "300000", gasPrice: "211000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f800000000000000000000000095e628c335e74d18e87fb73cb0dbd6628f3d167a00000000000000000000000025641fe4a8c49e0c5e45b2761b4be89fca53a2a304ca7b28", contractAddress: "", cumulativeGasUsed: "73459", gasUsed: "73459", confirmations: "4186853"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[56], to: addressList[2], value: "55000000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[57]}, {type: "address", name: "_returnAddress", value: addressList[58]}, {type: "bytes4", name: "checksum", value: "0x04ca7b28"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[57], addressList[58], "0x04ca7b28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1491483723 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x95e628c335e74d18e87fb73cb0dbd6628f3d167a"}, {name: "returnAddr", type: "address", value: "0x25641fe4a8c49e0c5e45b2761b4be89fca53a2a3"}, {name: "amount", type: "uint256", value: "55000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[56], balance: "1746931049552785554" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[56], balance: ( await web3.eth.getBalance( addressList[56], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[60], addressList[61], \"0x3a... )", async function( ) {
		const txOriginal = {blockNumber: "3487413", timeStamp: "1491483723", hash: "0xe0c2d9957af7350c8e5b85f3294003b9025a448bb2c05fc4a49abbd1758811d9", nonce: "1", blockHash: "0xbd45349ee1e249c0aa9815bc5f3e21f1e37a61276929d000d3fcfb5474247914", transactionIndex: "1", from: "0x03cb98d7acd817de9d886d22fab3f1b57d92a608", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "224668613794652886992", gas: "173460", gasPrice: "211000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f80000000000000000000000003736aa4f1f8c19c3c02b102c3ad1161eda790fd600000000000000000000000001c2bacbd2f21c736447133dd094b92d9cf1eee33acd1885", contractAddress: "", cumulativeGasUsed: "146918", gasUsed: "73459", confirmations: "4186853"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[59], to: addressList[2], value: "224668613794652886992" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[60]}, {type: "address", name: "_returnAddress", value: addressList[61]}, {type: "bytes4", name: "checksum", value: "0x3acd1885"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[60], addressList[61], "0x3acd1885", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1491483723 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x3736aa4f1f8c19c3c02b102c3ad1161eda790fd6"}, {name: "returnAddr", type: "address", value: "0x01c2bacbd2f21c736447133dd094b92d9cf1eee3"}, {name: "amount", type: "uint256", value: "224668613794652886992"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[59], balance: "2507077958474401" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[59], balance: ( await web3.eth.getBalance( addressList[59], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[63], addressList[64], \"0x50... )", async function( ) {
		const txOriginal = {blockNumber: "3487413", timeStamp: "1491483723", hash: "0xff6b4496466a027fc6b7c7e69f2aeb39c2a785c6d0acc28a0d1035b69e8dbe25", nonce: "5", blockHash: "0xbd45349ee1e249c0aa9815bc5f3e21f1e37a61276929d000d3fcfb5474247914", transactionIndex: "2", from: "0xa15913ea3d1e2ca9bb664df9a3811910b2e95386", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "471218389960000000000", gas: "73460", gasPrice: "211000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000c384d63b718380b3feb4cdcaaff08997cd05ad070000000000000000000000009f06c670da26c8097451bf2812e294f179b81bb35051d218", contractAddress: "", cumulativeGasUsed: "220377", gasUsed: "73459", confirmations: "4186853"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[62], to: addressList[2], value: "471218389960000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[63]}, {type: "address", name: "_returnAddress", value: addressList[64]}, {type: "bytes4", name: "checksum", value: "0x5051d218"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[63], addressList[64], "0x5051d218", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1491483723 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xc384d63b718380b3feb4cdcaaff08997cd05ad07"}, {name: "returnAddr", type: "address", value: "0x9f06c670da26c8097451bf2812e294f179b81bb3"}, {name: "amount", type: "uint256", value: "471218389960000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[62], balance: "162724575000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[62], balance: ( await web3.eth.getBalance( addressList[62], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[66], addressList[67], \"0xd4... )", async function( ) {
		const txOriginal = {blockNumber: "3487413", timeStamp: "1491483723", hash: "0x893b0c996989ea25913015323685bf0366c0dae2fd7edaa01213a236de30376a", nonce: "1", blockHash: "0xbd45349ee1e249c0aa9815bc5f3e21f1e37a61276929d000d3fcfb5474247914", transactionIndex: "3", from: "0xc9f3869f69712f01a97531e25beff9b56f9d418e", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "800000000000000000000", gas: "150000", gasPrice: "211000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f80000000000000000000000003f0038b2dc63649f5eaa28e81479df35d23ca421000000000000000000000000e1d33016c59d3d867c49d1b64184143e754d8a9fd406fc86", contractAddress: "", cumulativeGasUsed: "293772", gasUsed: "73395", confirmations: "4186853"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[65], to: addressList[2], value: "800000000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[66]}, {type: "address", name: "_returnAddress", value: addressList[67]}, {type: "bytes4", name: "checksum", value: "0xd406fc86"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[66], addressList[67], "0xd406fc86", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1491483723 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x3f0038b2dc63649f5eaa28e81479df35d23ca421"}, {name: "returnAddr", type: "address", value: "0xe1d33016c59d3d867c49d1b64184143e754d8a9f"}, {name: "amount", type: "uint256", value: "800000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[65], balance: "20000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[65], balance: ( await web3.eth.getBalance( addressList[65], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[69], addressList[70], \"0xc0... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0xeb2b8a7391f8f71ed201758b9aab5ad42188805bc353bcdf2bd92de1309e7f05", nonce: "7", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "0", from: "0xe7a8e471eafb798f4554cc6e526730fd56e62c7d", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "100000000000000000000", gas: "150000", gasPrice: "87000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000d412e5d17a458f2a0e06d76662819231ba31e8e2000000000000000000000000eb0e6c25f4701f0a58782156b974a3140c2d8a25c02cdafd", contractAddress: "", cumulativeGasUsed: "73459", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[68], to: addressList[2], value: "100000000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[69]}, {type: "address", name: "_returnAddress", value: addressList[70]}, {type: "bytes4", name: "checksum", value: "0xc02cdafd"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[69], addressList[70], "0xc02cdafd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xd412e5d17a458f2a0e06d76662819231ba31e8e2"}, {name: "returnAddr", type: "address", value: "0xeb0e6c25f4701f0a58782156b974a3140c2d8a25"}, {name: "amount", type: "uint256", value: "100000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[68], balance: "888105908109129000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[68], balance: ( await web3.eth.getBalance( addressList[68], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[72], addressList[73], \"0xc3... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x5803c691319a498ad475525ce4d4b612af37eb24cc93daf5e5de85bab3afb33a", nonce: "0", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "1", from: "0x001d9c5cbc516bf5bc1aa1fd2c9f8d762642a949", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "24000000000000000000", gas: "150000", gasPrice: "40000000010", isError: "0", txreceipt_status: "", input: "0x1c9981f800000000000000000000000063c5c55daa12963f022868c0e2c9b73d561abfce0000000000000000000000001be7d3b06e66a0dde4d3f7dd1db90cb97ce73195c33cd7be", contractAddress: "", cumulativeGasUsed: "146918", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[71], to: addressList[2], value: "24000000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[72]}, {type: "address", name: "_returnAddress", value: addressList[73]}, {type: "bytes4", name: "checksum", value: "0xc33cd7be"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[72], addressList[73], "0xc33cd7be", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x63c5c55daa12963f022868c0e2c9b73d561abfce"}, {name: "returnAddr", type: "address", value: "0x1be7d3b06e66a0dde4d3f7dd1db90cb97ce73195"}, {name: "amount", type: "uint256", value: "24000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[71], balance: "875713000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[71], balance: ( await web3.eth.getBalance( addressList[71], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[75], addressList[76], \"0xc1... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x20d28f260747e8d3cdf10853df3681d06ce7bbe04d2a1e10eee9bc1249f0c68b", nonce: "1", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "2", from: "0x0088db9e97689c85a29e67d08f1f0e43bc40ae4d", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "300000000000000000000", gas: "150000", gasPrice: "40000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000c24a407fbb32322ed6709f88f3b036c43c004835000000000000000000000000f80ec11b5a902c38ed6ef8d4818211c87b612790c147e704", contractAddress: "", cumulativeGasUsed: "220313", gasUsed: "73395", confirmations: "4186852"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[74], to: addressList[2], value: "300000000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[75]}, {type: "address", name: "_returnAddress", value: addressList[76]}, {type: "bytes4", name: "checksum", value: "0xc147e704"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[75], addressList[76], "0xc147e704", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xc24a407fbb32322ed6709f88f3b036c43c004835"}, {name: "returnAddr", type: "address", value: "0xf80ec11b5a902c38ed6ef8d4818211c87b612790"}, {name: "amount", type: "uint256", value: "300000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[74], balance: "35221702842000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[74], balance: ( await web3.eth.getBalance( addressList[74], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[78], addressList[79], \"0x02... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0xce38695e965830681c553479ebc24d7a6ddc7c6850824b211f51a758962091b4", nonce: "24", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "3", from: "0x2c5681447d88db17a4d830c83f4e639621a38970", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "13389630000000000000", gas: "173460", gasPrice: "28000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000a00f4bf14a56730595bed9200549be2253ba608e00000000000000000000000017f3cfe4fbd8364fdc99c2fbe1bb90c56d4610d0026fb45b", contractAddress: "", cumulativeGasUsed: "293772", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[77], to: addressList[2], value: "13389630000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[78]}, {type: "address", name: "_returnAddress", value: addressList[79]}, {type: "bytes4", name: "checksum", value: "0x026fb45b"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[78], addressList[79], "0x026fb45b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xa00f4bf14a56730595bed9200549be2253ba608e"}, {name: "returnAddr", type: "address", value: "0x17f3cfe4fbd8364fdc99c2fbe1bb90c56d4610d0"}, {name: "amount", type: "uint256", value: "13389630000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[77], balance: "21000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[77], balance: ( await web3.eth.getBalance( addressList[77], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[81], addressList[82], \"0xe3... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x0331eb3e9baa1b13bf18cd4d2ef9d91ff7085c30a6288bd0542930474933976c", nonce: "0", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "6", from: "0xcf65c3a8885050e9ad25f7f9d90d851a9848fc63", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "200000000000000000000", gas: "1995300", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000ddfd573d011c3391943e94c3ef2c2e90b05cd783000000000000000000000000cb6acc95dcff369f4ccc42ecf3f8a267d2bf4d53e32eebce", contractAddress: "", cumulativeGasUsed: "409231", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[80], to: addressList[2], value: "200000000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[81]}, {type: "address", name: "_returnAddress", value: addressList[82]}, {type: "bytes4", name: "checksum", value: "0xe32eebce"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[81], addressList[82], "0xe32eebce", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xddfd573d011c3391943e94c3ef2c2e90b05cd783"}, {name: "returnAddr", type: "address", value: "0xcb6acc95dcff369f4ccc42ecf3f8a267d2bf4d53"}, {name: "amount", type: "uint256", value: "200000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[80], balance: "1202797434902509605528" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[80], balance: ( await web3.eth.getBalance( addressList[80], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[84], addressList[85], \"0x27... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x0d98000b1beb9c9d18132bfc965f57d87327a1f50c85c5fd451562ef7e0a5e21", nonce: "30", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "9", from: "0x7ad41e9d6e1fa47f1f6bcc63bd0327009590a47b", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "775000000000000000000", gas: "88151", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f800000000000000000000000085e6458cbee932b4be534f502cb11acf2c61ae27000000000000000000000000beaadba09aa9c60f79f760ba2296e07eb55fffeb278212c8", contractAddress: "", cumulativeGasUsed: "524690", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[83], to: addressList[2], value: "775000000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[84]}, {type: "address", name: "_returnAddress", value: addressList[85]}, {type: "bytes4", name: "checksum", value: "0x278212c8"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[84], addressList[85], "0x278212c8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x85e6458cbee932b4be534f502cb11acf2c61ae27"}, {name: "returnAddr", type: "address", value: "0xbeaadba09aa9c60f79f760ba2296e07eb55fffeb"}, {name: "amount", type: "uint256", value: "775000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[83], balance: "486727644000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[83], balance: ( await web3.eth.getBalance( addressList[83], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[87], addressList[88], \"0x4e... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x170eed2a5e7821b246a332866453a59dbd0c134ec89e4c1774a05eaef308bf56", nonce: "9", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "12", from: "0x93ee64b12b5668a85d90f10289ed024499365a6c", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "30000000000000000000", gas: "1500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000f5e7700faf36d391b64013c81b225ed2ea9d9bc70000000000000000000000003cd36fbc96684adaf207147472ac559776c9a7cc4e9e6113", contractAddress: "", cumulativeGasUsed: "640149", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[86], to: addressList[2], value: "30000000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[87]}, {type: "address", name: "_returnAddress", value: addressList[88]}, {type: "bytes4", name: "checksum", value: "0x4e9e6113"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[87], addressList[88], "0x4e9e6113", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xf5e7700faf36d391b64013c81b225ed2ea9d9bc7"}, {name: "returnAddr", type: "address", value: "0x3cd36fbc96684adaf207147472ac559776c9a7cc"}, {name: "amount", type: "uint256", value: "30000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[86], balance: "500923114486777797777" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[86], balance: ( await web3.eth.getBalance( addressList[86], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[90], addressList[91], \"0xb7... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x19838c4e98c53789182d44380a417673a5f0112703ea5f127304c8a89fab3b6f", nonce: "8", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "13", from: "0x23785f9002e7d43da1f617e212b2518026315943", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "400000000000000000000", gas: "1995300", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000c223e225d46d8923983d7ec20db6c32be901c0380000000000000000000000008a187e4efdd8242317caeb317f193f16cdbd86b3b758154f", contractAddress: "", cumulativeGasUsed: "713608", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[89], to: addressList[2], value: "400000000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[90]}, {type: "address", name: "_returnAddress", value: addressList[91]}, {type: "bytes4", name: "checksum", value: "0xb758154f"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[90], addressList[91], "0xb758154f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xc223e225d46d8923983d7ec20db6c32be901c038"}, {name: "returnAddr", type: "address", value: "0x8a187e4efdd8242317caeb317f193f16cdbd86b3"}, {name: "amount", type: "uint256", value: "400000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[89], balance: "162822856237316403681" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[89], balance: ( await web3.eth.getBalance( addressList[89], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[24], addressList[25], \"0x7b... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x27987fb4450c6aee8abb0e546a743257e46d499dce4fe82103284fc4cd06103d", nonce: "62", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "15", from: "0x0fa38abec02bd4dbb87f189df50b674b9db0b468", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "100000000000000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000385687abcba639b00ad70cfcad72ed037adb9cf00000000000000000000000008e3d5dcae04b562e50a61f3e3f13778f7b57b86c7b15ca0f", contractAddress: "", cumulativeGasUsed: "821537", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "100000000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[24]}, {type: "address", name: "_returnAddress", value: addressList[25]}, {type: "bytes4", name: "checksum", value: "0x7b15ca0f"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[24], addressList[25], "0x7b15ca0f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x385687abcba639b00ad70cfcad72ed037adb9cf0"}, {name: "returnAddr", type: "address", value: "0x8e3d5dcae04b562e50a61f3e3f13778f7b57b86c"}, {name: "amount", type: "uint256", value: "100000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "80451489537794165420" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[93], addressList[94], \"0x1d... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x324b06e9c6b3d97a93df1194d0f3e7440eae7067774c26c0c672a06242f27185", nonce: "18", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "17", from: "0xff193cb60429183c706aa3612f0f4e2806529377", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "250000000000000000000", gas: "1995300", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000e6927121a36125e2c7b708913168bc37cb0e915100000000000000000000000013c2f6994a1e9ac8272255e1b2ef0a21d8dd38e01dda6930", contractAddress: "", cumulativeGasUsed: "915996", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[92], to: addressList[2], value: "250000000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[93]}, {type: "address", name: "_returnAddress", value: addressList[94]}, {type: "bytes4", name: "checksum", value: "0x1dda6930"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[93], addressList[94], "0x1dda6930", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xe6927121a36125e2c7b708913168bc37cb0e9151"}, {name: "returnAddr", type: "address", value: "0x13c2f6994a1e9ac8272255e1b2ef0a21d8dd38e0"}, {name: "amount", type: "uint256", value: "250000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[92], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[92], balance: ( await web3.eth.getBalance( addressList[92], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[96], addressList[97], \"0xae... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x337321cd5557e6b8b0f92c957b8af28c5b797e3692e025b384daf9f67571e7a7", nonce: "0", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "18", from: "0x092f5c68c0c5334711421c8f66380d91ee8f693a", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "75000000000000000000", gas: "1995300", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000941aeea5f99bb68feaa453df338505744d0f20b8000000000000000000000000645a744a058c9825845f42c3da12358dc81f1c31aed517f3", contractAddress: "", cumulativeGasUsed: "989455", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[95], to: addressList[2], value: "75000000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[96]}, {type: "address", name: "_returnAddress", value: addressList[97]}, {type: "bytes4", name: "checksum", value: "0xaed517f3"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[96], addressList[97], "0xaed517f3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x941aeea5f99bb68feaa453df338505744d0f20b8"}, {name: "returnAddr", type: "address", value: "0x645a744a058c9825845f42c3da12358dc81f1c31"}, {name: "amount", type: "uint256", value: "75000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[95], balance: "20000000000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[95], balance: ( await web3.eth.getBalance( addressList[95], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[45], addressList[46], \"0x20... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x359a7d014d110ad32e2097e00f2f8ca1580457397a0fec0a991a2ed4317f42b3", nonce: "2", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "20", from: "0xe434dee3328a1f7cf93b1e9acaa63a2598e1a06d", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "110000000000000000000", gas: "1995300", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000452b1a6257feeb054ffb77e7acc205357f8a810d000000000000000000000000f67d9569af280e1f8c1aeb5377ae67659b4881d620ad5b0c", contractAddress: "", cumulativeGasUsed: "1068914", gasUsed: "58459", confirmations: "4186852"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[44], to: addressList[2], value: "110000000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[45]}, {type: "address", name: "_returnAddress", value: addressList[46]}, {type: "bytes4", name: "checksum", value: "0x20ad5b0c"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[45], addressList[46], "0x20ad5b0c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x452b1a6257feeb054ffb77e7acc205357f8a810d"}, {name: "returnAddr", type: "address", value: "0xf67d9569af280e1f8c1aeb5377ae67659b4881d6"}, {name: "amount", type: "uint256", value: "110000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[44], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[44], balance: ( await web3.eth.getBalance( addressList[44], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x4a9bb2497ae44e2dcbf13782ec0eb5a6ce70f6a3970fafaff12f27bbb5629753", nonce: "0", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "22", from: "0xb351fa061c454b6f88c38ac4a9012184a8227d0e", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "7000000000000000000", gas: "150000", gasPrice: "20000000000", isError: "1", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "1252210", gasUsed: "150000", confirmations: "4186852"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[98], to: addressList[2], value: "7000000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[98], balance: "1117306079000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[98], balance: ( await web3.eth.getBalance( addressList[98], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[100], addressList[101], \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x4b6e965c574895c9fd73d84bf80a21b4e02da78119a0fa48a6ca138d07846508", nonce: "0", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "23", from: "0x0bf31b5ae2ed379d0e80991f9384bb475aa1c8c7", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "25800000000000000000", gas: "1995300", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000396679621552e9a18a1ec706572c450a45181bb8000000000000000000000000fe9d3219be2cffb24cb0b15c9bbb8178f3190a15ced2b6b0", contractAddress: "", cumulativeGasUsed: "1325669", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[99], to: addressList[2], value: "25800000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[100]}, {type: "address", name: "_returnAddress", value: addressList[101]}, {type: "bytes4", name: "checksum", value: "0xced2b6b0"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[100], addressList[101], "0xced2b6b0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x396679621552e9a18a1ec706572c450a45181bb8"}, {name: "returnAddr", type: "address", value: "0xfe9d3219be2cffb24cb0b15c9bbb8178f3190a15"}, {name: "amount", type: "uint256", value: "25800000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[99], balance: "9680000000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[99], balance: ( await web3.eth.getBalance( addressList[99], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[103], addressList[104], \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x580f9702c54277540ab9a9846af11c4fea375b4dda360a8235ad97fd558661da", nonce: "14", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "24", from: "0x8db62df0122f10d2864444b8930ce789a712efc1", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "39020000000000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f800000000000000000000000099182d4be7568969fc23c9f69866fc2e8df6d75300000000000000000000000092ab7b9687d46ec41b40160387ab691b90b31768ccfb4ab1", contractAddress: "", cumulativeGasUsed: "1399128", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[102], to: addressList[2], value: "39020000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[103]}, {type: "address", name: "_returnAddress", value: addressList[104]}, {type: "bytes4", name: "checksum", value: "0xccfb4ab1"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[103], addressList[104], "0xccfb4ab1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x99182d4be7568969fc23c9f69866fc2e8df6d753"}, {name: "returnAddr", type: "address", value: "0x92ab7b9687d46ec41b40160387ab691b90b31768"}, {name: "amount", type: "uint256", value: "39020000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[102], balance: "66140740087504036" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[102], balance: ( await web3.eth.getBalance( addressList[102], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[106], addressList[105], \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x5a821e6c3fcb0032f72ed47a4ffcc62903e8de7142e781c00a9e1c5e2cfcb192", nonce: "0", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "26", from: "0x61893465ea5fe701b7b9cd3683e3265012e61a2f", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "29990000000000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f8000000000000000000000000d9bdc7464e8b51626964d7be820e0b4a1792cc6c00000000000000000000000061893465ea5fe701b7b9cd3683e3265012e61a2f4ff87b3e", contractAddress: "", cumulativeGasUsed: "1496802", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[105], to: addressList[2], value: "29990000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[106]}, {type: "address", name: "_returnAddress", value: addressList[105]}, {type: "bytes4", name: "checksum", value: "0x4ff87b3e"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[106], addressList[105], "0x4ff87b3e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0xd9bdc7464e8b51626964d7be820e0b4a1792cc6c"}, {name: "returnAddr", type: "address", value: "0x61893465ea5fe701b7b9cd3683e3265012e61a2f"}, {name: "amount", type: "uint256", value: "29990000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[105], balance: "8530820000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[105], balance: ( await web3.eth.getBalance( addressList[105], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[108], addressList[109], \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x5b26f9c52744619efd34ea67763801c2b27b35998c2d2441bda1c6cbff5e851c", nonce: "9", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "27", from: "0xde5b2566de9341bcbd4225b21515cd56bdbc4a96", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "250000000000000000000", gas: "200000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f80000000000000000000000000de28ea4b1cd1001dae17c7e2837b53be707a17f00000000000000000000000002fd5527548c854d13a419628a755ecff4458b2a0e93bbaf", contractAddress: "", cumulativeGasUsed: "1570261", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[107], to: addressList[2], value: "250000000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[108]}, {type: "address", name: "_returnAddress", value: addressList[109]}, {type: "bytes4", name: "checksum", value: "0x0e93bbaf"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[108], addressList[109], "0x0e93bbaf", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x0de28ea4b1cd1001dae17c7e2837b53be707a17f"}, {name: "returnAddr", type: "address", value: "0x02fd5527548c854d13a419628a755ecff4458b2a"}, {name: "amount", type: "uint256", value: "250000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[107], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[107], balance: ( await web3.eth.getBalance( addressList[107], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[111], addressList[112], \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x5dfc075a4cc69e0dfc357f58ad757c2e027fecc9a2a5b3fa1d3c4434eb5b8b1c", nonce: "0", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "28", from: "0x61141d86a7b4492bfeb807fd14e54da58b0bcbac", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "40000000000000000000", gas: "1995300", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f80000000000000000000000008ea9175eee3e0a56efa1adcaa1e617ba6143e625000000000000000000000000e88052155f4ccdd09bd5664039f767b8e3ed2182a8629321", contractAddress: "", cumulativeGasUsed: "1643720", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[110], to: addressList[2], value: "40000000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[111]}, {type: "address", name: "_returnAddress", value: addressList[112]}, {type: "bytes4", name: "checksum", value: "0xa8629321"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[111], addressList[112], "0xa8629321", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x8ea9175eee3e0a56efa1adcaa1e617ba6143e625"}, {name: "returnAddr", type: "address", value: "0xe88052155f4ccdd09bd5664039f767b8e3ed2182"}, {name: "amount", type: "uint256", value: "40000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[110], balance: "9084161438338979" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[110], balance: ( await web3.eth.getBalance( addressList[110], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[114], addressList[115], \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x60eae9b883daacfb79cbff38f8c35909ba0919b0f30ca868dbf70f5d60409e93", nonce: "16", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "29", from: "0xbeef2e970f5ebf72e823995cf353d4a0c8b70f37", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "50000000000000000000", gas: "88074", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f80000000000000000000000008fd79295247fc06e14228117d4dfe4dbe7814e1b000000000000000000000000dfe8a75a23b4ce00c7c4439df8275a54770b92e20ceaf44b", contractAddress: "", cumulativeGasUsed: "1717115", gasUsed: "73395", confirmations: "4186852"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[113], to: addressList[2], value: "50000000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[114]}, {type: "address", name: "_returnAddress", value: addressList[115]}, {type: "bytes4", name: "checksum", value: "0x0ceaf44b"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[114], addressList[115], "0x0ceaf44b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x8fd79295247fc06e14228117d4dfe4dbe7814e1b"}, {name: "returnAddr", type: "address", value: "0xdfe8a75a23b4ce00c7c4439df8275a54770b92e2"}, {name: "amount", type: "uint256", value: "50000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[113], balance: "18951807435233652936" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[113], balance: ( await web3.eth.getBalance( addressList[113], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: donate( addressList[117], addressList[118], \"0x... )", async function( ) {
		const txOriginal = {blockNumber: "3487414", timeStamp: "1491483745", hash: "0x6f7f265c48bcca38f03c8f0dd3df507b9bc2ce4e91ab9fc6bf2539854a560ed6", nonce: "0", blockHash: "0xe2953c8c1807dc3537d7c60e273e29d8f5ca3202369f5e3cf38e8d10539cb518", transactionIndex: "31", from: "0xd9abd3b214d85283aa6f879e6eef49620a0619df", to: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764", value: "45000000000000000000", gas: "350000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x1c9981f80000000000000000000000007f2083ad31bdd7d1cb6285788b8d16b4ef9a1f040000000000000000000000002f8d6fa7655c1323b54d20dca398df0c28491df6fc90f1c0", contractAddress: "", cumulativeGasUsed: "1811574", gasUsed: "73459", confirmations: "4186852"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[116], to: addressList[2], value: "45000000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_donor", value: addressList[117]}, {type: "address", name: "_returnAddress", value: addressList[118]}, {type: "bytes4", name: "checksum", value: "0xfc90f1c0"}], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate(address,address,bytes4)" ]( addressList[117], addressList[118], "0xfc90f1c0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1491483745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "recipient", type: "address"}, {indexed: false, name: "returnAddr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "currentRate", type: "uint256"}], name: "Received", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Received", events: [{name: "recipient", type: "address", value: "0x7f2083ad31bdd7d1cb6285788b8d16b4ef9a1f04"}, {name: "returnAddr", type: "address", value: "0x2f8d6fa7655c1323b54d20dca398df0c28491df6"}, {name: "amount", type: "uint256", value: "45000000000000000000"}, {name: "currentRate", type: "uint256", value: "2210921954455007"}], address: "0xcf965cfe7c30323e9c9e41d4e398e2167506f764"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[116], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[116], balance: ( await web3.eth.getBalance( addressList[116], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
