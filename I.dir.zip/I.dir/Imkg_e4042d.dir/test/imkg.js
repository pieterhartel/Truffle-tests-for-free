const Imkg = artifacts.require( "./Imkg.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Imkg" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xb58470A0Ec113f823757993182131B4f0bE4042d", "0xF10898c3D10c8D1a16E697062b764fb510c3baD8", "0x348441aEB65ECC33b8B549df60566d2BE0013372", "0x3F0588DF556a4d34A568dCd6d2332a50A159f657", "0xF1Adc231CF6197Ff0f451fF1E1646ac68DFaD94B", "0xE7aE7d38aAF9EE90090C2E1574E9a1e3B7412f04", "0x9ad29a442B408123aB675407c7BBa863F2243D3e", "0x4bfDd0ACb699f4c8D4534b886EC5D74b486A2670"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "OutGap_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "pIDxAddr_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "roundGap_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "cooperator", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_pID", type: "uint256"}], name: "getPlayerRounds", outputs: [{name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "round_", outputs: [{name: "start", type: "uint256"}, {name: "state", type: "uint256"}, {name: "eth", type: "uint256"}, {name: "pot", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "team", type: "uint256"}, {name: "ethPerKey", type: "uint256"}, {name: "lastOutTime", type: "uint256"}, {name: "deadRate", type: "uint256"}, {name: "deadKeys", type: "uint256"}, {name: "liveTeams", type: "uint256"}, {name: "tID_", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "pIDxName_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tID", type: "uint256"}, {name: "_keys", type: "uint256"}], name: "getEthFromKeys", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "pID_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rID_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tID", type: "uint256"}], name: "getNextKeyPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_nameStr", type: "string"}], name: "checkIfNameValid", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], name: "rndTms_", outputs: [{name: "id", type: "uint256"}, {name: "name", type: "bytes32"}, {name: "keys", type: "uint256"}, {name: "eth", type: "uint256"}, {name: "price", type: "uint256"}, {name: "playersCount", type: "uint256"}, {name: "leaderID", type: "uint256"}, {name: "leaderAddr", type: "address"}, {name: "dead", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getLastRoundInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_pID", type: "uint256"}, {name: "_roundID", type: "uint256"}], name: "getPlayerRoundBought", outputs: [{name: "", type: "uint256[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentRoundInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getNextOutAfter", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}], name: "rndTIDxName_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tID", type: "uint256"}, {name: "_eth", type: "uint256"}], name: "getKeysFromEth", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getTeamsInfo", outputs: [{name: "", type: "uint256[]"}, {name: "", type: "bytes32[]"}, {name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}, {name: "", type: "bool[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], name: "plyrRnds_", outputs: [{name: "eth", type: "uint256"}, {name: "withdrawn", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_pID", type: "uint256"}], name: "getProfit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_pID", type: "uint256"}, {name: "_roundID", type: "uint256"}, {name: "_tID", type: "uint256"}], name: "getPlayerRoundTeamBought", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minTms_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_pID", type: "uint256"}], name: "getPreviousProfit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "activated_", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "plyr_", outputs: [{name: "addr", type: "address"}, {name: "name", type: "bytes32"}, {name: "gen", type: "uint256"}, {name: "aff", type: "uint256"}, {name: "laff", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getTeamLeaders", outputs: [{name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}, {name: "", type: "bytes32[]"}, {name: "", type: "address[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_addr", type: "address"}], name: "getPlayerInfoByAddress", outputs: [{name: "", type: "uint256"}, {name: "", type: "address"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxTms_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tID", type: "uint256"}], name: "getTeamInfoByID", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewNameEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "teamID", type: "uint256"}, {indexed: true, name: "teamName", type: "bytes32"}, {indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewTeamNameEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "teamID", type: "uint256"}, {indexed: false, name: "teamName", type: "bytes32"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}], name: "onTxEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "affID", type: "uint256"}, {indexed: false, name: "affAddress", type: "address"}, {indexed: false, name: "affName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffPayoutEvent", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "winnerTID", type: "uint256"}, {indexed: false, name: "winnerTName", type: "bytes32"}, {indexed: false, name: "playersCount", type: "uint256"}, {indexed: false, name: "eth", type: "uint256"}], name: "onEndRoundEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "ethOut", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onWithdrawEvent", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["onNewNameEvent(uint256,address,bytes32,bool,uint256,uint256)", "onNewTeamNameEvent(uint256,bytes32,uint256,bytes32,uint256,uint256)", "onTxEvent(uint256,address,bytes32,uint256,bytes32,uint256,uint256)", "onAffPayoutEvent(uint256,address,bytes32,uint256,uint256,uint256,uint256)", "onOutEvent(uint256,uint256,uint256)", "onEndRoundEvent(uint256,bytes32,uint256,uint256)", "onWithdrawEvent(uint256,address,bytes32,uint256,uint256)", "onOutInitialEvent(uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x71fe7db423509373e7a34c177214c78aa02d72ba4aa2d651dc8088bbdb48cb05", "0x2df77df2994dbe2d6074dad7bf48037033a82e312c5dda6f4599397bd488345e", "0x6d21c274a1fc053df37a7763047741da86045bd29a88790aa1cbd1368d186bf2", "0x6b4c68467c20dbc64ab403ad0800c5edebf7963d7bc5dd21abec4549d56580bc", "0x42ccf6326863db4a6d5a43a99d4a59d77995aa29fa715cb653da9c69ea5261f9", "0x5572b2596170a87f13a3328aee47e3367e6c16937a4b167442c97c544d3dd433", "0xcfc66706ab841800b7669eb55a07045f406e3bc8993e56858165dcf3295889bc", "0x2aecb2a09d031f49c639f46df9f40a2e3532229a70ea01c8facd9161447a1e2b"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6786271 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6915748 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Imkg", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "OutGap_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "OutGap_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "pIDxAddr_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pIDxAddr_(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "roundGap_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "roundGap_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cooperator", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cooperator()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_pID", value: random.range( maxRandom )}], name: "getPlayerRounds", outputs: [{name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerRounds(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "round_", outputs: [{name: "start", type: "uint256"}, {name: "state", type: "uint256"}, {name: "eth", type: "uint256"}, {name: "pot", type: "uint256"}, {name: "keys", type: "uint256"}, {name: "team", type: "uint256"}, {name: "ethPerKey", type: "uint256"}, {name: "lastOutTime", type: "uint256"}, {name: "deadRate", type: "uint256"}, {name: "deadKeys", type: "uint256"}, {name: "liveTeams", type: "uint256"}, {name: "tID_", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "round_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "pIDxName_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pIDxName_(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tID", value: random.range( maxRandom )}, {type: "uint256", name: "_keys", value: random.range( maxRandom )}], name: "getEthFromKeys", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getEthFromKeys(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "pID_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pID_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rID_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rID_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tID", value: random.range( maxRandom )}], name: "getNextKeyPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNextKeyPrice(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "string", name: "_nameStr", value: random.string( maxRandom )}], name: "checkIfNameValid", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkIfNameValid(string)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "rndTms_", outputs: [{name: "id", type: "uint256"}, {name: "name", type: "bytes32"}, {name: "keys", type: "uint256"}, {name: "eth", type: "uint256"}, {name: "price", type: "uint256"}, {name: "playersCount", type: "uint256"}, {name: "leaderID", type: "uint256"}, {name: "leaderAddr", type: "address"}, {name: "dead", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rndTms_(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getLastRoundInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLastRoundInfo()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_pID", value: random.range( maxRandom )}, {type: "uint256", name: "_roundID", value: random.range( maxRandom )}], name: "getPlayerRoundBought", outputs: [{name: "", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerRoundBought(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentRoundInfo", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentRoundInfo()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getNextOutAfter", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNextOutAfter()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "rndTIDxName_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rndTIDxName_(uint256,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tID", value: random.range( maxRandom )}, {type: "uint256", name: "_eth", value: random.range( maxRandom )}], name: "getKeysFromEth", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getKeysFromEth(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getTeamsInfo", outputs: [{name: "", type: "uint256[]"}, {name: "", type: "bytes32[]"}, {name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}, {name: "", type: "bool[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTeamsInfo()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "uint256", name: "", value: random.range( maxRandom )}], name: "plyrRnds_", outputs: [{name: "eth", type: "uint256"}, {name: "withdrawn", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyrRnds_(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_pID", value: random.range( maxRandom )}], name: "getProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getProfit(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_pID", value: random.range( maxRandom )}, {type: "uint256", name: "_roundID", value: random.range( maxRandom )}, {type: "uint256", name: "_tID", value: random.range( maxRandom )}], name: "getPlayerRoundTeamBought", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerRoundTeamBought(uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minTms_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minTms_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_pID", value: random.range( maxRandom )}], name: "getPreviousProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPreviousProfit(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "activated_", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "activated_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "plyr_", outputs: [{name: "addr", type: "address"}, {name: "name", type: "bytes32"}, {name: "gen", type: "uint256"}, {name: "aff", type: "uint256"}, {name: "laff", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "plyr_(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getTeamLeaders", outputs: [{name: "", type: "uint256[]"}, {name: "", type: "uint256[]"}, {name: "", type: "bytes32[]"}, {name: "", type: "address[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTeamLeaders()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getPlayerInfoByAddress", outputs: [{name: "", type: "uint256"}, {name: "", type: "address"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPlayerInfoByAddress(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxTms_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxTms_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tID", value: random.range( maxRandom )}], name: "getTeamInfoByID", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",33] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTeamInfoByID(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",33] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Imkg", function( accounts ) {

	it( "TEST: Imkg(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6786271", timeStamp: "1543380654", hash: "0x1e8932effed8d1731e403d118334e0c54bce9265d7220745d644d3786225adc2", nonce: "2", blockHash: "0xd14d57909b0f93cc61f637bf14f5162078181c2f4f997c5d29eaf452efb90915", transactionIndex: "13", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: 0, value: "0", gas: "5352071", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xef774850", contractAddress: "0xb58470a0ec113f823757993182131b4f0be4042d", cumulativeGasUsed: "6663045", gasUsed: "5352071", confirmations: "916817"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Imkg", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Imkg.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1543380654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Imkg.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: activate(  )", async function( ) {
		const txOriginal = {blockNumber: "6786293", timeStamp: "1543380988", hash: "0x6a039461c87a1ac7c49be473ab694ed92c99507dbc3b2818b5c794297c8366f1", nonce: "3", blockHash: "0x0cd87d07d23d556ccb4bd012588b1ffdfde8bb7917b97450c96b2411ab2552d2", transactionIndex: "108", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "202878", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x0f15f4c0", contractAddress: "", cumulativeGasUsed: "6369170", gasUsed: "202878", confirmations: "916795"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "activate", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activate()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1543380988 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXID( `guge` )", async function( ) {
		const txOriginal = {blockNumber: "6786691", timeStamp: "1543386719", hash: "0x612fd17ad632bbb5dacd65ae2815cc8dee419396e4df1a9c24c0c6a7b93e3f53", nonce: "0", blockHash: "0x0879cc2182845c2ad0d2727230643d4b9e10a3763cd36515be70e1a0fa715d5a", transactionIndex: "64", from: "0x3f0588df556a4d34a568dcd6d2332a50a159f657", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "10000000000000000", gas: "214288", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x0c1c3c14000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000046775676500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2793334", gasUsed: "142859", confirmations: "916397"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `guge`}], name: "registerNameXID", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXID(string)" ]( `guge`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1543386719 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewNameEvent", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onNewNameEvent", events: [{name: "playerID", type: "uint256", value: "2"}, {name: "playerAddress", type: "address", value: "0x3f0588df556a4d34a568dcd6d2332a50a159f657"}, {name: "playerName", type: "bytes32", value: "0x6775676500000000000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1543386719"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "899999974968000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXID( `huohu` )", async function( ) {
		const txOriginal = {blockNumber: "6786707", timeStamp: "1543386911", hash: "0xff1028aa695f0079d2a8c7fe259b1ab99b802c66c1eb2dea102cf862299eaa2b", nonce: "0", blockHash: "0xc1035c74dd4697ca879ab143b60bcfb77bf7a6d17eb2598c1b822c600fca1f35", transactionIndex: "138", from: "0xf1adc231cf6197ff0f451ff1e1646ac68dfad94b", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "10000000000000000", gas: "194995", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x0c1c3c140000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000568756f6875000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6615388", gasUsed: "129997", confirmations: "916381"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `huohu`}], name: "registerNameXID", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXID(string)" ]( `huohu`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1543386911 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewNameEvent", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onNewNameEvent", events: [{name: "playerID", type: "uint256", value: "3"}, {name: "playerAddress", type: "address", value: "0xf1adc231cf6197ff0f451ff1e1646ac68dfad94b"}, {name: "playerName", type: "bytes32", value: "0x68756f6875000000000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1543386911"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1419999974968000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"0\", \"0x67756765000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6786740", timeStamp: "1543387400", hash: "0x0f7b25c90c510f3f6f5180d3cd7aeb9af1e7f6127aeb8923c30754aac395ad5c", nonce: "1", blockHash: "0x03bdbc392d6ca44702f98e35029a600890814ab975dd1ae30881c86cdf3b9608", transactionIndex: "57", from: "0xf1adc231cf6197ff0f451ff1e1646ac68dfad94b", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "1000000000000000000", gas: "668980", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xe9fca28300000000000000000000000000000000000000000000000000000000000000006775676500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3081450", gasUsed: "445987", confirmations: "916348"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_team", value: "0"}, {type: "bytes32", name: "_affCode", value: "0x6775676500000000000000000000000000000000000000000000000000000000"}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,bytes32)" ]( "0", "0x6775676500000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543387400 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "teamID", type: "uint256"}, {indexed: false, name: "teamName", type: "bytes32"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}], name: "onTxEvent", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onTxEvent", events: [{name: "playerID", type: "uint256", value: "3"}, {name: "playerAddress", type: "address", value: "0xf1adc231cf6197ff0f451ff1e1646ac68dfad94b"}, {name: "playerName", type: "bytes32", value: "0x68756f6875000000000000000000000000000000000000000000000000000000"}, {name: "teamID", type: "uint256", value: "1"}, {name: "teamName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "13153133573268064322"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affID", type: "uint256"}, {indexed: false, name: "affAddress", type: "address"}, {indexed: false, name: "affName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffPayoutEvent", type: "event"} ;
		console.error( "eventCallOriginal[4,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffPayoutEvent", events: [{name: "affID", type: "uint256", value: "2"}, {name: "affAddress", type: "address", value: "0x3f0588df556a4d34a568dcd6d2332a50a159f657"}, {name: "affName", type: "bytes32", value: "0x6775676500000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "3"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "timeStamp", type: "uint256", value: "1543387400"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[4,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1419999974968000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"0\", \"0x68756f68750000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6787443", timeStamp: "1543397799", hash: "0xc594b8c7209f3d9a63456b92f39ace16d6c82469710f4a5b9815676bad14f963", nonce: "1", blockHash: "0x4cc324105b9995e8e44ac36b823769a9e289732f2511fcad31b658a22d422d9c", transactionIndex: "80", from: "0x3f0588df556a4d34a568dcd6d2332a50a159f657", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "1000000000000000000", gas: "526150", gasPrice: "9906250000", isError: "0", txreceipt_status: "1", input: "0xe9fca283000000000000000000000000000000000000000000000000000000000000000068756f6875000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4169768", gasUsed: "350767", confirmations: "915645"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_team", value: "0"}, {type: "bytes32", name: "_affCode", value: "0x68756f6875000000000000000000000000000000000000000000000000000000"}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,bytes32)" ]( "0", "0x68756f6875000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1543397799 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "teamID", type: "uint256"}, {indexed: false, name: "teamName", type: "bytes32"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}], name: "onTxEvent", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onTxEvent", events: [{name: "playerID", type: "uint256", value: "2"}, {name: "playerAddress", type: "address", value: "0x3f0588df556a4d34a568dcd6d2332a50a159f657"}, {name: "playerName", type: "bytes32", value: "0x6775676500000000000000000000000000000000000000000000000000000000"}, {name: "teamID", type: "uint256", value: "2"}, {name: "teamName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "13153133573268064322"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affID", type: "uint256"}, {indexed: false, name: "affAddress", type: "address"}, {indexed: false, name: "affName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffPayoutEvent", type: "event"} ;
		console.error( "eventCallOriginal[5,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffPayoutEvent", events: [{name: "affID", type: "uint256", value: "3"}, {name: "affAddress", type: "address", value: "0xf1adc231cf6197ff0f451ff1e1646ac68dfad94b"}, {name: "affName", type: "bytes32", value: "0x68756f6875000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "2"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "timeStamp", type: "uint256", value: "1543397799"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[5,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "899999974968000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: registerNameXID( `lxh` )", async function( ) {
		const txOriginal = {blockNumber: "6797932", timeStamp: "1543546816", hash: "0xd75e94f2b67d23b9f201de93831d545219ff1d77604ca871bee161e399e4cfc2", nonce: "0", blockHash: "0x9e25355a7f2fbfa2f0ee054e7566a211a7b8ad5bc20030bab5a823a610e5875f", transactionIndex: "62", from: "0xe7ae7d38aaf9ee90090c2e1574e9a1e3b7412f04", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "10000000000000000", gas: "188581", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x0c1c3c14000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000036c78680000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4542660", gasUsed: "125721", confirmations: "905156"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_nameString", value: `lxh`}], name: "registerNameXID", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "registerNameXID(string)" ]( `lxh`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1543546816 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: true, name: "playerAddress", type: "address"}, {indexed: true, name: "playerName", type: "bytes32"}, {indexed: false, name: "isNewPlayer", type: "bool"}, {indexed: false, name: "amountPaid", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onNewNameEvent", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onNewNameEvent", events: [{name: "playerID", type: "uint256", value: "4"}, {name: "playerAddress", type: "address", value: "0xe7ae7d38aaf9ee90090c2e1574e9a1e3b7412f04"}, {name: "playerName", type: "bytes32", value: "0x6c78680000000000000000000000000000000000000000000000000000000000"}, {name: "isNewPlayer", type: "bool", value: true}, {name: "amountPaid", type: "uint256", value: "10000000000000000"}, {name: "timeStamp", type: "uint256", value: "1543546816"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "439041000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"1\", \"0x68756f68750000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6797933", timeStamp: "1543546827", hash: "0x1af8a0e6c07ad9301c9cd14d3107e23f0e3a8105f4dc66b9bfa62cfab8949b45", nonce: "1", blockHash: "0xfee03457eff40957d0e2eb10c16cef8607475564d15dbb21a063bdb27ab39498", transactionIndex: "48", from: "0xe7ae7d38aaf9ee90090c2e1574e9a1e3b7412f04", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "10000000000000000", gas: "363673", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xe9fca283000000000000000000000000000000000000000000000000000000000000000168756f6875000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3108418", gasUsed: "196768", confirmations: "905155"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_team", value: "1"}, {type: "bytes32", name: "_affCode", value: "0x68756f6875000000000000000000000000000000000000000000000000000000"}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,bytes32)" ]( "1", "0x68756f6875000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543546827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "teamID", type: "uint256"}, {indexed: false, name: "teamName", type: "bytes32"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}], name: "onTxEvent", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onTxEvent", events: [{name: "playerID", type: "uint256", value: "4"}, {name: "playerAddress", type: "address", value: "0xe7ae7d38aaf9ee90090c2e1574e9a1e3b7412f04"}, {name: "playerName", type: "bytes32", value: "0x6c78680000000000000000000000000000000000000000000000000000000000"}, {name: "teamID", type: "uint256", value: "1"}, {name: "teamName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethIn", type: "uint256", value: "10000000000000000"}, {name: "keysBought", type: "uint256", value: "129760193476868343"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affID", type: "uint256"}, {indexed: false, name: "affAddress", type: "address"}, {indexed: false, name: "affName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffPayoutEvent", type: "event"} ;
		console.error( "eventCallOriginal[7,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffPayoutEvent", events: [{name: "affID", type: "uint256", value: "3"}, {name: "affAddress", type: "address", value: "0xf1adc231cf6197ff0f451ff1e1646ac68dfad94b"}, {name: "affName", type: "bytes32", value: "0x68756f6875000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "4"}, {name: "amount", type: "uint256", value: "1000000000000000"}, {name: "timeStamp", type: "uint256", value: "1543546827"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[7,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "439041000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"1\", \"0x00000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6798039", timeStamp: "1543548193", hash: "0xd4c72fc8a796daeade7c84201ce873aa60a8f2122a08992ee191ddde01d766a6", nonce: "1", blockHash: "0xb64957e20ed8e4c4efec8f7955ba300211c9a2c6bc14287b836a8458a2e41ebf", transactionIndex: "73", from: "0x9ad29a442b408123ab675407c7bba863f2243d3e", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "10000000000000000", gas: "318774", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe9fca28300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6622100", gasUsed: "212516", confirmations: "905049"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_team", value: "1"}, {type: "bytes32", name: "_affCode", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,bytes32)" ]( "1", "0x0000000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1543548193 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "teamID", type: "uint256"}, {indexed: false, name: "teamName", type: "bytes32"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}], name: "onTxEvent", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onTxEvent", events: [{name: "playerID", type: "uint256", value: "5"}, {name: "playerAddress", type: "address", value: "0x9ad29a442b408123ab675407c7bba863f2243d3e"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "teamID", type: "uint256", value: "1"}, {name: "teamName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethIn", type: "uint256", value: "10000000000000000"}, {name: "keysBought", type: "uint256", value: "129726068439091566"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "32412683200000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buy( \"0\", \"0x67756765000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6828017", timeStamp: "1543977055", hash: "0x3de7ef365c985c685138600c8a830ed0133126bc33742e247cfd7a2db810ff4a", nonce: "0", blockHash: "0x9de832c6efda5a7f4b2f97e247a8867204885bda572c56743dee08c570bdf6f8", transactionIndex: "44", from: "0x4bfdd0acb699f4c8d4534b886ec5d74b486a2670", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "1000000000000000000", gas: "675417", gasPrice: "12718750000", isError: "0", txreceipt_status: "1", input: "0xe9fca28300000000000000000000000000000000000000000000000000000000000000006775676500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5333564", gasUsed: "450278", confirmations: "875071"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_team", value: "0"}, {type: "bytes32", name: "_affCode", value: "0x6775676500000000000000000000000000000000000000000000000000000000"}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(uint256,bytes32)" ]( "0", "0x6775676500000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543977055 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "playerID", type: "uint256"}, {indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "playerName", type: "bytes32"}, {indexed: false, name: "teamID", type: "uint256"}, {indexed: false, name: "teamName", type: "bytes32"}, {indexed: false, name: "ethIn", type: "uint256"}, {indexed: false, name: "keysBought", type: "uint256"}], name: "onTxEvent", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onTxEvent", events: [{name: "playerID", type: "uint256", value: "6"}, {name: "playerAddress", type: "address", value: "0x4bfdd0acb699f4c8d4534b886ec5d74b486a2670"}, {name: "playerName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "teamID", type: "uint256", value: "3"}, {name: "teamName", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "ethIn", type: "uint256", value: "1000000000000000000"}, {name: "keysBought", type: "uint256", value: "13153133573268064322"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "affID", type: "uint256"}, {indexed: false, name: "affAddress", type: "address"}, {indexed: false, name: "affName", type: "bytes32"}, {indexed: true, name: "roundID", type: "uint256"}, {indexed: true, name: "buyerID", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "timeStamp", type: "uint256"}], name: "onAffPayoutEvent", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onAffPayoutEvent", events: [{name: "affID", type: "uint256", value: "2"}, {name: "affAddress", type: "address", value: "0x3f0588df556a4d34a568dcd6d2332a50a159f657"}, {name: "affName", type: "bytes32", value: "0x6775676500000000000000000000000000000000000000000000000000000000"}, {name: "roundID", type: "uint256", value: "1"}, {name: "buyerID", type: "uint256", value: "6"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "timeStamp", type: "uint256", value: "1543977055"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[9,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1543977055"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[9,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "14189026687500000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6831067", timeStamp: "1544020556", hash: "0x34c28933d1720712d219bdb7cc21b97311fd9723b664ef351832167db38748c8", nonce: "4", blockHash: "0xf6da7bf6f7dcb322d1115300b34fa244c457203a051687fa3f3b6ad9b863ffcd", transactionIndex: "57", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "5441782", gasUsed: "50858", confirmations: "872021"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1544020556 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "2682523967036804846"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[10,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544020556"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[10,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6834139", timeStamp: "1544063928", hash: "0x874e5161b696a9313506b47765187363eda40d8cbbb531abae2a2978f84356e2", nonce: "5", blockHash: "0x01025fd7868ef0429ff6e7ede52f40dd87ccedcb1fd9f16a9b69640157d4837e", transactionIndex: "72", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "6364305", gasUsed: "50858", confirmations: "868949"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1544063928 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "4023785950555207269"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[11,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544063928"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[11,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6837154", timeStamp: "1544107327", hash: "0x58094980a0b4988fb1a78899487c1bf12bdfe6b9d167869c3c8120072331940b", nonce: "6", blockHash: "0x54499568221897e9d5f3fa00e4451f80233b6a9f32c8ee82037240476a604bb7", transactionIndex: "42", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "2749990", gasUsed: "50858", confirmations: "865934"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1544107327 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[12,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "5365047934073609692"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[12,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[12,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544107327"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[12,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6837157", timeStamp: "1544107377", hash: "0xa3aa7ed73bf62bfc12cae01518d2db56eb0224211193d1c6e7ebfa1c0ee9e810", nonce: "7", blockHash: "0xc35a2751829393654ffbaa8354662508faf337959f4708bbac1b628ad7a9dc95", transactionIndex: "109", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "5999029", gasUsed: "24045", confirmations: "865931"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1544107377 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6837174", timeStamp: "1544107619", hash: "0x9513a656e649c21aac11090fdc19bb08a0d434f45190cbff39f5d0e37f9cd9e0", nonce: "8", blockHash: "0x92d328822645b0a38825604641b8612d9dde9b576be0c814386bfbf593d059bc", transactionIndex: "117", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "5512387", gasUsed: "24045", confirmations: "865914"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1544107619 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6837187", timeStamp: "1544107746", hash: "0x36fdc5a29a2f35ce275732a01557d100d7d182467d19159fb6182aee0eaa4a33", nonce: "9", blockHash: "0x6d6a934dff0719613418a787fade00a917b25b50aaf093d5a54d055820e8015a", transactionIndex: "94", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "3686195", gasUsed: "24045", confirmations: "865901"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1544107746 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6837215", timeStamp: "1544108298", hash: "0xe6763d00e5bc607bd1e67964e3eeccc6f10dd0ff624649d9a887f33847a36a20", nonce: "10", blockHash: "0x1fc65f166840a4b0d67b3175ddcea4d151a6527c360aefba5a7d023bdf32578e", transactionIndex: "65", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "2922277", gasUsed: "24045", confirmations: "865873"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1544108298 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6840168", timeStamp: "1544150713", hash: "0x8fa6829de696f83e7ebb249674400287387d7f2f8edd83daf21efd8449a28109", nonce: "11", blockHash: "0x216eaf6f27680e7b1108b89465fb70b1bd375ee8048cd984465fb1f5c621e700", transactionIndex: "66", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "2713340", gasUsed: "50858", confirmations: "862920"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1544150713 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[17,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "6706309917592012115"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[17,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[17,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544150713"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[17,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6843175", timeStamp: "1544194108", hash: "0x4f2fcd8f407a831c7ab662fa7bc040cbc870376a5fb9b2d93e2d7f5a5ca22cec", nonce: "12", blockHash: "0x0c2aa6a8691c64bd29c3ec785e251b6cfb68b88ebf2aad1750b9706764bfe412", transactionIndex: "68", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "6232898", gasUsed: "50858", confirmations: "859913"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1544194108 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "8047571901110414538"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[18,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544194108"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[18,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6846238", timeStamp: "1544237961", hash: "0xd31e621b29e2b9c8c1cd635996f2c3ee9157f8e046de9c6a8fd335412e9c2844", nonce: "13", blockHash: "0x37adb965978352aa5949a035ae5e90a47ef2594bd8e6b9989ba0246b415cd33c", transactionIndex: "37", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "5676727", gasUsed: "50858", confirmations: "856850"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1544237961 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "9388833884628816961"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[19,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544237961"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[19,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6846268", timeStamp: "1544238444", hash: "0x66a4f962f1237e04777a5a961ade61180b0fd6edc96be64b0a6f8a43f25503af", nonce: "14", blockHash: "0xd0d2e469179214c992661fdef09a7dbdc90f4af79470f449987d56a6ecc580b3", transactionIndex: "95", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "13650000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "4821838", gasUsed: "24045", confirmations: "856820"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1544238444 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6846280", timeStamp: "1544238687", hash: "0x89728ba3e8d811c8a321bc5a22f84ab42209abcc1002266dd2ebd8479b36f37b", nonce: "15", blockHash: "0x616fc01cfce5cd7e7a3c90becad296ff269e6bf4769aa8acfea9bc5b09c49bc9", transactionIndex: "80", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "4192492", gasUsed: "24045", confirmations: "856808"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1544238687 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6849220", timeStamp: "1544281325", hash: "0x942b3a33585fd00a42f32188c9d85b9fff5a228745849e56d4196ea8167bbe90", nonce: "16", blockHash: "0xb3f409f8a1dccc7bb10efac0daf3c773ed6ce865a2710160fb44b74269ef6ded", transactionIndex: "74", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "6587835", gasUsed: "50858", confirmations: "853868"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1544281325 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "10730095868147219384"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[22,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544281325"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[22,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6852293", timeStamp: "1544324646", hash: "0xaae6c08b758233512a707d22ad9a0c132b03f66e719f1167eb087747863fe616", nonce: "17", blockHash: "0x04e6525eaa0901ded11eb01b0a99e5446b9239e6dfe2f65a3842d24afb557c78", transactionIndex: "96", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "4402157", gasUsed: "50858", confirmations: "850795"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1544324646 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[23,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544324646"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[23,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6855354", timeStamp: "1544367975", hash: "0x9156796ea24b10b756961cce583a5aba537bd1f35bae5cfe28aebeeaf3c1ff27", nonce: "18", blockHash: "0xb21a2eaf77f78851c33bda884599bbbc728e2e4393dcb867df33b39b6b2c6134", transactionIndex: "65", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "6213968", gasUsed: "45362", confirmations: "847734"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1544367975 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[24,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[24,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[24,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544367975"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[24,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6858437", timeStamp: "1544411297", hash: "0x6a254bfbb01cedb4e39f66644798f95924bb322a2c1fad5cbdbcffcb0ce9e24e", nonce: "19", blockHash: "0x0368fc973233768c787309ba4aa3f153dd6ccae7c5562fdc38e3c33a261f389e", transactionIndex: "45", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "2328766", gasUsed: "45362", confirmations: "844651"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1544411297 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[25,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544411297"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[25,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6861508", timeStamp: "1544454745", hash: "0xfe989f8ea2177a9eb6b30bb15527f5ae12f4252372eff795d37c0eafe4c26109", nonce: "20", blockHash: "0x15205a864786aca5419ab0470d5fb495eeebc8d339eb5f4f6f89b5ded2a77835", transactionIndex: "63", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "3841461", gasUsed: "45362", confirmations: "841580"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1544454745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[26,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544454745"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[26,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6861565", timeStamp: "1544455415", hash: "0xa519ec2ed44f9abc94b1f7f87468167f91108f9100b0f441ca750ccb9bd4449f", nonce: "21", blockHash: "0x1d67924b134365f90cc5b125e18cb2c2811b7c5c6146263983db3179d8074700", transactionIndex: "25", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "7562500000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "6874395", gasUsed: "24045", confirmations: "841523"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1544455415 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6864601", timeStamp: "1544498084", hash: "0x3156d82b39233dd0cf3f096d52ee2bc99bff547f865beeda42cbe2e03797abf1", nonce: "22", blockHash: "0x4482c0ea4889e61e106018081aaf6104a2b5bea2d08a3d25fe93ec1f41b09158", transactionIndex: "34", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "6841018", gasUsed: "45362", confirmations: "838487"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1544498084 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[28,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[28,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[28,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544498084"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[28,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6867571", timeStamp: "1544541475", hash: "0xfec5104ce3b8920dbd33338f0ab2cf11451923ff76cd0d49297b4e6c46f56096", nonce: "23", blockHash: "0xbcf1a5b836002f105e876a2f94c9d6bc61b25057683c4ce792de96b23abe6cff", transactionIndex: "119", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "4915625", gasUsed: "45362", confirmations: "835517"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1544541475 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[29,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544541475"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[29,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6870604", timeStamp: "1544584799", hash: "0x36019e590cbf65af79ebdb4b636a3aeb9b0683cfc3f2d8f6c5003e6ecfac0038", nonce: "24", blockHash: "0x6ecf81cbaf4960c8c7c15917674965bd0f60d78d8ca67a7ebbc07651443b4773", transactionIndex: "64", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "4670145", gasUsed: "45362", confirmations: "832484"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1544584799 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[30,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[30,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[30,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544584799"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[30,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6873694", timeStamp: "1544628171", hash: "0xbee9ceddbc3ac660701ed55787ec8f5fc5cf71c38d09dfc64678433061074d2f", nonce: "25", blockHash: "0x2962a36f77bca9afad4ef84dbb0327ddcb27bc929ec0b71d6c18636581f66862", transactionIndex: "84", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "2500000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "7000262", gasUsed: "45362", confirmations: "829394"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1544628171 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[31,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[31,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[31,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544628171"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[31,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6876719", timeStamp: "1544671507", hash: "0xc78aec2441ca0b87e62a323647b6ac3e663ed7a32044a6867504a6c10bc704fc", nonce: "26", blockHash: "0x847ff448fd55eefb29e562e2dfb305fdf7b5215f85bf6aaff786e8c72c1e78c6", transactionIndex: "51", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "6422012", gasUsed: "45362", confirmations: "826369"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1544671507 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[32,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[32,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[32,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544671507"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[32,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6879749", timeStamp: "1544714830", hash: "0x3ade4658730a2e3073cd900adbbc7b242e3664eeeee7e69502717db74b98c1ed", nonce: "27", blockHash: "0x598d5a947475f2bbfcf39ad7aeb9afacc661cbf92ace270fed75768f10885ab1", transactionIndex: "42", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "4944902", gasUsed: "45362", confirmations: "823339"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1544714830 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[33,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[33,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[33,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544714830"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[33,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6882784", timeStamp: "1544758163", hash: "0xef9ae3079b820827a323c8dde21b557d4e41eff28b90d3d7f7c7ea017e342ab9", nonce: "28", blockHash: "0x61e4424fc34c4da831929629b8e445f8ed84c6790e0b916acda33b0b555dc912", transactionIndex: "53", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "5028150313", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "2228284", gasUsed: "45362", confirmations: "820304"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1544758163 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[34,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[34,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[34,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544758163"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[34,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6885826", timeStamp: "1544801661", hash: "0xe9a83157106da0e10252aa8cc68e8023588c51812bc9baedbcb4643b4156d619", nonce: "29", blockHash: "0x9f0ddba432b8a0697ca8fe45c9b1f310f24656dcbab1f9bc8e47cf2ba0a9a2ea", transactionIndex: "28", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "1864692", gasUsed: "45362", confirmations: "817262"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1544801661 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[35,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544801661"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[35,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6885840", timeStamp: "1544801867", hash: "0x0054f969a610a31d528c2e6b175a8bdd28ade793ff2c479b6088cb7588d1ffaf", nonce: "30", blockHash: "0xbab04ea7b129b479bb1aa6439fb786f37ad53beed536858e173df2c1bce8ae61", transactionIndex: "117", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "6505112", gasUsed: "24045", confirmations: "817248"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1544801867 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6888897", timeStamp: "1544845033", hash: "0xf5b17b11c97c09c2e05430540c85be28aac11f2948b3fb19eebfbe06605efb40", nonce: "31", blockHash: "0x0237221b90eb4ce36f2cdddc2fa2556bab5fb49abc7573ca0309b21e8ace1931", transactionIndex: "26", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "3581936", gasUsed: "45362", confirmations: "814191"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1544845033 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[37,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544845033"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[37,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6891968", timeStamp: "1544888478", hash: "0x3b99536233088965918fea56fc242ef30999cc289993f929c86ac2f6c25033c9", nonce: "32", blockHash: "0xae851050b3cfb04129f571205468c065a842c33fee0c2ea2bded96453d43b037", transactionIndex: "34", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "3300000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "6370261", gasUsed: "45362", confirmations: "811120"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1544888478 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[38,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544888478"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[38,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6892022", timeStamp: "1544889224", hash: "0x57a77ff6033dfe60fb93991c546310a576bd0589cf43440d37d087bbaf6c5a46", nonce: "33", blockHash: "0x74f9c40b36a17dc0a689fd2d682342ae93f2d974e704bebbdee6fedbbbad2d66", transactionIndex: "35", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "3000010000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "1688775", gasUsed: "24045", confirmations: "811066"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1544889224 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6895019", timeStamp: "1544931829", hash: "0x18cb9700086baacb12874a041f1ee68770eeb0cc356b47861363d729e4493a66", nonce: "34", blockHash: "0x91b6076f55140d16ab2c69309d82dfc117cd12eda537ce349ba3b880bb268449", transactionIndex: "12", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "1496530", gasUsed: "45362", confirmations: "808069"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1544931829 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[40,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544931829"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[40,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6898039", timeStamp: "1544975248", hash: "0xda5a0bbbc7713414c3a46878ac9241d5f68d1d19e6c9dd431e9ac900af9cd0da", nonce: "35", blockHash: "0x7c21782479fae4825186f156533fde25054b44bd14b78d317e90cbad227404a4", transactionIndex: "126", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "2300000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "7002866", gasUsed: "45362", confirmations: "805049"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1544975248 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[41,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1544975248"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[41,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6901068", timeStamp: "1545018565", hash: "0x1bcddd95188cbaa9aee55b4ed55cb5f410b46e1a3f38519ff2ed33d162fa4444", nonce: "36", blockHash: "0xc5c33e6ef63b4745e717a5dc32220751e86e8a76896b4815f890cb8910a754d2", transactionIndex: "106", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "7400000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "5419744", gasUsed: "45362", confirmations: "802020"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1545018565 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[42,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1545018565"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[42,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6903974", timeStamp: "1545061936", hash: "0x4a0ac0e929a0acef11df1d1bebc7f31317a1746ffecfe0185dc64bc43a7027bf", nonce: "37", blockHash: "0xdf653ad4a812147630c513f726a2c10ebfae049d2c9d6b803d9acbd12c00b04b", transactionIndex: "140", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "6387316", gasUsed: "45362", confirmations: "799114"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1545061936 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[43,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[43,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[43,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1545061936"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[43,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6906934", timeStamp: "1545105292", hash: "0xa4156de100ed0ca63a36d2c21f40bc65d118b6234336e99429acbe1935779f72", nonce: "38", blockHash: "0xd0134fbd566b0dd4366821ae482ea0179eaa6a9861d11ebb82561c142b01dca8", transactionIndex: "33", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "2575480", gasUsed: "45362", confirmations: "796154"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1545105292 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[44,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[44,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[44,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1545105292"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[44,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6909839", timeStamp: "1545148672", hash: "0x2ddcef5b4410a919c3b9ff67b67049f532852f7825c25f0d8ae5de7a5c3ad51f", nonce: "39", blockHash: "0x395c5b652dec5b822fade2ca364778e1a4619d4e6260e5cb2fe7392ea3b2e39f", transactionIndex: "57", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "4017732", gasUsed: "45362", confirmations: "793249"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1545148672 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[45,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1545148672"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[45,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6912868", timeStamp: "1545192073", hash: "0xfca05fd17658aaf56c129fbc6083709daa851f8d1d5d6a3b0ca5c7de0ee3b10e", nonce: "40", blockHash: "0xd5d4d44ff76607700e7e6046f1b3ed629121bcd84fc7806bfcbaa55a59e4b806", transactionIndex: "46", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "4164227", gasUsed: "45362", confirmations: "790220"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1545192073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[46,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1545192073"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[46,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6912880", timeStamp: "1545192276", hash: "0x25f20c99e0682b01da84e8bc96785b6360dc43ace377c6ea965e5c1f0e7e9886", nonce: "41", blockHash: "0xfbdadc3744560fbfcb380ac35b6119c89282a2ed9cdf5fa4d17a3ae5dbbdb38d", transactionIndex: "41", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "1749950", gasUsed: "24045", confirmations: "790208"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1545192276 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6912934", timeStamp: "1545193016", hash: "0xef5d738fe7be0a006105b1224dc4881a61e14b2d9bac638a3dc3cab632981b37", nonce: "42", blockHash: "0x441f8a3637289c3a50bdc62c559ca71f5e9dbc7fd9d9a8ff7ebc3764333d18fd", transactionIndex: "76", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "4057226", gasUsed: "24045", confirmations: "790154"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1545193016 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: timeCountdown(  )", async function( ) {
		const txOriginal = {blockNumber: "6915748", timeStamp: "1545235448", hash: "0xc83b484ea0e117f6e71c970ba8c1b38ff879f683df7b491c7c206ceb0ca91d0c", nonce: "43", blockHash: "0xd7c940b9862baacc122726aff091677c775b4403c9a0ed646ee665be9bd27d6f", transactionIndex: "101", from: "0x348441aeb65ecc33b8b549df60566d2be0013372", to: "0xb58470a0ec113f823757993182131b4f0be4042d", value: "0", gas: "1000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x46ad9cc1", contractAddress: "", cumulativeGasUsed: "5500221", gasUsed: "45362", confirmations: "787340"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "timeCountdown", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "timeCountdown()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1545235448 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deadCount", type: "uint256"}, {indexed: false, name: "liveCount", type: "uint256"}, {indexed: false, name: "deadKeys", type: "uint256"}], name: "onOutEvent", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutEvent", events: [{name: "deadCount", type: "uint256", value: "0"}, {name: "liveCount", type: "uint256", value: "3"}, {name: "deadKeys", type: "uint256", value: "12071357851665621807"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "outTime", type: "uint256"}], name: "onOutInitialEvent", type: "event"} ;
		console.error( "eventCallOriginal[49,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onOutInitialEvent", events: [{name: "outTime", type: "uint256", value: "1545235448"}], address: "0xb58470a0ec113f823757993182131b4f0be4042d"}] ;
		console.error( "eventResultOriginal[49,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "951840000000000043" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
