const InstaMaker = artifacts.require( "./InstaMaker.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "InstaMaker" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x3A306a399085F3460BbcB5b77015Ab33806A10d5", "0xb579D4f1546d51980499aa96a2E411Be3E449197", "0xE16D035B8E76303237b9660b3c9C94c1a86AAB47", "0x7284a8451d9a0e7Dc62B3a71C0593eA2eC5c5638", "0xd8db02A498E9AFbf4A32BC006DC1940495b4e592", "0xa7615CD307F323172331865181DC8b80a2834324", "0xbbD13CA6aACE2a8ECcBDe88bc7849C3c6E4e172E", "0x53CccA398F6CD117e6aa34AB71598b8F172Bf0FF", "0x184cC5908E1a3D29B4D31df67d99622C4Baa7b71", "0xFfF7830F9DDB9D48d9e213354c92604Ef7e1298b", "0xE4b205c76B78Cf72012D6040C33429Dba9bBd19B", "0xa53A13A80D72A855481DE5211E7654fAbDFE3526"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "ethNum", type: "uint256"}], name: "pethPEReth", outputs: [{name: "rPETH", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getETHRate", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "borrower", type: "address"}], name: "getCDP", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "freezed", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "addressRegistry", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "amount", type: "uint256"}], name: "MKRCollected", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "cdp", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "nextOwner", type: "address"}], name: "TranferCDP", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "cdp", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}], name: "CDPClaimed", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "daiWipe", type: "uint256"}, {indexed: false, name: "mkrCharged", type: "uint256"}, {indexed: false, name: "wipedBy", type: "address"}], name: "WipedDAI", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "ethFree", type: "uint256"}], name: "UnlockedETH", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "cdpBytes", type: "bytes32"}], name: "NewCDP", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["MKRCollected(uint256)", "TranferCDP(bytes32,address,address)", "CDPClaimed(bytes32,address)", "WipedDAI(address,uint256,uint256,address)", "UnlockedETH(address,uint256)", "LockedETH(address,uint256,uint256,address)", "LoanedDAI(address,uint256,address)", "NewCDP(address,bytes32)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x499d4b63f3a203c58019a864fc2d9cfe72954952ed53a3e40999755432cd3566", "0x54e847b75f10cd7e742b78312fe0079d5a973d8a9b9070bb0515a8390160bd51", "0x31f5dffe72808492cb2559d1f67508a7bb36622423aaac12f04b773d58bb3ffd", "0xcc6878355865ed21824b44591ff4007019184a8a745b0740f85423266f9a837e", "0x535dbd84e6041f33aaf78db176dd666c6b5d00094b3681ac68ea55ec9d0375b4", "0xae07a3d5c5e33182092cb26d77cc02764342b0772a21260cff9dfdf47e1dad19", "0x4e393322c078a1291e528e1e8719f9bc6d6845942cb87e9b2c6c1969f71db371", "0xaacf4dabf7a1318b83a988c9264a97b311ea7cef315258fd7cdab83ef8b8dedb"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6806227 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6832341 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "rAddr", value: 4}], name: "InstaMaker", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "ethNum", value: random.range( maxRandom )}], name: "pethPEReth", outputs: [{name: "rPETH", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pethPEReth(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getETHRate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getETHRate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "borrower", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getCDP", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCDP(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "freezed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "freezed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "addressRegistry", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "addressRegistry()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "InstaMaker", function( accounts ) {

	it( "TEST: InstaMaker( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6806227", timeStamp: "1543664449", hash: "0x70888cff33e93817bfce22ed4bc8b659da8d5960bb445b95f1788e1d9ec43667", nonce: "137", blockHash: "0x543b8d67435c4bd59313d5eeda9074361ecff6238b938f88961200f0ec7c2de4", transactionIndex: "57", from: "0xb579d4f1546d51980499aa96a2e411be3e449197", to: 0, value: "0", gas: "3461023", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x4147d514000000000000000000000000e16d035b8e76303237b9660b3c9c94c1a86aab47", contractAddress: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", cumulativeGasUsed: "7147443", gasUsed: "3461023", confirmations: "894623"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "rAddr", value: addressList[4]}], name: "InstaMaker", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = InstaMaker.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1543664449 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = InstaMaker.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "293223839797349742" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"1000000000000000000\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6808605", timeStamp: "1543698488", hash: "0xa9765a84cb74b710a9e12078bfcd872d507fb598cc5bcf70a79946be34fd23e4", nonce: "185", blockHash: "0x00d79656be8d92c3949a8a82b0c014394e83450e1062e56fb6f088aa11eaf419", transactionIndex: "143", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "15000000000000000", gas: "726824", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd1480000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000007284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", contractAddress: "", cumulativeGasUsed: "6811093", gasUsed: "388489", confirmations: "892245"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "15000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "1000000000000000000"}, {type: "address", name: "beneficiary", value: addressList[5]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "1000000000000000000", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1543698488 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[1,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "lockETH", type: "uint256", value: "15000000000000000"}, {name: "lockPETH", type: "uint256", value: "14447958282435392"}, {name: "lockedBy", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[1,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[1,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "loanDAI", type: "uint256", value: "1000000000000000000"}, {name: "payTo", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[1,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "cdpBytes", type: "bytes32"}], name: "NewCDP", type: "event"} ;
		console.error( "eventCallOriginal[1,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewCDP", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "cdpBytes", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000001238"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[1,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"1000000000000000000\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6808641", timeStamp: "1543698821", hash: "0xf205f95ec7d30ef559788f214748784b7604fe293513e9bf732c4c0571caf364", nonce: "186", blockHash: "0x44de358fbd8232385a8301e6633bd193578e6bd6bc31fe89785c6a96ab1865a4", transactionIndex: "25", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "12000000000000000", gas: "453412", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd1480000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000007284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", contractAddress: "", cumulativeGasUsed: "1484745", gasUsed: "272275", confirmations: "892209"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "12000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "1000000000000000000"}, {type: "address", name: "beneficiary", value: addressList[5]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "1000000000000000000", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1543698821 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[2,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "lockETH", type: "uint256", value: "12000000000000000"}, {name: "lockPETH", type: "uint256", value: "11558366625948314"}, {name: "lockedBy", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[2,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[2,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "loanDAI", type: "uint256", value: "1000000000000000000"}, {name: "payTo", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[2,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"1500000000000000000\", \"2000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6808887", timeStamp: "1543702389", hash: "0xf4354d066a16bd4fc0b81d741daf6d51f8b413b50798d1386129384da38c773d", nonce: "189", blockHash: "0x4f38f4f00390daa09557cff10329aa606b146ec7e81dcca7ee78ba09a0715710", transactionIndex: "91", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "40654696988", gas: "1049743", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd8aed14500000000000000000000000000000000000000000000000014d1120d7b16000000000000000000000000000000000000000000000000000000470de4df820000", contractAddress: "", cumulativeGasUsed: "5647174", gasUsed: "639257", confirmations: "891963"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "40654696988" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "1500000000000000000"}, {type: "uint256", name: "ethFree", value: "20000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "1500000000000000000", "20000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1543702389 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "daiWipe", type: "uint256"}, {indexed: false, name: "mkrCharged", type: "uint256"}, {indexed: false, name: "wipedBy", type: "address"}], name: "WipedDAI", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WipedDAI", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "daiWipe", type: "uint256", value: "1500000000000000000"}, {name: "mkrCharged", type: "uint256", value: "11900330011"}, {name: "wipedBy", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "ethFree", type: "uint256"}], name: "UnlockedETH", type: "event"} ;
		console.error( "eventCallOriginal[3,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UnlockedETH", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "ethFree", type: "uint256", value: "20000000000000000"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[3,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"300000000000000000\", \"10000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6808906", timeStamp: "1543702674", hash: "0xfe574c97071cf7ee85e25cf8b9a99c69a724e020ee69dea7039994b6598ecc35", nonce: "190", blockHash: "0x962d5f2c5f33c2c7716f36f579d8b55d12b5db0d8cb35b70abef5ba8e3a085cf", transactionIndex: "78", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "8587149681", gas: "1070766", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd8aed1450000000000000000000000000000000000000000000000000429d069189e000000000000000000000000000000000000000000000000000000038d7ea4c68000", contractAddress: "", cumulativeGasUsed: "4810282", gasUsed: "653252", confirmations: "891944"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "8587149681" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "300000000000000000"}, {type: "uint256", name: "ethFree", value: "1000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "300000000000000000", "1000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543702674 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "daiWipe", type: "uint256"}, {indexed: false, name: "mkrCharged", type: "uint256"}, {indexed: false, name: "wipedBy", type: "address"}], name: "WipedDAI", type: "event"} ;
		console.error( "eventCallOriginal[4,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WipedDAI", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "daiWipe", type: "uint256", value: "300000000000000000"}, {name: "mkrCharged", type: "uint256", value: "2561702065"}, {name: "wipedBy", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[4,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "ethFree", type: "uint256"}], name: "UnlockedETH", type: "event"} ;
		console.error( "eventCallOriginal[4,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UnlockedETH", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "ethFree", type: "uint256", value: "1000000000000000"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[4,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"1400000000000000000\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6808928", timeStamp: "1543703139", hash: "0x7b1f162cef1b80b20145a2d8f018cb6b09e379819386a45a985c24e806507c50", nonce: "191", blockHash: "0x0be054329843a3c441aeae92ca9c158b8f6353d037f0cb40a13ba32a0f58768f", transactionIndex: "61", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "20000000000000000", gas: "476367", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd148000000000000000000000000000000000000000000000000136dcc951d8c00000000000000000000000000007284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", contractAddress: "", cumulativeGasUsed: "6089985", gasUsed: "287891", confirmations: "891922"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "1400000000000000000"}, {type: "address", name: "beneficiary", value: addressList[5]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "1400000000000000000", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1543703139 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[5,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "lockETH", type: "uint256", value: "20000000000000000"}, {name: "lockPETH", type: "uint256", value: "19263944376580523"}, {name: "lockedBy", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[5,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[5,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "loanDAI", type: "uint256", value: "1400000000000000000"}, {name: "payTo", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[5,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: transferCDP( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6808941", timeStamp: "1543703318", hash: "0x05707750ccf2a43e076be428e413114c13baa705f8c382c04a8ed0a195ebab73", nonce: "192", blockHash: "0x7ce4e931bc8a000d2f95658235551e03f1fc2b1c14b100bb77fea1e6d194d537", transactionIndex: "89", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "64912", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd583b2060000000000000000000000007284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", contractAddress: "", cumulativeGasUsed: "5344749", gasUsed: "28275", confirmations: "891909"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "nextOwner", value: addressList[5]}], name: "transferCDP", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferCDP(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1543703318 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cdp", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "nextOwner", type: "address"}], name: "TranferCDP", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TranferCDP", events: [{name: "cdp", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "owner", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "nextOwner", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: claimCDP( \"4664\" )", async function( ) {
		const txOriginal = {blockNumber: "6808953", timeStamp: "1543703461", hash: "0x830e79b70061164acf8be250d7fb1d2f955759278e9b18f41d7dcc19bd28d4db", nonce: "193", blockHash: "0x27cf6ee7345db46d6eea3b95e8a035b24739bd885f2c87a9e71892bd5773b8d8", transactionIndex: "88", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "71563", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xb9ca3bf60000000000000000000000000000000000000000000000000000000000001238", contractAddress: "", cumulativeGasUsed: "7927511", gasUsed: "47709", confirmations: "891897"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "cdpNum", value: "4664"}], name: "claimCDP", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimCDP(uint256)" ]( "4664", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543703461 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cdp", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}], name: "CDPClaimed", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CDPClaimed", events: [{name: "cdp", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000001238"}, {name: "owner", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"1000000000000000000\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6811459", timeStamp: "1543739874", hash: "0x67c4e120e09feab8527c789f87effcd1eabad9edd36c05bdee9117e36aba53fb", nonce: "195", blockHash: "0xabd4da6b02350aecc2b2a85bd9f7f078d73c42db5f595aed360bdc24ced368c4", transactionIndex: "44", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "10000000000000000", gas: "429666", gasPrice: "6500000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd1480000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000007284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", contractAddress: "", cumulativeGasUsed: "3258022", gasUsed: "271226", confirmations: "889391"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "1000000000000000000"}, {type: "address", name: "beneficiary", value: addressList[5]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "1000000000000000000", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1543739874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[8,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "lockETH", type: "uint256", value: "10000000000000000"}, {name: "lockPETH", type: "uint256", value: "9631972188290205"}, {name: "lockedBy", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[8,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[8,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "loanDAI", type: "uint256", value: "1000000000000000000"}, {name: "payTo", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[8,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: collectMKR( \"1000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6811630", timeStamp: "1543742173", hash: "0xb9bab89296338abcbbbdb0e9f87723e9775df0d7d584670f75d918889cefc534", nonce: "196", blockHash: "0x6af757906bd4966d865321518cc4bc4edfa8a3c9a6da1ae3beeb1089178bfe00", transactionIndex: "45", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "92383", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xf2fec91300000000000000000000000000000000000000000000000000038d7ea4c68000", contractAddress: "", cumulativeGasUsed: "3280841", gasUsed: "61589", confirmations: "889220"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amount", value: "1000000000000000"}], name: "collectMKR", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "collectMKR(uint256)" ]( "1000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543742173 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amount", type: "uint256"}], name: "MKRCollected", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "MKRCollected", events: [{name: "amount", type: "uint256", value: "1000000000000000"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"100000000000000000\", \"10000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6811660", timeStamp: "1543742544", hash: "0x514c60b233dcd82a56dc680ae7d5068c22f6e20bffe31fe5f5250981fc5c9c15", nonce: "198", blockHash: "0x0c8cd8aa49f64336f343e47aee44e6e99d513a1a9cdea0c7bb825f2a6aca2c31", transactionIndex: "13", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "558649", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd8aed145000000000000000000000000000000000000000000000000016345785d8a000000000000000000000000000000000000000000000000000000038d7ea4c68000", contractAddress: "", cumulativeGasUsed: "1179388", gasUsed: "341861", confirmations: "889190"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "100000000000000000"}, {type: "uint256", name: "ethFree", value: "1000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "100000000000000000", "1000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1543742544 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "daiWipe", type: "uint256"}, {indexed: false, name: "mkrCharged", type: "uint256"}, {indexed: false, name: "wipedBy", type: "address"}], name: "WipedDAI", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WipedDAI", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "daiWipe", type: "uint256", value: "100000000000000000"}, {name: "mkrCharged", type: "uint256", value: "5058134902"}, {name: "wipedBy", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "ethFree", type: "uint256"}], name: "UnlockedETH", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UnlockedETH", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "ethFree", type: "uint256", value: "1000000000000000"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: transferCDP( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6811692", timeStamp: "1543742977", hash: "0xea7c1f6367d9bd26fd5d46c25f148b169543bb49b226a14adfdb8a33f6324190", nonce: "199", blockHash: "0x0f09582a94ce285127be18f3988dd898f0132b32b281adf2abc3920136f5779c", transactionIndex: "69", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "64912", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xd583b2060000000000000000000000007284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", contractAddress: "", cumulativeGasUsed: "4342142", gasUsed: "28275", confirmations: "889158"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "nextOwner", value: addressList[5]}], name: "transferCDP", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferCDP(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1543742977 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cdp", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "nextOwner", type: "address"}], name: "TranferCDP", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TranferCDP", events: [{name: "cdp", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "owner", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "nextOwner", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: collectMKR( \"9008802735619375\" )", async function( ) {
		const txOriginal = {blockNumber: "6818730", timeStamp: "1543843785", hash: "0x5b3cddd0573cdc1d7db89e209c923de7040785a24b5968778b09dcf5517f0957", nonce: "205", blockHash: "0x9d3fc9bffe071038b1eb1e210b1007afeb49bbca16e90d631c0982bbf631e319", transactionIndex: "71", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "69979", gasPrice: "5200000000", isError: "0", txreceipt_status: "1", input: "0xf2fec9130000000000000000000000000000000000000000000000000020017556e87d2f", contractAddress: "", cumulativeGasUsed: "5488970", gasUsed: "31653", confirmations: "882120"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amount", value: "9008802735619375"}], name: "collectMKR", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "collectMKR(uint256)" ]( "9008802735619375", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1543843785 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amount", type: "uint256"}], name: "MKRCollected", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "MKRCollected", events: [{name: "amount", type: "uint256", value: "9008802735619375"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: collectMKR( \"5000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6818783", timeStamp: "1543844486", hash: "0x47ef6b1953a5f82f92937838bdd77e25d22ef444ba4c5622746faa9b2aacd9d4", nonce: "206", blockHash: "0x0523494c2eaa95daf769b29f31368cff23bdb98789e4143074aa5f731e7df8d6", transactionIndex: "122", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "69883", gasPrice: "5500000000", isError: "0", txreceipt_status: "1", input: "0xf2fec9130000000000000000000000000000000000000000000000000011c37937e08000", contractAddress: "", cumulativeGasUsed: "6381368", gasUsed: "46589", confirmations: "882067"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amount", value: "5000000000000000"}], name: "collectMKR", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "collectMKR(uint256)" ]( "5000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1543844486 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "amount", type: "uint256"}], name: "MKRCollected", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "MKRCollected", events: [{name: "amount", type: "uint256", value: "5000000000000000"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"6000000000000000000\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6818836", timeStamp: "1543845281", hash: "0xb3091ce53099d8ce3d1087e4a3e96c4f3dbe48dc1affd622f0ca558205909321", nonce: "13", blockHash: "0xac2062d69e4a3b6aa319dff7b0217749c6eda3ba73f9404205e9f6e01ea72a6f", transactionIndex: "61", from: "0xd8db02a498e9afbf4a32bc006dc1940495b4e592", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "100000000000000000", gas: "624231", gasPrice: "5400000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd14800000000000000000000000000000000000000000000000053444835ec580000000000000000000000000000d8db02a498e9afbf4a32bc006dc1940495b4e592", contractAddress: "", cumulativeGasUsed: "7747625", gasUsed: "385483", confirmations: "882014"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "6000000000000000000"}, {type: "address", name: "beneficiary", value: addressList[6]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "6000000000000000000", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1543845281 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[14,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0xd8db02a498e9afbf4a32bc006dc1940495b4e592"}, {name: "lockETH", type: "uint256", value: "100000000000000000"}, {name: "lockPETH", type: "uint256", value: "96319718925363157"}, {name: "lockedBy", type: "address", value: "0xd8db02a498e9afbf4a32bc006dc1940495b4e592"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[14,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[14,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0xd8db02a498e9afbf4a32bc006dc1940495b4e592"}, {name: "loanDAI", type: "uint256", value: "6000000000000000000"}, {name: "payTo", type: "address", value: "0xd8db02a498e9afbf4a32bc006dc1940495b4e592"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[14,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "cdpBytes", type: "bytes32"}], name: "NewCDP", type: "event"} ;
		console.error( "eventCallOriginal[14,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewCDP", events: [{name: "borrower", type: "address", value: "0xd8db02a498e9afbf4a32bc006dc1940495b4e592"}, {name: "cdpBytes", type: "bytes32", value: "0x000000000000000000000000000000000000000000000000000000000000126d"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[14,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1036015168137214929" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: claimCDP( \"4664\" )", async function( ) {
		const txOriginal = {blockNumber: "6818898", timeStamp: "1543846410", hash: "0xf7a021a81f7dd66eb9bf84a9a28e91d8f2585aff8855afac8e59d8aa68aecf97", nonce: "209", blockHash: "0xf8a969e5cb681f8fbda4da8dfe08f2e3b17c51cca420b8a74c922417e8d96c27", transactionIndex: "2", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "71563", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xb9ca3bf60000000000000000000000000000000000000000000000000000000000001238", contractAddress: "", cumulativeGasUsed: "153658", gasUsed: "47709", confirmations: "881952"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "cdpNum", value: "4664"}], name: "claimCDP", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimCDP(uint256)" ]( "4664", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1543846410 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cdp", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}], name: "CDPClaimed", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CDPClaimed", events: [{name: "cdp", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000001238"}, {name: "owner", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"2500000000000000000\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6818960", timeStamp: "1543847292", hash: "0x31ca4cf62a7e5f32cc5da59cca80846fb8d70196f67c67cf52f7c182ba722954", nonce: "212", blockHash: "0x418f1f5842607176e1b562a70058349ebddfc300c00ba196c13c3c41158060b8", transactionIndex: "95", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "2492853471433", gas: "804325", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xd8aed14500000000000000000000000000000000000000000000000022b1c8c1227a00000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5532624", gasUsed: "475970", confirmations: "881890"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "2492853471433" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "2500000000000000000"}, {type: "uint256", name: "ethFree", value: "0"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "2500000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1543847292 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "daiWipe", type: "uint256"}, {indexed: false, name: "mkrCharged", type: "uint256"}, {indexed: false, name: "wipedBy", type: "address"}], name: "WipedDAI", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WipedDAI", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "daiWipe", type: "uint256", value: "2500000000000000000"}, {name: "mkrCharged", type: "uint256", value: "653095280848"}, {name: "wipedBy", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transferCDP( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6818988", timeStamp: "1543847648", hash: "0x928b553ad4a41833c22d00960335707b6bbb608acd9339fa72b0aaac2fa8e222", nonce: "213", blockHash: "0x6ed32a2c0d3571d9b790b5cd4aa1d08bb7a742285ee480a828b3dd4b041ab72a", transactionIndex: "49", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "64912", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xd583b2060000000000000000000000007284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", contractAddress: "", cumulativeGasUsed: "3722621", gasUsed: "28275", confirmations: "881862"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "nextOwner", value: addressList[5]}], name: "transferCDP", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferCDP(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1543847648 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cdp", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "nextOwner", type: "address"}], name: "TranferCDP", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TranferCDP", events: [{name: "cdp", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {name: "owner", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "nextOwner", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: claimCDP( \"2086\" )", async function( ) {
		const txOriginal = {blockNumber: "6819065", timeStamp: "1543848646", hash: "0xc795adeef9ea0b87e6abd9377ebfe7745c98d32d5681a1ed36a27671b14d7208", nonce: "218", blockHash: "0x577d256611f4f9bd30ed09f31839651f82aedc58fa62dd1f131c232ece32bcc3", transactionIndex: "52", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "71563", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb9ca3bf60000000000000000000000000000000000000000000000000000000000000826", contractAddress: "", cumulativeGasUsed: "3357841", gasUsed: "47709", confirmations: "881785"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "cdpNum", value: "2086"}], name: "claimCDP", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimCDP(uint256)" ]( "2086", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1543848646 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cdp", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}], name: "CDPClaimed", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CDPClaimed", events: [{name: "cdp", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000000826"}, {name: "owner", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: claimCDP( \"4664\" )", async function( ) {
		const txOriginal = {blockNumber: "6819211", timeStamp: "1543850726", hash: "0x6d4ded5c0a4ae47bbdc35a8c9a43f22c1158d20c09f3480fe261bfdd257d8e31", nonce: "139", blockHash: "0xe4fb2cd5542914d41906263c623c1af1e1f7a02b15eef3a790333a54d0de04bd", transactionIndex: "109", from: "0xb579d4f1546d51980499aa96a2e411be3e449197", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "71563", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb9ca3bf60000000000000000000000000000000000000000000000000000000000001238", contractAddress: "", cumulativeGasUsed: "7830946", gasUsed: "47709", confirmations: "881639"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "cdpNum", value: "4664"}], name: "claimCDP", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimCDP(uint256)" ]( "4664", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1543850726 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cdp", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}], name: "CDPClaimed", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CDPClaimed", events: [{name: "cdp", type: "bytes32", value: "0x0000000000000000000000000000000000000000000000000000000000001238"}, {name: "owner", type: "address", value: "0xb579d4f1546d51980499aa96a2e411be3e449197"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "293223839797349742" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: claimCDP( \"4639\" )", async function( ) {
		const txOriginal = {blockNumber: "6819239", timeStamp: "1543851240", hash: "0x8fc2cb28cce74f9fc06aec6dea7483952c238275b35858ab804763756d7f2daf", nonce: "224", blockHash: "0xc2ab5ed346ef17d3895613cf3c0e639c4aaf453b2d0bffc480802772a282fd23", transactionIndex: "54", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "71563", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xb9ca3bf6000000000000000000000000000000000000000000000000000000000000121f", contractAddress: "", cumulativeGasUsed: "3910139", gasUsed: "47709", confirmations: "881611"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "cdpNum", value: "4639"}], name: "claimCDP", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimCDP(uint256)" ]( "4639", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1543851240 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cdp", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}], name: "CDPClaimed", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CDPClaimed", events: [{name: "cdp", type: "bytes32", value: "0x000000000000000000000000000000000000000000000000000000000000121f"}, {name: "owner", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"0\", \"100000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6819384", timeStamp: "1543853306", hash: "0x9f8145b4a873b87eeea11b7a1995ce77172b3faa5b0d0bc436910813c3b645c2", nonce: "225", blockHash: "0x5033b44beef31874e8cfb23594c40f034a0713caa90ab412c56f9f3e09a31cf5", transactionIndex: "147", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "302530", gasPrice: "6500000000", isError: "0", txreceipt_status: "1", input: "0xd8aed1450000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016345785d8a0000", contractAddress: "", cumulativeGasUsed: "7604964", gasUsed: "185962", confirmations: "881466"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "0"}, {type: "uint256", name: "ethFree", value: "100000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "0", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1543853306 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "ethFree", type: "uint256"}], name: "UnlockedETH", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UnlockedETH", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "ethFree", type: "uint256", value: "100000000000000000"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: claimCDP( \"4254\" )", async function( ) {
		const txOriginal = {blockNumber: "6820054", timeStamp: "1543863125", hash: "0x41a2e09aa26caa2f42b0358b235c43abc73f405ed3e27f231020f8e1561da32e", nonce: "66", blockHash: "0xc7dde194e79a926b12fe9d7e2abf183fd939202f0dff4d8287cc4eb7f3d28b26", transactionIndex: "13", from: "0xa7615cd307f323172331865181dc8b80a2834324", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "71563", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xb9ca3bf6000000000000000000000000000000000000000000000000000000000000109e", contractAddress: "", cumulativeGasUsed: "2116631", gasUsed: "47709", confirmations: "880796"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "cdpNum", value: "4254"}], name: "claimCDP", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimCDP(uint256)" ]( "4254", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1543863125 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cdp", type: "bytes32"}, {indexed: false, name: "owner", type: "address"}], name: "CDPClaimed", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CDPClaimed", events: [{name: "cdp", type: "bytes32", value: "0x000000000000000000000000000000000000000000000000000000000000109e"}, {name: "owner", type: "address", value: "0xa7615cd307f323172331865181dc8b80a2834324"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "710193100695390033" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"10000000000000000000\", addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6820182", timeStamp: "1543865111", hash: "0xc7b6c83d931cadf36c61c64f139df3ba5cc05afe8591f6940b549ef7d64a351d", nonce: "182", blockHash: "0x7bf71061c261af863797709395fee3d6fec331c2214f64fa19ff6702ab809d5b", transactionIndex: "64", from: "0xbbd13ca6aace2a8eccbde88bc7849c3c6e4e172e", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "200000000000000000", gas: "603885", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd1480000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000bbd13ca6aace2a8eccbde88bc7849c3c6e4e172e", contractAddress: "", cumulativeGasUsed: "5790451", gasUsed: "370925", confirmations: "880668"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "10000000000000000000"}, {type: "address", name: "beneficiary", value: addressList[8]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "10000000000000000000", addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1543865111 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[23,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0xbbd13ca6aace2a8eccbde88bc7849c3c6e4e172e"}, {name: "lockETH", type: "uint256", value: "200000000000000000"}, {name: "lockPETH", type: "uint256", value: "192639436524181160"}, {name: "lockedBy", type: "address", value: "0xbbd13ca6aace2a8eccbde88bc7849c3c6e4e172e"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[23,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[23,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0xbbd13ca6aace2a8eccbde88bc7849c3c6e4e172e"}, {name: "loanDAI", type: "uint256", value: "10000000000000000000"}, {name: "payTo", type: "address", value: "0xbbd13ca6aace2a8eccbde88bc7849c3c6e4e172e"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[23,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "cdpBytes", type: "bytes32"}], name: "NewCDP", type: "event"} ;
		console.error( "eventCallOriginal[23,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewCDP", events: [{name: "borrower", type: "address", value: "0xbbd13ca6aace2a8eccbde88bc7849c3c6e4e172e"}, {name: "cdpBytes", type: "bytes32", value: "0x000000000000000000000000000000000000000000000000000000000000127b"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[23,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "917947190801848605" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"0\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6820681", timeStamp: "1543871479", hash: "0x634d5d30be06447bcf3d20ace004475cc7d39ab930e317657876dc596cc868d9", nonce: "226", blockHash: "0xeb97d8d7ad7e5e6aae12609d59a9388e932be97c760c6dfabf20a05328064409", transactionIndex: "238", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "500000000000000000", gas: "336106", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd14800000000000000000000000000000000000000000000000000000000000000000000000000000000000000007284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", contractAddress: "", cumulativeGasUsed: "7349495", gasUsed: "142404", confirmations: "880169"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "0"}, {type: "address", name: "beneficiary", value: addressList[5]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "0", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1543871479 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[24,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "lockETH", type: "uint256", value: "500000000000000000"}, {name: "lockPETH", type: "uint256", value: "481598586649059880"}, {name: "lockedBy", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[24,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13001064217022423095" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"30000000000000000000\", addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6824774", timeStamp: "1543929705", hash: "0x5f433140d2a70e58038c5eb92c7aae83c0f44e5fe4f981ed92cfcf60605f8e85", nonce: "1", blockHash: "0x6f2d798f28fc23bd3ab91083ad0f211b3ade69c1170fc56dc923b755308c13bc", transactionIndex: "87", from: "0x53ccca398f6cd117e6aa34ab71598b8f172bf0ff", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "500000000000000000", gas: "625899", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd148000000000000000000000000000000000000000000000001a055690d9db8000000000000000000000000000053ccca398f6cd117e6aa34ab71598b8f172bf0ff", contractAddress: "", cumulativeGasUsed: "6771192", gasUsed: "387048", confirmations: "876076"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "30000000000000000000"}, {type: "address", name: "beneficiary", value: addressList[9]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "30000000000000000000", addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1543929705 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[25,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0x53ccca398f6cd117e6aa34ab71598b8f172bf0ff"}, {name: "lockETH", type: "uint256", value: "500000000000000000"}, {name: "lockPETH", type: "uint256", value: "481598586649059880"}, {name: "lockedBy", type: "address", value: "0x53ccca398f6cd117e6aa34ab71598b8f172bf0ff"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[25,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[25,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0x53ccca398f6cd117e6aa34ab71598b8f172bf0ff"}, {name: "loanDAI", type: "uint256", value: "30000000000000000000"}, {name: "payTo", type: "address", value: "0x53ccca398f6cd117e6aa34ab71598b8f172bf0ff"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[25,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "cdpBytes", type: "bytes32"}], name: "NewCDP", type: "event"} ;
		console.error( "eventCallOriginal[25,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewCDP", events: [{name: "borrower", type: "address", value: "0x53ccca398f6cd117e6aa34ab71598b8f172bf0ff"}, {name: "cdpBytes", type: "bytes32", value: "0x000000000000000000000000000000000000000000000000000000000000129c"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[25,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "493948000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"3000000000000000000000\", addressList[... )", async function( ) {
		const txOriginal = {blockNumber: "6825382", timeStamp: "1543938385", hash: "0xc755830972a91b8a7ad7cd83c8d3bb4db0c817f61a5bf3870dc4f6a8aab6db2c", nonce: "286", blockHash: "0xf96cdb23cad850de64c3928176d5ecf77a55fdc40889ab22ee6b1862d2eed997", transactionIndex: "131", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "60000000000000000000", gas: "625914", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd1480000000000000000000000000000000000000000000000a2a15d09519be00000000000000000000000000000184cc5908e1a3d29b4d31df67d99622c4baa7b71", contractAddress: "", cumulativeGasUsed: "7664688", gasUsed: "387957", confirmations: "875468"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "60000000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "3000000000000000000000"}, {type: "address", name: "beneficiary", value: addressList[10]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "3000000000000000000000", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1543938385 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[26,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "lockETH", type: "uint256", value: "60000000000000000000"}, {name: "lockPETH", type: "uint256", value: "57791830397887185649"}, {name: "lockedBy", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[26,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[26,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "loanDAI", type: "uint256", value: "3000000000000000000000"}, {name: "payTo", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[26,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "cdpBytes", type: "bytes32"}], name: "NewCDP", type: "event"} ;
		console.error( "eventCallOriginal[26,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewCDP", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "cdpBytes", type: "bytes32", value: "0x00000000000000000000000000000000000000000000000000000000000012a0"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[26,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"3000000000000000000000\", \"6000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6825438", timeStamp: "1543939332", hash: "0xff41efd50cc1c4ff00d86973a348661425ba823d5178c32655785bc74583a1ba", nonce: "290", blockHash: "0x6084f93cbfbf3ff2b83dac295cf0467ac043f390c896731c276e73468a85b2e1", transactionIndex: "4", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "18112875047380", gas: "7600027", gasPrice: "12000000000", isError: "1", txreceipt_status: "0", input: "0xd8aed1450000000000000000000000000000000000000000000000a2a15d09519be0000000000000000000000000000000000000000000000000000340aad21b3b700000", contractAddress: "", cumulativeGasUsed: "665814", gasUsed: "508073", confirmations: "875412"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "18112875047380" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "3000000000000000000000"}, {type: "uint256", name: "ethFree", value: "60000000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "3000000000000000000000", "60000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1543939332 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"3000000000000000000000\", \"6000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6825445", timeStamp: "1543939481", hash: "0x5717c77718fb6f57743475c5cc0111978c577f0673fc29bddbab503fa57c293e", nonce: "291", blockHash: "0xc96b6e817050eae5b2c824d3f08f570ce8303c93838e46660a2e0fb116ba32ea", transactionIndex: "101", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "24688740668215", gas: "1048074", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd8aed1450000000000000000000000000000000000000000000000a2a15d09519be0000000000000000000000000000000000000000000000000000340aad21b3b700000", contractAddress: "", cumulativeGasUsed: "5212144", gasUsed: "605866", confirmations: "875405"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "24688740668215" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "3000000000000000000000"}, {type: "uint256", name: "ethFree", value: "60000000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "3000000000000000000000", "60000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1543939481 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "daiWipe", type: "uint256"}, {indexed: false, name: "mkrCharged", type: "uint256"}, {indexed: false, name: "wipedBy", type: "address"}], name: "WipedDAI", type: "event"} ;
		console.error( "eventCallOriginal[28,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WipedDAI", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "daiWipe", type: "uint256", value: "3000000000000000000000"}, {name: "mkrCharged", type: "uint256", value: "6412066125260"}, {name: "wipedBy", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[28,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "ethFree", type: "uint256"}], name: "UnlockedETH", type: "event"} ;
		console.error( "eventCallOriginal[28,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UnlockedETH", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "ethFree", type: "uint256", value: "60000000000000000000"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[28,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"5500000000000000000000\", addressList[... )", async function( ) {
		const txOriginal = {blockNumber: "6825627", timeStamp: "1543942072", hash: "0x4c3aa95bdfabdcd6f5a8473abb76152a8163ceb7e4ae79990e270bc6dd81d3e3", nonce: "292", blockHash: "0xfc2367e8366c6ec44d7ae69d2ccba6b1934b67074e5b33a734c2166c9cefdfc0", transactionIndex: "36", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "100000000000000000000", gas: "517360", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd14800000000000000000000000000000000000000000000012a27d53bc048700000000000000000000000000000184cc5908e1a3d29b4d31df67d99622c4baa7b71", contractAddress: "", cumulativeGasUsed: "7225806", gasUsed: "316269", confirmations: "875223"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "5500000000000000000000"}, {type: "address", name: "beneficiary", value: addressList[10]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "5500000000000000000000", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1543942072 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[29,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "lockETH", type: "uint256", value: "100000000000000000000"}, {name: "lockPETH", type: "uint256", value: "96319717329811976083"}, {name: "lockedBy", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[29,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[29,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "loanDAI", type: "uint256", value: "5500000000000000000000"}, {name: "payTo", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[29,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"0\", \"8900000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6826561", timeStamp: "1543954915", hash: "0xd910cf5bee1a1222045877bd9bd9d34860ad3ec61eadbc00a62ab738059b62cb", nonce: "302", blockHash: "0x730280c943d379b965d0fc6b968060ac315f56c66b0e6397d8aee75103819883", transactionIndex: "73", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "304359", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd8aed14500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007b8326d884fa0000", contractAddress: "", cumulativeGasUsed: "7162369", gasUsed: "186871", confirmations: "874289"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "0"}, {type: "uint256", name: "ethFree", value: "8900000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "0", "8900000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1543954915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "ethFree", type: "uint256"}], name: "UnlockedETH", type: "event"} ;
		console.error( "eventCallOriginal[30,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UnlockedETH", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "ethFree", type: "uint256", value: "8900000000000000000"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[30,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"1079000000000000000000\", \"7000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826673", timeStamp: "1543956247", hash: "0xba8f2167441b63e670b4bc61d7a17797fd1f1d5f96d20d0e58118e1abaaa3026", nonce: "307", blockHash: "0x10eaeb71526c907eccf1c76f424fe5337920ed67f794862d3a2d592fef4464fc", transactionIndex: "40", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "120002347608713", gas: "1017405", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xd8aed14500000000000000000000000000000000000000000000003a7e220f36867c00000000000000000000000000000000000000000000000000006124fee993bc0000", contractAddress: "", cumulativeGasUsed: "3253657", gasUsed: "636954", confirmations: "874177"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "120002347608713" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "1079000000000000000000"}, {type: "uint256", name: "ethFree", value: "7000000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "1079000000000000000000", "7000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1543956247 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "daiWipe", type: "uint256"}, {indexed: false, name: "mkrCharged", type: "uint256"}, {indexed: false, name: "wipedBy", type: "address"}], name: "WipedDAI", type: "event"} ;
		console.error( "eventCallOriginal[31,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WipedDAI", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "daiWipe", type: "uint256", value: "1079000000000000000000"}, {name: "mkrCharged", type: "uint256", value: "29736741394013"}, {name: "wipedBy", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[31,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "ethFree", type: "uint256"}], name: "UnlockedETH", type: "event"} ;
		console.error( "eventCallOriginal[31,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UnlockedETH", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "ethFree", type: "uint256", value: "7000000000000000000"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[31,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"50000000000000000000\", addressList[11... )", async function( ) {
		const txOriginal = {blockNumber: "6827527", timeStamp: "1543969394", hash: "0xc5ba3ac77a91fe0247c13c718a6ac64472bfac7c234c7c93758ff0814adb5bba", nonce: "22", blockHash: "0xee1778dea9c9c448bdcf0bce79e0e2e7ffb32a6ec937b81f8770fe2d4b44e754", transactionIndex: "98", from: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "1000000000000000000", gas: "648072", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd148000000000000000000000000000000000000000000000002b5e3af16b1880000000000000000000000000000fff7830f9ddb9d48d9e213354c92604ef7e1298b", contractAddress: "", cumulativeGasUsed: "6876115", gasUsed: "400829", confirmations: "873323"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "50000000000000000000"}, {type: "address", name: "beneficiary", value: addressList[11]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "50000000000000000000", addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1543969394 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[32,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b"}, {name: "lockETH", type: "uint256", value: "1000000000000000000"}, {name: "lockPETH", type: "uint256", value: "963197173298119760"}, {name: "lockedBy", type: "address", value: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[32,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[32,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b"}, {name: "loanDAI", type: "uint256", value: "50000000000000000000"}, {name: "payTo", type: "address", value: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[32,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "cdpBytes", type: "bytes32"}], name: "NewCDP", type: "event"} ;
		console.error( "eventCallOriginal[32,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewCDP", events: [{name: "borrower", type: "address", value: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b"}, {name: "cdpBytes", type: "bytes32", value: "0x00000000000000000000000000000000000000000000000000000000000012ae"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[32,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "718809857125790252" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"12000000000000000000\", addressList[12... )", async function( ) {
		const txOriginal = {blockNumber: "6830138", timeStamp: "1544006892", hash: "0x166830ffd8bcf5ced2efc1564e1749de9d88dcdda4d519b24638db288e7b713a", nonce: "115", blockHash: "0x7602158b825e001bce25f5aee04dbe347842dcce23af3c8210c6d8d569f76bce", transactionIndex: "149", from: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "200000000000000000", gas: "604339", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd148000000000000000000000000000000000000000000000000a688906bd8b00000000000000000000000000000e4b205c76b78cf72012d6040c33429dba9bbd19b", contractAddress: "", cumulativeGasUsed: "5451420", gasUsed: "372580", confirmations: "870712"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "12000000000000000000"}, {type: "address", name: "beneficiary", value: addressList[12]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "12000000000000000000", addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1544006892 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[33,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}, {name: "lockETH", type: "uint256", value: "200000000000000000"}, {name: "lockPETH", type: "uint256", value: "192639346276795412"}, {name: "lockedBy", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[33,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[33,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}, {name: "loanDAI", type: "uint256", value: "12000000000000000000"}, {name: "payTo", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[33,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "cdpBytes", type: "bytes32"}], name: "NewCDP", type: "event"} ;
		console.error( "eventCallOriginal[33,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewCDP", events: [{name: "borrower", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}, {name: "cdpBytes", type: "bytes32", value: "0x00000000000000000000000000000000000000000000000000000000000012c4"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[33,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "193927113676075496" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"10000000000000000000\", addressList[12... )", async function( ) {
		const txOriginal = {blockNumber: "6830185", timeStamp: "1544007553", hash: "0x903243d020623cc972c16e645e9077c7a391c781705a2e7d81c7badee876b60d", nonce: "116", blockHash: "0x318ab468c6edf447fefba09b20496b6b4a2d282941b888d3bf4fb881823556e6", transactionIndex: "51", from: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "200000000000000000", gas: "449229", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd1480000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000e4b205c76b78cf72012d6040c33429dba9bbd19b", contractAddress: "", cumulativeGasUsed: "7256902", gasUsed: "271216", confirmations: "870665"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "10000000000000000000"}, {type: "address", name: "beneficiary", value: addressList[12]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "10000000000000000000", addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1544007553 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[34,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}, {name: "lockETH", type: "uint256", value: "200000000000000000"}, {name: "lockPETH", type: "uint256", value: "192639346276795412"}, {name: "lockedBy", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[34,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[34,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}, {name: "loanDAI", type: "uint256", value: "10000000000000000000"}, {name: "payTo", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[34,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "193927113676075496" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"22000000000000000000\", \"400000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6830412", timeStamp: "1544011072", hash: "0xefca1ff681ebd5fd1484f859fa44b8832e92851683ffa7ef694b6f402779e906", nonce: "118", blockHash: "0x408c184a4e7a5dda2ebd5f92f4add9c87018c1546d202294c6c640d27a5c083b", transactionIndex: "0", from: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "535844411016", gas: "7600027", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xd8aed145000000000000000000000000000000000000000000000001314fb37062980000000000000000000000000000000000000000000000000000058d15e176280000", contractAddress: "", cumulativeGasUsed: "506950", gasUsed: "506950", confirmations: "870438"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "535844411016" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "22000000000000000000"}, {type: "uint256", name: "ethFree", value: "400000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "22000000000000000000", "400000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1544011072 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "193927113676075496" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"4421000000000000000000\", \"8410000000... )", async function( ) {
		const txOriginal = {blockNumber: "6830428", timeStamp: "1544011466", hash: "0xe40efdd6553243bd7fc539d183a1eb90a80a38e93c55ebb27dfcf7e564f8bfc4", nonce: "310", blockHash: "0x6b8624308c0489caa2311ec6f3a46ec1b8eda8ccf099967e07a7839c5622802a", transactionIndex: "4", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "2461353233839066", gas: "7600027", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0xd8aed1450000000000000000000000000000000000000000000000efa9b32c89c1f400000000000000000000000000000000000000000000000000048f1f386b4a5a0000", contractAddress: "", cumulativeGasUsed: "728116", gasUsed: "620609", confirmations: "870422"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "2461353233839066" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "4421000000000000000000"}, {type: "uint256", name: "ethFree", value: "84100000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "4421000000000000000000", "84100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1544011466 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"4421000000000000000000\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6830435", timeStamp: "1544011565", hash: "0x282c5c8eed083579487b771ed90afc1c7bcd6acbf3137581e8090cabe5470224", nonce: "311", blockHash: "0xc6c79c60a63884991e9f84621cb2be888e4341b5c8a068e986c3d520de4ba17b", transactionIndex: "91", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "2461353233839066", gas: "803527", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xd8aed1450000000000000000000000000000000000000000000000efa9b32c89c1f400000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4574626", gasUsed: "459522", confirmations: "870415"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "2461353233839066" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "4421000000000000000000"}, {type: "uint256", name: "ethFree", value: "0"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "4421000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1544011565 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "daiWipe", type: "uint256"}, {indexed: false, name: "mkrCharged", type: "uint256"}, {indexed: false, name: "wipedBy", type: "address"}], name: "WipedDAI", type: "event"} ;
		console.error( "eventCallOriginal[37,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WipedDAI", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "daiWipe", type: "uint256", value: "4421000000000000000000"}, {name: "mkrCharged", type: "uint256", value: "587204079335852"}, {name: "wipedBy", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[37,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"20000000000000000000\", \"370000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6830453", timeStamp: "1544011776", hash: "0x2d147bc2ef3545b61bf09f9f775223de3dda98a1e4420fba444e51f2a78f409f", nonce: "119", blockHash: "0xb9de4139e09f2461f1d1dd457065b8cd4331d81a70bb6dca6f2c5744301c9f92", transactionIndex: "1", from: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "562656979385", gas: "7600027", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xd8aed145000000000000000000000000000000000000000000000001158e460913d000000000000000000000000000000000000000000000000000000522810a26e50000", contractAddress: "", cumulativeGasUsed: "536494", gasUsed: "507631", confirmations: "870397"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "562656979385" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "20000000000000000000"}, {type: "uint256", name: "ethFree", value: "370000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "20000000000000000000", "370000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1544011776 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "193927113676075496" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"0\", \"56000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6830463", timeStamp: "1544011916", hash: "0x26b6b66ff4c27706eaefdf4ace21370937d93ab29577406b59d5dd755e2d5b32", nonce: "312", blockHash: "0x3f5c4a6f49d34b937efb0c1bfbd56826ffb40aab72294013bd3dee31cdbfcc90", transactionIndex: "9", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "208176832846", gas: "7600027", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd8aed14500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000030927f74c9de00000", contractAddress: "", cumulativeGasUsed: "517067", gasUsed: "186870", confirmations: "870387"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "208176832846" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "0"}, {type: "uint256", name: "ethFree", value: "56000000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "0", "56000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1544011916 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "ethFree", type: "uint256"}], name: "UnlockedETH", type: "event"} ;
		console.error( "eventCallOriginal[39,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UnlockedETH", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "ethFree", type: "uint256", value: "56000000000000000000"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[39,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"21000000000000000000\", \"350000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6830464", timeStamp: "1544011930", hash: "0xcac5b4d62025b08e242b6c91993c3fb2309c28d2d68b4cfa19a3fdfceefc263c", nonce: "120", blockHash: "0x5e1c3ae50fcfe375adc6cbb549af3a42d145b81181de4bc3f834e7751797d05e", transactionIndex: "39", from: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "779047426396", gas: "1049383", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd8aed145000000000000000000000000000000000000000000000001236efcbcbb34000000000000000000000000000000000000000000000000000004db732547630000", contractAddress: "", cumulativeGasUsed: "6574803", gasUsed: "651511", confirmations: "870386"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "779047426396" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "21000000000000000000"}, {type: "uint256", name: "ethFree", value: "350000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "21000000000000000000", "350000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1544011930 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "daiWipe", type: "uint256"}, {indexed: false, name: "mkrCharged", type: "uint256"}, {indexed: false, name: "wipedBy", type: "address"}], name: "WipedDAI", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WipedDAI", events: [{name: "borrower", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}, {name: "daiWipe", type: "uint256", value: "21000000000000000000"}, {name: "mkrCharged", type: "uint256", value: "190146863871"}, {name: "wipedBy", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "ethFree", type: "uint256"}], name: "UnlockedETH", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UnlockedETH", events: [{name: "borrower", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}, {name: "ethFree", type: "uint256", value: "350000000000000000"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "193927113676075496" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"1000000000000000000\", \"4450000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6830539", timeStamp: "1544013045", hash: "0x27e5daf97ce8a42776aa53f88f3d9d736adeda0c44f8f611650ba1b4d466f05a", nonce: "121", blockHash: "0xa996c4fc4c257334b16d97164dd1105d3e74c96ed858fa6f629a37628d22cc16", transactionIndex: "110", from: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "46084557217", gas: "1048750", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd8aed1450000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000009e1883a4814000", contractAddress: "", cumulativeGasUsed: "5837863", gasUsed: "621845", confirmations: "870311"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "46084557217" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "1000000000000000000"}, {type: "uint256", name: "ethFree", value: "44500000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "1000000000000000000", "44500000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1544013045 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "daiWipe", type: "uint256"}, {indexed: false, name: "mkrCharged", type: "uint256"}, {indexed: false, name: "wipedBy", type: "address"}], name: "WipedDAI", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WipedDAI", events: [{name: "borrower", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}, {name: "daiWipe", type: "uint256", value: "1000000000000000000"}, {name: "mkrCharged", type: "uint256", value: "11185656193"}, {name: "wipedBy", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "ethFree", type: "uint256"}], name: "UnlockedETH", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UnlockedETH", events: [{name: "borrower", type: "address", value: "0xe4b205c76b78cf72012d6040c33429dba9bbd19b"}, {name: "ethFree", type: "uint256", value: "44500000000000000"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "193927113676075496" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"1500000000000000000000\", addressList[... )", async function( ) {
		const txOriginal = {blockNumber: "6830545", timeStamp: "1544013115", hash: "0x0f85b7fb6bccd5482d5d0c9666c6d9cdd803c97b5e4aff3c840d07b19f39cf23", nonce: "313", blockHash: "0x36e611437e0402c88f8c1d67d7633d92e5718b4162dd9f9f2511d96a7da8018d", transactionIndex: "36", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "293905", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd14800000000000000000000000000000000000000000000005150ae84a8cdf00000000000000000000000000000184cc5908e1a3d29b4d31df67d99622c4baa7b71", contractAddress: "", cumulativeGasUsed: "1864832", gasUsed: "182006", confirmations: "870305"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "1500000000000000000000"}, {type: "address", name: "beneficiary", value: addressList[10]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "1500000000000000000000", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1544013115 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[42,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "loanDAI", type: "uint256", value: "1500000000000000000000"}, {name: "payTo", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[42,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"1500000000000000000000\", \"2810000000... )", async function( ) {
		const txOriginal = {blockNumber: "6830554", timeStamp: "1544013217", hash: "0xfa41ca891bf5b06922976e28bcfce52bb6531f2027579f4e9df2f0cba90982ca", nonce: "314", blockHash: "0x599c309e35904cc95e8b0f9f1c97ff57742f75c80ffdc22c625806412003cfa8", transactionIndex: "6", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "120830704583", gas: "7600027", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0xd8aed14500000000000000000000000000000000000000000000005150ae84a8cdf0000000000000000000000000000000000000000000000000000185f7411eac7a0000", contractAddress: "", cumulativeGasUsed: "655931", gasUsed: "507327", confirmations: "870296"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "120830704583" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "1500000000000000000000"}, {type: "uint256", name: "ethFree", value: "28100000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "1500000000000000000000", "28100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1544013217 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"1500000000000000000000\", \"2810003860... )", async function( ) {
		const txOriginal = {blockNumber: "6830564", timeStamp: "1544013321", hash: "0x17d29a10b39a705037c8c082c90ba8627f35f2fc3f475b601a773c8a059e7733", nonce: "315", blockHash: "0x3bc200797436c9aba26fbb61b0d68792822ca4f932a0fc16a2c541aae8b7c973", transactionIndex: "3", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "1365387016843", gas: "7600027", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0xd8aed14500000000000000000000000000000000000000000000005150ae84a8cdf0000000000000000000000000000000000000000000000000000185f76439efc3d000", contractAddress: "", cumulativeGasUsed: "579114", gasUsed: "508072", confirmations: "870286"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "1365387016843" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "1500000000000000000000"}, {type: "uint256", name: "ethFree", value: "28100038600000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "1500000000000000000000", "28100038600000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1544013321 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"1500000000000000000000\", \"2800000000... )", async function( ) {
		const txOriginal = {blockNumber: "6830617", timeStamp: "1544014105", hash: "0xc3e9de75a24e4d36e070c6d169686aab4932e71ae339e531d046f0a62b5268c3", nonce: "316", blockHash: "0x0b678a65981d7feed8a62a9cca2fc950ec421ecb9ba796cc9d6a89beda7c9a38", transactionIndex: "8", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "8811578680297", gas: "7600000", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0xd8aed14500000000000000000000000000000000000000000000005150ae84a8cdf000000000000000000000000000000000000000000000000000018493fba64ef00000", contractAddress: "", cumulativeGasUsed: "778018", gasUsed: "523148", confirmations: "870233"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "8811578680297" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "1500000000000000000000"}, {type: "uint256", name: "ethFree", value: "28000000000000000000"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "1500000000000000000000", "28000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1544014105 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: repay( \"1500000000000000000000\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6830674", timeStamp: "1544014940", hash: "0x0632cf018f34c92e895e7d853500c4da10c4571f9b9b5c8d4e9e5f09981e3169", nonce: "318", blockHash: "0xf9d26236395c07bd35e8cc7c0325b3619b429237ee04d61fbb468ec2906a69a8", transactionIndex: "128", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "21099514618929", gas: "827391", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xd8aed14500000000000000000000000000000000000000000000005150ae84a8cdf000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7313746", gasUsed: "490731", confirmations: "870176"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "21099514618929" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiWipe", value: "1500000000000000000000"}, {type: "uint256", name: "ethFree", value: "0"}], name: "repay", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "repay(uint256,uint256)" ]( "1500000000000000000000", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1544014940 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "daiWipe", type: "uint256"}, {indexed: false, name: "mkrCharged", type: "uint256"}, {indexed: false, name: "wipedBy", type: "address"}], name: "WipedDAI", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WipedDAI", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "daiWipe", type: "uint256", value: "1500000000000000000000"}, {name: "mkrCharged", type: "uint256", value: "5232028621104"}, {name: "wipedBy", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: unlockETH( \"28000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6830696", timeStamp: "1544015248", hash: "0x7ecf7840103fcf6b4f018edcb98262c8bd3ae10932f44662e9899aed71a13ac9", nonce: "319", blockHash: "0xff0492b0b90acfb935e1737ad37868bd9bf542bd88f481e1b06f9235aab73dee", transactionIndex: "117", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "298963", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x8d445bd00000000000000000000000000000000000000000000000018493fba64ef00000", contractAddress: "", cumulativeGasUsed: "6088923", gasUsed: "185150", confirmations: "870154"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "ethFree", value: "28000000000000000000"}], name: "unlockETH", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "unlockETH(uint256)" ]( "28000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544015248 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "ethFree", type: "uint256"}], name: "UnlockedETH", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UnlockedETH", events: [{name: "borrower", type: "address", value: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71"}, {name: "ethFree", type: "uint256", value: "28000000000000000000"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: unlockETH( \"100038600000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6830700", timeStamp: "1544015282", hash: "0x4d359faab9e135ecbca4e0b41999a18fdc4e977d2d0f5f64cecb3886fcb8348c", nonce: "320", blockHash: "0xa5c392ffbe7744e29de5a3e5160b37937335eca169670a6f72eed8ef30e1541d", transactionIndex: "28", from: "0x184cc5908e1a3d29b4d31df67d99622c4baa7b71", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "0", gas: "301119", gasPrice: "18000000000", isError: "1", txreceipt_status: "0", input: "0x8d445bd000000000000000000000000000000000000000000000000001636893a0d3d000", contractAddress: "", cumulativeGasUsed: "1135166", gasUsed: "40579", confirmations: "870150"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "ethFree", value: "100038600000000000"}], name: "unlockETH", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "unlockETH(uint256)" ]( "100038600000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1544015282 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "12015149257179646896" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: borrow( \"600000000000000000000\", addressList[1... )", async function( ) {
		const txOriginal = {blockNumber: "6832341", timeStamp: "1544038594", hash: "0xa462181af1f9abead9bebd95da0bc03001f17d0df08d0771ee9266376be34767", nonce: "123", blockHash: "0xb776f427cdc01a4c97d43d3995f8e3fcc29140f534c1d853c10db3195327634b", transactionIndex: "10", from: "0xa53a13a80d72a855481de5211e7654fabdfe3526", to: "0x3a306a399085f3460bbcb5b77015ab33806a10d5", value: "14000000000000000000", gas: "626368", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x4b3fd14800000000000000000000000000000000000000000000002086ac351052600000000000000000000000000000a53a13a80d72a855481de5211e7654fabdfe3526", contractAddress: "", cumulativeGasUsed: "4431802", gasUsed: "387957", confirmations: "868509"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "14000000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "daiDraw", value: "600000000000000000000"}, {type: "address", name: "beneficiary", value: addressList[13]}], name: "borrow", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "borrow(uint256,address)" ]( "600000000000000000000", addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544038594 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "lockETH", type: "uint256"}, {indexed: false, name: "lockPETH", type: "uint256"}, {indexed: false, name: "lockedBy", type: "address"}], name: "LockedETH", type: "event"} ;
		console.error( "eventCallOriginal[49,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedETH", events: [{name: "borrower", type: "address", value: "0xa53a13a80d72a855481de5211e7654fabdfe3526"}, {name: "lockETH", type: "uint256", value: "14000000000000000000"}, {name: "lockPETH", type: "uint256", value: "13484754239375678884"}, {name: "lockedBy", type: "address", value: "0xa53a13a80d72a855481de5211e7654fabdfe3526"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[49,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanDAI", type: "uint256"}, {indexed: false, name: "payTo", type: "address"}], name: "LoanedDAI", type: "event"} ;
		console.error( "eventCallOriginal[49,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LoanedDAI", events: [{name: "borrower", type: "address", value: "0xa53a13a80d72a855481de5211e7654fabdfe3526"}, {name: "loanDAI", type: "uint256", value: "600000000000000000000"}, {name: "payTo", type: "address", value: "0xa53a13a80d72a855481de5211e7654fabdfe3526"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[49,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "cdpBytes", type: "bytes32"}], name: "NewCDP", type: "event"} ;
		console.error( "eventCallOriginal[49,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewCDP", events: [{name: "borrower", type: "address", value: "0xa53a13a80d72a855481de5211e7654fabdfe3526"}, {name: "cdpBytes", type: "bytes32", value: "0x00000000000000000000000000000000000000000000000000000000000012d9"}], address: "0x3a306a399085f3460bbcb5b77015ab33806a10d5"}] ;
		console.error( "eventResultOriginal[49,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "61940707013804036101" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "600000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
