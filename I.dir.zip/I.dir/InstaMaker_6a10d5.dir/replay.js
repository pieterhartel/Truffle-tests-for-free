var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "InstaMaker"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0x3A306a399085F3460BbcB5b77015Ab33806A10d5","0xb579D4f1546d51980499aa96a2E411Be3E449197","0xE16D035B8E76303237b9660b3c9C94c1a86AAB47","0x7284a8451d9a0e7Dc62B3a71C0593eA2eC5c5638","0xd8db02A498E9AFbf4A32BC006DC1940495b4e592","0xa7615CD307F323172331865181DC8b80a2834324","0xbbD13CA6aACE2a8ECcBDe88bc7849C3c6E4e172E","0x53CccA398F6CD117e6aa34AB71598b8F172Bf0FF","0x184cC5908E1a3D29B4D31df67d99622C4Baa7b71","0xFfF7830F9DDB9D48d9e213354c92604Ef7e1298b","0xE4b205c76B78Cf72012D6040C33429Dba9bBd19B","0xa53A13A80D72A855481DE5211E7654fAbDFE3526"]
addressListOriginal.length = 14
methodPrototypeListOriginal = [{"constant":true,"inputs":[{"name":"ethNum","type":"uint256"}],"name":"pethPEReth","outputs":[{"name":"rPETH","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"getETHRate","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"borrower","type":"address"}],"name":"getCDP","outputs":[{"name":"","type":"uint256"},{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"freezed","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"addressRegistry","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"}]
eventPrototypeListOriginal = [{"anonymous":false,"inputs":[{"indexed":false,"name":"amount","type":"uint256"}],"name":"MKRCollected","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"cdp","type":"bytes32"},{"indexed":false,"name":"owner","type":"address"},{"indexed":false,"name":"nextOwner","type":"address"}],"name":"TranferCDP","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"cdp","type":"bytes32"},{"indexed":false,"name":"owner","type":"address"}],"name":"CDPClaimed","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"borrower","type":"address"},{"indexed":false,"name":"daiWipe","type":"uint256"},{"indexed":false,"name":"mkrCharged","type":"uint256"},{"indexed":false,"name":"wipedBy","type":"address"}],"name":"WipedDAI","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"borrower","type":"address"},{"indexed":false,"name":"ethFree","type":"uint256"}],"name":"UnlockedETH","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"borrower","type":"address"},{"indexed":false,"name":"lockETH","type":"uint256"},{"indexed":false,"name":"lockPETH","type":"uint256"},{"indexed":false,"name":"lockedBy","type":"address"}],"name":"LockedETH","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"borrower","type":"address"},{"indexed":false,"name":"loanDAI","type":"uint256"},{"indexed":false,"name":"payTo","type":"address"}],"name":"LoanedDAI","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"borrower","type":"address"},{"indexed":false,"name":"cdpBytes","type":"bytes32"}],"name":"NewCDP","type":"event"}]
eventSignatureListOriginal = ["MKRCollected(uint256)","TranferCDP(bytes32,address,address)","CDPClaimed(bytes32,address)","WipedDAI(address,uint256,uint256,address)","UnlockedETH(address,uint256)","LockedETH(address,uint256,uint256,address)","LoanedDAI(address,uint256,address)","NewCDP(address,bytes32)"]
topicListOriginal = ["0x499d4b63f3a203c58019a864fc2d9cfe72954952ed53a3e40999755432cd3566","0x54e847b75f10cd7e742b78312fe0079d5a973d8a9b9070bb0515a8390160bd51","0x31f5dffe72808492cb2559d1f67508a7bb36622423aaac12f04b773d58bb3ffd","0xcc6878355865ed21824b44591ff4007019184a8a745b0740f85423266f9a837e","0x535dbd84e6041f33aaf78db176dd666c6b5d00094b3681ac68ea55ec9d0375b4","0xae07a3d5c5e33182092cb26d77cc02764342b0772a21260cff9dfdf47e1dad19","0x4e393322c078a1291e528e1e8719f9bc6d6845942cb87e9b2c6c1969f71db371","0xaacf4dabf7a1318b83a988c9264a97b311ea7cef315258fd7cdab83ef8b8dedb"]
nBlocksOriginal = 50
fromBlockOriginal = 6806227
toBlockOriginal = 6832341
constructorPrototypeOriginal = {"inputs":[{"type":"address","name":"rAddr","value":4}],"name":"InstaMaker","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"6806227","timeStamp":"1543664449","hash":"0x70888cff33e93817bfce22ed4bc8b659da8d5960bb445b95f1788e1d9ec43667","nonce":"137","blockHash":"0x543b8d67435c4bd59313d5eeda9074361ecff6238b938f88961200f0ec7c2de4","transactionIndex":"57","from":"0xb579d4f1546d51980499aa96a2e411be3e449197","to":0,"value":"0","gas":"3461023","gasPrice":"7000000000","isError":"0","txreceipt_status":"1","input":"0x4147d514000000000000000000000000e16d035b8e76303237b9660b3c9c94c1a86aab47","contractAddress":"0x3a306a399085f3460bbcb5b77015ab33806a10d5","cumulativeGasUsed":"7147443","gasUsed":"3461023","confirmations":"894623"}
txOptions[0] = {"from":"0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1","to":0,"value":"0"}
txCall[0] = {"inputs":[{"type":"address","name":"rAddr","value":"0xFFcf8FDEE72ac11b5c542428B35EEF5769C409f0"}],"name":"InstaMaker","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
