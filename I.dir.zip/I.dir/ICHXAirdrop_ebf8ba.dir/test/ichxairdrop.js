const ICHXAirdrop = artifacts.require( "./ICHXAirdrop.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "ICHXAirdrop" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x4C2524807188073516056EADd24753FB3CeBF8bA", "0xC33FfAc8030C7C50D8994015C88D502a3240Dec7", "0xa573661b5FB2063d7AB12336ee24589F7A79fdab", "0x521aFF68aC6F05f36ae75Fc786eeC3B310BaF68B", "0xEe96EeDA7Ac9F51112b4fC53183871e9A65f94B7", "0x59f4DFBdFcB18B0347216a9e2BF9aA1fFcF0F643", "0xBf20D118dcEA9D2EEa4da1aA3121467e872Cd47e", "0x28791A193f4f07F41A4bA1472362a899768564b9", "0x16521215f08B8474028404177cff7b4377EdE03D", "0xD31f5A98cF4aE7DD8a013C9d89c27dE988f538b4", "0xBA3e6353b59088c5b8B38d8d3E534542B1fe4B9c", "0x9F8CF62b6D15490Df247eCfC51E4C8ed123B4db3", "0x73e775335bdDaac0B95211441Fefb7fCCe13dB08", "0xa673dF47739aE812fdd5098eDcbFb87dc7C40e33", "0x14EEB50B778564e145A2A941daB26D57Eb6e7F41", "0xa1C389ca1A45beB5a8D3667077c764BCfb1388FB", "0xa106F69838177fdde9AfD5F485894E065BaCEa0d", "0xB63CaB90E842f44498749Ef19bA5D3700e018FB4", "0x93fc01A843E52ee6bf109D621D0788F698D74E14", "0x449464912Fc8fF42B70B69C89BF4d7897C7112C1", "0xA36Ce14EF9E04d76800Ce2844B1DCA31F4235139", "0x2ac9859CC5b97dD0Cd824c04d44AEA64F0672f2d", "0xbffaa84D876cDbf5AC7F11404515D478a2cc3D80", "0xAea88d83c8Bccf611A27829176cBbF39a1CbD655", "0xAf1984a631724016688092c261Ce2488fB8FB9D4", "0x45Bbc5418C502712Ed57Df916784C4824BFDDef3", "0xEA34E12C536443b5a8d5468104bAbc4c2deC7aBD", "0xC807FEfD6A0A3Bed8e3e60D74A9CA5Eb8aE9e941", "0x9F25319D5f6DeEA4EDF5e0C4d1D5AbaaA9706b5b", "0x0738f2F11277899489D2fAfFEDbe622934325a11", "0x72470C12Dc8e64648a0760a592CE2274940BeA8C", "0xdC3a22647840A993EebCE407876284677319eaC8", "0xB048d4C62e92bcAB4d448ed48EACccf00f20609e", "0xeaD091FE59fd7c26295BD31163f4260a55819878", "0xE77C531dA0e289e1cdE9E9BbF3A1e54EE5401F57", "0x8E5f75462B86EE56B1f7713185a54EA3cDb2781c", "0x352b9b453435f16070C8Ef71E84B60d81FEbb3Aa", "0xEd1C8013bfe930B21180a6eAd0854d60A9883D87", "0xC3bd2241b28979506c84Cf90d6cDaDf3535FBec7"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "tokenHolder", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "users", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "locked", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "pendingOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "user", type: "address"}], name: "getAirdropStatus", outputs: [{name: "success", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"}, {anonymous: false, inputs: [], name: "Lock", type: "event"}, {anonymous: false, inputs: [], name: "Unlock", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["AirdropToken(address,uint256)", "Lock()", "Unlock()", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xb6b09d42fae5c5eedc2e2b4c72342ea7f76d69f00732b2183cf65d40b5afaeb3", "0x46620e39f4e119bf05f13544f8ef38338fc06c17f6b731c7f95bee356572db96", "0x70e3fffea7bbb557facdee48ed7f7af5179030adef9ad0c876df039a718f359e", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6966404 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6968574 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_token", value: 4}, {type: "address", name: "_tokenHolder", value: 5}], name: "ICHXAirdrop", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "tokenHolder", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenHolder()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "users", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "users(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "locked", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "locked()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "pendingOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pendingOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "user", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getAirdropStatus", outputs: [{name: "success", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAirdropStatus(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "ICHXAirdrop", function( accounts ) {

	it( "TEST: ICHXAirdrop( addressList[4], addressList[5] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6966404", timeStamp: "1545977098", hash: "0x05de460ab032a7f4d6ce93f0fa1e9b3c806fb7c971643565a38912f9778671b4", nonce: "43938", blockHash: "0xe46cc1ba8ecf2f74ca85aa77356fea28bc5596b5c73ffcd62253af8bc5741b12", transactionIndex: "46", from: "0xc33ffac8030c7c50d8994015c88d502a3240dec7", to: 0, value: "0", gas: "1031502", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd5409be3000000000000000000000000a573661b5fb2063d7ab12336ee24589f7a79fdab000000000000000000000000521aff68ac6f05f36ae75fc786eec3b310baf68b", contractAddress: "0x4c2524807188073516056eadd24753fb3cebf8ba", cumulativeGasUsed: "3418486", gasUsed: "1031502", confirmations: "707839"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}, {type: "address", name: "_tokenHolder", value: addressList[5]}], name: "ICHXAirdrop", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = ICHXAirdrop.new( addressList[4], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1545977098 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = ICHXAirdrop.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "111782225249378456" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: unlock(  )", async function( ) {
		const txOriginal = {blockNumber: "6966442", timeStamp: "1545977716", hash: "0x0e27d6974b111bb8ffaa2084b54ad1a91a39f4d40d43f6dc968e61716e2e8a17", nonce: "43939", blockHash: "0x5a44405a12f2d04b35ab3f0658ff0f1e4a300b742e22e40badb16b165bb401f8", transactionIndex: "126", from: "0xc33ffac8030c7c50d8994015c88d502a3240dec7", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "42052", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xa69df4b5", contractAddress: "", cumulativeGasUsed: "6809387", gasUsed: "14018", confirmations: "707801"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "unlock", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "unlock()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1545977716 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [], name: "Unlock", type: "event"} ;
		console.error( "eventCallOriginal[1,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Unlock", events: [], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[1,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "111782225249378456" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0x7664d1f25a70c9a1d85dbb7e4a96... )", async function( ) {
		const txOriginal = {blockNumber: "6966465", timeStamp: "1545977931", hash: "0xaf6959475a16befc2aac2b044b8d654b9dd7f699129d64663dacc3f2dbc74659", nonce: "43940", blockHash: "0x9325b987974007aa39407fd96e3e104ad92dc43ce306555fdfbc8846da2ba8d2", transactionIndex: "107", from: "0xc33ffac8030c7c50d8994015c88d502a3240dec7", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "138543", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001b7664d1f25a70c9a1d85dbb7e4a967f6feed0880c39bc87292bd759af7568043a3c62ce6f582f96097fa56933bcffc68caddd2b6bca4bba8e08c40e391fb2025300000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "7338394", gasUsed: "92362", confirmations: "707778"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x7664d1f25a70c9a1d85dbb7e4a967f6feed0880c39bc87292bd759af7568043a"}, {type: "bytes32", name: "s", value: "0x3c62ce6f582f96097fa56933bcffc68caddd2b6bca4bba8e08c40e391fb20253"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0x7664d1f25a70c9a1d85dbb7e4a967f6feed0880c39bc87292bd759af7568043a", "0x3c62ce6f582f96097fa56933bcffc68caddd2b6bca4bba8e08c40e391fb20253", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1545977931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xc33ffac8030c7c50d8994015c88d502a3240dec7"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "111782225249378456" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0xc7bcc713ae968d6b2833ad18d7b4... )", async function( ) {
		const txOriginal = {blockNumber: "6966655", timeStamp: "1545980778", hash: "0xed892123861e324be2801230bdf37a153075d2c6519ad44be2f3917a09be035a", nonce: "46", blockHash: "0xd37d124818a68cfa48d860ee69651df505d6a668cf5b93c84a13f829c50c4f3c", transactionIndex: "122", from: "0xee96eeda7ac9f51112b4fc53183871e9a65f94b7", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "138543", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001cc7bcc713ae968d6b2833ad18d7b44e8efed64f0ee859247c4e0ef419df2f2d9936f4307e0c5809325ad77048814d58782c0a67789afb7e2050b8912c93e4560a00000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "5447497", gasUsed: "92362", confirmations: "707588"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xc7bcc713ae968d6b2833ad18d7b44e8efed64f0ee859247c4e0ef419df2f2d99"}, {type: "bytes32", name: "s", value: "0x36f4307e0c5809325ad77048814d58782c0a67789afb7e2050b8912c93e4560a"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0xc7bcc713ae968d6b2833ad18d7b44e8efed64f0ee859247c4e0ef419df2f2d99", "0x36f4307e0c5809325ad77048814d58782c0a67789afb7e2050b8912c93e4560a", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1545980778 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xee96eeda7ac9f51112b4fc53183871e9a65f94b7"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "9851964529884003" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0x0591e6263c76d513e19c452f634c... )", async function( ) {
		const txOriginal = {blockNumber: "6966671", timeStamp: "1545981139", hash: "0x3abf175ccea167691cb336d5dc6acef5956e16bad3a306002d3c02d1f3390619", nonce: "36", blockHash: "0xa445f1fa5422a1cc9304c1fd20677c29ec764c969546998c06098305db2b8745", transactionIndex: "95", from: "0x59f4dfbdfcb18b0347216a9e2bf9aa1ffcf0f643", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001b0591e6263c76d513e19c452f634c75a3124dfc695c876c80d54926f50e0b369f051e48b6bace011339038395861ed258b0024ce8cfd66e056a0317282d9bc25600000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "3774508", gasUsed: "92362", confirmations: "707572"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x0591e6263c76d513e19c452f634c75a3124dfc695c876c80d54926f50e0b369f"}, {type: "bytes32", name: "s", value: "0x051e48b6bace011339038395861ed258b0024ce8cfd66e056a0317282d9bc256"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0x0591e6263c76d513e19c452f634c75a3124dfc695c876c80d54926f50e0b369f", "0x051e48b6bace011339038395861ed258b0024ce8cfd66e056a0317282d9bc256", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1545981139 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0x59f4dfbdfcb18b0347216a9e2bf9aa1ffcf0f643"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "10038826443172345" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0xb96b79563ea1698c8e29661b82c4... )", async function( ) {
		const txOriginal = {blockNumber: "6966737", timeStamp: "1545982220", hash: "0x4c1d790fbed280aa4418261485f89922c558bdcad6fb273a6c2565a4078b9f22", nonce: "237", blockHash: "0x1f96149c09f3263a9de46b7f5f3a69cc2c4599b8f378fdfe5fd205774d16f62d", transactionIndex: "125", from: "0xbf20d118dcea9d2eea4da1aa3121467e872cd47e", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "92362", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001bb96b79563ea1698c8e29661b82c413729ea9d0c31945c2a7155a0ae3e7afb0da2abf458e9c3a7174d7567b553be5d4afe6d8ee3b2a2ba79929fff19443e9d93800000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "5084795", gasUsed: "92362", confirmations: "707506"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xb96b79563ea1698c8e29661b82c413729ea9d0c31945c2a7155a0ae3e7afb0da"}, {type: "bytes32", name: "s", value: "0x2abf458e9c3a7174d7567b553be5d4afe6d8ee3b2a2ba79929fff19443e9d938"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0xb96b79563ea1698c8e29661b82c413729ea9d0c31945c2a7155a0ae3e7afb0da", "0x2abf458e9c3a7174d7567b553be5d4afe6d8ee3b2a2ba79929fff19443e9d938", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1545982220 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xbf20d118dcea9d2eea4da1aa3121467e872cd47e"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "8127256108109556" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6966758", timeStamp: "1545982504", hash: "0x55ab0bcafc72c85cb08d08c15806da4cb70c6931055dbbff9945dd7f05c816e7", nonce: "385", blockHash: "0x6ef7b7d00d722f1a109bc6915a39c5ee8498819ddf2cd4a1983d1ae976b3cf92", transactionIndex: "87", from: "0x28791a193f4f07f41a4ba1472362a899768564b9", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "100000", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "3968577", gasUsed: "21046", confirmations: "707485"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1545982504 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "5243390349999998" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0xa9734f841e7bb731dd3dcb728e67... )", async function( ) {
		const txOriginal = {blockNumber: "6966768", timeStamp: "1545982629", hash: "0xa98798b55fe98c5e13a94d80c699ab0612c75dd4a7abfe3a7323542c52f8cd4f", nonce: "386", blockHash: "0x3daf5cab893b82468444800730b0df3ef82a5227feefa38c15202005c5a56836", transactionIndex: "33", from: "0x28791a193f4f07f41a4ba1472362a899768564b9", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "100000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001ca9734f841e7bb731dd3dcb728e671e09224b1bd34588492c239c36579ac189de497c662d0b4a24987312b9b6c1162f9a4c670f1efe8b4b613d7d93244ea228f700000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "4379449", gasUsed: "92362", confirmations: "707475"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xa9734f841e7bb731dd3dcb728e671e09224b1bd34588492c239c36579ac189de"}, {type: "bytes32", name: "s", value: "0x497c662d0b4a24987312b9b6c1162f9a4c670f1efe8b4b613d7d93244ea228f7"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0xa9734f841e7bb731dd3dcb728e671e09224b1bd34588492c239c36579ac189de", "0x497c662d0b4a24987312b9b6c1162f9a4c670f1efe8b4b613d7d93244ea228f7", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1545982629 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0x28791a193f4f07f41a4ba1472362a899768564b9"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "5243390349999998" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6966804", timeStamp: "1545983201", hash: "0xac61eb26cbc6c4892f9a3092630b6ec0104a580ad50a618b08eb8968e243e855", nonce: "6", blockHash: "0x1723d9359a913ef11b86efd9937395cfd5d1dffadb5cd4889e9d390247121191", transactionIndex: "80", from: "0x16521215f08b8474028404177cff7b4377ede03d", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3600000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "4858503", gasUsed: "21046", confirmations: "707439"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1545983201 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "579074418816000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6966807", timeStamp: "1545983224", hash: "0xa38c97d5b9ca3811f5b3ca17b67719f52d6ff8e0229b845afee8b6f844db261c", nonce: "2", blockHash: "0x5bab905eba3433100dda5b7b5b918efae44b8e2a91fd507f438e84901e488cd0", transactionIndex: "47", from: "0xd31f5a98cf4ae7dd8a013c9d89c27de988f538b4", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "10349999104", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "2095736", gasUsed: "21046", confirmations: "707436"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1545983224 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0x1d85f3f61436abb6288a1dadf75c... )", async function( ) {
		const txOriginal = {blockNumber: "6966815", timeStamp: "1545983282", hash: "0xf8f07d74961c5fa6d030f23bb679c4c76026908ace5445f7504ab6665c68b4a1", nonce: "60", blockHash: "0x030819d647932f44c3dd6cef6e963e25effdb78357745a9ad8ff7618dbafa7e8", transactionIndex: "137", from: "0xba3e6353b59088c5b8b38d8d3e534542b1fe4b9c", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "100000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001b1d85f3f61436abb6288a1dadf75cf617b59e123ee41e765a4e090fb8eba9c1c1205fe7933e4b6261fa62afd627c44221655e739eb076d446eda19ae69ce619bf00000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "7168773", gasUsed: "92362", confirmations: "707428"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x1d85f3f61436abb6288a1dadf75cf617b59e123ee41e765a4e090fb8eba9c1c1"}, {type: "bytes32", name: "s", value: "0x205fe7933e4b6261fa62afd627c44221655e739eb076d446eda19ae69ce619bf"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0x1d85f3f61436abb6288a1dadf75cf617b59e123ee41e765a4e090fb8eba9c1c1", "0x205fe7933e4b6261fa62afd627c44221655e739eb076d446eda19ae69ce619bf", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1545983282 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xba3e6353b59088c5b8b38d8d3e534542b1fe4b9c"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "79149256250000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0xca21b5e2bba4995e5cc4c6084b3c... )", async function( ) {
		const txOriginal = {blockNumber: "6966910", timeStamp: "1545984659", hash: "0x66bbe79956b6b22d073a8c5dabe4e8948eadbe024017aac18b13d39df3c0ddf9", nonce: "78", blockHash: "0x6337297e34306c72d7bc2f78a83be9bc629f402288c2ac864e4df69df3cbdf65", transactionIndex: "115", from: "0x9f8cf62b6d15490df247ecfc51e4c8ed123b4db3", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "200000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001cca21b5e2bba4995e5cc4c6084b3c824b388d3a03d9fc430c584d160fddb6d5dc049556fa403ee7579f8cc74ccccbb72b4eae18d69f4a310188982437ce23c7a100000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "4865118", gasUsed: "92362", confirmations: "707333"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xca21b5e2bba4995e5cc4c6084b3c824b388d3a03d9fc430c584d160fddb6d5dc"}, {type: "bytes32", name: "s", value: "0x049556fa403ee7579f8cc74ccccbb72b4eae18d69f4a310188982437ce23c7a1"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0xca21b5e2bba4995e5cc4c6084b3c824b388d3a03d9fc430c584d160fddb6d5dc", "0x049556fa403ee7579f8cc74ccccbb72b4eae18d69f4a310188982437ce23c7a1", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1545984659 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0x9f8cf62b6d15490df247ecfc51e4c8ed123b4db3"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "27841330271009260" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0x7a6c2966d78344e13c20c2ced3c2... )", async function( ) {
		const txOriginal = {blockNumber: "6967031", timeStamp: "1545986272", hash: "0xc35deb9632893cbe6a9102d0509f0daaf5f279122fe7c4ad4fc5a9b9f0741aa0", nonce: "1588", blockHash: "0xd96cae23130a450a93ee59c221d1dae945eacce749efd7fd58e7bcc42da1f83d", transactionIndex: "157", from: "0x73e775335bddaac0b95211441fefb7fcce13db08", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "200000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001b7a6c2966d78344e13c20c2ced3c25b52904de84e9aa299de71cd7ddf8990bf2f616c2e2fe40902bc635ecdcf1a9b204fc30665ddce86d391377e554453f094f400000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "3745268", gasUsed: "92362", confirmations: "707212"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x7a6c2966d78344e13c20c2ced3c25b52904de84e9aa299de71cd7ddf8990bf2f"}, {type: "bytes32", name: "s", value: "0x616c2e2fe40902bc635ecdcf1a9b204fc30665ddce86d391377e554453f094f4"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0x7a6c2966d78344e13c20c2ced3c25b52904de84e9aa299de71cd7ddf8990bf2f", "0x616c2e2fe40902bc635ecdcf1a9b204fc30665ddce86d391377e554453f094f4", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1545986272 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0x73e775335bddaac0b95211441fefb7fcce13db08"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "2328634296116154" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0x0eecdddae204d242dec2a680c9a5... )", async function( ) {
		const txOriginal = {blockNumber: "6967097", timeStamp: "1545987238", hash: "0x25329d14002af2457ca61c42649e8ec895eb1c9ac1791b7f29c6c9e86d0ed203", nonce: "3", blockHash: "0x06de021e5aab5dc479889e29ce45eb98e859cb5201b2f562bf1eac8434cfd883", transactionIndex: "31", from: "0xd31f5a98cf4ae7dd8a013c9d89c27de988f538b4", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001c0eecdddae204d242dec2a680c9a551c9b9e18cfbf7061e27213917308ece0744217aad1f8b01ca0520c09b0fd84c80c7d179807804fc5afd2a7352c1f8d67fce00000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "2565032", gasUsed: "92362", confirmations: "707146"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x0eecdddae204d242dec2a680c9a551c9b9e18cfbf7061e27213917308ece0744"}, {type: "bytes32", name: "s", value: "0x217aad1f8b01ca0520c09b0fd84c80c7d179807804fc5afd2a7352c1f8d67fce"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0x0eecdddae204d242dec2a680c9a551c9b9e18cfbf7061e27213917308ece0744", "0x217aad1f8b01ca0520c09b0fd84c80c7d179807804fc5afd2a7352c1f8d67fce", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1545987238 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xd31f5a98cf4ae7dd8a013c9d89c27de988f538b4"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6967252", timeStamp: "1545989640", hash: "0x8e9021fd98d61440dc9d118f99eef817d31358e890c7779ff46a75bb7f799239", nonce: "282", blockHash: "0x24ccc0198fd1a1d85fa3f85274e2767cf5867abdce904add5d47037f3053120a", transactionIndex: "87", from: "0xa673df47739ae812fdd5098edcbfb87dc7c40e33", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "21000", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "6088550", gasUsed: "21000", confirmations: "706991"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "48171760180495725" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0xaf82cd957c1c2368df52e9342b98... )", async function( ) {
		const txOriginal = {blockNumber: "6967284", timeStamp: "1545990055", hash: "0xf5c36d0484e81645d8a83e4474deb0e3254e3d0e6b800c0cdc8f38d35e23d2da", nonce: "283", blockHash: "0x24ce9e4889c570f5b66e1e25959e0595256e760e18a17c05b84ef7832b1e88f5", transactionIndex: "196", from: "0xa673df47739ae812fdd5098edcbfb87dc7c40e33", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "200000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001baf82cd957c1c2368df52e9342b98f4a9f29226d8f56cdeabf863468a6c0ef2d82c74e04c9f32fbd763dce2882c2feba80d80a6c5c78c0bedc4e848b99061430000000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "6470576", gasUsed: "92298", confirmations: "706959"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xaf82cd957c1c2368df52e9342b98f4a9f29226d8f56cdeabf863468a6c0ef2d8"}, {type: "bytes32", name: "s", value: "0x2c74e04c9f32fbd763dce2882c2feba80d80a6c5c78c0bedc4e848b990614300"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0xaf82cd957c1c2368df52e9342b98f4a9f29226d8f56cdeabf863468a6c0ef2d8", "0x2c74e04c9f32fbd763dce2882c2feba80d80a6c5c78c0bedc4e848b990614300", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1545990055 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xa673df47739ae812fdd5098edcbfb87dc7c40e33"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "48171760180495725" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0x1a5373486a1ea3ecb97882ecc7b8... )", async function( ) {
		const txOriginal = {blockNumber: "6967452", timeStamp: "1545992270", hash: "0x6490d7f76d1f5a7f5961b893f9b2ba82592982ba280bcb59c789f4fb3f2b9de6", nonce: "34", blockHash: "0x79d4633d77d6254f562119c084141fd37dc4fcaf7be7df131a7ca725e21e2b85", transactionIndex: "110", from: "0x14eeb50b778564e145a2a941dab26d57eb6e7f41", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001b1a5373486a1ea3ecb97882ecc7b86d0d1203e34b49691d10453fb7fc58ababcb28fa6848b55f0fa2b77536bb525aa772fe1b6434bdddf42394d6eacdefb4339a00000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "5492440", gasUsed: "92362", confirmations: "706791"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x1a5373486a1ea3ecb97882ecc7b86d0d1203e34b49691d10453fb7fc58ababcb"}, {type: "bytes32", name: "s", value: "0x28fa6848b55f0fa2b77536bb525aa772fe1b6434bdddf42394d6eacdefb4339a"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0x1a5373486a1ea3ecb97882ecc7b86d0d1203e34b49691d10453fb7fc58ababcb", "0x28fa6848b55f0fa2b77536bb525aa772fe1b6434bdddf42394d6eacdefb4339a", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1545992270 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0x14eeb50b778564e145a2a941dab26d57eb6e7f41"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "519284048989043" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6967694", timeStamp: "1545996078", hash: "0x5328b8b98899a5526bd0fd6ce56184e9a3562de53a74c5098fbae4322a10e18b", nonce: "7", blockHash: "0xe31e14a6f9c6dcf5014d36841e2102068a4f63f901422178b3024ebb63ea8947", transactionIndex: "75", from: "0x16521215f08b8474028404177cff7b4377ede03d", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "4800000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "2914499", gasUsed: "21046", confirmations: "706549"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1545996078 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "579074418816000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0xb674281419d326b85f1ee1ed6cd1... )", async function( ) {
		const txOriginal = {blockNumber: "6967752", timeStamp: "1545996807", hash: "0xe9b466f190a5e934a90963efa42b99294544f48920fc3ce6321cc2b00942cd72", nonce: "4", blockHash: "0x563e1514c881a75e3819f139df74e619c08c6a42edb3176bac472f70ed3ac167", transactionIndex: "57", from: "0xa1c389ca1a45beb5a8d3667077c764bcfb1388fb", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001cb674281419d326b85f1ee1ed6cd162b5b884c4aba118818b862777dd38f6e3bc564ade1c1d17bc1e8d5eadff154b3cc7c17539ca1d6c3174cefac91168d1b3a800000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "2642401", gasUsed: "92362", confirmations: "706491"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xb674281419d326b85f1ee1ed6cd162b5b884c4aba118818b862777dd38f6e3bc"}, {type: "bytes32", name: "s", value: "0x564ade1c1d17bc1e8d5eadff154b3cc7c17539ca1d6c3174cefac91168d1b3a8"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0xb674281419d326b85f1ee1ed6cd162b5b884c4aba118818b862777dd38f6e3bc", "0x564ade1c1d17bc1e8d5eadff154b3cc7c17539ca1d6c3174cefac91168d1b3a8", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1545996807 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xa1c389ca1a45beb5a8d3667077c764bcfb1388fb"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3908107690341888" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6967787", timeStamp: "1545997383", hash: "0xf01360e137998be4a1dc5c8e02ec1f845323e1a7b28a711d69b20a93c516d5bd", nonce: "9", blockHash: "0x2fe3f69c7d78abe5c1d8fbc6ac0a75e2294ec9317af291a47e9af1d030e65624", transactionIndex: "76", from: "0xa106f69838177fdde9afd5f485894e065bacea0d", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "2880000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "5915038", gasUsed: "21046", confirmations: "706456"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1545997383 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "6644511480000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6967790", timeStamp: "1545997462", hash: "0x6900dc938e6a3a17cb3e1c4fadfe63d95337af0b0ffdb9e660e3e67967b748a7", nonce: "6", blockHash: "0x8afca2cd72a0001c44e573f7474bc7c929b4284ce1e530a1f85564ecea4aed28", transactionIndex: "124", from: "0xb63cab90e842f44498749ef19ba5d3700e018fb4", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "50000", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "5589123", gasUsed: "21046", confirmations: "706453"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1545997462 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "47938817000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6967808", timeStamp: "1545997821", hash: "0x62c8c0296578aebcc20a283d01852e8665edbb8982edbfb17b0105184a597384", nonce: "10", blockHash: "0x21b0809bb4a6e1ef1dff3bcbdad88ae230f6d9bf5175d194bdcaa7e1d98135d1", transactionIndex: "89", from: "0xa106f69838177fdde9afd5f485894e065bacea0d", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3120000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "4556675", gasUsed: "21046", confirmations: "706435"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1545997821 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "6644511480000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6967808", timeStamp: "1545997821", hash: "0xafa29ca2fbb9f638bc348474e77884608357aeac489a75e4aed1a4305ea2c85e", nonce: "7", blockHash: "0x21b0809bb4a6e1ef1dff3bcbdad88ae230f6d9bf5175d194bdcaa7e1d98135d1", transactionIndex: "118", from: "0xb63cab90e842f44498749ef19ba5d3700e018fb4", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "90000", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "7083892", gasUsed: "21046", confirmations: "706435"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1545997821 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "47938817000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6967810", timeStamp: "1545997866", hash: "0xfefa5b521a2c32b519f9cf42d72ca48206e4d7aea98d470d7d6c0d7c7c7d67ce", nonce: "11", blockHash: "0x95cd264fe5b9c6ae4cd362d72ed9a0b7ea99bb5b76385e6d7a70aaf08fd121ec", transactionIndex: "48", from: "0xa106f69838177fdde9afd5f485894e065bacea0d", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3120000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "7011579", gasUsed: "21046", confirmations: "706433"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1545997866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "6644511480000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6967924", timeStamp: "1545999431", hash: "0x36aa9c95701978cb7abc8bb814b41a58a32abe3573e648332ce625d23f308729", nonce: "22", blockHash: "0x8c34632638f13d5c642dfbe0e3f532b2c7e06865af8805fd36f37b2b1a3fc5c7", transactionIndex: "105", from: "0x93fc01a843e52ee6bf109d621d0788f698d74e14", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "2400000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "7320781", gasUsed: "21046", confirmations: "706319"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1545999431 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "5604416680000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0x5e792bfde48fe082302b1178acb9... )", async function( ) {
		const txOriginal = {blockNumber: "6968025", timeStamp: "1546000941", hash: "0x18bbed17815b805b1086a283c028e77d0e5c9f285d26c11c44c071d250977899", nonce: "6", blockHash: "0x8652ae6bec18ec58de0cd93fcabf1ccee3117783a323a037defaa5a0b3bf6d67", transactionIndex: "40", from: "0x449464912fc8ff42b70b69c89bf4d7897c7112c1", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001c5e792bfde48fe082302b1178acb9e5e95fb693176ccbcc730909136614702d7239cbab471ef275481886f456b44f4b620cbabde7caa09719cdcd385d8a5b9d9700000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "1778050", gasUsed: "92362", confirmations: "706218"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x5e792bfde48fe082302b1178acb9e5e95fb693176ccbcc730909136614702d72"}, {type: "bytes32", name: "s", value: "0x39cbab471ef275481886f456b44f4b620cbabde7caa09719cdcd385d8a5b9d97"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0x5e792bfde48fe082302b1178acb9e5e95fb693176ccbcc730909136614702d72", "0x39cbab471ef275481886f456b44f4b620cbabde7caa09719cdcd385d8a5b9d97", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1546000941 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0x449464912fc8ff42b70b69c89bf4d7897c7112c1"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "7839603000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0xc03fe847ff493a9fb6aca059fbba... )", async function( ) {
		const txOriginal = {blockNumber: "6968072", timeStamp: "1546001575", hash: "0xa5257136f02a1fd6b7812f996d410832aa3d23a9d679d8c5dbeec40ab54b3ddd", nonce: "514", blockHash: "0x53e1aa44a4d32143f26a69be13da8072ad483a805c43d4b0825ce84fd3c770b2", transactionIndex: "60", from: "0xa36ce14ef9e04d76800ce2844b1dca31f4235139", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "30000", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001cc03fe847ff493a9fb6aca059fbba78537c17d100ee383ac93e28c64b71c33c6d079de7673f14031fe127e5cd81278ad66d36153f602e097ced44d3eab03dc47400000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "6450038", gasUsed: "30000", confirmations: "706171"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xc03fe847ff493a9fb6aca059fbba78537c17d100ee383ac93e28c64b71c33c6d"}, {type: "bytes32", name: "s", value: "0x079de7673f14031fe127e5cd81278ad66d36153f602e097ced44d3eab03dc474"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "3512941000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6968088", timeStamp: "1546001739", hash: "0x2630786ddf38c65688081dfb4307d62284d30b50af85c3d94576ba35c574d074", nonce: "3", blockHash: "0xb32a2020c0e2a5a0b16206e3d035e18eb44928122493f729981a046f0916cae9", transactionIndex: "151", from: "0x2ac9859cc5b97dd0cd824c04d44aea64f0672f2d", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "6613344", gasUsed: "21046", confirmations: "706155"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1546001739 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "1978662000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0x89bb23d5fcdbb79e0158837244e1... )", async function( ) {
		const txOriginal = {blockNumber: "6968098", timeStamp: "1546001872", hash: "0x351c80957cbffdc7faeeae91d9febfdedeef4bf89fcfaaf8ba164451197366d6", nonce: "4", blockHash: "0xa020e8aebaadca99959af47922a9accedb6e84f91a53e69dec001bf0cb084aef", transactionIndex: "94", from: "0x2ac9859cc5b97dd0cd824c04d44aea64f0672f2d", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001b89bb23d5fcdbb79e0158837244e124a09d5e3aaade5c9c41c4970682d638e422301b7ce4b37bd835a18fe47d033cf9f9391d12122496df65813fba78047614e600000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "6740241", gasUsed: "92362", confirmations: "706145"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x89bb23d5fcdbb79e0158837244e124a09d5e3aaade5c9c41c4970682d638e422"}, {type: "bytes32", name: "s", value: "0x301b7ce4b37bd835a18fe47d033cf9f9391d12122496df65813fba78047614e6"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0x89bb23d5fcdbb79e0158837244e124a09d5e3aaade5c9c41c4970682d638e422", "0x301b7ce4b37bd835a18fe47d033cf9f9391d12122496df65813fba78047614e6", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1546001872 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0x2ac9859cc5b97dd0cd824c04d44aea64f0672f2d"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "1978662000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0x723e1e60ae664a9fb7d81fa545ef... )", async function( ) {
		const txOriginal = {blockNumber: "6968115", timeStamp: "1546002162", hash: "0xfcc72708455d916a637c87dbaf46d0eea7ecaa559157fbf16a2d911853f36aef", nonce: "5", blockHash: "0xf04e39221666c749ed687a10da48c8e14c87597f22f6688704d7aac040c29b69", transactionIndex: "57", from: "0xbffaa84d876cdbf5ac7f11404515d478a2cc3d80", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001c723e1e60ae664a9fb7d81fa545efaac05c1afcc607e4f5b9d60a9a474aaf801c7136941dec371dc892dc28fcf942ccd6f6fad978b19b3a91f7d8d9e13a3e1acd00000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "3111872", gasUsed: "92362", confirmations: "706128"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x723e1e60ae664a9fb7d81fa545efaac05c1afcc607e4f5b9d60a9a474aaf801c"}, {type: "bytes32", name: "s", value: "0x7136941dec371dc892dc28fcf942ccd6f6fad978b19b3a91f7d8d9e13a3e1acd"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0x723e1e60ae664a9fb7d81fa545efaac05c1afcc607e4f5b9d60a9a474aaf801c", "0x7136941dec371dc892dc28fcf942ccd6f6fad978b19b3a91f7d8d9e13a3e1acd", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1546002162 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xbffaa84d876cdbf5ac7f11404515d478a2cc3d80"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "1862983000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0xc03fe847ff493a9fb6aca059fbba... )", async function( ) {
		const txOriginal = {blockNumber: "6968115", timeStamp: "1546002162", hash: "0xc2072c6a57ed79e4a161a6894b5ab58d66882073b111e6f5b1a99351e4916343", nonce: "515", blockHash: "0xf04e39221666c749ed687a10da48c8e14c87597f22f6688704d7aac040c29b69", transactionIndex: "109", from: "0xa36ce14ef9e04d76800ce2844b1dca31f4235139", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "45000", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001cc03fe847ff493a9fb6aca059fbba78537c17d100ee383ac93e28c64b71c33c6d079de7673f14031fe127e5cd81278ad66d36153f602e097ced44d3eab03dc47400000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "6271165", gasUsed: "45000", confirmations: "706128"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xc03fe847ff493a9fb6aca059fbba78537c17d100ee383ac93e28c64b71c33c6d"}, {type: "bytes32", name: "s", value: "0x079de7673f14031fe127e5cd81278ad66d36153f602e097ced44d3eab03dc474"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "3512941000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0xc03fe847ff493a9fb6aca059fbba... )", async function( ) {
		const txOriginal = {blockNumber: "6968128", timeStamp: "1546002349", hash: "0x5a9ea7fe1194f3a0cf0795fb44348baeca37950dd191d9c6f2e3911356193d9a", nonce: "516", blockHash: "0xb9440d1202e111de6e195d7cd62ee5fb0ce3881d2ad5e223c1c5c33591392aa2", transactionIndex: "85", from: "0xa36ce14ef9e04d76800ce2844b1dca31f4235139", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "100000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001cc03fe847ff493a9fb6aca059fbba78537c17d100ee383ac93e28c64b71c33c6d079de7673f14031fe127e5cd81278ad66d36153f602e097ced44d3eab03dc47400000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "7511150", gasUsed: "92298", confirmations: "706115"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xc03fe847ff493a9fb6aca059fbba78537c17d100ee383ac93e28c64b71c33c6d"}, {type: "bytes32", name: "s", value: "0x079de7673f14031fe127e5cd81278ad66d36153f602e097ced44d3eab03dc474"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0xc03fe847ff493a9fb6aca059fbba78537c17d100ee383ac93e28c64b71c33c6d", "0x079de7673f14031fe127e5cd81278ad66d36153f602e097ced44d3eab03dc474", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1546002349 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xa36ce14ef9e04d76800ce2844b1dca31f4235139"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "3512941000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0xcd24535b1d4c28f6244953e8fee9... )", async function( ) {
		const txOriginal = {blockNumber: "6968151", timeStamp: "1546002710", hash: "0x980f4d793b8fa265369f2984cda02e4c7e12152178de0ad2acf8ac53c1a9e9a5", nonce: "50", blockHash: "0x65a01105408e0cec6f3bc4dd473156c5b978d0373780ef643c2151215d5658bc", transactionIndex: "32", from: "0xaea88d83c8bccf611a27829176cbbf39a1cbd655", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "138543", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001ccd24535b1d4c28f6244953e8fee907c03ba08f1d96b7800559e840e712bf9cac6ebc90f213f21264a4c62a2edd426741a75e53aa23a36dfb69f8d77846d9b1b000000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "4089276", gasUsed: "92362", confirmations: "706092"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xcd24535b1d4c28f6244953e8fee907c03ba08f1d96b7800559e840e712bf9cac"}, {type: "bytes32", name: "s", value: "0x6ebc90f213f21264a4c62a2edd426741a75e53aa23a36dfb69f8d77846d9b1b0"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0xcd24535b1d4c28f6244953e8fee907c03ba08f1d96b7800559e840e712bf9cac", "0x6ebc90f213f21264a4c62a2edd426741a75e53aa23a36dfb69f8d77846d9b1b0", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1546002710 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xaea88d83c8bccf611a27829176cbbf39a1cbd655"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "42407199600000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0xef1c3880c29e297b572da59fb553... )", async function( ) {
		const txOriginal = {blockNumber: "6968156", timeStamp: "1546002776", hash: "0xd1e974e058e5f7849e9b52dfd9c74fc9cccd1cf955dd3bb8d8a7b95fc90f44cb", nonce: "0", blockHash: "0x90cabf6f57a0e4bdaff1665616a940537781ed0e80f3983a11f524d890e953c8", transactionIndex: "44", from: "0xaf1984a631724016688092c261ce2488fb8fb9d4", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "70000", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001cef1c3880c29e297b572da59fb553299d715fba9bee25f90f0b28e8980a7889b74bc031a9a4e909900c72328cca919394c84fd3fee5fa3a4c7bd76af60e14e07a00000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "7585500", gasUsed: "69815", confirmations: "706087"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xef1c3880c29e297b572da59fb553299d715fba9bee25f90f0b28e8980a7889b7"}, {type: "bytes32", name: "s", value: "0x4bc031a9a4e909900c72328cca919394c84fd3fee5fa3a4c7bd76af60e14e07a"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0xef1c3880c29e297b572da59fb553299d715fba9bee25f90f0b28e8980a7889b7", "0x4bc031a9a4e909900c72328cca919394c84fd3fee5fa3a4c7bd76af60e14e07a", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1546002776 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "1884120000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0xef1c3880c29e297b572da59fb553... )", async function( ) {
		const txOriginal = {blockNumber: "6968159", timeStamp: "1546002843", hash: "0x5ad277363cf4cbbd6156dffb29cc647f018974425a569d7fc8c83e11f18ddc39", nonce: "1", blockHash: "0x5bd5e81cb655a16c4efd6c48a2aafc41d43ede9aa38c4d2ba50ed1810b4ab956", transactionIndex: "114", from: "0xaf1984a631724016688092c261ce2488fb8fb9d4", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "100000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001cef1c3880c29e297b572da59fb553299d715fba9bee25f90f0b28e8980a7889b74bc031a9a4e909900c72328cca919394c84fd3fee5fa3a4c7bd76af60e14e07a00000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "7754970", gasUsed: "92362", confirmations: "706084"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xef1c3880c29e297b572da59fb553299d715fba9bee25f90f0b28e8980a7889b7"}, {type: "bytes32", name: "s", value: "0x4bc031a9a4e909900c72328cca919394c84fd3fee5fa3a4c7bd76af60e14e07a"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0xef1c3880c29e297b572da59fb553299d715fba9bee25f90f0b28e8980a7889b7", "0x4bc031a9a4e909900c72328cca919394c84fd3fee5fa3a4c7bd76af60e14e07a", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1546002843 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xaf1984a631724016688092c261ce2488fb8fb9d4"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "1884120000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0xa6df1471503d560691c8a083d77d... )", async function( ) {
		const txOriginal = {blockNumber: "6968329", timeStamp: "1546005419", hash: "0x871d89e44d45c9272e7dbcd2ebcbbe72b0de2996aacb7a9d25f8555a32912674", nonce: "6", blockHash: "0xcaf4eb17c7b06ca8ce129faf8e96493109d15f378fa16cf99ec6e3b0feef728f", transactionIndex: "111", from: "0x45bbc5418c502712ed57df916784c4824bfddef3", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001ba6df1471503d560691c8a083d77d76827929e84514f0485d63d33e367ae30c8202e51145e577c8793d48bc3fec68c4fcc6150254697919d0084f7bcd4a4a248600000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "6498482", gasUsed: "92362", confirmations: "705914"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa6df1471503d560691c8a083d77d76827929e84514f0485d63d33e367ae30c82"}, {type: "bytes32", name: "s", value: "0x02e51145e577c8793d48bc3fec68c4fcc6150254697919d0084f7bcd4a4a2486"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0xa6df1471503d560691c8a083d77d76827929e84514f0485d63d33e367ae30c82", "0x02e51145e577c8793d48bc3fec68c4fcc6150254697919d0084f7bcd4a4a2486", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1546005419 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0x45bbc5418c502712ed57df916784c4824bfddef3"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "1180443000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6968361", timeStamp: "1546005887", hash: "0xa6065087f31414d2ec646ca2f99f028d32705de2a1befa45efdfaecec08890dd", nonce: "3", blockHash: "0x0ba5e8a6ea552a3e3d0138abfe626f66d5843dfa57afc1a269365afdee0bb790", transactionIndex: "96", from: "0xea34e12c536443b5a8d5468104babc4c2dec7abd", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "3701768", gasUsed: "21046", confirmations: "705882"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1546005887 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "2024206000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0x6cd5856641f0446e52ff4604e93d... )", async function( ) {
		const txOriginal = {blockNumber: "6968372", timeStamp: "1546006024", hash: "0x7a4d742bb64ae4581e67f070a93192d89f3010c99499491058618c4846c8862e", nonce: "4", blockHash: "0x2ae37baab7245fb40ef5bf2c16d2ab7e192ed8ab9b7588413109d050316e42d6", transactionIndex: "173", from: "0xea34e12c536443b5a8d5468104babc4c2dec7abd", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001c6cd5856641f0446e52ff4604e93df1852da3b50042de4525ca77df7e3e070d6873f1d5163288a2936c75f0bf48fa8775a0f179b73c9af26d854d6b4643515b7200000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "6933887", gasUsed: "92298", confirmations: "705871"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6cd5856641f0446e52ff4604e93df1852da3b50042de4525ca77df7e3e070d68"}, {type: "bytes32", name: "s", value: "0x73f1d5163288a2936c75f0bf48fa8775a0f179b73c9af26d854d6b4643515b72"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0x6cd5856641f0446e52ff4604e93df1852da3b50042de4525ca77df7e3e070d68", "0x73f1d5163288a2936c75f0bf48fa8775a0f179b73c9af26d854d6b4643515b72", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1546006024 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xea34e12c536443b5a8d5468104babc4c2dec7abd"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "2024206000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0xa9cfa0992ccf11b8b4864931fa19... )", async function( ) {
		const txOriginal = {blockNumber: "6968376", timeStamp: "1546006094", hash: "0xf643fd9e8b2a38131d7988c874804027052b482a88b742eb2a2aaf50f15c45df", nonce: "3", blockHash: "0x69c8b36adef454cdeba6401878f7871eeab0f53f2033c4e5650887ce3b73c114", transactionIndex: "123", from: "0xc807fefd6a0a3bed8e3e60d74a9ca5eb8ae9e941", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001ba9cfa0992ccf11b8b4864931fa19dfeacf6929ba550553c3096662940d180fbe17947de0a354cd503c616bf83ef85635736775a50f6d995c9d5f8e7e4714def400000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "6101425", gasUsed: "92362", confirmations: "705867"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xa9cfa0992ccf11b8b4864931fa19dfeacf6929ba550553c3096662940d180fbe"}, {type: "bytes32", name: "s", value: "0x17947de0a354cd503c616bf83ef85635736775a50f6d995c9d5f8e7e4714def4"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0xa9cfa0992ccf11b8b4864931fa19dfeacf6929ba550553c3096662940d180fbe", "0x17947de0a354cd503c616bf83ef85635736775a50f6d995c9d5f8e7e4714def4", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1546006094 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xc807fefd6a0a3bed8e3e60d74a9ca5eb8ae9e941"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "1964636000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0x778913fc0f58acb975b2fc43729c... )", async function( ) {
		const txOriginal = {blockNumber: "6968399", timeStamp: "1546006346", hash: "0x785a535dce5b11f07060d590d092424cf9c460b1c5691369423d55a465dbb29b", nonce: "3", blockHash: "0xae2e5010bc992b6a6ab475b3238ebac3ad31cbe1935f5727f078d702a1e8c2b9", transactionIndex: "82", from: "0x9f25319d5f6deea4edf5e0c4d1d5abaaa9706b5b", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001b778913fc0f58acb975b2fc43729c5844d5d38a603f0c43206579385390eff91b1b6cd04a5e97ec5617da5820d9d5b9999c3d6b9dfb3699d551a465c3c8bdabfa00000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "5317215", gasUsed: "92362", confirmations: "705844"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x778913fc0f58acb975b2fc43729c5844d5d38a603f0c43206579385390eff91b"}, {type: "bytes32", name: "s", value: "0x1b6cd04a5e97ec5617da5820d9d5b9999c3d6b9dfb3699d551a465c3c8bdabfa"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0x778913fc0f58acb975b2fc43729c5844d5d38a603f0c43206579385390eff91b", "0x1b6cd04a5e97ec5617da5820d9d5b9999c3d6b9dfb3699d551a465c3c8bdabfa", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1546006346 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0x9f25319d5f6deea4edf5e0c4d1d5abaaa9706b5b"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "2200017000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0x9f1f5e0f3936f3e9f786a44e86df... )", async function( ) {
		const txOriginal = {blockNumber: "6968399", timeStamp: "1546006346", hash: "0xe611247102ddb19ac568d1b478c7d3b3e655feda3919b368790b30776b2a2c35", nonce: "5", blockHash: "0xae2e5010bc992b6a6ab475b3238ebac3ad31cbe1935f5727f078d702a1e8c2b9", transactionIndex: "94", from: "0x0738f2f11277899489d2faffedbe622934325a11", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001b9f1f5e0f3936f3e9f786a44e86df2a31feb8317376b712c09851ff8a97ab2e7f7bd9adf91e4a76574c00829aeb3b8acf9fd45e5f8268d93503fd58312dc5199700000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "6056949", gasUsed: "92298", confirmations: "705844"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x9f1f5e0f3936f3e9f786a44e86df2a31feb8317376b712c09851ff8a97ab2e7f"}, {type: "bytes32", name: "s", value: "0x7bd9adf91e4a76574c00829aeb3b8acf9fd45e5f8268d93503fd58312dc51997"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0x9f1f5e0f3936f3e9f786a44e86df2a31feb8317376b712c09851ff8a97ab2e7f", "0x7bd9adf91e4a76574c00829aeb3b8acf9fd45e5f8268d93503fd58312dc51997", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1546006346 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0x0738f2f11277899489d2faffedbe622934325a11"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "1788328000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0xd222d678e9eadf2c29e2b672eaaa... )", async function( ) {
		const txOriginal = {blockNumber: "6968414", timeStamp: "1546006514", hash: "0x8a69137cd312c24919e27eecad98d4137776596dd29396027a0486d8658df19e", nonce: "4", blockHash: "0xf063d2928af020753472b276761fce014498e430e0fc19e010f4b827a789e095", transactionIndex: "97", from: "0x72470c12dc8e64648a0760a592ce2274940bea8c", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001cd222d678e9eadf2c29e2b672eaaac682475de42354ff82dc022f6a30ac9b9fb354ee934468b4dc1976b6cafd154c8da3ee91ecee1a979d4647b8baceb33b257000000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "4371425", gasUsed: "92362", confirmations: "705829"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xd222d678e9eadf2c29e2b672eaaac682475de42354ff82dc022f6a30ac9b9fb3"}, {type: "bytes32", name: "s", value: "0x54ee934468b4dc1976b6cafd154c8da3ee91ecee1a979d4647b8baceb33b2570"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0xd222d678e9eadf2c29e2b672eaaac682475de42354ff82dc022f6a30ac9b9fb3", "0x54ee934468b4dc1976b6cafd154c8da3ee91ecee1a979d4647b8baceb33b2570", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1546006514 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0x72470c12dc8e64648a0760a592ce2274940bea8c"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "2098136000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0x0dce39015e2d64acfe65864fcbae... )", async function( ) {
		const txOriginal = {blockNumber: "6968419", timeStamp: "1546006575", hash: "0x37b9fa5867714146cd1ba2efbc439a19c9543b2c9ab7b4488388fb28e01d60fd", nonce: "4", blockHash: "0xa3dfa46123b2b0de75f6e0fc13715a562c8776e6a17e2b0970b3edac130e3ac0", transactionIndex: "92", from: "0xdc3a22647840a993eebce407876284677319eac8", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001b0dce39015e2d64acfe65864fcbae2efdcbc065191cd8c8de835648c8bfb033c20ee8724c233a8ce548b068228f964cd8861cd12094b4ed0ac71302947382416500000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "5766905", gasUsed: "92362", confirmations: "705824"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x0dce39015e2d64acfe65864fcbae2efdcbc065191cd8c8de835648c8bfb033c2"}, {type: "bytes32", name: "s", value: "0x0ee8724c233a8ce548b068228f964cd8861cd12094b4ed0ac713029473824165"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0x0dce39015e2d64acfe65864fcbae2efdcbc065191cd8c8de835648c8bfb033c2", "0x0ee8724c233a8ce548b068228f964cd8861cd12094b4ed0ac713029473824165", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1546006575 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xdc3a22647840a993eebce407876284677319eac8"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "2078136000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0xc11e3289566c98b6015bf529eaab... )", async function( ) {
		const txOriginal = {blockNumber: "6968426", timeStamp: "1546006670", hash: "0xc71eba2c90597f0d585dcf99f785834000e43ff12c944d0ba417469e2803db96", nonce: "3", blockHash: "0xcf6e696d9901cb2a7f591cfa2b5d100c2bbcbdff51da08989a0387527122bbb3", transactionIndex: "54", from: "0xb048d4c62e92bcab4d448ed48eacccf00f20609e", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001bc11e3289566c98b6015bf529eaabeae0868a747cbfcb009a3492c53b503636ac7b820002f2dec9bdb9c42782fbf9e364d736385aaaf7f8280a17ceca4524a70f00000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "4229788", gasUsed: "92234", confirmations: "705817"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xc11e3289566c98b6015bf529eaabeae0868a747cbfcb009a3492c53b503636ac"}, {type: "bytes32", name: "s", value: "0x7b820002f2dec9bdb9c42782fbf9e364d736385aaaf7f8280a17ceca4524a70f"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0xc11e3289566c98b6015bf529eaabeae0868a747cbfcb009a3492c53b503636ac", "0x7b820002f2dec9bdb9c42782fbf9e364d736385aaaf7f8280a17ceca4524a70f", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1546006670 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xb048d4c62e92bcab4d448ed48eacccf00f20609e"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "2115404000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0x15393f9ad1cda7ebb63452b6cb09... )", async function( ) {
		const txOriginal = {blockNumber: "6968429", timeStamp: "1546006702", hash: "0x6afe45b733a94aa5a884cbe9f5756552c7a0523dfd40153c45f57a5f572293e1", nonce: "1", blockHash: "0xd1250da238938591be85e171cd2a123e036e922b2c0058ebde716614c054098b", transactionIndex: "80", from: "0xead091fe59fd7c26295bd31163f4260a55819878", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001c15393f9ad1cda7ebb63452b6cb09612d90aa7ac056f1ce19c3b0f589f179c5050e4151285b51b719f86fd916b37b9bd1da65003ac26d530e6b8f78ffa1e3f2e900000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "4637886", gasUsed: "92298", confirmations: "705814"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x15393f9ad1cda7ebb63452b6cb09612d90aa7ac056f1ce19c3b0f589f179c505"}, {type: "bytes32", name: "s", value: "0x0e4151285b51b719f86fd916b37b9bd1da65003ac26d530e6b8f78ffa1e3f2e9"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0x15393f9ad1cda7ebb63452b6cb09612d90aa7ac056f1ce19c3b0f589f179c505", "0x0e4151285b51b719f86fd916b37b9bd1da65003ac26d530e6b8f78ffa1e3f2e9", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1546006702 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xead091fe59fd7c26295bd31163f4260a55819878"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "1720475000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0x68c8f83e623547dd9386121442e9... )", async function( ) {
		const txOriginal = {blockNumber: "6968465", timeStamp: "1546007280", hash: "0xd5ba052a49c7567a70b76bc71a6bb71a490436a59bdf42426f278a29db40798b", nonce: "1", blockHash: "0x574a772244a504bd82baa6ba89fbd273c089e2d3101a2081ad464f0babb3c58e", transactionIndex: "106", from: "0xe77c531da0e289e1cde9e9bbf3a1e54ee5401f57", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001b68c8f83e623547dd9386121442e9897d64bccab96a92acbc810248cae4c180553c6ab94230eb9b6fcf1671ba0a799f7e456a339894ed4d8a1a176b0c7604cada00000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "5891233", gasUsed: "92362", confirmations: "705778"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x68c8f83e623547dd9386121442e9897d64bccab96a92acbc810248cae4c18055"}, {type: "bytes32", name: "s", value: "0x3c6ab94230eb9b6fcf1671ba0a799f7e456a339894ed4d8a1a176b0c7604cada"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0x68c8f83e623547dd9386121442e9897d64bccab96a92acbc810248cae4c18055", "0x3c6ab94230eb9b6fcf1671ba0a799f7e456a339894ed4d8a1a176b0c7604cada", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1546007280 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xe77c531da0e289e1cde9e9bbf3a1e54ee5401f57"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "1098604000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0x5a2687aabf59c303ce6c41f389c3... )", async function( ) {
		const txOriginal = {blockNumber: "6968508", timeStamp: "1546007840", hash: "0xe0404f4679b2e65cd3b11c0bc468956f918258fd6dc16124ba8b7abfb45abc53", nonce: "0", blockHash: "0x680a1f98a56c1ec1505bb85e0111ccbb63a6a2ca29bf80381201ece5a7afd246", transactionIndex: "46", from: "0x8e5f75462b86ee56b1f7713185a54ea3cdb2781c", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001c5a2687aabf59c303ce6c41f389c354febdda64a88914344a9f410c0c04849b3a0c05700f59bbdab8e8b1f23c3507c5e2cb828cb0338ef93fcddc583444f8e4cd00000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "7966127", gasUsed: "92362", confirmations: "705735"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[37], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x5a2687aabf59c303ce6c41f389c354febdda64a88914344a9f410c0c04849b3a"}, {type: "bytes32", name: "s", value: "0x0c05700f59bbdab8e8b1f23c3507c5e2cb828cb0338ef93fcddc583444f8e4cd"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0x5a2687aabf59c303ce6c41f389c354febdda64a88914344a9f410c0c04849b3a", "0x0c05700f59bbdab8e8b1f23c3507c5e2cb828cb0338ef93fcddc583444f8e4cd", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1546007840 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0x8e5f75462b86ee56b1f7713185a54ea3cdb2781c"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[37], balance: "1260332000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[37], balance: ( await web3.eth.getBalance( addressList[37], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"27\", \"0x6c20f6b8eb2f662a734c9262af50... )", async function( ) {
		const txOriginal = {blockNumber: "6968561", timeStamp: "1546008745", hash: "0x24b2e9a64eb568a5ba75450c826ea2ef571fe6f88ec2e1a26085cafb9dca2d41", nonce: "0", blockHash: "0x972e507ac7999ba33c2e868d4feb99de260ef833d8bf188adaee9587b46ffb3e", transactionIndex: "33", from: "0x352b9b453435f16070c8ef71e84b60d81febb3aa", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001b6c20f6b8eb2f662a734c9262af50a81a3ac9000d379efe870593ca473f1760be418877b20df39ff03af49b77f92bfc6bfb405c59a1fc738a1c5f959d46423e1900000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "7431619", gasUsed: "92298", confirmations: "705682"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x6c20f6b8eb2f662a734c9262af50a81a3ac9000d379efe870593ca473f1760be"}, {type: "bytes32", name: "s", value: "0x418877b20df39ff03af49b77f92bfc6bfb405c59a1fc738a1c5f959d46423e19"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "27", "0x6c20f6b8eb2f662a734c9262af50a81a3ac9000d379efe870593ca473f1760be", "0x418877b20df39ff03af49b77f92bfc6bfb405c59a1fc738a1c5f959d46423e19", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1546008745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0x352b9b453435f16070c8ef71e84b60d81febb3aa"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "1000460000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0x14085f78bb3f8cafab5693d6d6c2... )", async function( ) {
		const txOriginal = {blockNumber: "6968574", timeStamp: "1546009018", hash: "0x049269af89ba041d1fc9da95f22becd6183551554bccc983583b8f563e748be6", nonce: "0", blockHash: "0x9e387bf4273dcc4e0717cea228afb33905906410e73aef9289bee1127560e7fa", transactionIndex: "131", from: "0xed1c8013bfe930b21180a6ead0854d60a9883d87", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001c14085f78bb3f8cafab5693d6d6c223ca29265aacf88db5ac30db04b3885c2c432b7f52d93b5f2f1fe66c96e8269fe7c6a6bd3bcb301ab3d78ef6f697321f893100000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "7737122", gasUsed: "92362", confirmations: "705669"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x14085f78bb3f8cafab5693d6d6c223ca29265aacf88db5ac30db04b3885c2c43"}, {type: "bytes32", name: "s", value: "0x2b7f52d93b5f2f1fe66c96e8269fe7c6a6bd3bcb301ab3d78ef6f697321f8931"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0x14085f78bb3f8cafab5693d6d6c223ca29265aacf88db5ac30db04b3885c2c43", "0x2b7f52d93b5f2f1fe66c96e8269fe7c6a6bd3bcb301ab3d78ef6f697321f8931", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1546009018 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xed1c8013bfe930b21180a6ead0854d60a9883d87"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "1260332000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: airdrop( \"28\", \"0x243c633e5a6f89d151a6270a6496... )", async function( ) {
		const txOriginal = {blockNumber: "6968574", timeStamp: "1546009018", hash: "0x198aca27092d3eec9e059368b28be93c6f61c66817f1028f562bd15eb2769dd4", nonce: "0", blockHash: "0x9e387bf4273dcc4e0717cea228afb33905906410e73aef9289bee1127560e7fa", transactionIndex: "134", from: "0xc3bd2241b28979506c84cf90d6cdadf3535fbec7", to: "0x4c2524807188073516056eadd24753fb3cebf8ba", value: "0", gas: "117000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xcaf91b30000000000000000000000000000000000000000000000000000000000000001c243c633e5a6f89d151a6270a6496208119fe2380305e29b76bb07eacbccb03e122032fc0cd56cf9063983b427af22ec855b3b7b7defb28b878419f22e8002b6100000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "7936812", gasUsed: "92298", confirmations: "705669"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x243c633e5a6f89d151a6270a6496208119fe2380305e29b76bb07eacbccb03e1"}, {type: "bytes32", name: "s", value: "0x22032fc0cd56cf9063983b427af22ec855b3b7b7defb28b878419f22e8002b61"}, {type: "uint256", name: "amount", value: "1500000000000000000000"}], name: "airdrop", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "airdrop(uint8,bytes32,bytes32,uint256)" ]( "28", "0x243c633e5a6f89d151a6270a6496208119fe2380305e29b76bb07eacbccb03e1", "0x22032fc0cd56cf9063983b427af22ec855b3b7b7defb28b878419f22e8002b61", "1500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1546009018 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "AirdropToken", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AirdropToken", events: [{name: "to", type: "address", value: "0xc3bd2241b28979506c84cf90d6cdadf3535fbec7"}, {name: "amount", type: "uint256", value: "1500000000000000000000"}], address: "0x4c2524807188073516056eadd24753fb3cebf8ba"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "1260460000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
