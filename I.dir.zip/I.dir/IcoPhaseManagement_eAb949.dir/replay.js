var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "IcoPhaseManagement"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0xf8Fc0cc97d01A47E0Ba66B167B120A8A0DeAb949","0x41b17F4F6Ad997a67b23f2AA3c1aCd3F8dd2e4D2","0xc6a3746Aa3fec176559f0865Fd5240159402A81f","0x8a187D5285d316bcBC9ADafc08b51d70a0d8e000","0x47eEB2dcAc7b96A06108196a7544cc59bcdaC02E","0x941d900c975cB6CD6A07E67A7a798d64602e9E0D","0x9d3D03A34F714b228C83BbF38A3c38DCf591E21A","0xfC7d5e499f869D8ee0b17C61b0f6f83BbAC2FBc2","0x7251002BdfA4A23c2D443685ce8A2fceF6978942","0xC2F897135AC2EB4f165Aa784561f7174dCe55A59","0x481525718f1536ca2D739aa7e68b94B5e1D5D2C2","0x0A6B6853244a397Fb481927556A882BB8b3Fc4dc","0x58a1dF9F525a38C83c6f103E809a1cC4a41FE245","0xd7d450C63F7B3789F721552509CEeBAc48Ec985a","0x09AA7dc647B0A74a47cB1F5C1a0dF1C1E8620b58","0xFf54308621EEDdf887AA2D1470B480e2C0a195f5","0xEeEC16AeFFA231436B302541289CCD96e1DEDC9d","0x48BD219170c63f23eBa643D9ACbD78219D802c83","0xb855512184923b9EdB4E9A3cf780d1329Fdcd606","0xB80F143B056034064B5fF2C6F26793D3DF83f07B","0xc4AD0b9174DBe86CBFB53a218074607CC261dF6d","0xB5b03C79d33D088A28182e2AAda636893f69ab6F","0x17806E8E5bF77DFf03742CBD6b51Ac6b1f98E973","0xd27b049Fee9eB320f881dA17789EfD882B523a7a","0x79E95F5b9679cA97da6823864548b223024F56FF","0xAa7c67F9a1CB57bb3A5A8F17a2d23FB8bC39EF12","0xc5DE97dE45cf59eaA97d89c68FaC549167B85D28","0x93fB7BeA36d788Bcb87bA92094b72c6c43586Bdb","0x11100f3F6B55427A02064327b7a3E3e16960Cffb","0x4CD85c982cbc36Ae011aC8f58Cf98b2A68CA6E15","0x69884801b1d7c869dEd7191222D18598Aac298f2","0x8415E8788E3d5261449f81f2E84fd292B9d10282","0xbDeFCA014967C0e079616D0004baD73c76b9541A","0x77A935e19660692B27775F1E10724bBF3f834Fb3","0x119865aFB55DDA309072cD1031e7BF2CAF4289bA","0xc3644C919a6fDf88731ce441E3cCdfD3C31b21b7","0x1ed7B1E76dFc90d4DDFDe92E73fC57cAA25B27a0","0x744a34833f079601326B1E77AE30ac0fEE624c0a"]
addressListOriginal.length = 40
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"icoPhase","outputs":[{"name":"","type":"bool"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"icoEndTime","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"contractVersion","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"icoStartTime","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"icoAbandoned","outputs":[{"name":"","type":"bool"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"abandonedIcoBalances","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"}]
eventPrototypeListOriginal = [{"anonymous":false,"inputs":[],"name":"IcoClosed","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"details","type":"string"}],"name":"IcoAbandoned","type":"event"}]
eventSignatureListOriginal = ["IcoClosed()","IcoAbandoned(string)"]
topicListOriginal = ["0x5e04d124c56129382e672952415fc39c773434a5bf8eba7f572a7672e76fe443","0x9166b10ac45c5649d97c0d46ba2c919bd0e4b263909c07c707dab4f1ded2b4d3"]
nBlocksOriginal = 50
fromBlockOriginal = 4036329
toBlockOriginal = 4133216
constructorPrototypeOriginal = {"inputs":[{"type":"address","name":"_authenticationManagerAddress","value":4}],"name":"IcoPhaseManagement","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"4036329","timeStamp":"1500324910","hash":"0x283640ad5eb42ef29c8850d90c33b8bc863db58aa5baedee7a6fa016026ed8a6","nonce":"1","blockHash":"0x4f482b3b2a1b4c2a2df5b8e6a6cf14ca0da6c8fc82832d063fb1b2351b1bbf9f","transactionIndex":"29","from":"0x41b17f4f6ad997a67b23f2aa3c1acd3f8dd2e4d2","to":0,"value":"0","gas":"1027844","gasPrice":"21000000000","isError":"0","txreceipt_status":"","input":"0x25d78d3b000000000000000000000000c6a3746aa3fec176559f0865fd5240159402a81f","contractAddress":"0xf8fc0cc97d01a47e0ba66b167b120a8a0deab949","cumulativeGasUsed":"2502813","gasUsed":"1027843","confirmations":"3643684"}
txOptions[0] = {"from":"0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1","to":0,"value":"0"}
txCall[0] = {"inputs":[{"type":"address","name":"_authenticationManagerAddress","value":"0xFFcf8FDEE72ac11b5c542428B35EEF5769C409f0"}],"name":"IcoPhaseManagement","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
