const InstaKyber = artifacts.require( "./InstaKyber.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "InstaKyber" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x3f0682f440a130794C6F0Dce495AA7beA7bFA0f2", "0xb579D4f1546d51980499aa96a2E411Be3E449197", "0xE16D035B8E76303237b9660b3c9C94c1a86AAB47", "0xdd974D5C2e2928deA5F71b9825b8b646686BD200", "0x89d24A6b4CcB1B6fAA2625fE562bDD9a23260359", "0x744d70FDBE2Ba4CF95131626614a1763DF805B9E", "0x595832F8FC6BF59c85C527fEC3740A1b7a361269", "0x0F5D2fB29fb7d3CFeE444a200298f468908cC942", "0x0D8775F648430679A709E98d2b0Cb6250d2887EF", "0x8f8221aFbB33998d8584A2B05749bA73c37a938a", "0x255Aa6DF07540Cb5d3d297f0D0D4D84cb52bc8e6", "0x1a7a8BD9106F2B8D977E08582DC7d24c723ab0DB", "0x4156D3342D5c385a87D264F90653733592000581", "0x27054b13b1B798B345b591a4d22e6562d47eA75a", "0xF970b8E36e23F7fC3FD752EeA86f8Be8D83375A6", "0x05f4a42e251f2d52b8ed15E9FEdAacFcEF1FAD27", "0x514910771AF9Ca656af840dff83E8264EcF986CA", "0x12480E24eb5bec1a9D4369CaB6a80caD3c0A377A", "0x9f8F72aA9304c8B593d555F12eF6589cC3A579A2", "0x4f3AfEC4E5a3F2A6a1A411DEF7D7dFe50eE057bF", "0xFA1a856Cfa3409CFa145Fa4e20Eb270dF3EB21ab", "0xD0a4b8946Cb52f0661273bfbC6fD0E0C75Fc6433", "0xB98d4C97425d9908E66E53A6fDf673ACcA0BE986", "0x5CA9a71B1d01849C0a95490Cc00559717fCF0D1d", "0x41e5560054824eA6B0732E656E3Ad64E20e94E45", "0x1985365e9f78359a9B6AD760e32412f4a445E862", "0x9992eC3cF6A55b00978cdDF2b27BC6882d88D1eC", "0x69b148395Ce0015C13e36BFfBAd63f49EF874E03", "0x1F573D6Fb3F13d689FF844B4cE37794d79a7FF1C", "0x8dd5fbCe2F6a956C3022bA3663759011Dd51e73E", "0x80fB784B7eD66730e8b1DBd9820aFD29931aab03", "0xB8c77482e45F1F44dE1745F52C74426C631bDD52", "0xE41d2489571d322189246DaFA5ebDe1F4699F498", "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", "0xEA26c4aC16D4a5A106820BC8AEE85fd0b7b2b664", "0x4092678e4E78230F46A1534C0fbc8fA39780892B", "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE", "0x4DCA34903a8CA41373F9Ad0d36ee05C288eF34d9", "0x7284a8451d9a0e7Dc62B3a71C0593eA2eC5c5638", "0xFfF7830F9DDB9D48d9e213354c92604Ef7e1298b", "0x685C80e4c759E6058508ba39Bab59D632F08931A", "0x405A9b7568E0640aFdAE8B3c37182eF34467fC5F", "0x0aD9Fb61a07BAC25625382B63693644497f1B204", "0x7e5cE10826eE167de897D262fCC9976F609ECd2B", "0x72B48383c4D2Fc012E981156678E7851Fae22063", "0x3C1CC48446B69D657dB2192f246e2f5ca84e44DD", "0x47930c76790C865217472f2dDB4d14c640ee450a", "0xEabF7dec6253f3DdbcB70a93FA9a5d6470F6CF74", "0x372e2D6f74eFA2C5A4C72DAC4A31da09E8505995"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "src", type: "address"}, {name: "dest", type: "address"}, {name: "srcAmt", type: "uint256"}], name: "getExpectedPrice", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "addressRegistry", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["KyberTrade(address,uint256,address,uint256,address,uint256,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xaf95114641285cac53dca41a5a81b1d27d822a892a3611d8d8b82d406539ed40"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6778548 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6914605 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "rAddr", value: 4}], name: "InstaKyber", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "src", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "dest", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "srcAmt", value: random.range( maxRandom )}], name: "getExpectedPrice", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getExpectedPrice(address,address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "addressRegistry", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "addressRegistry()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "InstaKyber", function( accounts ) {

	it( "TEST: InstaKyber( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6778548", timeStamp: "1543269385", hash: "0x541ad38d6f12a5c267c9a6af0ad3a99f54e0119317cd5200cf6cd744ba936f6b", nonce: "121", blockHash: "0x8ea47e332801774982dd4f1062a1d78b4a90ffc41ae8120025c2b34a54b31a8f", transactionIndex: "69", from: "0xb579d4f1546d51980499aa96a2e411be3e449197", to: 0, value: "0", gas: "722786", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x1b9e3c70000000000000000000000000e16d035b8e76303237b9660b3c9c94c1a86aab47", contractAddress: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", cumulativeGasUsed: "6922174", gasUsed: "722786", confirmations: "925130"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "rAddr", value: addressList[4]}], name: "InstaKyber", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = InstaKyber.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1543269385 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = InstaKyber.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "489237203941136283" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: approveKyber( [addressList[5]] )", async function( ) {
		const txOriginal = {blockNumber: "6778561", timeStamp: "1543269572", hash: "0x22476c81e97d7f7f8d9c2762c24d57337324c19db8216317447a734d76c335ad", nonce: "122", blockHash: "0x4384a8801be8e67a87cadb9dcd15964b0356e30bfe3162a9e110d8ae28b3b95c", transactionIndex: "64", from: "0xb579d4f1546d51980499aa96a2e411be3e449197", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "77941", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x4fbea8ea00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000001000000000000000000000000dd974d5c2e2928dea5f71b9825b8b646686bd200", contractAddress: "", cumulativeGasUsed: "7478646", gasUsed: "51741", confirmations: "925117"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "tokenArr", value: [addressList[5]]}], name: "approveKyber", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approveKyber(address[])" ]( [addressList[5]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1543269572 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "489237203941136283" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: approveKyber( [addressList[6]] )", async function( ) {
		const txOriginal = {blockNumber: "6778573", timeStamp: "1543269703", hash: "0xb224196a31fb482e5dee792a7b9f7279b609c43ca2c9a8f69082572ca945488a", nonce: "123", blockHash: "0x6247b98dec36ae7b078906658ba01b6cfa3798bdea56221edb95fb9106c0ffd6", transactionIndex: "161", from: "0xb579d4f1546d51980499aa96a2e411be3e449197", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "77899", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x4fbea8ea0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000100000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359", contractAddress: "", cumulativeGasUsed: "7512732", gasUsed: "51715", confirmations: "925105"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "tokenArr", value: [addressList[6]]}], name: "approveKyber", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approveKyber(address[])" ]( [addressList[6]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1543269703 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "489237203941136283" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: approveKyber( [addressList[7],addressList[8],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "6778599", timeStamp: "1543269960", hash: "0x92e6b3e1e456d2883788723e8bf8510f785240664e88be347b10e1a4a4753a60", nonce: "124", blockHash: "0xbe219945323ec0671d02a1cffeea40f257ecf3503283c8f17a680ac0382cfa1c", transactionIndex: "83", from: "0xb579d4f1546d51980499aa96a2e411be3e449197", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "863392", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x4fbea8ea0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001f000000000000000000000000744d70fdbe2ba4cf95131626614a1763df805b9e000000000000000000000000595832f8fc6bf59c85c527fec3740a1b7a3612690000000000000000000000000f5d2fb29fb7d3cfee444a200298f468908cc9420000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef0000000000000000000000008f8221afbb33998d8584a2b05749ba73c37a938a000000000000000000000000255aa6df07540cb5d3d297f0d0d4d84cb52bc8e60000000000000000000000001a7a8bd9106f2b8d977e08582dc7d24c723ab0db0000000000000000000000004156d3342d5c385a87d264f9065373359200058100000000000000000000000027054b13b1b798b345b591a4d22e6562d47ea75a000000000000000000000000f970b8e36e23f7fc3fd752eea86f8be8d83375a600000000000000000000000005f4a42e251f2d52b8ed15e9fedaacfcef1fad27000000000000000000000000514910771af9ca656af840dff83e8264ecf986ca00000000000000000000000012480e24eb5bec1a9d4369cab6a80cad3c0a377a0000000000000000000000009f8f72aa9304c8b593d555f12ef6589cc3a579a20000000000000000000000004f3afec4e5a3f2a6a1a411def7d7dfe50ee057bf000000000000000000000000fa1a856cfa3409cfa145fa4e20eb270df3eb21ab000000000000000000000000d0a4b8946cb52f0661273bfbc6fd0e0c75fc6433000000000000000000000000b98d4c97425d9908e66e53a6fdf673acca0be9860000000000000000000000005ca9a71b1d01849c0a95490cc00559717fcf0d1d00000000000000000000000041e5560054824ea6b0732e656e3ad64e20e94e450000000000000000000000001985365e9f78359a9b6ad760e32412f4a445e8620000000000000000000000009992ec3cf6a55b00978cddf2b27bc6882d88d1ec00000000000000000000000069b148395ce0015c13e36bffbad63f49ef874e030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000008dd5fbce2f6a956c3022ba3663759011dd51e73e00000000000000000000000080fb784b7ed66730e8b1dbd9820afd29931aab03000000000000000000000000b8c77482e45f1f44de1745f52c74426c631bdd52000000000000000000000000e41d2489571d322189246dafa5ebde1f4699f498000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc2000000000000000000000000ea26c4ac16d4a5a106820bc8aee85fd0b7b2b6640000000000000000000000004092678e4e78230f46a1534c0fbc8fa39780892b", contractAddress: "", cumulativeGasUsed: "7983998", gasUsed: "863175", confirmations: "925079"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "tokenArr", value: [addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37]]}], name: "approveKyber", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approveKyber(address[])" ]( [addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1543269960 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "489237203941136283" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[38], addressList[5], \"15000... )", async function( ) {
		const txOriginal = {blockNumber: "6778638", timeStamp: "1543270496", hash: "0x334584abce5b2a4626b928fb36e4b4889f0b9d8700129022bdc52261e2cffc1f", nonce: "125", blockHash: "0x7098eb151fe1486f2ed0d9a030ebef7b0ef6cfd33a04f803c824ecc312c36e0e", transactionIndex: "30", from: "0xb579d4f1546d51980499aa96a2e411be3e449197", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "1500000000000000", gas: "371740", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee000000000000000000000000dd974d5c2e2928dea5f71b9825b8b646686bd2000000000000000000000000000000000000000000000000000005543df729c0000000000000000000000000000000000000000000000000220112ddee9e05a640800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "5551575", gasUsed: "255671", confirmations: "925040"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1500000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[38]}, {type: "address", name: "dest", value: addressList[5]}, {type: "uint256", name: "srcAmt", value: "1500000000000000"}, {type: "uint256", name: "minConversionRate", value: "627266666666666600000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[38], addressList[5], "1500000000000000", "627266666666666600000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543270496 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "srcAmt", type: "uint256", value: "1500000000000000"}, {name: "dest", type: "address", value: "0xdd974d5c2e2928dea5f71b9825b8b646686bd200"}, {name: "destAmt", type: "uint256", value: "1009259383093776450"}, {name: "beneficiary", type: "address", value: "0xb579d4f1546d51980499aa96a2e411be3e449197"}, {name: "minConversionRate", type: "uint256", value: "627266666666666600000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "489237203941136283" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[5], \"160000... )", async function( ) {
		const txOriginal = {blockNumber: "6778638", timeStamp: "1543270496", hash: "0xfc352082b218c05411cebca914cf4235e03bdaf47d06cf0094491dafc4eb3c20", nonce: "127", blockHash: "0x7098eb151fe1486f2ed0d9a030ebef7b0ef6cfd33a04f803c824ecc312c36e0e", transactionIndex: "32", from: "0xb579d4f1546d51980499aa96a2e411be3e449197", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "492538", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000dd974d5c2e2928dea5f71b9825b8b646686bd20000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000519c2d47d6481000800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "6090930", gasUsed: "492538", confirmations: "925040"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[5]}, {type: "uint256", name: "srcAmt", value: "160000000000000000"}, {type: "uint256", name: "minConversionRate", value: "5880625000000000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "489237203941136283" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[5], addressList[38], \"30000... )", async function( ) {
		const txOriginal = {blockNumber: "6778648", timeStamp: "1543270633", hash: "0x0561af0eb1ca881c7971086e705aaaf1e729d5e6feec5071e06ce8beb008c338", nonce: "129", blockHash: "0x45a68b3224c437aabe4bf621706e25e334bc782306a65fc91386025103fbb1d7", transactionIndex: "62", from: "0xb579d4f1546d51980499aa96a2e411be3e449197", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000dd974d5c2e2928dea5f71b9825b8b646686bd200000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee00000000000000000000000000000000000000000000000029a2241af62c00000000000000000000000000000000000000000000000000000004e7adbf65fd55800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "3948137", gasUsed: "272116", confirmations: "925030"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[5]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "3000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "1380633333333333"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[5], addressList[38], "3000000000000000000", "1380633333333333", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1543270633 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xdd974d5c2e2928dea5f71b9825b8b646686bd200"}, {name: "srcAmt", type: "uint256", value: "3000000000000000000"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "4387763490377574"}, {name: "beneficiary", type: "address", value: "0xb579d4f1546d51980499aa96a2e411be3e449197"}, {name: "minConversionRate", type: "uint256", value: "1380633333333333"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "489237203941136283" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[5], addressList[6], \"200000... )", async function( ) {
		const txOriginal = {blockNumber: "6778650", timeStamp: "1543270660", hash: "0xefed65125008aada2e85dc84f15a66d3d23f93e3fa2add42f96fcab5f8e33d94", nonce: "130", blockHash: "0x13f76ef1deaced348c7328781be34436cd332b5a012d4e1c21bbd2aea8d8abdb", transactionIndex: "50", from: "0xb579d4f1546d51980499aa96a2e411be3e449197", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "492538", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000dd974d5c2e2928dea5f71b9825b8b646686bd20000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000001bc16d674ec8000000000000000000000000000000000000000000000000000002062040a7b87800800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "5905036", gasUsed: "475361", confirmations: "925028"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[5]}, {type: "address", name: "dest", value: addressList[6]}, {type: "uint256", name: "srcAmt", value: "2000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "145839500000000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[5], addressList[6], "2000000000000000000", "145839500000000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543270660 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xdd974d5c2e2928dea5f71b9825b8b646686bd200"}, {name: "srcAmt", type: "uint256", value: "2000000000000000000"}, {name: "dest", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "destAmt", type: "uint256", value: "309322627063926200"}, {name: "beneficiary", type: "address", value: "0xb579d4f1546d51980499aa96a2e411be3e449197"}, {name: "minConversionRate", type: "uint256", value: "145839500000000000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "489237203941136283" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[5], \"160000... )", async function( ) {
		const txOriginal = {blockNumber: "6778666", timeStamp: "1543270980", hash: "0x0ae4277baf7a1456ea1f155eadef4258a02e51bebb4f42359ce222e9375f2d2e", nonce: "131", blockHash: "0x3891f5eb254675773d0454bc6f43cb9eeb24b34b81c4b23fc4d18be2257f1e84", transactionIndex: "35", from: "0xb579d4f1546d51980499aa96a2e411be3e449197", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "592538", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000dd974d5c2e2928dea5f71b9825b8b646686bd20000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000519c2d47d6481000800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "6570449", gasUsed: "483125", confirmations: "925012"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[5]}, {type: "uint256", name: "srcAmt", value: "160000000000000000"}, {type: "uint256", name: "minConversionRate", value: "5880625000000000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[5], "160000000000000000", "5880625000000000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1543270980 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "160000000000000000"}, {name: "dest", type: "address", value: "0xdd974d5c2e2928dea5f71b9825b8b646686bd200"}, {name: "destAmt", type: "uint256", value: "984669991136357956"}, {name: "beneficiary", type: "address", value: "0xb579d4f1546d51980499aa96a2e411be3e449197"}, {name: "minConversionRate", type: "uint256", value: "5880625000000000000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "489237203941136283" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[38], addressList[5], \"15000... )", async function( ) {
		const txOriginal = {blockNumber: "6782364", timeStamp: "1543324837", hash: "0x6649cf568234bf1211feeb8892f59f2af2861f7325cd67e3077d51e397d78b3d", nonce: "133", blockHash: "0xe7c606db178073210df4aefe21407db350730f154cb5a93010edeb4da83cf1ae", transactionIndex: "191", from: "0xb579d4f1546d51980499aa96a2e411be3e449197", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "1500000000000000", gas: "371523", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee000000000000000000000000dd974d5c2e2928dea5f71b9825b8b646686bd2000000000000000000000000000000000000000000000000000005543df729c0000000000000000000000000000000000000000000000000220112ddee9e05a640800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "7633392", gasUsed: "247682", confirmations: "921314"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1500000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[38]}, {type: "address", name: "dest", value: addressList[5]}, {type: "uint256", name: "srcAmt", value: "1500000000000000"}, {type: "uint256", name: "minConversionRate", value: "627266666666666600000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[38], addressList[5], "1500000000000000", "627266666666666600000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543324837 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "srcAmt", type: "uint256", value: "1500000000000000"}, {name: "dest", type: "address", value: "0xdd974d5c2e2928dea5f71b9825b8b646686bd200"}, {name: "destAmt", type: "uint256", value: "1009146800769983231"}, {name: "beneficiary", type: "address", value: "0xb579d4f1546d51980499aa96a2e411be3e449197"}, {name: "minConversionRate", type: "uint256", value: "627266666666666600000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "489237203941136283" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[38], addressList[21], \"3559... )", async function( ) {
		const txOriginal = {blockNumber: "6785579", timeStamp: "1543370794", hash: "0x1d2a415a7b4c830cf1012d4021d45d754a35d8a806540078ac4c8daf4693df01", nonce: "0", blockHash: "0x20afb419ac4eb548f2f2f7dc2147be2fc7d898b544a4cc2113a2dfd9816ef75b", transactionIndex: "56", from: "0x4dca34903a8ca41373f9ad0d36ee05c288ef34d9", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "355900000000000000", gas: "884092", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000004f3afec4e5a3f2a6a1a411def7d7dfe50ee057bf00000000000000000000000000000000000000000000000004f0692a138fc00000000000000000000000000000000000000000000000000024b061774256a21c800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "4194246", gasUsed: "588225", confirmations: "918099"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "355900000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[38]}, {type: "address", name: "dest", value: addressList[21]}, {type: "uint256", name: "srcAmt", value: "355900000000000000"}, {type: "uint256", name: "minConversionRate", value: "2643720146108457500"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[38], addressList[21], "355900000000000000", "2643720146108457500", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1543370794 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "srcAmt", type: "uint256", value: "355900000000000000"}, {name: "dest", type: "address", value: "0x4f3afec4e5a3f2a6a1a411def7d7dfe50ee057bf"}, {name: "destAmt", type: "uint256", value: "999904334"}, {name: "beneficiary", type: "address", value: "0x4dca34903a8ca41373f9ad0d36ee05c288ef34d9"}, {name: "minConversionRate", type: "uint256", value: "2643720146108457500"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[21], addressList[38], \"9999... )", async function( ) {
		const txOriginal = {blockNumber: "6785830", timeStamp: "1543374362", hash: "0x22c37905e2197f74778b5b056d36c3fdbd6ca9483f76fb3f9ba5c32d6de35f54", nonce: "2", blockHash: "0x9fe5433a76f01191bdc45f77be26bd89b0e620126c33e95e0ccc0ed2fa6c9674", transactionIndex: "29", from: "0x4dca34903a8ca41373f9ad0d36ee05c288ef34d9", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "881613", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0x3e23ee7e0000000000000000000000004f3afec4e5a3f2a6a1a411def7d7dfe50ee057bf000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee000000000000000000000000000000000000000000000000000000003b99436000000000000000000000000000000000000000000000000000000000132a4a5d800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "2812108", gasUsed: "442562", confirmations: "917848"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[21]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "999900000"}, {type: "uint256", name: "minConversionRate", value: "321538653"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[21], addressList[38], "999900000", "321538653", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1543374362 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[38], addressList[20], \"3259... )", async function( ) {
		const txOriginal = {blockNumber: "6802531", timeStamp: "1543611779", hash: "0x6646f5b5f1bda43d439d94925b3f409fecacd7638563f88fad5ab7c240919b01", nonce: "177", blockHash: "0x787b37b45cbbd5f1d5acfb13e92041674be0979eaa1409714c5655bcc7c12a7b", transactionIndex: "138", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "32599999999999996", gas: "462100", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000009f8f72aa9304c8b593d555f12ef6589cc3a579a20000000000000000000000000000000000000000000000000073d186fbad7ffc00000000000000000000000000000000000000000000000004016206aab69474800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "7099398", gasUsed: "278067", confirmations: "901147"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "32599999999999996" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[38]}, {type: "address", name: "dest", value: addressList[20]}, {type: "uint256", name: "srcAmt", value: "32599999999999996"}, {type: "uint256", name: "minConversionRate", value: "288619631901840500"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[38], addressList[20], "32599999999999996", "288619631901840500", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1543611779 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "srcAmt", type: "uint256", value: "32599999999999996"}, {name: "dest", type: "address", value: "0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2"}, {name: "destAmt", type: "uint256", value: "10008802735619375"}, {name: "beneficiary", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "minConversionRate", type: "uint256", value: "288619631901840500"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "13011729783201857559" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[38], addressList[6], \"44300... )", async function( ) {
		const txOriginal = {blockNumber: "6818630", timeStamp: "1543842527", hash: "0x6c333881e2d5c28529745303fa79e7622ddcf0c9347dc660e8d3d474f16eca58", nonce: "201", blockHash: "0x80c79da1abb0db8cb07cb00a00ed76729545e014be57c726519ebc4df5a79ec0", transactionIndex: "90", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "44300000000000000", gas: "450481", gasPrice: "5500000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000000000000000000000000000009d629d838cc000000000000000000000000000000000000000000000000005c1c55c78b9176cc0800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "5200063", gasUsed: "300321", confirmations: "885048"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "44300000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[38]}, {type: "address", name: "dest", value: addressList[6]}, {type: "uint256", name: "srcAmt", value: "44300000000000000"}, {type: "uint256", name: "minConversionRate", value: "106196388261851000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[38], addressList[6], "44300000000000000", "106196388261851000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1543842527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "srcAmt", type: "uint256", value: "44300000000000000"}, {name: "dest", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "destAmt", type: "uint256", value: "4988966324999999983"}, {name: "beneficiary", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "minConversionRate", type: "uint256", value: "106196388261851000000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "13011729783201857559" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"89852... )", async function( ) {
		const txOriginal = {blockNumber: "6818646", timeStamp: "1543842690", hash: "0xfd7ff0567b1a7ecad183c567aaadcd5e9d7009e715edd9ab6f6030b688df3ee1", nonce: "203", blockHash: "0x62ba664cac7f75f0f8ab6ca25c5b6f42692e73cd4482daf3bf8f3648144a7bf6", transactionIndex: "61", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "5200000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000000000000000000000000000007cb1d7cb5bd703e8000000000000000000000000000000000000000000000000001d3d9b7fcfe770800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "7807796", gasUsed: "324944", confirmations: "885032"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "8985200000000001000"}, {type: "uint256", name: "minConversionRate", value: "8230512398165872"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "8985200000000001000", "8230512398165872", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1543842690 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "8985200000000001000"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "78620499999999999"}, {name: "beneficiary", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "minConversionRate", type: "uint256", value: "8230512398165872"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "13011729783201857559" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[38], addressList[6], \"23200... )", async function( ) {
		const txOriginal = {blockNumber: "6818938", timeStamp: "1543846946", hash: "0x5475c633ebdeee6d6c05654808965af70db4f912850e6157dd6dee24fd9a9b5c", nonce: "211", blockHash: "0x39d458201b26acb39ec212d0ca30b90a4f34d0890dc2bc031538d93001520f5a", transactionIndex: "27", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "23200000000000000", gas: "450385", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000526c46eeca0000000000000000000000000000000000000000000000000005b75a5810f0a251a0800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "1827201", gasUsed: "300257", confirmations: "884740"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "23200000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[38]}, {type: "address", name: "dest", value: addressList[6]}, {type: "uint256", name: "srcAmt", value: "23200000000000000"}, {type: "uint256", name: "minConversionRate", value: "105445689655172420000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[38], addressList[6], "23200000000000000", "105445689655172420000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1543846946 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "srcAmt", type: "uint256", value: "23200000000000000"}, {name: "dest", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "destAmt", type: "uint256", value: "2591904000000000000"}, {name: "beneficiary", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "minConversionRate", type: "uint256", value: "105445689655172420000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "13011729783201857559" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"10000... )", async function( ) {
		const txOriginal = {blockNumber: "6827583", timeStamp: "1543970227", hash: "0xdda83ba3f13cf3de379d10051acf5ef7d9e962016304e92f2f86eb7dfe67bc45", nonce: "24", blockHash: "0xf40916c658eeee20cf768034a7a1ef1f52d9589dd29e5bc27d6be80df573d78b", transactionIndex: "82", from: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000000000000000000000800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "6827360", gasUsed: "324305", confirmations: "876095"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "10000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "0"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "10000000000000000000", "0", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1543970227 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "10000000000000000000"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "89864864864864860"}, {name: "beneficiary", type: "address", value: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b"}, {name: "minConversionRate", type: "uint256", value: "0"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "718809857125790252" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[38], addressList[6], \"29100... )", async function( ) {
		const txOriginal = {blockNumber: "6832799", timeStamp: "1544044679", hash: "0x899048c0a54503752be2b0cabd336cf09e60990151326721152a01bad2bc2f9c", nonce: "30", blockHash: "0x471da0578d4e50c7de726122e7041b067cc4d695bcae94e9755c6244ad92fa70", transactionIndex: "41", from: "0x685c80e4c759e6058508ba39bab59d632f08931a", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "29100000000000000", gas: "472789", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000000067624bbaf6c00000000000000000000000000000000000000000000000000542253a126ce40000800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "2419930", gasUsed: "315193", confirmations: "870879"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[42], to: addressList[2], value: "29100000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[38]}, {type: "address", name: "dest", value: addressList[6]}, {type: "uint256", name: "srcAmt", value: "29100000000000000"}, {type: "uint256", name: "minConversionRate", value: "97000000000000000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[38], addressList[6], "29100000000000000", "97000000000000000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1544044679 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "srcAmt", type: "uint256", value: "29100000000000000"}, {name: "dest", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "destAmt", type: "uint256", value: "2978486122499998441"}, {name: "beneficiary", type: "address", value: "0x685c80e4c759e6058508ba39bab59d632f08931a"}, {name: "minConversionRate", type: "uint256", value: "97000000000000000000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[42], balance: "287030202151501742" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[42], balance: ( await web3.eth.getBalance( addressList[42], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[38], addressList[20], \"3570... )", async function( ) {
		const txOriginal = {blockNumber: "6836730", timeStamp: "1544101165", hash: "0x2c3d88eb2533979465bf77705b85d8043b367250a6e0a15adaa8a34e44431679", nonce: "37", blockHash: "0x8c075d574f5097cb524e068db585ea9253de7c875f7e37a31bf5c3a83cb1a67e", transactionIndex: "81", from: "0x685c80e4c759e6058508ba39bab59d632f08931a", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "35700000000000004", gas: "439600", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000009f8f72aa9304c8b593d555f12ef6589cc3a579a2000000000000000000000000000000000000000000000000007ed4f5fa7b400400000000000000000000000000000000000000000000000003a858146dfeed42800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "5980421", gasUsed: "278067", confirmations: "866948"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[42], to: addressList[2], value: "35700000000000004" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[38]}, {type: "address", name: "dest", value: addressList[20]}, {type: "uint256", name: "srcAmt", value: "35700000000000004"}, {type: "uint256", name: "minConversionRate", value: "263557422969187650"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[38], addressList[20], "35700000000000004", "263557422969187650", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1544101165 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "srcAmt", type: "uint256", value: "35700000000000004"}, {name: "dest", type: "address", value: "0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2"}, {name: "destAmt", type: "uint256", value: "10003019662921349"}, {name: "beneficiary", type: "address", value: "0x685c80e4c759e6058508ba39bab59d632f08931a"}, {name: "minConversionRate", type: "uint256", value: "263557422969187650"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[42], balance: "287030202151501742" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[42], balance: ( await web3.eth.getBalance( addressList[42], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[35], addressList[6], \"20000... )", async function( ) {
		const txOriginal = {blockNumber: "6839148", timeStamp: "1544136055", hash: "0x7df43065bde4a3436f58f450a1c851fc08468015eb00b347143494d0863a3c42", nonce: "55", blockHash: "0xf1092ab4e04d72827c4f3772622f7445750621ffab6d46f044df73cd3710efa9", transactionIndex: "45", from: "0x685c80e4c759e6058508ba39bab59d632f08931a", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "492538", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000001bc16d674ec80000000000000000000000000000000000000000000000000004b4c2ac03ec832800800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "4085645", gasUsed: "397862", confirmations: "864530"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[42], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[35]}, {type: "address", name: "dest", value: addressList[6]}, {type: "uint256", name: "srcAmt", value: "2000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "86812138500000000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[35], addressList[6], "2000000000000000000", "86812138500000000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1544136055 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "srcAmt", type: "uint256", value: "2000000000000000000"}, {name: "dest", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "destAmt", type: "uint256", value: "184537539899999999998"}, {name: "beneficiary", type: "address", value: "0x685c80e4c759e6058508ba39bab59d632f08931a"}, {name: "minConversionRate", type: "uint256", value: "86812138500000000000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[42], balance: "287030202151501742" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[42], balance: ( await web3.eth.getBalance( addressList[42], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[35], \"17624... )", async function( ) {
		const txOriginal = {blockNumber: "6841537", timeStamp: "1544170309", hash: "0x9e98b0b36cd5b27a5a5d34efd1914e901e606f95d3bb30bcaa58a639fdabfdf6", nonce: "56", blockHash: "0x20a460e965c90765e10202cf5a1186a5a3528a17721f5c6d69d98d47306ab77a", transactionIndex: "21", from: "0x685c80e4c759e6058508ba39bab59d632f08931a", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "492538", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc20000000000000000000000000000000000000000000000098dd2423d8ed800000000000000000000000000000000000000000000000000000025ef1dc343e0e2800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "3884899", gasUsed: "422792", confirmations: "862141"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[42], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[35]}, {type: "uint256", name: "srcAmt", value: "176240000000000000000"}, {type: "uint256", name: "minConversionRate", value: "10677485247389922"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[35], "176240000000000000000", "10677485247389922", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1544170309 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "176240000000000000000"}, {name: "dest", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "destAmt", type: "uint256", value: "2032363005780346668"}, {name: "beneficiary", type: "address", value: "0x685c80e4c759e6058508ba39bab59d632f08931a"}, {name: "minConversionRate", type: "uint256", value: "10677485247389922"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[42], balance: "287030202151501742" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[42], balance: ( await web3.eth.getBalance( addressList[42], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[38], addressList[6], \"23500... )", async function( ) {
		const txOriginal = {blockNumber: "6842864", timeStamp: "1544189624", hash: "0x7efda09085f6d061b78e0a2d7ce5bf284a3ab2ff8af65067e999c4833d4bade7", nonce: "242", blockHash: "0xb9186f5e8f007d77a8bd82fb2be0f7700c2e1f614df7a0766e795a57c217ab53", transactionIndex: "84", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "23500000000000000", gas: "450481", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000537d202038c00000000000000000000000000000000000000000000000000457493790d8420b40800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "7442807", gasUsed: "300321", confirmations: "860814"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "23500000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[38]}, {type: "address", name: "dest", value: addressList[6]}, {type: "uint256", name: "srcAmt", value: "23500000000000000"}, {type: "uint256", name: "minConversionRate", value: "80076595744680840000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[38], addressList[6], "23500000000000000", "80076595744680840000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1544189624 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "srcAmt", type: "uint256", value: "23500000000000000"}, {name: "dest", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "destAmt", type: "uint256", value: "1992506249999999999"}, {name: "beneficiary", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "minConversionRate", type: "uint256", value: "80076595744680840000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "13011729783201857559" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"10230... )", async function( ) {
		const txOriginal = {blockNumber: "6843819", timeStamp: "1544203147", hash: "0x55e3a568da75aac10e6a2cb738160fbed67c5eefc544496f761de4b1a7f3b31c", nonce: "143", blockHash: "0x349b0be87749e8bf334496c558c251454a1111e7b2c0a6aab9f770ed39d120de", transactionIndex: "148", from: "0xb579d4f1546d51980499aa96a2e411be3e449197", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000000000000000000000000000008df953a5c5adc00000000000000000000000000000000000000000000000000000282812daf30992800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "4654619", gasUsed: "324880", confirmations: "859859"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "10230300000000000000"}, {type: "uint256", name: "minConversionRate", value: "11303060516309394"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "10230300000000000000", "11303060516309394", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1544203147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "10230300000000000000"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "122948484939759030"}, {name: "beneficiary", type: "address", value: "0xb579d4f1546d51980499aa96a2e411be3e449197"}, {name: "minConversionRate", type: "uint256", value: "11303060516309394"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "489237203941136283" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"10000... )", async function( ) {
		const txOriginal = {blockNumber: "6850241", timeStamp: "1544295260", hash: "0x1db4b4a0e4413864f14d8fb1852c2a6bc3bfda879f88782c6ee80d4cc28e814c", nonce: "17", blockHash: "0xafc21ddca62c05bb6661619975f9caa4eb5c294c2df1ba18ed187f3ac614fcc6", transactionIndex: "19", from: "0x405a9b7568e0640afdae8b3c37182ef34467fc5f", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee00000000000000000000000000000000000000000000003635c9adc5dea000000000000000000000000000000000000000000000000000000026d94d6e39dd00800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "1029675", gasUsed: "309692", confirmations: "853437"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[43], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "1000000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "10934975700000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "1000000000000000000000", "10934975700000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1544295260 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "1000000000000000000000"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "11157718120805368000"}, {name: "beneficiary", type: "address", value: "0x405a9b7568e0640afdae8b3c37182ef34467fc5f"}, {name: "minConversionRate", type: "uint256", value: "10934975700000000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[43], balance: "7734141463879778000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[43], balance: ( await web3.eth.getBalance( addressList[43], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[15], \"27500... )", async function( ) {
		const txOriginal = {blockNumber: "6854385", timeStamp: "1544354134", hash: "0x8c4ce8dc54763962eafdd77049270cb1fce3b07ac53fc2a855987ed2d5bc02d3", nonce: "762", blockHash: "0x3d909966fc5bb551cc8ff299400868a61c8fb1cd74c15b7cec359b764ed1dcdf", transactionIndex: "9", from: "0x0ad9fb61a07bac25625382b63693644497f1b204", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "492538", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000027054b13b1b798b345b591a4d22e6562d47ea75a0000000000000000000000000000000000000000000000002629f66e0c530000000000000000000000000000000000000000000000000001dad27bd081a33fc8800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "1094928", gasUsed: "476851", confirmations: "849293"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[44], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[15]}, {type: "uint256", name: "srcAmt", value: "2750000000000000000"}, {type: "uint256", name: "minConversionRate", value: "34214545454545453000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[15], "2750000000000000000", "34214545454545453000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1544354134 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[44], balance: "560000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[44], balance: ( await web3.eth.getBalance( addressList[44], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[38], addressList[20], \"7610... )", async function( ) {
		const txOriginal = {blockNumber: "6854397", timeStamp: "1544354262", hash: "0xce9b77d9bd813be4d5118ca9b64bee30319ff276c0d3b21b84a719ff86ae465d", nonce: "89", blockHash: "0x0d09e1d9c9955b12c941fb39d53f67f5fcedf07fbb1e3cda0fba513bb8d4120c", transactionIndex: "34", from: "0x7e5ce10826ee167de897d262fcc9976f609ecd2b", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "76100000000000000", gas: "439600", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000009f8f72aa9304c8b593d555f12ef6589cc3a579a2000000000000000000000000000000000000000000000000010e5c8bfb684000000000000000000000000000000000000000000000000000036e83c116214e64800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "2692753", gasUsed: "278067", confirmations: "849281"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[45], to: addressList[2], value: "76100000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[38]}, {type: "address", name: "dest", value: addressList[20]}, {type: "uint256", name: "srcAmt", value: "76100000000000000"}, {type: "uint256", name: "minConversionRate", value: "247279894875164260"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[38], addressList[20], "76100000000000000", "247279894875164260", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1544354262 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "srcAmt", type: "uint256", value: "76100000000000000"}, {name: "dest", type: "address", value: "0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2"}, {name: "destAmt", type: "uint256", value: "19976302569217287"}, {name: "beneficiary", type: "address", value: "0x7e5ce10826ee167de897d262fcc9976f609ecd2b"}, {name: "minConversionRate", type: "uint256", value: "247279894875164260"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[45], balance: "13158436784597229042" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[45], balance: ( await web3.eth.getBalance( addressList[45], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[15], \"34300... )", async function( ) {
		const txOriginal = {blockNumber: "6854403", timeStamp: "1544354377", hash: "0xd857d5dd93d4296c4e925b0d567aad96a6373ed1ac6f37531718aecfc9da9983", nonce: "763", blockHash: "0x89386de68250c8a84adad2c5ad2bbc54290e281de1518a49a7d7ade91ac30ec3", transactionIndex: "56", from: "0x0ad9fb61a07bac25625382b63693644497f1b204", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "600000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000027054b13b1b798b345b591a4d22e6562d47ea75a0000000000000000000000000000000000000000000000002f99ced3bb970000000000000000000000000000000000000000000000000001dbdc45f973bd7fb0800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "2990878", gasUsed: "490529", confirmations: "849275"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[44], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[15]}, {type: "uint256", name: "srcAmt", value: "3430000000000000000"}, {type: "uint256", name: "minConversionRate", value: "34289358600583086000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[15], "3430000000000000000", "34289358600583086000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1544354377 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "3430000000000000000"}, {name: "dest", type: "address", value: "0x27054b13b1b798b345b591a4d22e6562d47ea75a"}, {name: "destAmt", type: "uint256", value: "1245306"}, {name: "beneficiary", type: "address", value: "0x0ad9fb61a07bac25625382b63693644497f1b204"}, {name: "minConversionRate", type: "uint256", value: "34289358600583086000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[44], balance: "560000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[44], balance: ( await web3.eth.getBalance( addressList[44], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[35], addressList[38], \"6000... )", async function( ) {
		const txOriginal = {blockNumber: "6855531", timeStamp: "1544370810", hash: "0xe2493faa23b650dc11a3b526bad210c9eee51486129137be8da0408f7634e760", nonce: "198", blockHash: "0x583d077a69698ddb72ab2fb18a9d0df35774185031098da8f784e5f0a88940ea", transactionIndex: "127", from: "0x72b48383c4d2fc012e981156678e7851fae22063", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc2000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee00000000000000000000000000000000000000000000000000d529ae9e8600000000000000000000000000000000000000000000000000000de0b6b3a7640000800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "6183490", gasUsed: "194775", confirmations: "848147"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[35]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "60000000000000000"}, {type: "uint256", name: "minConversionRate", value: "1000000000000000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[35], addressList[38], "60000000000000000", "1000000000000000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1544370810 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "srcAmt", type: "uint256", value: "60000000000000000"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "60000000000000000"}, {name: "beneficiary", type: "address", value: "0x72b48383c4d2fc012e981156678e7851fae22063"}, {name: "minConversionRate", type: "uint256", value: "1000000000000000000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "2487029006691994263" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[38], addressList[16], \"1610... )", async function( ) {
		const txOriginal = {blockNumber: "6855775", timeStamp: "1544374280", hash: "0x9f4dac74cc35f5a6b11d3147d4fadaa33ed8f4100df723d36c0d425a31a6e08b", nonce: "764", blockHash: "0xe1e933a4e1263ef768db94eb6a2b336c4657c05b9f4ac46bf73e3aa682c130d4", transactionIndex: "75", from: "0x0ad9fb61a07bac25625382b63693644497f1b204", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "16100000000000000", gas: "241929", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee000000000000000000000000f970b8e36e23f7fc3fd752eea86f8be8d83375a6000000000000000000000000000000000000000000000000003932dd5ce24000000000000000000000000000000000000000000000000185ace684b998805d40800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "3362730", gasUsed: "226929", confirmations: "847903"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[44], to: addressList[2], value: "16100000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[38]}, {type: "address", name: "dest", value: addressList[16]}, {type: "uint256", name: "srcAmt", value: "16100000000000000"}, {type: "uint256", name: "minConversionRate", value: "7188242236024845000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[38], addressList[16], "16100000000000000", "7188242236024845000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1544374280 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "srcAmt", type: "uint256", value: "16100000000000000"}, {name: "dest", type: "address", value: "0xf970b8e36e23f7fc3fd752eea86f8be8d83375a6"}, {name: "destAmt", type: "uint256", value: "123512016400937052630"}, {name: "beneficiary", type: "address", value: "0x0ad9fb61a07bac25625382b63693644497f1b204"}, {name: "minConversionRate", type: "uint256", value: "7188242236024845000000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[44], balance: "560000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[44], balance: ( await web3.eth.getBalance( addressList[44], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[29], addressList[6], \"20000... )", async function( ) {
		const txOriginal = {blockNumber: "6856403", timeStamp: "1544383058", hash: "0x13325c02c4db021f83029b2ca27889b63a63238177d65ec11f46806193745661", nonce: "137", blockHash: "0x5734679c0d5cd487844f3b1d65e65e6440d66fc26657817bfe155973bc315fac", transactionIndex: "18", from: "0x3c1cc48446b69d657db2192f246e2f5ca84e44dd", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "492538", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000069b148395ce0015c13e36bffbad63f49ef874e0300000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000000000000000000000000001158e460913d000000000000000000000000000000000000000000000000000000001abdf2d227400800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "1895988", gasUsed: "441865", confirmations: "847275"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[29]}, {type: "address", name: "dest", value: addressList[6]}, {type: "uint256", name: "srcAmt", value: "20000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "470450000000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[29], addressList[6], "20000000000000000000", "470450000000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1544383058 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x69b148395ce0015c13e36bffbad63f49ef874e03"}, {name: "srcAmt", type: "uint256", value: "20000000000000000000"}, {name: "dest", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "destAmt", type: "uint256", value: "18847207465385696"}, {name: "beneficiary", type: "address", value: "0x3c1cc48446b69d657db2192f246e2f5ca84e44dd"}, {name: "minConversionRate", type: "uint256", value: "470450000000000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "9410000000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[27], \"97660... )", async function( ) {
		const txOriginal = {blockNumber: "6856431", timeStamp: "1544383447", hash: "0x446dd98ef666a8bba9fc03884f4a726cc6ddde82a322a97fec11ee3265a44a20", nonce: "142", blockHash: "0xc5b4d3e2de99e2bd198f0ae68cda952c2c958798998d6047622602b175c6b3ee", transactionIndex: "24", from: "0x3c1cc48446b69d657db2192f246e2f5ca84e44dd", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "492538", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000001985365e9f78359a9b6ad760e32412f4a445e8620000000000000000000000000000000000000000000000054b4e04933ca6000000000000000000000000000000000000000000000000000002016d2a14e3a040800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "1754201", gasUsed: "477010", confirmations: "847247"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[27]}, {type: "uint256", name: "srcAmt", value: "97660000000000000000"}, {type: "uint256", name: "minConversionRate", value: "144516690559082560"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[27], "97660000000000000000", "144516690559082560", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1544383447 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "9410000000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[27], \"97660... )", async function( ) {
		const txOriginal = {blockNumber: "6856439", timeStamp: "1544383548", hash: "0xde97f9931bc541811a0fb4d1a3b2623d1a76b2f63b2dc58fb622c3cc8432a4d6", nonce: "143", blockHash: "0x32e24588ad0d1d7b9484d9cdfbee6401f5dbc48bac72419d0395f8eb42c102c2", transactionIndex: "28", from: "0x3c1cc48446b69d657db2192f246e2f5ca84e44dd", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "792538", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000001985365e9f78359a9b6ad760e32412f4a445e8620000000000000000000000000000000000000000000000054b4e04933ca6000000000000000000000000000000000000000000000000000001b9ff5909af4098800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "2108230", gasUsed: "502558", confirmations: "847239"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[27]}, {type: "uint256", name: "srcAmt", value: "97660000000000000000"}, {type: "uint256", name: "minConversionRate", value: "124411222609051800"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[27], "97660000000000000000", "124411222609051800", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1544383548 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "97660000000000000000"}, {name: "dest", type: "address", value: "0x1985365e9f78359a9b6ad760e32412f4a445e862"}, {name: "destAmt", type: "uint256", value: "14936793326749338727"}, {name: "beneficiary", type: "address", value: "0x3c1cc48446b69d657db2192f246e2f5ca84e44dd"}, {name: "minConversionRate", type: "uint256", value: "124411222609051800"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "9410000000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[27], addressList[38], \"9244... )", async function( ) {
		const txOriginal = {blockNumber: "6856506", timeStamp: "1544384351", hash: "0x823d8fafe2b121aaf530352f6c11bc35eeb7d3490410b2c1b43604fbce29a02f", nonce: "145", blockHash: "0x41e5b9d9b8763ea82840f25851f4cc51ffef1562fbfcf6ae7f63eb98c844fffc", transactionIndex: "53", from: "0x3c1cc48446b69d657db2192f246e2f5ca84e44dd", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e0000000000000000000000001985365e9f78359a9b6ad760e32412f4a445e862000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000000000000000000000000000000cd44a32faf8135000000000000000000000000000000000000000000000000000c9fd92d3d7e492800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "5643334", gasUsed: "312070", confirmations: "847172"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[27]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "924445406337176400"}, {type: "uint256", name: "minConversionRate", value: "56855277380035730"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[27], addressList[38], "924445406337176400", "56855277380035730", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1544384351 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x1985365e9f78359a9b6ad760e32412f4a445e862"}, {name: "srcAmt", type: "uint256", value: "924445406337176400"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "62178415511184045"}, {name: "beneficiary", type: "address", value: "0x3c1cc48446b69d657db2192f246e2f5ca84e44dd"}, {name: "minConversionRate", type: "uint256", value: "56855277380035730"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "9410000000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"23588... )", async function( ) {
		const txOriginal = {blockNumber: "6856517", timeStamp: "1544384461", hash: "0xa92ea9b480de17b7f708b691bcf99e2b18cfa33b836bb4553e54090d7d702aae", nonce: "146", blockHash: "0x258fd714b9acf594634bb1335094219b7968d98a6d7b8b4b8113cd233cbd448d", transactionIndex: "48", from: "0x3c1cc48446b69d657db2192f246e2f5ca84e44dd", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee00000000000000000000000000000000000000000000000020bc4f0998657e1c0000000000000000000000000000000000000000000000000022fd4f699dc84e800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "4540571", gasUsed: "324944", confirmations: "847161"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "2358847207465385500"}, {type: "uint256", name: "minConversionRate", value: "9848666724354126"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "2358847207465385500", "9848666724354126", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1544384461 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "2358847207465385500"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "24725732630346842"}, {name: "beneficiary", type: "address", value: "0x3c1cc48446b69d657db2192f246e2f5ca84e44dd"}, {name: "minConversionRate", type: "uint256", value: "9848666724354126"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "9410000000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"30000... )", async function( ) {
		const txOriginal = {blockNumber: "6861313", timeStamp: "1544451776", hash: "0xf7608115e8f262d184e578482a81ce24027d84af3b0db7cc687fc0948ecf6e0b", nonce: "250", blockHash: "0x5ff48dd938cd65c66aa7ab852ca7b9084f610ea4fe2570eba2ca794d2ca9814d", transactionIndex: "177", from: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee000000000000000000000000000000000000000000000001a055690d9db80000000000000000000000000000000000000000000000000000002629a331633c00800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "7942912", gasUsed: "339816", confirmations: "842365"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "30000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "10741830000000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "30000000000000000000", "10741830000000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1544451776 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "30000000000000000000"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "328846153846153830"}, {name: "beneficiary", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}, {name: "minConversionRate", type: "uint256", value: "10741830000000000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "13011729783201857559" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[28], addressList[38], \"4058... )", async function( ) {
		const txOriginal = {blockNumber: "6877577", timeStamp: "1544683698", hash: "0x41f78d1427480239e58c579a8837431adb85ccb1d613b082b4cdfdbb591b1385", nonce: "463", blockHash: "0x071d1b7d0bc63425b0c4c15eadf5af099e4ccf03b1a0c7031cfe625a11b8662d", transactionIndex: "118", from: "0x47930c76790c865217472f2ddb4d14c640ee450a", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e0000000000000000000000009992ec3cf6a55b00978cddf2b27bc6882d88d1ec000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee000000000000000000000000000000000000000000000015ffd962230115c0000000000000000000000000000000000000000000000000000004e8f9ab9b6256800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "5632628", gasUsed: "221569", confirmations: "826101"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[28]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "405817500000000000000"}, {type: "uint256", name: "minConversionRate", value: "1382058930430550"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[28], addressList[38], "405817500000000000000", "1382058930430550", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1544683698 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x9992ec3cf6a55b00978cddf2b27bc6882d88d1ec"}, {name: "srcAmt", type: "uint256", value: "405817500000000000000"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "600607988824490827"}, {name: "beneficiary", type: "address", value: "0x47930c76790c865217472f2ddb4d14c640ee450a"}, {name: "minConversionRate", type: "uint256", value: "1382058930430550"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "558322513492795641" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"15000... )", async function( ) {
		const txOriginal = {blockNumber: "6877883", timeStamp: "1544688344", hash: "0x0bf472b400fdc4f052b5a5087205951d0bdefe4bd4d38e107aba91a6113f3028", nonce: "23", blockHash: "0xf15c182d0070d06a0fb9902743b806c7e96f1b49ea884e28513a6b9625726792", transactionIndex: "119", from: "0x405a9b7568e0640afdae8b3c37182ef34467fc5f", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee00000000000000000000000000000000000000000000005150ae84a8cdf000000000000000000000000000000000000000000000000000000025928d41fb6754800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "7373889", gasUsed: "309756", confirmations: "825795"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[43], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "1500000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "10575709533333332"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "1500000000000000000000", "10575709533333332", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1544688344 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "1500000000000000000000"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "16860558582953127000"}, {name: "beneficiary", type: "address", value: "0x405a9b7568e0640afdae8b3c37182ef34467fc5f"}, {name: "minConversionRate", type: "uint256", value: "10575709533333332"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[43], balance: "7734141463879778000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[43], balance: ( await web3.eth.getBalance( addressList[43], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[38], addressList[10], \"2298... )", async function( ) {
		const txOriginal = {blockNumber: "6882104", timeStamp: "1544747657", hash: "0x740a1b72b37e1c41a9b7959cb66e145af94395b8211911c1a706a873f45b8e7d", nonce: "156", blockHash: "0xdc57babdedaa6069c536a3be37d2b77057ec43be4fb0df3fa49bf4b9557a6008", transactionIndex: "95", from: "0x3c1cc48446b69d657db2192f246e2f5ca84e44dd", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "2298700000000000300", gas: "378553", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef0000000000000000000000000000000000000000000000001fe69f789130c12c00000000000000000000000000000000000000000000002150ffccf80a2c8120800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "6664202", gasUsed: "252165", confirmations: "821574"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "2298700000000000300" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[38]}, {type: "address", name: "dest", value: addressList[10]}, {type: "uint256", name: "srcAmt", value: "2298700000000000300"}, {type: "uint256", name: "minConversionRate", value: "614579163440205300000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[38], addressList[10], "2298700000000000300", "614579163440205300000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1544747657 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "srcAmt", type: "uint256", value: "2298700000000000300"}, {name: "dest", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "destAmt", type: "uint256", value: "1504424475856020449228"}, {name: "beneficiary", type: "address", value: "0x3c1cc48446b69d657db2192f246e2f5ca84e44dd"}, {name: "minConversionRate", type: "uint256", value: "614579163440205300000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "9410000000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[38], addressList[20], \"4110... )", async function( ) {
		const txOriginal = {blockNumber: "6897305", timeStamp: "1544965139", hash: "0xfe6dd995b377ed4d794b66e935138005a2a75b5bd7aec1d76c04af8ba7b5f2f0", nonce: "210", blockHash: "0x0ea7d84a0b12be53055d46efc2d9cf16fafea01f4500f2bae724559775816738", transactionIndex: "66", from: "0xeabf7dec6253f3ddbcb70a93fa9a5d6470f6cf74", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "411000000000000000", gas: "438088", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000009f8f72aa9304c8b593d555f12ef6589cc3a579a200000000000000000000000000000000000000000000000005b42a528aaf8000000000000000000000000000000000000000000000000000032d521cf5086940800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "3758152", gasUsed: "277059", confirmations: "806373"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "411000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[38]}, {type: "address", name: "dest", value: addressList[20]}, {type: "uint256", name: "srcAmt", value: "411000000000000000"}, {type: "uint256", name: "minConversionRate", value: "228929440389294400"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[38], addressList[20], "411000000000000000", "228929440389294400", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1544965139 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "srcAmt", type: "uint256", value: "411000000000000000"}, {name: "dest", type: "address", value: "0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2"}, {name: "destAmt", type: "uint256", value: "99993780457465645"}, {name: "beneficiary", type: "address", value: "0xeabf7dec6253f3ddbcb70a93fa9a5d6470f6cf74"}, {name: "minConversionRate", type: "uint256", value: "228929440389294400"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "1629527062359882850" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"99000... )", async function( ) {
		const txOriginal = {blockNumber: "6904278", timeStamp: "1545065877", hash: "0x4625b2bb4d9bcedf627cdc18a67de4146734a75cdb5889c777c09ab82ea01f23", nonce: "4", blockHash: "0xd098f4509a2a8a15b1d85412b825664f059f91aaf1ec00c203cc13d25ce6d5aa", transactionIndex: "52", from: "0x372e2d6f74efa2c5a4c72dac4a31da09e8505995", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000000000000000000000000000055de6a779bbac00000000000000000000000000000000000000000000000000000024d90d1c588676800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "6797556", gasUsed: "324225", confirmations: "799400"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[50], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "99000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "10371749494949494"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "99000000000000000000", "10371749494949494", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1545065877 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "99000000000000000000"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "1082648645638518519"}, {name: "beneficiary", type: "address", value: "0x372e2d6f74efa2c5a4c72dac4a31da09e8505995"}, {name: "minConversionRate", type: "uint256", value: "10371749494949494"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[50], balance: "77301248642327836" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[50], balance: ( await web3.eth.getBalance( addressList[50], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"84000... )", async function( ) {
		const txOriginal = {blockNumber: "6904609", timeStamp: "1545070923", hash: "0x7142e107cba136315b407c6e63c75ef4dbb8329e4df9a01d53ad22fe2dd1d440", nonce: "6", blockHash: "0x472b259678579bb12165146d90f9a83e9a7c7877f339ef27b8f80adc61c4140f", transactionIndex: "40", from: "0x372e2d6f74efa2c5a4c72dac4a31da09e8505995", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000000000000000000000000000048dbbf2f2ecd000000000000000000000000000000000000000000000000000000027edfa0330dfb8800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "7270616", gasUsed: "39896", confirmations: "799069"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[50], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "84000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "11239182142857144"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "84000000000000000000", "11239182142857144", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1545070923 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[50], balance: "77301248642327836" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[50], balance: ( await web3.eth.getBalance( addressList[50], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"40000... )", async function( ) {
		const txOriginal = {blockNumber: "6905712", timeStamp: "1545087000", hash: "0xd559ff233b8005d6527c4ed671f30901c82c293f97f332d774badd123f8dc916", nonce: "41", blockHash: "0xd3315c34f0ed5264bad55a2d20bd85f97bd61c7a30bd7a0f9b5939601d4c0996", transactionIndex: "8", from: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000000000000000000000000000022b1c8c1227a0000000000000000000000000000000000000000000000000000000254db1c2243ffe800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "7345916", gasUsed: "309225", confirmations: "797966"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "40000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "10499999999999998"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "40000000000000000000", "10499999999999998", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1545087000 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "40000000000000000000"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "423117709437963880"}, {name: "beneficiary", type: "address", value: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b"}, {name: "minConversionRate", type: "uint256", value: "10499999999999998"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "718809857125790252" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[35], addressList[6], \"20000... )", async function( ) {
		const txOriginal = {blockNumber: "6905814", timeStamp: "1545088419", hash: "0x001439b6024e29c2eb623e1ac78673bf7c706bb956e76d00a7f8a574c11b32c2", nonce: "43", blockHash: "0xc2e38fdc7577be72e2bc428bd0d2abdd76760bd3d96613191968ca7d88564305", transactionIndex: "49", from: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "492538", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000004c8cdca632fadf1e0800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "7881776", gasUsed: "397271", confirmations: "797864"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[35]}, {type: "address", name: "dest", value: addressList[6]}, {type: "uint256", name: "srcAmt", value: "200000000000000000"}, {type: "uint256", name: "minConversionRate", value: "88256419999999980000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[35], addressList[6], "200000000000000000", "88256419999999980000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1545088419 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "srcAmt", type: "uint256", value: "200000000000000000"}, {name: "dest", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "destAmt", type: "uint256", value: "18613349999999999999"}, {name: "beneficiary", type: "address", value: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b"}, {name: "minConversionRate", type: "uint256", value: "88256419999999980000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "718809857125790252" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[5], addressList[6], \"285246... )", async function( ) {
		const txOriginal = {blockNumber: "6905818", timeStamp: "1545088464", hash: "0x54a5c16de76ecb0f2c7f5ec903adf49ef7a1bbca83a52751acda56c25d1128aa", nonce: "44", blockHash: "0xd1f71369bb769b46114ce517523aa37567db7696ad8e4ff5ec3b65194bf2a8df", transactionIndex: "44", from: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "492538", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e000000000000000000000000dd974d5c2e2928dea5f71b9825b8b646686bd20000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000f7698903f455f400000000000000000000000000000000000000000000000000001b0125ecc68ef0e800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "7147321", gasUsed: "475180", confirmations: "797860"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[5]}, {type: "address", name: "dest", value: addressList[6]}, {type: "uint256", name: "srcAmt", value: "285246900000000000000"}, {type: "uint256", name: "minConversionRate", value: "121617388304658190"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[5], addressList[6], "285246900000000000000", "121617388304658190", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1545088464 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0xdd974d5c2e2928dea5f71b9825b8b646686bd200"}, {name: "srcAmt", type: "uint256", value: "285246900000000000000"}, {name: "dest", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "destAmt", type: "uint256", value: "36974975252103471241"}, {name: "beneficiary", type: "address", value: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b"}, {name: "minConversionRate", type: "uint256", value: "121617388304658190"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "718809857125790252" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[5], addressList[38], \"28524... )", async function( ) {
		const txOriginal = {blockNumber: "6908046", timeStamp: "1545121686", hash: "0xbbb609c09b3dd535f8395ce9c19019869769a57b2eb058238df84d5e0273c9c8", nonce: "45", blockHash: "0x5e2e603a5e472238c6236f0a512a33f5db31d80806b16b7a96e918854a3d456e", transactionIndex: "42", from: "0xfff7830f9ddb9d48d9e213354c92604ef7e1298b", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0x3e23ee7e000000000000000000000000dd974d5c2e2928dea5f71b9825b8b646686bd200000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee00000000000000000000000000000000000000000000000f7698903f455f40000000000000000000000000000000000000000000000000000004a49773a0af4f800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "7407181", gasUsed: "352137", confirmations: "795632"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[5]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "285246900000000000000"}, {type: "uint256", name: "minConversionRate", value: "1306870293770063"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[5], addressList[38], "285246900000000000000", "1306870293770063", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1545121686 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "718809857125790252" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"12000... )", async function( ) {
		const txOriginal = {blockNumber: "6914532", timeStamp: "1545217454", hash: "0x5067d7100e8946c8c1a3fbf29935f733087340f43a2daebca6175ecccca5c156", nonce: "26", blockHash: "0x6b5fc38a2bee15077a6cc518ed8539dace98b2ebc7b292db98626bbc167f0660", transactionIndex: "86", from: "0x405a9b7568e0640afdae8b3c37182ef34467fc5f", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "7601500000", isError: "1", txreceipt_status: "0", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000000000000000000000000000410d586a20a4c000000000000000000000000000000000000000000000000000000020463441261700800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "3746224", gasUsed: "334726", confirmations: "789146"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[43], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "1200000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "9084389500000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "1200000000000000000000", "9084389500000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1545217454 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[43], balance: "7734141463879778000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[43], balance: ( await web3.eth.getBalance( addressList[43], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"12000... )", async function( ) {
		const txOriginal = {blockNumber: "6914549", timeStamp: "1545217640", hash: "0xb99a40d06ecfe635e609fd6520f39ba13a94897e1838ecf0c983dbc437200204", nonce: "27", blockHash: "0x35ac2cd9e79109156d55b15608c1cc10af2c3a1464a8d7a0b0a5dcd19f9d7962", transactionIndex: "46", from: "0x405a9b7568e0640afdae8b3c37182ef34467fc5f", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "25000000000", isError: "1", txreceipt_status: "0", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000000000000000000000000000410d586a20a4c0000000000000000000000000000000000000000000000000000000219e6d10af4f00800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "1674123", gasUsed: "334863", confirmations: "789129"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[43], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "1200000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "9462865500000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "1200000000000000000000", "9462865500000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1545217640 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[43], balance: "7734141463879778000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[43], balance: ( await web3.eth.getBalance( addressList[43], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"12000... )", async function( ) {
		const txOriginal = {blockNumber: "6914582", timeStamp: "1545218031", hash: "0xc15e5beb02f6805ecec811c7b58d47bab78113d734495c533ca7603b24709bd5", nonce: "28", blockHash: "0x2f2f137148b59eab47cc4d9eb3c71b95ebaeace99707d2e680ab923f3631859e", transactionIndex: "33", from: "0x405a9b7568e0640afdae8b3c37182ef34467fc5f", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "360000", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000000000000000000000000000410d586a20a4c000000000000000000000000000000000000000000000000000000020172362958000800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "1948261", gasUsed: "337647", confirmations: "789096"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[43], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "1200000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "9032640000000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "1200000000000000000000", "9032640000000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1545218031 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[43], balance: "7734141463879778000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[43], balance: ( await web3.eth.getBalance( addressList[43], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"12000... )", async function( ) {
		const txOriginal = {blockNumber: "6914602", timeStamp: "1545218270", hash: "0x7b17300b538ebb51a5957424ddc3d55312eb61a139aadfa5505249d1a84961b2", nonce: "29", blockHash: "0xc0b2b5796532b58a2b3f917976bf5add5b4c82006b9dc35531ddca092a58a3d4", transactionIndex: "139", from: "0x405a9b7568e0640afdae8b3c37182ef34467fc5f", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "357172", gasPrice: "4800000000", isError: "1", txreceipt_status: "0", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000000000000000000000000000410d586a20a4c000000000000000000000000000000000000000000000000000000020172362958000800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "4485504", gasUsed: "334863", confirmations: "789076"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[43], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "1200000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "9032640000000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "1200000000000000000000", "9032640000000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1545218270 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[43], balance: "7734141463879778000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[43], balance: ( await web3.eth.getBalance( addressList[43], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: executeTrade( addressList[6], addressList[38], \"12000... )", async function( ) {
		const txOriginal = {blockNumber: "6914605", timeStamp: "1545218357", hash: "0x81262802fe96308265da38125f3de46e7122b3322ad4e68cb8ee63b65e2d597b", nonce: "30", blockHash: "0x39830f2d16907328c78d3ca5655809fe7d86d7e9fbb67295a884e28dfcec00b2", transactionIndex: "4", from: "0x405a9b7568e0640afdae8b3c37182ef34467fc5f", to: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2", value: "0", gas: "500000", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x3e23ee7e00000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee0000000000000000000000000000000000000000000000410d586a20a4c000000000000000000000000000000000000000000000000000000020172362958000800000000000016c889a28c160ce0422bb9138ff1d4e48274000000000000000", contractAddress: "", cumulativeGasUsed: "480849", gasUsed: "348847", confirmations: "789073"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[43], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "src", value: addressList[6]}, {type: "address", name: "dest", value: addressList[38]}, {type: "uint256", name: "srcAmt", value: "1200000000000000000000"}, {type: "uint256", name: "minConversionRate", value: "9032640000000000"}, {type: "uint256", name: "maxDestAmt", value: "57896044618658100000000000000000000000000000000000000000000000000000000000000"}], name: "executeTrade", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "executeTrade(address,address,uint256,uint256,uint256)" ]( addressList[6], addressList[38], "1200000000000000000000", "9032640000000000", "57896044618658100000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1545218357 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "src", type: "address"}, {indexed: false, name: "srcAmt", type: "uint256"}, {indexed: false, name: "dest", type: "address"}, {indexed: false, name: "destAmt", type: "uint256"}, {indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "minConversionRate", type: "uint256"}, {indexed: false, name: "affiliate", type: "address"}], name: "KyberTrade", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "KyberTrade", events: [{name: "src", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "srcAmt", type: "uint256", value: "1200000000000000000000"}, {name: "dest", type: "address", value: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}, {name: "destAmt", type: "uint256", value: "11520531603410307600"}, {name: "beneficiary", type: "address", value: "0x405a9b7568e0640afdae8b3c37182ef34467fc5f"}, {name: "minConversionRate", type: "uint256", value: "9032640000000000"}, {name: "affiliate", type: "address", value: "0x7284a8451d9a0e7dc62b3a71c0593ea2ec5c5638"}], address: "0x3f0682f440a130794c6f0dce495aa7bea7bfa0f2"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[43], balance: "7734141463879778000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[43], balance: ( await web3.eth.getBalance( addressList[43], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
