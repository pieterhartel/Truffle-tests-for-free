const ITTicket = artifacts.require( "./ITTicket.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "ITTicket" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x6B31a2EF5986d283332E4A3a608aDB3C09fFdD13", "0xE8478559f5c775BC1d25e636186D90faAC5FdbD4", "0x5970f4872B41C5532a930E69D5363e9C2241f3c6", "0xa07E04F54cB79558863906B3e96d4298Ec63296E", "0xBDAACea6A70baBA0d51CF17ba81C24372f47D2A7", "0xbb8D11436850ae2abaeA86Ff4c83C79De7Ccb9cf", "0x9e315E9701908501f6dC68A2af6e28a20C75d970", "0x4ca0c81F6E594ac83C54584A49a3760cADc42423", "0xD706Edca0B5D34d2dB3acF92137FB28c97929D87", "0xe70F46dB43085C4dA54Fe380ac04cB3955B50AB3", "0x05935b37d38d374f4D27e63Dc7df2c8Ce687B0ec", "0x258e2EDa1e6F554813C65B2fb1A11a003B8C8629", "0x72d0ed985BD3fF775beaD61747cC55f6C260c639", "0x67B9cA1F543Bf21d5DE381C3319a551C22059Eaa", "0xD0877Ba727251EE13e90881b285a792bA8B746E5", "0xB5EF960812768903596dc0c21C9EA52D15Ab8472", "0x03C4dcDbD7Efc4fD32e2C0E92D4E1F8B778e1A56", "0x4b81D0733362594915ffd1F1bacE83576F276dEb", "0xd5B7cB57a6B1d95ac509C4ab1b44b9EbeF8f01f7", "0x0Bb49A85306EE9AA24709B26DDAA30249cC21BAC", "0x7d15b8d557E9f9123b9F7Ee5D06087974B673Ec0"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "interfaceId", type: "bytes4"}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_legendaryTicketCount", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tokenId", type: "uint256"}], name: "getApproved", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "_ticketHashMap", outputs: [{name: "key", type: "address"}, {name: "ticketType", type: "uint8"}, {name: "exchange", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_rarePrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "account", type: "address"}], name: "isAdmin", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "owner", type: "address"}, {name: "index", type: "uint256"}], name: "tokenOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "id", type: "uint256"}, {name: "v", type: "uint8"}, {name: "r", type: "bytes32"}, {name: "s", type: "bytes32"}], name: "verifyOwnerTicket", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "account", type: "address"}], name: "isPauser", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "id", type: "uint256"}], name: "getHashExchangeState", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "index", type: "uint256"}], name: "tokenByIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_ticketFlag", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tokenId", type: "uint256"}], name: "ownerOf", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_rareAddCount", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_normalPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_legendaryAddCount", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "_ticketMap", outputs: [{name: "ticketType", type: "uint8"}, {name: "ticketFlag", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_curTicketId", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_legendaryPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tokenId", type: "uint256"}], name: "tokenURI", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_sellNormalTicketCount", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_baseAddRatio", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "owner", type: "address"}, {name: "operator", type: "address"}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_rareTicketCount", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "ticketId", type: "uint256"}], name: "getTicketInfo", outputs: [{name: "ticketType", type: "uint8"}, {name: "ticketFlag", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}], name: "AddTicketHash", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "ticketId", type: "uint256"}, {indexed: false, name: "ticketType", type: "uint8"}], name: "ExchangeOwnerTicket", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}], name: "Paused", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "account", type: "address"}], name: "Unpaused", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "PauserAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "PauserRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "AdminAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "AdminRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "approved", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "operator", type: "address"}, {indexed: false, name: "approved", type: "bool"}], name: "ApprovalForAll", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["AddTicketHash(uint256)", "ExchangeOwnerTicket(uint8,address,uint256,uint256,uint8)", "BuyTicket(uint8,address,uint8)", "Paused(address)", "Unpaused(address)", "PauserAdded(address)", "PauserRemoved(address)", "AdminAdded(address)", "AdminRemoved(address)", "OwnershipTransferred(address,address)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)", "ApprovalForAll(address,address,bool)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x2b18c29869c3611bc6ecbb90c579823fa067924192d0db836b8e87afee77bc2c", "0x4f545f6bcf62eb2ffc046617d0a42b6ec21df1f850aaba8e45acdea984c75938", "0xe645d62f5ce95c40ef0ed49325a0a29aa1e8821dd852d0cfa87e02c221e27a5d", "0x62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258", "0x5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa", "0x6719d08c1888103bea251a4ed56406bd0c3e69723c8a1686e017e7bbe159b6f8", "0xcd265ebaf09df2871cc7bd4133404a235ba12eff2041bb89d9c714a2621c7c7e", "0x44d6d25963f097ad14f29f06854a01f575648a1ef82f30e562ccd3889717e339", "0xa3b62bc36326052d97ea62d63c3d60308ed4c3ea8ac079dd8499f1e9c4f80c0f", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0x17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6805861 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6816900 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "ITTicket", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "bytes4", name: "interfaceId", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "supportsInterface(bytes4)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_legendaryTicketCount", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_legendaryTicketCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tokenId", value: random.range( maxRandom )}], name: "getApproved", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getApproved(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "_ticketHashMap", outputs: [{name: "key", type: "address"}, {name: "ticketType", type: "uint8"}, {name: "exchange", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_ticketHashMap(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_rarePrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_rarePrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "account", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isAdmin", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isAdmin(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "index", value: random.range( maxRandom )}], name: "tokenOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenOfOwnerByIndex(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "id", value: random.range( maxRandom )}, {type: "uint8", name: "v", value: random.range( maxRandom )}, {type: "bytes32", name: "r", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "bytes32", name: "s", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "verifyOwnerTicket", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "verifyOwnerTicket(uint256,uint8,bytes32,bytes32)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value,methodCall.inputs[ 3 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "account", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isPauser", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isPauser(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "id", value: random.range( maxRandom )}], name: "getHashExchangeState", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getHashExchangeState(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "index", value: random.range( maxRandom )}], name: "tokenByIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenByIndex(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_ticketFlag", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_ticketFlag()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tokenId", value: random.range( maxRandom )}], name: "ownerOf", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerOf(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_rareAddCount", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_rareAddCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_normalPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_normalPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_legendaryAddCount", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_legendaryAddCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "_ticketMap", outputs: [{name: "ticketType", type: "uint8"}, {name: "ticketFlag", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_ticketMap(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_curTicketId", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_curTicketId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_legendaryPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_legendaryPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tokenId", value: random.range( maxRandom )}], name: "tokenURI", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenURI(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_sellNormalTicketCount", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_sellNormalTicketCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_baseAddRatio", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_baseAddRatio()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isApprovedForAll(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_rareTicketCount", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_rareTicketCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "ticketId", value: random.range( maxRandom )}], name: "getTicketInfo", outputs: [{name: "ticketType", type: "uint8"}, {name: "ticketFlag", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTicketInfo(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "ITTicket", function( accounts ) {

	it( "TEST: ITTicket(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6805861", timeStamp: "1543659288", hash: "0x78fee91b1f70629bb1ec59d9dd94bdfcdda0fd467bb339dba16626737ffe8b1c", nonce: "7", blockHash: "0x03bbf734670ea848633ad9c411f1c9c281a00468bbed19203f4a56a0c3e023ef", transactionIndex: "50", from: "0xe8478559f5c775bc1d25e636186d90faac5fdbd4", to: 0, value: "0", gas: "3128560", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1e60d595", contractAddress: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", cumulativeGasUsed: "5546434", gasUsed: "3128560", confirmations: "878149"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "ITTicket", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = ITTicket.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1543659288 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = ITTicket.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "PauserAdded", type: "event"} ;
		console.error( "eventCallOriginal[0,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PauserAdded", events: [{name: "account", type: "address", value: "0xe8478559f5c775bc1d25e636186d90faac5fdbd4"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[0,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "account", type: "address"}], name: "AdminAdded", type: "event"} ;
		console.error( "eventCallOriginal[0,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AdminAdded", events: [{name: "account", type: "address", value: "0xe8478559f5c775bc1d25e636186d90faac5fdbd4"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[0,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"} ;
		console.error( "eventCallOriginal[0,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnershipTransferred", events: [{name: "previousOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0xe8478559f5c775bc1d25e636186d90faac5fdbd4"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[0,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "5403672350936000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"1\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6805894", timeStamp: "1543659720", hash: "0x27ff17fbbc748f067cfc59da686acbadf5862d4a95aba5c40e239ecf65d20404", nonce: "7", blockHash: "0xd3a8fc42ffcd1ab0a9907b3ed47a52ad1b5d584ed90e00abf60c70ed4baf09b2", transactionIndex: "51", from: "0x5970f4872b41c5532a930e69d5363e9c2241f3c6", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "294468", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3733120", gasUsed: "196312", confirmations: "878116"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "1"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "1", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1543659720 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[1,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "1"}, {name: "owner", type: "address", value: "0x5970f4872b41c5532a930e69d5363e9c2241f3c6"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[1,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x5970f4872b41c5532a930e69d5363e9c2241f3c6"}, {name: "tokenId", type: "uint256", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[1,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "651279446103085674" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6816843", timeStamp: "1543816867", hash: "0x02c42409577ea54fc5d2821a15adff2822525020fb5fbf579784f13b035ef2ab", nonce: "8", blockHash: "0x2d74a08d2ff398277912075ac7c81c6a601ac91604a0fe5abadca66442a39b76", transactionIndex: "61", from: "0xa07e04f54cb79558863906b3e96d4298ec63296e", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "1000000000000000000", gas: "294631", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "4975009", gasUsed: "196421", confirmations: "867167"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "3"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1543816867 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[2,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xa07e04f54cb79558863906b3e96d4298ec63296e"}, {name: "ticket_type", type: "uint8", value: "3"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[2,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xa07e04f54cb79558863906b3e96d4298ec63296e"}, {name: "tokenId", type: "uint256", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[2,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "34814372400000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816843", timeStamp: "1543816867", hash: "0x575c9be9c3f9f71b12386a450c26eec78d00915f3cd9071e80343ec0d553802f", nonce: "45", blockHash: "0x2d74a08d2ff398277912075ac7c81c6a601ac91604a0fe5abadca66442a39b76", transactionIndex: "63", from: "0xbdaacea6a70baba0d51cf17ba81c24372f47d2a7", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5209170", gasUsed: "196380", confirmations: "867167"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1543816867 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[3,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xbdaacea6a70baba0d51cf17ba81c24372f47d2a7"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[3,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xbdaacea6a70baba0d51cf17ba81c24372f47d2a7"}, {name: "tokenId", type: "uint256", value: "3"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[3,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "6359171555174527" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6816843", timeStamp: "1543816867", hash: "0xd8c7ce3646dbdccfa24f46c4b6664832ef06c012ee2a798d1dfe6f4a5d642140", nonce: "0", blockHash: "0x2d74a08d2ff398277912075ac7c81c6a601ac91604a0fe5abadca66442a39b76", transactionIndex: "65", from: "0xbb8d11436850ae2abaea86ff4c83c79de7ccb9cf", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "1000000000000000000", gas: "294631", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "5460402", gasUsed: "196421", confirmations: "867167"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "3"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543816867 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xbb8d11436850ae2abaea86ff4c83c79de7ccb9cf"}, {name: "ticket_type", type: "uint8", value: "3"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xbb8d11436850ae2abaea86ff4c83c79de7ccb9cf"}, {name: "tokenId", type: "uint256", value: "4"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[4,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "23240806000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816843", timeStamp: "1543816867", hash: "0x61c8de0523b3560fe6b384e9f7af6f9fb137bd49839c8a03b9548af826069f83", nonce: "3408", blockHash: "0x2d74a08d2ff398277912075ac7c81c6a601ac91604a0fe5abadca66442a39b76", transactionIndex: "66", from: "0x9e315e9701908501f6dc68a2af6e28a20c75d970", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5656782", gasUsed: "196380", confirmations: "867167"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1543816867 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "tokenId", type: "uint256", value: "5"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[5,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "420584935162692320" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6816843", timeStamp: "1543816867", hash: "0xc8be70143edbca3028f0f962fafe632ef19fd4d5393491eb664c75a86fedf81a", nonce: "48", blockHash: "0x2d74a08d2ff398277912075ac7c81c6a601ac91604a0fe5abadca66442a39b76", transactionIndex: "73", from: "0x4ca0c81f6e594ac83c54584a49a3760cadc42423", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "1000000000000000000", gas: "294631", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "6195763", gasUsed: "196421", confirmations: "867167"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "3"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1543816867 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x4ca0c81f6e594ac83c54584a49a3760cadc42423"}, {name: "ticket_type", type: "uint8", value: "3"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x4ca0c81f6e594ac83c54584a49a3760cadc42423"}, {name: "tokenId", type: "uint256", value: "6"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[6,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "875421569000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816843", timeStamp: "1543816867", hash: "0xc71fff88e4d4e8390fa590b90315db13c3001f56d81f0db4493a25bc2119e548", nonce: "128", blockHash: "0x2d74a08d2ff398277912075ac7c81c6a601ac91604a0fe5abadca66442a39b76", transactionIndex: "77", from: "0xd706edca0b5d34d2db3acf92137fb28c97929d87", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6507770", gasUsed: "196380", confirmations: "867167"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543816867 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xd706edca0b5d34d2db3acf92137fb28c97929d87"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd706edca0b5d34d2db3acf92137fb28c97929d87"}, {name: "tokenId", type: "uint256", value: "7"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[7,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "415111622053638256" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816843", timeStamp: "1543816867", hash: "0xf81e635139644ae263ba84f6b134d6d61f7620fa91caaeac2bde7a75ad4e1d90", nonce: "0", blockHash: "0x2d74a08d2ff398277912075ac7c81c6a601ac91604a0fe5abadca66442a39b76", transactionIndex: "101", from: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7562773", gasUsed: "196380", confirmations: "867167"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1543816867 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "tokenId", type: "uint256", value: "8"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[8,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "10549826510320238" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816844", timeStamp: "1543816873", hash: "0xf3dd49efa43e4be6ed76bf7905fd310950ceceaa05a9a44cfe73775c533c4046", nonce: "79", blockHash: "0xf9daef3c9b477bbe37d31c40ffdccb6ddfd2a9fa8af5b1b9d074baae34b73099", transactionIndex: "101", from: "0x05935b37d38d374f4d27e63dc7df2c8ce687b0ec", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "3781855", gasUsed: "196380", confirmations: "867166"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543816873 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x05935b37d38d374f4d27e63dc7df2c8ce687b0ec"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x05935b37d38d374f4d27e63dc7df2c8ce687b0ec"}, {name: "tokenId", type: "uint256", value: "9"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[9,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "67742540374546232" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816844", timeStamp: "1543816873", hash: "0x8f6f4e99e3f819343d07af626731129d6bd64f8b53ec6d2f3ab81586863d0e9a", nonce: "0", blockHash: "0xf9daef3c9b477bbe37d31c40ffdccb6ddfd2a9fa8af5b1b9d074baae34b73099", transactionIndex: "133", from: "0x258e2eda1e6f554813c65b2fb1a11a003b8c8629", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7755752", gasUsed: "196380", confirmations: "867166"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1543816873 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[10,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x258e2eda1e6f554813c65b2fb1a11a003b8c8629"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[10,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x258e2eda1e6f554813c65b2fb1a11a003b8c8629"}, {name: "tokenId", type: "uint256", value: "10"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[10,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "970860000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6816845", timeStamp: "1543816906", hash: "0x92dcf557158abe9755f648b392fa6b420567a21bff48ef7935e2d610f883facb", nonce: "3409", blockHash: "0xaaaf28685a63429319cea1dbc7adf532e44cb5a2c77d715ef039c2ce888e61d8", transactionIndex: "86", from: "0x9e315e9701908501f6dc68a2af6e28a20c75d970", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "1000000000000000000", gas: "294631", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "5252318", gasUsed: "181421", confirmations: "867165"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "3"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1543816906 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "ticket_type", type: "uint8", value: "3"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "tokenId", type: "uint256", value: "11"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[11,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "420584935162692320" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816849", timeStamp: "1543816989", hash: "0xf98bc2929f22583e179935eef9a5945d97090da4b4af1f3f20748cc0f5bd8904", nonce: "277", blockHash: "0x95e277cf9b2b89046869bba0fee94a2794f2a276f17f5378e2ee2df29756cf31", transactionIndex: "50", from: "0x72d0ed985bd3ff775bead61747cc55f6c260c639", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4879508", gasUsed: "196380", confirmations: "867161"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1543816989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x72d0ed985bd3ff775bead61747cc55f6c260c639"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x72d0ed985bd3ff775bead61747cc55f6c260c639"}, {name: "tokenId", type: "uint256", value: "12"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[12,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "236475071600173542" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816849", timeStamp: "1543816989", hash: "0xec01b93da6caf5edc66e6f6fc5ebdb87a15a0e637de15d3f0706ce8b5041fb26", nonce: "60", blockHash: "0x95e277cf9b2b89046869bba0fee94a2794f2a276f17f5378e2ee2df29756cf31", transactionIndex: "51", from: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5075888", gasUsed: "196380", confirmations: "867161"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1543816989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "tokenId", type: "uint256", value: "13"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[13,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "20008100768623730" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6816849", timeStamp: "1543816989", hash: "0xc00cda126c18be4c2b755f1399c798fbfe96073b96380d902210ec983ee53bb9", nonce: "0", blockHash: "0x95e277cf9b2b89046869bba0fee94a2794f2a276f17f5378e2ee2df29756cf31", transactionIndex: "52", from: "0xd0877ba727251ee13e90881b285a792ba8b746e5", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "1000000000000000000", gas: "294631", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "5272309", gasUsed: "196421", confirmations: "867161"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "3"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1543816989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xd0877ba727251ee13e90881b285a792ba8b746e5"}, {name: "ticket_type", type: "uint8", value: "3"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd0877ba727251ee13e90881b285a792ba8b746e5"}, {name: "tokenId", type: "uint256", value: "14"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[14,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1495020000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816849", timeStamp: "1543816989", hash: "0x6f888f7552ffd823253bb30f616e122e60006f0001c13b6fd7afd864155521a9", nonce: "0", blockHash: "0x95e277cf9b2b89046869bba0fee94a2794f2a276f17f5378e2ee2df29756cf31", transactionIndex: "60", from: "0xb5ef960812768903596dc0c21c9ea52d15ab8472", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5894577", gasUsed: "196380", confirmations: "867161"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1543816989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xb5ef960812768903596dc0c21c9ea52d15ab8472"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb5ef960812768903596dc0c21c9ea52d15ab8472"}, {name: "tokenId", type: "uint256", value: "15"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[15,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3422224000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816849", timeStamp: "1543816989", hash: "0xdad30513eec22ac340976733b5dbbd961729f7713f9779a17883fe84614028c2", nonce: "1", blockHash: "0x95e277cf9b2b89046869bba0fee94a2794f2a276f17f5378e2ee2df29756cf31", transactionIndex: "76", from: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7230343", gasUsed: "181380", confirmations: "867161"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1543816989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "tokenId", type: "uint256", value: "16"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[16,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "10549826510320238" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6816849", timeStamp: "1543816989", hash: "0x806102f4095fde1f0864219eb1cadbace3c0b8b75f51fe7741b99b7526ecdd05", nonce: "9", blockHash: "0x95e277cf9b2b89046869bba0fee94a2794f2a276f17f5378e2ee2df29756cf31", transactionIndex: "77", from: "0xa07e04f54cb79558863906b3e96d4298ec63296e", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "1000000000000000000", gas: "294631", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "7411764", gasUsed: "181421", confirmations: "867161"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "3"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1543816989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xa07e04f54cb79558863906b3e96d4298ec63296e"}, {name: "ticket_type", type: "uint8", value: "3"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xa07e04f54cb79558863906b3e96d4298ec63296e"}, {name: "tokenId", type: "uint256", value: "17"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[17,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "34814372400000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6816849", timeStamp: "1543816989", hash: "0x4b5a8d2786b02e919a30afba1f1eebf661edc49af2f267054bf50e1a003dc78d", nonce: "49", blockHash: "0x95e277cf9b2b89046869bba0fee94a2794f2a276f17f5378e2ee2df29756cf31", transactionIndex: "81", from: "0x4ca0c81f6e594ac83c54584a49a3760cadc42423", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "1000000000000000000", gas: "294631", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "7736226", gasUsed: "181421", confirmations: "867161"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "3"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1543816989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x4ca0c81f6e594ac83c54584a49a3760cadc42423"}, {name: "ticket_type", type: "uint8", value: "3"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x4ca0c81f6e594ac83c54584a49a3760cadc42423"}, {name: "tokenId", type: "uint256", value: "18"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[18,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "875421569000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"105\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816850", timeStamp: "1543817004", hash: "0x85cbde053b36a63d044238649eafc061fb289bd040bf5c74e2ada0580272e24a", nonce: "283", blockHash: "0x6c77ba294dd6e81a55da6218921736363a821d81003a87ba89f200e80b4c6af4", transactionIndex: "80", from: "0x03c4dcdbd7efc4fd32e2c0e92d4e1f8b778e1a56", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294666", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000690000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4448516", gasUsed: "196444", confirmations: "867160"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "105"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "105", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1543817004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "105"}, {name: "owner", type: "address", value: "0x03c4dcdbd7efc4fd32e2c0e92d4e1f8b778e1a56"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x03c4dcdbd7efc4fd32e2c0e92d4e1f8b778e1a56"}, {name: "tokenId", type: "uint256", value: "19"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[19,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "119481884745549651" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816850", timeStamp: "1543817004", hash: "0x13b5c12845cef4cf2ddd8d84db5522e31d4e1824e66b376beed1270712d03d79", nonce: "19", blockHash: "0x6c77ba294dd6e81a55da6218921736363a821d81003a87ba89f200e80b4c6af4", transactionIndex: "87", from: "0x4b81d0733362594915ffd1f1bace83576f276deb", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "294372", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4934249", gasUsed: "196248", confirmations: "867160"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1543817004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x4b81d0733362594915ffd1f1bace83576f276deb"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x4b81d0733362594915ffd1f1bace83576f276deb"}, {name: "tokenId", type: "uint256", value: "20"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[20,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "651985236651080721" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816850", timeStamp: "1543817004", hash: "0xccee52741d61de516ab50bda61766c7bc078caeed0b1eb469987e9a945f86079", nonce: "0", blockHash: "0x6c77ba294dd6e81a55da6218921736363a821d81003a87ba89f200e80b4c6af4", transactionIndex: "94", from: "0xd5b7cb57a6b1d95ac509c4ab1b44b9ebef8f01f7", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "294372", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5506113", gasUsed: "196248", confirmations: "867160"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1543817004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xd5b7cb57a6b1d95ac509c4ab1b44b9ebef8f01f7"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd5b7cb57a6b1d95ac509c4ab1b44b9ebef8f01f7"}, {name: "tokenId", type: "uint256", value: "21"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[21,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "16937688000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6816850", timeStamp: "1543817004", hash: "0x67667dc860019c27cf2cb90295f1b9546b4c718da0a0f9db3eae8ac612fbabdb", nonce: "129", blockHash: "0x6c77ba294dd6e81a55da6218921736363a821d81003a87ba89f200e80b4c6af4", transactionIndex: "112", from: "0xd706edca0b5d34d2db3acf92137fb28c97929d87", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "1000000000000000000", gas: "272131", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "6572703", gasUsed: "181421", confirmations: "867160"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "3"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1543817004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xd706edca0b5d34d2db3acf92137fb28c97929d87"}, {name: "ticket_type", type: "uint8", value: "3"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd706edca0b5d34d2db3acf92137fb28c97929d87"}, {name: "tokenId", type: "uint256", value: "22"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[22,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "415111622053638256" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816852", timeStamp: "1543817051", hash: "0x7b5fc6d1560cad728d96b1a1fb9eab0909eec2503481fb33059c962971c7983b", nonce: "278", blockHash: "0x2ca17e444d0a6d45382a54ba46a570dcbc0e8f34eacab0f6fb1fbb2d86922c99", transactionIndex: "118", from: "0x72d0ed985bd3ff775bead61747cc55f6c260c639", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "294372", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6433091", gasUsed: "181248", confirmations: "867158"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1543817051 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x72d0ed985bd3ff775bead61747cc55f6c260c639"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x72d0ed985bd3ff775bead61747cc55f6c260c639"}, {name: "tokenId", type: "uint256", value: "23"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[23,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "236475071600173542" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816852", timeStamp: "1543817051", hash: "0x84f85a2ff3c71d9b34dab36dfe8122b7cd04f7de29387d4c2abda96e284f1737", nonce: "80", blockHash: "0x2ca17e444d0a6d45382a54ba46a570dcbc0e8f34eacab0f6fb1fbb2d86922c99", transactionIndex: "127", from: "0x05935b37d38d374f4d27e63dc7df2c8ce687b0ec", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "7285193", gasUsed: "181380", confirmations: "867158"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1543817051 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x05935b37d38d374f4d27e63dc7df2c8ce687b0ec"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x05935b37d38d374f4d27e63dc7df2c8ce687b0ec"}, {name: "tokenId", type: "uint256", value: "24"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[24,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "67742540374546232" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816853", timeStamp: "1543817062", hash: "0x58ee93b20b75848f7d7de2c9aa16a98bde695eb02252382721f9efaf95e00f13", nonce: "1", blockHash: "0xfad262ca18861376bb7a6c3d019e0241ca8302ee8b0d78085780a7ba8506c80a", transactionIndex: "61", from: "0xd0877ba727251ee13e90881b285a792ba8b746e5", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "294372", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2863109", gasUsed: "181248", confirmations: "867157"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1543817062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xd0877ba727251ee13e90881b285a792ba8b746e5"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd0877ba727251ee13e90881b285a792ba8b746e5"}, {name: "tokenId", type: "uint256", value: "25"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[25,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1495020000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816853", timeStamp: "1543817062", hash: "0x343edadc2bd6eee468a6c54c91fc468c1f24054778e49210cbe3559795e93ce6", nonce: "2", blockHash: "0xfad262ca18861376bb7a6c3d019e0241ca8302ee8b0d78085780a7ba8506c80a", transactionIndex: "62", from: "0xd0877ba727251ee13e90881b285a792ba8b746e5", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "3044489", gasUsed: "181380", confirmations: "867157"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1543817062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xd0877ba727251ee13e90881b285a792ba8b746e5"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd0877ba727251ee13e90881b285a792ba8b746e5"}, {name: "tokenId", type: "uint256", value: "26"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[26,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1495020000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816853", timeStamp: "1543817062", hash: "0x50d025b68a4eb58dbd98f3c4815c5ff19c17757b1dfc862e5f6c49e3bf08f962", nonce: "2", blockHash: "0xfad262ca18861376bb7a6c3d019e0241ca8302ee8b0d78085780a7ba8506c80a", transactionIndex: "67", from: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "294372", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3528709", gasUsed: "181248", confirmations: "867157"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1543817062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[27,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[27,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "tokenId", type: "uint256", value: "27"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[27,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "10549826510320238" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816853", timeStamp: "1543817062", hash: "0xf7fd53f95b6e65592eaa4cb704dfe254081040acdd8c17023c5801270f7ef105", nonce: "3", blockHash: "0xfad262ca18861376bb7a6c3d019e0241ca8302ee8b0d78085780a7ba8506c80a", transactionIndex: "68", from: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "294372", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3709957", gasUsed: "181248", confirmations: "867157"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1543817062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "tokenId", type: "uint256", value: "28"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[28,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "10549826510320238" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816853", timeStamp: "1543817062", hash: "0x67de7846a4ff2edc13b657099e7d3c2fbdf46fc38c53635f8afd95b6ae9bee8c", nonce: "1", blockHash: "0xfad262ca18861376bb7a6c3d019e0241ca8302ee8b0d78085780a7ba8506c80a", transactionIndex: "74", from: "0xd5b7cb57a6b1d95ac509c4ab1b44b9ebef8f01f7", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "294372", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4062130", gasUsed: "181248", confirmations: "867157"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1543817062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xd5b7cb57a6b1d95ac509c4ab1b44b9ebef8f01f7"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd5b7cb57a6b1d95ac509c4ab1b44b9ebef8f01f7"}, {name: "tokenId", type: "uint256", value: "29"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[29,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "16937688000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6816853", timeStamp: "1543817062", hash: "0x1cb5d19e73b507d7bf79db7f9c5e6d0bc479dbd1bc9fa8f7b973d04a38c1d266", nonce: "50", blockHash: "0xfad262ca18861376bb7a6c3d019e0241ca8302ee8b0d78085780a7ba8506c80a", transactionIndex: "89", from: "0x4ca0c81f6e594ac83c54584a49a3760cadc42423", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "1000000000000000000", gas: "294631", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "5854658", gasUsed: "181421", confirmations: "867157"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "3"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1543817062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x4ca0c81f6e594ac83c54584a49a3760cadc42423"}, {name: "ticket_type", type: "uint8", value: "3"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x4ca0c81f6e594ac83c54584a49a3760cadc42423"}, {name: "tokenId", type: "uint256", value: "30"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[30,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "875421569000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816853", timeStamp: "1543817062", hash: "0x7697762cde514b3743d41984ccf634a5eff13ebbde58cb73bf9e5405dc7316fd", nonce: "130", blockHash: "0xfad262ca18861376bb7a6c3d019e0241ca8302ee8b0d78085780a7ba8506c80a", transactionIndex: "95", from: "0xd706edca0b5d34d2db3acf92137fb28c97929d87", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "272070", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6250734", gasUsed: "181380", confirmations: "867157"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1543817062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xd706edca0b5d34d2db3acf92137fb28c97929d87"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd706edca0b5d34d2db3acf92137fb28c97929d87"}, {name: "tokenId", type: "uint256", value: "31"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[31,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "415111622053638256" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816853", timeStamp: "1543817062", hash: "0xe6189e0497a182ba331d6293f659dcc924b930c1f7bb219cb96e85bd7f70e05d", nonce: "61", blockHash: "0xfad262ca18861376bb7a6c3d019e0241ca8302ee8b0d78085780a7ba8506c80a", transactionIndex: "110", from: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "271872", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7177251", gasUsed: "181248", confirmations: "867157"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1543817062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "tokenId", type: "uint256", value: "32"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[32,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "20008100768623730" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816855", timeStamp: "1543817087", hash: "0xa3f71e514b0d54f454eb4e6b2455e82fc42447bd1089e177df22b763bf75397b", nonce: "62", blockHash: "0x7ab6d0fa9892a0c2a439b2fa6ecda4e2c24e27e594b2133a7b2927b22502db77", transactionIndex: "36", from: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "271872", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6659051", gasUsed: "181248", confirmations: "867155"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1543817087 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "tokenId", type: "uint256", value: "33"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[33,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "20008100768623730" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816855", timeStamp: "1543817087", hash: "0xd0ed457ffaf2ab0de2917f5c224f8fa75326e262caa59d3c71b08f2d13a7dfdb", nonce: "4", blockHash: "0x7ab6d0fa9892a0c2a439b2fa6ecda4e2c24e27e594b2133a7b2927b22502db77", transactionIndex: "41", from: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "271872", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7192653", gasUsed: "181248", confirmations: "867155"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1543817087 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "tokenId", type: "uint256", value: "34"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[34,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "10549826510320238" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816856", timeStamp: "1543817090", hash: "0xd490b36f5d38a14ee9fa3594f1f0a6a93f47dd54e251bd9369142f5a7fc89a84", nonce: "5", blockHash: "0x61d19f7df766da71eefab9d3f9a9f5dd933964a9e88f9c4cc519a3696b61e33e", transactionIndex: "113", from: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "271872", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5988699", gasUsed: "181248", confirmations: "867154"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1543817090 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "tokenId", type: "uint256", value: "35"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[35,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "10549826510320238" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816856", timeStamp: "1543817090", hash: "0x8884fc7d079e6f17c4ff59385f7d153a8a071a3a3d080ad8aedd480ae5afb1d6", nonce: "1", blockHash: "0x61d19f7df766da71eefab9d3f9a9f5dd933964a9e88f9c4cc519a3696b61e33e", transactionIndex: "132", from: "0x258e2eda1e6f554813c65b2fb1a11a003b8c8629", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "271872", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7526319", gasUsed: "181248", confirmations: "867154"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1543817090 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x258e2eda1e6f554813c65b2fb1a11a003b8c8629"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x258e2eda1e6f554813c65b2fb1a11a003b8c8629"}, {name: "tokenId", type: "uint256", value: "36"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[36,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "970860000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816862", timeStamp: "1543817157", hash: "0x6a7e57093373f6d9a6b0e809aa30b493c3e551e5aee1cc9e80d6e70374783f98", nonce: "0", blockHash: "0xf120a0cf59995a168ff87f211b7e32426affa6a88f41a3cd270bcef9b7eb5615", transactionIndex: "31", from: "0x0bb49a85306ee9aa24709b26ddaa30249cc21bac", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6279655", gasUsed: "196380", confirmations: "867148"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1543817157 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x0bb49a85306ee9aa24709b26ddaa30249cc21bac"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x0bb49a85306ee9aa24709b26ddaa30249cc21bac"}, {name: "tokenId", type: "uint256", value: "37"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[37,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "198625340000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6816862", timeStamp: "1543817157", hash: "0x96c9c8e17e56e86f7340a0e4fc5e7fce3fcbdf4b9bee0f73c939d4f0f6b76db1", nonce: "81", blockHash: "0xf120a0cf59995a168ff87f211b7e32426affa6a88f41a3cd270bcef9b7eb5615", transactionIndex: "33", from: "0x05935b37d38d374f4d27e63dc7df2c8ce687b0ec", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "1000000000000000000", gas: "272131", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "6499831", gasUsed: "181421", confirmations: "867148"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "3"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1543817157 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x05935b37d38d374f4d27e63dc7df2c8ce687b0ec"}, {name: "ticket_type", type: "uint8", value: "3"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x05935b37d38d374f4d27e63dc7df2c8ce687b0ec"}, {name: "tokenId", type: "uint256", value: "38"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[38,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "67742540374546232" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816863", timeStamp: "1543817169", hash: "0x7c48fd34b261ea9a847cdc641e804f8161102381d29b55d8be8bf25ba3eed0b5", nonce: "63", blockHash: "0x488dc2eee4ac8ef28ff5d0a01d352a73b0935898260bf843005b0d97c5aa2c73", transactionIndex: "113", from: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "272070", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5761386", gasUsed: "181380", confirmations: "867147"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1543817169 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[39,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[39,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "tokenId", type: "uint256", value: "39"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[39,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "20008100768623730" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816868", timeStamp: "1543817219", hash: "0x115bf43385efc1e7d4d1ff0f7d0964db6837eba9b1072f10a12609a067ef2291", nonce: "1", blockHash: "0x01a868ab3f0f4281554c31c2b60556f709873d5f5ba779e18e232d3ba2aa0a3d", transactionIndex: "39", from: "0xb5ef960812768903596dc0c21c9ea52d15ab8472", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "271872", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2731661", gasUsed: "181248", confirmations: "867142"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1543817219 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xb5ef960812768903596dc0c21c9ea52d15ab8472"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xb5ef960812768903596dc0c21c9ea52d15ab8472"}, {name: "tokenId", type: "uint256", value: "40"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[40,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3422224000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816869", timeStamp: "1543817234", hash: "0x30ac339ea0af04a65c87249367379406bdb206abf3626983238ce4981e3d0bfc", nonce: "6", blockHash: "0x61e8451621f45eb6d177c0848911c83981340b4520d59cfd47c3c6bcbfea2cb7", transactionIndex: "147", from: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "271872", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4835021", gasUsed: "181248", confirmations: "867141"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1543817234 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xe70f46db43085c4da54fe380ac04cb3955b50ab3"}, {name: "tokenId", type: "uint256", value: "41"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[41,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "10549826510320238" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816871", timeStamp: "1543817273", hash: "0x286dab75289c42bfa6057ab420301d92b0236c1444c15e5cfd09d4046b02f1e3", nonce: "64", blockHash: "0x91355a0323e8d9792e9677ee9aced936b4bb1795e4ffc012ffd40af7fa83bffa", transactionIndex: "88", from: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "271872", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4477690", gasUsed: "181248", confirmations: "867139"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1543817273 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "tokenId", type: "uint256", value: "42"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[42,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "20008100768623730" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816873", timeStamp: "1543817283", hash: "0xaeec9abc10e0bef0b4d31248c39f90d8a3049494e32b692b67768ab25262a5cb", nonce: "65", blockHash: "0x801dc52b70ddee6a133082fb24ebfdafb30fea410a027c67ca2f3d275ebb952a", transactionIndex: "82", from: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "271872", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4386849", gasUsed: "181248", confirmations: "867137"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1543817283 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "tokenId", type: "uint256", value: "43"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[43,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "20008100768623730" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816876", timeStamp: "1543817316", hash: "0x7cbf5712f5682c5272f6c8f87385373bde9092cff849cb61f27f8d338c332cc6", nonce: "66", blockHash: "0x4d98a12998bc37f99221eddf72fa0f855d23612e8efe6ac5962c923891a27168", transactionIndex: "38", from: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "271872", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1395992", gasUsed: "181248", confirmations: "867134"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1543817316 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x67b9ca1f543bf21d5de381c3319a551c22059eaa"}, {name: "tokenId", type: "uint256", value: "44"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[44,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "20008100768623730" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816882", timeStamp: "1543817382", hash: "0x74bdc005236e43698047f075a492c9f303fb6d2642d017fb853120debe658b28", nonce: "131", blockHash: "0xe59e5f2eaff85ea47b0504edad142b4cba8e8e37be818519b98e7c41388d7799", transactionIndex: "15", from: "0xd706edca0b5d34d2db3acf92137fb28c97929d87", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "271872", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1019414", gasUsed: "181248", confirmations: "867128"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1543817382 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xd706edca0b5d34d2db3acf92137fb28c97929d87"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xd706edca0b5d34d2db3acf92137fb28c97929d87"}, {name: "tokenId", type: "uint256", value: "45"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[45,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "415111622053638256" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816889", timeStamp: "1543817536", hash: "0xf550a7cd47e39102c2b050998d1524b1ebf0b97592dcd33418c1f50f18553b22", nonce: "1", blockHash: "0xd9c797e83ff8de6b8531a68c8aad3cabb8ebd373199faffa2c4067e9d6d54aaf", transactionIndex: "126", from: "0xbb8d11436850ae2abaea86ff4c83c79de7ccb9cf", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "271872", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5429413", gasUsed: "181248", confirmations: "867121"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1543817536 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0xbb8d11436850ae2abaea86ff4c83c79de7ccb9cf"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xbb8d11436850ae2abaea86ff4c83c79de7ccb9cf"}, {name: "tokenId", type: "uint256", value: "46"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[46,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "23240806000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"105\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6816897", timeStamp: "1543817606", hash: "0x3ec946c27dc7c3b852dd1885cae5561dab703de7452ad0f93b17b863df41c4a8", nonce: "284", blockHash: "0xc7ba925b32b902b0218711608a2609267b43236d6a82ad92fc9c9f951f14c73b", transactionIndex: "61", from: "0x03c4dcdbd7efc4fd32e2c0e92d4e1f8b778e1a56", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "10000000000000000", gas: "271968", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000690000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3091415", gasUsed: "181312", confirmations: "867113"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "105"}, {type: "uint8", name: "ticketType", value: "1"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "105", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1543817606 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "105"}, {name: "owner", type: "address", value: "0x03c4dcdbd7efc4fd32e2c0e92d4e1f8b778e1a56"}, {name: "ticket_type", type: "uint8", value: "1"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x03c4dcdbd7efc4fd32e2c0e92d4e1f8b778e1a56"}, {name: "tokenId", type: "uint256", value: "47"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[47,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "119481884745549651" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6816897", timeStamp: "1543817606", hash: "0x3a89def5aab7dafd074dddc536853679c1fd815c31dcc27f4b8e7844f8db27ea", nonce: "0", blockHash: "0xc7ba925b32b902b0218711608a2609267b43236d6a82ad92fc9c9f951f14c73b", transactionIndex: "66", from: "0x7d15b8d557e9f9123b9f7ee5d06087974b673ec0", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "100000000000000000", gas: "294570", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "3478976", gasUsed: "196380", confirmations: "867113"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "2"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1543817606 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "channelId", type: "uint8"}, {indexed: false, name: "owner", type: "address"}, {indexed: false, name: "ticket_type", type: "uint8"}], name: "BuyTicket", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BuyTicket", events: [{name: "channelId", type: "uint8", value: "0"}, {name: "owner", type: "address", value: "0x7d15b8d557e9f9123b9f7ee5d06087974b673ec0"}, {name: "ticket_type", type: "uint8", value: "2"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: true, name: "tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0x7d15b8d557e9f9123b9f7ee5d06087974b673ec0"}, {name: "tokenId", type: "uint256", value: "48"}], address: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13"}] ;
		console.error( "eventResultOriginal[48,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "832010654000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buyTicket( \"0\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6816900", timeStamp: "1543817676", hash: "0x44e0c75eff29b75d0767f1315cae48684ee0f28d5efaae985a6de9b731a97428", nonce: "51", blockHash: "0x703662ef91c98b826ae2467c74652d27e9d64130cde7820a4f5f21af5388c36b", transactionIndex: "73", from: "0x4ca0c81f6e594ac83c54584a49a3760cadc42423", to: "0x6b31a2ef5986d283332e4a3a608adb3c09ffdd13", value: "1000000000000000000", gas: "294631", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0x700662cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "5715964", gasUsed: "23101", confirmations: "867110"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "channelId", value: "0"}, {type: "uint8", name: "ticketType", value: "3"}], name: "buyTicket", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyTicket(uint8,uint8)" ]( "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1543817676 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "875421569000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "530000000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
