const DebtKernel = artifacts.require( "./DebtKernel.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "DebtKernel" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x8ef1351941d0CD8da09d5A4c74f2d64503031A18", "0xD4915e172a195f5F3e343A4196E8bdA3Fc94Aee8", "0x2f40766E91AAEE4794D3389AC8dc3a4B8FD7aB3e", "0xF7B3fC555C458c46d288ffD049dDBfb09f706df7", "0x9445d5dDc2D8A3663ce8cC9fE74009f99B343cfC", "0x2987Aa227df48D4891b3FE667C7A0c463F8857b1", "0xC1df9B92645CC3B6733992C692A39C34A86fAE5F", "0x601E6E7711B9E3B1b20e1e8016038a32DFc86DDD", "0x5De2538838B4EB7FA2dBDeA09d642b88546e5F20", "0x89d24A6b4CcB1B6fAA2625fE562bDD9a23260359", "0x51343C13216afBbC0202b824AD532bdda1e222A9", "0x431194c3e0f35bC7f1266ec6bb85E0c5eC554935", "0xE94327D07Fc17907b4DB788E5aDf2ed424adDff6", "0x24a7eaaD0D7F13d1999206D8C22f926980A12CA6", "0x9f8F72aA9304c8B593d555F12eF6589cC3A579A2", "0x800b7a428dfa0E7E478540FB06c07d0940414f25", "0xf230b790E05390FC8295F4d3F60332c93BEd42e2", "0xE08c5C6D17Be3aB837B421723e9215BB9902c9f1", "0x0006e4548AED4502ec8c844567840Ce6eF1013f5", "0x3605780992537dCaae52a8dA39238D6D883b7009", "0x0D8775F648430679A709E98d2b0Cb6250d2887EF", "0xE5A3412E37e04a4E4c83800eDa967a9e8468b75D", "0xB6d3D9bc0e8Ab251C0eb29bD7c0E53bf482B3093", "0x86Fa049857E0209aa7D9e616F7eb3b3B78ECfdb0", "0x31a3768FE55c5b8742b5287B62032F26369b96F5", "0x8940866A6D3Ceb7225853133A86a45692A2f42C5", "0xE41d2489571d322189246DaFA5ebDe1F4699F498", "0x69ff994f211aF3043EE490fa97796DBc4193dBC6", "0x0Bd09Dc09379664D35Add8f34933404D3e5895fb", "0xb4F6aE2cca59f0Ea3fB2559e32C61dF753Bb542A", "0x885949A79f83c4F5aD24945F3264f2A4c9c59a00", "0xf44a42cc7B25Dd3A6E07e6d7B0d4f492Ad749c56", "0x85847fD710fd3968b021be4A003A6af515d4c637", "0x9b34F1E9b15cA6f2A4513c90A5260102eB21bec8", "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", "0x4D5B082Fc164a7BF38FaB4b133C1e8f3D438D406", "0x4aA6df8a00e84B11d652f959ea22D9Af62573709", "0xFAF95953A36eD1e8f8426Ab5B7EB53dA246e3476", "0x4056F3f55c338e22330002924023025DF61a9D3b", "0x0c81D7d494faCFBa3eFE7A3030755Fc2249EA983", "0x2958DB51a0b4c458d0aa183E8cFB4f2E95cf6E75", "0x0678c3827Fb20c6883b1Ee9D243fDDCF0D0bC271", "0xD850942eF8811f2A866692A623011bDE52a462C1", "0x262bA400bB2cF20FAB04262b5a60EB8e6EEBc7b2", "0xD05955436368c9659b7a1bDF8F0427Ca8c193b11", "0xb877ddBcB49A44E0Bdd5659326dE9678a84a3182", "0xD51576e9df69e2e13ACB2066eB8Ec53acD9a3c9e", "0x9AbDefBAbE7F459186b5cd58D17371B2e02AC8f8", "0x577a5B3bf1d36c4280A1c0d9c4513De48FB7ab2e", "0x00F34Ad48A326b406bf995E04189e42D285d5773", "0x0be81F52642969952D470bbE0F50de78D1b3D085", "0x6622E301f757BBaEc6cfB34C03338DA4358D94DA", "0x1ce3d14fb814ad1df000A26486C274496681B363", "0xA2e112E4D1E50568109136D66d68121Deeb25F09", "0xB78a7D1c1D03Cf9155cC522097CBc679E15cF9a3", "0xB8c77482e45F1F44dE1745F52C74426C631bDD52", "0x25763B7f6248bF02E269038C58726460851dC65d"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "bytes32"}], name: "debtOrderCancelled", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "issuanceCancelled", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "TOKEN_TRANSFER_PROXY", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "NULL_ISSUANCE_HASH", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "EXTERNAL_QUERY_GAS_LIMIT", outputs: [{name: "", type: "uint16"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "debtToken", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: true, name: "_cancelledBy", type: "address"}], name: "LogIssuanceCancelled", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_debtOrderHash", type: "bytes32"}, {indexed: true, name: "_cancelledBy", type: "address"}], name: "LogDebtOrderCancelled", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_errorId", type: "uint8"}, {indexed: true, name: "_orderHash", type: "bytes32"}], name: "LogError", type: "event"}, {anonymous: false, inputs: [], name: "Pause", type: "event"}, {anonymous: false, inputs: [], name: "Unpause", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogDebtOrderFilled(bytes32,uint256,address,address,uint256,address,uint256)", "LogIssuanceCancelled(bytes32,address)", "LogDebtOrderCancelled(bytes32,address)", "LogError(uint8,bytes32)", "Pause()", "Unpause()", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x4d61b488582cd44b5157ec41d5a9cfcc0595cc347661eda1d84cc40d7e943fb3", "0x77b488cc12f7f1c1527489c59889ce053dfc7115033f9b5d147fd7a8bdbc3a47", "0x781502ecbc7096cfe7d502e0027f02eedf4ce6d62162cd3bd45d1a3dd98b8c23", "0x36d86c59e00bd73dc19ba3adfe068e4b64ac7e92be35546adeddf1b956a87e90", "0x6985a02210a168e66602d3235cb6db0e70f92b3ba4d376a33c0f3d9434bff625", "0x7805862f689e2f13df9f062ff482ad3ad112aca9e0847911ed832e158c525b33", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 5655950 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 5804697 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "tokenTransferProxyAddress", value: 4}], name: "DebtKernel", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "debtOrderCancelled", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "debtOrderCancelled(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "issuanceCancelled", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "issuanceCancelled(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "TOKEN_TRANSFER_PROXY", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "TOKEN_TRANSFER_PROXY()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "NULL_ISSUANCE_HASH", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "NULL_ISSUANCE_HASH()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "EXTERNAL_QUERY_GAS_LIMIT", outputs: [{name: "", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "EXTERNAL_QUERY_GAS_LIMIT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "debtToken", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "debtToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "DebtKernel", function( accounts ) {

	it( "TEST: DebtKernel( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "5655950", timeStamp: "1526968596", hash: "0x00b0969fe1180a7238465b5184d4757df1273e6cccfe6aac5696db4c8fcf79c0", nonce: "67", blockHash: "0x86c6cbee7094690a838b2928755771e84bb1ad5c688629684587a8e273ef4471", transactionIndex: "50", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: 0, value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x2a1dc96e0000000000000000000000002f40766e91aaee4794d3389ac8dc3a4b8fd7ab3e", contractAddress: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", cumulativeGasUsed: "4446020", gasUsed: "2724693", confirmations: "2080635"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenTransferProxyAddress", value: addressList[4]}], name: "DebtKernel", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = DebtKernel.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1526968596 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = DebtKernel.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setDebtToken( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "5656025", timeStamp: "1526969724", hash: "0x8ddccfd3b80123adbb87ee9d64646fc0eb3d87b4431fbccaceafbee7b3504c7f", nonce: "128", blockHash: "0x35a9b80e7f0bf37b4d583fd23794d95829a747a680f189a0d1b82e8516d6b631", transactionIndex: "6", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x9b345d75000000000000000000000000f7b3fc555c458c46d288ffd049ddbfb09f706df7", contractAddress: "", cumulativeGasUsed: "466126", gasUsed: "43569", confirmations: "2080560"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "debtTokenAddress", value: addressList[5]}], name: "setDebtToken", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDebtToken(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1526969724 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: transferOwnership( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "5656062", timeStamp: "1526970157", hash: "0x614d7df01b46e929447e3a56b527c2c7bb9ae26355f17c1bc4c9ffc892915d5c", nonce: "134", blockHash: "0xf87089f19a7e723fe3c8e13241b8ea87509273c1be0c19e2d855e44b3d5cea3f", transactionIndex: "3", from: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "4000000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0xf2fde38b0000000000000000000000009445d5ddc2d8a3663ce8cc9fe74009f99b343cfc", contractAddress: "", cumulativeGasUsed: "99148", gasUsed: "30504", confirmations: "2080523"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newOwner", value: addressList[6]}], name: "transferOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferOwnership(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1526970157 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"} ;
		console.error( "eventCallOriginal[2,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnershipTransferred", events: [{name: "previousOwner", type: "address", value: "0xd4915e172a195f5f3e343a4196e8bda3fc94aee8"}, {name: "newOwner", type: "address", value: "0x9445d5ddc2d8a3663ce8cc9fe74009f99b343cfc"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[2,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[7], [addressList[8],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5658723", timeStamp: "1527011536", hash: "0x2d33675e5ed8533ef75bea7d4837f5b4cd6a34a92bf4cb26a9a910b572702924", nonce: "36", blockHash: "0xd66ada88531c7342f374181a9e049051b2a0ff96237295254a14a17e900dab23", transactionIndex: "16", from: "0x2987aa227df48d4891b3fe667c7a0c463f8857b1", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000002987aa227df48d4891b3fe667c7a0c463f8857b1000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000601e6e7711b9e3b1b20e1e8016038a32dfc86ddd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001a055690d9db800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2be4630200000001a055690d9db80000009c40000020a000000033590a6584f2000001000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000cad1bad804a5e596f9fe8c7dcfefd1ced633349967614051795dec5ebab5164f0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000076dd4d9c14fe2120ff7e8a879173da990692e8fd13d7703a0fac55566cb7e17500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3415020", gasUsed: "496106", confirmations: "2077862"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[7]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[9],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","30000000000000000000","0","0","0","0","1529603171"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x0200000001a055690d9db80000009c40000020a000000033590a6584f2000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xcad1bad804a5e596f9fe8c7dcfefd1ced633349967614051795dec5ebab5164f","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x76dd4d9c14fe2120ff7e8a879173da990692e8fd13d7703a0fac55566cb7e175","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[7], [addressList[8],addressList[9],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","30000000000000000000","0","0","0","0","1529603171"], ["0x0200000001a055690d9db80000009c40000020a000000033590a6584f2000001"], ["27","0","0"], ["0xcad1bad804a5e596f9fe8c7dcfefd1ced633349967614051795dec5ebab5164f","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x76dd4d9c14fe2120ff7e8a879173da990692e8fd13d7703a0fac55566cb7e175","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1527011536 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x0104f89e91c554760fc83ca5ca02f7b2fc13b99e105522c286b7b3615ffa0cb1"}, {name: "_principal", type: "uint256", value: "30000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[12], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5659104", timeStamp: "1527017489", hash: "0x3a418cdfc3e1c9935960f1bcee03d56f4e1ed82ba23a59eab05aecc28920b577", nonce: "49", blockHash: "0x768a39b9157c698c1378682655a3b2bc134ec926e5d17ddac19e68a7671f930a", transactionIndex: "37", from: "0x51343c13216afbbc0202b824ad532bdda1e222a9", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc900000000000000000000000051343c13216afbbc0202b824ad532bdda1e222a9000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000431194c3e0f35bc7f1266ec6bb85e0c5ec55493500000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff60000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2bfa3f00000000000de0b6b3a76400000003e80000a03000000000f8b0a10e47000001000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000f633102de8a9a2e5fc5eb05d2df9bc8a0e33ec8505742f8d676d12335e4a193e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000156ec6eb674e7f72188e691c9b15ac9707e9490c71ccc1a6e072c0cc11944e7b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1920996", gasUsed: "479884", confirmations: "2077481"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[12]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[13],addressList[0],addressList[10],addressList[14],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","1000000000000000000","0","0","0","0","1529608767"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x00000000000de0b6b3a76400000003e80000a03000000000f8b0a10e47000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xf633102de8a9a2e5fc5eb05d2df9bc8a0e33ec8505742f8d676d12335e4a193e","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x156ec6eb674e7f72188e691c9b15ac9707e9490c71ccc1a6e072c0cc11944e7b","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[12], [addressList[8],addressList[13],addressList[0],addressList[10],addressList[14],addressList[0]], ["0","0","1000000000000000000","0","0","0","0","1529608767"], ["0x00000000000de0b6b3a76400000003e80000a03000000000f8b0a10e47000001"], ["28","0","0"], ["0xf633102de8a9a2e5fc5eb05d2df9bc8a0e33ec8505742f8d676d12335e4a193e","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x156ec6eb674e7f72188e691c9b15ac9707e9490c71ccc1a6e072c0cc11944e7b","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1527017489 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0xeba7db1ca70af364a4c4125c27109a62c4f63b565af28baa92b6b69cc552314a"}, {name: "_principal", type: "uint256", value: "1000000000000000000"}, {name: "_principalToken", type: "address", value: "0xe94327d07fc17907b4db788e5adf2ed424addff6"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "103657790655991222" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: cancelDebtOrder( [addressList[8],addressList[15],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5659183", timeStamp: "1527018805", hash: "0x1f38d16f2101400b15343d6f9a2242d78573e23b61f64420123348d60ebc7dd4", nonce: "320", blockHash: "0x298ecab8f3eed878daec1692c9b26ea68b71579882d457b1611a58fabe4068c1", transactionIndex: "17", from: "0x24a7eaad0d7f13d1999206d8c22f926980a12ca6", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x20385f2f000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f00000000000000000000000024a7eaad0d7f13d1999206d8c22f926980a12ca600000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f200000000000000000000000009f8f72aa9304c8b593d555f12ef6589cc3a579a2000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2bfcf50500000000016345785d8a00000027104000105000000002c68af0bb1400000a", contractAddress: "", cumulativeGasUsed: "669612", gasUsed: "57333", confirmations: "2077402"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[15],addressList[0],addressList[10],addressList[16],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","100000000000000000","0","0","0","0","1529609461"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x0500000000016345785d8a00000027104000105000000002c68af0bb1400000a"]}], name: "cancelDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelDebtOrder(address[6],uint256[8],bytes32[1])" ]( [addressList[8],addressList[15],addressList[0],addressList[10],addressList[16],addressList[0]], ["0","0","100000000000000000","0","0","0","0","1529609461"], ["0x0500000000016345785d8a00000027104000105000000002c68af0bb1400000a"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1527018805 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_debtOrderHash", type: "bytes32"}, {indexed: true, name: "_cancelledBy", type: "address"}], name: "LogDebtOrderCancelled", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogDebtOrderCancelled", events: [{name: "_debtOrderHash", type: "bytes32", value: "0x69e34406040ba4e68c4ee3ccf0f0c62aaa1046569dd2f9ed7a3a8c5264f99614"}, {name: "_cancelledBy", type: "address", value: "0x24a7eaad0d7f13d1999206d8c22f926980a12ca6"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "30354108124790198" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[17], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5659461", timeStamp: "1527023195", hash: "0x4ce00d18546037f7e177dcaa61d3e134a31ebe0895e9d44f6e3bbb36f8ed9778", nonce: "1", blockHash: "0x030db257232e610a052188da5631f85350d9243eb47d960cd136b0a98ca0f8d8", transactionIndex: "101", from: "0x800b7a428dfa0e7e478540fb06c07d0940414f25", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000800b7a428dfa0e7e478540fb06c07d0940414f25000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f00000000000000000000000051343c13216afbbc0202b824ad532bdda1e222a900000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000f230b790e05390fc8295f4d3f60332c93bed42e200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b2d05e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2bffc8080000000000000000b2d05e00004e202000103000000006f05b59d3b2000001000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000db1fd5d4e03dad28239269402292c3e4ec5bde4f6ed20d12496f9be296768249000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003663dd3acf28e91012487677f5f2f4651e10f981951d70f5c8f7085b5fb7b60a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6457552", gasUsed: "464489", confirmations: "2077124"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[17]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[12],addressList[0],addressList[10],addressList[18],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","3000000000","0","0","0","0","1529610184"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x080000000000000000b2d05e00004e202000103000000006f05b59d3b2000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xdb1fd5d4e03dad28239269402292c3e4ec5bde4f6ed20d12496f9be296768249","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x3663dd3acf28e91012487677f5f2f4651e10f981951d70f5c8f7085b5fb7b60a","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[17], [addressList[8],addressList[12],addressList[0],addressList[10],addressList[18],addressList[0]], ["0","0","3000000000","0","0","0","0","1529610184"], ["0x080000000000000000b2d05e00004e202000103000000006f05b59d3b2000001"], ["27","0","0"], ["0xdb1fd5d4e03dad28239269402292c3e4ec5bde4f6ed20d12496f9be296768249","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x3663dd3acf28e91012487677f5f2f4651e10f981951d70f5c8f7085b5fb7b60a","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1527023195 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x6e02b4fd31079e99797c0cdc717e51685cef566aa780951155383bdda87a8966"}, {name: "_principal", type: "uint256", value: "3000000000"}, {name: "_principalToken", type: "address", value: "0xf230b790e05390fc8295f4d3f60332c93bed42e2"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[19], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5659650", timeStamp: "1527026079", hash: "0x2544b36be068942a4c8a12478b19cf4743b437b1f981b085bfc65cdee56fe735", nonce: "5902", blockHash: "0x9ea82fb0baec5e9c2a209a84980108d9c02a60c1da91d5938ab4ce3a1db4d91c", transactionIndex: "26", from: "0xe08c5c6d17be3ab837b421723e9215bb9902c9f1", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000e08c5c6d17be3ab837b421723e9215bb9902c9f1000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000002987aa227df48d4891b3fe667c7a0c463f8857b100000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001b1ae4d6e2ef5000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2c0aa9020000001b1ae4d6e2ef50000001b774200010300000000de0b6b3a764000001000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005e72a5a4a98786a2dd779d2b913ea7943dabb2ff4c619c6fc88eb0c561a6675700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000325fcb17b90b63589807306f96eaa0a4670378dbc5e0fbcfa1c66d4dc4bb4ee700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1846520", gasUsed: "460041", confirmations: "2076935"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[19]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[7],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","500000000000000000000","0","0","0","0","1529612969"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x020000001b1ae4d6e2ef50000001b774200010300000000de0b6b3a764000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x5e72a5a4a98786a2dd779d2b913ea7943dabb2ff4c619c6fc88eb0c561a66757","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x325fcb17b90b63589807306f96eaa0a4670378dbc5e0fbcfa1c66d4dc4bb4ee7","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[19], [addressList[8],addressList[7],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","500000000000000000000","0","0","0","0","1529612969"], ["0x020000001b1ae4d6e2ef50000001b774200010300000000de0b6b3a764000001"], ["28","0","0"], ["0x5e72a5a4a98786a2dd779d2b913ea7943dabb2ff4c619c6fc88eb0c561a66757","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x325fcb17b90b63589807306f96eaa0a4670378dbc5e0fbcfa1c66d4dc4bb4ee7","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1527026079 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x3a505ed81fe7816d94318d12e3e7427c8466b7e1679d356f6005863a0a78d2aa"}, {name: "_principal", type: "uint256", value: "500000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "313237567845709048" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[20], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5659920", timeStamp: "1527030200", hash: "0x743aba2d4d3f2285ac7ff3d7c4c25a035883b0f68052e734f5274083f52b24d2", nonce: "286", blockHash: "0x09aad27259922c5d5de8309c6d66425a65e3365b6b9702aea020a1936e15644a", transactionIndex: "165", from: "0x0006e4548aed4502ec8c844567840ce6ef1013f5", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000000006e4548aed4502ec8c844567840ce6ef1013f5000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000003605780992537dcaae52a8da39238d6d883b700900000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f200000000000000000000000000d8775f648430679a709e98d2b0cb6250d2887ef0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2c2c9917000000003782dace9d900000030d4010001030000000000000174876e80001000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a7fba282cf93bf2edaefd39dd1cf5d0cfa860abd2f8f9fb1148082d7a923b7710000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000044eab32b16c8bd2906757f068b7e5585fa0e3ce3aa69863847ff112dac3113c800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7656275", gasUsed: "464770", confirmations: "2076665"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[20]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[21],addressList[0],addressList[10],addressList[22],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","4000000000000000000","0","0","0","0","1529621657"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x17000000003782dace9d900000030d4010001030000000000000174876e80001"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xa7fba282cf93bf2edaefd39dd1cf5d0cfa860abd2f8f9fb1148082d7a923b771","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x44eab32b16c8bd2906757f068b7e5585fa0e3ce3aa69863847ff112dac3113c8","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[20], [addressList[8],addressList[21],addressList[0],addressList[10],addressList[22],addressList[0]], ["0","0","4000000000000000000","0","0","0","0","1529621657"], ["0x17000000003782dace9d900000030d4010001030000000000000174876e80001"], ["28","0","0"], ["0xa7fba282cf93bf2edaefd39dd1cf5d0cfa860abd2f8f9fb1148082d7a923b771","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x44eab32b16c8bd2906757f068b7e5585fa0e3ce3aa69863847ff112dac3113c8","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1527030200 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0xbab209a50510b0ca3524cb6041bb8e376f30400367da3fde57d00746b754db95"}, {name: "_principal", type: "uint256", value: "4000000000000000000"}, {name: "_principalToken", type: "address", value: "0x0d8775f648430679a709e98d2b0cb6250d2887ef"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "145850637156826701" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[7], [addressList[8],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5660606", timeStamp: "1527040247", hash: "0x81c8bb16d6572402cfe628ba3cc7999136ce251a9ff9e93c6a0dd941dc8524e2", nonce: "42", blockHash: "0x9845d5a5075f68efd59bde769e6f231d83661d19ba8f583cf6502eafc5f8e7b9", transactionIndex: "47", from: "0x2987aa227df48d4891b3fe667c7a0c463f8857b1", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000002987aa227df48d4891b3fe667c7a0c463f8857b1000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000e5a3412e37e04a4e4c83800eda967a9e8468b75d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000f230b790e05390fc8295f4d3f60332c93bed42e2000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001a39de000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2c34f50800000000000000001a39de0000c35020001030000000006a94d74f43000001000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005fcf6defc346e86f00d250895e257782213ad4ef24b7373574c8449d4930067a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000460db2001b570067bb1e0ddb92fc3ad26e4ee24ebf22c0d025f449c2f21e098300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2739214", gasUsed: "449233", confirmations: "2075979"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[7]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[23],addressList[0],addressList[10],addressList[18],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","440000000","0","0","0","0","1529623797"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x0800000000000000001a39de0000c35020001030000000006a94d74f43000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x5fcf6defc346e86f00d250895e257782213ad4ef24b7373574c8449d4930067a","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x460db2001b570067bb1e0ddb92fc3ad26e4ee24ebf22c0d025f449c2f21e0983","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[7], [addressList[8],addressList[23],addressList[0],addressList[10],addressList[18],addressList[0]], ["0","0","440000000","0","0","0","0","1529623797"], ["0x0800000000000000001a39de0000c35020001030000000006a94d74f43000001"], ["27","0","0"], ["0x5fcf6defc346e86f00d250895e257782213ad4ef24b7373574c8449d4930067a","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x460db2001b570067bb1e0ddb92fc3ad26e4ee24ebf22c0d025f449c2f21e0983","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1527040247 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x1c241c3dbb037dae94e490c67960dabc9a828ff9a5d87d79f055ed11c65eeafe"}, {name: "_principal", type: "uint256", value: "440000000"}, {name: "_principalToken", type: "address", value: "0xf230b790e05390fc8295f4d3f60332c93bed42e2"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[24], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5661038", timeStamp: "1527047267", hash: "0x7c8e70bbf5541d135985485313ff7dfc3832e9940e1c758b6aa50a749df17ebf", nonce: "144", blockHash: "0xc5ad2a8c9c49185e74b6b7b40a1bed3b9ddccd9a98584d30a873de87aa1dec95", transactionIndex: "155", from: "0xb6d3d9bc0e8ab251c0eb29bd7c0e53bf482b3093", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000b6d3d9bc0e8ab251c0eb29bd7c0e53bf482b3093000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000002987aa227df48d4891b3fe667c7a0c463f8857b100000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000086fa049857e0209aa7d9e616f7eb3b3b78ecfdb0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2c23ac0400000000de0b6b3a7640000000fde82000102000001043561a882930000001000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000cc08d0d383c3aa25308c26c85317b3edc40d6e07ec9c728583306dda98d661fb000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006c9dd77d950a0d5839070af9d7e214d908de8d53f65db7e543da801729daacb400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6224549", gasUsed: "485369", confirmations: "2075547"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[24]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[7],addressList[0],addressList[10],addressList[25],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","16000000000000000000","0","0","0","0","1529619372"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x0400000000de0b6b3a7640000000fde82000102000001043561a882930000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xcc08d0d383c3aa25308c26c85317b3edc40d6e07ec9c728583306dda98d661fb","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x6c9dd77d950a0d5839070af9d7e214d908de8d53f65db7e543da801729daacb4","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[24], [addressList[8],addressList[7],addressList[0],addressList[10],addressList[25],addressList[0]], ["0","0","16000000000000000000","0","0","0","0","1529619372"], ["0x0400000000de0b6b3a7640000000fde82000102000001043561a882930000001"], ["27","0","0"], ["0xcc08d0d383c3aa25308c26c85317b3edc40d6e07ec9c728583306dda98d661fb","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x6c9dd77d950a0d5839070af9d7e214d908de8d53f65db7e543da801729daacb4","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1527047267 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x7ee88f86451ac72096d1c6af8c36eca5ab1d4c1c5e788d71975e8315d9e90226"}, {name: "_principal", type: "uint256", value: "16000000000000000000"}, {name: "_principalToken", type: "address", value: "0x86fa049857e0209aa7d9e616f7eb3b3b78ecfdb0"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "67050124895926590" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[17], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5663949", timeStamp: "1527092521", hash: "0x3048bc2972f2ccbf2a6ab59efc201918dfee924824017642e54e2595f6649ba3", nonce: "9", blockHash: "0xa25b10a41e59e82c0f1a6272b8874322cf7ff08abe28ac8f834451758e28e3a2", transactionIndex: "143", from: "0x800b7a428dfa0e7e478540fb06c07d0940414f25", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000800b7a428dfa0e7e478540fb06c07d0940414f25000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f00000000000000000000000031a3768fe55c5b8742b5287b62032f26369b96f500000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000021e19e0c9bab24000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2d1f12020000021e19e0c9bab2400000030d40300020a000004d085623382614000003000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000081f9d32cc1b86ead0bfa8b07ff879b51f3564532559f8b687d1c79d8c131c142000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005fe6dc8dc7e5f099d19f45f7612e4a5061fb08f188dc2da34a4104bee0827f9900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7143303", gasUsed: "451426", confirmations: "2072636"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[17]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[26],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","10000000000000000000000","0","0","0","0","1529683730"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x020000021e19e0c9bab2400000030d40300020a000004d085623382614000003"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x81f9d32cc1b86ead0bfa8b07ff879b51f3564532559f8b687d1c79d8c131c142","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x5fe6dc8dc7e5f099d19f45f7612e4a5061fb08f188dc2da34a4104bee0827f99","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[17], [addressList[8],addressList[26],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","10000000000000000000000","0","0","0","0","1529683730"], ["0x020000021e19e0c9bab2400000030d40300020a000004d085623382614000003"], ["28","0","0"], ["0x81f9d32cc1b86ead0bfa8b07ff879b51f3564532559f8b687d1c79d8c131c142","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x5fe6dc8dc7e5f099d19f45f7612e4a5061fb08f188dc2da34a4104bee0827f99","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1527092521 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x19a14d194eeb9bd2591e6a63f30b60cd07e704dc3212fe8d8335c51e313d3513"}, {name: "_principal", type: "uint256", value: "10000000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[12], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5664158", timeStamp: "1527095475", hash: "0x8b35c6b3fba0f51cd138614af10522e7322e43fbf8ee9f3f91233cc6b999e88f", nonce: "54", blockHash: "0x05edb06619ebb31b0e80bc018a9238b8d02c11463906f148ff739203a4e6005c", transactionIndex: "21", from: "0x51343c13216afbbc0202b824ad532bdda1e222a9", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc900000000000000000000000051343c13216afbbc0202b824ad532bdda1e222a9000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000008940866a6d3ceb7225853133a86a45692a2f42c500000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000e41d2489571d322189246dafa5ebde1f4699f498000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001158e460913d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2d123c0100000001158e460913d000000186a02000101000000410d586a20a4c000002000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000507a06de187e22467bf972dabf662d6e0ce6f14fd4a66734a449bcff51a331930000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000053188cef75aa046427696e753fb13a5b46bc05a0d30fa1901cf248120b824eb700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1349742", gasUsed: "460186", confirmations: "2072427"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[12]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[27],addressList[0],addressList[10],addressList[28],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","20000000000000000000","0","0","0","0","1529680444"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x0100000001158e460913d000000186a02000101000000410d586a20a4c000002"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x507a06de187e22467bf972dabf662d6e0ce6f14fd4a66734a449bcff51a33193","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x53188cef75aa046427696e753fb13a5b46bc05a0d30fa1901cf248120b824eb7","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[12], [addressList[8],addressList[27],addressList[0],addressList[10],addressList[28],addressList[0]], ["0","0","20000000000000000000","0","0","0","0","1529680444"], ["0x0100000001158e460913d000000186a02000101000000410d586a20a4c000002"], ["28","0","0"], ["0x507a06de187e22467bf972dabf662d6e0ce6f14fd4a66734a449bcff51a33193","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x53188cef75aa046427696e753fb13a5b46bc05a0d30fa1901cf248120b824eb7","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1527095475 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0xed30168030a0cccbc745646a4d2d108eff1a0a0c86652f86f584820c5ce310e1"}, {name: "_principal", type: "uint256", value: "20000000000000000000"}, {name: "_principalToken", type: "address", value: "0xe41d2489571d322189246dafa5ebde1f4699f498"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "103657790655991222" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[12], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5664438", timeStamp: "1527099525", hash: "0x7c5cd482f2c588e92db769f7041f609d178a049319d0506ac65cc47021491806", nonce: "56", blockHash: "0xf60cdcc7617e851ba5cf81ae20f03a3c7792eb26dbd6f31313ba7bf8d5000ee2", transactionIndex: "24", from: "0x51343c13216afbbc0202b824ad532bdda1e222a9", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc900000000000000000000000051343c13216afbbc0202b824ad532bdda1e222a9000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f00000000000000000000000069ff994f211af3043ee490fa97796dbc4193dbc600000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000053444835ec5800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2d3c78000000000053444835ec58000000c350200030000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000090f74fa092436d3237e36d450a45bc0d7c63ceea255550501e1f75cd46b59c59000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000479bb2eb5108607842a13ab39b9439f45f328b0bbe3891acb1588cdec216b0a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1944863", gasUsed: "471300", confirmations: "2072147"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[12]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[29],addressList[0],addressList[10],addressList[14],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","6000000000000000000","0","0","0","0","1529691256"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x000000000053444835ec58000000c350200030000000000de0b6b3a764000000"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x90f74fa092436d3237e36d450a45bc0d7c63ceea255550501e1f75cd46b59c59","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x0479bb2eb5108607842a13ab39b9439f45f328b0bbe3891acb1588cdec216b0a","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[12], [addressList[8],addressList[29],addressList[0],addressList[10],addressList[14],addressList[0]], ["0","0","6000000000000000000","0","0","0","0","1529691256"], ["0x000000000053444835ec58000000c350200030000000000de0b6b3a764000000"], ["27","0","0"], ["0x90f74fa092436d3237e36d450a45bc0d7c63ceea255550501e1f75cd46b59c59","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x0479bb2eb5108607842a13ab39b9439f45f328b0bbe3891acb1588cdec216b0a","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1527099525 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x7d25233902c99945d6c686cdfef2facd9ce8c012d923b8d1938d8aaf39109ef6"}, {name: "_principal", type: "uint256", value: "6000000000000000000"}, {name: "_principalToken", type: "address", value: "0xe94327d07fc17907b4db788e5adf2ed424addff6"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "103657790655991222" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[17], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5664812", timeStamp: "1527105510", hash: "0xb993280b13032d71609b9cbd188493ab4a9cebcfd0bc8fd0623575e4c9c3b1f5", nonce: "11", blockHash: "0x30b976f4994ff0b9ab90252c4caf6139b864832dbf31c4075e7b85b8777a32d0", transactionIndex: "79", from: "0x800b7a428dfa0e7e478540fb06c07d0940414f25", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000800b7a428dfa0e7e478540fb06c07d0940414f25000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f00000000000000000000000031a3768fe55c5b8742b5287b62032f26369b96f500000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010f0cf064dd592000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2d5401020000010f0cf064dd59200000030d40300020a00000273f84b41566d0000003000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000fdcbbbb67cd32e296e5ca20186ca5ed563e19ef009890e38c0ede1d3aa38b3640000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000057cac424fb6a919afc0efecd64173f37fc677cb7b3e1a9fdbc8061edc02cfd1c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3990337", gasUsed: "436426", confirmations: "2071773"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[17]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[26],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","5000000000000000000000","0","0","0","0","1529697281"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x020000010f0cf064dd59200000030d40300020a00000273f84b41566d0000003"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xfdcbbbb67cd32e296e5ca20186ca5ed563e19ef009890e38c0ede1d3aa38b364","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x57cac424fb6a919afc0efecd64173f37fc677cb7b3e1a9fdbc8061edc02cfd1c","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[17], [addressList[8],addressList[26],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","5000000000000000000000","0","0","0","0","1529697281"], ["0x020000010f0cf064dd59200000030d40300020a00000273f84b41566d0000003"], ["27","0","0"], ["0xfdcbbbb67cd32e296e5ca20186ca5ed563e19ef009890e38c0ede1d3aa38b364","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x57cac424fb6a919afc0efecd64173f37fc677cb7b3e1a9fdbc8061edc02cfd1c","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1527105510 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0xbc09fd5f1bcd98e2d45509d52c7e784e6b9af6d0a6a26da7799b4ada386e5d11"}, {name: "_principal", type: "uint256", value: "5000000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: cancelDebtOrder( [addressList[8],addressList[27],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5666894", timeStamp: "1527136786", hash: "0x9b394cebbd13febee14c2c2fea63829da5a1c64bb50fad1c7442e7dd20ec83a7", nonce: "5", blockHash: "0xe00ebf9a0cdffa37b8757c7bf460a1de0bc2268f30d52b3b35511d7de7027576", transactionIndex: "134", from: "0x8940866a6d3ceb7225853133a86a45692a2f42c5", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x20385f2f000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000008940866a6d3ceb7225853133a86a45692a2f42c500000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000e41d2489571d322189246dafa5ebde1f4699f4980000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022b1c8c1227a000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2c7e9301000000022b1c8c1227a000000186a0200010200000056bc75e2d6310000001", contractAddress: "", cumulativeGasUsed: "5124212", gasUsed: "57589", confirmations: "2069691"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[27],addressList[0],addressList[10],addressList[28],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","40000000000000000000","0","0","0","0","1529642643"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x01000000022b1c8c1227a000000186a0200010200000056bc75e2d6310000001"]}], name: "cancelDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelDebtOrder(address[6],uint256[8],bytes32[1])" ]( [addressList[8],addressList[27],addressList[0],addressList[10],addressList[28],addressList[0]], ["0","0","40000000000000000000","0","0","0","0","1529642643"], ["0x01000000022b1c8c1227a000000186a0200010200000056bc75e2d6310000001"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1527136786 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_debtOrderHash", type: "bytes32"}, {indexed: true, name: "_cancelledBy", type: "address"}], name: "LogDebtOrderCancelled", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogDebtOrderCancelled", events: [{name: "_debtOrderHash", type: "bytes32", value: "0x70c73502de84ccd1f17076f4a142ba5570f299c5fe50f081c49ba2c83be48964"}, {name: "_cancelledBy", type: "address", value: "0x8940866a6d3ceb7225853133a86a45692a2f42c5"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[30], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5671044", timeStamp: "1527201399", hash: "0x3ee8254d66aae7ae9df3eb5389848af57fe0120a9da622cb3a3122e392f06afc", nonce: "199", blockHash: "0xbc96448578d628a0224a4a26819f9558eae5e52f2f04ae475b9195eb8d798b01", transactionIndex: "61", from: "0x0bd09dc09379664d35add8f34933404d3e5895fb", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000000bd09dc09379664d35add8f34933404d3e5895fb000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000002987aa227df48d4891b3fe667c7a0c463f8857b100000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff60000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005e5e73f8d8a800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2c580b00000000005e5e73f8d8a8000001e8482000102000001b1ae4d6e2ef50000001000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d4dc9337752aab250286ef3587895a91d0d2aafa6c3cd34d4077ad0104776fcb000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001329dc39c6dec8d459268ed7c6a5df4d5b7be4af736acf6a21fd5553181ae38900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3209331", gasUsed: "451329", confirmations: "2065541"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[30]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[7],addressList[0],addressList[10],addressList[14],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","6800000000000000000","0","0","0","0","1529632779"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x00000000005e5e73f8d8a8000001e8482000102000001b1ae4d6e2ef50000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xd4dc9337752aab250286ef3587895a91d0d2aafa6c3cd34d4077ad0104776fcb","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x1329dc39c6dec8d459268ed7c6a5df4d5b7be4af736acf6a21fd5553181ae389","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[30], [addressList[8],addressList[7],addressList[0],addressList[10],addressList[14],addressList[0]], ["0","0","6800000000000000000","0","0","0","0","1529632779"], ["0x00000000005e5e73f8d8a8000001e8482000102000001b1ae4d6e2ef50000001"], ["27","0","0"], ["0xd4dc9337752aab250286ef3587895a91d0d2aafa6c3cd34d4077ad0104776fcb","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x1329dc39c6dec8d459268ed7c6a5df4d5b7be4af736acf6a21fd5553181ae389","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1527201399 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x8474cd10b7693022a1710348d4212344fc8e5394ec52af71d3b2957ce46e827f"}, {name: "_principal", type: "uint256", value: "6800000000000000000"}, {name: "_principalToken", type: "address", value: "0xe94327d07fc17907b4db788e5adf2ed424addff6"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "94642965931071540" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[7], [addressList[8],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5671460", timeStamp: "1527207701", hash: "0xc1d7e473d6216ffff544e512a2b6b0d7fe80e48c0eeac2d33d97d8ae2cfef095", nonce: "56", blockHash: "0x61063116aaf01916dfbb1d16826d02a4938e63e167eb613da4b56364c92b4378", transactionIndex: "41", from: "0x2987aa227df48d4891b3fe667c7a0c463f8857b1", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000002987aa227df48d4891b3fe667c7a0c463f8857b1000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000431194c3e0f35bc7f1266ec6bb85e0c5ec55493500000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003635c9adc5dea000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2ee0ab020000003635c9adc5dea0000000000020002030000000002386f26fc1000001000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000086a3cafcc44e2bb82873f40afab713a7bb979b5d7b6a0a6420c05cfafcaf6b6f000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003fdedbd37137360da950637f35d22873c84287ef56d689f833172c521eae7e9a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2553509", gasUsed: "444785", confirmations: "2065125"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[7]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[13],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","1000000000000000000000","0","0","0","0","1529798827"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x020000003635c9adc5dea0000000000020002030000000002386f26fc1000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x86a3cafcc44e2bb82873f40afab713a7bb979b5d7b6a0a6420c05cfafcaf6b6f","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x3fdedbd37137360da950637f35d22873c84287ef56d689f833172c521eae7e9a","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[7], [addressList[8],addressList[13],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","1000000000000000000000","0","0","0","0","1529798827"], ["0x020000003635c9adc5dea0000000000020002030000000002386f26fc1000001"], ["28","0","0"], ["0x86a3cafcc44e2bb82873f40afab713a7bb979b5d7b6a0a6420c05cfafcaf6b6f","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x3fdedbd37137360da950637f35d22873c84287ef56d689f833172c521eae7e9a","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1527207701 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x29f947da1b7833a446a4b7f9fd097bb982b95ad19b9c6a650bb270ae9d12cb6f"}, {name: "_principal", type: "uint256", value: "1000000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[7], [addressList[8],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5671582", timeStamp: "1527209322", hash: "0xe01a23cec1d017321c1f5e0845624444e6abee254dd15554c0537807f42db06a", nonce: "57", blockHash: "0x9235ee737aa1ee9c58ce08e1898a544465f527c79b34f6a9ee9654b0e9a82ddb", transactionIndex: "18", from: "0x2987aa227df48d4891b3fe667c7a0c463f8857b1", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000002987aa227df48d4891b3fe667c7a0c463f8857b1000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000601e6e7711b9e3b1b20e1e8016038a32dfc86ddd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003635c9adc5dea000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2d9791020000003635c9adc5dea00000000000200020200000000de0b6b3a764000001000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000234e42142a4cd5aa71b94aa966b028e941be383855ca12d3c3fd350a5fc0a29e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000035eda609899e474ea443f672332530910de45200d962090d777044ddaa02716d00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1089817", gasUsed: "430974", confirmations: "2065003"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[7]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[9],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","1000000000000000000000","0","0","0","0","1529714577"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x020000003635c9adc5dea00000000000200020200000000de0b6b3a764000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x234e42142a4cd5aa71b94aa966b028e941be383855ca12d3c3fd350a5fc0a29e","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x35eda609899e474ea443f672332530910de45200d962090d777044ddaa02716d","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[7], [addressList[8],addressList[9],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","1000000000000000000000","0","0","0","0","1529714577"], ["0x020000003635c9adc5dea00000000000200020200000000de0b6b3a764000001"], ["28","0","0"], ["0x234e42142a4cd5aa71b94aa966b028e941be383855ca12d3c3fd350a5fc0a29e","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x35eda609899e474ea443f672332530910de45200d962090d777044ddaa02716d","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1527209322 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0xec833c46767540924def059afb7f06aadb320d0baedc2c72bed02758dccc304b"}, {name: "_principal", type: "uint256", value: "1000000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[31], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5671589", timeStamp: "1527209413", hash: "0xa6379cc0a5dc028cb50a8f9e9ec314d836612be1b874da5ed43d36646933246d", nonce: "522", blockHash: "0x1fb21da06f4f1f3f2adaa65695c5150a5c3613c29fa539f57b38bd32b4bc4cc7", transactionIndex: "27", from: "0xb4f6ae2cca59f0ea3fb2559e32c61df753bb542a", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000b4f6ae2cca59f0ea3fb2559e32c61df753bb542a000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f00000000000000000000000051343c13216afbbc0202b824ad532bdda1e222a900000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff60000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2ee04600000000008ac7230489e80000004e20200010300000000de0b6b3a764000001000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000934f990eb9a0d2a9d563f73ca50bbfb737f623612c6fa8bcdf06326ac2c4e4cd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000433201facb1ab6d0d70157fd53e0b31a86d9f8c3aee45b5188f09f0fad93f31e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1288616", gasUsed: "450012", confirmations: "2064996"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[31]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[12],addressList[0],addressList[10],addressList[14],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","10000000000000000000","0","0","0","0","1529798726"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x00000000008ac7230489e80000004e20200010300000000de0b6b3a764000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x934f990eb9a0d2a9d563f73ca50bbfb737f623612c6fa8bcdf06326ac2c4e4cd","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x433201facb1ab6d0d70157fd53e0b31a86d9f8c3aee45b5188f09f0fad93f31e","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[31], [addressList[8],addressList[12],addressList[0],addressList[10],addressList[14],addressList[0]], ["0","0","10000000000000000000","0","0","0","0","1529798726"], ["0x00000000008ac7230489e80000004e20200010300000000de0b6b3a764000001"], ["28","0","0"], ["0x934f990eb9a0d2a9d563f73ca50bbfb737f623612c6fa8bcdf06326ac2c4e4cd","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x433201facb1ab6d0d70157fd53e0b31a86d9f8c3aee45b5188f09f0fad93f31e","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1527209413 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x3e55324739365fc2c8cd1ed7cc1921b2ecc88667a31c80f5c8f5c86d4d744b88"}, {name: "_principal", type: "uint256", value: "10000000000000000000"}, {name: "_principalToken", type: "address", value: "0xe94327d07fc17907b4db788e5adf2ed424addff6"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[7], [addressList[8],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5671592", timeStamp: "1527209473", hash: "0xfea26c5a2da990311a455d98c2107160c38ed0de1b169bb2624fe67e90b1f295", nonce: "58", blockHash: "0x66bd171f7171ff2dc23ba04bb86ac953c4f54c500899e2cffddf99d6744e2c28", transactionIndex: "131", from: "0x2987aa227df48d4891b3fe667c7a0c463f8857b1", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000002987aa227df48d4891b3fe667c7a0c463f8857b1000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f00000000000000000000000051343c13216afbbc0202b824ad532bdda1e222a900000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003635c9adc5dea000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2d915c020000003635c9adc5dea0000000271020002030000000002386f26fc1000001000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034f226c5d074a29ffa1b1b724c7dc3268a4efd07466f54f28bff08de9f835d15000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001abff0c32d4af10d9ec0c649d637fcec7175ee038c401d9bd73103f6f0586da100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5958269", gasUsed: "444913", confirmations: "2064993"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[7]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[12],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","1000000000000000000000","0","0","0","0","1529712988"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x020000003635c9adc5dea0000000271020002030000000002386f26fc1000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x34f226c5d074a29ffa1b1b724c7dc3268a4efd07466f54f28bff08de9f835d15","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x1abff0c32d4af10d9ec0c649d637fcec7175ee038c401d9bd73103f6f0586da1","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[7], [addressList[8],addressList[12],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","1000000000000000000000","0","0","0","0","1529712988"], ["0x020000003635c9adc5dea0000000271020002030000000002386f26fc1000001"], ["27","0","0"], ["0x34f226c5d074a29ffa1b1b724c7dc3268a4efd07466f54f28bff08de9f835d15","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x1abff0c32d4af10d9ec0c649d637fcec7175ee038c401d9bd73103f6f0586da1","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1527209473 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x71ce2e8b91bb5b9721768a072e15fa0f4a125923835b818128829f401fa6e0bd"}, {name: "_principal", type: "uint256", value: "1000000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[7], [addressList[8],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5671662", timeStamp: "1527210392", hash: "0xb96f7cf8c91a91b82b00afb68e94d3dadae8f0b79e9fba07d373cd5b3e93ad86", nonce: "59", blockHash: "0xdbeb21e112745ceea4516dc97a47e9ac5f160822c8e7afdceae95935a5de7589", transactionIndex: "210", from: "0x2987aa227df48d4891b3fe667c7a0c463f8857b1", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "23000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000002987aa227df48d4891b3fe667c7a0c463f8857b1000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000885949a79f83c4f5ad24945f3264f2a4c9c59a0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003635c9adc5dea000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2eed29020000003635c9adc5dea0000000000020002030000000002386f26fc1000001000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a8a0454ca8fcbc0ca9f8ee5ec47f8d4b9fb161b163587f77b886414443a63185000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007991052157d2d6982181106e7cf76ea70507826ba1815a928e12fe3f7bdf00bc00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5381276", gasUsed: "444657", confirmations: "2064923"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[7]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[32],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","1000000000000000000000","0","0","0","0","1529802025"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x020000003635c9adc5dea0000000000020002030000000002386f26fc1000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xa8a0454ca8fcbc0ca9f8ee5ec47f8d4b9fb161b163587f77b886414443a63185","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x7991052157d2d6982181106e7cf76ea70507826ba1815a928e12fe3f7bdf00bc","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[7], [addressList[8],addressList[32],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","1000000000000000000000","0","0","0","0","1529802025"], ["0x020000003635c9adc5dea0000000000020002030000000002386f26fc1000001"], ["28","0","0"], ["0xa8a0454ca8fcbc0ca9f8ee5ec47f8d4b9fb161b163587f77b886414443a63185","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x7991052157d2d6982181106e7cf76ea70507826ba1815a928e12fe3f7bdf00bc","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1527210392 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0xcbe3e60ba5fd623db826c761240ba67bce35f684f5053295b420ff11e96d6bf3"}, {name: "_principal", type: "uint256", value: "1000000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[33], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5675419", timeStamp: "1527268346", hash: "0xa4637bd89252d955edb38ce8c9113dd64a62dc781d8b7f92e903e874c41e55a1", nonce: "41", blockHash: "0x7b02cbecbf0d6eff0c38dbb2cb38d4c381f67131d11ce4d19591b65d07eeac2e", transactionIndex: "61", from: "0xf44a42cc7b25dd3a6e07e6d7b0d4f492ad749c56", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000f44a42cc7b25dd3a6e07e6d7b0d4f492ad749c56000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f00000000000000000000000085847fd710fd3968b021be4a003a6af515d4c63700000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000086fa049857e0209aa7d9e616f7eb3b3b78ecfdb00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2fc72c04000000008ac7230489e800000000001000503000000002c68af0bb14000001000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009b5d6ccafa1049edf1fd376cfe9a68c344da10fd4d6da90a9467c67033182ec00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000700926f0ecc53f8d5b6653fd0e9a6b05a0e7e55d3ac1d46b33aa5970f7245ad600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4136770", gasUsed: "483924", confirmations: "2061166"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[33]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[34],addressList[0],addressList[10],addressList[25],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","10000000000000000000","0","0","0","0","1529857836"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x04000000008ac7230489e800000000001000503000000002c68af0bb14000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x09b5d6ccafa1049edf1fd376cfe9a68c344da10fd4d6da90a9467c67033182ec","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x700926f0ecc53f8d5b6653fd0e9a6b05a0e7e55d3ac1d46b33aa5970f7245ad6","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[33], [addressList[8],addressList[34],addressList[0],addressList[10],addressList[25],addressList[0]], ["0","0","10000000000000000000","0","0","0","0","1529857836"], ["0x04000000008ac7230489e800000000001000503000000002c68af0bb14000001"], ["27","0","0"], ["0x09b5d6ccafa1049edf1fd376cfe9a68c344da10fd4d6da90a9467c67033182ec","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x700926f0ecc53f8d5b6653fd0e9a6b05a0e7e55d3ac1d46b33aa5970f7245ad6","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1527268346 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x4b142ce078e2ca3e19905fa109f87ca31685eb0757b96120f59ea1be485ff21e"}, {name: "_principal", type: "uint256", value: "10000000000000000000"}, {name: "_principalToken", type: "address", value: "0x86fa049857e0209aa7d9e616f7eb3b3b78ecfdb0"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "245253009540000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[35], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5675459", timeStamp: "1527268883", hash: "0xe623db09a2795fdc12ad89866d73d93fad600a0b70e3f2758a53718bf3d3e646", nonce: "70", blockHash: "0x6b6a67976f356d51dfe2211663455b1447709299378402351447eee7e9de460f", transactionIndex: "98", from: "0x9b34f1e9b15ca6f2a4513c90a5260102eb21bec8", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000009b34f1e9b15ca6f2a4513c90a5260102eb21bec8000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f00000000000000000000000051343c13216afbbc0202b824ad532bdda1e222a900000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b1a2bc2ec500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2fb0ac030000000000b1a2bc2ec5000000271020001020000001a055690d9db8000001000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000091f1d7238e00b9e4c9abd59987b9e69845fba6dadee54e584e684495b1c42c68000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007c80f9764f1a9563974c5bb68546383c5d7335bd633b05c151db575565ac2bba00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7684787", gasUsed: "444721", confirmations: "2061126"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[35]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[12],addressList[0],addressList[10],addressList[36],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","50000000000000000","0","0","0","0","1529852076"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x030000000000b1a2bc2ec5000000271020001020000001a055690d9db8000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x91f1d7238e00b9e4c9abd59987b9e69845fba6dadee54e584e684495b1c42c68","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x7c80f9764f1a9563974c5bb68546383c5d7335bd633b05c151db575565ac2bba","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[35], [addressList[8],addressList[12],addressList[0],addressList[10],addressList[36],addressList[0]], ["0","0","50000000000000000","0","0","0","0","1529852076"], ["0x030000000000b1a2bc2ec5000000271020001020000001a055690d9db8000001"], ["28","0","0"], ["0x91f1d7238e00b9e4c9abd59987b9e69845fba6dadee54e584e684495b1c42c68","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x7c80f9764f1a9563974c5bb68546383c5d7335bd633b05c151db575565ac2bba","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1527268883 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x0d2d94c78661e9895c0d5455787af2478bb25e8b5b0cfe8a639e9f6044a7029a"}, {name: "_principal", type: "uint256", value: "50000000000000000"}, {name: "_principalToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "191885738491306375" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: cancelDebtOrder( [addressList[8],addressList[37],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5675995", timeStamp: "1527277374", hash: "0x4f56b3087447b2d2754d0a072aef23ef1481b9f3e26148bb0aed33fc900b3141", nonce: "14", blockHash: "0x371745730148af2f653f78280a692c8c774dbc5411517622d1cd08a10ecdb696", transactionIndex: "121", from: "0x4d5b082fc164a7bf38fab4b133c1e8f3d438d406", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x20385f2f000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000004d5b082fc164a7bf38fab4b133c1e8f3d438d40600000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000086fa049857e0209aa7d9e616f7eb3b3b78ecfdb0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004563918244f4000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2e58ff0400000004563918244f4000000186a03000601000003635c9adc5dea0000001", contractAddress: "", cumulativeGasUsed: "5489248", gasUsed: "57589", confirmations: "2060590"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[37], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[37],addressList[0],addressList[10],addressList[25],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","80000000000000000000","0","0","0","0","1529764095"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x0400000004563918244f4000000186a03000601000003635c9adc5dea0000001"]}], name: "cancelDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelDebtOrder(address[6],uint256[8],bytes32[1])" ]( [addressList[8],addressList[37],addressList[0],addressList[10],addressList[25],addressList[0]], ["0","0","80000000000000000000","0","0","0","0","1529764095"], ["0x0400000004563918244f4000000186a03000601000003635c9adc5dea0000001"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1527277374 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_debtOrderHash", type: "bytes32"}, {indexed: true, name: "_cancelledBy", type: "address"}], name: "LogDebtOrderCancelled", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogDebtOrderCancelled", events: [{name: "_debtOrderHash", type: "bytes32", value: "0xf92053c707559f9971bcfad83787d43b2c2c711f72998132bd74fc89b8945e32"}, {name: "_cancelledBy", type: "address", value: "0x4d5b082fc164a7bf38fab4b133c1e8f3d438d406"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[37], balance: "134880873840772276813" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[37], balance: ( await web3.eth.getBalance( addressList[37], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[7], [addressList[8],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5676375", timeStamp: "1527282919", hash: "0xaa5d8c52eeb67a760201c691f3b9e7b19cba43fa534cbcac1434b808335c2f5b", nonce: "60", blockHash: "0x69f79aa4907818435fc6a8498ccfd4c26594e5c81bfb8fd91d1fab6aba0c6afc", transactionIndex: "9", from: "0x2987aa227df48d4891b3fe667c7a0c463f8857b1", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000002987aa227df48d4891b3fe667c7a0c463f8857b1000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000002987aa227df48d4891b3fe667c7a0c463f8857b100000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001158e460913d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b3009550200000001158e460913d0000000635630001030000000006a94d74f43000001000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d46975cb2b0439b4b32fc6f4df44c58449a52afdda66ffceda3e707b73b7bdad0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000068497ebffb7aab70a7cdb3b605a0afd60b938f1a8793e9cfa2e0fbb9bc51c0f700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "972598", gasUsed: "425521", confirmations: "2060210"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[7]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[7],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","20000000000000000000","0","0","0","0","1529874773"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x0200000001158e460913d0000000635630001030000000006a94d74f43000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xd46975cb2b0439b4b32fc6f4df44c58449a52afdda66ffceda3e707b73b7bdad","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x68497ebffb7aab70a7cdb3b605a0afd60b938f1a8793e9cfa2e0fbb9bc51c0f7","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[7], [addressList[8],addressList[7],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","20000000000000000000","0","0","0","0","1529874773"], ["0x0200000001158e460913d0000000635630001030000000006a94d74f43000001"], ["28","0","0"], ["0xd46975cb2b0439b4b32fc6f4df44c58449a52afdda66ffceda3e707b73b7bdad","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x68497ebffb7aab70a7cdb3b605a0afd60b938f1a8793e9cfa2e0fbb9bc51c0f7","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1527282919 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x24d824e648defc305fd5a351a7f2f01e7b6b39583b1c4662b3f3c29fbf406af8"}, {name: "_principal", type: "uint256", value: "20000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[38], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5676382", timeStamp: "1527283086", hash: "0xbbee0d3626868180bea58ee87f239af0c43240d49d1b0b29c1162ce40aa2c8a2", nonce: "1", blockHash: "0x6fdb0e910ce59c350ae26d609cebc0a58d5902e5b68b12f30c78adb25a55fbb1", transactionIndex: "52", from: "0x4aa6df8a00e84b11d652f959ea22d9af62573709", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000004aa6df8a00e84b11d652f959ea22d9af62573709000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f00000000000000000000000051343c13216afbbc0202b824ad532bdda1e222a900000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000f230b790e05390fc8295f4d3f60332c93bed42e2000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000012a05f2000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2ecffe0800000000000000012a05f200002710200010300000000de0b6b3a764000001000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e850b8c6738a515aa87fd71dcdcedab70714abe123c96a10c92c747460a506130000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000033e1472d93156855d8b5be34d5926aed4d4bf567cf704c220d3670bde155b75e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2946992", gasUsed: "464553", confirmations: "2060203"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[38]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[12],addressList[0],addressList[10],addressList[18],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","5000000000","0","0","0","0","1529794558"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x0800000000000000012a05f200002710200010300000000de0b6b3a764000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xe850b8c6738a515aa87fd71dcdcedab70714abe123c96a10c92c747460a50613","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x33e1472d93156855d8b5be34d5926aed4d4bf567cf704c220d3670bde155b75e","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[38], [addressList[8],addressList[12],addressList[0],addressList[10],addressList[18],addressList[0]], ["0","0","5000000000","0","0","0","0","1529794558"], ["0x0800000000000000012a05f200002710200010300000000de0b6b3a764000001"], ["28","0","0"], ["0xe850b8c6738a515aa87fd71dcdcedab70714abe123c96a10c92c747460a50613","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x33e1472d93156855d8b5be34d5926aed4d4bf567cf704c220d3670bde155b75e","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1527283086 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x7af90ff591d8da80ae7f27ad0942f307da48b153622aa8209a8e4120bc66ebd9"}, {name: "_principal", type: "uint256", value: "5000000000"}, {name: "_principalToken", type: "address", value: "0xf230b790e05390fc8295f4d3f60332c93bed42e2"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "94089189000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[39], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5676730", timeStamp: "1527288376", hash: "0x3397efacf5c043dfcc143a6be31b773cc9e153b2ec75e959fea8f846ecf0cbd6", nonce: "132", blockHash: "0xdb204aed05d7b5d8d654a66cf3fdf0258b7d43a4203d4d1c2d80962a389f60eb", transactionIndex: "151", from: "0xfaf95953a36ed1e8f8426ab5b7eb53da246e3476", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "6010000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000faf95953a36ed1e8f8426ab5b7eb53da246e3476000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f00000000000000000000000051343c13216afbbc0202b824ad532bdda1e222a900000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b2f9f95030000000006f05b59d3b200000027102000102000001b1ae4d6e2ef50000001000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b3d1f24d03465c67d79f7ee2132e5470687f8b2ddf478769bac26e375a352a07000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004bf4b3834c13e1f7af61ae22072b0ebbe19af6fb1b4cc865b888d115e6026fb100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7786766", gasUsed: "444913", confirmations: "2059855"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[39]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[12],addressList[0],addressList[10],addressList[36],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","500000000000000000","0","0","0","0","1529847701"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x030000000006f05b59d3b200000027102000102000001b1ae4d6e2ef50000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xb3d1f24d03465c67d79f7ee2132e5470687f8b2ddf478769bac26e375a352a07","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x4bf4b3834c13e1f7af61ae22072b0ebbe19af6fb1b4cc865b888d115e6026fb1","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[39], [addressList[8],addressList[12],addressList[0],addressList[10],addressList[36],addressList[0]], ["0","0","500000000000000000","0","0","0","0","1529847701"], ["0x030000000006f05b59d3b200000027102000102000001b1ae4d6e2ef50000001"], ["27","0","0"], ["0xb3d1f24d03465c67d79f7ee2132e5470687f8b2ddf478769bac26e375a352a07","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x4bf4b3834c13e1f7af61ae22072b0ebbe19af6fb1b4cc865b888d115e6026fb1","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1527288376 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x6dc5c9d0b14da26d1563e14194cc0ea3065c1548e4137b3ea70b3672bd738584"}, {name: "_principal", type: "uint256", value: "500000000000000000"}, {name: "_principalToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "350850932317077150" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[13], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5676813", timeStamp: "1527289653", hash: "0x9f5be4a20702de5e3b13c0671cabdb85d59f4403275bd7f91d9253555337a937", nonce: "19", blockHash: "0xe49b1495a8513aff8dd5d946b9644cb4999f06a1a685b9522fa59dcfdefc8b70", transactionIndex: "36", from: "0x431194c3e0f35bc7f1266ec6bb85e0c5ec554935", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "6200000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000431194c3e0f35bc7f1266ec6bb85e0c5ec554935000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000002987aa227df48d4891b3fe667c7a0c463f8857b100000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001158e460913d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b3005850200000001158e460913d000000053341000103000000000005af3107a400000000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004388af0588c00d33018de33c4199edf8b105b368a208a2ab004dfe301a4670a5000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004bca7d59ee24d354d091ea2b9956df447db0b97ad09432661a29c274848d332900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2121646", gasUsed: "444785", confirmations: "2059772"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[13]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[7],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","20000000000000000000","0","0","0","0","1529873797"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x0200000001158e460913d000000053341000103000000000005af3107a400000"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x4388af0588c00d33018de33c4199edf8b105b368a208a2ab004dfe301a4670a5","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x4bca7d59ee24d354d091ea2b9956df447db0b97ad09432661a29c274848d3329","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[13], [addressList[8],addressList[7],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","20000000000000000000","0","0","0","0","1529873797"], ["0x0200000001158e460913d000000053341000103000000000005af3107a400000"], ["27","0","0"], ["0x4388af0588c00d33018de33c4199edf8b105b368a208a2ab004dfe301a4670a5","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x4bca7d59ee24d354d091ea2b9956df447db0b97ad09432661a29c274848d3329","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1527289653 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0xd630c126fe0f0ef4e5d96d8fd6fd73301a7b5687a6f07a7cb5e145e9cbbf06eb"}, {name: "_principal", type: "uint256", value: "20000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[31], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5677009", timeStamp: "1527292930", hash: "0x8b940780a1fb8a9a235a77088e3486b3422cad977e8d3fcbde8b992be1c06d2d", nonce: "525", blockHash: "0xec65baa800e522643c856cde04ff1d7e9b4be81a78276f283bec1606a16c8385", transactionIndex: "50", from: "0xb4f6ae2cca59f0ea3fb2559e32c61df753bb542a", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000b4f6ae2cca59f0ea3fb2559e32c61df753bb542a000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000431194c3e0f35bc7f1266ec6bb85e0c5ec55493500000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff60000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006124fee993bc00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b3023ba00000000006124fee993bc000001e84820001020000012f939c99edab8000001000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000863ee98cb9e73a96732d701595ff2143f53ebf5cb2e37d1b69e5c361340451bf0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000071741f52a291bb7c0d581d18c92aa423acdd5b5c0cabd60cf779b46b32f04b3600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4370090", gasUsed: "436329", confirmations: "2059576"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[31]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[13],addressList[0],addressList[10],addressList[14],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","7000000000000000000","0","0","0","0","1529881530"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x00000000006124fee993bc000001e84820001020000012f939c99edab8000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x863ee98cb9e73a96732d701595ff2143f53ebf5cb2e37d1b69e5c361340451bf","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x71741f52a291bb7c0d581d18c92aa423acdd5b5c0cabd60cf779b46b32f04b36","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[31], [addressList[8],addressList[13],addressList[0],addressList[10],addressList[14],addressList[0]], ["0","0","7000000000000000000","0","0","0","0","1529881530"], ["0x00000000006124fee993bc000001e84820001020000012f939c99edab8000001"], ["27","0","0"], ["0x863ee98cb9e73a96732d701595ff2143f53ebf5cb2e37d1b69e5c361340451bf","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x71741f52a291bb7c0d581d18c92aa423acdd5b5c0cabd60cf779b46b32f04b36","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1527292930 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x60a849935bf6853b86c12e25d7a9447a0430916dbd3570d6392b75a74fde0117"}, {name: "_principal", type: "uint256", value: "7000000000000000000"}, {name: "_principalToken", type: "address", value: "0xe94327d07fc17907b4db788e5adf2ed424addff6"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "126000000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[40], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5683708", timeStamp: "1527394059", hash: "0x0a19ba1d61f0085cd46b5dcf8fd1ca94dbafa996a38a55eba0ab5e14fdfe85c6", nonce: "220", blockHash: "0xbeede29dde884ffd65828dfc753c3f225a8b249fe20ba4f1171d5ead64cacf10", transactionIndex: "130", from: "0x4056f3f55c338e22330002924023025df61a9d3b", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000004056f3f55c338e22330002924023025df61a9d3b000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000004056f3f55c338e22330002924023025df61a9d3b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc2000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b31baa70300000000002386f26fc100000249f01000105000000000b1a2bc2ec5000000000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b62e75c0487e5ce6e8cf206a05fb610a9ea37a97af5de4043b4e146f90deccd7000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e0100a47a33ace8e398a8d1f12cd54182a66a12ea2154c31f469c3b007f8f3800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5058071", gasUsed: "470009", confirmations: "2052877"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[40]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[40],addressList[0],addressList[10],addressList[36],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","10000000000000000","0","0","0","0","1529985703"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x0300000000002386f26fc100000249f01000105000000000b1a2bc2ec5000000"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xb62e75c0487e5ce6e8cf206a05fb610a9ea37a97af5de4043b4e146f90deccd7","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x3e0100a47a33ace8e398a8d1f12cd54182a66a12ea2154c31f469c3b007f8f38","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[40], [addressList[8],addressList[40],addressList[0],addressList[10],addressList[36],addressList[0]], ["0","0","10000000000000000","0","0","0","0","1529985703"], ["0x0300000000002386f26fc100000249f01000105000000000b1a2bc2ec5000000"], ["28","0","0"], ["0xb62e75c0487e5ce6e8cf206a05fb610a9ea37a97af5de4043b4e146f90deccd7","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x3e0100a47a33ace8e398a8d1f12cd54182a66a12ea2154c31f469c3b007f8f38","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1527394059 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x45e7acad919efe7fc431c7437bfe79240744162182ea7f96d5db36e280b193dc"}, {name: "_principal", type: "uint256", value: "10000000000000000"}, {name: "_principalToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[41], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5698445", timeStamp: "1527619157", hash: "0xde4a908ca36ab049dd6f1becfbb6cf784ea37a760589c24c998fb92a9911addd", nonce: "10", blockHash: "0xb83c5a77d3ff3919f1ab6dd7f68d5b5e43fa196b120fd687f9dbafeeda55442f", transactionIndex: "20", from: "0x0c81d7d494facfba3efe7a3030755fc2249ea983", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000000c81d7d494facfba3efe7a3030755fc2249ea983000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000002987aa227df48d4891b3fe667c7a0c463f8857b100000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000056bc75e2d631000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b32e22502000000056bc75e2d631000000186a020001000000000610177f723fb000001000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000be7ea4a0ef80b56bea98b2170783b5612fbc4466ed465ab4d7bf0b5e47606ad70000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000014fa1837e3a784874da8c17cbd2759a17c7bb8944cedeecb669c83d8d987203900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1354173", gasUsed: "451393", confirmations: "2038140"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[41]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[7],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","100000000000000000000","0","0","0","0","1530061349"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x02000000056bc75e2d631000000186a020001000000000610177f723fb000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xbe7ea4a0ef80b56bea98b2170783b5612fbc4466ed465ab4d7bf0b5e47606ad7","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x14fa1837e3a784874da8c17cbd2759a17c7bb8944cedeecb669c83d8d9872039","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[41], [addressList[8],addressList[7],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","100000000000000000000","0","0","0","0","1530061349"], ["0x02000000056bc75e2d631000000186a020001000000000610177f723fb000001"], ["27","0","0"], ["0xbe7ea4a0ef80b56bea98b2170783b5612fbc4466ed465ab4d7bf0b5e47606ad7","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x14fa1837e3a784874da8c17cbd2759a17c7bb8944cedeecb669c83d8d9872039","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1527619157 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x832c58d8b45dea51288f2c1a06d354b2b80a05f5232fe9f1d0583c552908efd9"}, {name: "_principal", type: "uint256", value: "100000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[42], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5701249", timeStamp: "1527661742", hash: "0xd4ed3b1e34c276fba65e6675a72b48d32b1a7365b0b3be9a617e4e6e70bd99e3", nonce: "282", blockHash: "0xb740f41b1c9f1ed53e1788cc06818fa3c3a0dae1fa9758be5e4f104ea8a72dd8", transactionIndex: "38", from: "0x2958db51a0b4c458d0aa183e8cfb4f2e95cf6e75", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000002958db51a0b4c458d0aa183e8cfb4f2e95cf6e75000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000002958db51a0b4c458d0aa183e8cfb4f2e95cf6e7500000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b35ce2302000000000de0b6b3a76400000027102000105000000000038d7ea4c6800005000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002ffe98c3eb301b58d09a9fa3b9ab397e94d54ebe0f4d54279f39fc69cc60a1d700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000456dc0d8728ea2227d0472bdc776680deb9776ef5facb213faf20bb6601c0fcd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1779634", gasUsed: "471646", confirmations: "2035336"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[42], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[42]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[42],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","1000000000000000000","0","0","0","0","1530252835"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x02000000000de0b6b3a76400000027102000105000000000038d7ea4c6800005"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x2ffe98c3eb301b58d09a9fa3b9ab397e94d54ebe0f4d54279f39fc69cc60a1d7","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x456dc0d8728ea2227d0472bdc776680deb9776ef5facb213faf20bb6601c0fcd","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[42], [addressList[8],addressList[42],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","1000000000000000000","0","0","0","0","1530252835"], ["0x02000000000de0b6b3a76400000027102000105000000000038d7ea4c6800005"], ["27","0","0"], ["0x2ffe98c3eb301b58d09a9fa3b9ab397e94d54ebe0f4d54279f39fc69cc60a1d7","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x456dc0d8728ea2227d0472bdc776680deb9776ef5facb213faf20bb6601c0fcd","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1527661742 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0xdc99d003d0c99fec6127881cdea535b8a5a9b6ec17f8618643c801da1d1985c5"}, {name: "_principal", type: "uint256", value: "1000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[42], balance: "611839763481271077" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[42], balance: ( await web3.eth.getBalance( addressList[42], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[43], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5710095", timeStamp: "1527797973", hash: "0x6687d97c58493abe3c705da6e721bd889c657327f8841a902ce5cef190c59fb5", nonce: "3", blockHash: "0xe973809565c38d176ab413489029af68bcb1e9ae094c36c6a9f350cc43479e93", transactionIndex: "31", from: "0x0678c3827fb20c6883b1ee9d243fddcf0d0bc271", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "28000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000000678c3827fb20c6883b1ee9d243fddcf0d0bc271000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f00000000000000000000000051343c13216afbbc0202b824ad532bdda1e222a900000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000d850942ef8811f2a866692a623011bde52a462c1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d02ab486cedc00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b354cb00900000000d02ab486cedc0000004e20200010300000000214e8348c4f000001000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000089b92e2de79cce75f2207995428644a7702e7b5ea6bcf3688bcd2271acef49b8000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007d94e8c3d485acf81e0084b1db240e1b787643057abe14ccf7c4c5880e00f82a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1756715", gasUsed: "468198", confirmations: "2026490"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[43], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[43]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[12],addressList[0],addressList[10],addressList[44],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","15000000000000000000","0","0","0","0","1530219696"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x0900000000d02ab486cedc0000004e20200010300000000214e8348c4f000001"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x89b92e2de79cce75f2207995428644a7702e7b5ea6bcf3688bcd2271acef49b8","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x7d94e8c3d485acf81e0084b1db240e1b787643057abe14ccf7c4c5880e00f82a","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[43], [addressList[8],addressList[12],addressList[0],addressList[10],addressList[44],addressList[0]], ["0","0","15000000000000000000","0","0","0","0","1530219696"], ["0x0900000000d02ab486cedc0000004e20200010300000000214e8348c4f000001"], ["27","0","0"], ["0x89b92e2de79cce75f2207995428644a7702e7b5ea6bcf3688bcd2271acef49b8","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x7d94e8c3d485acf81e0084b1db240e1b787643057abe14ccf7c4c5880e00f82a","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1527797973 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x166ccf7863fc6152dea73a79c76fe529f5444be381da86aefab4e8de5fd3bfd0"}, {name: "_principal", type: "uint256", value: "15000000000000000000"}, {name: "_principalToken", type: "address", value: "0xd850942ef8811f2a866692a623011bde52a462c1"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[43], balance: "31700286000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[43], balance: ( await web3.eth.getBalance( addressList[43], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[45], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5739007", timeStamp: "1528241787", hash: "0xc71708f6104d91aa828ad53526a615740867de97a0c728d5ea1edb73a5e5e4d3", nonce: "25", blockHash: "0x14c62caae46977c8b51c40787474444bb37fcd068208e2c3f84fcfe51ddb9ccf", transactionIndex: "116", from: "0x262ba400bb2cf20fab04262b5a60eb8e6eebc7b2", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000262ba400bb2cf20fab04262b5a60eb8e6eebc7b2000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000d05955436368c9659b7a1bdf8f0427ca8c193b1100000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001158e460913d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b3ea6fe0200000001158e460913d000000061a830001050000000007c369282d1480000000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007756a0bd2ca57ffa3d90aea308091dbd6cc72ffee3da0b0a656e9238378c06050000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005d8aebd470f6652da2072595365ac2f7f632203f3bad10f2bdb862c08d13c2f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6013483", gasUsed: "476038", confirmations: "1997578"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[45], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[45]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[46],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","20000000000000000000","0","0","0","0","1530832638"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x0200000001158e460913d000000061a830001050000000007c369282d1480000"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x7756a0bd2ca57ffa3d90aea308091dbd6cc72ffee3da0b0a656e9238378c0605","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x05d8aebd470f6652da2072595365ac2f7f632203f3bad10f2bdb862c08d13c2f","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[45], [addressList[8],addressList[46],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","20000000000000000000","0","0","0","0","1530832638"], ["0x0200000001158e460913d000000061a830001050000000007c369282d1480000"], ["28","0","0"], ["0x7756a0bd2ca57ffa3d90aea308091dbd6cc72ffee3da0b0a656e9238378c0605","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x05d8aebd470f6652da2072595365ac2f7f632203f3bad10f2bdb862c08d13c2f","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1528241787 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x95faa973fd9144b29c9e031cdc82b26243e73c7a994959004180ad6200d918d3"}, {name: "_principal", type: "uint256", value: "20000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[45], balance: "49548141546888915507" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[45], balance: ( await web3.eth.getBalance( addressList[45], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: cancelDebtOrder( [addressList[8],addressList[47],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5742630", timeStamp: "1528297130", hash: "0x568d3d2e0227e97c7141ab7eed7aafc07fa60cb84e39c3257f45a22ec15aa945", nonce: "17", blockHash: "0xb5624ba9508d284858940fc2e170567a919ce2a1af7742c162d852910d0ffb7c", transactionIndex: "168", from: "0xb877ddbcb49a44e0bdd5659326de9678a84a3182", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x20385f2f000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000b877ddbcb49a44e0bdd5659326de9678a84a318200000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000056bc75e2d631000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b3f7a2502000000056bc75e2d631000000186a0100020200000008ac7230489e800000a", contractAddress: "", cumulativeGasUsed: "5275453", gasUsed: "57525", confirmations: "1993955"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[47],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","100000000000000000000","0","0","0","0","1530886693"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x02000000056bc75e2d631000000186a0100020200000008ac7230489e800000a"]}], name: "cancelDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelDebtOrder(address[6],uint256[8],bytes32[1])" ]( [addressList[8],addressList[47],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","100000000000000000000","0","0","0","0","1530886693"], ["0x02000000056bc75e2d631000000186a0100020200000008ac7230489e800000a"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1528297130 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_debtOrderHash", type: "bytes32"}, {indexed: true, name: "_cancelledBy", type: "address"}], name: "LogDebtOrderCancelled", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogDebtOrderCancelled", events: [{name: "_debtOrderHash", type: "bytes32", value: "0xd17605ef8e3c6046f9c06c19baf0b6bd236f501eba9c5126c8d052d81a60a15e"}, {name: "_cancelledBy", type: "address", value: "0xb877ddbcb49a44e0bdd5659326de9678a84a3182"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "288569949137500000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[41], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5754194", timeStamp: "1528474283", hash: "0x3ff66066cfcf2e64d6517b94dad41d736bafbfa19c8c778d74575f96c76807b7", nonce: "15", blockHash: "0x0ee7043328be6fbb15149f2a48f80c58d26f957939f4ace85a2402455970f85d", transactionIndex: "75", from: "0x0c81d7d494facfba3efe7a3030755fc2249ea983", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000000c81d7d494facfba3efe7a3030755fc2249ea983000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000d51576e9df69e2e13acb2066eb8ec53acd9a3c9e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc20000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006124fee993bc00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b42181d03000000006124fee993bc000001adb0300011700004ded51e9cc70060000002000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005cac4390ec05ee4c8038979aa7b47b94c569b866a644b1ba3ca1108cba8db77000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003242e757976818a880c911fedc128e17f3504e49cf7c39648bcbcf009e459cda00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3805023", gasUsed: "464962", confirmations: "1982391"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[41]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[48],addressList[0],addressList[10],addressList[36],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","7000000000000000000","0","0","0","0","1531058205"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x03000000006124fee993bc000001adb0300011700004ded51e9cc70060000002"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x05cac4390ec05ee4c8038979aa7b47b94c569b866a644b1ba3ca1108cba8db77","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x3242e757976818a880c911fedc128e17f3504e49cf7c39648bcbcf009e459cda","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[41], [addressList[8],addressList[48],addressList[0],addressList[10],addressList[36],addressList[0]], ["0","0","7000000000000000000","0","0","0","0","1531058205"], ["0x03000000006124fee993bc000001adb0300011700004ded51e9cc70060000002"], ["28","0","0"], ["0x05cac4390ec05ee4c8038979aa7b47b94c569b866a644b1ba3ca1108cba8db77","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x3242e757976818a880c911fedc128e17f3504e49cf7c39648bcbcf009e459cda","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1528474283 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0xb488fb88378c51e0058298adeae6781239f13c7586c60ed216f75d6849af5ca5"}, {name: "_principal", type: "uint256", value: "7000000000000000000"}, {name: "_principalToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: cancelDebtOrder( [addressList[8],addressList[49],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5777841", timeStamp: "1528835603", hash: "0x610d89eddaa0fd1f37976d0a6ab42840f51df7ad7dd7c8be628774e62ace4655", nonce: "129", blockHash: "0xf1cd00c285e84f9d56ce17150eb5624d3678d6dd8c99a82cda90884feec9bdbf", transactionIndex: "62", from: "0x9abdefbabe7f459186b5cd58d17371b2e02ac8f8", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x20385f2f000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000009abdefbabe7f459186b5cd58d17371b2e02ac8f800000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000056bc75e2d631000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b47b77902000000056bc75e2d6310000000c3503000101000000b469471f80140000007", contractAddress: "", cumulativeGasUsed: "3009047", gasUsed: "57525", confirmations: "1958744"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[49],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","100000000000000000000","0","0","0","0","1531426681"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x02000000056bc75e2d6310000000c3503000101000000b469471f80140000007"]}], name: "cancelDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelDebtOrder(address[6],uint256[8],bytes32[1])" ]( [addressList[8],addressList[49],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","100000000000000000000","0","0","0","0","1531426681"], ["0x02000000056bc75e2d6310000000c3503000101000000b469471f80140000007"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1528835603 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_debtOrderHash", type: "bytes32"}, {indexed: true, name: "_cancelledBy", type: "address"}], name: "LogDebtOrderCancelled", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogDebtOrderCancelled", events: [{name: "_debtOrderHash", type: "bytes32", value: "0xbb65f697244784097e03fad6c385aeba23dcb6e38930d0e950bb1680b8f8538b"}, {name: "_cancelledBy", type: "address", value: "0x9abdefbabe7f459186b5cd58d17371b2e02ac8f8"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "13487035251171272105" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: cancelDebtOrder( [addressList[8],addressList[49],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5777842", timeStamp: "1528835615", hash: "0xbb6ef6da901374d52e29ec9d563d0e409e97df14adef720269334e4048d5ddc0", nonce: "130", blockHash: "0x29b8228d9725e0d115222cf99881e890dbcefacefb1812a5a0e1e8ea8b94b61c", transactionIndex: "35", from: "0x9abdefbabe7f459186b5cd58d17371b2e02ac8f8", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x20385f2f000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000009abdefbabe7f459186b5cd58d17371b2e02ac8f800000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000056bc75e2d631000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b47b77902000000056bc75e2d6310000000c3503000101000000b469471f80140000007", contractAddress: "", cumulativeGasUsed: "1603950", gasUsed: "42525", confirmations: "1958743"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[49],addressList[0],addressList[10],addressList[11],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","100000000000000000000","0","0","0","0","1531426681"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x02000000056bc75e2d6310000000c3503000101000000b469471f80140000007"]}], name: "cancelDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelDebtOrder(address[6],uint256[8],bytes32[1])" ]( [addressList[8],addressList[49],addressList[0],addressList[10],addressList[11],addressList[0]], ["0","0","100000000000000000000","0","0","0","0","1531426681"], ["0x02000000056bc75e2d6310000000c3503000101000000b469471f80140000007"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1528835615 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_debtOrderHash", type: "bytes32"}, {indexed: true, name: "_cancelledBy", type: "address"}], name: "LogDebtOrderCancelled", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogDebtOrderCancelled", events: [{name: "_debtOrderHash", type: "bytes32", value: "0xbb65f697244784097e03fad6c385aeba23dcb6e38930d0e950bb1680b8f8538b"}, {name: "_cancelledBy", type: "address", value: "0x9abdefbabe7f459186b5cd58d17371b2e02ac8f8"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "13487035251171272105" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[50], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5795223", timeStamp: "1529096067", hash: "0x27418e26115330a95ffaa297e4b34a5300fb25483407229ecddeea76d607e8f7", nonce: "5", blockHash: "0x5a379dde31c53ff8d4c0d4485c09c1c4b242716cdde7cb8efe9db2a577980a3c", transactionIndex: "6", from: "0x577a5b3bf1d36c4280a1c0d9c4513de48fb7ab2e", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000577a5b3bf1d36c4280a1c0d9c4513de48fb7ab2e000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000577a5b3bf1d36c4280a1c0d9c4513de48fb7ab2e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000000f34ad48a326b406bf995e04189e42d285d577300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000028f5487100000000000000000000000000000000000000000000000000038d7ea4c680000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b4b9ee0030000000000038d7ea4c680000027101000503000000000354a6ba7a1800000000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002dcfad1cee7a286665562108fe1a7de8449e6621eace40dd9720c5aad952078c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000351d50002bd0ee3293bef1e2fed65fe2da6e98d647b2903004a2ec36c0f7ee4400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "690487", gasUsed: "455589", confirmations: "1941362"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[50], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[50]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[50],addressList[0],addressList[10],addressList[36],addressList[51]]}, {type: "uint256[8]", name: "orderValues", value: ["0","687163505","1000000000000000","0","0","0","0","1531682528"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x030000000000038d7ea4c680000027101000503000000000354a6ba7a1800000"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x2dcfad1cee7a286665562108fe1a7de8449e6621eace40dd9720c5aad952078c","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x351d50002bd0ee3293bef1e2fed65fe2da6e98d647b2903004a2ec36c0f7ee44","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[50], [addressList[8],addressList[50],addressList[0],addressList[10],addressList[36],addressList[51]], ["0","687163505","1000000000000000","0","0","0","0","1531682528"], ["0x030000000000038d7ea4c680000027101000503000000000354a6ba7a1800000"], ["28","0","0"], ["0x2dcfad1cee7a286665562108fe1a7de8449e6621eace40dd9720c5aad952078c","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x351d50002bd0ee3293bef1e2fed65fe2da6e98d647b2903004a2ec36c0f7ee44","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1529096067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x8f785fc6198cfe75d96647eb859a0f0f95067dc35cef62dc6837757f6b90e31d"}, {name: "_principal", type: "uint256", value: "1000000000000000"}, {name: "_principalToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x00f34ad48a326b406bf995e04189e42d285d5773"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[50], balance: "4476393319324438" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[50], balance: ( await web3.eth.getBalance( addressList[50], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[52], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5795261", timeStamp: "1529096637", hash: "0xa45d6032dfb5135e61271d4319735f81336bcd92e977824682651390f648347b", nonce: "7", blockHash: "0x500c7fd27abedf33ddb003fe6b2968d0245196d1b63ad987b365a74457420777", transactionIndex: "129", from: "0x0be81f52642969952d470bbe0f50de78d1b3d085", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000000be81f52642969952d470bbe0f50de78d1b3d085000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000577a5b3bf1d36c4280a1c0d9c4513de48fb7ab2e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff600000000000000000000000000f34ad48a326b406bf995e04189e42d285d577300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000015a4ed9b000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b4bafca0000000000016345785d8a000000c3501000f03000000000038d7ea4c6800000000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007035e84b5853134606c81aa420767d99b1548c11b952e9d658924b235a930acd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000305fc68289534536c2e6e438a1f146ddfeae67ba9e2d7b4cebb5ebdc62ad5aef00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6814328", gasUsed: "466397", confirmations: "1941324"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[52], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[52]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[50],addressList[0],addressList[10],addressList[14],addressList[51]]}, {type: "uint256[8]", name: "orderValues", value: ["0","363130267","100000000000000000","0","0","0","0","1531686858"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x0000000000016345785d8a000000c3501000f03000000000038d7ea4c6800000"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x7035e84b5853134606c81aa420767d99b1548c11b952e9d658924b235a930acd","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x305fc68289534536c2e6e438a1f146ddfeae67ba9e2d7b4cebb5ebdc62ad5aef","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[52], [addressList[8],addressList[50],addressList[0],addressList[10],addressList[14],addressList[51]], ["0","363130267","100000000000000000","0","0","0","0","1531686858"], ["0x0000000000016345785d8a000000c3501000f03000000000038d7ea4c6800000"], ["28","0","0"], ["0x7035e84b5853134606c81aa420767d99b1548c11b952e9d658924b235a930acd","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x305fc68289534536c2e6e438a1f146ddfeae67ba9e2d7b4cebb5ebdc62ad5aef","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1529096637 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x2749bbbf7f0774bc4ecf0ac4fc0ba08470182220805f51a61b9f0de3a6e0429f"}, {name: "_principal", type: "uint256", value: "100000000000000000"}, {name: "_principalToken", type: "address", value: "0xe94327d07fc17907b4db788e5adf2ed424addff6"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x00f34ad48a326b406bf995e04189e42d285d5773"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[52], balance: "91773459399479580" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[52], balance: ( await web3.eth.getBalance( addressList[52], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[50], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5795519", timeStamp: "1529100528", hash: "0x4f874c3f6ddddd043b6978125a63a70454f6dd43fde73e2c6a32ce44bfd7106a", nonce: "13", blockHash: "0x3ffbbd5d5e146a4251ccf1befa55843b6cc4bef5ae3f873ca5ef584a54e06417", transactionIndex: "18", from: "0x577a5b3bf1d36c4280a1c0d9c4513de48fb7ab2e", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000577a5b3bf1d36c4280a1c0d9c4513de48fb7ab2e000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000000be81f52642969952d470bbe0f50de78d1b3d08500000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000e41d2489571d322189246dafa5ebde1f4699f49800000000000000000000000000f34ad48a326b406bf995e04189e42d285d577300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022335e5e0000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b4bc53601000000000de0b6b3a764000000c35010002000000000002386f26fc1000000000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006ba0ceb8c2b4d7a21d8e7e0fa74e26f221a984471977bd9e04fb7b6f6d84fc28000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003dc453f53a56ba438e7c2552f040a5214064a5c667b4d66cb5b0bf73196bb75c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1225269", gasUsed: "466968", confirmations: "1941066"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[50], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[50]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[52],addressList[0],addressList[10],addressList[28],addressList[51]]}, {type: "uint256[8]", name: "orderValues", value: ["0","573791838","1000000000000000000","0","0","0","0","1531692342"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x01000000000de0b6b3a764000000c35010002000000000002386f26fc1000000"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x6ba0ceb8c2b4d7a21d8e7e0fa74e26f221a984471977bd9e04fb7b6f6d84fc28","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x3dc453f53a56ba438e7c2552f040a5214064a5c667b4d66cb5b0bf73196bb75c","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[50], [addressList[8],addressList[52],addressList[0],addressList[10],addressList[28],addressList[51]], ["0","573791838","1000000000000000000","0","0","0","0","1531692342"], ["0x01000000000de0b6b3a764000000c35010002000000000002386f26fc1000000"], ["28","0","0"], ["0x6ba0ceb8c2b4d7a21d8e7e0fa74e26f221a984471977bd9e04fb7b6f6d84fc28","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x3dc453f53a56ba438e7c2552f040a5214064a5c667b4d66cb5b0bf73196bb75c","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1529100528 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0xfc8b3cc52dadb2744e3cc948bcc554e99f65c532c722bfa0941ecccc0f27c355"}, {name: "_principal", type: "uint256", value: "1000000000000000000"}, {name: "_principalToken", type: "address", value: "0xe41d2489571d322189246dafa5ebde1f4699f498"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x00f34ad48a326b406bf995e04189e42d285d5773"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[50], balance: "4476393319324438" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[50], balance: ( await web3.eth.getBalance( addressList[50], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[53], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5795972", timeStamp: "1529107188", hash: "0xde25659a6f79500d259c096fe1cfaf54e6075388f57c29eae2429f0865df46d2", nonce: "14", blockHash: "0xede59651f80c5a3fe1d08b0eca475f6f9027d3ec364b6005d26c174592a207e0", transactionIndex: "95", from: "0x6622e301f757bbaec6cfb34c03338da4358d94da", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000006622e301f757bbaec6cfb34c03338da4358d94da000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000006622e301f757bbaec6cfb34c03338da4358d94da00000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000e41d2489571d322189246dafa5ebde1f4699f4980000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b4bd1a401000000000de0b6b3a7640000002710400010100000000de0b6b3a76400000a000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000f8f155de31551592c07fe53d4ab5d81e2d5563bae11fca88ba4975f26ebc399c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008954c42f9947bad49c04650b36c19af341c67af3b9ac42bb38cab52f88a3cdb00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7261437", gasUsed: "54166", confirmations: "1940613"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[53], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[53]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[53],addressList[0],addressList[10],addressList[28],addressList[0]]}, {type: "uint256[8]", name: "orderValues", value: ["0","0","1000000000000000000","0","0","0","0","1531695524"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x01000000000de0b6b3a7640000002710400010100000000de0b6b3a76400000a"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xf8f155de31551592c07fe53d4ab5d81e2d5563bae11fca88ba4975f26ebc399c","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x08954c42f9947bad49c04650b36c19af341c67af3b9ac42bb38cab52f88a3cdb","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[53], [addressList[8],addressList[53],addressList[0],addressList[10],addressList[28],addressList[0]], ["0","0","1000000000000000000","0","0","0","0","1531695524"], ["0x01000000000de0b6b3a7640000002710400010100000000de0b6b3a76400000a"], ["28","0","0"], ["0xf8f155de31551592c07fe53d4ab5d81e2d5563bae11fca88ba4975f26ebc399c","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x08954c42f9947bad49c04650b36c19af341c67af3b9ac42bb38cab52f88a3cdb","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1529107188 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_errorId", type: "uint8"}, {indexed: true, name: "_orderHash", type: "bytes32"}], name: "LogError", type: "event"} ;
		console.error( "eventCallOriginal[42,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogError", events: [{name: "_errorId", type: "uint8", value: "8"}, {name: "_orderHash", type: "bytes32", value: "0xf6a19a4231bbcbb4d209128773080bc72acdc679e410d46c26cf0171edb74d67"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[42,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[53], balance: "877371872931015" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[53], balance: ( await web3.eth.getBalance( addressList[53], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[54], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5798765", timeStamp: "1529148742", hash: "0x7e18b17519842500b58958c2fed4f4fafd8b675a8912c12589e997fe83c62c9f", nonce: "1", blockHash: "0xa7b46a2fb0db9b73b440f177e899fc3026a22974369df5009124b8da5297d3e8", transactionIndex: "86", from: "0x1ce3d14fb814ad1df000a26486c274496681b363", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc90000000000000000000000001ce3d14fb814ad1df000a26486c274496681b363000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000577a5b3bf1d36c4280a1c0d9c4513de48fb7ab2e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000e41d2489571d322189246dafa5ebde1f4699f49800000000000000000000000000f34ad48a326b406bf995e04189e42d285d57730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001b3b5adf00000000000000000000000000000000000000000000000029a2241af62c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b4bbc28010000000029a2241af62c0000004e201000103000000000b1a2bc2ec5000000000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000fc5359a7d8561ed6f982e529a69e62cce04297366095a169631e7387d18b1d53000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007fee6a21ce741e4fbb66a8c37ae6503da749d7dc1697054262e2af89d7b1d1f900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4609881", gasUsed: "445552", confirmations: "1937820"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[54]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[50],addressList[0],addressList[10],addressList[28],addressList[51]]}, {type: "uint256[8]", name: "orderValues", value: ["0","456874719","3000000000000000000","0","0","0","0","1531690024"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x010000000029a2241af62c0000004e201000103000000000b1a2bc2ec5000000"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0xfc5359a7d8561ed6f982e529a69e62cce04297366095a169631e7387d18b1d53","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x7fee6a21ce741e4fbb66a8c37ae6503da749d7dc1697054262e2af89d7b1d1f9","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[54], [addressList[8],addressList[50],addressList[0],addressList[10],addressList[28],addressList[51]], ["0","456874719","3000000000000000000","0","0","0","0","1531690024"], ["0x010000000029a2241af62c0000004e201000103000000000b1a2bc2ec5000000"], ["28","0","0"], ["0xfc5359a7d8561ed6f982e529a69e62cce04297366095a169631e7387d18b1d53","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x7fee6a21ce741e4fbb66a8c37ae6503da749d7dc1697054262e2af89d7b1d1f9","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1529148742 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0xba4f3aa3edf109e9622d293c2c65538b4f844a9ac4827a82d27b35c449cbc60d"}, {name: "_principal", type: "uint256", value: "3000000000000000000"}, {name: "_principalToken", type: "address", value: "0xe41d2489571d322189246dafa5ebde1f4699f498"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x00f34ad48a326b406bf995e04189e42d285d5773"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "77755722148913056" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[17], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5799905", timeStamp: "1529165193", hash: "0x1d0166b6399c5039169c172555164e48eb3d51c91aca71b96f4a07e7b3893ea4", nonce: "19", blockHash: "0x7a06a0b9d6ae21a92074e634be82293a80f3c14f753d3e2371bb570a917d4ec1", transactionIndex: "32", from: "0x800b7a428dfa0e7e478540fb06c07d0940414f25", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc9000000000000000000000000800b7a428dfa0e7e478540fb06c07d0940414f25000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f00000000000000000000000051343c13216afbbc0202b824ad532bdda1e222a900000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f2000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000f34ad48a326b406bf995e04189e42d285d57730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003904377300000000000000000000000000000000000000000000000ad78ebc5ac62000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b4b814e020000000ad78ebc5ac620000000afc8300010000000007ce66c50e284000000000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009e9c667c662ddff7aabaef277f651668a70a6a51838e3a122ea70d5933c262510000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000027fd1f9cc193e17a877fc7d8c6407da18cdc07b4b0fda1325918ac124028488400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1472426", gasUsed: "437714", confirmations: "1936680"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[17]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[12],addressList[0],addressList[10],addressList[11],addressList[51]]}, {type: "uint256[8]", name: "orderValues", value: ["0","956577651","200000000000000000000","0","0","0","0","1531674958"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x020000000ad78ebc5ac620000000afc8300010000000007ce66c50e284000000"]}, {type: "uint8[3]", name: "signaturesV", value: ["27","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x9e9c667c662ddff7aabaef277f651668a70a6a51838e3a122ea70d5933c26251","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x27fd1f9cc193e17a877fc7d8c6407da18cdc07b4b0fda1325918ac1240284884","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[17], [addressList[8],addressList[12],addressList[0],addressList[10],addressList[11],addressList[51]], ["0","956577651","200000000000000000000","0","0","0","0","1531674958"], ["0x020000000ad78ebc5ac620000000afc8300010000000007ce66c50e284000000"], ["27","0","0"], ["0x9e9c667c662ddff7aabaef277f651668a70a6a51838e3a122ea70d5933c26251","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x27fd1f9cc193e17a877fc7d8c6407da18cdc07b4b0fda1325918ac1240284884","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1529165193 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0x2d0fe5bfb4f6306f1f3a3e3d38ce50368d111165c774f9c77d71b242cb577705"}, {name: "_principal", type: "uint256", value: "200000000000000000000"}, {name: "_principalToken", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x00f34ad48a326b406bf995e04189e42d285d5773"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: cancelDebtOrder( [addressList[8],addressList[55],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5803084", timeStamp: "1529211780", hash: "0x888273529a5431a3a988c89df42a6b1ac0dc58635cb72b87c92f92613d9c458e", nonce: "3", blockHash: "0x34055517453141844a5b482b0e672a3ae3847a77edacd7f6b01d123e2880a875", transactionIndex: "89", from: "0xa2e112e4d1e50568109136d66d68121deeb25f09", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x20385f2f000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000a2e112e4d1e50568109136d66d68121deeb25f090000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b78a7d1c1d03cf9155cc522097cbc679e15cf9a3000000000000000000000000b8c77482e45f1f44de1745f52c74426c631bdd5200000000000000000000000000f34ad48a326b406bf995e04189e42d285d577300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000038d417eb000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b4ce75d06000000008ac7230489e800000186a020001000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7096537", gasUsed: "58037", confirmations: "1933501"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[55], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[55],addressList[0],addressList[56],addressList[57],addressList[51]]}, {type: "uint256[8]", name: "orderValues", value: ["0","953423851","10","0","0","0","0","1531766621"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x06000000008ac7230489e800000186a020001000000000000000000000000000"]}], name: "cancelDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelDebtOrder(address[6],uint256[8],bytes32[1])" ]( [addressList[8],addressList[55],addressList[0],addressList[56],addressList[57],addressList[51]], ["0","953423851","10","0","0","0","0","1531766621"], ["0x06000000008ac7230489e800000186a020001000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1529211780 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_debtOrderHash", type: "bytes32"}, {indexed: true, name: "_cancelledBy", type: "address"}], name: "LogDebtOrderCancelled", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogDebtOrderCancelled", events: [{name: "_debtOrderHash", type: "bytes32", value: "0x0ed4b1d8e1ad9c0f0f30bc4495bab387a6a8232591851de81f02c142893f9c17"}, {name: "_cancelledBy", type: "address", value: "0xa2e112e4d1e50568109136d66d68121deeb25f09"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[55], balance: "29420402000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[55], balance: ( await web3.eth.getBalance( addressList[55], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: cancelDebtOrder( [addressList[8],addressList[55],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5803092", timeStamp: "1529211924", hash: "0x803a9c2f2a01a9ee8c56ed35e13e23d00ef0f8710ce96bf468fd6e0fdb45c560", nonce: "4", blockHash: "0x8d16f4a2de3b0ff602c54da8771a5ae9037d0a6a6219decec28a3a715b8bc847", transactionIndex: "119", from: "0xa2e112e4d1e50568109136d66d68121deeb25f09", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x20385f2f000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000a2e112e4d1e50568109136d66d68121deeb25f090000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b78a7d1c1d03cf9155cc522097cbc679e15cf9a3000000000000000000000000b8c77482e45f1f44de1745f52c74426c631bdd5200000000000000000000000000f34ad48a326b406bf995e04189e42d285d577300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000038d417eb000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b4ce75d06000000008ac7230489e800000186a020001000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5496533", gasUsed: "43037", confirmations: "1933493"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[55], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[55],addressList[0],addressList[56],addressList[57],addressList[51]]}, {type: "uint256[8]", name: "orderValues", value: ["0","953423851","10","0","0","0","0","1531766621"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x06000000008ac7230489e800000186a020001000000000000000000000000000"]}], name: "cancelDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelDebtOrder(address[6],uint256[8],bytes32[1])" ]( [addressList[8],addressList[55],addressList[0],addressList[56],addressList[57],addressList[51]], ["0","953423851","10","0","0","0","0","1531766621"], ["0x06000000008ac7230489e800000186a020001000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1529211924 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_debtOrderHash", type: "bytes32"}, {indexed: true, name: "_cancelledBy", type: "address"}], name: "LogDebtOrderCancelled", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogDebtOrderCancelled", events: [{name: "_debtOrderHash", type: "bytes32", value: "0x0ed4b1d8e1ad9c0f0f30bc4495bab387a6a8232591851de81f02c142893f9c17"}, {name: "_cancelledBy", type: "address", value: "0xa2e112e4d1e50568109136d66d68121deeb25f09"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[55], balance: "29420402000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[55], balance: ( await web3.eth.getBalance( addressList[55], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: cancelDebtOrder( [addressList[8],addressList[55],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5803093", timeStamp: "1529211940", hash: "0xeedbc0144b66fdd067d74c90c4cb5714f13bdfac97483e5a94d01567a6878821", nonce: "5", blockHash: "0x13ebc8cfcbf04cdb13a46110957321cc1ec6ca23f05ca1e96f35216fb344a358", transactionIndex: "134", from: "0xa2e112e4d1e50568109136d66d68121deeb25f09", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x20385f2f000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000a2e112e4d1e50568109136d66d68121deeb25f090000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b78a7d1c1d03cf9155cc522097cbc679e15cf9a3000000000000000000000000b8c77482e45f1f44de1745f52c74426c631bdd5200000000000000000000000000f34ad48a326b406bf995e04189e42d285d577300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000038d417eb000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b4ce75d06000000008ac7230489e800000186a020001000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5429931", gasUsed: "43037", confirmations: "1933492"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[55], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[55],addressList[0],addressList[56],addressList[57],addressList[51]]}, {type: "uint256[8]", name: "orderValues", value: ["0","953423851","10","0","0","0","0","1531766621"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x06000000008ac7230489e800000186a020001000000000000000000000000000"]}], name: "cancelDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelDebtOrder(address[6],uint256[8],bytes32[1])" ]( [addressList[8],addressList[55],addressList[0],addressList[56],addressList[57],addressList[51]], ["0","953423851","10","0","0","0","0","1531766621"], ["0x06000000008ac7230489e800000186a020001000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1529211940 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_debtOrderHash", type: "bytes32"}, {indexed: true, name: "_cancelledBy", type: "address"}], name: "LogDebtOrderCancelled", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogDebtOrderCancelled", events: [{name: "_debtOrderHash", type: "bytes32", value: "0x0ed4b1d8e1ad9c0f0f30bc4495bab387a6a8232591851de81f02c142893f9c17"}, {name: "_cancelledBy", type: "address", value: "0xa2e112e4d1e50568109136d66d68121deeb25f09"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[55], balance: "29420402000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[55], balance: ( await web3.eth.getBalance( addressList[55], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: cancelDebtOrder( [addressList[8],addressList[55],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "5803096", timeStamp: "1529212031", hash: "0x05977450acd12eae6a902163448c01021280e53eed0a17165b181c9b6723e96e", nonce: "6", blockHash: "0x1b89346300eeda2dd559552b7ea5c2d6eabf0e67f619b39ec10188f49561d64e", transactionIndex: "190", from: "0xa2e112e4d1e50568109136d66d68121deeb25f09", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x20385f2f000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f000000000000000000000000a2e112e4d1e50568109136d66d68121deeb25f090000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b78a7d1c1d03cf9155cc522097cbc679e15cf9a3000000000000000000000000b8c77482e45f1f44de1745f52c74426c631bdd5200000000000000000000000000f34ad48a326b406bf995e04189e42d285d577300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000038d417eb000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b4ce75d06000000008ac7230489e800000186a020001000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7081500", gasUsed: "43037", confirmations: "1933489"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[55], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[55],addressList[0],addressList[56],addressList[57],addressList[51]]}, {type: "uint256[8]", name: "orderValues", value: ["0","953423851","10","0","0","0","0","1531766621"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x06000000008ac7230489e800000186a020001000000000000000000000000000"]}], name: "cancelDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelDebtOrder(address[6],uint256[8],bytes32[1])" ]( [addressList[8],addressList[55],addressList[0],addressList[56],addressList[57],addressList[51]], ["0","953423851","10","0","0","0","0","1531766621"], ["0x06000000008ac7230489e800000186a020001000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1529212031 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_debtOrderHash", type: "bytes32"}, {indexed: true, name: "_cancelledBy", type: "address"}], name: "LogDebtOrderCancelled", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogDebtOrderCancelled", events: [{name: "_debtOrderHash", type: "bytes32", value: "0x0ed4b1d8e1ad9c0f0f30bc4495bab387a6a8232591851de81f02c142893f9c17"}, {name: "_cancelledBy", type: "address", value: "0xa2e112e4d1e50568109136d66d68121deeb25f09"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[55], balance: "29420402000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[55], balance: ( await web3.eth.getBalance( addressList[55], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: fillDebtOrder( addressList[58], [addressList[8],address... )", async function( ) {
		const txOriginal = {blockNumber: "5804697", timeStamp: "1529235357", hash: "0xfaafd7e022ad19154d20430dc7ec2a7a927d1cfd513648b43ad9f8ee59568700", nonce: "55", blockHash: "0x3d29e7f9a118f7281cd3c6236f2f03336894aad56e4ef1b39da06da1993368e7", transactionIndex: "62", from: "0x25763b7f6248bf02e269038c58726460851dc65d", to: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18", value: "0", gas: "600000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xe6488fc900000000000000000000000025763b7f6248bf02e269038c58726460851dc65d000000000000000000000000c1df9b92645cc3b6733992c692a39c34a86fae5f0000000000000000000000000006e4548aed4502ec8c844567840ce6ef1013f500000000000000000000000000000000000000000000000000000000000000000000000000000000000000005de2538838b4eb7fa2dbdea09d642b88546e5f20000000000000000000000000c02aaa39b223fe8d0a0e5c4f27ead9083c756cc200000000000000000000000000f34ad48a326b406bf995e04189e42d285d57730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003494f21a00000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005b4ccabb030000000006f05b59d3b200000b71b020001080000000000000000112a88000000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009febd4ea53dc346e2b53a7619a688263fdb1df0d513a32c6d96f875d34411f35000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006bab3903b9d9cf170406480b3ec8d71c94531746b565341aac0486614575f13300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4836443", gasUsed: "466130", confirmations: "1931888"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[58], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "creditor", value: addressList[58]}, {type: "address[6]", name: "orderAddresses", value: [addressList[8],addressList[20],addressList[0],addressList[10],addressList[36],addressList[51]]}, {type: "uint256[8]", name: "orderValues", value: ["0","882176538","500000000000000000","0","0","0","0","1531759291"]}, {type: "bytes32[1]", name: "orderBytes32", value: ["0x030000000006f05b59d3b200000b71b020001080000000000000000112a88000"]}, {type: "uint8[3]", name: "signaturesV", value: ["28","0","0"]}, {type: "bytes32[3]", name: "signaturesR", value: ["0x9febd4ea53dc346e2b53a7619a688263fdb1df0d513a32c6d96f875d34411f35","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}, {type: "bytes32[3]", name: "signaturesS", value: ["0x6bab3903b9d9cf170406480b3ec8d71c94531746b565341aac0486614575f133","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"]}], name: "fillDebtOrder", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillDebtOrder(address,address[6],uint256[8],bytes32[1],uint8[3],bytes32[3],bytes32[3])" ]( addressList[58], [addressList[8],addressList[20],addressList[0],addressList[10],addressList[36],addressList[51]], ["0","882176538","500000000000000000","0","0","0","0","1531759291"], ["0x030000000006f05b59d3b200000b71b020001080000000000000000112a88000"], ["28","0","0"], ["0x9febd4ea53dc346e2b53a7619a688263fdb1df0d513a32c6d96f875d34411f35","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], ["0x6bab3903b9d9cf170406480b3ec8d71c94531746b565341aac0486614575f133","0x0000000000000000000000000000000000000000000000000000000000000000","0x0000000000000000000000000000000000000000000000000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1529235357 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_agreementId", type: "bytes32"}, {indexed: false, name: "_principal", type: "uint256"}, {indexed: false, name: "_principalToken", type: "address"}, {indexed: true, name: "_underwriter", type: "address"}, {indexed: false, name: "_underwriterFee", type: "uint256"}, {indexed: true, name: "_relayer", type: "address"}, {indexed: false, name: "_relayerFee", type: "uint256"}], name: "LogDebtOrderFilled", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogDebtOrderFilled", events: [{name: "_agreementId", type: "bytes32", value: "0xeeec9cefe88bc5b574d1c04cb7a15c1ea81f354878c980edd3d73ba31628f34f"}, {name: "_principal", type: "uint256", value: "500000000000000000"}, {name: "_principalToken", type: "address", value: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"}, {name: "_underwriter", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_underwriterFee", type: "uint256", value: "0"}, {name: "_relayer", type: "address", value: "0x00f34ad48a326b406bf995e04189e42d285d5773"}, {name: "_relayerFee", type: "uint256", value: "0"}], address: "0x8ef1351941d0cd8da09d5a4c74f2d64503031a18"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[58], balance: "11486211157126863" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[58], balance: ( await web3.eth.getBalance( addressList[58], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
