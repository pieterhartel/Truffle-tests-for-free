const DemeterCrowdsale = artifacts.require( "./DemeterCrowdsale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "DemeterCrowdsale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xB8Eb17dfa4ec9A6457e4c8FB3D724C0Ed9ba4CF0", "0x867D85437d27cA97e1EB574250efbba487aca637", "0x70323222694584c68BD5a29194bb72c248e715F7", "0xE43053e265F04f690021735E02BBA559Cea681D6", "0x002Fe928c25A5A5D4E919730f27925d24B2410B5", "0x18061456803b185583C84780C55e667BC7B71F7D", "0xEE73E05D0Ed780006063C0e34C6d0bB24F04a6bE", "0x6958165b082D5b83E24b52a8D1835065e2DA00D2", "0x000Aa542e1adb7c96ca7F17Fc432Ea4c1972d54C", "0xdd93D95901e8C7228Fe0f59a1B48Ed5070f0EEC3", "0x63623d46b3676e509BF0Ebd11d6F160Cf8b50d01", "0x5eB83C9f93eeb6BF6Eb02a1aa9A0815A03C53B2a", "0xa3b2f88eAF0E65e5a236aE3950c99f823e918cFB", "0x857D27B63Cb4fDE55AB840eaCcDd8513AE1e324B", "0xf42F8e411fe3f19e558cFa076A1052683e292d8E", "0x7a3891586659754fA936cdf4736dfF52247a39FB", "0x881d07030D714A9C5D469B9171CB62110DA351b5", "0x1c4F5E82Dac438c7F8Cf47B4f237FAED93b43b16", "0xf939ca38eA22bae9c2962F38Ee837a38891af970", "0xC8DfCC7F50fDab8Dd1E68FbCa27c3Fed4e114e86", "0xA13c0F9d92c9528BB79aF95Af5C8d348B283fe6a", "0x1755869d0b086738FdAACFCd342dF6b85fFa0C9a", "0xbE45c52566af3325CE2f31b90b456E8AfFDfd154", "0x846aB25745C5349473c34d56365017071B47b79E", "0x80fcfdd18c0b83a1827f5964D4D1B214Db16aDc5", "0xcbA9893e77b387Cee319980a418E8751880a8B91", "0x32Be343B94f860124dC4fEe278FDCBD38C102D88", "0xd90eA6bb71A83952160536B6d3d35035cfD709A2", "0xa6384118370B7Ab77067d6F1d2Ced2EB4a4334c1", "0x42B964b851740DA9dE829ed7027dC8560B4ab01A", "0xd5C56952e1Aad42f20075666b123F42334969297", "0x7Cd3eBe1e2e11F8cFDd07326Bc700d52EE5AeE89", "0x09016aB9f549B6828afCB6878aCC33AE00c9a2ae", "0x75750D0BbA74ECb961Fa588873A0EF69c54361c1", "0x3bDBB23B42E2DCF045c49C4DE43EdF93E991f2f5", "0x193724Cd4e4CDD37CCb7B4Ee7c94c45b5963ed3C", "0xDe582fbb8482576dD35FaA8879B1Fb904794c4b2", "0x2b616914adA8484Ab9D70398dBE86B029b1a9a39", "0xE7872E618b00c88d7c1450F5D656AFC152c0e180", "0x3e7ec755Be89B83d00b15d540cE38d6Dbfc10557", "0x3802DDa14645De66EB3cC13c14f9bDB669d717Ba", "0xD47C67E9829BdEFC1bb27c4e364ee9aCc1003d84", "0x56E99e3F9e68656b830A20aD46e5c2f5384EC7D8", "0xe286ac47Fe66768acFf597C0D9dC36BF3c676f65", "0xc989e2A6dCa5c7Ef02c69033740579f4e05bd975", "0x74231d64aa97949334fD9AaE6Db4C8C7707BAc4D", "0xfAe83D59634892ae1ac19c8e28493ae1628d691F", "0x50fB6237364aE15E0D097ca868765b0891a212bF", "0x5CaA66408617F77601d0DC19C163621E7f4B8B38", "0x1b859Bb7b022e34DdAB72d541881a2283f60d567", "0x4fd55f56dAcE98c59E095D35b8B6a11E7276F48e", "0xFC4b3E7AEE17c6F523859cacdda947937bd34662", "0x790622728897B6367b7A8709c5f69d3DbD105072", "0x00F0e5b8FA6d8cb1e5CbEdc4D4A6B92BC81B4aA3", "0x6D569e92d1f0B4Fe25152b4ab53c5cC303854659", "0xa4C6C4050A25a397f59B02B7ACE3b6dbF4DF2361", "0x62c66FFcd2C7063396Bf8C159b7E836e85B00605", "0x2eBc91ACDA66Ef683CB8931F7599dB9c54908d19", "0x05344DDCe68acb0Bbed1c3e392c7bcFd4be4258D", "0x9Ae5010e64D8206446f97C500b518A9f8588300f", "0x6a60fCA2aCbE8d4cd3dc0bfC01B496d02fFE1697", "0x3D8573232BF13860f991a4BB072298df4eBd3b97", "0x13619e9E15Bd01d9a6DE72A394052Dfaa9f30Ae7", "0x1B87C2a6058BC88548Bc9bB18b0717f939B2CCB3", "0x63CC9097751E144BA4b6Ea2cc7A5D692297CA85E", "0xdcDe00E24e44d0291C656d7ad16465289365Ca03", "0xb43Af95f19c691d43ed1729eFa02F064045828f7", "0x26F471fF52759A8bEAA07c55E694a2f64a343614", "0x8eBAEb59c6767331caDad731152009cFC12Fb1C1", "0x17cffE843f348D9E0FA9Cb4d0a216c42999Ae9Da", "0xD1a25310eE726685710aE52c56Bd14D2eE484C11", "0x72aaA61E51534668c134aFc072c60E8734b7ce11", "0x727f349750b7E361dDF2777569409433543FE309", "0xf04a37F79b1628A2c1e52bF38FEc8d2AbcE0D415", "0x1cdbC8917Dc7D3c4C21a66bF2F0AcCE0D6647327", "0x4Db05a8400Ca968EBCa86f68AffF63dc0a675963", "0x7d7C35f479A9dCBe5A0fB43b4645F46107A4F4c4", "0x53624E85e5f4aF6072eC2f5D2D70e30219708BB8", "0xeE2AB7f1146C5141920A800D6a057Ee9289820De", "0x379779B7F0084790e7987eA99Ac5b90d90fFF4d6", "0xf9DF2fde9399Cc5bC4920Cd7FB004E35E0acACB7", "0xF369bAACC7ee1E87B9b555C27885c6c05578283a", "0x66e86FdC814Ad464b5578A44499c8518c5574737", "0xd3Fd65adE652ea370ff5E2beeF3BFde928747974", "0x1016395A5E2fAf753BDe87D110a19aC3047bb107", "0x8784477dF76f9A7cb0FE393064DcC954A01F1D4D", "0x125C34c67ccE888d3692ed51B14ec7101A74E0E3", "0x150f8879fF63AEB8C6FfC08f18656B712F06bbe3", "0xda5B5F574D31b71D4F985fA4be142e0edD0B1Ef0", "0x2CB35bC2A9B6cedeF5Ac41D0Bb8b73D4C558aF13", "0xcA18E65CD05C8086d6Dfe4023243AC92a15A8162", "0xdf56648816c6571497ee9A05063c2C601f9d2382", "0xBcE1a30831BbCA59Dd11495595e6bC1Cf81B938C", "0xf47Bf659fB71a96F1C16119B5Ce0098f821d84Ec", "0x933d9f8D7D82922591Bd5c3962e5B15743B1dc04", "0xb890305a848fB073b1e2d51C5Fd67b70063A0003", "0xA51B194b4f2dDb5dEC4a4bE6B8A351DbEe5F6750", "0x52f0E7dD5856a31333a4C4Dc1311f35b67c7aB3B", "0x7CAA9e3c74D6c05655Ef2fb390721EDfD921d7A2", "0x8f9F54E76Bc081c06E33BE89E03581B4Ee79A637", "0xc1A2A12d2Ee0cbDC25Cd78Ae13Ad6028aA92C566", "0x2D27c26f482Ee0D508Bba64A4154dBcDcBc24921", "0x677d4197db9FB03b7bB4217DFF4Eb91782C78913", "0x66FF4b146431183D249aFF97b08DB4EEab46f448", "0xFADd0a0Eb3752b0171b3394d60c8b09FAd24bAa8", "0x5DC3b8898370E270779c3548Eb440b337471ECBB", "0x27CFE2cA121B83882578F80B3AF1E60E02D1Fe72", "0xfeE1CF7535bfE00c5FAe39dc4fB344312697cbcb", "0x91EfEe37bD22c6C6b6a9e68602cb160D0E7A9b66", "0x22aaa7456421Ff99C8cFA86318c5A1e969Eab40e", "0x2324E70cD0b592B85167A18a9Eeb391703596AC6", "0x670f948320b7eC3d6f9065C3236F9083D7c4a908", "0xd553F3A4cCDc7543eb5448ff0307906c2a541ED2", "0x10890B4482BFE354dd67CFDadF031724429a5f43", "0xC6d68Aa54686B7c2bEf252f1aC0DC906fe1c6149", "0x3733b1a7ebF5C4A5Ef81A66036b2856d9ef79C94", "0xB8Ab558137940a9265B2A8B6D5A738aD61b11C3a", "0xE133614D5E772a520bD03c488663266eBb3849c0", "0x32e214cA890d6d280E267b35B03d6B6b59a8C64C", "0xADa0505e97915A069025DEE3025C0026360CeF4a", "0xfe2Da16FB6f12575D5E9329Fd3d26265E4b52004", "0xF6bbC43c2a2C8776C8C9Db58DcBD6413c1CB7923", "0x7408c65285478C3Be8c392dD62D8956715ebD55F", "0x12107554D83727cb8533a82cD68B85601054d667", "0xCC5E37A4851eE3Ad545fa8aB96aF23C7D0bCA87E", "0x6Ade98240e2449d0D502Dfb11F80B4870a5A5f3A", "0x4593b3c06A42E932DBC8A7627fD84DFA1C7F9F53", "0x3507A375464348D3AfF4fD4df5C3134235755178", "0x11eA5E932D361838685C4e1bC48c399981AEE100", "0x4c82a07e4827436F86aDa9FB87162A5e52eAcecf", "0xcDC01AbaEEa88dB6a69EDe3513389DAe3f5f83f5", "0x0b196B342fc35Ce0892B76B320d215Ea7A8B4687", "0xd3E33aF45e30F30Ac9C37376371aB93E657b495D", "0xEE171a52EF989116A6E76DaE11C73bF13C9032c1", "0xe6c263da32022242817985cf3D44bbc71E519789", "0xc0ba12C217f7D6983C6F21e33B434665c1c70849", "0x4Ef730C459a1A42ef59156589396627b71131586", "0x63F48C2FC60764AbF1E7a429d52e6E04cCe94AcC", "0x39b18e24D79bE0D658fc916AE7d4722343dE29f1", "0x64127CB3d9008965c5982E4AcdF91c6AeF7222b1", "0xb4F7a89b0f97A7573AC9d200Ab4490456e9e9725", "0x88330EFB596e94d70726e0F99a33D94497E80D0b", "0x48476B6c003E5F10686D21d2E8362F1aD64B3fF9", "0xFbd27D9c8026828E9b6792a32E57435C7702B28D", "0x541C536625F1c0b22794449f90fd0Dd68622d37D", "0x64825dE50505832d661E1e461F9Be6cA005B63e4", "0xDfc66B1079B502de715Eb6ba7E6224d91ABC6a98", "0x91f4bd5aaae4c18Da51B552beba178e2902cD990", "0x451aaAaa9f1E7E264FDaC6BebB991Fb48f3Dc057", "0x976f4e810F0719CD1C7654E612B8d236cbbb6812", "0x1E4D6653bBCddd527d6679170Af3320a83c65E6D", "0x97e987F98D478a445deD36140fDA6eDC4af7182c", "0xacB8f16A62A9d98212DfBe57b0D501a5c6B08b04", "0xA9C0b993D91e32D53Cd627F8bC5e2744f13c0E5D", "0x8cCD03603F453aeA792dC9d9d125ad47a8297c66", "0x58Ff2641A79Eb0858fb79bd961A3F10bD89d811f", "0x8b144a8586457aEB6C2193196cEc35eC3387D9b9", "0x71baF1e614e271dDd075Be548384dF512B1ae134", "0xBDf2294F6eCb5D96b15d62Af8472aFa6d799ff80", "0x6d19bb2A7F606E3527Db16cC6A8e0Eda5Bf5276E", "0x94781af1f0732A5186cfCe41b96fF55a8C44FA04", "0x1C9D9D9D65143237350Bd56446bE632070D6A5b5", "0x66c4bebd810518237E3f726232aAabc390A48527", "0x2f7189ef76E575976Fbd6961107F9aD633fB1ad9", "0x7d6201CdA0b47Db7b859240f00e6056aE03c6139", "0xC3651344e7839f124F7A64d7fCc1F615196F90a0", "0xC6Ec1d13b2405D480DF398628d0bF9067D82c9b6", "0x92793df575FA41ff83b6D8845c5898d0c92304c8", "0x1C2BbDbcD9CdB3Bd8d2DC082C12B8d2b3662274C", "0x6001c916e5a6fDD8f4dEfc36242759FE5D2B2A3B", "0x0cc85E04b156D11AFC983240203b94CA8D98B076", "0x1e28F669a710675cc44FC2386078B08BD4B2cba2", "0x554Ca18a0c69DEcace1Cf54AabE52cF12e25a87a", "0x5B598Bd240943Da4fAC91fF99eeEc020d860Dca1", "0x8C335D35004B4bA3dC2221d09C02c19A35DAD8b5", "0x3fFad1b916B29A20D99BD90f9302B2Ead464e415", "0x08B1D5C43f9777eE3F0874B70675dd7143Ef1216", "0x58B30DbD4668779De330eB31A9392d7146117f61", "0x5D13Db1e7916e66c4676Ff41b3B14F3906002AD2", "0x510A867d61A2Afe88Ef381BFe286D71c481F916E", "0x08a3B015E77E791FA2F065468b3F4d51f4157F33", "0x55ac8215cC397b1216088b7b7cA8138CCd05727F", "0x163D696432A4d689d15861b5a6C59f36c757b9F2", "0x89b335E2093BF261E4573B1A7EC57e5b9fACAE8D", "0xdD7112b9aAe6c75Dfd349024E452Be1a279b61fB", "0xFAB5C18DF15Ab7cAD0a8451f7fB35B054856f418", "0x61598890Dbf4294E431E98D6F59de5c0A4636623", "0x3361B0E1E334177f5ca6749AcA7449939a67b2eB", "0x4d3bAd2364A2c0d959f295066281185515bC1183", "0x1CAefD9588d2F5A891093E00AD6f7048506C8Bf0", "0xc25d196C89B46b70a2DB57310951e76e7290Fa2b", "0xadC9347848592FC0D9569335b224E6a253Cf44a7", "0x64BA3F02378FFf800952db01b646BC611FA4158f", "0x1eFe29d4fc3c720BD0E2b2a0f714c82d250A91b2", "0xaA2F9AF22397330Cdf8c1CA3fA1fc48592E7E0b7", "0xB44E835471D78d19bbCc56Eaf0A2556eEb2f811a", "0x898eBae28305f61f2d5446B92799Cf4d20890BA5", "0x4A959743ac5A5Ca4042Fe38c6d2dae94a5Aa543C", "0xf0c49021326D76fFE3b99B9055ce0616642961A8", "0x210Be71DCc7014427EbCeEA6f156807eD423227a", "0x7c51a1d131e915F5c3FA30816719eCEfB723Af22", "0x757466e1f746116efeC6C7c75022cEA11d9Eb9e3", "0x5b6Ea7FD78D3994a09c413aA48131257c73b7948", "0xd5159e2b8D9DC1Ec0352E24663402643a62f9d6C", "0xB737Af9B213Da3dD1BcC9E336421087dA6d88343", "0xB96Fd763500d2f3710FD19884A99886264cA15D1", "0xF804E840FCE9D62C8332BbEb6a43E4e7930f6CF7", "0xFf80DDdfda46EE987031c5A7E33520cD69952F96", "0xfD24D5f821cDEd9d09adeFa2D429115fe0f5aCec", "0xBAE93E299598c76FF5393860838684DFEbB3EAA9", "0x7bE7Cae4fD8c14A7c4e9153219DCd6b98ad5a206", "0xFE96087e0984a0bf74125Ad88f4150B9225bF318", "0xdA8301e930C47db3e1B5d7784420F89A74d714C6", "0x135fF73faccb5157E44C9f518e78Fba98b453d45", "0x8F01EF166001cE1a3eF072D755998a9CE25546D8", "0x3f27012224b8bd89f74fEe93bFbbEf579686923b", "0x0dB078365Ec8E8a32b15FEd6040d56e9B298369E", "0x1f44CE9475B9430Fe7DB7204B5ec62f6cB8893e9", "0xc1fd9e33539eCfec2A39F1Fb2d42f639CA0522d6", "0xba0D9EF20FBA7d204e2408d78aF19377413fBF45", "0x52faBdBd0853aab04C954e1e82Cb62D6C9E59B51", "0x2C5fCaE84ed0d872946bd3ad7C0ca3124220673E", "0xA525EC304aC1C908F9c37B4C8de775c78C629B1C", "0xc23925285932870e5802C3d2559ed11eA459Ac0E", "0xE733380Fbb195d728Bfc3708c526cd1Ce32208F7", "0xD1f31cb5c87A2558D7bFE19F39E466EC47f706ac", "0xd96f674B234978daD7a14d2bDc4AAeB40548cE42", "0x217ca634Eb2Ebb088aF1c2fF1a15183C6a7235f6", "0x0a40445D48e74F747e24eC046e9977811815d7f0", "0x8c9adc7494b7f3898C2964dD5aBD3FCD45121632", "0xA4208c7cA8b733E9d3Fe016bF7826EE0A0a530fa", "0x91547E77F3d162c3975f8847F91bBC284F77c322", "0xe70b477D853C4d97A6DF3879a65beE52CD65F4b8", "0xB915B2Fdd584001061e82Ce130cFdB3114d43223", "0xA502dDb91161080C8D3B30BFAb128a6De7d60BBC", "0x3b394a541681aA4e21075a938B284e20D29533eA", "0x1D0676ab90E684E9c70c96a8691c2c993eEc2dA8", "0xBD8ba7A166074cf41A375b54109e12103D6aff25", "0xAcDB574E86AE4A9406a49c04146B067b9Ef4142d", "0x1544853ceAE12634ed1d23d09fc970acD010a32B", "0xe534339f2132b820626bdfD7316816e683FDD206", "0x1749238D844248094aE1FD54bb79750b45836E4e", "0x57dE22737C5a7580a612E8b2477e3B691D8a7E59", "0x253454fDf97a3fc23503442A4bf5692D54acf6CC", "0x1AD26339EaE968567BDb910aE5248890351CCE6f", "0x525f8B26E54279F949DBeF9Bee029D2c2fF39820", "0x16BEf1F16d4ea8901ec2ca46200abcc784604fFe", "0x892fD9376606EFdE0078Bcd40C11FeF1AaB17FBA", "0x4A71789C84288e631078f7042d40b4c869693997", "0x19f7174465f4b4dc01a13d333746a56E12Fb3cd1", "0xBF69aDe5876a6971c8d0400654fca5E4C96E67D2", "0xb06045212D6548f9b42cC62d87698D55d44E913C", "0x2C68E65544AE4Bd038819c774A334466155c1519", "0xe5D2A2b3fb2818e0257E151AE5A95dFAad1A25d6", "0xd535500c81d422899da23f79173C80a0e741ef1E", "0xeB4c058D2e9E95010a1479e32DEc7ECCC77B0E3b", "0xdBa56802F4BA5d32f7D2fDfB53E1b4b224321544", "0x7e319a56e15ee9723c175684533e0042605d2FaD", "0x89d6C9616030713b0CF8348583Ac66b6D938bad6", "0x98F51b2a996c759399D2Fb440CaCdcf762023906", "0x9823AAE6074aA8C5eE3AD6C328EE36ec6305d9f4", "0xe01228e2b29e52705dB28b137F6e92AD2887B9c1", "0xdB156c95CcE17414195a724633E54edB1cB43484", "0x79b384dCaaBb6212C93334441A89EbC18816460E", "0xd1a5332794922d273C33a08345f18dfAa692ba04", "0x3C0f7Aa72CD452120ac15A0E6D1db79A03dbC112", "0x7a43182D3bdf978e161eB117c0eAb864D4f03220", "0xAf6FB60BAcdF00aB17DFe3f55376d5B47B3887f3", "0xc2Cd2a679B80e76D644357D15a0e4d194eCE4Ed8", "0x721a2042014805eb429cdc1E4e76FbB243aFdBF0", "0xc47980d52E421809698ffFf62F4c0F9db6F11913", "0xbceb22A26B1518e47ECA45600cdE20151BA0B3b4", "0x7cB57B5A97eAbe94205C07890BE4c1aD31E486A8", "0x7dA1CF9360Df990E55040187a36D11f88451BccE", "0xdc47494e7B58E0C8845Ae0670F7647Bed621Eb18", "0x89eb2b388B79f482400FF854fa35F54E1bCE833E", "0x41234FEaF2eA263f2Ac8d77314a96229e49CeD5e", "0xecD097Dc8C5609DE98E17FCAbd5f79DeA2Ba5780", "0xD927549bcBd42861c5be9ab2464d82E72b475691", "0xD1C42b9f7d4C8D056bC72ec3d43a984C97E3FE31", "0xf302e2678ddE2a31481d3987172Ab44541daE98F"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "PERC_TOKENS_TO_RELEASE", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "rate", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "DEV_WALLET", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "endTime", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "cap", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "PERC_TOKENS_TO_INVESTOR", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "goal", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "PERC_TOKENS_TO_BIZDEV", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "BIZDEV_WALLET", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "isWhiteListed", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "whiteListRegistrationEndTime", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "startTime", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "goalReached", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isFinalized", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "RELEASE_WALLET", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "REFERRAL_SHARE_RATE", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "WHITELIST_BONUS_RATE", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "PERC_TOKENS_TO_DEV", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "whiteListEndTime", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "hasEnded", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_investor", type: "address"}], name: "isReferred", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "vault", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "investor", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "CompanyTokensIssued", type: "event"}, {anonymous: false, inputs: [], name: "Pause", type: "event"}, {anonymous: false, inputs: [], name: "Unpause", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "investor", type: "address"}, {indexed: false, name: "referralCode", type: "string"}], name: "WhiteListedInvestorAdded", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "referralCode", type: "string"}, {indexed: false, name: "referredInvestor", type: "address"}], name: "ReferredInvestorAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "ReferredBonusTokensEmitted", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WhiteListBonusTokensEmitted", type: "event"}, {anonymous: false, inputs: [], name: "Finalized", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["CompanyTokensIssued(address,uint256,uint256)", "Pause()", "Unpause()", "WhiteListedInvestorAdded(address,string)", "ReferredInvestorAdded(string,address)", "ReferredBonusTokensEmitted(address,uint256)", "WhiteListBonusTokensEmitted(address,uint256)", "Finalized()", "OwnershipTransferred(address,address)", "TokenPurchase(address,address,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x83dcecd3eb3b32c8d288cd062e56204c514bab3cdcf40c1d4130c6d9f6b5f3f6", "0x6985a02210a168e66602d3235cb6db0e70f92b3ba4d376a33c0f3d9434bff625", "0x7805862f689e2f13df9f062ff482ad3ad112aca9e0847911ed832e158c525b33", "0xcb85f1750810a7229e5c354d153e69d70f87c6d2e8219188712124963d9de654", "0x8616865d2d8ce22dc92429061830ce6c73e8bb80a4a75af97374286c5ef3a6c7", "0xd12d5c47a71f54749782a6eb58dc14cc4f3a23e277983ac722e205492ba8f2ca", "0xe3e5c9c13d6f5f6153efb3eb09b7a3111111b6f4f309b6105ff49176a52a4514", "0x6823b073d48d6e3a7d385eeb601452d680e74bb46afe3255a7d778f3a9b17681", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0", "0x623b3804fa71d67900d064613da8f94b9617215ee90799290593e1745087ad18"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4563779 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4593835 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "uint256", name: "_startTime", value: "1511002800"}, {type: "uint256", name: "_endTime", value: "1513594799"}, {type: "uint256", name: "_whiteListRegistrationEndTime", value: "1510743599"}, {type: "uint256", name: "_whiteListEndTime", value: "1511434799"}, {type: "uint256", name: "_rate", value: "2300"}, {type: "uint256", name: "_cap", value: "26086960000000000000000"}, {type: "uint256", name: "_goal", value: "4000000000000000000000"}, {type: "address", name: "_wallet", value: 7}], name: "DemeterCrowdsale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "PERC_TOKENS_TO_RELEASE", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "PERC_TOKENS_TO_RELEASE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "DEV_WALLET", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "DEV_WALLET()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "endTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cap", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cap()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "PERC_TOKENS_TO_INVESTOR", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "PERC_TOKENS_TO_INVESTOR()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "goal", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "goal()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "weiRaised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "PERC_TOKENS_TO_BIZDEV", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "PERC_TOKENS_TO_BIZDEV()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BIZDEV_WALLET", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BIZDEV_WALLET()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "wallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isWhiteListed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isWhiteListed(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "whiteListRegistrationEndTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whiteListRegistrationEndTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "goalReached", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "goalReached()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isFinalized", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isFinalized()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "RELEASE_WALLET", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "RELEASE_WALLET()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "REFERRAL_SHARE_RATE", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "REFERRAL_SHARE_RATE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "WHITELIST_BONUS_RATE", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "WHITELIST_BONUS_RATE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "PERC_TOKENS_TO_DEV", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "PERC_TOKENS_TO_DEV()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "whiteListEndTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whiteListEndTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "hasEnded", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "hasEnded()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_investor", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isReferred", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isReferred(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "vault", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "vault()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "DemeterCrowdsale", function( accounts ) {

	it( "TEST: DemeterCrowdsale( \"1511002800\", \"1513594799\", \"151074... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4563779", timeStamp: "1510840449", hash: "0x98cbd256af7a530029539e48efbb5ea74eac531797352fe8e7843137c1053735", nonce: "7", blockHash: "0x7debe3a4baedd74a7c4009f547a1c553a1e3817c484be0f4f09fbff9cbc4a722", transactionIndex: "6", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: 0, value: "0", gas: "6500000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc393e09b000000000000000000000000000000000000000000000000000000005a1012b0000000000000000000000000000000000000000000000000000000005a379faf000000000000000000000000000000000000000000000000000000005a0c1e2f000000000000000000000000000000000000000000000000000000005a16aa2f00000000000000000000000000000000000000000000000000000000000008fc0000000000000000000000000000000000000000000005862d4ba15cc03800000000000000000000000000000000000000000000000000d8d726b7177a80000000000000000000000000000018061456803b185583c84780c55e667bc7b71f7d", contractAddress: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", cumulativeGasUsed: "5531446", gasUsed: "5370603", confirmations: "3176805"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_startTime", value: "1511002800"}, {type: "uint256", name: "_endTime", value: "1513594799"}, {type: "uint256", name: "_whiteListRegistrationEndTime", value: "1510743599"}, {type: "uint256", name: "_whiteListEndTime", value: "1511434799"}, {type: "uint256", name: "_rate", value: "2300"}, {type: "uint256", name: "_cap", value: "26086960000000000000000"}, {type: "uint256", name: "_goal", value: "4000000000000000000000"}, {type: "address", name: "_wallet", value: addressList[7]}], name: "DemeterCrowdsale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = DemeterCrowdsale.new( "1511002800", "1513594799", "1510743599", "1511434799", "2300", "26086960000000000000000", "4000000000000000000000", addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510840449 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = DemeterCrowdsale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: loadWhiteList( [addressList[8],addressList[9],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4563959", timeStamp: "1510842929", hash: "0x5a38c7efc9b595bcf014b9db50f03f0e7ef4781d429e94f1308d6c9c2a2f1d9f", nonce: "8", blockHash: "0x8ef8fc62dc58c826570e4295304198601c205003f4d53fbc19886432e1fda8fa", transactionIndex: "96", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "1183411", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xe3fe48a1000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000003a0000000000000000000000000000000000000000000000000000000000000001a000000000000000000000000ee73e05d0ed780006063c0e34c6d0bb24f04a6be0000000000000000000000006958165b082d5b83e24b52a8d1835065e2da00d2000000000000000000000000000aa542e1adb7c96ca7f17fc432ea4c1972d54c000000000000000000000000dd93d95901e8c7228fe0f59a1b48ed5070f0eec300000000000000000000000063623d46b3676e509bf0ebd11d6f160cf8b50d010000000000000000000000005eb83c9f93eeb6bf6eb02a1aa9a0815a03c53b2a000000000000000000000000a3b2f88eaf0e65e5a236ae3950c99f823e918cfb000000000000000000000000857d27b63cb4fde55ab840eaccdd8513ae1e324b000000000000000000000000f42f8e411fe3f19e558cfa076a1052683e292d8e0000000000000000000000007a3891586659754fa936cdf4736dff52247a39fb000000000000000000000000881d07030d714a9c5d469b9171cb62110da351b50000000000000000000000001c4f5e82dac438c7f8cf47b4f237faed93b43b16000000000000000000000000f939ca38ea22bae9c2962f38ee837a38891af970000000000000000000000000c8dfcc7f50fdab8dd1e68fbca27c3fed4e114e86000000000000000000000000a13c0f9d92c9528bb79af95af5c8d348b283fe6a0000000000000000000000001755869d0b086738fdaacfcd342df6b85ffa0c9a000000000000000000000000be45c52566af3325ce2f31b90b456e8affdfd154000000000000000000000000846ab25745c5349473c34d56365017071b47b79e00000000000000000000000080fcfdd18c0b83a1827f5964d4d1b214db16adc5000000000000000000000000cba9893e77b387cee319980a418e8751880a8b9100000000000000000000000032be343b94f860124dc4fee278fdcbd38c102d88000000000000000000000000d90ea6bb71a83952160536b6d3d35035cfd709a2000000000000000000000000a6384118370b7ab77067d6f1d2ced2eb4a4334c100000000000000000000000042b964b851740da9de829ed7027dc8560b4ab01a000000000000000000000000d5c56952e1aad42f20075666b123f423349692970000000000000000000000007cd3ebe1e2e11f8cfdd07326bc700d52ee5aee89000000000000000000000000000000000000000000000000000000000000001ac675f3143c95b4923d847e1f2da41c2a399347c8b9a4e0b46ada99031078424160d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98e2cdff4aa348ef5926fce13425a908ece56b12f96e092a4b1795091ab399ccdd552df37c9209eec06a3dbdccee5b08a753a37c1a20b29c9123940cc8914ea4a73dce487fde64eac490cba05ad571f4cd62596d408ed023e2163b9af23441370a667e0473a6036889390dedffd6099094b5a04963023c4202817cdab302041eee2e14ae75b2cc56b117438b306a6d712a2bf615422f90bc9a8f3b9960ee38e977aa9858ec86a2ed63e31a714fc564f79d3c420524fbbdfd7bf4fa1e3db47fc1c8d73e6205a1e240229a23db457367df45fa67ee638344a9a61185b9f618cd01eb21236b13a5b3225b3d4477469b32f0ec1f4bba2e4847b8ddb0b29d8e4831c006f4212e6ae2c9a7368094a0564c668bb69697c904d539bfb1cf92a084e3c1dd132c98d440b2414b9b580f27cf462532190473b289246436dc9fdeb37e07f2bb3235fb4d9b035314545ca030bf106eabeda572fae05872031af6a21d7e50bebae82fde93dd15fc898aaaeaf41d8bba93be31e96625332822d99a5ca5f8550b12271b370d5ca776446d659d756023ed494a2f9a25b796fb779c4df16a87fc873a8288bb346ebcd05e8f28d289ebf0a9f0bee5f8960c134fb88ab381e5b618196f7f915ec6057a27657ac51c1dc5afa559efb79d88f1aa0db12589b1d4399e298aa8683d991c1fe1ec9187d03e353314c9e18931bd0666ca8bb5147b3e5bef7673d20463a3ac078cf54fc78cf7038d3f8dc4dbb0407ac3ca575b892f1df962122e4db82120188b8c88e3043682785fabc1e3a5df56dd5d9dbc28983e49c3e00311463d4ea452515440a9254892b17eca1fb043b10de396ac3544eb15245fc70907511c62015d128d75c689664002a75db98954f305ed1747b431676ed1d5bd1983385208708ca78ec2521b1165449c87f53d17469b588df3c2592359c1d7e4c61c5df04d8c9b5611956d59ec26019475b9776f5ca4f37fc760705fd8767598b27ff1cb7b0acefcd1c3e6826228962d85d092481d2b609a70f6727f750620317baa637bcd4d84af99ed0d5e739428bcb1fd70ca12f6690afba75241d86362184805b3", contractAddress: "", cumulativeGasUsed: "6389581", gasUsed: "1183411", confirmations: "3176625"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33]]}, {type: "bytes32[]", name: "_referralCodes", value: ["0xc675f3143c95b4923d847e1f2da41c2a399347c8b9a4e0b46ada990310784241","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0xe2cdff4aa348ef5926fce13425a908ece56b12f96e092a4b1795091ab399ccdd","0x552df37c9209eec06a3dbdccee5b08a753a37c1a20b29c9123940cc8914ea4a7","0x3dce487fde64eac490cba05ad571f4cd62596d408ed023e2163b9af23441370a","0x667e0473a6036889390dedffd6099094b5a04963023c4202817cdab302041eee","0x2e14ae75b2cc56b117438b306a6d712a2bf615422f90bc9a8f3b9960ee38e977","0xaa9858ec86a2ed63e31a714fc564f79d3c420524fbbdfd7bf4fa1e3db47fc1c8","0xd73e6205a1e240229a23db457367df45fa67ee638344a9a61185b9f618cd01eb","0x21236b13a5b3225b3d4477469b32f0ec1f4bba2e4847b8ddb0b29d8e4831c006","0xf4212e6ae2c9a7368094a0564c668bb69697c904d539bfb1cf92a084e3c1dd13","0x2c98d440b2414b9b580f27cf462532190473b289246436dc9fdeb37e07f2bb32","0x35fb4d9b035314545ca030bf106eabeda572fae05872031af6a21d7e50bebae8","0x2fde93dd15fc898aaaeaf41d8bba93be31e96625332822d99a5ca5f8550b1227","0x1b370d5ca776446d659d756023ed494a2f9a25b796fb779c4df16a87fc873a82","0x88bb346ebcd05e8f28d289ebf0a9f0bee5f8960c134fb88ab381e5b618196f7f","0x915ec6057a27657ac51c1dc5afa559efb79d88f1aa0db12589b1d4399e298aa8","0x683d991c1fe1ec9187d03e353314c9e18931bd0666ca8bb5147b3e5bef7673d2","0x0463a3ac078cf54fc78cf7038d3f8dc4dbb0407ac3ca575b892f1df962122e4d","0xb82120188b8c88e3043682785fabc1e3a5df56dd5d9dbc28983e49c3e0031146","0x3d4ea452515440a9254892b17eca1fb043b10de396ac3544eb15245fc7090751","0x1c62015d128d75c689664002a75db98954f305ed1747b431676ed1d5bd198338","0x5208708ca78ec2521b1165449c87f53d17469b588df3c2592359c1d7e4c61c5d","0xf04d8c9b5611956d59ec26019475b9776f5ca4f37fc760705fd8767598b27ff1","0xcb7b0acefcd1c3e6826228962d85d092481d2b609a70f6727f750620317baa63","0x7bcd4d84af99ed0d5e739428bcb1fd70ca12f6690afba75241d86362184805b3"]}], name: "loadWhiteList", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadWhiteList(address[],bytes32[])" ]( [addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33]], ["0xc675f3143c95b4923d847e1f2da41c2a399347c8b9a4e0b46ada990310784241","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0xe2cdff4aa348ef5926fce13425a908ece56b12f96e092a4b1795091ab399ccdd","0x552df37c9209eec06a3dbdccee5b08a753a37c1a20b29c9123940cc8914ea4a7","0x3dce487fde64eac490cba05ad571f4cd62596d408ed023e2163b9af23441370a","0x667e0473a6036889390dedffd6099094b5a04963023c4202817cdab302041eee","0x2e14ae75b2cc56b117438b306a6d712a2bf615422f90bc9a8f3b9960ee38e977","0xaa9858ec86a2ed63e31a714fc564f79d3c420524fbbdfd7bf4fa1e3db47fc1c8","0xd73e6205a1e240229a23db457367df45fa67ee638344a9a61185b9f618cd01eb","0x21236b13a5b3225b3d4477469b32f0ec1f4bba2e4847b8ddb0b29d8e4831c006","0xf4212e6ae2c9a7368094a0564c668bb69697c904d539bfb1cf92a084e3c1dd13","0x2c98d440b2414b9b580f27cf462532190473b289246436dc9fdeb37e07f2bb32","0x35fb4d9b035314545ca030bf106eabeda572fae05872031af6a21d7e50bebae8","0x2fde93dd15fc898aaaeaf41d8bba93be31e96625332822d99a5ca5f8550b1227","0x1b370d5ca776446d659d756023ed494a2f9a25b796fb779c4df16a87fc873a82","0x88bb346ebcd05e8f28d289ebf0a9f0bee5f8960c134fb88ab381e5b618196f7f","0x915ec6057a27657ac51c1dc5afa559efb79d88f1aa0db12589b1d4399e298aa8","0x683d991c1fe1ec9187d03e353314c9e18931bd0666ca8bb5147b3e5bef7673d2","0x0463a3ac078cf54fc78cf7038d3f8dc4dbb0407ac3ca575b892f1df962122e4d","0xb82120188b8c88e3043682785fabc1e3a5df56dd5d9dbc28983e49c3e0031146","0x3d4ea452515440a9254892b17eca1fb043b10de396ac3544eb15245fc7090751","0x1c62015d128d75c689664002a75db98954f305ed1747b431676ed1d5bd198338","0x5208708ca78ec2521b1165449c87f53d17469b588df3c2592359c1d7e4c61c5d","0xf04d8c9b5611956d59ec26019475b9776f5ca4f37fc760705fd8767598b27ff1","0xcb7b0acefcd1c3e6826228962d85d092481d2b609a70f6727f750620317baa63","0x7bcd4d84af99ed0d5e739428bcb1fd70ca12f6690afba75241d86362184805b3"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510842929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: loadWhiteList( [addressList[34],addressList[35],address... )", async function( ) {
		const txOriginal = {blockNumber: "4563976", timeStamp: "1510843155", hash: "0x8e7ce4ef574cbfe9f7c8e21b027a3ad358692743cef28fcb266bf9aa83356d90", nonce: "9", blockHash: "0xbbafc1636d7dfe605a43ffd1a61834c54d16a4f3246e4a8d78a2465dc31f4fad", transactionIndex: "68", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "1138544", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xe3fe48a100000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000380000000000000000000000000000000000000000000000000000000000000001900000000000000000000000009016ab9f549b6828afcb6878acc33ae00c9a2ae00000000000000000000000075750d0bba74ecb961fa588873a0ef69c54361c10000000000000000000000003bdbb23b42e2dcf045c49c4de43edf93e991f2f5000000000000000000000000193724cd4e4cdd37ccb7b4ee7c94c45b5963ed3c000000000000000000000000de582fbb8482576dd35faa8879b1fb904794c4b20000000000000000000000002b616914ada8484ab9d70398dbe86b029b1a9a39000000000000000000000000e7872e618b00c88d7c1450f5d656afc152c0e1800000000000000000000000003e7ec755be89b83d00b15d540ce38d6dbfc105570000000000000000000000003802dda14645de66eb3cc13c14f9bdb669d717ba000000000000000000000000d47c67e9829bdefc1bb27c4e364ee9acc1003d8400000000000000000000000056e99e3f9e68656b830a20ad46e5c2f5384ec7d8000000000000000000000000e286ac47fe66768acff597c0d9dc36bf3c676f65000000000000000000000000c989e2a6dca5c7ef02c69033740579f4e05bd97500000000000000000000000074231d64aa97949334fd9aae6db4c8c7707bac4d000000000000000000000000fae83d59634892ae1ac19c8e28493ae1628d691f00000000000000000000000050fb6237364ae15e0d097ca868765b0891a212bf0000000000000000000000005caa66408617f77601d0dc19c163621e7f4b8b380000000000000000000000001b859bb7b022e34ddab72d541881a2283f60d5670000000000000000000000004fd55f56dace98c59e095d35b8b6a11e7276f48e000000000000000000000000fc4b3e7aee17c6f523859cacdda947937bd34662000000000000000000000000790622728897b6367b7a8709c5f69d3dbd10507200000000000000000000000000f0e5b8fa6d8cb1e5cbedc4d4a6b92bc81b4aa30000000000000000000000006d569e92d1f0b4fe25152b4ab53c5cc303854659000000000000000000000000a4c6c4050a25a397f59b02b7ace3b6dbf4df236100000000000000000000000062c66ffcd2c7063396bf8c159b7e836e85b00605000000000000000000000000000000000000000000000000000000000000001990868a26844130e7ecaf7cc3d6bbed26ee6114481a33821430b3841d688c0883dd2b57c9ca6d10d7fc0f94658f2bf5366ab796287f59d58fe3778d2eed7ec4f2eda6f22b74204528735db93543815d202ecce6186bb31abcc144a8760cb030196af7b9b37a05f99710d9857bc6d5963a47c845b854f407ac68d01ae8ad3fb01f46f4fd83c55980a7c072dfd081bc1ece5aefa155abc311e1b096e07603922de57fe5db39e7866088c93d542046b83295072d96de45d0e6c5decc41d323ec8dd8483b3b837eca3f9d57765343b16d06efbeb81339de17069178cd19b5c0182e47ea77fd1a3c4b0e61205f84bb0ce3937708aae260286b76ba3c03690e0133fe52fb471b4f19c7097bc99338b74432ab68e6d743231bcaf7d486be3b9191c4dc80b0df5da236c2d21c86176d698a0dc1451c9025119ca9d0a954a8176432dfcea88dc2f96694e174985de8315861340554cce0142c065a6465131854ee52ed82f4a18d1cce0a6d0e618eb7d2465be9b198b9c2df14783861dc1856db37bf4c958098b9f2f6e3cc2e90530ab93e4f07e9627965e5d400ce41381b9c981bf3dfbb7cec293859fc013dfbe0a9c95efcbfc99e1f2f8486baa51ac446b860a73f492c110747f53fb99e1148a20480bb55f01b068ec0c806344d351dedcc7c5d07e72ad092242fd5dacb8cdf62c5e28cc62c0e3ac973be79f3d68f984480efa8fc1632c2fb3e94799d1b445f375952e4797c1bc6e142585f5b3466347a6e29fea50574103e20048f833d669dfdebd9833e4a24108a01c57114e6e9b7b88c32047c9ec35a13d8c45066bb785f47ec031638a7d6bf2628b858f39a0ff751d6e019c41e4a5bb15dc7bce900d93d3bc8280682e0c745c398ae9112dda4bf253603fabad8648cd9fde4a71f29ca162fe56785eb1a641662af14fe47a2c5315591aff695789e202f0b5bfb9e7ea1b772e237cea562c581d8b638cde3a5482d568847ac3cb2fc91910343ce6392aed9eeed277e9671c4c5c3c492897a08cde81ba6223cfc1c4e66841870be97c87d3da9ad4216833b77fb503187a1b1dde078ebb671625c6b58c4becbd4a50e83278063c59956edddf799494c093f05099e708526b94be1858f0b", contractAddress: "", cumulativeGasUsed: "4757861", gasUsed: "1138544", confirmations: "3176608"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_investors", value: [addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58]]}, {type: "bytes32[]", name: "_referralCodes", value: ["0x90868a26844130e7ecaf7cc3d6bbed26ee6114481a33821430b3841d688c0883","0xdd2b57c9ca6d10d7fc0f94658f2bf5366ab796287f59d58fe3778d2eed7ec4f2","0xeda6f22b74204528735db93543815d202ecce6186bb31abcc144a8760cb03019","0x6af7b9b37a05f99710d9857bc6d5963a47c845b854f407ac68d01ae8ad3fb01f","0x46f4fd83c55980a7c072dfd081bc1ece5aefa155abc311e1b096e07603922de5","0x7fe5db39e7866088c93d542046b83295072d96de45d0e6c5decc41d323ec8dd8","0x483b3b837eca3f9d57765343b16d06efbeb81339de17069178cd19b5c0182e47","0xea77fd1a3c4b0e61205f84bb0ce3937708aae260286b76ba3c03690e0133fe52","0xfb471b4f19c7097bc99338b74432ab68e6d743231bcaf7d486be3b9191c4dc80","0xb0df5da236c2d21c86176d698a0dc1451c9025119ca9d0a954a8176432dfcea8","0x8dc2f96694e174985de8315861340554cce0142c065a6465131854ee52ed82f4","0xa18d1cce0a6d0e618eb7d2465be9b198b9c2df14783861dc1856db37bf4c9580","0x98b9f2f6e3cc2e90530ab93e4f07e9627965e5d400ce41381b9c981bf3dfbb7c","0xec293859fc013dfbe0a9c95efcbfc99e1f2f8486baa51ac446b860a73f492c11","0x0747f53fb99e1148a20480bb55f01b068ec0c806344d351dedcc7c5d07e72ad0","0x92242fd5dacb8cdf62c5e28cc62c0e3ac973be79f3d68f984480efa8fc1632c2","0xfb3e94799d1b445f375952e4797c1bc6e142585f5b3466347a6e29fea5057410","0x3e20048f833d669dfdebd9833e4a24108a01c57114e6e9b7b88c32047c9ec35a","0x13d8c45066bb785f47ec031638a7d6bf2628b858f39a0ff751d6e019c41e4a5b","0xb15dc7bce900d93d3bc8280682e0c745c398ae9112dda4bf253603fabad8648c","0xd9fde4a71f29ca162fe56785eb1a641662af14fe47a2c5315591aff695789e20","0x2f0b5bfb9e7ea1b772e237cea562c581d8b638cde3a5482d568847ac3cb2fc91","0x910343ce6392aed9eeed277e9671c4c5c3c492897a08cde81ba6223cfc1c4e66","0x841870be97c87d3da9ad4216833b77fb503187a1b1dde078ebb671625c6b58c4","0xbecbd4a50e83278063c59956edddf799494c093f05099e708526b94be1858f0b"]}], name: "loadWhiteList", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadWhiteList(address[],bytes32[])" ]( [addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58]], ["0x90868a26844130e7ecaf7cc3d6bbed26ee6114481a33821430b3841d688c0883","0xdd2b57c9ca6d10d7fc0f94658f2bf5366ab796287f59d58fe3778d2eed7ec4f2","0xeda6f22b74204528735db93543815d202ecce6186bb31abcc144a8760cb03019","0x6af7b9b37a05f99710d9857bc6d5963a47c845b854f407ac68d01ae8ad3fb01f","0x46f4fd83c55980a7c072dfd081bc1ece5aefa155abc311e1b096e07603922de5","0x7fe5db39e7866088c93d542046b83295072d96de45d0e6c5decc41d323ec8dd8","0x483b3b837eca3f9d57765343b16d06efbeb81339de17069178cd19b5c0182e47","0xea77fd1a3c4b0e61205f84bb0ce3937708aae260286b76ba3c03690e0133fe52","0xfb471b4f19c7097bc99338b74432ab68e6d743231bcaf7d486be3b9191c4dc80","0xb0df5da236c2d21c86176d698a0dc1451c9025119ca9d0a954a8176432dfcea8","0x8dc2f96694e174985de8315861340554cce0142c065a6465131854ee52ed82f4","0xa18d1cce0a6d0e618eb7d2465be9b198b9c2df14783861dc1856db37bf4c9580","0x98b9f2f6e3cc2e90530ab93e4f07e9627965e5d400ce41381b9c981bf3dfbb7c","0xec293859fc013dfbe0a9c95efcbfc99e1f2f8486baa51ac446b860a73f492c11","0x0747f53fb99e1148a20480bb55f01b068ec0c806344d351dedcc7c5d07e72ad0","0x92242fd5dacb8cdf62c5e28cc62c0e3ac973be79f3d68f984480efa8fc1632c2","0xfb3e94799d1b445f375952e4797c1bc6e142585f5b3466347a6e29fea5057410","0x3e20048f833d669dfdebd9833e4a24108a01c57114e6e9b7b88c32047c9ec35a","0x13d8c45066bb785f47ec031638a7d6bf2628b858f39a0ff751d6e019c41e4a5b","0xb15dc7bce900d93d3bc8280682e0c745c398ae9112dda4bf253603fabad8648c","0xd9fde4a71f29ca162fe56785eb1a641662af14fe47a2c5315591aff695789e20","0x2f0b5bfb9e7ea1b772e237cea562c581d8b638cde3a5482d568847ac3cb2fc91","0x910343ce6392aed9eeed277e9671c4c5c3c492897a08cde81ba6223cfc1c4e66","0x841870be97c87d3da9ad4216833b77fb503187a1b1dde078ebb671625c6b58c4","0xbecbd4a50e83278063c59956edddf799494c093f05099e708526b94be1858f0b"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1510843155 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: loadReferredInvestors( [\"0x60d98cd98b8e7aa8f6b95e47dfc66b1079b... )", async function( ) {
		const txOriginal = {blockNumber: "4564188", timeStamp: "1510845863", hash: "0x0f605e7ab34a390c9acfe3585a2008a9efd5b7e283ee74afc2bf15b4548a00eb", nonce: "10", blockHash: "0x7d975bcf8cf77b1534907d17fa1a56e7730657871e2bacb6a7b7ecfa4d577d97", transactionIndex: "74", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "1500000", gasPrice: "1000000000", isError: "0", txreceipt_status: "0", input: "0x61a23f42000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000003e0000000000000000000000000000000000000000000000000000000000000001c60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98000000000000000000000000000000000000000000000000000000000000001d0000000000000000000000002ebc91acda66ef683cb8931f7599db9c54908d1900000000000000000000000005344ddce68acb0bbed1c3e392c7bcfd4be4258d0000000000000000000000009ae5010e64d8206446f97c500b518a9f8588300f0000000000000000000000006a60fca2acbe8d4cd3dc0bfc01b496d02ffe16970000000000000000000000003d8573232bf13860f991a4bb072298df4ebd3b9700000000000000000000000013619e9e15bd01d9a6de72a394052dfaa9f30ae70000000000000000000000001b87c2a6058bc88548bc9bb18b0717f939b2ccb300000000000000000000000063cc9097751e144ba4b6ea2cc7a5d692297ca85e000000000000000000000000dcde00e24e44d0291c656d7ad16465289365ca03000000000000000000000000b43af95f19c691d43ed1729efa02f064045828f700000000000000000000000026f471ff52759a8beaa07c55e694a2f64a3436140000000000000000000000008ebaeb59c6767331cadad731152009cfc12fb1c100000000000000000000000017cffe843f348d9e0fa9cb4d0a216c42999ae9da000000000000000000000000d1a25310ee726685710ae52c56bd14d2ee484c1100000000000000000000000072aaa61e51534668c134afc072c60e8734b7ce11000000000000000000000000727f349750b7e361ddf2777569409433543fe309000000000000000000000000f04a37f79b1628a2c1e52bf38fec8d2abce0d4150000000000000000000000001cdbc8917dc7d3c4c21a66bf2f0acce0d66473270000000000000000000000004db05a8400ca968ebca86f68afff63dc0a6759630000000000000000000000007d7c35f479a9dcbe5a0fb43b4645f46107a4f4c400000000000000000000000053624e85e5f4af6072ec2f5d2d70e30219708bb8000000000000000000000000ee2ab7f1146c5141920a800d6a057ee9289820de000000000000000000000000379779b7f0084790e7987ea99ac5b90d90fff4d6000000000000000000000000f9df2fde9399cc5bc4920cd7fb004e35e0acacb7000000000000000000000000f369baacc7ee1e87b9b555c27885c6c05578283a00000000000000000000000066e86fdc814ad464b5578a44499c8518c5574737000000000000000000000000d3fd65ade652ea370ff5e2beef3bfde9287479740000000000000000000000001016395a5e2faf753bde87d110a19ac3047bb1070000000000000000000000008784477df76f9a7cb0fe393064dcc954a01f1d4d", contractAddress: "", cumulativeGasUsed: "3562795", gasUsed: "125232", confirmations: "3176396"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32[]", name: "_referralCodes", value: ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"]}, {type: "address[]", name: "_investors", value: [addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87]]}], name: "loadReferredInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadReferredInvestors(bytes32[],address[])" ]( ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"], [addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1510845863 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: loadReferredInvestors( [\"0x60d98cd98b8e7aa8f6b95e47dfc66b1079b... )", async function( ) {
		const txOriginal = {blockNumber: "4564196", timeStamp: "1510845942", hash: "0xc336b31a3b6295ee4b0403c64068b886aa35b31ff8aab5f5ebfceb0b338d5d82", nonce: "11", blockHash: "0x2dfe2609c8a5f8c00ef7337940f5997cedd704c8fd54e2097e4ca67a44dd52fd", transactionIndex: "12", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "1500000", gasPrice: "1000000000", isError: "0", txreceipt_status: "0", input: "0x61a23f4200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001d60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000125c34c67cce888d3692ed51b14ec7101a74e0e3000000000000000000000000150f8879ff63aeb8c6ffc08f18656b712f06bbe3000000000000000000000000da5b5f574d31b71d4f985fa4be142e0edd0b1ef00000000000000000000000002cb35bc2a9b6cedef5ac41d0bb8b73d4c558af13000000000000000000000000ca18e65cd05c8086d6dfe4023243ac92a15a8162000000000000000000000000df56648816c6571497ee9a05063c2c601f9d2382000000000000000000000000bce1a30831bbca59dd11495595e6bc1cf81b938c000000000000000000000000f47bf659fb71a96f1c16119b5ce0098f821d84ec000000000000000000000000933d9f8d7d82922591bd5c3962e5b15743b1dc04000000000000000000000000b890305a848fb073b1e2d51c5fd67b70063a0003000000000000000000000000a51b194b4f2ddb5dec4a4be6b8a351dbee5f675000000000000000000000000052f0e7dd5856a31333a4c4dc1311f35b67c7ab3b0000000000000000000000007caa9e3c74d6c05655ef2fb390721edfd921d7a20000000000000000000000008f9f54e76bc081c06e33be89e03581b4ee79a637000000000000000000000000c1a2a12d2ee0cbdc25cd78ae13ad6028aa92c5660000000000000000000000002d27c26f482ee0d508bba64a4154dbcdcbc24921000000000000000000000000677d4197db9fb03b7bb4217dff4eb91782c7891300000000000000000000000066ff4b146431183d249aff97b08db4eeab46f448000000000000000000000000fadd0a0eb3752b0171b3394d60c8b09fad24baa80000000000000000000000005dc3b8898370e270779c3548eb440b337471ecbb00000000000000000000000027cfe2ca121b83882578f80b3af1e60e02d1fe72000000000000000000000000fee1cf7535bfe00c5fae39dc4fb344312697cbcb00000000000000000000000091efee37bd22c6c6b6a9e68602cb160d0e7a9b6600000000000000000000000022aaa7456421ff99c8cfa86318c5a1e969eab40e0000000000000000000000002324e70cd0b592b85167a18a9eeb391703596ac6000000000000000000000000670f948320b7ec3d6f9065c3236f9083d7c4a908000000000000000000000000d553f3a4ccdc7543eb5448ff0307906c2a541ed200000000000000000000000010890b4482bfe354dd67cfdadf031724429a5f43000000000000000000000000c6d68aa54686b7c2bef252f1ac0dc906fe1c61490000000000000000000000003733b1a7ebf5c4a5ef81a66036b2856d9ef79c94", contractAddress: "", cumulativeGasUsed: "647267", gasUsed: "128893", confirmations: "3176388"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32[]", name: "_referralCodes", value: ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"]}, {type: "address[]", name: "_investors", value: [addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117]]}], name: "loadReferredInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadReferredInvestors(bytes32[],address[])" ]( ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"], [addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1510845942 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: loadReferredInvestors( [\"0x60d98cd98b8e7aa8f6b95e47dfc66b1079b... )", async function( ) {
		const txOriginal = {blockNumber: "4564211", timeStamp: "1510846136", hash: "0xe86aa5595552ac74225befbbd00f0ec3956ea67e6d9d5257075a32fc7b38b0d0", nonce: "12", blockHash: "0x2108140fb0b60b86e57e922bfceee6020ad4099393e6c5ce91c1f0529e6612aa", transactionIndex: "31", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "734513", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x61a23f4200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000001d60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98000000000000000000000000000000000000000000000000000000000000001d0000000000000000000000002ebc91acda66ef683cb8931f7599db9c54908d1900000000000000000000000005344ddce68acb0bbed1c3e392c7bcfd4be4258d0000000000000000000000009ae5010e64d8206446f97c500b518a9f8588300f0000000000000000000000006a60fca2acbe8d4cd3dc0bfc01b496d02ffe16970000000000000000000000003d8573232bf13860f991a4bb072298df4ebd3b9700000000000000000000000013619e9e15bd01d9a6de72a394052dfaa9f30ae70000000000000000000000001b87c2a6058bc88548bc9bb18b0717f939b2ccb300000000000000000000000063cc9097751e144ba4b6ea2cc7a5d692297ca85e000000000000000000000000dcde00e24e44d0291c656d7ad16465289365ca03000000000000000000000000b43af95f19c691d43ed1729efa02f064045828f700000000000000000000000026f471ff52759a8beaa07c55e694a2f64a3436140000000000000000000000008ebaeb59c6767331cadad731152009cfc12fb1c100000000000000000000000017cffe843f348d9e0fa9cb4d0a216c42999ae9da000000000000000000000000d1a25310ee726685710ae52c56bd14d2ee484c1100000000000000000000000072aaa61e51534668c134afc072c60e8734b7ce11000000000000000000000000727f349750b7e361ddf2777569409433543fe309000000000000000000000000f04a37f79b1628a2c1e52bf38fec8d2abce0d4150000000000000000000000001cdbc8917dc7d3c4c21a66bf2f0acce0d66473270000000000000000000000004db05a8400ca968ebca86f68afff63dc0a6759630000000000000000000000007d7c35f479a9dcbe5a0fb43b4645f46107a4f4c400000000000000000000000053624e85e5f4af6072ec2f5d2d70e30219708bb8000000000000000000000000ee2ab7f1146c5141920a800d6a057ee9289820de000000000000000000000000379779b7f0084790e7987ea99ac5b90d90fff4d6000000000000000000000000f9df2fde9399cc5bc4920cd7fb004e35e0acacb7000000000000000000000000f369baacc7ee1e87b9b555c27885c6c05578283a00000000000000000000000066e86fdc814ad464b5578a44499c8518c5574737000000000000000000000000d3fd65ade652ea370ff5e2beef3bfde9287479740000000000000000000000001016395a5e2faf753bde87d110a19ac3047bb1070000000000000000000000008784477df76f9a7cb0fe393064dcc954a01f1d4d", contractAddress: "", cumulativeGasUsed: "1701117", gasUsed: "734513", confirmations: "3176373"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32[]", name: "_referralCodes", value: ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"]}, {type: "address[]", name: "_investors", value: [addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87]]}], name: "loadReferredInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadReferredInvestors(bytes32[],address[])" ]( ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"], [addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1510846136 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: loadReferredInvestors( [\"0x60d98cd98b8e7aa8f6b95e47dfc66b1079b... )", async function( ) {
		const txOriginal = {blockNumber: "4564245", timeStamp: "1510846748", hash: "0xa10124337a07a9d13237a4ca51cbdf78516d43e27a50ffa60fa634df9473cd15", nonce: "13", blockHash: "0xdd7dbe5240e7a8aba061600ff56929386f76cad22ea3ffef591b0154ba9d24d0", transactionIndex: "74", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "759237", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x61a23f4200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000420000000000000000000000000000000000000000000000000000000000000001e60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000125c34c67cce888d3692ed51b14ec7101a74e0e3000000000000000000000000150f8879ff63aeb8c6ffc08f18656b712f06bbe3000000000000000000000000da5b5f574d31b71d4f985fa4be142e0edd0b1ef00000000000000000000000002cb35bc2a9b6cedef5ac41d0bb8b73d4c558af13000000000000000000000000ca18e65cd05c8086d6dfe4023243ac92a15a8162000000000000000000000000df56648816c6571497ee9a05063c2c601f9d2382000000000000000000000000bce1a30831bbca59dd11495595e6bc1cf81b938c000000000000000000000000f47bf659fb71a96f1c16119b5ce0098f821d84ec000000000000000000000000933d9f8d7d82922591bd5c3962e5b15743b1dc04000000000000000000000000b890305a848fb073b1e2d51c5fd67b70063a0003000000000000000000000000a51b194b4f2ddb5dec4a4be6b8a351dbee5f675000000000000000000000000052f0e7dd5856a31333a4c4dc1311f35b67c7ab3b0000000000000000000000007caa9e3c74d6c05655ef2fb390721edfd921d7a20000000000000000000000008f9f54e76bc081c06e33be89e03581b4ee79a637000000000000000000000000c1a2a12d2ee0cbdc25cd78ae13ad6028aa92c5660000000000000000000000002d27c26f482ee0d508bba64a4154dbcdcbc24921000000000000000000000000677d4197db9fb03b7bb4217dff4eb91782c7891300000000000000000000000066ff4b146431183d249aff97b08db4eeab46f448000000000000000000000000fadd0a0eb3752b0171b3394d60c8b09fad24baa80000000000000000000000005dc3b8898370e270779c3548eb440b337471ecbb00000000000000000000000027cfe2ca121b83882578f80b3af1e60e02d1fe72000000000000000000000000fee1cf7535bfe00c5fae39dc4fb344312697cbcb00000000000000000000000091efee37bd22c6c6b6a9e68602cb160d0e7a9b6600000000000000000000000022aaa7456421ff99c8cfa86318c5a1e969eab40e0000000000000000000000002324e70cd0b592b85167a18a9eeb391703596ac6000000000000000000000000670f948320b7ec3d6f9065c3236f9083d7c4a908000000000000000000000000d553f3a4ccdc7543eb5448ff0307906c2a541ed200000000000000000000000010890b4482bfe354dd67cfdadf031724429a5f43000000000000000000000000c6d68aa54686b7c2bef252f1ac0dc906fe1c61490000000000000000000000003733b1a7ebf5c4a5ef81a66036b2856d9ef79c94", contractAddress: "", cumulativeGasUsed: "4993153", gasUsed: "759237", confirmations: "3176339"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32[]", name: "_referralCodes", value: ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"]}, {type: "address[]", name: "_investors", value: [addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117]]}], name: "loadReferredInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadReferredInvestors(bytes32[],address[])" ]( ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"], [addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1510846748 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: loadReferredInvestors( [\"0x60d98cd98b8e7aa8f6b95e47dfc66b1079b... )", async function( ) {
		const txOriginal = {blockNumber: "4564246", timeStamp: "1510846763", hash: "0xfdfdccc0f8672763a272f61c4eb067c3507a5f807ca4c07b138aa95f4f614ded", nonce: "14", blockHash: "0x4fb33bace9c76906551e3d0e8993fa9cc91bf7dcca419ac44999ebdd4a532f3b", transactionIndex: "67", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "758917", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x61a23f4200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000420000000000000000000000000000000000000000000000000000000000000001e60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000b8ab558137940a9265b2a8b6d5a738ad61b11c3a000000000000000000000000e133614d5e772a520bd03c488663266ebb3849c000000000000000000000000032e214ca890d6d280e267b35b03d6b6b59a8c64c000000000000000000000000ada0505e97915a069025dee3025c0026360cef4a000000000000000000000000fe2da16fb6f12575d5e9329fd3d26265e4b52004000000000000000000000000f6bbc43c2a2c8776c8c9db58dcbd6413c1cb79230000000000000000000000007408c65285478c3be8c392dd62d8956715ebd55f00000000000000000000000012107554d83727cb8533a82cd68b85601054d667000000000000000000000000cc5e37a4851ee3ad545fa8ab96af23c7d0bca87e0000000000000000000000006ade98240e2449d0d502dfb11f80b4870a5a5f3a0000000000000000000000004593b3c06a42e932dbc8a7627fd84dfa1c7f9f530000000000000000000000003507a375464348d3aff4fd4df5c313423575517800000000000000000000000011ea5e932d361838685c4e1bc48c399981aee1000000000000000000000000004c82a07e4827436f86ada9fb87162a5e52eacecf000000000000000000000000cdc01abaeea88db6a69ede3513389dae3f5f83f50000000000000000000000000b196b342fc35ce0892b76b320d215ea7a8b4687000000000000000000000000d3e33af45e30f30ac9c37376371ab93e657b495d000000000000000000000000ee171a52ef989116a6e76dae11c73bf13c9032c1000000000000000000000000e6c263da32022242817985cf3d44bbc71e519789000000000000000000000000c0ba12c217f7d6983c6f21e33b434665c1c708490000000000000000000000004ef730c459a1a42ef59156589396627b7113158600000000000000000000000063f48c2fc60764abf1e7a429d52e6e04cce94acc00000000000000000000000039b18e24d79be0d658fc916ae7d4722343de29f100000000000000000000000064127cb3d9008965c5982e4acdf91c6aef7222b1000000000000000000000000b4f7a89b0f97a7573ac9d200ab4490456e9e972500000000000000000000000088330efb596e94d70726e0f99a33d94497e80d0b00000000000000000000000048476b6c003e5f10686d21d2e8362f1ad64b3ff9000000000000000000000000fbd27d9c8026828e9b6792a32e57435c7702b28d000000000000000000000000541c536625f1c0b22794449f90fd0dd68622d37d00000000000000000000000064825de50505832d661e1e461f9be6ca005b63e4", contractAddress: "", cumulativeGasUsed: "3835471", gasUsed: "758917", confirmations: "3176338"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32[]", name: "_referralCodes", value: ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"]}, {type: "address[]", name: "_investors", value: [addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147]]}], name: "loadReferredInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadReferredInvestors(bytes32[],address[])" ]( ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"], [addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1510846763 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: loadReferredInvestors( [\"0x60d98cd98b8e7aa8f6b95e47dfc66b1079b... )", async function( ) {
		const txOriginal = {blockNumber: "4564300", timeStamp: "1510847603", hash: "0xed75197d2ab1a32e24cfc297bded03362e7bac74f4a7a3c0ae86ecb082d762e1", nonce: "15", blockHash: "0x53d4e93bfe7d40404164f821d95a4cce7a95015bf047e0a2436189c08c98dfa5", transactionIndex: "108", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "347341", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x61a23f4200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000420000000000000000000000000000000000000000000000000000000000000001e60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98000000000000000000000000000000000000000000000000000000000000001e60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98", contractAddress: "", cumulativeGasUsed: "4741576", gasUsed: "347341", confirmations: "3176284"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32[]", name: "_referralCodes", value: ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"]}, {type: "address[]", name: "_investors", value: [addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148]]}], name: "loadReferredInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadReferredInvestors(bytes32[],address[])" ]( ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"], [addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148],addressList[148]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1510847603 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: loadReferredInvestors( [\"0x60d98cd98b8e7aa8f6b95e47dfc66b1079b... )", async function( ) {
		const txOriginal = {blockNumber: "4564312", timeStamp: "1510847743", hash: "0xb5dde0aea9bb9964e6772583ef605c9f43e4987839d0d426c154f64e3e9c4ef1", nonce: "16", blockHash: "0x3d1a4247ad2811eb8da1d4d9fa9048fb9ba4e5afa2fd52c2e51c0eca43ba7137", transactionIndex: "102", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "759173", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x61a23f4200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000420000000000000000000000000000000000000000000000000000000000000001e60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98000000000000000000000000000000000000000000000000000000000000001e00000000000000000000000091f4bd5aaae4c18da51b552beba178e2902cd990000000000000000000000000451aaaaa9f1e7e264fdac6bebb991fb48f3dc057000000000000000000000000976f4e810f0719cd1c7654e612b8d236cbbb68120000000000000000000000001e4d6653bbcddd527d6679170af3320a83c65e6d00000000000000000000000097e987f98d478a445ded36140fda6edc4af7182c000000000000000000000000acb8f16a62a9d98212dfbe57b0d501a5c6b08b04000000000000000000000000a9c0b993d91e32d53cd627f8bc5e2744f13c0e5d0000000000000000000000008ccd03603f453aea792dc9d9d125ad47a8297c6600000000000000000000000058ff2641a79eb0858fb79bd961a3f10bd89d811f0000000000000000000000008b144a8586457aeb6c2193196cec35ec3387d9b900000000000000000000000071baf1e614e271ddd075be548384df512b1ae134000000000000000000000000bdf2294f6ecb5d96b15d62af8472afa6d799ff800000000000000000000000006d19bb2a7f606e3527db16cc6a8e0eda5bf5276e00000000000000000000000094781af1f0732a5186cfce41b96ff55a8c44fa040000000000000000000000001c9d9d9d65143237350bd56446be632070d6a5b500000000000000000000000066c4bebd810518237e3f726232aaabc390a485270000000000000000000000002f7189ef76e575976fbd6961107f9ad633fb1ad90000000000000000000000007d6201cda0b47db7b859240f00e6056ae03c6139000000000000000000000000c3651344e7839f124f7a64d7fcc1f615196f90a0000000000000000000000000c6ec1d13b2405d480df398628d0bf9067d82c9b600000000000000000000000092793df575fa41ff83b6d8845c5898d0c92304c80000000000000000000000001c2bbdbcd9cdb3bd8d2dc082c12b8d2b3662274c0000000000000000000000006001c916e5a6fdd8f4defc36242759fe5d2b2a3b0000000000000000000000000cc85e04b156d11afc983240203b94ca8d98b0760000000000000000000000001e28f669a710675cc44fc2386078b08bd4b2cba2000000000000000000000000554ca18a0c69decace1cf54aabe52cf12e25a87a0000000000000000000000005b598bd240943da4fac91ff99eeec020d860dca10000000000000000000000008c335d35004b4ba3dc2221d09c02c19a35dad8b50000000000000000000000003ffad1b916b29a20d99bd90f9302b2ead464e41500000000000000000000000008b1d5c43f9777ee3f0874b70675dd7143ef1216", contractAddress: "", cumulativeGasUsed: "5813472", gasUsed: "759173", confirmations: "3176272"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32[]", name: "_referralCodes", value: ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"]}, {type: "address[]", name: "_investors", value: [addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178]]}], name: "loadReferredInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadReferredInvestors(bytes32[],address[])" ]( ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"], [addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1510847743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: loadReferredInvestors( [\"0x60d98cd98b8e7aa8f6b95e47dfc66b1079b... )", async function( ) {
		const txOriginal = {blockNumber: "4564320", timeStamp: "1510847835", hash: "0xa37dc2111b6d8130f0783995946f3626a118c70720c36c5a1c03f257059479d0", nonce: "17", blockHash: "0x4575203ee9cd67b044a645ac65a91fd7f9000f6de68440b1379f5078b276fcd4", transactionIndex: "111", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "759173", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x61a23f4200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000420000000000000000000000000000000000000000000000000000000000000001e60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98000000000000000000000000000000000000000000000000000000000000001e00000000000000000000000058b30dbd4668779de330eb31a9392d7146117f610000000000000000000000005d13db1e7916e66c4676ff41b3b14f3906002ad2000000000000000000000000510a867d61a2afe88ef381bfe286d71c481f916e00000000000000000000000008a3b015e77e791fa2f065468b3f4d51f4157f3300000000000000000000000055ac8215cc397b1216088b7b7ca8138ccd05727f000000000000000000000000163d696432a4d689d15861b5a6c59f36c757b9f200000000000000000000000089b335e2093bf261e4573b1a7ec57e5b9facae8d000000000000000000000000dd7112b9aae6c75dfd349024e452be1a279b61fb000000000000000000000000fab5c18df15ab7cad0a8451f7fb35b054856f41800000000000000000000000061598890dbf4294e431e98d6f59de5c0a46366230000000000000000000000003361b0e1e334177f5ca6749aca7449939a67b2eb0000000000000000000000004d3bad2364a2c0d959f295066281185515bc11830000000000000000000000001caefd9588d2f5a891093e00ad6f7048506c8bf0000000000000000000000000c25d196c89b46b70a2db57310951e76e7290fa2b000000000000000000000000adc9347848592fc0d9569335b224e6a253cf44a700000000000000000000000064ba3f02378fff800952db01b646bc611fa4158f0000000000000000000000001efe29d4fc3c720bd0e2b2a0f714c82d250a91b2000000000000000000000000aa2f9af22397330cdf8c1ca3fa1fc48592e7e0b7000000000000000000000000b44e835471d78d19bbcc56eaf0a2556eeb2f811a000000000000000000000000898ebae28305f61f2d5446b92799cf4d20890ba50000000000000000000000004a959743ac5a5ca4042fe38c6d2dae94a5aa543c000000000000000000000000f0c49021326d76ffe3b99b9055ce0616642961a8000000000000000000000000210be71dcc7014427ebceea6f156807ed423227a0000000000000000000000007c51a1d131e915f5c3fa30816719ecefb723af22000000000000000000000000757466e1f746116efec6c7c75022cea11d9eb9e30000000000000000000000005b6ea7fd78d3994a09c413aa48131257c73b7948000000000000000000000000d5159e2b8d9dc1ec0352e24663402643a62f9d6c000000000000000000000000b737af9b213da3dd1bcc9e336421087da6d88343000000000000000000000000b96fd763500d2f3710fd19884a99886264ca15d1000000000000000000000000f804e840fce9d62c8332bbeb6a43e4e7930f6cf7", contractAddress: "", cumulativeGasUsed: "5148614", gasUsed: "759173", confirmations: "3176264"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32[]", name: "_referralCodes", value: ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"]}, {type: "address[]", name: "_investors", value: [addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208]]}], name: "loadReferredInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadReferredInvestors(bytes32[],address[])" ]( ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"], [addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1510847835 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: loadReferredInvestors( [\"0x60d98cd98b8e7aa8f6b95e47dfc66b1079b... )", async function( ) {
		const txOriginal = {blockNumber: "4564329", timeStamp: "1510847975", hash: "0x795713a093d40be52cfaa95d933af425f81b5da27206bb22c2056b07a20c7408", nonce: "18", blockHash: "0xb3f0f74776c6fff90fe7d141c95fe062c1f1c5e805113434cec3a941151036c0", transactionIndex: "79", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "759237", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x61a23f4200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000420000000000000000000000000000000000000000000000000000000000000001e60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000ff80dddfda46ee987031c5a7e33520cd69952f96000000000000000000000000fd24d5f821cded9d09adefa2d429115fe0f5acec000000000000000000000000bae93e299598c76ff5393860838684dfebb3eaa90000000000000000000000007be7cae4fd8c14a7c4e9153219dcd6b98ad5a206000000000000000000000000fe96087e0984a0bf74125ad88f4150b9225bf318000000000000000000000000da8301e930c47db3e1b5d7784420f89a74d714c6000000000000000000000000135ff73faccb5157e44c9f518e78fba98b453d450000000000000000000000008f01ef166001ce1a3ef072d755998a9ce25546d80000000000000000000000003f27012224b8bd89f74fee93bfbbef579686923b0000000000000000000000000db078365ec8e8a32b15fed6040d56e9b298369e0000000000000000000000001f44ce9475b9430fe7db7204b5ec62f6cb8893e9000000000000000000000000c1fd9e33539ecfec2a39f1fb2d42f639ca0522d6000000000000000000000000ba0d9ef20fba7d204e2408d78af19377413fbf4500000000000000000000000052fabdbd0853aab04c954e1e82cb62d6c9e59b510000000000000000000000002c5fcae84ed0d872946bd3ad7c0ca3124220673e000000000000000000000000a525ec304ac1c908f9c37b4c8de775c78c629b1c000000000000000000000000c23925285932870e5802c3d2559ed11ea459ac0e000000000000000000000000e733380fbb195d728bfc3708c526cd1ce32208f7000000000000000000000000d1f31cb5c87a2558d7bfe19f39e466ec47f706ac000000000000000000000000d96f674b234978dad7a14d2bdc4aaeb40548ce42000000000000000000000000217ca634eb2ebb088af1c2ff1a15183c6a7235f60000000000000000000000000a40445d48e74f747e24ec046e9977811815d7f00000000000000000000000008c9adc7494b7f3898c2964dd5abd3fcd45121632000000000000000000000000a4208c7ca8b733e9d3fe016bf7826ee0a0a530fa00000000000000000000000091547e77f3d162c3975f8847f91bbc284f77c322000000000000000000000000e70b477d853c4d97a6df3879a65bee52cd65f4b8000000000000000000000000b915b2fdd584001061e82ce130cfdb3114d43223000000000000000000000000a502ddb91161080c8d3b30bfab128a6de7d60bbc0000000000000000000000003b394a541681aa4e21075a938b284e20d29533ea000000000000000000000000d5c56952e1aad42f20075666b123f42334969297", contractAddress: "", cumulativeGasUsed: "3620402", gasUsed: "759237", confirmations: "3176255"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32[]", name: "_referralCodes", value: ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"]}, {type: "address[]", name: "_investors", value: [addressList[209],addressList[210],addressList[211],addressList[212],addressList[213],addressList[214],addressList[215],addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[221],addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229],addressList[230],addressList[231],addressList[232],addressList[233],addressList[234],addressList[235],addressList[236],addressList[237],addressList[32]]}], name: "loadReferredInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadReferredInvestors(bytes32[],address[])" ]( ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"], [addressList[209],addressList[210],addressList[211],addressList[212],addressList[213],addressList[214],addressList[215],addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[221],addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229],addressList[230],addressList[231],addressList[232],addressList[233],addressList[234],addressList[235],addressList[236],addressList[237],addressList[32]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1510847975 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: loadReferredInvestors( [\"0xc675f3143c95b4923d847e1f2da41c2a399... )", async function( ) {
		const txOriginal = {blockNumber: "4564351", timeStamp: "1510848309", hash: "0x79972bb4ea48418f6ebc5d3709b447a47259375ed87c51219769bf6e8a479073", nonce: "19", blockHash: "0xb363c7b96d78be7889cbf4fb6fc9da5e45d0ff24894aff3084ad3aafa8094df1", transactionIndex: "74", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "72361", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x61a23f42000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000002c675f3143c95b4923d847e1f2da41c2a399347c8b9a4e0b46ada990310784241c675f3143c95b4923d847e1f2da41c2a399347c8b9a4e0b46ada99031078424100000000000000000000000000000000000000000000000000000000000000020000000000000000000000001d0676ab90e684e9c70c96a8691c2c993eec2da8000000000000000000000000bd8ba7a166074cf41a375b54109e12103d6aff25", contractAddress: "", cumulativeGasUsed: "4862850", gasUsed: "72361", confirmations: "3176233"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32[]", name: "_referralCodes", value: ["0xc675f3143c95b4923d847e1f2da41c2a399347c8b9a4e0b46ada990310784241","0xc675f3143c95b4923d847e1f2da41c2a399347c8b9a4e0b46ada990310784241"]}, {type: "address[]", name: "_investors", value: [addressList[238],addressList[239]]}], name: "loadReferredInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadReferredInvestors(bytes32[],address[])" ]( ["0xc675f3143c95b4923d847e1f2da41c2a399347c8b9a4e0b46ada990310784241","0xc675f3143c95b4923d847e1f2da41c2a399347c8b9a4e0b46ada990310784241"], [addressList[238],addressList[239]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510848309 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: loadReferredInvestors( [\"0x60d98cd98b8e7aa8f6b95e47dfc66b1079b... )", async function( ) {
		const txOriginal = {blockNumber: "4564374", timeStamp: "1510848585", hash: "0xe95ee504561c00d503d206e9b215318f72ed06d0147c080f6fd7d852d596388c", nonce: "20", blockHash: "0xaab6febe0584a7822958bda2c8517489f9db04e266282984db942fd8989594df", transactionIndex: "105", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "759109", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x61a23f4200000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000420000000000000000000000000000000000000000000000000000000000000001e60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a9860d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000acdb574e86ae4a9406a49c04146b067b9ef4142d0000000000000000000000001544853ceae12634ed1d23d09fc970acd010a32b000000000000000000000000e534339f2132b820626bdfd7316816e683fdd2060000000000000000000000001749238d844248094ae1fd54bb79750b45836e4e00000000000000000000000057de22737c5a7580a612e8b2477e3b691d8a7e59000000000000000000000000253454fdf97a3fc23503442a4bf5692d54acf6cc0000000000000000000000001ad26339eae968567bdb910ae5248890351cce6f000000000000000000000000525f8b26e54279f949dbef9bee029d2c2ff3982000000000000000000000000016bef1f16d4ea8901ec2ca46200abcc784604ffe000000000000000000000000892fd9376606efde0078bcd40c11fef1aab17fba0000000000000000000000004a71789c84288e631078f7042d40b4c86969399700000000000000000000000019f7174465f4b4dc01a13d333746a56e12fb3cd1000000000000000000000000bf69ade5876a6971c8d0400654fca5e4c96e67d2000000000000000000000000b06045212d6548f9b42cc62d87698d55d44e913c0000000000000000000000002c68e65544ae4bd038819c774a334466155c1519000000000000000000000000e5d2a2b3fb2818e0257e151ae5a95dfaad1a25d6000000000000000000000000d535500c81d422899da23f79173c80a0e741ef1e000000000000000000000000eb4c058d2e9e95010a1479e32dec7eccc77b0e3b000000000000000000000000dba56802f4ba5d32f7d2fdfb53e1b4b2243215440000000000000000000000007e319a56e15ee9723c175684533e0042605d2fad00000000000000000000000089d6c9616030713b0cf8348583ac66b6d938bad600000000000000000000000098f51b2a996c759399d2fb440cacdcf7620239060000000000000000000000009823aae6074aa8c5ee3ad6c328ee36ec6305d9f4000000000000000000000000e01228e2b29e52705db28b137f6e92ad2887b9c1000000000000000000000000db156c95cce17414195a724633e54edb1cb4348400000000000000000000000079b384dcaabb6212c93334441a89ebc18816460e000000000000000000000000d1a5332794922d273c33a08345f18dfaa692ba040000000000000000000000003c0f7aa72cd452120ac15a0e6d1db79a03dbc1120000000000000000000000007a43182d3bdf978e161eb117c0eab864d4f03220000000000000000000000000af6fb60bacdf00ab17dfe3f55376d5b47b3887f3", contractAddress: "", cumulativeGasUsed: "5477265", gasUsed: "759109", confirmations: "3176210"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32[]", name: "_referralCodes", value: ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"]}, {type: "address[]", name: "_investors", value: [addressList[240],addressList[241],addressList[242],addressList[243],addressList[244],addressList[245],addressList[246],addressList[247],addressList[248],addressList[249],addressList[250],addressList[251],addressList[252],addressList[253],addressList[254],addressList[255],addressList[256],addressList[257],addressList[258],addressList[259],addressList[260],addressList[261],addressList[262],addressList[263],addressList[264],addressList[265],addressList[266],addressList[267],addressList[268],addressList[269]]}], name: "loadReferredInvestors", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "loadReferredInvestors(bytes32[],address[])" ]( ["0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98","0x60d98cd98b8e7aa8f6b95e47dfc66b1079b502de715eb6ba7e6224d91abc6a98"], [addressList[240],addressList[241],addressList[242],addressList[243],addressList[244],addressList[245],addressList[246],addressList[247],addressList[248],addressList[249],addressList[250],addressList[251],addressList[252],addressList[253],addressList[254],addressList[255],addressList[256],addressList[257],addressList[258],addressList[259],addressList[260],addressList[261],addressList[262],addressList[263],addressList[264],addressList[265],addressList[266],addressList[267],addressList[268],addressList[269]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510848585 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `demeter0`, addressList[271] )", async function( ) {
		const txOriginal = {blockNumber: "4574920", timeStamp: "1510995811", hash: "0x5dcaa697d721537ee17be13fdf4ba92301aa46c38bec700ff6faa02b1060338b", nonce: "23", blockHash: "0x71a52e79789ec893b735f43c3f174a6972337000ba7278249e4fe964bcc74580", transactionIndex: "20", from: "0xc2cd2a679b80e76d644357d15a0e4d194ece4ed8", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "49944", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd8bea8980000000000000000000000000000000000000000000000000000000000000040000000000000000000000000721a2042014805eb429cdc1e4e76fbb243afdbf0000000000000000000000000000000000000000000000000000000000000000864656d6574657230000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "751725", gasUsed: "49944", confirmations: "3165664"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[270], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `demeter0`}, {type: "address", name: "_referredInvestor", value: addressList[271]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `demeter0`, addressList[271], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1510995811 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "referralCode", type: "string"}, {indexed: false, name: "referredInvestor", type: "address"}], name: "ReferredInvestorAdded", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredInvestorAdded", events: [{name: "referralCode", type: "string", value: "demeter0"}, {name: "referredInvestor", type: "address", value: "0x721a2042014805eb429cdc1e4e76fbb243afdbf0"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[270], balance: "163170451000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[270], balance: ( await web3.eth.getBalance( addressList[270], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `Demeter9`, addressList[273] )", async function( ) {
		const txOriginal = {blockNumber: "4574990", timeStamp: "1510996595", hash: "0x7a35d5f751d0b0af6394d2e9714355016949012bd9946b71a32e1f5ac7dbc689", nonce: "0", blockHash: "0xb40a7a2bec333930565318b181bfe0ce70d2e1cf648c6415629d482efa31a528", transactionIndex: "23", from: "0xc47980d52e421809698ffff62f4c0f9db6f11913", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "49944", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd8bea8980000000000000000000000000000000000000000000000000000000000000040000000000000000000000000bceb22a26b1518e47eca45600cde20151ba0b3b4000000000000000000000000000000000000000000000000000000000000000844656d6574657239000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1158284", gasUsed: "49944", confirmations: "3165594"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[272], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `Demeter9`}, {type: "address", name: "_referredInvestor", value: addressList[273]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `Demeter9`, addressList[273], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510996595 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "referralCode", type: "string"}, {indexed: false, name: "referredInvestor", type: "address"}], name: "ReferredInvestorAdded", type: "event"} ;
		console.error( "eventCallOriginal[15,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredInvestorAdded", events: [{name: "referralCode", type: "string", value: "Demeter9"}, {name: "referredInvestor", type: "address", value: "0xbceb22a26b1518e47eca45600cde20151ba0b3b4"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[15,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[272], balance: "448000000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[272], balance: ( await web3.eth.getBalance( addressList[272], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `Demeter9`, addressList[274] )", async function( ) {
		const txOriginal = {blockNumber: "4574991", timeStamp: "1510996656", hash: "0x2d99da8e1ce088b84d047a12f82f0c8b1ae7e50496d6e81a128ce6cd326c1a9f", nonce: "1", blockHash: "0xb34cadb5c48d7bb98cc159f0f2bb311338361230d2820c19e75b7c3bf65373c2", transactionIndex: "30", from: "0xc47980d52e421809698ffff62f4c0f9db6f11913", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "49944", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd8bea89800000000000000000000000000000000000000000000000000000000000000400000000000000000000000007cb57b5a97eabe94205c07890be4c1ad31e486a8000000000000000000000000000000000000000000000000000000000000000844656d6574657239000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "983851", gasUsed: "49944", confirmations: "3165593"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[272], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `Demeter9`}, {type: "address", name: "_referredInvestor", value: addressList[274]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `Demeter9`, addressList[274], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510996656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "referralCode", type: "string"}, {indexed: false, name: "referredInvestor", type: "address"}], name: "ReferredInvestorAdded", type: "event"} ;
		console.error( "eventCallOriginal[16,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredInvestorAdded", events: [{name: "referralCode", type: "string", value: "Demeter9"}, {name: "referredInvestor", type: "address", value: "0x7cb57b5a97eabe94205c07890be4c1ad31e486a8"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[16,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[272], balance: "448000000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[272], balance: ( await web3.eth.getBalance( addressList[272], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `Demeter9`, addressList[275] )", async function( ) {
		const txOriginal = {blockNumber: "4574991", timeStamp: "1510996656", hash: "0x4949f48ec0755ac48722ca223fc606b6a474a6b79d6f37941603bc24ae72f8aa", nonce: "2", blockHash: "0xb34cadb5c48d7bb98cc159f0f2bb311338361230d2820c19e75b7c3bf65373c2", transactionIndex: "162", from: "0xc47980d52e421809698ffff62f4c0f9db6f11913", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "49944", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd8bea89800000000000000000000000000000000000000000000000000000000000000400000000000000000000000007da1cf9360df990e55040187a36d11f88451bcce000000000000000000000000000000000000000000000000000000000000000844656d6574657239000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6334073", gasUsed: "49944", confirmations: "3165593"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[272], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `Demeter9`}, {type: "address", name: "_referredInvestor", value: addressList[275]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `Demeter9`, addressList[275], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1510996656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "referralCode", type: "string"}, {indexed: false, name: "referredInvestor", type: "address"}], name: "ReferredInvestorAdded", type: "event"} ;
		console.error( "eventCallOriginal[17,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredInvestorAdded", events: [{name: "referralCode", type: "string", value: "Demeter9"}, {name: "referredInvestor", type: "address", value: "0x7da1cf9360df990e55040187a36d11f88451bcce"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[17,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[272], balance: "448000000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[272], balance: ( await web3.eth.getBalance( addressList[272], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: transferOwnership( addressList[276] )", async function( ) {
		const txOriginal = {blockNumber: "4575080", timeStamp: "1510997930", hash: "0xb2c754f0e15a6a480c35574bbff5ab69b8a14e44dd5f49617ec1afd890ae1f2e", nonce: "21", blockHash: "0x07b253fa4b8ee5f58d6606633d3219cd19e03001c412bb3b6c976efe248abcc8", transactionIndex: "172", from: "0x002fe928c25a5a5d4e919730f27925d24b2410b5", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "37519", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xf2fde38b000000000000000000000000dc47494e7b58e0c8845ae0670f7647bed621eb18", contractAddress: "", cumulativeGasUsed: "6023526", gasUsed: "31266", confirmations: "3165504"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newOwner", value: addressList[276]}], name: "transferOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferOwnership(address)" ]( addressList[276], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1510997930 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"} ;
		console.error( "eventCallOriginal[18,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnershipTransferred", events: [{name: "previousOwner", type: "address", value: "0x002fe928c25a5a5d4e919730f27925d24b2410b5"}, {name: "newOwner", type: "address", value: "0xdc47494e7b58e0c8845ae0670f7647bed621eb18"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[18,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "96115821000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4575456", timeStamp: "1511002873", hash: "0xc22e142b3738f0242dd11131fcfe1b59a8843cf0ef3b53617272786ea7f1ba93", nonce: "4", blockHash: "0x8926394824c6df6032892d771a9aee1a49f8b7b2168f0cb4a7ded9ca2a3ebe5c", transactionIndex: "23", from: "0x000aa542e1adb7c96ca7f17fc432ea4c1972d54c", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "100000000000000000", gas: "300000", gasPrice: "500000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1710872", gasUsed: "246595", confirmations: "3165128"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1511002873 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "investor", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "CompanyTokensIssued", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CompanyTokensIssued", events: [{name: "investor", type: "address", value: "0x000aa542e1adb7c96ca7f17fc432ea4c1972d54c"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "amount", type: "uint256", value: "513666666666666666666"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WhiteListBonusTokensEmitted", type: "event"} ;
		console.error( "eventCallOriginal[19,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WhiteListBonusTokensEmitted", events: [{name: "beneficiary", type: "address", value: "0x000aa542e1adb7c96ca7f17fc432ea4c1972d54c"}, {name: "amount", type: "uint256", value: "23000000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[19,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[19,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x000aa542e1adb7c96ca7f17fc432ea4c1972d54c"}, {name: "beneficiary", type: "address", value: "0x000aa542e1adb7c96ca7f17fc432ea4c1972d54c"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "amount", type: "uint256", value: "230000000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[19,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "81990427563359608" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4577326", timeStamp: "1511028960", hash: "0x16fa26fcfc32bed88b23792182ea7b9d558c5ddb3407e4b0aba46081697a4300", nonce: "0", blockHash: "0x296562de0b1b21185f7fdc3e8d5f159d98ada4e951016d1428537715ba320909", transactionIndex: "6", from: "0x3d8573232bf13860f991a4bb072298df4ebd3b97", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "200000000000000000", gas: "3000000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "421166", gasUsed: "205587", confirmations: "3163258"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[63], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1511028960 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "investor", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "CompanyTokensIssued", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CompanyTokensIssued", events: [{name: "investor", type: "address", value: "0x3d8573232bf13860f991a4bb072298df4ebd3b97"}, {name: "value", type: "uint256", value: "200000000000000000"}, {name: "amount", type: "uint256", value: "1027333333333333333333"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "ReferredBonusTokensEmitted", type: "event"} ;
		console.error( "eventCallOriginal[20,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredBonusTokensEmitted", events: [{name: "beneficiary", type: "address", value: "0x3d8573232bf13860f991a4bb072298df4ebd3b97"}, {name: "amount", type: "uint256", value: "23000000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[20,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WhiteListBonusTokensEmitted", type: "event"} ;
		console.error( "eventCallOriginal[20,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WhiteListBonusTokensEmitted", events: [{name: "beneficiary", type: "address", value: "0x6958165b082d5b83e24b52a8d1835065e2da00d2"}, {name: "amount", type: "uint256", value: "23000000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[20,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[20,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x3d8573232bf13860f991a4bb072298df4ebd3b97"}, {name: "beneficiary", type: "address", value: "0x3d8573232bf13860f991a4bb072298df4ebd3b97"}, {name: "value", type: "uint256", value: "200000000000000000"}, {name: "amount", type: "uint256", value: "460000000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[20,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[63], balance: "171453379400000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[63], balance: ( await web3.eth.getBalance( addressList[63], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4581458", timeStamp: "1511086111", hash: "0x8ffe3c6edf352803719b99187f719e6dcb9b6abb7ff39a80c36f53a915a37114", nonce: "2", blockHash: "0x6c4e7f193b76ffb1e51b1eca69ea2f9489d592d6842a17a6ac9bf6a5912e8fc6", transactionIndex: "3", from: "0x89eb2b388b79f482400ff854fa35f54e1bce833e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "600000000000000000", gas: "300000", gasPrice: "46000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "105364", gasUsed: "22393", confirmations: "3159126"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[277], to: addressList[2], value: "600000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1511086111 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[277], balance: "70508000000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[277], balance: ( await web3.eth.getBalance( addressList[277], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4581595", timeStamp: "1511088051", hash: "0x4b9dc22afc4c40362e7c15ed0a997ae97ab9e8e14ac54ebd15783f96d7fc4629", nonce: "3", blockHash: "0xd46f508f04c0d1e1428a4d28903bfee6bce591c9348538b6edecbdfb1cbb0d84", transactionIndex: "1", from: "0x89eb2b388b79f482400ff854fa35f54e1bce833e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "600000000000000000", gas: "300000", gasPrice: "48400000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "55734", gasUsed: "22393", confirmations: "3158989"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[277], to: addressList[2], value: "600000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1511088051 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[277], balance: "70508000000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[277], balance: ( await web3.eth.getBalance( addressList[277], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4581706", timeStamp: "1511089608", hash: "0x663f5a8316c5166be0e348e444d561185d8c3e28ef9d6fb20d6b2f88aad78187", nonce: "4", blockHash: "0x3012ca18bb7f1a575fd17d4fe675ecf8129c9518f28e6471cd4c380308b11430", transactionIndex: "3", from: "0x89eb2b388b79f482400ff854fa35f54e1bce833e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "500000000000000000", gas: "300000", gasPrice: "48000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "176959", gasUsed: "22393", confirmations: "3158878"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[277], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1511089608 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[277], balance: "70508000000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[277], balance: ( await web3.eth.getBalance( addressList[277], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4581719", timeStamp: "1511089785", hash: "0xd01b48b4499ccfbe4aae065c5efb690339bf2af2b46767c20125b05559044640", nonce: "5", blockHash: "0x0e51a14c98a6d50935bbcccca871f800880443339a1aab1c7e28957de138cf06", transactionIndex: "2", from: "0x89eb2b388b79f482400ff854fa35f54e1bce833e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "500000000000000000", gas: "300000", gasPrice: "48000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "193301", gasUsed: "22393", confirmations: "3158865"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[277], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1511089785 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[277], balance: "70508000000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[277], balance: ( await web3.eth.getBalance( addressList[277], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4581752", timeStamp: "1511090267", hash: "0x1cc729975f2a961801cf92bd764781d89f70ec4dbad95730f88ecaca30e9c678", nonce: "6", blockHash: "0xd322c1e0fcee84e06d2de999e7adbd19b747245a25240bb505bf8204773c1d12", transactionIndex: "1", from: "0x89eb2b388b79f482400ff854fa35f54e1bce833e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "500000000000000000", gas: "300000", gasPrice: "46700000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "43393", gasUsed: "22393", confirmations: "3158832"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[277], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1511090267 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[277], balance: "70508000000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[277], balance: ( await web3.eth.getBalance( addressList[277], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `demeter9`, addressList[277] )", async function( ) {
		const txOriginal = {blockNumber: "4581921", timeStamp: "1511092377", hash: "0x288d4d7a3ebfde7bbcb0b7e8dd4c775245db0b3a33ef584296a7a3774bd418bf", nonce: "7", blockHash: "0x91468a451047aabf1b646e7c2b28cc208c97095ad440e1b0670dcaf9aab38558", transactionIndex: "5", from: "0x89eb2b388b79f482400ff854fa35f54e1bce833e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "600000000000000000", gas: "300000", gasPrice: "46000000000", isError: "0", txreceipt_status: "0", input: "0xd8bea898000000000000000000000000000000000000000000000000000000000000004000000000000000000000000089eb2b388b79f482400ff854fa35f54e1bce833e000000000000000000000000000000000000000000000000000000000000000864656d6574657239000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "240082", gasUsed: "24508", confirmations: "3158663"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[277], to: addressList[2], value: "600000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `demeter9`}, {type: "address", name: "_referredInvestor", value: addressList[277]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `demeter9`, addressList[277], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1511092377 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[277], balance: "70508000000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[277], balance: ( await web3.eth.getBalance( addressList[277], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4581929", timeStamp: "1511092484", hash: "0xe564d313fb2cc862b165c561ddafd5758a6a7966c29ab968c0f28e23d7ab1b0c", nonce: "8", blockHash: "0xadaa9f719c704723d4f127d05d014050aededcdb525bce7c68bef4048a9d0008", transactionIndex: "1", from: "0x89eb2b388b79f482400ff854fa35f54e1bce833e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "500000000000000000", gas: "300000", gasPrice: "46000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "43393", gasUsed: "22393", confirmations: "3158655"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[277], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1511092484 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[277], balance: "70508000000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[277], balance: ( await web3.eth.getBalance( addressList[277], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `demeter9`, addressList[277] )", async function( ) {
		const txOriginal = {blockNumber: "4581963", timeStamp: "1511092927", hash: "0x88725323de0cc46052b5f6e58e89bf996adc4dc6b0f1df6bd92b2136148db60b", nonce: "9", blockHash: "0x9619eb680254e08a205b2edda337fa67a7d5afb84fbbf2bee894fb87ccad44cd", transactionIndex: "0", from: "0x89eb2b388b79f482400ff854fa35f54e1bce833e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "500000000000000000", gas: "300000", gasPrice: "46000000000", isError: "0", txreceipt_status: "0", input: "0xd8bea898000000000000000000000000000000000000000000000000000000000000004000000000000000000000000089eb2b388b79f482400ff854fa35f54e1bce833e000000000000000000000000000000000000000000000000000000000000000864656d6574657239000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "24508", gasUsed: "24508", confirmations: "3158621"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[277], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `demeter9`}, {type: "address", name: "_referredInvestor", value: addressList[277]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `demeter9`, addressList[277], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1511092927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[277], balance: "70508000000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[277], balance: ( await web3.eth.getBalance( addressList[277], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4581976", timeStamp: "1511093138", hash: "0xde78746b4808703042426a75d8904e660521c7e9f9eded8377e20c1bd2e2cfc4", nonce: "10", blockHash: "0x389bf1aaf85c554a073b3e4c06930fd1d68f5440cfcf5d243535bfcb942c2544", transactionIndex: "4", from: "0x89eb2b388b79f482400ff854fa35f54e1bce833e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "500000000000000000", gas: "350000", gasPrice: "46000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "109385", gasUsed: "22393", confirmations: "3158608"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[277], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1511093138 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[277], balance: "70508000000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[277], balance: ( await web3.eth.getBalance( addressList[277], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4582306", timeStamp: "1511097653", hash: "0x9a22d8901cfd81f3ec0057e8333e753bc47d52e1af42456c212fede4b7b95037", nonce: "11", blockHash: "0x9b17b16cc4fcae78a33e5c5ef94570dfc6c0235da3e9b0e1acc933b40ecf36c8", transactionIndex: "8", from: "0x89eb2b388b79f482400ff854fa35f54e1bce833e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "500000000000000000", gas: "300000", gasPrice: "46000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "226688", gasUsed: "22393", confirmations: "3158278"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[277], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1511097653 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[277], balance: "70508000000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[277], balance: ( await web3.eth.getBalance( addressList[277], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4582329", timeStamp: "1511097926", hash: "0xac3b27799e1415ce0e0513a9380e153d127bd8bb518f55a4d6050093ce03a4b0", nonce: "12", blockHash: "0xd1e956d6bd724aea77bcb527df5a77d285dca0800fbcf17803e6d2d544da9425", transactionIndex: "5", from: "0x89eb2b388b79f482400ff854fa35f54e1bce833e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "500000000000000000", gas: "300000", gasPrice: "46000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "451236", gasUsed: "22393", confirmations: "3158255"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[277], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1511097926 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[277], balance: "70508000000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[277], balance: ( await web3.eth.getBalance( addressList[277], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `Demeter9`, addressList[278] )", async function( ) {
		const txOriginal = {blockNumber: "4582776", timeStamp: "1511104110", hash: "0x861809f22fdcc3ee68e7f62ad326c6eac8e31b0a34aded93fa953b8c2571642c", nonce: "4", blockHash: "0x5f71d6facc4a6831a3103ab1eda67ec6b7ae9ce54c3f2ecb36f63ec9fcbcea2c", transactionIndex: "12", from: "0x41234feaf2ea263f2ac8d77314a96229e49ced5e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "49944", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd8bea898000000000000000000000000000000000000000000000000000000000000004000000000000000000000000041234feaf2ea263f2ac8d77314a96229e49ced5e000000000000000000000000000000000000000000000000000000000000000844656d6574657239000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "370798", gasUsed: "49944", confirmations: "3157808"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[278], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `Demeter9`}, {type: "address", name: "_referredInvestor", value: addressList[278]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `Demeter9`, addressList[278], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1511104110 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "referralCode", type: "string"}, {indexed: false, name: "referredInvestor", type: "address"}], name: "ReferredInvestorAdded", type: "event"} ;
		console.error( "eventCallOriginal[32,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredInvestorAdded", events: [{name: "referralCode", type: "string", value: "Demeter9"}, {name: "referredInvestor", type: "address", value: "0x41234feaf2ea263f2ac8d77314a96229e49ced5e"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[32,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[278], balance: "6046165115671803" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[278], balance: ( await web3.eth.getBalance( addressList[278], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `Demeter9`, addressList[279] )", async function( ) {
		const txOriginal = {blockNumber: "4582808", timeStamp: "1511104543", hash: "0x7490958ac14d213b5d33ad53708185e820e22001d1d07fb497ac12368557489e", nonce: "1", blockHash: "0x9b2fee959509d6f4396c22c479e2bb6106ebe40bd4c4ef14caf98b020f15bc1e", transactionIndex: "38", from: "0xecd097dc8c5609de98e17fcabd5f79dea2ba5780", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "207000000000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0xd8bea8980000000000000000000000000000000000000000000000000000000000000040000000000000000000000000ecd097dc8c5609de98e17fcabd5f79dea2ba5780000000000000000000000000000000000000000000000000000000000000000844656d6574657239000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2334848", gasUsed: "24508", confirmations: "3157776"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[279], to: addressList[2], value: "207000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `Demeter9`}, {type: "address", name: "_referredInvestor", value: addressList[279]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `Demeter9`, addressList[279], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1511104543 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[279], balance: "769000000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[279], balance: ( await web3.eth.getBalance( addressList[279], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `Demeter9`, addressList[279] )", async function( ) {
		const txOriginal = {blockNumber: "4582894", timeStamp: "1511105851", hash: "0x2d76acca4d0ebbbddf944d38284d11555d255e434e1264afdc495cb1ca78ce59", nonce: "24", blockHash: "0x15581a9bfe2edd8ce56824b6044d831a08484d1fa1541b01285da9d58a0f4543", transactionIndex: "9", from: "0xc2cd2a679b80e76d644357d15a0e4d194ece4ed8", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "49944", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd8bea8980000000000000000000000000000000000000000000000000000000000000040000000000000000000000000ecd097dc8c5609de98e17fcabd5f79dea2ba5780000000000000000000000000000000000000000000000000000000000000000844656d6574657239000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "309268", gasUsed: "49944", confirmations: "3157690"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[270], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `Demeter9`}, {type: "address", name: "_referredInvestor", value: addressList[279]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `Demeter9`, addressList[279], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1511105851 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "referralCode", type: "string"}, {indexed: false, name: "referredInvestor", type: "address"}], name: "ReferredInvestorAdded", type: "event"} ;
		console.error( "eventCallOriginal[34,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredInvestorAdded", events: [{name: "referralCode", type: "string", value: "Demeter9"}, {name: "referredInvestor", type: "address", value: "0xecd097dc8c5609de98e17fcabd5f79dea2ba5780"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[34,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[270], balance: "163170451000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[270], balance: ( await web3.eth.getBalance( addressList[270], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `Demeter9`, addressList[279] )", async function( ) {
		const txOriginal = {blockNumber: "4582919", timeStamp: "1511106166", hash: "0xd0522cbb51925d687e9bbf8299d7725432413f256e40cb5761d8600e9afb0e7e", nonce: "2", blockHash: "0xd2760d4ca4f2c022ea681073b91b1364f33a5bfe4c21692621f8705a5996da1c", transactionIndex: "7", from: "0xecd097dc8c5609de98e17fcabd5f79dea2ba5780", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "207000000000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0xd8bea8980000000000000000000000000000000000000000000000000000000000000040000000000000000000000000ecd097dc8c5609de98e17fcabd5f79dea2ba5780000000000000000000000000000000000000000000000000000000000000000844656d6574657239000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "212162", gasUsed: "24508", confirmations: "3157665"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[279], to: addressList[2], value: "207000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `Demeter9`}, {type: "address", name: "_referredInvestor", value: addressList[279]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `Demeter9`, addressList[279], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1511106166 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[279], balance: "769000000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[279], balance: ( await web3.eth.getBalance( addressList[279], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4582938", timeStamp: "1511106427", hash: "0x0e6d3ded17f0e1ed166083b887ef7f4295725278b7f091e709ed693941b17c09", nonce: "5", blockHash: "0xd737f5e953b68507bb4c54c58b9b667545ee4db8a726a22501747e5e421ad305", transactionIndex: "43", from: "0x41234feaf2ea263f2ac8d77314a96229e49ced5e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "100000000000000000", gas: "228704", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1818797", gasUsed: "190587", confirmations: "3157646"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[278], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1511106427 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "investor", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "CompanyTokensIssued", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CompanyTokensIssued", events: [{name: "investor", type: "address", value: "0x41234feaf2ea263f2ac8d77314a96229e49ced5e"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "amount", type: "uint256", value: "513666666666666666666"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "ReferredBonusTokensEmitted", type: "event"} ;
		console.error( "eventCallOriginal[36,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredBonusTokensEmitted", events: [{name: "beneficiary", type: "address", value: "0x41234feaf2ea263f2ac8d77314a96229e49ced5e"}, {name: "amount", type: "uint256", value: "11500000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[36,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WhiteListBonusTokensEmitted", type: "event"} ;
		console.error( "eventCallOriginal[36,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WhiteListBonusTokensEmitted", events: [{name: "beneficiary", type: "address", value: "0x6958165b082d5b83e24b52a8d1835065e2da00d2"}, {name: "amount", type: "uint256", value: "11500000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[36,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[36,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x41234feaf2ea263f2ac8d77314a96229e49ced5e"}, {name: "beneficiary", type: "address", value: "0x41234feaf2ea263f2ac8d77314a96229e49ced5e"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "amount", type: "uint256", value: "230000000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[36,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[278], balance: "6046165115671803" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[278], balance: ( await web3.eth.getBalance( addressList[278], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `Demeter9`, addressList[280] )", async function( ) {
		const txOriginal = {blockNumber: "4582954", timeStamp: "1511106712", hash: "0x347dd3e9c2d33ddaf00486f5198f78850fdd5d2dfd28702d6fc19d58c6594fa1", nonce: "25", blockHash: "0x829eb2c492396fb8e2c22fa450e4bbadd6f7e8128a71e0dc93fbfdb22b3c0ed4", transactionIndex: "28", from: "0xc2cd2a679b80e76d644357d15a0e4d194ece4ed8", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "49944", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd8bea8980000000000000000000000000000000000000000000000000000000000000040000000000000000000000000d927549bcbd42861c5be9ab2464d82e72b475691000000000000000000000000000000000000000000000000000000000000000844656d6574657239000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "715856", gasUsed: "49944", confirmations: "3157630"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[270], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `Demeter9`}, {type: "address", name: "_referredInvestor", value: addressList[280]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `Demeter9`, addressList[280], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1511106712 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "referralCode", type: "string"}, {indexed: false, name: "referredInvestor", type: "address"}], name: "ReferredInvestorAdded", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredInvestorAdded", events: [{name: "referralCode", type: "string", value: "Demeter9"}, {name: "referredInvestor", type: "address", value: "0xd927549bcbd42861c5be9ab2464d82e72b475691"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[270], balance: "163170451000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[270], balance: ( await web3.eth.getBalance( addressList[270], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `Demeter9`, addressList[2] )", async function( ) {
		const txOriginal = {blockNumber: "4582963", timeStamp: "1511106805", hash: "0xe7fcf0e6dab10fc460fa532aaffbd540cc9e2e2f6d5916b1d269f1e19ca1b5ad", nonce: "3", blockHash: "0x6f951e3615250fed6ac41daef6dd972fb3531eaa99ed2d65e094a8c68fdd1942", transactionIndex: "10", from: "0xecd097dc8c5609de98e17fcabd5f79dea2ba5780", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "207000000000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0xd8bea8980000000000000000000000000000000000000000000000000000000000000040000000000000000000000000b8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0000000000000000000000000000000000000000000000000000000000000000844656d6574657239000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "465157", gasUsed: "24508", confirmations: "3157621"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[279], to: addressList[2], value: "207000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `Demeter9`}, {type: "address", name: "_referredInvestor", value: addressList[2]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `Demeter9`, addressList[2], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1511106805 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[279], balance: "769000000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[279], balance: ( await web3.eth.getBalance( addressList[279], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4583000", timeStamp: "1511107241", hash: "0x839ccbc3e5858c19b2a696aee9cf473abb44dc322ea202ece2b90d948f3e9a74", nonce: "1", blockHash: "0xdeba7495082450c2ab2a8c32daf78f52802a4960f262494771ca6bf4e4e832ed", transactionIndex: "101", from: "0xd927549bcbd42861c5be9ab2464d82e72b475691", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "1000000000000000000", gas: "305000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4596718", gasUsed: "190587", confirmations: "3157584"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[280], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1511107241 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "investor", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "CompanyTokensIssued", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CompanyTokensIssued", events: [{name: "investor", type: "address", value: "0xd927549bcbd42861c5be9ab2464d82e72b475691"}, {name: "value", type: "uint256", value: "1000000000000000000"}, {name: "amount", type: "uint256", value: "5136666666666666666666"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "ReferredBonusTokensEmitted", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredBonusTokensEmitted", events: [{name: "beneficiary", type: "address", value: "0xd927549bcbd42861c5be9ab2464d82e72b475691"}, {name: "amount", type: "uint256", value: "115000000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WhiteListBonusTokensEmitted", type: "event"} ;
		console.error( "eventCallOriginal[39,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WhiteListBonusTokensEmitted", events: [{name: "beneficiary", type: "address", value: "0x6958165b082d5b83e24b52a8d1835065e2da00d2"}, {name: "amount", type: "uint256", value: "115000000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[39,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[39,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0xd927549bcbd42861c5be9ab2464d82e72b475691"}, {name: "beneficiary", type: "address", value: "0xd927549bcbd42861c5be9ab2464d82e72b475691"}, {name: "value", type: "uint256", value: "1000000000000000000"}, {name: "amount", type: "uint256", value: "2300000000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[39,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[280], balance: "29255694613729400" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[280], balance: ( await web3.eth.getBalance( addressList[280], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4583043", timeStamp: "1511107998", hash: "0x3c0dbbe8c0ed25f100ff48e7e45f678e0d3329ef20073f96bd5c774fb834f6f4", nonce: "4", blockHash: "0x102bd0023d28e2e4de92ec75691987f8333f01f18eddf4a514c18696ef3a1543", transactionIndex: "10", from: "0xecd097dc8c5609de98e17fcabd5f79dea2ba5780", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "209598406000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "510649", gasUsed: "190587", confirmations: "3157541"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[279], to: addressList[2], value: "209598406000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1511107998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "investor", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "CompanyTokensIssued", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CompanyTokensIssued", events: [{name: "investor", type: "address", value: "0xecd097dc8c5609de98e17fcabd5f79dea2ba5780"}, {name: "value", type: "uint256", value: "209598406000000000"}, {name: "amount", type: "uint256", value: "1076637145486666666666"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "ReferredBonusTokensEmitted", type: "event"} ;
		console.error( "eventCallOriginal[40,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredBonusTokensEmitted", events: [{name: "beneficiary", type: "address", value: "0xecd097dc8c5609de98e17fcabd5f79dea2ba5780"}, {name: "amount", type: "uint256", value: "24103816690000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[40,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WhiteListBonusTokensEmitted", type: "event"} ;
		console.error( "eventCallOriginal[40,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WhiteListBonusTokensEmitted", events: [{name: "beneficiary", type: "address", value: "0x6958165b082d5b83e24b52a8d1835065e2da00d2"}, {name: "amount", type: "uint256", value: "24103816690000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[40,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[40,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0xecd097dc8c5609de98e17fcabd5f79dea2ba5780"}, {name: "beneficiary", type: "address", value: "0xecd097dc8c5609de98e17fcabd5f79dea2ba5780"}, {name: "value", type: "uint256", value: "209598406000000000"}, {name: "amount", type: "uint256", value: "482076333800000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[40,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[279], balance: "769000000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[279], balance: ( await web3.eth.getBalance( addressList[279], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4583223", timeStamp: "1511110589", hash: "0x124c40c0edd20bf0734bdb46314492c7cc06fedbd98560ceda56a27f9177af1e", nonce: "6", blockHash: "0xf2c0c343cc7cdd80c27facbbcab2533ddd0ae8a4d71b66f66260d4c65f19db1c", transactionIndex: "111", from: "0x41234feaf2ea263f2ac8d77314a96229e49ced5e", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "100000000000000000", gas: "192704", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5571417", gasUsed: "160587", confirmations: "3157361"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[278], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1511110589 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "investor", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "CompanyTokensIssued", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "CompanyTokensIssued", events: [{name: "investor", type: "address", value: "0x41234feaf2ea263f2ac8d77314a96229e49ced5e"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "amount", type: "uint256", value: "513666666666666666666"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "ReferredBonusTokensEmitted", type: "event"} ;
		console.error( "eventCallOriginal[41,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredBonusTokensEmitted", events: [{name: "beneficiary", type: "address", value: "0x41234feaf2ea263f2ac8d77314a96229e49ced5e"}, {name: "amount", type: "uint256", value: "11500000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[41,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WhiteListBonusTokensEmitted", type: "event"} ;
		console.error( "eventCallOriginal[41,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WhiteListBonusTokensEmitted", events: [{name: "beneficiary", type: "address", value: "0x6958165b082d5b83e24b52a8d1835065e2da00d2"}, {name: "amount", type: "uint256", value: "11500000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[41,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: true, name: "beneficiary", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "TokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[41,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokenPurchase", events: [{name: "purchaser", type: "address", value: "0x41234feaf2ea263f2ac8d77314a96229e49ced5e"}, {name: "beneficiary", type: "address", value: "0x41234feaf2ea263f2ac8d77314a96229e49ced5e"}, {name: "value", type: "uint256", value: "100000000000000000"}, {name: "amount", type: "uint256", value: "230000000000000000000"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[41,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[278], balance: "6046165115671803" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[278], balance: ( await web3.eth.getBalance( addressList[278], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `Demeter9`, addressList[281] )", async function( ) {
		const txOriginal = {blockNumber: "4588654", timeStamp: "1511184729", hash: "0x516dbe65cd42fc41fd789326350ef758f22f30466c29c49d02402a65110101f6", nonce: "74", blockHash: "0xec37e5229a813830ac828f102ef52f13f7abc83a36388e6a7173b4ee2c92460f", transactionIndex: "11", from: "0xd1c42b9f7d4c8d056bc72ec3d43a984c97e3fe31", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "49944", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd8bea8980000000000000000000000000000000000000000000000000000000000000040000000000000000000000000d1c42b9f7d4c8d056bc72ec3d43a984c97e3fe31000000000000000000000000000000000000000000000000000000000000000844656d6574657239000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "699511", gasUsed: "49944", confirmations: "3151930"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[281], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `Demeter9`}, {type: "address", name: "_referredInvestor", value: addressList[281]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `Demeter9`, addressList[281], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1511184729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "referralCode", type: "string"}, {indexed: false, name: "referredInvestor", type: "address"}], name: "ReferredInvestorAdded", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredInvestorAdded", events: [{name: "referralCode", type: "string", value: "Demeter9"}, {name: "referredInvestor", type: "address", value: "0xd1c42b9f7d4c8d056bc72ec3d43a984c97e3fe31"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[281], balance: "48014825079495513" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[281], balance: ( await web3.eth.getBalance( addressList[281], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4593742", timeStamp: "1511256706", hash: "0x2b8091898c1acd06a471006ee0662d5b017cd78f834f9734c549dcb58aff0c81", nonce: "0", blockHash: "0xfff9fab7eb91148a6c34612f89233a4c54ccf6cfa1f096d1e73a5151e22b1135", transactionIndex: "53", from: "0xf302e2678dde2a31481d3987172ab44541dae98f", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "437429590000000000", gas: "21000", gasPrice: "21000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "2678544", gasUsed: "21000", confirmations: "3146842"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[282], to: addressList[2], value: "437429590000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[282], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[282], balance: ( await web3.eth.getBalance( addressList[282], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4593778", timeStamp: "1511257128", hash: "0xff95bf94601084f3af8c15bae154c855e5556bc874e336d0cd51ef039caba57f", nonce: "1", blockHash: "0x73aacb32e5f926c658cfff06534fbfe11bd3795466a143017da229ab705902e7", transactionIndex: "50", from: "0xf302e2678dde2a31481d3987172ab44541dae98f", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "436788611000000000", gas: "21000", gasPrice: "21000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1317014", gasUsed: "21000", confirmations: "3146806"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[282], to: addressList[2], value: "436788611000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[282], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[282], balance: ( await web3.eth.getBalance( addressList[282], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4593783", timeStamp: "1511257161", hash: "0xd4666a8339796f05dc135c1c98942283e3af7e7b16947bfc625404d4be773c2a", nonce: "2", blockHash: "0x14d737882e155665d98ccbc2b3cd87cc7d72b22ffc4b9688c88ab407c3458806", transactionIndex: "10", from: "0xf302e2678dde2a31481d3987172ab44541dae98f", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "436547590000000000", gas: "21000", gasPrice: "21000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "316794", gasUsed: "21000", confirmations: "3146801"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[282], to: addressList[2], value: "436547590000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[282], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[282], balance: ( await web3.eth.getBalance( addressList[282], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4593791", timeStamp: "1511257289", hash: "0xc93d2393f3551531fc7abeb25c489f224359318f779cd07e785af8de3f89f67c", nonce: "3", blockHash: "0xd3bbf99e333e9852dbd2a93012f930f6a129c3e9098720a841fd924f323c8f94", transactionIndex: "14", from: "0xf302e2678dde2a31481d3987172ab44541dae98f", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "435917590000000000", gas: "30000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "505145", gasUsed: "22393", confirmations: "3146793"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[282], to: addressList[2], value: "435917590000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1511257289 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[282], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[282], balance: ( await web3.eth.getBalance( addressList[282], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4593803", timeStamp: "1511257467", hash: "0xb6f17a90a0a58910ef20dc3b0ace5f8b00db9ef06073a5134fd36b3a730c10b0", nonce: "4", blockHash: "0xc4151807ae51fc81ff689d52b1c10c2918cd01ae1f292891691e46b5f2c17715", transactionIndex: "15", from: "0xf302e2678dde2a31481d3987172ab44541dae98f", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "429777337000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "845316", gasUsed: "22393", confirmations: "3146781"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[282], to: addressList[2], value: "429777337000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1511257467 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[282], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[282], balance: ( await web3.eth.getBalance( addressList[282], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4593803", timeStamp: "1511257467", hash: "0x78195e6a58e9a27c4374d8753e02efafcc0ab394dd644541901cd636a6246010", nonce: "5", blockHash: "0xc4151807ae51fc81ff689d52b1c10c2918cd01ae1f292891691e46b5f2c17715", transactionIndex: "98", from: "0xf302e2678dde2a31481d3987172ab44541dae98f", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "429307084000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "5697864", gasUsed: "22393", confirmations: "3146781"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[282], to: addressList[2], value: "429307084000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1511257467 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[282], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[282], balance: ( await web3.eth.getBalance( addressList[282], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: addReferredInvestor( `Demeter9`, addressList[282] )", async function( ) {
		const txOriginal = {blockNumber: "4593835", timeStamp: "1511257961", hash: "0x63579d591638ddb813e2f52e8d4ae137fece0d791a4dbff1765426fd19965470", nonce: "6", blockHash: "0xbd3a85a22ccc7f4efd254b6b05ed0ebec4aebfb5664bbbdb5983af3ff8489624", transactionIndex: "23", from: "0xf302e2678dde2a31481d3987172ab44541dae98f", to: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0", value: "0", gas: "49944", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd8bea8980000000000000000000000000000000000000000000000000000000000000040000000000000000000000000f302e2678dde2a31481d3987172ab44541dae98f000000000000000000000000000000000000000000000000000000000000000844656d6574657239000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1079535", gasUsed: "49944", confirmations: "3146749"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[282], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_referralCode", value: `Demeter9`}, {type: "address", name: "_referredInvestor", value: addressList[282]}], name: "addReferredInvestor", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReferredInvestor(string,address)" ]( `Demeter9`, addressList[282], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1511257961 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "referralCode", type: "string"}, {indexed: false, name: "referredInvestor", type: "address"}], name: "ReferredInvestorAdded", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ReferredInvestorAdded", events: [{name: "referralCode", type: "string", value: "Demeter9"}, {name: "referredInvestor", type: "address", value: "0xf302e2678dde2a31481d3987172ab44541dae98f"}], address: "0xb8eb17dfa4ec9a6457e4c8fb3d724c0ed9ba4cf0"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[282], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[282], balance: ( await web3.eth.getBalance( addressList[282], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
