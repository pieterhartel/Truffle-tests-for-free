const Dice = artifacts.require( "./Dice.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Dice" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xCB932640a448b264fdBCfE81d6c34A2887f89F15", "0xcB71EB21F53a2F4de0F26dc90518Df10Be13D1EC", "0xd1b24eb6A8318008AFD9F89C49980B9bd5C64Ac4", "0xEe54D208f62368B4efFe176CB548A317dcAe963F", "0x008ca4F1bA79D1A265617c6206d7884ee8108a78", "0x47a49ACb7f3DF01e02Fc8B2977a353269759b731", "0x153CaF10387B13fDa75A03f974fa5C2D2763d5a8", "0x966226303da9644E535E560fDfaD5b4cd1f333B9", "0xE1a2CABFc6412BEC651FCD7DBBAD0266b6d78d1b", "0xb653684d5e213cfEF2a0dc2820a589E283Cc13a1"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "bankroll", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "player", type: "address"}], name: "statsOf", outputs: [{name: "", type: "uint256[5]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isMining", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxProfitAsPercentOfHouse", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "payoutsPaused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxNumber", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxProfitDivisor", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minNumber", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "player", type: "address"}], name: "lastSession", outputs: [{name: "", type: "address"}, {name: "", type: "uint256[7]"}, {name: "", type: "bytes32[3]"}, {name: "", type: "bool[2]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "rollUnder", type: "uint256"}, {name: "wager", type: "uint256"}], name: "profit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSessions", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "player", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalWagered", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minBet", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "whitelist", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalWon", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxProfit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalBets", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "gamePaused", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "houseEdge", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "houseEdgeDivisor", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "futureDelta", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onCredit", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "player", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "onWithdraw", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}], name: "WhitelistedAddressAdded", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}], name: "WhitelistedAddressRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["onSessionOpen(uint256,uint256,uint256,address,uint256,uint256,uint256)", "onSessionClose(uint256,uint256,uint256,uint256,uint256,address,uint256,uint256,uint256,uint256,bool)", "onCredit(address,uint256)", "onWithdraw(address,uint256)", "WhitelistedAddressAdded(address)", "WhitelistedAddressRemoved(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xb589cb490debd784d510b133d7ea2fd792649003a838604effd1aae3862f2811", "0x2456d1145cd5c216408d97c67e5ef1c09ff51832a54a9b1d49b4a95c27452b5a", "0xe2bccdac21b198a76a034160654c2fc6827d1b79e9461f970b2ed7d74060d523", "0xccad973dcd043c7d680389db4378bd6b9775db7124092e9e0422c9e46d7985dc", "0xd1bba68c128cc3f427e5831b3c6f99f480b6efa6b9e80c757768f6124158cc3f", "0xf1abf01a1043b7c244d128e8595cf0c1d10743b022b03a02dffd8ca3bf729f5a", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6602301 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6606503 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Dice", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "bankroll", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bankroll()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "player", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "statsOf", outputs: [{name: "", type: "uint256[5]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "statsOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isMining", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isMining()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxProfitAsPercentOfHouse", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxProfitAsPercentOfHouse()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "payoutsPaused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "payoutsPaused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxProfitDivisor", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxProfitDivisor()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "player", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "lastSession", outputs: [{name: "", type: "address"}, {name: "", type: "uint256[7]"}, {name: "", type: "bytes32[3]"}, {name: "", type: "bool[2]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lastSession(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "rollUnder", value: random.range( maxRandom )}, {type: "uint256", name: "wager", value: random.range( maxRandom )}], name: "profit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "profit(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSessions", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSessions()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "player", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalWagered", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalWagered()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minBet", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minBet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "whitelist", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whitelist(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalWon", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalWon()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxProfit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalBets", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalBets()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gamePaused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gamePaused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "houseEdge", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "houseEdge()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "houseEdgeDivisor", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "houseEdgeDivisor()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "futureDelta", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "futureDelta()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Dice", function( accounts ) {

	it( "TEST: Dice(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6602301", timeStamp: "1540773363", hash: "0x81889f68d10f578b99880c647adc78190ac7624aef782ab489711a3935437129", nonce: "713", blockHash: "0x19b546bfebbfdeacd2806e03b3359fdde1650d5a3a5023e8e05ba522cd61d59c", transactionIndex: "93", from: "0xcb71eb21f53a2f4de0f26dc90518df10be13d1ec", to: 0, value: "0", gas: "2560205", gasPrice: "11200000000", isError: "0", txreceipt_status: "1", input: "0x594151e0", contractAddress: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", cumulativeGasUsed: "4945917", gasUsed: "2560205", confirmations: "1130738"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Dice", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Dice.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540773363 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Dice.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "248923651293239522" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: updateBankrollAddress( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6602368", timeStamp: "1540774417", hash: "0x3e989e43b6fbc53955a8244be58b8ecc3a422363f99d2f2444e4c4c42af35cc4", nonce: "719", blockHash: "0x2a5d02184e73ecac2c169162adfcf0d442eb1b5636f754a613ceb034b0998183", transactionIndex: "77", from: "0xcb71eb21f53a2f4de0f26dc90518df10be13d1ec", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "52266", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x0bc0504e000000000000000000000000d1b24eb6a8318008afd9f89c49980b9bd5c64ac4", contractAddress: "", cumulativeGasUsed: "3810667", gasUsed: "52266", confirmations: "1130671"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "bankrollAddress", value: addressList[4]}], name: "updateBankrollAddress", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateBankrollAddress(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540774417 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "248923651293239522" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: ownerSetMaxProfitAsPercentOfHouse( \"10000\" )", async function( ) {
		const txOriginal = {blockNumber: "6604138", timeStamp: "1540799820", hash: "0x3d4225c7860742ed9620d987bf3eff5d9c620c534f9937ffd42680e82d44e1d6", nonce: "770", blockHash: "0x325431a41aec75be8488ba779d6a6e778a1a7eff2ef85f0b82633475aadd006f", transactionIndex: "0", from: "0xcb71eb21f53a2f4de0f26dc90518df10be13d1ec", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "51105", gasPrice: "17000000000", isError: "0", txreceipt_status: "1", input: "0x5e968a490000000000000000000000000000000000000000000000000000000000002710", contractAddress: "", cumulativeGasUsed: "51105", gasUsed: "51105", confirmations: "1128901"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "newMaxProfitAsPercent", value: "10000"}], name: "ownerSetMaxProfitAsPercentOfHouse", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "ownerSetMaxProfitAsPercentOfHouse(uint256)" ]( "10000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540799820 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "248923651293239522" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "6604220", timeStamp: "1540801004", hash: "0x1b351df2ada32a31e9c525b124f88b38728be9ea9e8478c2afb92807833e2bfe", nonce: "772", blockHash: "0x1fd14aa8de8413c41a25a0c2d2318ce558ece30f83ff3f4e5d62a719d5bba738", transactionIndex: "63", from: "0xcb71eb21f53a2f4de0f26dc90518df10be13d1ec", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "10000000000000000", gas: "623794", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "4214547", gasUsed: "415863", confirmations: "1128819"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "50"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540801004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "54159795384039027511060449313299706775655108157308496983757421105666562734313"}, {name: "block", type: "uint256", value: "6604220"}, {name: "futureBlock", type: "uint256", value: "6604222"}, {name: "player", type: "address", value: "0xcb71eb21f53a2f4de0f26dc90518df10be13d1ec"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "50"}, {name: "profit", type: "uint256", value: "10204081632653060"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "248923651293239522" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "6604233", timeStamp: "1540801131", hash: "0x27690f994dfa5cb7042ec2b18f818e1cc9a4b83649025fd2872c6b16b22a3f60", nonce: "296", blockHash: "0x2c328cb6992ca90520bf5155aad363d46a97cffbbc5eec255715c21806a86dd8", transactionIndex: "141", from: "0xee54d208f62368b4effe176cb548a317dcae963f", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "10000000000000000", gas: "623794", gasPrice: "7730000000", isError: "1", txreceipt_status: "0", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "5392053", gasUsed: "623794", confirmations: "1128806"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "44714005697437672" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6604239", timeStamp: "1540801205", hash: "0xa6c0f97babc3eb5a587985f75d7c9a77beb91cebe7350d99c9d41027712e1827", nonce: "773", blockHash: "0x69384dcd169707a62a4552912f46b81a07426d680871e325f4b1037d411f2ba4", transactionIndex: "36", from: "0xcb71eb21f53a2f4de0f26dc90518df10be13d1ec", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "535429", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "1772943", gasUsed: "341953", confirmations: "1128800"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540801205 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "54159795384039027511060449313299706775655108157308496983757421105666562734313"}, {name: "block", type: "uint256", value: "6604220"}, {name: "futureBlock", type: "uint256", value: "6604222"}, {name: "futureHash", type: "uint256", value: "77148060563945356151483226420856422881825228357912782590035750077782408136832"}, {name: "seed", type: "uint256", value: "103519446423925201143138256589337660763896259384919273915648780145461203616746"}, {name: "player", type: "address", value: "0xcb71eb21f53a2f4de0f26dc90518df10be13d1ec"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "50"}, {name: "dieRoll", type: "uint256", value: "13"}, {name: "payout", type: "uint256", value: "20204081632653060"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "248923651293239522" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"68\" )", async function( ) {
		const txOriginal = {blockNumber: "6604291", timeStamp: "1540801999", hash: "0xd35ba5b05deefd1a192996e4120c1e85a81e33848fdc780b4c9cb23c27e4f95f", nonce: "1764", blockHash: "0x3b04d6d8a4dfc277180d49138581ef825a606b08cdcc514da77011e7d6b341bd", transactionIndex: "45", from: "0x008ca4f1ba79d1a265617c6206d7884ee8108a78", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "50000000000000000", gas: "553876", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000044", contractAddress: "", cumulativeGasUsed: "2603015", gasUsed: "354251", confirmations: "1128748"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "68"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "68", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540801999 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "9108293707294498676871627856277371161619750386320004009967420988165027703762"}, {name: "block", type: "uint256", value: "6604291"}, {name: "futureBlock", type: "uint256", value: "6604293"}, {name: "player", type: "address", value: "0x008ca4f1ba79d1a265617c6206d7884ee8108a78"}, {name: "wager", type: "uint256", value: "50000000000000000"}, {name: "rollUnder", type: "uint256", value: "68"}, {name: "profit", type: "uint256", value: "23880597014925373"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "38414031130137890" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"68\" )", async function( ) {
		const txOriginal = {blockNumber: "6604319", timeStamp: "1540802395", hash: "0xe663a645251bc61c18457f4325a35ab54ee9e21b938636133f9fbd518705e4ff", nonce: "1765", blockHash: "0x53e37f5dd08f851c11a41cdadc232e60793491cbe6e43d528b6b798475ad1b46", transactionIndex: "73", from: "0x008ca4f1ba79d1a265617c6206d7884ee8108a78", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "50000000000000000", gas: "737091", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000044", contractAddress: "", cumulativeGasUsed: "6235678", gasUsed: "431394", confirmations: "1128720"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "68"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "68", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540802395 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "41177403523656570515950693266299444506207354243003832984121889803122647238475"}, {name: "block", type: "uint256", value: "6604319"}, {name: "futureBlock", type: "uint256", value: "6604321"}, {name: "player", type: "address", value: "0x008ca4f1ba79d1a265617c6206d7884ee8108a78"}, {name: "wager", type: "uint256", value: "50000000000000000"}, {name: "rollUnder", type: "uint256", value: "68"}, {name: "profit", type: "uint256", value: "23880597014925373"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "9108293707294498676871627856277371161619750386320004009967420988165027703762"}, {name: "block", type: "uint256", value: "6604291"}, {name: "futureBlock", type: "uint256", value: "6604293"}, {name: "futureHash", type: "uint256", value: "30630965386703389085478027583281178349350314580338910749092765340694530850524"}, {name: "seed", type: "uint256", value: "5926563573000696973419125636222661321436228042607991946420068347083949976783"}, {name: "player", type: "address", value: "0x008ca4f1ba79d1a265617c6206d7884ee8108a78"}, {name: "wager", type: "uint256", value: "50000000000000000"}, {name: "rollUnder", type: "uint256", value: "68"}, {name: "dieRoll", type: "uint256", value: "45"}, {name: "payout", type: "uint256", value: "73880597014925373"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "38414031130137890" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"42\" )", async function( ) {
		const txOriginal = {blockNumber: "6604330", timeStamp: "1540802528", hash: "0x78f41ff5acae79fe674348564ecc8f1dc07a1cb451d4d19b0c2db4b6f39bbb7c", nonce: "7", blockHash: "0xc52d77cb699b7f3afb4634171ea2f71e6a29710de2b4a443798d2bd7456d85c4", transactionIndex: "27", from: "0x47a49acb7f3df01e02fc8b2977a353269759b731", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "780000", gasPrice: "12000000000", isError: "1", txreceipt_status: "0", input: "0x6898f82b000000000000000000000000000000000000000000000000000000000000002a", contractAddress: "", cumulativeGasUsed: "1094608", gasUsed: "53660", confirmations: "1128709"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "42"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "42", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540802528 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: playWithVault( \"68\", \"50000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6604330", timeStamp: "1540802528", hash: "0x81c8c2f766b4676da7764d319cb8b0e63fccaef10ce390c0bfe5923aca8af4ad", nonce: "1766", blockHash: "0xc52d77cb699b7f3afb4634171ea2f71e6a29710de2b4a443798d2bd7456d85c4", transactionIndex: "78", from: "0x008ca4f1ba79d1a265617c6206d7884ee8108a78", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "614758", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x9cd8e54c000000000000000000000000000000000000000000000000000000000000004400000000000000000000000000000000000000000000000000b1a2bc2ec50000", contractAddress: "", cumulativeGasUsed: "3297003", gasUsed: "349839", confirmations: "1128709"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "68"}, {type: "uint256", name: "wager", value: "50000000000000000"}], name: "playWithVault", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playWithVault(uint256,uint256)" ]( "68", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540802528 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "102358281926046261380359461424346048983794520333221838676459461853635316768210"}, {name: "block", type: "uint256", value: "6604330"}, {name: "futureBlock", type: "uint256", value: "6604332"}, {name: "player", type: "address", value: "0x008ca4f1ba79d1a265617c6206d7884ee8108a78"}, {name: "wager", type: "uint256", value: "50000000000000000"}, {name: "rollUnder", type: "uint256", value: "68"}, {name: "profit", type: "uint256", value: "23880597014925373"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "41177403523656570515950693266299444506207354243003832984121889803122647238475"}, {name: "block", type: "uint256", value: "6604319"}, {name: "futureBlock", type: "uint256", value: "6604321"}, {name: "futureHash", type: "uint256", value: "91605970169961035978625331818939372407605455780848130079402194969258581071853"}, {name: "seed", type: "uint256", value: "66941096701173846909964145177556782498820546479457854233738933933163137402273"}, {name: "player", type: "address", value: "0x008ca4f1ba79d1a265617c6206d7884ee8108a78"}, {name: "wager", type: "uint256", value: "50000000000000000"}, {name: "rollUnder", type: "uint256", value: "68"}, {name: "dieRoll", type: "uint256", value: "25"}, {name: "payout", type: "uint256", value: "73880597014925373"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "38414031130137890" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"43\" )", async function( ) {
		const txOriginal = {blockNumber: "6604379", timeStamp: "1540803029", hash: "0x5df44ec9ea0f5cc323012be1db01b6c29f4faeaba9f9326aede77f9fbfd86fd2", nonce: "8", blockHash: "0x71e2b655c33306d3a794fe277e836ccf44779adb1946ec11a02a34780df07ccf", transactionIndex: "60", from: "0x47a49acb7f3df01e02fc8b2977a353269759b731", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "10000000000000000", gas: "706179", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b000000000000000000000000000000000000000000000000000000000000002b", contractAddress: "", cumulativeGasUsed: "7439376", gasUsed: "513215", confirmations: "1128660"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "43"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "43", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540803029 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "94253221896602442347448711871097559820598584306286948319299389487625474577089"}, {name: "block", type: "uint256", value: "6604379"}, {name: "futureBlock", type: "uint256", value: "6604381"}, {name: "player", type: "address", value: "0x47a49acb7f3df01e02fc8b2977a353269759b731"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "43"}, {name: "profit", type: "uint256", value: "13571428571428570"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "102358281926046261380359461424346048983794520333221838676459461853635316768210"}, {name: "block", type: "uint256", value: "6604330"}, {name: "futureBlock", type: "uint256", value: "6604332"}, {name: "futureHash", type: "uint256", value: "489412041469556949096316896255845661041150162707979087303045353686416277834"}, {name: "seed", type: "uint256", value: "1362447626223781046842904351973194423328867349900194329750454710898388670984"}, {name: "player", type: "address", value: "0x008ca4f1ba79d1a265617c6206d7884ee8108a78"}, {name: "wager", type: "uint256", value: "50000000000000000"}, {name: "rollUnder", type: "uint256", value: "68"}, {name: "dieRoll", type: "uint256", value: "98"}, {name: "payout", type: "uint256", value: "0"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "6604519", timeStamp: "1540804836", hash: "0x2a64dfe474dab572e29d8022b33fbdbbe4febe8440ca87e00720800ebec37576", nonce: "9", blockHash: "0x860099efac54b6d670a868e4a4b8eba18a27547d8f9d346ec5e3e45c1d537f94", transactionIndex: "27", from: "0x47a49acb7f3df01e02fc8b2977a353269759b731", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "10000000000000000", gas: "511201", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "4230459", gasUsed: "348232", confirmations: "1128520"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540804836 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "90266073582947200874397239016315668869080038324587469990166241194816705571998"}, {name: "block", type: "uint256", value: "6604519"}, {name: "futureBlock", type: "uint256", value: "6604521"}, {name: "player", type: "address", value: "0x47a49acb7f3df01e02fc8b2977a353269759b731"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "51"}, {name: "profit", type: "uint256", value: "9800000000000000"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "94253221896602442347448711871097559820598584306286948319299389487625474577089"}, {name: "block", type: "uint256", value: "6604379"}, {name: "futureBlock", type: "uint256", value: "6604381"}, {name: "futureHash", type: "uint256", value: "88776428811415068519513267046242320430732176312079086369920850157765219135917"}, {name: "seed", type: "uint256", value: "31142159996724979558154963233354443683628271534841988007586337373973859432883"}, {name: "player", type: "address", value: "0x47a49acb7f3df01e02fc8b2977a353269759b731"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "43"}, {name: "dieRoll", type: "uint256", value: "46"}, {name: "payout", type: "uint256", value: "0"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: playWithVault( \"71\", \"50000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6604547", timeStamp: "1540805213", hash: "0xde198109dc60045d06fdc29c922c05d7bc995775134bc676cd39ecafdbc2ee94", nonce: "1772", blockHash: "0x510f390ef8440c956c0992fa57f4f0633ca8083fd8b70915fb32cd6e94d894ee", transactionIndex: "131", from: "0x008ca4f1ba79d1a265617c6206d7884ee8108a78", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "682258", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x9cd8e54c000000000000000000000000000000000000000000000000000000000000004700000000000000000000000000000000000000000000000000b1a2bc2ec50000", contractAddress: "", cumulativeGasUsed: "5415648", gasUsed: "409839", confirmations: "1128492"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "71"}, {type: "uint256", name: "wager", value: "50000000000000000"}], name: "playWithVault", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playWithVault(uint256,uint256)" ]( "71", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540805213 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "41258975630829219316536859157421844368269450361824744953825809605402665530126"}, {name: "block", type: "uint256", value: "6604547"}, {name: "futureBlock", type: "uint256", value: "6604549"}, {name: "player", type: "address", value: "0x008ca4f1ba79d1a265617c6206d7884ee8108a78"}, {name: "wager", type: "uint256", value: "50000000000000000"}, {name: "rollUnder", type: "uint256", value: "71"}, {name: "profit", type: "uint256", value: "20714285714285713"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "90266073582947200874397239016315668869080038324587469990166241194816705571998"}, {name: "block", type: "uint256", value: "6604519"}, {name: "futureBlock", type: "uint256", value: "6604521"}, {name: "futureHash", type: "uint256", value: "67454922406297648744730581790272640735291422442499133130614319159561347716621"}, {name: "seed", type: "uint256", value: "35598640685416738699160328017730432360604890835143015889768813050842405963196"}, {name: "player", type: "address", value: "0x47a49acb7f3df01e02fc8b2977a353269759b731"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "51"}, {name: "dieRoll", type: "uint256", value: "21"}, {name: "payout", type: "uint256", value: "19800000000000000"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "38414031130137890" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: playWithVault( \"44\", \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6604713", timeStamp: "1540807925", hash: "0xd0d04e46e55116ef6323fdb042202bdaa5ad01386f56935a6be2f83932d016f9", nonce: "10", blockHash: "0x0e2f63f370b87f3a74caddddba8ae403b0714053719922171709b5ebb55876ce", transactionIndex: "160", from: "0x47a49acb7f3df01e02fc8b2977a353269759b731", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "557515", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x9cd8e54c000000000000000000000000000000000000000000000000000000000000002c000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "6078536", gasUsed: "311677", confirmations: "1128326"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "44"}, {type: "uint256", name: "wager", value: "10000000000000000"}], name: "playWithVault", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playWithVault(uint256,uint256)" ]( "44", "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540807925 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "63103535552440732602374623736722142841372286062252614629018283499792602296083"}, {name: "block", type: "uint256", value: "6604713"}, {name: "futureBlock", type: "uint256", value: "6604715"}, {name: "player", type: "address", value: "0x47a49acb7f3df01e02fc8b2977a353269759b731"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "44"}, {name: "profit", type: "uint256", value: "13023255813953488"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "41258975630829219316536859157421844368269450361824744953825809605402665530126"}, {name: "block", type: "uint256", value: "6604547"}, {name: "futureBlock", type: "uint256", value: "6604549"}, {name: "futureHash", type: "uint256", value: "18584255573885174763377287988077500530677627676091304665973995720412628297123"}, {name: "seed", type: "uint256", value: "38877265090519434903149320249571976735193356634629954510033007968171199857053"}, {name: "player", type: "address", value: "0x008ca4f1ba79d1a265617c6206d7884ee8108a78"}, {name: "wager", type: "uint256", value: "50000000000000000"}, {name: "rollUnder", type: "uint256", value: "71"}, {name: "dieRoll", type: "uint256", value: "71"}, {name: "payout", type: "uint256", value: "0"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"67\" )", async function( ) {
		const txOriginal = {blockNumber: "6604983", timeStamp: "1540812073", hash: "0x3e6219962f4568e04f82201db04c46a999ae19c8ac738b769f5dbed79911b9c1", nonce: "388", blockHash: "0xbeb6529f3a10388dc18e0dc836885a91223a07e3636a6f6b05edc13183a99d71", transactionIndex: "83", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "50000000000000000", gas: "738312", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000043", contractAddress: "", cumulativeGasUsed: "4305165", gasUsed: "462208", confirmations: "1128056"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "67"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "67", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540812073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "84930872824684926520491589297757734984185884006407401873312276177996841445080"}, {name: "block", type: "uint256", value: "6604983"}, {name: "futureBlock", type: "uint256", value: "6604985"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "50000000000000000"}, {name: "rollUnder", type: "uint256", value: "67"}, {name: "profit", type: "uint256", value: "24999999999999999"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "63103535552440732602374623736722142841372286062252614629018283499792602296083"}, {name: "block", type: "uint256", value: "6604713"}, {name: "futureBlock", type: "uint256", value: "6604715"}, {name: "futureHash", type: "uint256", value: "67454922406297648744730581790272640735291422442499133130614319159561347716621"}, {name: "seed", type: "uint256", value: "35598640685416738699160328017730432360604890835143015889768813050842405963196"}, {name: "player", type: "address", value: "0x47a49acb7f3df01e02fc8b2977a353269759b731"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "44"}, {name: "dieRoll", type: "uint256", value: "100"}, {name: "payout", type: "uint256", value: "0"}, {name: "timeout", type: "bool", value: true}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6604992", timeStamp: "1540812200", hash: "0x93d7d692d2a7b1cdca8438f8e6364ce4e611ed3c72b97ff9bacc850330d16d63", nonce: "389", blockHash: "0x2ad128dc3abf28edcb711131a350ce5472b134c72b849ef5fe60aef0f5188f81", transactionIndex: "83", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "320686", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "4637238", gasUsed: "198791", confirmations: "1128047"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540812200 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "84930872824684926520491589297757734984185884006407401873312276177996841445080"}, {name: "block", type: "uint256", value: "6604983"}, {name: "futureBlock", type: "uint256", value: "6604985"}, {name: "futureHash", type: "uint256", value: "99427296235829060147585241098469830952191910672790205213191436079426594049774"}, {name: "seed", type: "uint256", value: "16052536035462621330378714026894416551480620877893444757693383788626109915671"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "50000000000000000"}, {name: "rollUnder", type: "uint256", value: "67"}, {name: "dieRoll", type: "uint256", value: "93"}, {name: "payout", type: "uint256", value: "0"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"69\" )", async function( ) {
		const txOriginal = {blockNumber: "6605001", timeStamp: "1540812303", hash: "0xb6f52ad438463c9226e0a710fa81e07129f437cba9fe8a9000884fafb562cad0", nonce: "390", blockHash: "0xad1e641186bad242cf21cbb3265911f008f647e6b3aeca471a4d2e3d1bed4120", transactionIndex: "72", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "10000000000000000", gas: "306402", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000045", contractAddress: "", cumulativeGasUsed: "7235717", gasUsed: "174268", confirmations: "1128038"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "69"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "69", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540812303 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "39747767578997984973164168527112918146817979531179239484356624759043815908577"}, {name: "block", type: "uint256", value: "6605001"}, {name: "futureBlock", type: "uint256", value: "6605003"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "profit", type: "uint256", value: "4558823529411764"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6605012", timeStamp: "1540812495", hash: "0xad16a2c343080749046905ce0f6a31163cade958aaf73b140559dc07d5f9b84e", nonce: "391", blockHash: "0x0333c7b3f8e9662787bb1701b8ba3821910f39b67d320d6f3a5569109d1f4035", transactionIndex: "92", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "400429", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "7237148", gasUsed: "251953", confirmations: "1128027"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540812495 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "39747767578997984973164168527112918146817979531179239484356624759043815908577"}, {name: "block", type: "uint256", value: "6605001"}, {name: "futureBlock", type: "uint256", value: "6605003"}, {name: "futureHash", type: "uint256", value: "465549624077002486716300518790245878540469532955271760753903538310361395357"}, {name: "seed", type: "uint256", value: "93228649604955901102880690690155750623758816257676959473026539436568249414403"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "dieRoll", type: "uint256", value: "25"}, {name: "payout", type: "uint256", value: "14558823529411764"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6605019", timeStamp: "1540812542", hash: "0xc4f8ec8a039d482be78837a7dd0310527a59cff1e15d3b8b1b80abd0b1c0c685", nonce: "392", blockHash: "0x33d3d1b21e6a376b92c7f65cb3f0163f18a52c4c0feecc2435fc6562945d8706", transactionIndex: "73", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "134523", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "5059158", gasUsed: "73779", confirmations: "1128020"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540812542 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"68\" )", async function( ) {
		const txOriginal = {blockNumber: "6605597", timeStamp: "1540820277", hash: "0x8f6add6cf87007fd67f5ae71e830d42fad9aaf30408407e28c5975c9db28d20e", nonce: "393", blockHash: "0x4cd15507c682ff29d12e2a6d6ca0c922f18605235f5df70af8d3d21e38d16c2c", transactionIndex: "19", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "10000000000000000", gas: "306402", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000044", contractAddress: "", cumulativeGasUsed: "1189823", gasUsed: "159268", confirmations: "1127442"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "68"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "68", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540820277 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "71410251299113869148522599615288458594127651883802227145153862315738843361620"}, {name: "block", type: "uint256", value: "6605597"}, {name: "futureBlock", type: "uint256", value: "6605599"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "68"}, {name: "profit", type: "uint256", value: "4776119402985074"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6605610", timeStamp: "1540820414", hash: "0xbf8bbe5289900e45d9c2b01f83d7159eecda1cd38da83cbbf839c39446932dbf", nonce: "394", blockHash: "0xf93171cbef7d1bbd233c3638fcc7240eb4c38be0596be3b15be9fd9c2dcf15fd", transactionIndex: "37", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "230686", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "3164229", gasUsed: "138791", confirmations: "1127429"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540820414 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "71410251299113869148522599615288458594127651883802227145153862315738843361620"}, {name: "block", type: "uint256", value: "6605597"}, {name: "futureBlock", type: "uint256", value: "6605599"}, {name: "futureHash", type: "uint256", value: "82324720018661095110337642115668741979903963083034025369199119582173228117991"}, {name: "seed", type: "uint256", value: "98239576693639199045645297685200802695562208907040239751394371074663218313892"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "68"}, {name: "dieRoll", type: "uint256", value: "69"}, {name: "payout", type: "uint256", value: "0"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"68\" )", async function( ) {
		const txOriginal = {blockNumber: "6605628", timeStamp: "1540820685", hash: "0x77f52ff1bb9905c458448cc08a096f35fd13445657c7757ed6f0af35871ff925", nonce: "395", blockHash: "0xcf7ee29c5fa29f69506ddec31910e6dfd6ae985f3581f57a175d3f72f22dba42", transactionIndex: "73", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "20000000000000000", gas: "306402", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000044", contractAddress: "", cumulativeGasUsed: "4622617", gasUsed: "174268", confirmations: "1127411"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "68"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "68", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540820685 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "114762588389726696845403238260473035376352984924049534731269590828736723537861"}, {name: "block", type: "uint256", value: "6605628"}, {name: "futureBlock", type: "uint256", value: "6605630"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "20000000000000000"}, {name: "rollUnder", type: "uint256", value: "68"}, {name: "profit", type: "uint256", value: "9552238805970148"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6605638", timeStamp: "1540820829", hash: "0x247c7bd43b26a46b6c97b2901e89d95f402219f4a0c90c51b8e8daf9318315db", nonce: "396", blockHash: "0xd2d01a4b77cff218b7a28d2f016147e550445722ce19ae179bee5628fc20b92e", transactionIndex: "90", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "230686", gasPrice: "7100000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "7830669", gasUsed: "138791", confirmations: "1127401"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540820829 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "114762588389726696845403238260473035376352984924049534731269590828736723537861"}, {name: "block", type: "uint256", value: "6605628"}, {name: "futureBlock", type: "uint256", value: "6605630"}, {name: "futureHash", type: "uint256", value: "36005385463166085194278538241806404529696747217600474697669774369987644391388"}, {name: "seed", type: "uint256", value: "56228754813137488774019951286804977238126111458799838437981054359795496735629"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "20000000000000000"}, {name: "rollUnder", type: "uint256", value: "68"}, {name: "dieRoll", type: "uint256", value: "86"}, {name: "payout", type: "uint256", value: "0"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"69\" )", async function( ) {
		const txOriginal = {blockNumber: "6605643", timeStamp: "1540820913", hash: "0x81bb061ecd030434ffe7cb500cb5f70b8135c982de4ed639213b44921f90149d", nonce: "397", blockHash: "0x81b79155fc210212f31ce0b5b307a906c12c2c548df76ce4c290bacd82dc0f93", transactionIndex: "138", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "30000000000000000", gas: "306402", gasPrice: "8400000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000045", contractAddress: "", cumulativeGasUsed: "7574237", gasUsed: "174268", confirmations: "1127396"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "69"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "69", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540820913 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "26524759922257436177881658372410412772684380762619268483086161247101721829367"}, {name: "block", type: "uint256", value: "6605643"}, {name: "futureBlock", type: "uint256", value: "6605645"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "30000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "profit", type: "uint256", value: "13676470588235293"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6605653", timeStamp: "1540821078", hash: "0xd14324f9c93ea3fdc9ab17333e205b0611aee7927193aa8f9b9bb1f048c2a217", nonce: "398", blockHash: "0x79be44c3b6bf994d25c6e2f55b4d1475177703005625a9539ce0c32894fb59c2", transactionIndex: "36", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "310429", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "5707652", gasUsed: "191953", confirmations: "1127386"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540821078 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "26524759922257436177881658372410412772684380762619268483086161247101721829367"}, {name: "block", type: "uint256", value: "6605643"}, {name: "futureBlock", type: "uint256", value: "6605645"}, {name: "futureHash", type: "uint256", value: "36295776564297923609945540141339389592454499242841987045544825921541850154854"}, {name: "seed", type: "uint256", value: "56628563904175046162465988544995284576682362950852521993202102979511831339588"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "30000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "dieRoll", type: "uint256", value: "15"}, {name: "payout", type: "uint256", value: "43676470588235293"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6605658", timeStamp: "1540821143", hash: "0xad35e1ecd498c3899c6413e6b8d0fa94decf66dc4083110dac68c45a3fff2a04", nonce: "399", blockHash: "0x952212d2d5ac83782c6aa4f7582a10c96db54d5fe677c4253645d467f0428db3", transactionIndex: "65", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "88809", gasPrice: "8204098560", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2212018", gasUsed: "43779", confirmations: "1127381"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540821143 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"69\" )", async function( ) {
		const txOriginal = {blockNumber: "6605673", timeStamp: "1540821362", hash: "0x2237c3ba969deea77da4492a9c5830abf75380948f843bea540b5a92e2f5b9a8", nonce: "400", blockHash: "0x2bd963ce771686fd90182e7ea06bb78d267283e2206f63faf56669fd413b0a97", transactionIndex: "73", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "10000000000000000", gas: "306402", gasPrice: "8900000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000045", contractAddress: "", cumulativeGasUsed: "1840040", gasUsed: "159268", confirmations: "1127366"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "69"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "69", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540821362 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "11349751940515374510412301526731622724979281266674797175951994582638347462381"}, {name: "block", type: "uint256", value: "6605673"}, {name: "futureBlock", type: "uint256", value: "6605675"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "profit", type: "uint256", value: "4558823529411764"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6605681", timeStamp: "1540821441", hash: "0xaf6f5b7940edde5cdbf8bd484ced3fda9501a29493eb755809ebc8088b3ae207", nonce: "401", blockHash: "0xee0cc8829812ccd633770c258bdd816420815ff9d87a1938848ac52aba360fd6", transactionIndex: "49", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "310429", gasPrice: "8750000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "3349729", gasUsed: "191953", confirmations: "1127358"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540821441 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "11349751940515374510412301526731622724979281266674797175951994582638347462381"}, {name: "block", type: "uint256", value: "6605673"}, {name: "futureBlock", type: "uint256", value: "6605675"}, {name: "futureHash", type: "uint256", value: "65380216749664976579694761816076950068177951544552982479363851923622849393146"}, {name: "seed", type: "uint256", value: "104827452074895647631278879092033286422265882996096719046561191768729322402253"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "dieRoll", type: "uint256", value: "51"}, {name: "payout", type: "uint256", value: "14558823529411764"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: playWithVault( \"69\", \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6605695", timeStamp: "1540821715", hash: "0x4b728d2ac2179150d8224e17a04e132c5733a4e5eec837481987e97d3ed262d0", nonce: "402", blockHash: "0xef142e96c22815fb135ffd2cfc7eec772eb15e8d9d0bd77195319afd8352d534", transactionIndex: "143", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "364069", gasPrice: "7562500000", isError: "0", txreceipt_status: "1", input: "0x9cd8e54c0000000000000000000000000000000000000000000000000000000000000045000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "7702772", gasUsed: "197713", confirmations: "1127344"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "69"}, {type: "uint256", name: "wager", value: "10000000000000000"}], name: "playWithVault", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "playWithVault(uint256,uint256)" ]( "69", "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540821715 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "83234836752564235442142130534811383131875419785259789743269716713653223477380"}, {name: "block", type: "uint256", value: "6605695"}, {name: "futureBlock", type: "uint256", value: "6605697"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "profit", type: "uint256", value: "4558823529411764"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6605709", timeStamp: "1540821920", hash: "0xb596454c71fda3bad3e9b01c94c95cda5217b55eedccb7666db506878c8fccbf", nonce: "403", blockHash: "0x8738ebea152dfa8308ba6408cfe3c3285bdb54c5a67c117155786cc89094d860", transactionIndex: "40", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "287929", gasPrice: "7100000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "1882737", gasUsed: "176953", confirmations: "1127330"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540821920 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "83234836752564235442142130534811383131875419785259789743269716713653223477380"}, {name: "block", type: "uint256", value: "6605695"}, {name: "futureBlock", type: "uint256", value: "6605697"}, {name: "futureHash", type: "uint256", value: "53102741881887020620229986808760619599748066720034416003049251717167409898783"}, {name: "seed", type: "uint256", value: "66061197944315059343727776536726472187754578161833330428796016053519929336008"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "dieRoll", type: "uint256", value: "26"}, {name: "payout", type: "uint256", value: "14558823529411764"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6605715", timeStamp: "1540821984", hash: "0xd507c805ecd38caa772586722ed69b999ffc527537aaf25bd6bce251bddfeb1c", nonce: "404", blockHash: "0xcccd3420edf813792b0770fb5ff5179d8cb8f3ef57d079c3d40c84d37ee1073a", transactionIndex: "56", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "88809", gasPrice: "9900000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2907046", gasUsed: "43779", confirmations: "1127324"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540821984 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"65\" )", async function( ) {
		const txOriginal = {blockNumber: "6605797", timeStamp: "1540823281", hash: "0x40655a5e9e4c21f2a48444bd0cafbd3cb8f26bfa317a391321036cfeeea7f1fa", nonce: "1606", blockHash: "0x04a551ac118149b7d277830570ff87b717a61c40ab0e23596f52ab43c6b5534a", transactionIndex: "130", from: "0x966226303da9644e535e560fdfad5b4cd1f333b9", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "10000000000000000", gas: "553876", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000041", contractAddress: "", cumulativeGasUsed: "7363640", gasUsed: "354251", confirmations: "1127242"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "65"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "65", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540823281 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "2631339089506897058264232687189607939920326550685471386588758391794873660354"}, {name: "block", type: "uint256", value: "6605797"}, {name: "futureBlock", type: "uint256", value: "6605799"}, {name: "player", type: "address", value: "0x966226303da9644e535e560fdfad5b4cd1f333b9"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "65"}, {name: "profit", type: "uint256", value: "5468750000000000"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "6981367508849031" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6605851", timeStamp: "1540823885", hash: "0xb1cb38a57a702ba1df87f354d86ca03962f2f0bdc0603c709192f40b882dc7be", nonce: "1610", blockHash: "0xfd1b67778a0d47bf99b6213419392a9f53fbe22ff831e1f166db66942634cc5a", transactionIndex: "208", from: "0x966226303da9644e535e560fdfad5b4cd1f333b9", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "467929", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "6191882", gasUsed: "296953", confirmations: "1127188"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540823885 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "2631339089506897058264232687189607939920326550685471386588758391794873660354"}, {name: "block", type: "uint256", value: "6605797"}, {name: "futureBlock", type: "uint256", value: "6605799"}, {name: "futureHash", type: "uint256", value: "76931032656622567601751713039519991428151093818019815496950323687616732807189"}, {name: "seed", type: "uint256", value: "75500738930301029818953997448469561294730650075653205051276266885297760280121"}, {name: "player", type: "address", value: "0x966226303da9644e535e560fdfad5b4cd1f333b9"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "65"}, {name: "dieRoll", type: "uint256", value: "23"}, {name: "payout", type: "uint256", value: "15468750000000000"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "6981367508849031" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"50\" )", async function( ) {
		const txOriginal = {blockNumber: "6605856", timeStamp: "1540824030", hash: "0x73f749ddd57968ef4da64df8b42c445330e5c582b6ece1428bab889f8add32a0", nonce: "1611", blockHash: "0x57618d1c911e9f77c388ee5a4cbc81fb1ccb6d6d940fb686af20a31cb03cc111", transactionIndex: "159", from: "0x966226303da9644e535e560fdfad5b4cd1f333b9", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "20000000000000000", gas: "306402", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000032", contractAddress: "", cumulativeGasUsed: "6321508", gasUsed: "159268", confirmations: "1127183"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "50"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "50", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540824030 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "53193076912096076962908266420661894214256825696316112117160557050065924534699"}, {name: "block", type: "uint256", value: "6605856"}, {name: "futureBlock", type: "uint256", value: "6605858"}, {name: "player", type: "address", value: "0x966226303da9644e535e560fdfad5b4cd1f333b9"}, {name: "wager", type: "uint256", value: "20000000000000000"}, {name: "rollUnder", type: "uint256", value: "50"}, {name: "profit", type: "uint256", value: "20408163265306121"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "6981367508849031" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6605864", timeStamp: "1540824142", hash: "0x8ec243d126d39d7f50360d9709071c6996a5fa00587140683bbb73ff353a1285", nonce: "1612", blockHash: "0xe8c88f6d83fc9592bfe5d1da656dc79db648d3dd3ddb2dd3f94aa72df2448f72", transactionIndex: "56", from: "0x966226303da9644e535e560fdfad5b4cd1f333b9", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "253186", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "3468656", gasUsed: "153791", confirmations: "1127175"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540824142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "53193076912096076962908266420661894214256825696316112117160557050065924534699"}, {name: "block", type: "uint256", value: "6605856"}, {name: "futureBlock", type: "uint256", value: "6605858"}, {name: "futureHash", type: "uint256", value: "34697255295193986758772899738984656289393628058088567506766707792633562542124"}, {name: "seed", type: "uint256", value: "41614265584238546396798332301697012935283484250076078200310891626327765883304"}, {name: "player", type: "address", value: "0x966226303da9644e535e560fdfad5b4cd1f333b9"}, {name: "wager", type: "uint256", value: "20000000000000000"}, {name: "rollUnder", type: "uint256", value: "50"}, {name: "dieRoll", type: "uint256", value: "58"}, {name: "payout", type: "uint256", value: "0"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "6981367508849031" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"46\" )", async function( ) {
		const txOriginal = {blockNumber: "6605879", timeStamp: "1540824375", hash: "0x29f3427e62c5cb3402af1b91fcbd0ddf7535179cbb0605ae0f17d64f943829a3", nonce: "1613", blockHash: "0xa1740b689f6423c7626d9e5b754761b7d193d033c15968911d6d26c5cc813037", transactionIndex: "156", from: "0x966226303da9644e535e560fdfad5b4cd1f333b9", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "20000000000000000", gas: "306402", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b000000000000000000000000000000000000000000000000000000000000002e", contractAddress: "", cumulativeGasUsed: "7161221", gasUsed: "174268", confirmations: "1127160"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "46"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "46", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540824375 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "42760263847082252281141109158702429944140091271856822654817226312555374802490"}, {name: "block", type: "uint256", value: "6605879"}, {name: "futureBlock", type: "uint256", value: "6605881"}, {name: "player", type: "address", value: "0x966226303da9644e535e560fdfad5b4cd1f333b9"}, {name: "wager", type: "uint256", value: "20000000000000000"}, {name: "rollUnder", type: "uint256", value: "46"}, {name: "profit", type: "uint256", value: "23999999999999999"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "6981367508849031" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6605902", timeStamp: "1540824656", hash: "0x368b83bcf58463acee8f0e290414d1432c1f8224540436f72d76165d6b361e60", nonce: "1614", blockHash: "0x6455e9295476afbafec163b3e5e51add042633831cb6af6d2a6dd6a4f2f1acab", transactionIndex: "42", from: "0x966226303da9644e535e560fdfad5b4cd1f333b9", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "230686", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "6640938", gasUsed: "138791", confirmations: "1127137"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540824656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "42760263847082252281141109158702429944140091271856822654817226312555374802490"}, {name: "block", type: "uint256", value: "6605879"}, {name: "futureBlock", type: "uint256", value: "6605881"}, {name: "futureHash", type: "uint256", value: "56754383561644170486173283597126747198206335794881300668991317852937967909325"}, {name: "seed", type: "uint256", value: "58556630425303322406302450782487045017091230838182734520397292404724146123977"}, {name: "player", type: "address", value: "0x966226303da9644e535e560fdfad5b4cd1f333b9"}, {name: "wager", type: "uint256", value: "20000000000000000"}, {name: "rollUnder", type: "uint256", value: "46"}, {name: "dieRoll", type: "uint256", value: "46"}, {name: "payout", type: "uint256", value: "0"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "6981367508849031" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6605975", timeStamp: "1540825634", hash: "0x80ac20129500132a05d564abcd8b9006faafc1fa74afb457db416cf468137911", nonce: "1617", blockHash: "0xecc95894c5d6c89ab52d065ff49c9928186998e3adf0a9261c59d2ffae01434d", transactionIndex: "51", from: "0x966226303da9644e535e560fdfad5b4cd1f333b9", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "134523", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "2100226", gasUsed: "73779", confirmations: "1127064"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540825634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "6981367508849031" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"51\" )", async function( ) {
		const txOriginal = {blockNumber: "6605997", timeStamp: "1540825966", hash: "0x4cf6967be310b20b3866bce79bab5bd12681dd7a032d51d8218824a45741d3f0", nonce: "11", blockHash: "0x7e6c2fd76d391f36aa92fa9d00ab46c2e0bba5bdffc48c6ac9ffa10984fe0af2", transactionIndex: "37", from: "0x47a49acb7f3df01e02fc8b2977a353269759b731", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "10000000000000000", gas: "265548", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "1942051", gasUsed: "174268", confirmations: "1127042"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "51"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540825966 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "28634748119633894241321101592571398314717296560386710399013790154562507767173"}, {name: "block", type: "uint256", value: "6605997"}, {name: "futureBlock", type: "uint256", value: "6605999"}, {name: "player", type: "address", value: "0x47a49acb7f3df01e02fc8b2977a353269759b731"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "51"}, {name: "profit", type: "uint256", value: "9800000000000000"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"69\" )", async function( ) {
		const txOriginal = {blockNumber: "6606018", timeStamp: "1540826273", hash: "0xd380ef231e6ce4516a8df782762f22d1a5789fd9f36c2bc68fe14316c2a33370", nonce: "405", blockHash: "0x77b38a1d320a2fb1c874c7ec4038c42493696df07694b532b6850a6e1fbc62e2", transactionIndex: "130", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "10000000000000000", gas: "499848", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000045", contractAddress: "", cumulativeGasUsed: "6259106", gasUsed: "273232", confirmations: "1127021"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "69"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "69", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540826273 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "3601584599082749704010613976244889523926179457784685368667347685848462586520"}, {name: "block", type: "uint256", value: "6606018"}, {name: "futureBlock", type: "uint256", value: "6606020"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "profit", type: "uint256", value: "4558823529411764"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "28634748119633894241321101592571398314717296560386710399013790154562507767173"}, {name: "block", type: "uint256", value: "6605997"}, {name: "futureBlock", type: "uint256", value: "6605999"}, {name: "futureHash", type: "uint256", value: "86789286429690658480023801561648773170298755365578788924250437920283223816837"}, {name: "seed", type: "uint256", value: "54926671068054549683591799589323885903732745535976760993372508163527603061738"}, {name: "player", type: "address", value: "0x47a49acb7f3df01e02fc8b2977a353269759b731"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "51"}, {name: "dieRoll", type: "uint256", value: "93"}, {name: "payout", type: "uint256", value: "0"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"56\" )", async function( ) {
		const txOriginal = {blockNumber: "6606023", timeStamp: "1540826354", hash: "0x4fe02dcb4d3febb522e436d9d85207d54dfff716a8c76e62931ceb34914ec360", nonce: "379", blockHash: "0x1388092e4e627bc73fe2815ff02c19553bde7f5054a9a5452302abdf4aa6bade", transactionIndex: "65", from: "0xe1a2cabfc6412bec651fcd7dbbad0266b6d78d1b", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "10000000000000000", gas: "518868", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000038", contractAddress: "", cumulativeGasUsed: "5631244", gasUsed: "518868", confirmations: "1127016"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "56"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "668971688811332801" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6606028", timeStamp: "1540826398", hash: "0xa7ab7f255f562c6cfce45d17df28825f8d64a0b8d78f41f6aee878c1903a9ae4", nonce: "406", blockHash: "0x599dd3e1c44e6700ec4db9db4f67c1929c03c9034ab70d8bef8dff4a321ef968", transactionIndex: "32", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "310429", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "1652282", gasUsed: "191953", confirmations: "1127011"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1540826398 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "3601584599082749704010613976244889523926179457784685368667347685848462586520"}, {name: "block", type: "uint256", value: "6606018"}, {name: "futureBlock", type: "uint256", value: "6606020"}, {name: "futureHash", type: "uint256", value: "82081188121519777884408131982610164333652885330735891743164178889493759398876"}, {name: "seed", type: "uint256", value: "80484014480786842568505438528462769047340426081135203942788893984713425888594"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "10000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "dieRoll", type: "uint256", value: "59"}, {name: "payout", type: "uint256", value: "14558823529411764"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6606033", timeStamp: "1540826504", hash: "0xdfe3cc2982ffea59797a3d6522d72c10f102e7219e08540a7809a4304bd6cb4a", nonce: "407", blockHash: "0xb9b25306800c75a10408afa0116dcca095630a3d6b08d59c1399ca480976e93c", transactionIndex: "60", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "88809", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "6828243", gasUsed: "43779", confirmations: "1127006"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540826504 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"69\" )", async function( ) {
		const txOriginal = {blockNumber: "6606147", timeStamp: "1540827988", hash: "0xbb21a9e3bd63c26488334297a05ce7e27cd5fbd2afc44bbf31bd50f23075e95d", nonce: "408", blockHash: "0x32e6917e996be3245aab48b6ed05ce5ebe25777ba3fae81eef032f91e0e1ff00", transactionIndex: "63", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "20000000000000000", gas: "306402", gasPrice: "4281250000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000045", contractAddress: "", cumulativeGasUsed: "5860656", gasUsed: "159268", confirmations: "1126892"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "69"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "69", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540827988 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "14884738485893504677915446702938554638116601572517765033220159336846602205304"}, {name: "block", type: "uint256", value: "6606147"}, {name: "futureBlock", type: "uint256", value: "6606149"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "20000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "profit", type: "uint256", value: "9117647058823528"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6606189", timeStamp: "1540828522", hash: "0x9d6b00be74366647b6aacc6c4abd35d39da451570793b2a628bf1c3252977900", nonce: "409", blockHash: "0x83bc52471ead6eaf0eb9f37422e0633efb11525a945de49d96e0fd38bba97ed0", transactionIndex: "37", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "230686", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "2696882", gasUsed: "138791", confirmations: "1126850"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540828522 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "14884738485893504677915446702938554638116601572517765033220159336846602205304"}, {name: "block", type: "uint256", value: "6606147"}, {name: "futureBlock", type: "uint256", value: "6606149"}, {name: "futureHash", type: "uint256", value: "30281244438801930847407160082571819993152615609500161446948903252263427854380"}, {name: "seed", type: "uint256", value: "91142054103714036651536349769412634557534050940186853132281826845073317406557"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "20000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "dieRoll", type: "uint256", value: "77"}, {name: "payout", type: "uint256", value: "0"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"69\" )", async function( ) {
		const txOriginal = {blockNumber: "6606206", timeStamp: "1540828664", hash: "0x1a43b61b5d5f6744a97d47054a089850ddb02c572deae13cd86c4f8ee82d5826", nonce: "410", blockHash: "0xcc8e39615564ea502025d4f792faf00f28d1c2e9b19df215e41b5ae510480004", transactionIndex: "101", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "30000000000000000", gas: "306402", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000045", contractAddress: "", cumulativeGasUsed: "4197588", gasUsed: "174268", confirmations: "1126833"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "69"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "69", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540828664 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "3775531800571748560633451336164238136658420811768359528239613816284207594055"}, {name: "block", type: "uint256", value: "6606206"}, {name: "futureBlock", type: "uint256", value: "6606208"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "30000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "profit", type: "uint256", value: "13676470588235293"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: closeSession(  )", async function( ) {
		const txOriginal = {blockNumber: "6606215", timeStamp: "1540828833", hash: "0x9e2276bfe7cb1d46fd676135be7d52aa03eaf8c6ab1f45e38c766814936d31db", nonce: "411", blockHash: "0x0c559efae442c71669aeb2b1133febe13520ef388b372ed8c390f5655c772185", transactionIndex: "92", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "310429", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x06f4bcbf", contractAddress: "", cumulativeGasUsed: "4864352", gasUsed: "191953", confirmations: "1126824"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "closeSession", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "closeSession()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540828833 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "futureHash", type: "uint256"}, {indexed: false, name: "seed", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "dieRoll", type: "uint256"}, {indexed: false, name: "payout", type: "uint256"}, {indexed: false, name: "timeout", type: "bool"}], name: "onSessionClose", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onSessionClose", events: [{name: "id", type: "uint256", value: "3775531800571748560633451336164238136658420811768359528239613816284207594055"}, {name: "block", type: "uint256", value: "6606206"}, {name: "futureBlock", type: "uint256", value: "6606208"}, {name: "futureHash", type: "uint256", value: "114907610504319154814874928151681778743815209116308274417807967827726845178655"}, {name: "seed", type: "uint256", value: "101830478238528059545040163690273268877895149309192525746093024904675731155906"}, {name: "player", type: "address", value: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8"}, {name: "wager", type: "uint256", value: "30000000000000000"}, {name: "rollUnder", type: "uint256", value: "69"}, {name: "dieRoll", type: "uint256", value: "9"}, {name: "payout", type: "uint256", value: "43676470588235293"}, {name: "timeout", type: "bool", value: false}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6606221", timeStamp: "1540828902", hash: "0x25fe5450736e70463710c75b29f8ad29c2fb593e1d2ba2169a3dee0779d9be9a", nonce: "412", blockHash: "0x8bf3a7db44ea69f65889fd14889e52db878d9d3abf1cb6ff11448c231f4d455e", transactionIndex: "65", from: "0x153caf10387b13fda75a03f974fa5c2d2763d5a8", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "0", gas: "88809", gasPrice: "5731816000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "4061925", gasUsed: "43779", confirmations: "1126818"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540828902 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "30446802913275300" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"65\" )", async function( ) {
		const txOriginal = {blockNumber: "6606503", timeStamp: "1540833025", hash: "0xba5f969a94ec1b5b53876ee753b3c0e83f0a547e7b7bf6482346f2232cdf34f5", nonce: "531", blockHash: "0xe3477a6bdba398908d8f9c18760908c1aeffedb1d0a7d420c4b4b7429aa84355", transactionIndex: "5", from: "0xb653684d5e213cfef2a0dc2820a589e283cc13a1", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "100000000000000000", gas: "7600027", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000041", contractAddress: "", cumulativeGasUsed: "308503", gasUsed: "75149", confirmations: "1126536"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "65"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "65", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540833025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "19693259665327443" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: play( \"89\" )", async function( ) {
		const txOriginal = {blockNumber: "6606503", timeStamp: "1540833025", hash: "0xf7fca96320561ae09844ff4c181529ad022661f67765d5f81818bc19491618b3", nonce: "532", blockHash: "0xe3477a6bdba398908d8f9c18760908c1aeffedb1d0a7d420c4b4b7429aa84355", transactionIndex: "7", from: "0xb653684d5e213cfef2a0dc2820a589e283cc13a1", to: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15", value: "100000000000000000", gas: "553876", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x6898f82b0000000000000000000000000000000000000000000000000000000000000059", contractAddress: "", cumulativeGasUsed: "683754", gasUsed: "354251", confirmations: "1126536"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "rollUnder", value: "89"}], name: "play", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "play(uint256)" ]( "89", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540833025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "id", type: "uint256"}, {indexed: false, name: "block", type: "uint256"}, {indexed: false, name: "futureBlock", type: "uint256"}, {indexed: false, name: "player", type: "address"}, {indexed: false, name: "wager", type: "uint256"}, {indexed: false, name: "rollUnder", type: "uint256"}, {indexed: false, name: "profit", type: "uint256"}], name: "onSessionOpen", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onSessionOpen", events: [{name: "id", type: "uint256", value: "21268701465568187711526386695645282663396414715484958089309658285744831406959"}, {name: "block", type: "uint256", value: "6606503"}, {name: "futureBlock", type: "uint256", value: "6606505"}, {name: "player", type: "address", value: "0xb653684d5e213cfef2a0dc2820a589e283cc13a1"}, {name: "wager", type: "uint256", value: "100000000000000000"}, {name: "rollUnder", type: "uint256", value: "89"}, {name: "profit", type: "uint256", value: "12499999999999999"}], address: "0xcb932640a448b264fdbcfe81d6c34a2887f89f15"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "19693259665327443" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
