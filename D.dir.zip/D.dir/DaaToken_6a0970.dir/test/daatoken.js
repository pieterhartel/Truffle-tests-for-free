const DaaToken = artifacts.require( "./DaaToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "DaaToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xE5a7c12972f3bbFe70ed29521C8949b8Af6a0970", "0x00D04AFD887256911c04ba4aD8A0B222db98118C", "0x3254F3Fa04300A9A755A941664fDB1fc7acc82Cd", "0x06E3CCAF50DAE224cC8b7B120Ec855e97c0Bb424", "0x29d38FdF26d64Fa799276e6615759D27dB1F1fcD", "0xdF7e1f46f3a53552c168f28ad95eF5EaB6283178", "0x06bB9E92E85622919F831d35fCaAD17E462CC218", "0x82212FE53AA9Ad02C853B5033b1A1F3668633fEB", "0x8d12A197cB00D4747a1fe03395095ce2A5CC6819", "0x79eb77C4A57E7d5d3Ce0d9dff1AD79fD7aC37933", "0xf724faaa99df6811D448053ADa1e4a004f3bc9ED", "0x40f661C87b8d43D77eD2C1277Df54e9299063313", "0xC20655792d1bd4A4a7173dcf0450beDDDB97dDe1", "0xA532168D0A0D537Bd5F3Aa925b829754f906267F", "0x778c2615ed7FbeD9A06E595ee73436DaF2022bAA", "0x00A20A450a79A1f8b7E19858dd55712b47542fF6", "0xaAe1Cb04c830FA907210355C0DcEA3118B445BB0", "0x50B445Ce9F2176046548deE6e2cB3bC73852bA79", "0x095285c240ed8a71C37cE1469C44099f859E6D7A", "0x92506dbC4655af7D3A036Cb7e5e0372aADC98D62", "0xb68C63dA5eEB35aE1BE5AF03385a0f11abB618bD", "0x810858F00f41F99873E97a5018d83cAB22843c9F", "0x76071d20D6B6b57Edf8fD02be6877e43EA0F02C6", "0x608Cb60905EfC0b59ebaD8A9C650A410fead95A0", "0x554CEa37Ac322f4c6a34c2ABF7A33dC734B0c0A0", "0x86E9C2c1D28DAc0B8919FfA094710de7C069C843", "0x2498874F1c02b1D5C11a17b15a6cb11C3918585C", "0x0e7aC5d8F55F0bf2c3f8daC5836022750c2a46ce", "0x305732b09edbF31429560f7E38C090453a16ADC5", "0xB3e1819Fe07BF073819859073cf400Ca2d0a753a", "0x60Bd735F26FBE35667448834A8680240295f50B3", "0x1423C1EddD4cE254DAd54f563FfbFDFec5eb0731", "0xdf89aF4E461Edbbf8AFB5f559181fE429630C2ba", "0x8E5D6E1292F3C07ad35FD2E8848F007C7cB1D1Ff", "0x73b971AD24845E1d8BA5A18CE5962aEF68165b68", "0x887A74A0C897a042Cb2ddC084b6421f1BeD96B46", "0xefFc47dB119b138D220C47A7496E32262B29b033", "0xB2979ac909b7178A2D306DD77B1c2aF0F623B980", "0x192F6A84b3d1f8309CF0d184838018e83cB81979", "0xB7c260E9331B788F186C59e1edFa982F81678a68", "0x23D46E916a4ca406153A1D4f2bA3b1dCFF31522A", "0xaB79E567ba66A1A3699F5FaaDBaeD44AC08796b5", "0xb43D8A6e82Fa38a49F8A5fA9c0602349071aB49D", "0x4B7C2Ca6b9CCE7580871E2A154af697aC58eE8B9", "0x1Fa5dF5bfBC13640DAa6d37e1112f3DdEd1B8E9D", "0x42503e603489d8ac1B5A634d6efB607963BA248e", "0x87F00bF7096CEf81347b1e60d5Da23Fb33958343", "0xCf6c7e98053AD4D8A635Dd481941ABFEA7a90403", "0x63A1D3dBec37CA4B1Db520056E8F82534376b24B", "0x4B85e9D2e433D7EcA29f8A7A859Cf0346702c89a", "0x218c31fd147173C981aa857f9cFB4cb8780a34f5", "0x626A7B370391310B1Cb9f6E17273A43e95851048", "0x2bc2CA2A7B3E6EdEF35223a211aC3B0b9b8d4346", "0xEf2507aa7014C45152DBAcb5092A571d4A94D925", "0x19190710378C7828bF101270c171894c3092326F"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "minter", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "version", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isLocked", outputs: [{name: "success", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "lockedUntilBlock", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_newTotalSupply", type: "uint256"}], name: "Mint", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_newTotalSupply", type: "uint256"}], name: "Burn", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}], name: "BlockLockSet", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_newOwner", type: "address"}], name: "NewOwner", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_minter", type: "address"}], name: "NewMinter", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Transfer(address,address,uint256)", "Approval(address,address,uint256)", "Mint(address,uint256,uint256)", "Burn(address,uint256,uint256)", "BlockLockSet(uint256)", "NewOwner(address)", "NewMinter(address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0x4c209b5fc8ad50758f13e2e1088ba56a560dff690a1c6fef26394f4c03821c4f", "0x49995e5dd6158cf69ad3e9777c46755a1a826a446c6416992167462dad033b2a", "0x6c04066f6ede40cc1642c211ba9d18f1a096ccc84fb8d11be28ea6c3c6f68b36", "0x3edd90e7770f06fafde38004653b33870066c33bfc923ff6102acd601f85dfbc", "0x6adffd5c93085d835dac6f3b40adf7c242ca4b3284048d20c3d8a501748dc973"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4174296 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4228006 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "string", name: "_tokenName", value: "Blockchain Index"}, {type: "uint8", name: "_decimalUnits", value: "18"}, {type: "string", name: "_tokenSymbol", value: "BLX"}, {type: "uint256", name: "_lockedUntilBlock", value: "0"}], name: "DaaToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minter", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minter()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "version", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "version()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isLocked", outputs: [{name: "success", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isLocked()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "lockedUntilBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lockedUntilBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "DaaToken", function( accounts ) {

	it( "TEST: DaaToken( `Blockchain Index`, \"18\", `BLX`, \"0\" )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4174296", timeStamp: "1503079928", hash: "0x2ca8bde4deb6ca7b56b230829b288b1a0e2bbc96e638d0a68ca6d1d0dcc262ae", nonce: "0", blockHash: "0xb67ca1aeab13594101ffbc41c513a96d26b818aaca0d5ae93764193dde5a03f0", transactionIndex: "51", from: "0x00d04afd887256911c04ba4ad8a0b222db98118c", to: 0, value: "0", gas: "1525567", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x7896904e0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010426c6f636b636861696e20496e646578000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003424c580000000000000000000000000000000000000000000000000000000000", contractAddress: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", cumulativeGasUsed: "3177979", gasUsed: "1271306", confirmations: "3527094"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_tokenName", value: `Blockchain Index`}, {type: "uint8", name: "_decimalUnits", value: "18"}, {type: "string", name: "_tokenSymbol", value: `BLX`}, {type: "uint256", name: "_lockedUntilBlock", value: "0"}], name: "DaaToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = DaaToken.new( `Blockchain Index`, "18", `BLX`, "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1503079928 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = DaaToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "107130066000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setMinter( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4174333", timeStamp: "1503080506", hash: "0x4517c8e58a5f139550f1543f99fbbba22599b4dfd0f350e1387ce8630909d8e9", nonce: "2", blockHash: "0x418ff29a9a8c9d53ce9accdeb2fd0a10b7e7ba3eb2f647465bdcf8f4ebaa3319", transactionIndex: "39", from: "0x00d04afd887256911c04ba4ad8a0b222db98118c", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "210000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xfca3b5aa0000000000000000000000003254f3fa04300a9a755a941664fdb1fc7acc82cd", contractAddress: "", cumulativeGasUsed: "5372794", gasUsed: "45110", confirmations: "3527057"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newMinter", value: addressList[4]}], name: "setMinter", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setMinter(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1503080506 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_minter", type: "address"}], name: "NewMinter", type: "event"} ;
		console.error( "eventCallOriginal[1,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewMinter", events: [{name: "_minter", type: "address", value: "0x3254f3fa04300a9a755a941664fdb1fc7acc82cd"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[1,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "107130066000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setMinter( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4174393", timeStamp: "1503081559", hash: "0xf2e5f24eb863ffa03cf17838734812c50c68ef5c0b8cffb4b68b29f9732c72f0", nonce: "5", blockHash: "0x711aa43dfc51eee74361b11b750b0919dff82c829eb6746400b95a57cd7ad722", transactionIndex: "29", from: "0x00d04afd887256911c04ba4ad8a0b222db98118c", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "36132", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0xfca3b5aa00000000000000000000000006e3ccaf50dae224cc8b7b120ec855e97c0bb424", contractAddress: "", cumulativeGasUsed: "1054381", gasUsed: "30110", confirmations: "3526997"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newMinter", value: addressList[5]}], name: "setMinter", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setMinter(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1503081559 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_minter", type: "address"}], name: "NewMinter", type: "event"} ;
		console.error( "eventCallOriginal[2,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewMinter", events: [{name: "_minter", type: "address", value: "0x06e3ccaf50dae224cc8b7b120ec855e97c0bb424"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[2,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "107130066000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: replaceOwner( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "4174399", timeStamp: "1503081809", hash: "0xc8f9e300a1e08c771c04ee0811f1ccfabc2d87083867fb3570a44d29735f3b79", nonce: "6", blockHash: "0x9e8d9f1edfaf1266fdba3ae984d87e052ab0094a0bf47328d144876e703f9be7", transactionIndex: "144", from: "0x00d04afd887256911c04ba4ad8a0b222db98118c", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "35974", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0xa39a45b700000000000000000000000029d38fdf26d64fa799276e6615759d27db1f1fcd", contractAddress: "", cumulativeGasUsed: "4851010", gasUsed: "29978", confirmations: "3526991"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newOwner", value: addressList[6]}], name: "replaceOwner", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "replaceOwner(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1503081809 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_newOwner", type: "address"}], name: "NewOwner", type: "event"} ;
		console.error( "eventCallOriginal[3,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewOwner", events: [{name: "_newOwner", type: "address", value: "0x29d38fdf26d64fa799276e6615759d27db1f1fcd"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[3,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "107130066000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"49000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4174782", timeStamp: "1503090115", hash: "0xe9aee80365dce632b03a8fbc718addbdfc1f21adc3fa5c37e21aaaa49a0700db", nonce: "134", blockHash: "0x31fae22b1dbf3e85362d867b170742fb4409c4b33d91d69fe5399561d4646dca", transactionIndex: "126", from: "0xdf7e1f46f3a53552c168f28ad95ef5eab6283178", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "210000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000006bb9e92e85622919f831d35fcaad17e462cc218000000000000000000000000000000000000000000000002a802f8630a240000", contractAddress: "", cumulativeGasUsed: "5186581", gasUsed: "37396", confirmations: "3526608"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "49000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "49000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1503090115 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdf7e1f46f3a53552c168f28ad95ef5eab6283178"}, {name: "_to", type: "address", value: "0x06bb9e92e85622919f831d35fcaad17e462cc218"}, {name: "_value", type: "uint256", value: "49000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "10531870854736231220" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"42000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4176182", timeStamp: "1503118777", hash: "0x2e52ab008adc8ec267ea303cf257fb790373facd53c4f581f1f2dfc4f38b3398", nonce: "25", blockHash: "0xaa895162a83332171c754e6fe8a3d6036c8cece67a22fa5688bef8a3960d103f", transactionIndex: "102", from: "0x82212fe53aa9ad02c853b5033b1a1f3668633feb", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "1000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000000000000000000000000000000000000246ddf97976680000", contractAddress: "", cumulativeGasUsed: "6458327", gasUsed: "45567", confirmations: "3525208"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "42000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "42000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1503118777 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x82212fe53aa9ad02c853b5033b1a1f3668633feb"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "42000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "540170691616202939" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4176437", timeStamp: "1503123831", hash: "0x511f212ae95ad33a8fb4f20602345c98b9843da775212936b202a653b7c302e8", nonce: "0", blockHash: "0x34f0b9755ad2bb98f54cdd2e63489bbd9b855578c550aad2b1939556a3a0f4ea", transactionIndex: "59", from: "0x79eb77c4a57e7d5d3ce0d9dff1ad79fd7ac37933", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000000000000000000000000000000000001b1ae4d6e2ef500000", contractAddress: "", cumulativeGasUsed: "2342230", gasUsed: "45567", confirmations: "3524953"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "500000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1503123831 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x79eb77c4a57e7d5d3ce0d9dff1ad79fd7ac37933"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "500000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "194797500000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[13], \"749000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4176683", timeStamp: "1503128909", hash: "0xbd8bff05200d7196b9b33c0032310754cb77aa4f7ea72a85f7c6ff5c784f0dbe", nonce: "29", blockHash: "0xc470ea87d1a05a4eca8458a9b05f224ee53d421680781919c8ff1f82bce2eb6f", transactionIndex: "54", from: "0xf724faaa99df6811d448053ada1e4a004f3bc9ed", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52396", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000040f661c87b8d43d77ed2c1277df54e92990633130000000000000000000000000000000000000000000000289a768ba0bf940000", contractAddress: "", cumulativeGasUsed: "2676991", gasUsed: "37396", confirmations: "3524707"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_value", value: "749000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[13], "749000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1503128909 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xf724faaa99df6811d448053ada1e4a004f3bc9ed"}, {name: "_to", type: "address", value: "0x40f661c87b8d43d77ed2c1277df54e9299063313"}, {name: "_value", type: "uint256", value: "749000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "357000000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"249000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4176693", timeStamp: "1503129118", hash: "0x65b15691aed117654208204b2d0dc43ab53a0bb419f5c2a9365d2dc384713ced", nonce: "153", blockHash: "0x0c721a33a44b188bc7e300266b5b96899d033c00f03361ec375a4f683f6ed1fa", transactionIndex: "45", from: "0x40f661c87b8d43d77ed2c1277df54e9299063313", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000000000000000000000000000000000000d7f91b4bdd0440000", contractAddress: "", cumulativeGasUsed: "4909668", gasUsed: "45567", confirmations: "3524697"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "249000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "249000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1503129118 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x40f661c87b8d43d77ed2c1277df54e9299063313"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "249000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "317709677418000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"249000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4176696", timeStamp: "1503129186", hash: "0x0a86b97f5e3ba22b4bb5b026997590e7e28951de7d99a7e5d041051843a4ff7f", nonce: "154", blockHash: "0x491eb464b1bab9c181894eb317fc736c90ae333981bd34caf4d0aa1fdb3058af", transactionIndex: "80", from: "0x40f661c87b8d43d77ed2c1277df54e9299063313", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000000000000000000000000000000000000d7f91b4bdd0440000", contractAddress: "", cumulativeGasUsed: "2848451", gasUsed: "30567", confirmations: "3524694"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "249000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "249000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1503129186 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x40f661c87b8d43d77ed2c1277df54e9299063313"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "249000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "317709677418000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[15], \"42000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4176777", timeStamp: "1503130964", hash: "0xf9dfc6b1aac083265339e60687d31a0aa24de565026bf88f7b940c9e30f5eb81", nonce: "59", blockHash: "0xb22a5e3b4486eaf6c58c7325a8202634e8d13ad61e5fd7a7f46aded88fa88725", transactionIndex: "3", from: "0xc20655792d1bd4a4a7173dcf0450bedddb97dde1", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52396", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000a532168d0a0d537bd5f3aa925b829754f906267f00000000000000000000000000000000000000000000000246ddf97976680000", contractAddress: "", cumulativeGasUsed: "118908", gasUsed: "37396", confirmations: "3524613"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[15]}, {type: "uint256", name: "_value", value: "42000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[15], "42000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1503130964 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xc20655792d1bd4a4a7173dcf0450bedddb97dde1"}, {name: "_to", type: "address", value: "0xa532168d0a0d537bd5f3aa925b829754f906267f"}, {name: "_value", type: "uint256", value: "42000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"499000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4177508", timeStamp: "1503146016", hash: "0x9faa4f451ca5a0a13ae46be30b01a8df59419edd67ed00203fb07cb1b87066a6", nonce: "51", blockHash: "0xbcc2042a9093972e0995502a67c27bf2b50b6673c53e76a0e4090862cf92109c", transactionIndex: "125", from: "0x778c2615ed7fbed9a06e595ee73436daf2022baa", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000000000000000000000000000000000001b0d04202f47ec0000", contractAddress: "", cumulativeGasUsed: "5799058", gasUsed: "45567", confirmations: "3523882"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "499000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "499000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1503146016 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x778c2615ed7fbed9a06e595ee73436daf2022baa"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "499000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "6762309844980025" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4185615", timeStamp: "1503313590", hash: "0x592fb598684be94e082e66ced98505242706ce784f22594f387f7a3987a4f424", nonce: "37", blockHash: "0x395bd4c35397d57ef10707cb67bd9851214f1a88d5eb7e4076e43a33a7483bdb", transactionIndex: "79", from: "0x00a20a450a79a1f8b7e19858dd55712b47542ff6", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc68190000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "6226150", gasUsed: "45567", confirmations: "3515775"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "100000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1503313590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x00a20a450a79a1f8b7e19858dd55712b47542ff6"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "100000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "41498907590135000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"499000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4189714", timeStamp: "1503398233", hash: "0x9354fd39a17949c7ade8477d626b71acfe74869335665b3e553afeeb06de63e4", nonce: "158", blockHash: "0x58ed7dfa61a4f8a4f99fb80293c925173a312dd28310e56b6e1f8cb0a0f53601", transactionIndex: "81", from: "0xaae1cb04c830fa907210355c0dcea3118b445bb0", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000000000000000000000000000000000001b0d04202f47ec0000", contractAddress: "", cumulativeGasUsed: "4155076", gasUsed: "45567", confirmations: "3511676"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "499000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "499000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1503398233 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0xaae1cb04c830fa907210355c0dcea3118b445bb0"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "499000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1596450669237957734" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"499000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4189717", timeStamp: "1503398270", hash: "0xbaf71b32fe85531aa5a5fc9c53e57047f423c52beb2bd2dbf5e645bd0f284a56", nonce: "159", blockHash: "0xc769e518fce3d4769abfc3aa9013653954ee16b2eab9931fdd6dd75de60f5311", transactionIndex: "75", from: "0xaae1cb04c830fa907210355c0dcea3118b445bb0", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000000000000000000000000000000000001b0d04202f47ec0000", contractAddress: "", cumulativeGasUsed: "2976525", gasUsed: "30567", confirmations: "3511673"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "499000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "499000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1503398270 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0xaae1cb04c830fa907210355c0dcea3118b445bb0"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "499000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1596450669237957734" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[20], \"700000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4194400", timeStamp: "1503494232", hash: "0x8d48b35e7a29838a0844a58ed4eb8bb3a62274c67945456baa3e8187554c08d9", nonce: "48", blockHash: "0xe92888a88a11fd041243751533fa0e899f4e6745e209cf3fc1af3c9d97d35a56", transactionIndex: "44", from: "0x50b445ce9f2176046548dee6e2cb3bc73852ba79", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52461", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000095285c240ed8a71c37ce1469c44099f859e6d7a00000000000000000000000000000000000000000000017b7883c06916600000", contractAddress: "", cumulativeGasUsed: "1614982", gasUsed: "52460", confirmations: "3506990"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_value", value: "7000000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[20], "7000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1503494232 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x50b445ce9f2176046548dee6e2cb3bc73852ba79"}, {name: "_to", type: "address", value: "0x095285c240ed8a71c37ce1469c44099f859e6d7a"}, {name: "_value", type: "uint256", value: "7000000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "65217340797360000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"792000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4198496", timeStamp: "1503578491", hash: "0x2c39d6322cbabd2cef2728a6ccecb02e44572873f3bc95a81672a61ef2e91533", nonce: "64", blockHash: "0x63c39336688404bc8ccf2cd181d34879abaea080a44078e2ff64aacee82d83a1", transactionIndex: "32", from: "0x92506dbc4655af7d3a036cb7e5e0372aadc98d62", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52397", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000b68c63da5eeb35ae1be5af03385a0f11abb618bd00000000000000000000000000000000000000000000002aef353bcddd600000", contractAddress: "", cumulativeGasUsed: "1395779", gasUsed: "52396", confirmations: "3502894"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "792000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "792000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1503578491 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x92506dbc4655af7d3a036cb7e5e0372aadc98d62"}, {name: "_to", type: "address", value: "0xb68c63da5eeb35ae1be5af03385a0f11abb618bd"}, {name: "_value", type: "uint256", value: "792000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "116082521981015973" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[20], \"142553415700000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4199226", timeStamp: "1503593245", hash: "0xe7587a7821b8acb0532279311d181335610a50a0c43518e11ca3272a11bf6e33", nonce: "49", blockHash: "0x82813555bd5fe6f67e6ca0d0303873e0e0550c26a20a149c5be0047e90b59893", transactionIndex: "70", from: "0x50b445ce9f2176046548dee6e2cb3bc73852ba79", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52524", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000095285c240ed8a71c37ce1469c44099f859e6d7a000000000000000000000000000000000000000000000304c89afde0dd4a2000", contractAddress: "", cumulativeGasUsed: "3845355", gasUsed: "37524", confirmations: "3502164"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_value", value: "14255341570000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[20], "14255341570000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1503593245 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x50b445ce9f2176046548dee6e2cb3bc73852ba79"}, {name: "_to", type: "address", value: "0x095285c240ed8a71c37ce1469c44099f859e6d7a"}, {name: "_value", type: "uint256", value: "14255341570000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "65217340797360000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"270550000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4201654", timeStamp: "1503647446", hash: "0x900bef1ce3abbc6373b48140c2dd7a13b3d25aaadb1293c0b0b4aa2f1bdf3570", nonce: "170", blockHash: "0xdde85414de1cf5acf7d56507dd7bf43c38427319c2c8d3403de08deaf8dd935c", transactionIndex: "24", from: "0x810858f00f41f99873e97a5018d83cab22843c9f", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "6000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000000000000000000000000000000000000eaaa2af908def0000", contractAddress: "", cumulativeGasUsed: "913057", gasUsed: "45567", confirmations: "3499736"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "270550000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "270550000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1503647446 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x810858f00f41f99873e97a5018d83cab22843c9f"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "270550000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "5884583108242054512" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[24], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4204072", timeStamp: "1503706795", hash: "0xdd8f30f42dba0c5ad6e3954bd9fc8b2c4e7097c71e70473c7d5bd1c3a901e415", nonce: "5", blockHash: "0xc10a6e63504143f227cb2b2eed292f9aac6e8ccfcaf73bfc3ac16a5656907a88", transactionIndex: "193", from: "0x79eb77c4a57e7d5d3ce0d9dff1ad79fd7ac37933", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "60000", gasPrice: "5687500000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000076071d20d6b6b57edf8fd02be6877e43ea0f02c600000000000000000000000000000000000000000000001b1ae4d6e2ef500000", contractAddress: "", cumulativeGasUsed: "6311490", gasUsed: "22396", confirmations: "3497318"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_value", value: "500000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[24], "500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1503706795 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x79eb77c4a57e7d5d3ce0d9dff1ad79fd7ac37933"}, {name: "_to", type: "address", value: "0x76071d20d6b6b57edf8fd02be6877e43ea0f02c6"}, {name: "_value", type: "uint256", value: "500000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "194797500000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[26], \"789127713000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4204832", timeStamp: "1503725750", hash: "0xbbc2740eec9722b4013bca4a9676863ab6191b30cb3ab3e69f6b977d96261938", nonce: "129", blockHash: "0x1d95075525b3884c44e424a14938fcda1f7bc407a3778e9baeb246ab373949a6", transactionIndex: "8", from: "0x608cb60905efc0b59ebad8a9c650a410fead95a0", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52460", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000554cea37ac322f4c6a34c2abf7a33dc734b0c0a000000000000000000000000000000000000000000000002ac758d1fee5671000", contractAddress: "", cumulativeGasUsed: "281253", gasUsed: "37460", confirmations: "3496558"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[26]}, {type: "uint256", name: "_value", value: "789127713000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[26], "789127713000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1503725750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x608cb60905efc0b59ebad8a9c650a410fead95a0"}, {name: "_to", type: "address", value: "0x554cea37ac322f4c6a34c2abf7a33dc734b0c0a0"}, {name: "_value", type: "uint256", value: "789127713000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "75447605492117114" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[28], \"370387820000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4209680", timeStamp: "1503845093", hash: "0xfa3934cc37dfb43e5af2d447e4f2b9f44d3ceb217360505a73e7a2007955073e", nonce: "0", blockHash: "0xee8bf559386bd9bf743cc1070beeeb8b6c19628725ef33fd8aac779c5e997f44", transactionIndex: "1", from: "0x86e9c2c1d28dac0b8919ffa094710de7c069c843", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "37460", gasPrice: "52000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000002498874f1c02b1d5c11a17b15a6cb11c3918585c0000000000000000000000000000000000000000000000141429dfe42752c000", contractAddress: "", cumulativeGasUsed: "43460", gasUsed: "22460", confirmations: "3491710"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[28]}, {type: "uint256", name: "_value", value: "370387820000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[28], "370387820000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1503845093 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x86e9c2c1d28dac0b8919ffa094710de7c069c843"}, {name: "_to", type: "address", value: "0x2498874f1c02b1d5c11a17b15a6cb11c3918585c"}, {name: "_value", type: "uint256", value: "370387820000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[29], \"377387820000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4211897", timeStamp: "1503900189", hash: "0x118c5ddad291acd06ed08a1d8b9b911cc11fc1e160517560e62a7b085294e369", nonce: "45", blockHash: "0x2ad340a5cfa73e64380fe50f65349175464d707da34cc0a6675056e679b454dd", transactionIndex: "7", from: "0x2498874f1c02b1d5c11a17b15a6cb11c3918585c", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52460", gasPrice: "55000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000000e7ac5d8f55f0bf2c3f8dac5836022750c2a46ce000000000000000000000000000000000000000000000014754edecdbb0ec000", contractAddress: "", cumulativeGasUsed: "200860", gasUsed: "37460", confirmations: "3489493"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_value", value: "377387820000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[29], "377387820000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1503900189 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x2498874f1c02b1d5c11a17b15a6cb11c3918585c"}, {name: "_to", type: "address", value: "0x0e7ac5d8f55f0bf2c3f8dac5836022750c2a46ce"}, {name: "_value", type: "uint256", value: "377387820000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "53432306971777777777" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: burn( \"4000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4212300", timeStamp: "1503910614", hash: "0x0689dc0f6e01c1dfaac6f0b192acb32ecfa1fa213f937a3b504b98f7018dfaec", nonce: "2", blockHash: "0xe876da155f5424046aa05e6dfb785aeabeb57b093cfc0bfe96a61e4e8f54c0b9", transactionIndex: "134", from: "0x305732b09edbf31429560f7e38c090453a16adc5", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "500000", gasPrice: "24824854500", isError: "0", txreceipt_status: "", input: "0x42966c680000000000000000000000000000000000000000000000003782dace9d900000", contractAddress: "", cumulativeGasUsed: "5074508", gasUsed: "22036", confirmations: "3489090"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "4000000000000000000"}], name: "burn", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "burn(uint256)" ]( "4000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1503910614 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x305732b09edbf31429560f7e38c090453a16adc5"}, {name: "_to", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_value", type: "uint256", value: "4000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_newTotalSupply", type: "uint256"}], name: "Burn", type: "event"} ;
		console.error( "eventCallOriginal[23,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Burn", events: [{name: "_from", type: "address", value: "0x305732b09edbf31429560f7e38c090453a16adc5"}, {name: "_amount", type: "uint256", value: "4000000000000000000"}, {name: "_newTotalSupply", type: "uint256", value: "79753254482000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[23,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "11865386756238000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[29], \"278919771000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4215732", timeStamp: "1503995147", hash: "0xde5a9ea6134680a96ec6d50027107220b0be057ef96d67101abca09480040b47", nonce: "28", blockHash: "0x4a1be578c3dd4183bc061e49a5cdba6558903a4961019b41575b5d8bab870a92", transactionIndex: "0", from: "0xb3e1819fe07bf073819859073cf400ca2d0a753a", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "45000", gasPrice: "51000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000000e7ac5d8f55f0bf2c3f8dac5836022750c2a46ce00000000000000000000000000000000000000000000000f1eca15f1b84cb000", contractAddress: "", cumulativeGasUsed: "22460", gasUsed: "22460", confirmations: "3485658"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_value", value: "278919771000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[29], "278919771000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1503995147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xb3e1819fe07bf073819859073cf400ca2d0a753a"}, {name: "_to", type: "address", value: "0x0e7ac5d8f55f0bf2c3f8dac5836022750c2a46ce"}, {name: "_value", type: "uint256", value: "278919771000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[32], \"707000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4216477", timeStamp: "1504013121", hash: "0x43396f8ea78e56e09ec935d8bce44d2961b71463be999c6fc46f630178cd1a93", nonce: "163", blockHash: "0x94fec1afffcf659d2923d5fda55f04e3c3fa470bbcb194cdf9badea2f8ea14c4", transactionIndex: "156", from: "0x40f661c87b8d43d77ed2c1277df54e9299063313", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "152396", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000060bd735f26fbe35667448834a8680240295f50b300000000000000000000000000000000000000000000002653989227492c0000", contractAddress: "", cumulativeGasUsed: "5807423", gasUsed: "37396", confirmations: "3484913"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[32]}, {type: "uint256", name: "_value", value: "707000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[32], "707000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1504013121 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x40f661c87b8d43d77ed2c1277df54e9299063313"}, {name: "_to", type: "address", value: "0x60bd735f26fbe35667448834a8680240295f50b3"}, {name: "_value", type: "uint256", value: "707000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "317709677418000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[34], \"2000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4218996", timeStamp: "1504074700", hash: "0x85690bcc980eb957d0d59fcae6765b0d7950dbbd1920f01ddea1b8a6e47a75df", nonce: "1", blockHash: "0x782e59876ea5eedc650dcf23e613a6bc0ed0bc769812025c2957fd1b000c4f33", transactionIndex: "34", from: "0x1423c1eddd4ce254dad54f563ffbfdfec5eb0731", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52333", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000df89af4e461edbbf8afb5f559181fe429630c2ba0000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "2344000", gasUsed: "52332", confirmations: "3482394"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[34]}, {type: "uint256", name: "_value", value: "2000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[34], "2000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1504074700 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x1423c1eddd4ce254dad54f563ffbfdfec5eb0731"}, {name: "_to", type: "address", value: "0xdf89af4e461edbbf8afb5f559181fe429630c2ba"}, {name: "_value", type: "uint256", value: "2000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[34], \"3000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4219364", timeStamp: "1504084014", hash: "0xc1f8c6d6736c805218e416e212f6a6c9b8beb67bb1ade14139e9291f505ce5bf", nonce: "2", blockHash: "0xa8a25a8546d235136ede72e3f3334dd908716b7cb1f0d1d01c232e4bdf98c5e3", transactionIndex: "99", from: "0x1423c1eddd4ce254dad54f563ffbfdfec5eb0731", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52332", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000df89af4e461edbbf8afb5f559181fe429630c2ba00000000000000000000000000000000000000000000000029a2241af62c0000", contractAddress: "", cumulativeGasUsed: "3667324", gasUsed: "37332", confirmations: "3482026"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[34]}, {type: "uint256", name: "_value", value: "3000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[34], "3000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1504084014 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x1423c1eddd4ce254dad54f563ffbfdfec5eb0731"}, {name: "_to", type: "address", value: "0xdf89af4e461edbbf8afb5f559181fe429630c2ba"}, {name: "_value", type: "uint256", value: "3000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"499000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4219956", timeStamp: "1504098994", hash: "0xf5a94c9d9251998f800e9f1d465fa1acc3061da4cf6e7ab9595543c6f7550f80", nonce: "131", blockHash: "0xba4f3d71eebed538c58704780bd0c2ddc590c00818d19b2d975baaaed800c4bc", transactionIndex: "55", from: "0x8e5d6e1292f3c07ad35fd2e8848f007c7cb1d1ff", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000000000000000000000000000000000001b0d04202f47ec0000", contractAddress: "", cumulativeGasUsed: "3149876", gasUsed: "45567", confirmations: "3481434"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "499000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "499000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1504098994 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x8e5d6e1292f3c07ad35fd2e8848f007c7cb1d1ff"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "499000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[37], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4220411", timeStamp: "1504110418", hash: "0x20b3d32cd2ada12d88469e70b708809c0ff8d40095ddfba64209e98e039544c1", nonce: "0", blockHash: "0x28650e3079f7732ee1e8d90dc4714f79a865ec81c44e4fd1e8dd2675bf987446", transactionIndex: "2", from: "0x73b971ad24845e1d8ba5a18ce5962aef68165b68", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52397", gasPrice: "56000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000887a74a0c897a042cb2ddc084b6421f1bed96b460000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "133396", gasUsed: "52396", confirmations: "3480979"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[37]}, {type: "uint256", name: "_value", value: "100000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[37], "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1504110418 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x73b971ad24845e1d8ba5a18ce5962aef68165b68"}, {name: "_to", type: "address", value: "0x887a74a0c897a042cb2ddc084b6421f1bed96b46"}, {name: "_value", type: "uint256", value: "100000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[29], \"401136968000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4220415", timeStamp: "1504110580", hash: "0x17d306268f95a5a65dd33c9bb85830cd7488a08a5e4166471cd276ba612f10d2", nonce: "1", blockHash: "0x2ffde2dbc28a5111a51976d586969755f5c4f1aac44d30e96f674707ef2bac2b", transactionIndex: "29", from: "0x73b971ad24845e1d8ba5a18ce5962aef68165b68", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52000", gasPrice: "56000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000000e7ac5d8f55f0bf2c3f8dac5836022750c2a46ce000000000000000000000000000000000000000000000015bee4cb14cd3c8000", contractAddress: "", cumulativeGasUsed: "1342102", gasUsed: "24704", confirmations: "3480975"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_value", value: "401136968000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[29], "401136968000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1504110580 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[29], \"301136968000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4220422", timeStamp: "1504110803", hash: "0x1352c4c93108c39221ebd1e6270a7ce09e891074e5ae0613993c08f3308f7375", nonce: "2", blockHash: "0x75224ad69680df54cdd34d559cb2ccfe015d1cbc899b1fc48d647908a52cf5d2", transactionIndex: "8", from: "0x73b971ad24845e1d8ba5a18ce5962aef68165b68", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52000", gasPrice: "56000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000000e7ac5d8f55f0bf2c3f8dac5836022750c2a46ce000000000000000000000000000000000000000000000010531d6ce76a2c8000", contractAddress: "", cumulativeGasUsed: "284503", gasUsed: "22460", confirmations: "3480968"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_value", value: "301136968000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[29], "301136968000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1504110803 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x73b971ad24845e1d8ba5a18ce5962aef68165b68"}, {name: "_to", type: "address", value: "0x0e7ac5d8f55f0bf2c3f8dac5836022750c2a46ce"}, {name: "_value", type: "uint256", value: "301136968000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[39], \"2000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4221100", timeStamp: "1504127214", hash: "0xb583a7f4b3ff36ef74e9aad71437ba9dfd64c14b2eea636b90fb1895ba8e62e9", nonce: "5", blockHash: "0x88c5f327920a8e7e6793717ec6043d9efda1a67306062c517b21e7a4010c2d70", transactionIndex: "88", from: "0xeffc47db119b138d220c47a7496e32262b29b033", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52333", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000b2979ac909b7178a2d306dd77b1c2af0f623b9800000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "2127676", gasUsed: "52332", confirmations: "3480290"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[39]}, {type: "uint256", name: "_value", value: "2000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[39], "2000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1504127214 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xeffc47db119b138d220c47a7496e32262b29b033"}, {name: "_to", type: "address", value: "0xb2979ac909b7178a2d306dd77b1c2af0f623b980"}, {name: "_value", type: "uint256", value: "2000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[39], \"268550000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4221125", timeStamp: "1504127918", hash: "0xc5745bb173aa8429448e11586445c550e12eeb2695f1f76016dc2ee074ebe040", nonce: "6", blockHash: "0x7004b4ecb0aa5fc8d459975b0b6e087eadce6f865957ffb5c9e006dff3ba5e79", transactionIndex: "164", from: "0xeffc47db119b138d220c47a7496e32262b29b033", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "37396", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000b2979ac909b7178a2d306dd77b1c2af0f623b98000000000000000000000000000000000000000000000000e8ee142293f270000", contractAddress: "", cumulativeGasUsed: "5006691", gasUsed: "22396", confirmations: "3480265"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[39]}, {type: "uint256", name: "_value", value: "268550000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[39], "268550000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1504127918 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xeffc47db119b138d220c47a7496e32262b29b033"}, {name: "_to", type: "address", value: "0xb2979ac909b7178a2d306dd77b1c2af0f623b980"}, {name: "_value", type: "uint256", value: "268550000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[40], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4223041", timeStamp: "1504174164", hash: "0xac498c5c584985a3e36997257485530887d406b3210a012d535cd84b755be1dc", nonce: "0", blockHash: "0xb7cfe06119291a244d67bddf98f85b4d3ae3b84cf621406ee05cb5fd7566347b", transactionIndex: "3", from: "0x887a74a0c897a042cb2ddc084b6421f1bed96b46", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52396", gasPrice: "57000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000192f6a84b3d1f8309cf0d184838018e83cb819790000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "196831", gasUsed: "37396", confirmations: "3478349"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[37], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[40]}, {type: "uint256", name: "_value", value: "100000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[40], "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1504174164 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x887a74a0c897a042cb2ddc084b6421f1bed96b46"}, {name: "_to", type: "address", value: "0x192f6a84b3d1f8309cf0d184838018e83cb81979"}, {name: "_value", type: "uint256", value: "100000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[37], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[37], balance: ( await web3.eth.getBalance( addressList[37], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[42], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4224184", timeStamp: "1504202949", hash: "0x8ae2e6348aa0615e5076738dc35e9e66f6971640e8e53f51c47bae1b389e23ed", nonce: "2", blockHash: "0x7db1910245b973e5d0203620b6d0bb72d7ba5de73eec6536fd3737a79326d0d4", transactionIndex: "34", from: "0xb7c260e9331b788f186c59e1edfa982f81678a68", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "37332", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000023d46e916a4ca406153a1d4f2ba3b1dcff31522a0000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "1234227", gasUsed: "22332", confirmations: "3477206"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[42]}, {type: "uint256", name: "_value", value: "1000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[42], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1504202949 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xb7c260e9331b788f186c59e1edfa982f81678a68"}, {name: "_to", type: "address", value: "0x23d46e916a4ca406153a1d4f2ba3b1dcff31522a"}, {name: "_value", type: "uint256", value: "1000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "538394710339115585" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[43], \"2000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4224191", timeStamp: "1504203181", hash: "0xf06b6684f9d96c20576f00082ccdae152f2b4875c5127cf73368e4b09d6749ab", nonce: "0", blockHash: "0x20d6ab5871fe42e23fd228b5b861d175028735ec9e0ead53b96b9f310173dd9b", transactionIndex: "103", from: "0x23d46e916a4ca406153a1d4f2ba3b1dcff31522a", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "52332", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000ab79e567ba66a1a3699f5faadbaed44ac08796b50000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "4715605", gasUsed: "37332", confirmations: "3477199"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[42], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[43]}, {type: "uint256", name: "_value", value: "2000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[43], "2000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1504203181 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x23d46e916a4ca406153a1d4f2ba3b1dcff31522a"}, {name: "_to", type: "address", value: "0xab79e567ba66a1a3699f5faadbaed44ac08796b5"}, {name: "_value", type: "uint256", value: "2000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[42], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[42], balance: ( await web3.eth.getBalance( addressList[42], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[45], \"502348272000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4226200", timeStamp: "1504252176", hash: "0x0752cd1ac7f28e683385a6962301186482b6e4c98f180ea237e90315dbdb9f59", nonce: "7", blockHash: "0x0829ddb93f0b402276d8fde7a58d71aabefc0d3cbc0ad0de7fd51640a1a45009", transactionIndex: "0", from: "0xb43d8a6e82fa38a49f8a5fa9c0602349071ab49d", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "100000", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000004b7c2ca6b9cce7580871e2a154af697ac58ee8b900000000000000000000000000000000000000000000001b3b7b93d42b4f0000", contractAddress: "", cumulativeGasUsed: "37396", gasUsed: "37396", confirmations: "3475190"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[44], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[45]}, {type: "uint256", name: "_value", value: "502348272000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[45], "502348272000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1504252176 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xb43d8a6e82fa38a49f8a5fa9c0602349071ab49d"}, {name: "_to", type: "address", value: "0x4b7c2ca6b9cce7580871e2a154af697ac58ee8b9"}, {name: "_value", type: "uint256", value: "502348272000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[44], balance: "997538891262683964" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[44], balance: ( await web3.eth.getBalance( addressList[44], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[29], \"302098316000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4226901", timeStamp: "1504269181", hash: "0x96432c587afb4e918adeeddfaa6233108aefd44770b6605f6bc2abc70a447c05", nonce: "0", blockHash: "0xdbb9cb08f7ae60aa503b6a3f749d291ac13969df40eb546c254b7e70303cd191", transactionIndex: "4", from: "0x1fa5df5bfbc13640daa6d37e1112f3dded1b8e9d", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "37460", gasPrice: "51000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000000e7ac5d8f55f0bf2c3f8dac5836022750c2a46ce0000000000000000000000000000000000000000000000106074d1d107b4c000", contractAddress: "", cumulativeGasUsed: "126251", gasUsed: "22460", confirmations: "3474489"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_value", value: "302098316000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[29], "302098316000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1504269181 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x1fa5df5bfbc13640daa6d37e1112f3dded1b8e9d"}, {name: "_to", type: "address", value: "0x0e7ac5d8f55f0bf2c3f8dac5836022750c2a46ce"}, {name: "_value", type: "uint256", value: "302098316000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[48], \"250000\" )", async function( ) {
		const txOriginal = {blockNumber: "4227498", timeStamp: "1504283997", hash: "0x9c4a954cb2d3b20e83bd95bb15a2d2e08e197ad0283b9562aef191754d2a6ef7", nonce: "27", blockHash: "0xc66f4c186c321c732a8555d3560d32264697055583679354f1b37475baeb88ec", transactionIndex: "105", from: "0x42503e603489d8ac1b5a634d6efb607963ba248e", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "152141", gasPrice: "26000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000087f00bf7096cef81347b1e60d5da23fb33958343000000000000000000000000000000000000000000000000000000000003d090", contractAddress: "", cumulativeGasUsed: "3927932", gasUsed: "52140", confirmations: "3473892"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[48]}, {type: "uint256", name: "_value", value: "250000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[48], "250000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1504283997 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x42503e603489d8ac1b5a634d6efb607963ba248e"}, {name: "_to", type: "address", value: "0x87f00bf7096cef81347b1e60d5da23fb33958343"}, {name: "_value", type: "uint256", value: "250000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[48], \"249999999999999975000... )", async function( ) {
		const txOriginal = {blockNumber: "4227512", timeStamp: "1504284390", hash: "0xb6c5fdb513a6f28ece2bb2d8caff727ec1915d4cc52aef3c0718a8efb0be4965", nonce: "28", blockHash: "0xde2e5fe796730fc10b4f89dea0b7ce9525b60f8155ab11a22a74736bc7ce59a7", transactionIndex: "63", from: "0x42503e603489d8ac1b5a634d6efb607963ba248e", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "137525", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000087f00bf7096cef81347b1e60d5da23fb339583430000000000000000000000000000000000000000000000878678326eac8c2f70", contractAddress: "", cumulativeGasUsed: "1918052", gasUsed: "52524", confirmations: "3473878"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[48]}, {type: "uint256", name: "_value", value: "2499999999999999750000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[48], "2499999999999999750000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1504284390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x42503e603489d8ac1b5a634d6efb607963ba248e"}, {name: "_to", type: "address", value: "0x87f00bf7096cef81347b1e60d5da23fb33958343"}, {name: "_value", type: "uint256", value: "2499999999999999750000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4227546", timeStamp: "1504285178", hash: "0xde956d29255b0712a3d58b5398c591b5fa517ee29ec3c1b911b4c2b076f52278", nonce: "10", blockHash: "0x86f49a858edbfc09fbb0e0057c4c9493f3ed63ac8a085169790e46b359afb319", transactionIndex: "116", from: "0xcf6c7e98053ad4d8a635dd481941abfea7a90403", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc68190000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6082757", gasUsed: "45503", confirmations: "3473844"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "1000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1504285178 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0xcf6c7e98053ad4d8a635dd481941abfea7a90403"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "7895160208354103" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[51], \"5000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4227581", timeStamp: "1504285958", hash: "0xdcd6dd26c744e060c7bb7e3f1fdbff3a8d68b99fb6a363808ed948609d8aea59", nonce: "0", blockHash: "0x204058f40dd5b05595d1c3291f6269623f2a11b1ac605ea1f5915463aee7f5a0", transactionIndex: "155", from: "0x63a1d3dbec37ca4b1db520056e8f82534376b24b", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "200000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb0000000000000000000000004b85e9d2e433d7eca29f8a7a859cf0346702c89a0000000000000000000000000000000000000000000000004563918244f40000", contractAddress: "", cumulativeGasUsed: "4462174", gasUsed: "52332", confirmations: "3473809"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[50], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[51]}, {type: "uint256", name: "_value", value: "5000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[51], "5000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1504285958 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x63a1d3dbec37ca4b1db520056e8f82534376b24b"}, {name: "_to", type: "address", value: "0x4b85e9d2e433d7eca29f8a7a859cf0346702c89a"}, {name: "_value", type: "uint256", value: "5000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[50], balance: "2287898917570460" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[50], balance: ( await web3.eth.getBalance( addressList[50], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"498000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4227583", timeStamp: "1504285992", hash: "0x12667ee27f586197a72eb4be06d5ae95bb4c45f048910c649379ccedb22b9d29", nonce: "13", blockHash: "0xde886e1e0fe8a707044033555a80343577ecf197c0bdb428456e9a8c4fea2e1c", transactionIndex: "134", from: "0xcf6c7e98053ad4d8a635dd481941abfea7a90403", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000000000000000000000000000000000001aff23697ba0880000", contractAddress: "", cumulativeGasUsed: "6241303", gasUsed: "45567", confirmations: "3473807"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "498000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "498000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1504285992 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0xcf6c7e98053ad4d8a635dd481941abfea7a90403"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "498000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "7895160208354103" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"2000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4227594", timeStamp: "1504286217", hash: "0xc7937f520802adc3f431de3face33bc9ccfc68e1450bba4799997fea82013ca3", nonce: "0", blockHash: "0xbf1264b3230f6e52f60dfdbff9d44a458f1468b46b97adb736f01928620383c9", transactionIndex: "76", from: "0x218c31fd147173c981aa857f9cfb4cb8780a34f5", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc68190000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "4246561", gasUsed: "45503", confirmations: "3473796"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[52], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "2000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "2000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1504286217 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x218c31fd147173c981aa857f9cfb4cb8780a34f5"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "2000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[52], balance: "115838418864661820" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[52], balance: ( await web3.eth.getBalance( addressList[52], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"672355000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4227705", timeStamp: "1504288869", hash: "0x30c0babb934897d614cae97916aff51c7a9ca7531afa7c0179f3f19efd0defae", nonce: "45", blockHash: "0x09d8252964bca80de007d380afc8e0836cfbefeac910fb7e88cc114a6500618a", transactionIndex: "98", from: "0x626a7b370391310b1cb9f6e17273a43e95851048", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000000000000000000000000000000000002472ccce35e5c38000", contractAddress: "", cumulativeGasUsed: "4969719", gasUsed: "45631", confirmations: "3473685"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[53], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "672355000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "672355000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1504288869 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x626a7b370391310b1cb9f6e17273a43e95851048"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "672355000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[53], balance: "2012961979407938" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[53], balance: ( await web3.eth.getBalance( addressList[53], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"999000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4227788", timeStamp: "1504290650", hash: "0xbca7c2608c754ddae4015305f0e7be854abfc2992cbd2044a91d57c1f5effbb4", nonce: "134", blockHash: "0x6c4d19560406fef38f52157455fcfd2bc30346b3361ac79090fc923920f30ee2", transactionIndex: "142", from: "0x8e5d6e1292f3c07ad35fd2e8848f007c7cb1d1ff", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc681900000000000000000000000000000000000000000000003627e8f712373c0000", contractAddress: "", cumulativeGasUsed: "6151690", gasUsed: "45567", confirmations: "3473602"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "999000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "999000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1504290650 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x8e5d6e1292f3c07ad35fd2e8848f007c7cb1d1ff"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "999000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"49000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4227889", timeStamp: "1504293139", hash: "0x0642c82fb70c16e428d829c5e98125177a4fafb85c7bffcc7bb4c9b6874539c0", nonce: "0", blockHash: "0x0764931a26898a97ba4cb3fe48b406593c0645520cf32a4ecc4e0d194dd230ae", transactionIndex: "121", from: "0x2bc2ca2a7b3e6edef35223a211ac3b0b9b8d4346", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000002a802f8630a240000", contractAddress: "", cumulativeGasUsed: "4846662", gasUsed: "45567", confirmations: "3473501"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "49000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "49000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1504293139 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x2bc2ca2a7b3e6edef35223a211ac3b0b9b8d4346"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "49000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "543218663388108118" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[56], \"18000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4228005", timeStamp: "1504295999", hash: "0x74b3424c048617b4e42e0a755d8fa6547357ea4bd80174fc40c891a2428244b8", nonce: "3", blockHash: "0xe98a845f658fb0072c44d3511c7aa113cdb0266edd03643d2391b8939c23ce33", transactionIndex: "72", from: "0xef2507aa7014c45152dbacb5092a571d4a94d925", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000019190710378c7828bf101270c171894c3092326f000000000000000000000000000000000000000000000000f9ccd8a1c5080000", contractAddress: "", cumulativeGasUsed: "4480548", gasUsed: "37332", confirmations: "3473385"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[55], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[56]}, {type: "uint256", name: "_value", value: "18000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[56], "18000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1504295999 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xef2507aa7014c45152dbacb5092a571d4a94d925"}, {name: "_to", type: "address", value: "0x19190710378c7828bf101270c171894c3092326f"}, {name: "_value", type: "uint256", value: "18000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[55], balance: "3987616000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[55], balance: ( await web3.eth.getBalance( addressList[55], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"400000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4228006", timeStamp: "1504296038", hash: "0x683bd9440015eaf55b4179ffaf41b2f7300ba2353b23aaa561b56f39d1230096", nonce: "3", blockHash: "0xcd5e119e815a0ae0b7d8efa9322a3b806ef01213cdd1eecad0a66a2f2b46abb3", transactionIndex: "76", from: "0x2bc2ca2a7b3e6edef35223a211ac3b0b9b8d4346", to: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970", value: "0", gas: "250000", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000015af1d78b58c400000", contractAddress: "", cumulativeGasUsed: "5140902", gasUsed: "45567", confirmations: "3473384"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[10]}, {type: "uint256", name: "_value", value: "400000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "400000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1504296038 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x2bc2ca2a7b3e6edef35223a211ac3b0b9b8d4346"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "400000000000000000000"}], address: "0xe5a7c12972f3bbfe70ed29521c8949b8af6a0970"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "543218663388108118" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
