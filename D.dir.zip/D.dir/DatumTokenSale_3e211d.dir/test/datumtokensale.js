const DatumTokenSale = artifacts.require( "./DatumTokenSale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "DatumTokenSale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xE6766297571F8693adec94e5f8ef363D323e211D", "0x5EF33f97A8B716A11C40c74b5DAB56d74D5e3c58", "0xA899df9e9CF14A7C5b87744b1EdC6890a712cb97", "0x0079eF6B5d2777774Afb5b74680C058b11DED77f", "0xa28FB44e8b73A20f88c9CF1bacbE4f1Cc038d9E1", "0xE9f2E452E4f6ef755035B1a0a73a67f104846127", "0xCCd17Ad819C4C71F41E31157Eb316b4a843eF0bE", "0xE73CeEc12AbcB039B99c9e06900c8C4517FD592C", "0x7C6998F6AbABb97199EcF4672e00710dAC0d2e4C", "0xfDAbaFBFBe0c4e238b863BfFcBD98D3BF6c7ff10", "0x7713BC05e727CEE0CA62861D4cbF42A5E8bbC211", "0x571795CBbB3243b3923aB1EB4487215397D099B2", "0x15B2719A55E840E84dA704100DdbA2675Aaf1005", "0x27538F05395B500170294400745Cb190096E277e", "0xc094C22Fad02DfAfeB45123b40e1Bb5b5941C291", "0xCF1BCbB30cA47B37754081e43360E783117C2E4a", "0x2C38d21f510eC901f39A4Ac7D0f834B20eF2fa68", "0x5759061dE128eF83517CeBe1CfCF3703feA4CFBd", "0xd3F9f45908965E0A58822E77f0568a148Cc3Efac", "0x5Cca1Dd2dcB143d5f99588efF59748BCc5946f3e", "0xA2861B88ad53A9f056402c36a8c63f72c8BC0EB3", "0x914Af8E4438359dBac232d9e6051Cc6762ae930C", "0x23df1074ab69D313A18c95Cc4129D5cFF4BA6408", "0xFE733aca9fCc9024Bf6e12bd345835950B4ef083", "0x80641BcBA5A3951d7E01e04FaaB26b414Fbad162", "0x6243C3C6172D9758dcCDCFa40dFb3c888B615a64", "0xB2C3c27bf78aB22e116172036aa38f5AD80ed937", "0x5d5D643ef1446B81CD8FC658DEb918DA540bDD23", "0x9300909A77e765872022e7db5dfCeb1330c836FB", "0xd2E89790abAcC3412cE328DEe4A64007948F7c7E", "0x228a2E2b2FE39695940eC3CDc06e95208693c37b", "0x1C1Bb5915cEc7dA52985a2765519Fc23483C93B0", "0x6Da5960902f6C6804F11b30e59594F8CbAa1718F", "0x7bff82c27fa7AD2e04beb543404808599F90cd10", "0xae3c3Eb95b5f65BAD910f35300EB67b5321E87af", "0xcEe95733fb63ae1a4D397B2eEFE701817c23694c", "0xDeD9d129C2A0c45a6Be4b5FD961235091721fb51", "0x6d70B72C0455991a839b93923FEb9cD9fed9E545", "0x2d5edf44cEc2b2eC5B3A062fdA53F53391fD2Bf2", "0xFBb1b73C4f0BDa4f67dcA266ce6Ef42f520fBB98", "0xE68a452CadBfa2D7F87960Fa837D54feE0614938", "0xa46a69569B4D86daB047142a6AD657893Dac287e", "0x6Fb6EAe7F83Eb2d2cE86Db33A73e78983a5A0693", "0x1b1774F3749d8efA524591C125C0C8349Cf782F4", "0x82f298e25caC12F712E2047fc08c59FEE7c322C7", "0x999DEE64B75209243c0be481d454D1EC72418eF8", "0xad27DD6bA4c56aC93D3c02a767B69BEB98190255", "0x050CBBcCe5Bc7d4e7831e9136Dd54151609Bb7Ce", "0xC49325C65EcC701198874b5516924C6cD1657766", "0x00d357CC58Fde175760c2689c1E050F75B46c26A", "0x6E3c904A2Db3B5eFc7B619257D5127F39cA2653e", "0x12f8f25BBcdb6e99F7BA957989F62f9a22a9BAb0", "0x6817108ecf2Bf2842F49cBBd7d7647e48575123B", "0xf5F1216d72321AfE6d2a053F163145a349E1329E", "0xD1dDE7728264bf5bF14D01DBE768CBfa9cB8c87A", "0x8c3C524A2be451A670183Ee4A2415f0d64a8f1ae", "0xd02A135627224Cab666BDdE27B36b6C6d09C7323", "0x00Ddc3285dcFAadA9895448DBE732AD335f54240", "0xD2a2401109C63884a8B27fCA99EE63c07A8D51C6", "0x2F2fF938eD348da2BAc284f6f6FCb1f06a71Ff8e", "0x17ecd0545D46eA2768ea3F987F0b8A4651B357C2", "0x468dBc8796Faabd8303911474C7E06C42776E867", "0x60F1C5d41C1931e77Cf0F5FcC4A1F3C94BDaFb28", "0xa0Fdb50236135d9F6cB2CB43656dd55A1d2a6878", "0xCA766AEaA877d3941768Ef4c27eFaA8D3FdcbbFc", "0x4c23AFf782883B78eE394c56eFe673e540c224A7", "0xe614A4Fb56A1E803b9b83d8444c047F3Ff524aC3", "0x34A96b68e1b3FD3eA52CA6f485BD94d2471B0c2E", "0x73A1c1088801e25fc7E9bA63C962952Ae3EdA693", "0x54715B6451A6AED81BDeeF4605E0EE5136D4fF80", "0xC03Fde71fb2C0Cd93c79a7a164d58CCf430412D3", "0xB0Ee9b83f268e40dC31cc6EB0c9abd3420103aa1", "0x9619D11CFd728dF2e062281F06A3356e9E233ff0", "0xbFf8F97C2Fa01f8ebf301f816F74c576136A4C66", "0xEa5C5e91d45Aa47f7DA9410cef6DE56326329f53", "0x2EddA2A41cDE3D88fA031163aFdD881F8dDF7D76", "0x487835B9A2B5ab6DE973bBe71f936d9856B7948F", "0xE3049a11C843d4F3d2a1efCAeC1f33342c56FDB8", "0xa0AD5e0E8fc86a8440992Ad57B201FaDefBaF595", "0xc182D6D7506B7756e0474EA27451cAB46fD73F5A", "0x5C44f3Dd2Bf7F49e99b79FaeeBe770124AaaD23C", "0xA90A03e6771770C13b9d980A6643a131048e342A", "0xdD69ac836b4C1856290696A2C89f2503781ed11c", "0x5051CB2f363eaFE2fDD8CC32bCcF742016EE7285", "0x5f4168892f9E697dBE18E6d1d4515dAC056252b5", "0x8bfB25AaE90465657e473815DE66625187434AE0", "0x4d798448f76cB8DAB81622D10092c38e11468562", "0x48b11Cb3d442f094CEaa97F3c7012A2624bBfd09", "0x08992d34f13a137114058FEf51b47B1ad5247231", "0xb9B72cF937D9FA0f70F4E1a8E3F166c52897b736", "0x0389272aa1C642f1B051728F48B8EAD262613EAA", "0x018e8a4E614f98FA24B1C2e2F2bf97F5737e3f47", "0x01A1691Ea98e647Fd348FA2fd8A9b44ABE947a07", "0xcf10b94a99a1a6dCE62f7fB708C860eDC530f0F4", "0x0d80b358953cb93Dd76027354146e9e23bDfff37", "0xE79075d6a584E386e3DFb9C1aAD506AF1F46d06D", "0x1dFBf8Fd08d154459cFeF56a5DAA348fB20052C1", "0xdEEB8431db02b14273B930BDa8ecBE1336C2C5e0", "0x0554C53C3e9d959Ed278E3bc085D42ae9bfDE7c5", "0x007cA5C1AfdCE9618C0bb7d86C2E1699fe935581", "0x1aF4A58af447639563Bc9a420981D6fF7a785D6D", "0xdcDe00E24e44d0291C656d7ad16465289365Ca03", "0x89d0790090d0E79Bc1B16A3b7727aaB394b38561", "0x14462B5Ce639C3d381e6Fd6F03aF358a8cD0741b", "0xbe19FEbdF5a1273D0bd3c6a13Acab4e5a434991A", "0x31eCd2B8D55B4a9A1f587CB90146f35E1C579a6B", "0x5C91364F0a6C4D0e869cB24ff012Bb87c08218B4", "0x57E81f0a76781382A36984b0E23B4d551c163BDd", "0x79685F2F4c74ceAC40508aFfBcdCc1194A0Ed1c7", "0x823355b7323b70Ec9b881e0541FC8B96055E7193", "0x537A649915b7866C978A4Dd4afB5Bc7f5e4155Be", "0xeAcac102b636E38B55fBaE52C50eE3677B51ca84", "0xd26510D553e5BC9fdDA01C52d112c92DD2d55D4b", "0x86F8c74454ff8e1e7e7986BCF267d4167ee44320", "0xf2311E976a1f3C256d8AbdFb52f87C897E7e04c0", "0xE8bcC0FC7421ce248e88A191128aD8169fDC25E9", "0x72a9cc244f2D36DA1f89748D64fA33b9f7e973b4", "0xF44197864722E4E300A89624480d275eC2988383", "0x5ceAede33080851debA28041B9ab18087f83Fa12", "0x7F17a62BD78014dB9569bf20c7EEFCc25e3d0AA5", "0xF1dF86E8B7c68835f35BF215eb2a464ce0397C2e", "0x4A9c8C0eBC2eaAB9B9674e9202a0FBbaab2e882B", "0xAC3e926028FD002446e1E8781d3d0745Aa465d70", "0x54Fc433E95549E68FA362Eb85c235177d94a8745", "0x3467665E6915F14C73c2818eEdF96935162549c5", "0xc74324d50Cc6FD8c6D2f04238a82eA6e5652dE57", "0x72Eac7A456606010fBdaDB793c83F767F9C94bF8", "0x0F424f1A7A05772F30BB034726068275F88776c9", "0xd4c6073d0E586aC4729dC18539fd0Ea534c1DfC9", "0x3ea0B8a0e240bbBBA77B5f5E855Bd9a58090CEDC", "0x79aa26E907FA4c0B01f96365b8F0EffF3bc1aF83", "0x5C5ACccba3f32aE66bfF15d2ba252091C731bcBA", "0xcbA20f1F55AFC27B977F740C7Fa0F1916a4FA023", "0xdfd38cfEBcD556c1e28bF15f66c55246dB6B65D6", "0xa4E88e89d15Bf0CB81833235B276cDd3f88bb7f6", "0x7625dF361070954B0d32d7600BF37a18bF8e0f9c", "0x2ef9d5d059b5f88e3595B25F3Fa49fC2CF2Fda38", "0xbFffc4ca4A430B8Df71D06724138EE3B210328AE", "0x557A9d49DAA4EAc52E6C2EAFD2813789c194750d", "0xF962E1E7ecf9bAaB6F88933A20469729B353C59A", "0xE0D9F6A0Be3d378dd2773C5B119ad27160f96134", "0x1956fba58840de3440b358AD8828b7F33Acb6Cb9", "0x257bDfB800C07acFc9750831E75c4c9e0BE8Fe54", "0x9D1F4C6b49aa614D6307C339a8Cf4BFA0dc81849", "0x7462f8E63F6B413AeF1D4FD06506Ab69dC1A2170", "0x048AE0e8BFc328661e143c9798cE27C8B4B0efA2", "0x399B1eb2987ccb8783f9387E7619AF48B729b6aA", "0xD01DB73E047855Efb414e6202098C4Be4Cd2423B", "0x90f57d90E3Cb4e122a008a80475927601FFf5783", "0x96CE925995Cd29Ac5760C444F4A07B284e9C1BF0", "0x77c0016feA4b7C41CB7867518f23A5Cde66F8cD4", "0xF17BA07F65Cb14F737E81deE964031b28C445687", "0xf7C716d6B97C69E22824F6Ad2943ccDc67389ee2", "0xf1F8061ab5687c53105C35202774539e361c2D28", "0x50a99c1C57Ef5BaF995D85E508991DC95Aacb45B", "0xe1C612Ae55A7eF83AB320ABC046ff662512b6d35", "0x7B5bbeac048C7B9a5d6E5f73809Fc93AE4b8e448", "0x628594DBF68bAB097D6753e8e2c7E465722FDc8f", "0x46ea7e8d263373F38F5D32621212f43736023926", "0x507C667059FCCebC14ba35cf3D8f5bbaE2E3f0De", "0x54E3B90aD561056ccEE8Ebb82101C66d60bC9EBF", "0x37a43C49a95B5a633D0Fe5b420d8f278C2F30efd", "0x998aedac3DAA201838297F5bb6CE1A22CA478b65", "0xB86f547fabd32315bc8929Ea19E4AD985BF27adF", "0xB79bc3dcb775dD74B55CDC22E0aCfE9b91Ed4C33", "0x4869BA113321343F3bC47Ea2cE7Ae119C39CB7E7", "0x54583F06AeaF5C9178CD59D36E3dA0601Dcef5Ad", "0xe8828F971767bDdcc117973BA56Ee27001d2DDF7", "0xeb834eede5Ba33401E82f3f3ee1ff325574f2B39", "0xADAe7914A367F0190E98749bAF4672B0A85Dc98b", "0xe033126833Eb6C9DED524e8147F85dE62B74B604", "0xDfF10dcdc1c95a2D04949892fB4Aa4d5693744d1", "0x18911D15278F29d515b35aa0fd6B2312E6E3Fe08", "0x47331edc7220ad93D62130CE64c10F7166F4c947", "0x56E97d246b9F1635D78B0eF176Af06929a4EC114", "0xCf37fDbF8B931bb74b3A0896BEe2D4a98183dfC9", "0x0903D864766a81d2c8385d5Cf15Ec475E021AAfC", "0x39De91Bf474F5F0945Ac19B075FF8deE73c56141", "0x2968f22297c171496DDe77f2b148AaB5aD41feC4", "0xb0F559f121f97aBFC64Fbef0E57dE65A0EF244A3", "0x8A5cEEA0F749aA02592269AF3Db4C46d69b9443a", "0xE4350f5d75147228FBc9cd57D6e009C617127e9F", "0xBC2d6d9928823411E612EE9D98E638173dFe3b4F", "0xfa24AbD494fEB93e391A0382ffBfC061e82659E9", "0x0598fbcFd61a5A7bd258Bf62ffe7f75929fd1a5D", "0x15DBF5647C1480A6796FD8616bEb0E2E6B848bB1", "0x4F0Ee972f7fCed8989C4D323aadeF6928Db1A4ba", "0x7c8a7d7c829D698e297a789463C27559d476d620", "0x21812ea488c35eA4eBd858c92409a312dE02B45e", "0xF945f03f0be48bA513f268C69CE0BFfD768Ce000", "0xfe1ADFa5d31d3F7da12465d1A56823Cd68C03188", "0x0c67b02f922635D1B7Ee31C8d82aeF0Bd5f1AF9c", "0xa51E43C4a93E072Ba7400B9a4a96cf12DEa7c393", "0x420D64264f5893aBdEf473e39254dA4DFDd1b16B", "0xD6f7c94c8e82C7E2e1234c636D509d9065B1c36f", "0x4B6979e29CFBF9eaA59088f6193A7Bf75cE6ca43", "0x7b71595A0ceD80C6039f2Ba34504cE7D619b6F00", "0x1Aa1bcd827e576C35F1906b4abbc130EAF09622F", "0x1Dc121941c9b987F9cbC94E9102798F5a0Bca922", "0x0123060A82150cAE03318e464d27dFaFDFd675D0", "0x99C05254937f7B39730292183d7e3e1E696eEa80", "0x7FD3cDC63cf777cB2fba5ebD9c552363fc46b7Bb", "0x9110194965796d58A11d0148dE2B29237791159d", "0x97b193319Ab0C3FE40aa639CaDD2591AEeff8471", "0x55f47ed98dF95aB917e134444a73577372944fBB", "0x4031DFdDaF163Ac762EB449B32C365E98F97271a", "0x71CA13248bA333FFE5bc222d1ebd4c9B4196321b", "0x31876009c2A99e6AbcF7DF9599CA168d5202B127", "0x2D63a088A9205eCAf39e89E9C4B584ebe586f23d", "0x7eD512e3D7914d20eb7972AB7fb831A022e968a6", "0x3dEC676871158170ddbd7090A69821c23472DfD0", "0x4edCE1E4620b26E77D4B817C6323567a73dE8505", "0x1F24EE6c1F5A352Ded88EC390237f573f4882907", "0xF0d366E5Cd5BDcF08e9CB80e9b181e7bDb97978B", "0xDe626A5cfFF9B7EfB38e3cA3354dBe83cEbbC49B", "0xF99A7F42066e891AE793a0f1ee3c865E9A61377e", "0x8556903A32E38cbb9dE5ADc83291Fc3e95d721f7", "0x4e1106607f6bed0177541c1EC3ff7EDe7D75dfB8", "0x5d967a9042713180b1eB39fE76ceDB43D04507B7", "0x9CBA037341E8703bAA015525DB99C0398fefBb77", "0xF75947aa09b03074491bF5bd2645927A3117ed12", "0xEaE973588c6800F510a5c781626Bdecc0A31B60d", "0x7547CBFa5F6c222F33379F407B17A76DC7B76B46", "0x4a0f45F23De70699Ab6bDeC5aaEf7955B0Afe6fD", "0x9a72C927EC61A74E6322Bfe466f0395D969D02A8", "0x8F9105569f04b74b5Ce52d0942D96A340B5e2526", "0x87c32b5a1697D367f06D58926bC5ce5EB8201F83", "0xaFb70F78895Feb5B9D9E26A59997A1EE7d68EFd5", "0x6ffE59CCA7B88Ad5d23e2fB7666860cA2135E4e8", "0x1829458c7DF7ee19e5dC240dFC9D2a4DDd30680D", "0xb60f9fbc25b2FBc448187A7B54d1CB9bdDb24868", "0x4C3257551382fA2C9429E4F914bcdf27947BCe68", "0xf995A24032Ce56128141F21fFB6483ba38Ce8835", "0x15037023E91b4a1Ba84e2d78a915b1b582ABfC72", "0x0dC05b755fEa7119700543695e6F5b11512DCe1a", "0x4Ada24eBb2f598D8bbe3e38FBf44D0fe5C871671", "0xB38287451324fFd920F363b4c3336dC768b15f2b", "0xEA917E28A855a5F29cb5317C80EB0215AA597F4E", "0x2fd689f803c861aaD46aD757360E07a69B2B67b7", "0xfC7d5e499f869D8ee0b17C61b0f6f83BbAC2FBc2", "0xb6a34Bd460f02241e80e031023ec20ce6FC310AE", "0x9C4c521204B9E03E6d6d50bb303ee3e2dCE8715c", "0x258D355b317010FabC10cA0E40e95e7918126656", "0x0437aaa252279B28a950C0b2Fae70a5d1Bb9897B", "0x145395622a74F85CCdbF1494fe9899A22F246c6c", "0xe15E50a82C319D3e5ACc7DeDe60912a2F50c2243", "0xc5d8356e6fF2693FB942bc9c78140D1E77381569", "0x8Ac6c962281122167b39DF6b5C0B2d479201b042", "0x5E448026D1275006b51f8E689Fd18aF84B691F54", "0xC091C0E3F3e45612330B23cc9B45E8b16e05d6b5", "0x246552074C2Dd8B239cB8b64f317c5Ee7aA62cF6", "0xfDe4cc6b5D0aE3127146EB98CF940569760842b2", "0xA58Cf935145B39A65dA6c86f1Ad926edCc30D130", "0xBe15B797ADDF9d90d40BC8c02827c0b984630387", "0xc98Df3Db909aBCe7DD287c6CCf7B6D97E867de6A", "0xefB47a2970386A75645F61D018E6f013c388F5e8", "0x7af4717Bb896aF5DE646D0440f331fE30A1DAD58", "0xC12d995C12705628bB2FA0288A7E051B5c564ED4", "0xd8e32c2011C0b6675D28a03372D4048e3ACA74FF", "0x509D8161f47d27B809797cE0E4F6A92235e6b772", "0xB08aF849F539A2f2B0B25E34c65dD509E91A1C95", "0xC51D55E3BA91B2C24f8A17E9dE099d9D76208CC8", "0xe26109CccF5319c23E58115fC21E0Ce7AeE085ab", "0xA2F57EE620EbdE9a5E84636a2e577a4a4DC99c06", "0xcd0dE9EC410D55b94Ac6D6c32F0DD242420D6F40", "0x8C341809D1D3E0d8c6D3C1127033F2ce4F48e1D6", "0xbcC7E71Ea1dfc94baA5352e179eA901f5A272e8D", "0x0dfD16E4094FA3895Ce11cA15F890b9Efb501478", "0xA0B8b814F2aB93f63A42E37ddcab994b5b21A29B", "0xc85306DB94659182BEc5B735Cd70824ee079E290", "0x5934DCB2D2D0C6F02E2b16fBd1b94Cd5D6E00559", "0x50481E60E1ed963302837e48badC1C077A5E6Fd5", "0xAE631A37Ad50Bf03e8028d0aE8ba041C70AC4C70", "0x05798EA9E10d9DCb16495f7A1ef93d5a6c733BdE", "0xC19412e413dfa68c7F74fb8C5af07E75887138F3", "0x842373a5C4559f3c6ba26804780c0E9a16f5eec5", "0x292264776e4D339f0cF4cC1aD1e1C94Db1e9b877", "0xAeAe7258e897d3027D872fA8ce401A0f714B015d", "0x60D488358411C52565339F3C5bB343B2f0A0Da28", "0xF12Fb47576d97A1227656a66d951d99ea79FDf34", "0xCe9412e6644E648c7DDe7D0fb70b1Bd24F2b4DC1", "0xfE0E21D6741378e7c2E0b6278981574459786635", "0xE65D7550a1619EC9c69658A787523bf8CC441Cb3", "0x021EAC92Ce7bAb8338a22845E78AD7aE0844BD12", "0x964DA88C5339b8cfBDc008f0337400FEef5e9894", "0xe3f0652433668a661748C4D4E4B7B77B15c34cfA", "0x8bBdf22Aae90a83fc2B9B7f2F1A4D780A4Ac2197", "0x64821173B8D721006ea140886403225E752B4c02", "0x3e03481Bf2735cC396C0dc91e86EDcb559262B76", "0x2f553Fe14819b07F142A6751c1fA326e0576119f", "0x7F15C2Ab437F7cC6C6c29f7f20D98A48D6D97907", "0xDbD3957808604c13cB52D71BCdf66Ce17255329E", "0xDdc85B17849E2907162e9ED534a01270d95fa886", "0x4EbC3C60f03C800d8435Fd9c183c6e0fc07Cc699", "0xB4893Fad20549f470005A108EeCeecBf0d6E075d", "0xb64353454723141F2cC64daE37f46f55981c03Cc", "0x9dC9987e883373916Dc08F3D0E6F07a726327aCf", "0x9AdCabB1535535aae61e503E2f883e80902a7ef1", "0x36fd363b456B7Aaf6A6aBB6b1049ff601F4A8529", "0x03E17CF1fC585AA0Cc9F5BC058629D79ccDE1869", "0xaF78E0C5ea7bF46Ef3cA977Ffa73A2ca8aA85E3e", "0x28f86F4346d83DcC1f9bE54e40D866Ee73057c54", "0x34F68fb168FBab42316BD83dd28C5fd3162cc1B1", "0x3961E1070BcF504d01D3278536CC55cF21e549Ae", "0x960416418b9f6946fc178095E5096066C6Db656b", "0x3802DDa14645De66EB3cC13c14f9bDB669d717Ba", "0xe5cC1A4eCC73671705BCBD099E4705DA4BAE1654", "0x393739c14b6fd3968Fb17EcE3562ad4889da087B", "0x0A28A926aE9a0C9D9423cC8bF0159a2fec5FC082", "0xAa51116A9DdC36754Fe8114C37EA9B7a80Bb53B7", "0x725B387FBAE38309a7538f3e25cA711AF8B91724", "0x5B6d1F120e54f1040f91e84b11016c1Ba1942cf2", "0x7624Ed59a74Ae74922E860f139b0E817d5075904", "0xC5Ae36e0800ECFc4e4C01ac6D8d9D0ddfA2cd180", "0x004535925130bdeA28473B3bE532fe9B24c2a984", "0x728Ad87D02a24C5454a047AE6e3C91C0a5a64e66", "0x6B2Af5066d33AFe71043D568694B0a8a5397bf09", "0xa17497c584116636903D1cFaD32DB95D87E3F67A", "0x9369710302Ea1F54849eb90D032C1963F2527999", "0xA603a8ed8CfDD6D1D1aE7805b606Ef8Cd62A269f", "0x59f5B392e7eFF58992E298f94aA355c36897557e", "0x735421c52e312de675e26295AC5426e86fC7A115", "0x9f11eBa694d633a715681f15b3F6C75b77F50A08", "0x0B03E8ff011f91468c0Da3a9486f73e779992ee1", "0x3111D2D44e5cFCDFDa3112af3ABA868Ccc6A4cAc", "0x4FB324B848F75a1e8467A7Fd5e57aD2F0Aa4f36a", "0x44B73d79835D319D766c733a3bD4588e81e2fe3C", "0xd7db82F6c8446A36486611A3b6CB5bB2d5028E4b", "0x8629Bf805749f90F00fbE7a390171D4bddE80e3C", "0x5dF37D232702ed5cE393f3cFf92406FE0C27bFd3", "0x9fE294605dC4DDd5222359307ddC764D1753A98d", "0x4DE7e57EE6a20D2Fe4b0C2d6bC7D866Fd436a940", "0x65F3Ac1D439cb08a7Be155C3B37581a63F0F3cAe", "0xB238a2d5e2B411637269aBE4d9fA117Db3fd86d0", "0x33A215C9c3d74385d97b878E854eE50bC5B916Eb", "0x8c0A0Ba507CE136c29EC050781Ee80697A06E3E9", "0x2E66d73AE7918a359a76486138c36e1d79A4AAB9", "0x69701d282Af2fcE1cc07445dB27d046c7cBbF323", "0x8682794D9509Ba171140D072a2276AC82De0704F", "0x4602c6fF42bBE2D315674A5dFBE4b794349eA0CC"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "maximalParticipationAmount", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "minimumParticipationAmount", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "startDate", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalTokenSupply", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "balances", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "cap", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "capReached", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "whiteListControllerAddress", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isFinalized", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "whiteListAddresses", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "endDate", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "maxAmountAddresses", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "bonusAddresses", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "hasEnded", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "tokensInWeiSold", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [], name: "Finalized", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "LogParticipation", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "LogTokenReceiver", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "LogTokenRemover", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Finalized()", "LogParticipation(address,uint256)", "LogTokenReceiver(address,uint256)", "LogTokenRemover(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x6823b073d48d6e3a7d385eeb601452d680e74bb46afe3255a7d778f3a9b17681", "0x87c849333123ec338107397b71001d77ec70480108d12660d2f0700e14aef3d7", "0xd668e654cf507e54774b25d068f320ada46152a56aebdefba13854ca58a7f9cf", "0xdff7990534ee26d271160e47a3a4976c37a1e41904bfdf62f8f114e1c3100797"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4451560 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4452152 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_wallet", value: 4}], name: "DatumTokenSale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "maximalParticipationAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maximalParticipationAmount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minimumParticipationAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimumParticipationAmount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startDate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startDate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalTokenSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalTokenSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balances", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balances(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cap", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cap()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "capReached", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "capReached()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "whiteListControllerAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whiteListControllerAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isFinalized", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isFinalized()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "whiteListAddresses", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whiteListAddresses(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "endDate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endDate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "maxAmountAddresses", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxAmountAddresses(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "bonusAddresses", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bonusAddresses(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "hasEnded", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "hasEnded()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensInWeiSold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensInWeiSold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "DatumTokenSale", function( accounts ) {

	it( "TEST: DatumTokenSale( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4451560", timeStamp: "1509279142", hash: "0xe69e671069fe0d30501c60056aed2f00c7c33a22716875802cc771facc77bc33", nonce: "12", blockHash: "0xabb1314517086367b92e8c5ed8338cf987317521de9a153cba56d1be770baa64", transactionIndex: "82", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: 0, value: "0", gas: "1621855", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x75e68bae000000000000000000000000a899df9e9cf14a7c5b87744b1edc6890a712cb97", contractAddress: "0xe6766297571f8693adec94e5f8ef363d323e211d", cumulativeGasUsed: "4525269", gasUsed: "1521855", confirmations: "3278361"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_wallet", value: addressList[4]}], name: "DatumTokenSale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = DatumTokenSale.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1509279142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = DatumTokenSale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setWhitelistControllerAddress( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4451883", timeStamp: "1509283774", hash: "0x4fcfe259be9e893d5c922935587423d23e84733e748746e7d3eb44fad25c5580", nonce: "14", blockHash: "0x938c5bff99bd02baaa280eb1b34f9b1202088768f0f4626a1acbd78164efdb16", transactionIndex: "7", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "434540", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x041257ef0000000000000000000000000079ef6b5d2777774afb5b74680c058b11ded77f", contractAddress: "", cumulativeGasUsed: "407154", gasUsed: "43454", confirmations: "3278038"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_controller", value: addressList[5]}], name: "setWhitelistControllerAddress", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setWhitelistControllerAddress(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1509283774 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setWhitelistControllerAddress( addressList[3] )", async function( ) {
		const txOriginal = {blockNumber: "4452009", timeStamp: "1509285551", hash: "0x06fa3752870580d848ebe6380ecfb11651c176c258bf0976659aeec0ad83ed67", nonce: "15", blockHash: "0x2c94d7218e2cf3fc333f94057552d760d87267f30a187516b12cd168dacf4614", transactionIndex: "6", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "28518", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x041257ef0000000000000000000000005ef33f97a8b716a11c40c74b5dab56d74d5e3c58", contractAddress: "", cumulativeGasUsed: "154518", gasUsed: "28518", confirmations: "3277912"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_controller", value: addressList[3]}], name: "setWhitelistControllerAddress", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setWhitelistControllerAddress(address)" ]( addressList[3], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1509285551 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddress( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "4452014", timeStamp: "1509285594", hash: "0xe85b5f1cfb81b8a6a121867d8e587c9142dc679beef408f42e268043b81aa595", nonce: "16", blockHash: "0xc883ecca89c9e0bab1084e6e049756cb0058e2e72ac790f3a2bcac3b64c533fb", transactionIndex: "1", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "43916", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x94a7ef15000000000000000000000000a28fb44e8b73a20f88c9cf1bacbe4f1cc038d9e1", contractAddress: "", cumulativeGasUsed: "64916", gasUsed: "43916", confirmations: "3277907"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addressToAdd", value: addressList[6]}], name: "addWhitelistAddress", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddress(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1509285594 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddress( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "4452016", timeStamp: "1509285618", hash: "0xd73ab3c21800f30a0de72ebc7356dcc1bce2d7ad3d33b9d7f759aad62c0ba4b7", nonce: "17", blockHash: "0x02ce1d0fe088fc5a14f4195045b4ac3303b6be1d81aa434cc932939ad2e13f76", transactionIndex: "10", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "243916", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x94a7ef15000000000000000000000000a28fb44e8b73a20f88c9cf1bacbe4f1cc038d9e1", contractAddress: "", cumulativeGasUsed: "313677", gasUsed: "28916", confirmations: "3277905"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addressToAdd", value: addressList[6]}], name: "addWhitelistAddress", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddress(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1509285618 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4452021", timeStamp: "1509285668", hash: "0x490b12ff6709130bbe9f6fbe3b97df5405ee75e031d7c123077a0defd145df88", nonce: "68", blockHash: "0x0f9606423c77a82715935c8b21d0adda364078fb205c3783ccb7322d9be338a6", transactionIndex: "35", from: "0xa28fb44e8b73a20f88c9cf1bacbe4f1cc038d9e1", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "300000000000000000", gas: "100522", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1108204", gasUsed: "98282", confirmations: "3277900"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1509285668 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "LogParticipation", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogParticipation", events: [{name: "sender", type: "address", value: "0xa28fb44e8b73a20f88c9cf1bacbe4f1cc038d9e1"}, {name: "value", type: "uint256", value: "300000000000000000"}], address: "0xe6766297571f8693adec94e5f8ef363d323e211d"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "LogTokenReceiver", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokenReceiver", events: [{name: "sender", type: "address", value: "0xa28fb44e8b73a20f88c9cf1bacbe4f1cc038d9e1"}, {name: "value", type: "uint256", value: "8625000000000000000000"}], address: "0xe6766297571f8693adec94e5f8ef363d323e211d"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddress( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4452028", timeStamp: "1509285786", hash: "0x19c581500708054c099330e29593acd033c166b2303e2fc4ae279567ac3a94e9", nonce: "18", blockHash: "0x7852e61750e2ebf607bd81d25edaf55e126de87f9e1d625caa40366fd69d6442", transactionIndex: "11", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "43916", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x94a7ef15000000000000000000000000e9f2e452e4f6ef755035b1a0a73a67f104846127", contractAddress: "", cumulativeGasUsed: "792518", gasUsed: "43916", confirmations: "3277893"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addressToAdd", value: addressList[7]}], name: "addWhitelistAddress", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddress(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1509285786 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddress( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "4452036", timeStamp: "1509285968", hash: "0xba1f1388a9b56137626a8937a567b0e5df834559e63cd22a855525df515284bd", nonce: "19", blockHash: "0x58edcc040f23cc17ca967ad93d0465dbc3b30562375a7744de3bd44625850590", transactionIndex: "15", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "43916", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x94a7ef15000000000000000000000000ccd17ad819c4c71f41e31157eb316b4a843ef0be", contractAddress: "", cumulativeGasUsed: "621977", gasUsed: "43916", confirmations: "3277885"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addressToAdd", value: addressList[8]}], name: "addWhitelistAddress", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddress(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1509285968 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddress( addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "4452041", timeStamp: "1509286008", hash: "0x850b5c21f4e1b841b45f7e0cc76aa0e22d2abdd1201aa9f95f4472992c510fd5", nonce: "20", blockHash: "0x2cb7d06310f3fbd3ef7e718c250673dcc8d88e2b0df1a50d1c1b9c123002c2d7", transactionIndex: "15", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "43916", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x94a7ef15000000000000000000000000e73ceec12abcb039b99c9e06900c8c4517fd592c", contractAddress: "", cumulativeGasUsed: "725919", gasUsed: "43916", confirmations: "3277880"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addressToAdd", value: addressList[9]}], name: "addWhitelistAddress", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddress(address)" ]( addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1509286008 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddress( addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "4452042", timeStamp: "1509286028", hash: "0x2b02b35f501c0f691a4ce85fbdaf403de909b2021d104704445202095a678f55", nonce: "21", blockHash: "0x8e3b0a4dceae7b61484906677b1a5082f85472c53a8fea86c6627fe74ec49a90", transactionIndex: "26", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "43852", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x94a7ef150000000000000000000000007c6998f6ababb97199ecf4672e00710dac0d2e4c", contractAddress: "", cumulativeGasUsed: "1253286", gasUsed: "43852", confirmations: "3277879"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addressToAdd", value: addressList[10]}], name: "addWhitelistAddress", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddress(address)" ]( addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1509286028 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddress( addressList[11] )", async function( ) {
		const txOriginal = {blockNumber: "4452042", timeStamp: "1509286028", hash: "0x58a257f5b5d32b45ae7847c5590cf17126703ee6b5e03cb638affdc67d1d95ad", nonce: "22", blockHash: "0x8e3b0a4dceae7b61484906677b1a5082f85472c53a8fea86c6627fe74ec49a90", transactionIndex: "27", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "43916", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x94a7ef15000000000000000000000000fdabafbfbe0c4e238b863bffcbd98d3bf6c7ff10", contractAddress: "", cumulativeGasUsed: "1297202", gasUsed: "43916", confirmations: "3277879"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addressToAdd", value: addressList[11]}], name: "addWhitelistAddress", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddress(address)" ]( addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1509286028 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddress( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "4452045", timeStamp: "1509286096", hash: "0x137fcfd406588de0f691aebba2a494c9a1c6d0700612770361348c530a58d1bc", nonce: "23", blockHash: "0x8c11c6199bb2f3d2afc95a7904ad1495404ab8dc1558ab848bb53c41d98ea7c0", transactionIndex: "26", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "43916", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x94a7ef150000000000000000000000007713bc05e727cee0ca62861d4cbf42a5e8bbc211", contractAddress: "", cumulativeGasUsed: "1782188", gasUsed: "43916", confirmations: "3277876"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addressToAdd", value: addressList[12]}], name: "addWhitelistAddress", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddress(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1509286096 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddress( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "4452047", timeStamp: "1509286115", hash: "0xb1668cbb2559115804152a317d57486989debfb18727c4a3ba95d994f6f8ff6d", nonce: "24", blockHash: "0xcc445d7b2cf5469f67a58c38368e5b0175badc30caf8ea4b6514d80166e0458d", transactionIndex: "3", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "43916", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x94a7ef15000000000000000000000000571795cbbb3243b3923ab1eb4487215397d099b2", contractAddress: "", cumulativeGasUsed: "109808", gasUsed: "43916", confirmations: "3277874"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addressToAdd", value: addressList[13]}], name: "addWhitelistAddress", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddress(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1509286115 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddress( addressList[14] )", async function( ) {
		const txOriginal = {blockNumber: "4452047", timeStamp: "1509286115", hash: "0xb575e3c6cce45ffde7f65b816622a02f3cf298e01593fedc39190fd369103243", nonce: "25", blockHash: "0xcc445d7b2cf5469f67a58c38368e5b0175badc30caf8ea4b6514d80166e0458d", transactionIndex: "76", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "43916", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x94a7ef1500000000000000000000000015b2719a55e840e84da704100ddba2675aaf1005", contractAddress: "", cumulativeGasUsed: "4232426", gasUsed: "43916", confirmations: "3277874"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_addressToAdd", value: addressList[14]}], name: "addWhitelistAddress", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddress(address)" ]( addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1509286115 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[15],addressList[16]] )", async function( ) {
		const txOriginal = {blockNumber: "4452047", timeStamp: "1509286115", hash: "0x4e01ba870038f547b24575e6fa704bcbf12da31d0a4d84bf3f97438b1cb11882", nonce: "26", blockHash: "0xcc445d7b2cf5469f67a58c38368e5b0175badc30caf8ea4b6514d80166e0458d", transactionIndex: "91", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "66304", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000200000000000000000000000027538f05395b500170294400745cb190096e277e000000000000000000000000c094c22fad02dfafeb45123b40e1bb5b5941c291", contractAddress: "", cumulativeGasUsed: "5507686", gasUsed: "66304", confirmations: "3277874"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[15],addressList[16]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[15],addressList[16]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1509286115 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[17],addressList[18],address... )", async function( ) {
		const txOriginal = {blockNumber: "4452056", timeStamp: "1509286212", hash: "0x68ad11f348da9a17445cd3235cafe7c9bd5384d17dbdf363e3045a687677858d", nonce: "27", blockHash: "0x9665cbe3c94b5cebe6819d463f567190227082c440fd7f34ea60821caec8e99c", transactionIndex: "5", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "285538", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000cf1bcbb30ca47b37754081e43360e783117c2e4a0000000000000000000000002c38d21f510ec901f39a4ac7d0f834b20ef2fa680000000000000000000000005759061de128ef83517cebe1cfcf3703fea4cfbd000000000000000000000000d3f9f45908965e0a58822e77f0568a148cc3efac0000000000000000000000005cca1dd2dcb143d5f99588eff59748bcc5946f3e000000000000000000000000a2861b88ad53a9f056402c36a8c63f72c8bc0eb3000000000000000000000000914af8e4438359dbac232d9e6051cc6762ae930c00000000000000000000000023df1074ab69d313a18c95cc4129d5cff4ba6408000000000000000000000000fe733aca9fcc9024bf6e12bd345835950b4ef08300000000000000000000000080641bcba5a3951d7e01e04faab26b414fbad1620000000000000000000000006243c3c6172d9758dccdcfa40dfb3c888b615a64000000000000000000000000b2c3c27bf78ab22e116172036aa38f5ad80ed937", contractAddress: "", cumulativeGasUsed: "546417", gasUsed: "285538", confirmations: "3277865"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1509286212 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[29],addressList[30],address... )", async function( ) {
		const txOriginal = {blockNumber: "4452067", timeStamp: "1509286318", hash: "0xeb85fef4fb32096540d515cf785aa91428b86abf2814d3d82a70c09450b55076", nonce: "28", blockHash: "0xb89feeb24f91a8d6aa684ab65bf6a73363688a16e580c0a40d4c5714d0e593fc", transactionIndex: "12", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "263493", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000005d5d643ef1446b81cd8fc658deb918da540bdd230000000000000000000000009300909a77e765872022e7db5dfceb1330c836fb000000000000000000000000d2e89790abacc3412ce328dee4a64007948f7c7e000000000000000000000000228a2e2b2fe39695940ec3cdc06e95208693c37b0000000000000000000000001c1bb5915cec7da52985a2765519fc23483c93b00000000000000000000000006da5960902f6c6804f11b30e59594f8cbaa1718f0000000000000000000000007bff82c27fa7ad2e04beb543404808599f90cd10000000000000000000000000ae3c3eb95b5f65bad910f35300eb67b5321e87af000000000000000000000000cee95733fb63ae1a4d397b2eefe701817c23694c000000000000000000000000ded9d129c2a0c45a6be4b5fd961235091721fb510000000000000000000000006d70b72c0455991a839b93923feb9cd9fed9e545", contractAddress: "", cumulativeGasUsed: "737256", gasUsed: "263493", confirmations: "3277854"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1509286318 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[40],addressList[41],address... )", async function( ) {
		const txOriginal = {blockNumber: "4452069", timeStamp: "1509286342", hash: "0x50b04c8073dc55feeb4629662da0f934b71126d27fe27f4839c34f3b6cad6c7e", nonce: "29", blockHash: "0xa764f366d3c924b77b561f9daa37a69e9cf0dea2ca5acf584bac94662baef97a", transactionIndex: "10", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "241704", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000002d5edf44cec2b2ec5b3a062fda53f53391fd2bf2000000000000000000000000fbb1b73c4f0bda4f67dca266ce6ef42f520fbb98000000000000000000000000e68a452cadbfa2d7f87960fa837d54fee0614938000000000000000000000000a46a69569b4d86dab047142a6ad657893dac287e0000000000000000000000006fb6eae7f83eb2d2ce86db33a73e78983a5a06930000000000000000000000001b1774f3749d8efa524591c125c0c8349cf782f400000000000000000000000082f298e25cac12f712e2047fc08c59fee7c322c7000000000000000000000000999dee64b75209243c0be481d454d1ec72418ef8000000000000000000000000ad27dd6ba4c56ac93d3c02a767b69beb98190255000000000000000000000000050cbbcce5bc7d4e7831e9136dd54151609bb7ce", contractAddress: "", cumulativeGasUsed: "666334", gasUsed: "241704", confirmations: "3277852"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1509286342 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[50],addressList[51],address... )", async function( ) {
		const txOriginal = {blockNumber: "4452075", timeStamp: "1509286412", hash: "0x7a7bceda8851e7192bcc0826dc1c5ae045500df48be8d0e121aa07201830f5cd", nonce: "30", blockHash: "0x4f6a279efa70645131ac67faa22036db6b7999d6222b8d5103ece07a0bf3cf50", transactionIndex: "17", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "219723", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000009000000000000000000000000c49325c65ecc701198874b5516924c6cd165776600000000000000000000000000d357cc58fde175760c2689c1e050f75b46c26a0000000000000000000000006e3c904a2db3b5efc7b619257d5127f39ca2653e00000000000000000000000012f8f25bbcdb6e99f7ba957989f62f9a22a9bab00000000000000000000000006817108ecf2bf2842f49cbbd7d7647e48575123b000000000000000000000000f5f1216d72321afe6d2a053f163145a349e1329e000000000000000000000000d1dde7728264bf5bf14d01dbe768cbfa9cb8c87a0000000000000000000000008c3c524a2be451a670183ee4a2415f0d64a8f1ae000000000000000000000000d02a135627224cab666bdde27b36b6c6d09c7323", contractAddress: "", cumulativeGasUsed: "806741", gasUsed: "219723", confirmations: "3277846"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1509286412 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[59],addressList[60],address... )", async function( ) {
		const txOriginal = {blockNumber: "4452076", timeStamp: "1509286429", hash: "0x124ca491756a88300d415f0f760ebd16f462246a6ffa2dcaa55b3ae539eae806", nonce: "31", blockHash: "0xed80aca95a4ee006a4e37d904e3a181d945ee8e6d06e57f38d8e359277b23b39", transactionIndex: "8", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "241640", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000ddc3285dcfaada9895448dbe732ad335f54240000000000000000000000000d2a2401109c63884a8b27fca99ee63c07a8d51c60000000000000000000000002f2ff938ed348da2bac284f6f6fcb1f06a71ff8e00000000000000000000000017ecd0545d46ea2768ea3f987f0b8a4651b357c2000000000000000000000000468dbc8796faabd8303911474c7e06c42776e86700000000000000000000000060f1c5d41c1931e77cf0f5fcc4a1f3c94bdafb28000000000000000000000000a0fdb50236135d9f6cb2cb43656dd55a1d2a6878000000000000000000000000ca766aeaa877d3941768ef4c27efaa8d3fdcbbfc0000000000000000000000004c23aff782883b78ee394c56efe673e540c224a7000000000000000000000000e614a4fb56a1e803b9b83d8444c047f3ff524ac3", contractAddress: "", cumulativeGasUsed: "506718", gasUsed: "241640", confirmations: "3277845"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1509286429 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[69],addressList[70],address... )", async function( ) {
		const txOriginal = {blockNumber: "4452078", timeStamp: "1509286475", hash: "0x3706494ae344cc23bb48da37c445e588fe3efe60368c628b1d485b9c6afcb5b6", nonce: "32", blockHash: "0x186080ca8a8c3d6ff96eaf902bfd1138fdb2e5890d2731bb434d690b9281d73c", transactionIndex: "107", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "263621", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000034a96b68e1b3fd3ea52ca6f485bd94d2471b0c2e00000000000000000000000073a1c1088801e25fc7e9ba63c962952ae3eda69300000000000000000000000054715b6451a6aed81bdeef4605e0ee5136d4ff80000000000000000000000000c03fde71fb2c0cd93c79a7a164d58ccf430412d3000000000000000000000000b0ee9b83f268e40dc31cc6eb0c9abd3420103aa10000000000000000000000009619d11cfd728df2e062281f06a3356e9e233ff0000000000000000000000000bff8f97c2fa01f8ebf301f816f74c576136a4c66000000000000000000000000ea5c5e91d45aa47f7da9410cef6de56326329f530000000000000000000000002edda2a41cde3d88fa031163afdd881f8ddf7d76000000000000000000000000487835b9a2b5ab6de973bbe71f936d9856b7948f000000000000000000000000e3049a11c843d4f3d2a1efcaec1f33342c56fdb8", contractAddress: "", cumulativeGasUsed: "4457610", gasUsed: "263621", confirmations: "3277843"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1509286475 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[80],addressList[81],address... )", async function( ) {
		const txOriginal = {blockNumber: "4452081", timeStamp: "1509286502", hash: "0x9dc949ca0d90772a6322fd977ab483b5330fa83bb799375e4f15dcb12cee2c47", nonce: "33", blockHash: "0xe4f87e57113bc7ad48621942917a81b97f8dce31712f1f7f0d1ea941e6f2547a", transactionIndex: "13", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "307391", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000a0ad5e0e8fc86a8440992ad57b201fadefbaf595000000000000000000000000c182d6d7506b7756e0474ea27451cab46fd73f5a0000000000000000000000005c44f3dd2bf7f49e99b79faeebe770124aaad23c000000000000000000000000a90a03e6771770c13b9d980a6643a131048e342a000000000000000000000000dd69ac836b4c1856290696a2c89f2503781ed11c0000000000000000000000005051cb2f363eafe2fdd8cc32bccf742016ee72850000000000000000000000005f4168892f9e697dbe18e6d1d4515dac056252b50000000000000000000000008bfb25aae90465657e473815de66625187434ae00000000000000000000000004d798448f76cb8dab81622d10092c38e1146856200000000000000000000000048b11cb3d442f094ceaa97f3c7012a2624bbfd0900000000000000000000000008992d34f13a137114058fef51b47b1ad5247231000000000000000000000000b9b72cf937d9fa0f70f4e1a8e3f166c52897b7360000000000000000000000000389272aa1c642f1b051728f48b8ead262613eaa", contractAddress: "", cumulativeGasUsed: "952238", gasUsed: "307391", confirmations: "3277840"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1509286502 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[93],addressList[94],address... )", async function( ) {
		const txOriginal = {blockNumber: "4452084", timeStamp: "1509286525", hash: "0x6f2cf176082778b416b9d693c0fb94d1c17e7125cca02c0ce3a830e222f9b56b", nonce: "34", blockHash: "0x39098657e09d6e84cb38b4bbad32c43439c730b2e35db7edf8eb11cc27980723", transactionIndex: "3", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "241576", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000018e8a4e614f98fa24b1c2e2f2bf97f5737e3f4700000000000000000000000001a1691ea98e647fd348fa2fd8a9b44abe947a07000000000000000000000000cf10b94a99a1a6dce62f7fb708c860edc530f0f40000000000000000000000000d80b358953cb93dd76027354146e9e23bdfff37000000000000000000000000e79075d6a584e386e3dfb9c1aad506af1f46d06d0000000000000000000000001dfbf8fd08d154459cfef56a5daa348fb20052c1000000000000000000000000deeb8431db02b14273b930bda8ecbe1336c2c5e00000000000000000000000000554c53c3e9d959ed278e3bc085d42ae9bfde7c5000000000000000000000000007ca5c1afdce9618c0bb7d86c2e1699fe9355810000000000000000000000001af4a58af447639563bc9a420981d6ff7a785d6d", contractAddress: "", cumulativeGasUsed: "320291", gasUsed: "241576", confirmations: "3277837"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1509286525 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[103],addressList[104],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452090", timeStamp: "1509286574", hash: "0xa05d9945ae699ab81dcc4bfadc9ba831be6dac457f598a820e6622868467d9ba", nonce: "35", blockHash: "0xbef8f58bd35e79f11091312ac683729911a86e071aad4bb06ead8d36eaaf0e9d", transactionIndex: "5", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "285410", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000dcde00e24e44d0291c656d7ad16465289365ca0300000000000000000000000089d0790090d0e79bc1b16a3b7727aab394b3856100000000000000000000000014462b5ce639c3d381e6fd6f03af358a8cd0741b000000000000000000000000be19febdf5a1273d0bd3c6a13acab4e5a434991a00000000000000000000000031ecd2b8d55b4a9a1f587cb90146f35e1c579a6b0000000000000000000000005c91364f0a6c4d0e869cb24ff012bb87c08218b400000000000000000000000057e81f0a76781382a36984b0e23b4d551c163bdd00000000000000000000000079685f2f4c74ceac40508affbcdcc1194a0ed1c7000000000000000000000000823355b7323b70ec9b881e0541fc8b96055e7193000000000000000000000000537a649915b7866c978a4dd4afb5bc7f5e4155be000000000000000000000000eacac102b636e38b55fbae52c50ee3677b51ca84000000000000000000000000d26510d553e5bc9fdda01c52d112c92dd2d55d4b", contractAddress: "", cumulativeGasUsed: "390410", gasUsed: "285410", confirmations: "3277831"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1509286574 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[115],addressList[116],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452094", timeStamp: "1509286605", hash: "0x60394876031fc4aafe10f9f573dca79c717ecf287b1e8ebb49e25d36149ed1e1", nonce: "36", blockHash: "0x5dfb1a08dc631f00fcb1d7f95298be1e618c1e8983ce6397bc429d4ddd132fc2", transactionIndex: "3", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "241576", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000086f8c74454ff8e1e7e7986bcf267d4167ee44320000000000000000000000000f2311e976a1f3c256d8abdfb52f87c897e7e04c0000000000000000000000000e8bcc0fc7421ce248e88a191128ad8169fdc25e900000000000000000000000072a9cc244f2d36da1f89748d64fa33b9f7e973b4000000000000000000000000f44197864722e4e300a89624480d275ec29883830000000000000000000000005ceaede33080851deba28041b9ab18087f83fa120000000000000000000000007f17a62bd78014db9569bf20c7eefcc25e3d0aa5000000000000000000000000f1df86e8b7c68835f35bf215eb2a464ce0397c2e0000000000000000000000004a9c8c0ebc2eaab9b9674e9202a0fbbaab2e882b000000000000000000000000ac3e926028fd002446e1e8781d3d0745aa465d70", contractAddress: "", cumulativeGasUsed: "323088", gasUsed: "241576", confirmations: "3277827"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1509286605 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[125],addressList[126],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452096", timeStamp: "1509286635", hash: "0x84a8de2e33fdb7dcb7e0ecef340eeff8bdc6ea6f46c4eac8c0ec6de32827f612", nonce: "37", blockHash: "0x87426c8630869989daf34b61fc7676fd86ae3d9c7e4c889fefad8023fc8259b2", transactionIndex: "51", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "219787", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000900000000000000000000000054fc433e95549e68fa362eb85c235177d94a87450000000000000000000000003467665e6915f14c73c2818eedf96935162549c5000000000000000000000000c74324d50cc6fd8c6d2f04238a82ea6e5652de5700000000000000000000000072eac7a456606010fbdadb793c83f767f9c94bf80000000000000000000000000f424f1a7a05772f30bb034726068275f88776c9000000000000000000000000d4c6073d0e586ac4729dc18539fd0ea534c1dfc90000000000000000000000003ea0b8a0e240bbbba77b5f5e855bd9a58090cedc00000000000000000000000079aa26e907fa4c0b01f96365b8f0efff3bc1af830000000000000000000000005c5acccba3f32ae66bff15d2ba252091c731bcba", contractAddress: "", cumulativeGasUsed: "1760644", gasUsed: "219787", confirmations: "3277825"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1509286635 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[134],addressList[135],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452098", timeStamp: "1509286661", hash: "0xe6c10f4f9a9f047d11f8d6626c53d297f7a9632b2af39ccf7fc9407a2e7dbdec", nonce: "38", blockHash: "0x585ae93ccf024d51e8549dd92b763230fba35f94e4ee8beb02d7b89564c9c180", transactionIndex: "32", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "197870", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000008000000000000000000000000cba20f1f55afc27b977f740c7fa0f1916a4fa023000000000000000000000000dfd38cfebcd556c1e28bf15f66c55246db6b65d6000000000000000000000000a4e88e89d15bf0cb81833235b276cdd3f88bb7f60000000000000000000000007625df361070954b0d32d7600bf37a18bf8e0f9c0000000000000000000000002ef9d5d059b5f88e3595b25f3fa49fc2cf2fda38000000000000000000000000bfffc4ca4a430b8df71d06724138ee3b210328ae000000000000000000000000557a9d49daa4eac52e6c2eafd2813789c194750d000000000000000000000000f962e1e7ecf9baab6f88933a20469729b353c59a", contractAddress: "", cumulativeGasUsed: "1177844", gasUsed: "197870", confirmations: "3277823"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1509286661 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[142],addressList[143],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452102", timeStamp: "1509286727", hash: "0x321c7ae08902d6cceac87ce5600b86f5c367bd3659d0f23eec3712136941b533", nonce: "39", blockHash: "0x857aba93995135a46417d3550d62e342ce7bfac64e0749f07257ce4c445146d6", transactionIndex: "22", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "219659", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000009000000000000000000000000e0d9f6a0be3d378dd2773c5b119ad27160f961340000000000000000000000001956fba58840de3440b358ad8828b7f33acb6cb9000000000000000000000000257bdfb800c07acfc9750831e75c4c9e0be8fe540000000000000000000000009d1f4c6b49aa614d6307c339a8cf4bfa0dc818490000000000000000000000007462f8e63f6b413aef1d4fd06506ab69dc1a2170000000000000000000000000048ae0e8bfc328661e143c9798ce27c8b4b0efa2000000000000000000000000399b1eb2987ccb8783f9387e7619af48b729b6aa000000000000000000000000d01db73e047855efb414e6202098c4be4cd2423b00000000000000000000000090f57d90e3cb4e122a008a80475927601fff5783", contractAddress: "", cumulativeGasUsed: "1217373", gasUsed: "219659", confirmations: "3277819"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1509286727 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[151],addressList[152],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452102", timeStamp: "1509286727", hash: "0xe02792cef3b939302c7bb88e39abffb7e7334300e8331c3f211f4fae47e69edc", nonce: "40", blockHash: "0x857aba93995135a46417d3550d62e342ce7bfac64e0749f07257ce4c445146d6", transactionIndex: "23", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "263621", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000096ce925995cd29ac5760c444f4a07b284e9c1bf000000000000000000000000077c0016fea4b7c41cb7867518f23a5cde66f8cd4000000000000000000000000f17ba07f65cb14f737e81dee964031b28c445687000000000000000000000000f7c716d6b97c69e22824f6ad2943ccdc67389ee2000000000000000000000000f1f8061ab5687c53105c35202774539e361c2d2800000000000000000000000050a99c1c57ef5baf995d85e508991dc95aacb45b000000000000000000000000e1c612ae55a7ef83ab320abc046ff662512b6d350000000000000000000000007b5bbeac048c7b9a5d6e5f73809fc93ae4b8e448000000000000000000000000628594dbf68bab097d6753e8e2c7e465722fdc8f00000000000000000000000046ea7e8d263373f38f5d32621212f43736023926000000000000000000000000507c667059fccebc14ba35cf3d8f5bbae2e3f0de", contractAddress: "", cumulativeGasUsed: "1480994", gasUsed: "263621", confirmations: "3277819"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1509286727 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[162],addressList[163],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452107", timeStamp: "1509286761", hash: "0xf6c9bac6c9f5d63be085436051e7ae74656c88896f6a76f0f0196660ba3a4949", nonce: "41", blockHash: "0x8e985af52a4065602ed9445cc90358d048688c650600dd11de09453e4ddb0f60", transactionIndex: "7", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "241704", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000054e3b90ad561056ccee8ebb82101c66d60bc9ebf00000000000000000000000037a43c49a95b5a633d0fe5b420d8f278c2f30efd000000000000000000000000998aedac3daa201838297f5bb6ce1a22ca478b65000000000000000000000000b86f547fabd32315bc8929ea19e4ad985bf27adf000000000000000000000000b79bc3dcb775dd74b55cdc22e0acfe9b91ed4c330000000000000000000000004869ba113321343f3bc47ea2ce7ae119c39cb7e700000000000000000000000054583f06aeaf5c9178cd59d36e3da0601dcef5ad000000000000000000000000e8828f971767bddcc117973ba56ee27001d2ddf7000000000000000000000000eb834eede5ba33401e82f3f3ee1ff325574f2b39000000000000000000000000adae7914a367f0190e98749baf4672b0a85dc98b", contractAddress: "", cumulativeGasUsed: "457559", gasUsed: "241704", confirmations: "3277814"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1509286761 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[41],addressList[172],addres... )", async function( ) {
		const txOriginal = {blockNumber: "4452115", timeStamp: "1509286834", hash: "0x06bc1f604f56c34bc4372b6cfcbdcffb167f8f12a131a8b5678d3784dfaf09d7", nonce: "42", blockHash: "0xd76226f1ded921fb6e5e72b1f46737f56fc243a612a1893a94bb7598d5c056ff", transactionIndex: "14", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "226704", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000fbb1b73c4f0bda4f67dca266ce6ef42f520fbb98000000000000000000000000e033126833eb6c9ded524e8147f85de62b74b604000000000000000000000000dff10dcdc1c95a2d04949892fb4aa4d5693744d100000000000000000000000018911d15278f29d515b35aa0fd6b2312e6e3fe0800000000000000000000000047331edc7220ad93d62130ce64c10f7166f4c94700000000000000000000000056e97d246b9f1635d78b0ef176af06929a4ec114000000000000000000000000cf37fdbf8b931bb74b3a0896bee2d4a98183dfc90000000000000000000000000903d864766a81d2c8385d5cf15ec475e021aafc00000000000000000000000039de91bf474f5f0945ac19b075ff8dee73c561410000000000000000000000002968f22297c171496dde77f2b148aab5ad41fec4", contractAddress: "", cumulativeGasUsed: "1305099", gasUsed: "226704", confirmations: "3277806"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[41],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[41],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1509286834 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[181],addressList[182],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452119", timeStamp: "1509286856", hash: "0xb574513256c37eb60ffd3854929368e46e04cfe8ed7a450ed70ea382b7ec1c1a", nonce: "43", blockHash: "0x330458be9f71f756794fd45513026a2fd801ae55486846fe50bafdcbd6ff9247", transactionIndex: "0", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "219787", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000009000000000000000000000000b0f559f121f97abfc64fbef0e57de65a0ef244a30000000000000000000000008a5ceea0f749aa02592269af3db4c46d69b9443a000000000000000000000000e4350f5d75147228fbc9cd57d6e009c617127e9f000000000000000000000000bc2d6d9928823411e612ee9d98e638173dfe3b4f000000000000000000000000fa24abd494feb93e391a0382ffbfc061e82659e90000000000000000000000000598fbcfd61a5a7bd258bf62ffe7f75929fd1a5d00000000000000000000000015dbf5647c1480a6796fd8616beb0e2e6b848bb10000000000000000000000004f0ee972f7fced8989c4d323aadef6928db1a4ba0000000000000000000000007c8a7d7c829d698e297a789463c27559d476d620", contractAddress: "", cumulativeGasUsed: "219787", gasUsed: "219787", confirmations: "3277802"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1509286856 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[190],addressList[191],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452121", timeStamp: "1509286919", hash: "0xcdef3599dc03062812abbe47922997e7b433c10f45b704c018a45e16af424abd", nonce: "44", blockHash: "0xc576b7851ef4841cdd0e994dd59af1c2a28b228ab07208907bee691200341cd7", transactionIndex: "6", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "285410", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000021812ea488c35ea4ebd858c92409a312de02b45e000000000000000000000000f945f03f0be48ba513f268c69ce0bffd768ce000000000000000000000000000fe1adfa5d31d3f7da12465d1a56823cd68c031880000000000000000000000000c67b02f922635d1b7ee31c8d82aef0bd5f1af9c000000000000000000000000a51e43c4a93e072ba7400b9a4a96cf12dea7c393000000000000000000000000420d64264f5893abdef473e39254da4dfdd1b16b000000000000000000000000d6f7c94c8e82c7e2e1234c636d509d9065b1c36f0000000000000000000000004b6979e29cfbf9eaa59088f6193a7bf75ce6ca430000000000000000000000007b71595a0ced80c6039f2ba34504ce7d619b6f000000000000000000000000001aa1bcd827e576c35f1906b4abbc130eaf09622f0000000000000000000000001dc121941c9b987f9cbc94e9102798f5a0bca9220000000000000000000000000123060a82150cae03318e464d27dfafdfd675d0", contractAddress: "", cumulativeGasUsed: "700435", gasUsed: "285410", confirmations: "3277800"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1509286919 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[202],addressList[203],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452122", timeStamp: "1509286926", hash: "0xd85c86a3e81c4369ff1c2b8d0ec63fe8119181488c69f13e4863ec2c23a545fb", nonce: "45", blockHash: "0x18b91bce5fca97853e3c8adcb250da3c083e2002999f6cba9aefc0dc1fe13bde", transactionIndex: "5", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "241704", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000099c05254937f7b39730292183d7e3e1e696eea800000000000000000000000007fd3cdc63cf777cb2fba5ebd9c552363fc46b7bb0000000000000000000000009110194965796d58a11d0148de2b29237791159d00000000000000000000000097b193319ab0c3fe40aa639cadd2591aeeff847100000000000000000000000055f47ed98df95ab917e134444a73577372944fbb0000000000000000000000004031dfddaf163ac762eb449b32c365e98f97271a00000000000000000000000071ca13248ba333ffe5bc222d1ebd4c9b4196321b00000000000000000000000031876009c2a99e6abcf7df9599ca168d5202b1270000000000000000000000002d63a088a9205ecaf39e89e9c4b584ebe586f23d0000000000000000000000007ed512e3d7914d20eb7972ab7fb831a022e968a6", contractAddress: "", cumulativeGasUsed: "363285", gasUsed: "241704", confirmations: "3277799"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210],addressList[211]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210],addressList[211]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1509286926 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[212],addressList[213],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452126", timeStamp: "1509286968", hash: "0x0ce9434028f140d2f5bc9262ad0e04a8464b4d5346a2e1073464a6df0b4e55c6", nonce: "46", blockHash: "0xe9aa597adde46116e82b6a4b20ab203244949a79a1f400b856889bad238fecb7", transactionIndex: "12", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "241704", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000003dec676871158170ddbd7090a69821c23472dfd00000000000000000000000004edce1e4620b26e77d4b817c6323567a73de85050000000000000000000000001f24ee6c1f5a352ded88ec390237f573f4882907000000000000000000000000f0d366e5cd5bdcf08e9cb80e9b181e7bdb97978b000000000000000000000000de626a5cfff9b7efb38e3ca3354dbe83cebbc49b000000000000000000000000f99a7f42066e891ae793a0f1ee3c865e9a61377e0000000000000000000000008556903a32e38cbb9de5adc83291fc3e95d721f70000000000000000000000004e1106607f6bed0177541c1ec3ff7ede7d75dfb80000000000000000000000005d967a9042713180b1eb39fe76cedb43d04507b70000000000000000000000009cba037341e8703baa015525db99c0398fefbb77", contractAddress: "", cumulativeGasUsed: "908804", gasUsed: "241704", confirmations: "3277795"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[212],addressList[213],addressList[214],addressList[215],addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[221]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[212],addressList[213],addressList[214],addressList[215],addressList[216],addressList[217],addressList[218],addressList[219],addressList[220],addressList[221]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1509286968 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[222],addressList[223],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452130", timeStamp: "1509287050", hash: "0xbf2f40de35438fb91ee56dd88fc73b5ad1da487e2e8e11141e10b81969f95f58", nonce: "47", blockHash: "0x3e7c692ed2eb5d6bfcaa4e9e2d419f4a89dba62da06f131d0b37f8e9fc3d4058", transactionIndex: "13", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "219723", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000009000000000000000000000000f75947aa09b03074491bf5bd2645927a3117ed12000000000000000000000000eae973588c6800f510a5c781626bdecc0a31b60d0000000000000000000000007547cbfa5f6c222f33379f407b17a76dc7b76b460000000000000000000000004a0f45f23de70699ab6bdec5aaef7955b0afe6fd0000000000000000000000009a72c927ec61a74e6322bfe466f0395d969d02a80000000000000000000000008f9105569f04b74b5ce52d0942d96a340b5e252600000000000000000000000087c32b5a1697d367f06d58926bc5ce5eb8201f83000000000000000000000000afb70f78895feb5b9d9e26a59997a1ee7d68efd50000000000000000000000006ffe59cca7b88ad5d23e2fb7666860ca2135e4e8", contractAddress: "", cumulativeGasUsed: "664627", gasUsed: "219723", confirmations: "3277791"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229],addressList[230]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[222],addressList[223],addressList[224],addressList[225],addressList[226],addressList[227],addressList[228],addressList[229],addressList[230]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1509287050 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[231],addressList[232],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452131", timeStamp: "1509287052", hash: "0xc2898a7a6e2da5fe2af91f277859314d21f2caa66c6a29ab5a87ff13c289be62", nonce: "48", blockHash: "0x0267fc9f562b1a71d450e8cea71d2ed097b42e4a354d4857e55e0cffe1ea1573", transactionIndex: "1", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "197870", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000080000000000000000000000001829458c7df7ee19e5dc240dfc9d2a4ddd30680d000000000000000000000000b60f9fbc25b2fbc448187a7b54d1cb9bddb248680000000000000000000000004c3257551382fa2c9429e4f914bcdf27947bce68000000000000000000000000f995a24032ce56128141f21ffb6483ba38ce883500000000000000000000000015037023e91b4a1ba84e2d78a915b1b582abfc720000000000000000000000000dc05b755fea7119700543695e6f5b11512dce1a0000000000000000000000004ada24ebb2f598d8bbe3e38fbf44d0fe5c871671000000000000000000000000b38287451324ffd920f363b4c3336dc768b15f2b", contractAddress: "", cumulativeGasUsed: "220211", gasUsed: "197870", confirmations: "3277790"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[231],addressList[232],addressList[233],addressList[234],addressList[235],addressList[236],addressList[237],addressList[238]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[231],addressList[232],addressList[233],addressList[234],addressList[235],addressList[236],addressList[237],addressList[238]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1509287052 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[239],addressList[240],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452131", timeStamp: "1509287052", hash: "0xa32ec324a56be2a5b672ae9a49c537db2db544e1b3a6365b09778d272844eb11", nonce: "49", blockHash: "0x0267fc9f562b1a71d450e8cea71d2ed097b42e4a354d4857e55e0cffe1ea1573", transactionIndex: "22", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "226704", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000ea917e28a855a5f29cb5317c80eb0215aa597f4e0000000000000000000000002fd689f803c861aad46ad757360e07a69b2b67b7000000000000000000000000fc7d5e499f869d8ee0b17c61b0f6f83bbac2fbc2000000000000000000000000048ae0e8bfc328661e143c9798ce27c8b4b0efa2000000000000000000000000b6a34bd460f02241e80e031023ec20ce6fc310ae0000000000000000000000009c4c521204b9e03e6d6d50bb303ee3e2dce8715c000000000000000000000000258d355b317010fabc10ca0e40e95e79181266560000000000000000000000000437aaa252279b28a950c0b2fae70a5d1bb9897b000000000000000000000000145395622a74f85ccdbf1494fe9899a22f246c6c000000000000000000000000e15e50a82c319d3e5acc7dede60912a2f50c2243", contractAddress: "", cumulativeGasUsed: "1498009", gasUsed: "226704", confirmations: "3277790"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[239],addressList[240],addressList[241],addressList[147],addressList[242],addressList[243],addressList[244],addressList[245],addressList[246],addressList[247]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[239],addressList[240],addressList[241],addressList[147],addressList[242],addressList[243],addressList[244],addressList[245],addressList[246],addressList[247]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1509287052 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[248],addressList[249],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452134", timeStamp: "1509287098", hash: "0x0aa1950ad02d8963279be1aac00aea173561cb35871ce2d6a68a8706e58f0772", nonce: "50", blockHash: "0xd4056876331cabe77ec33e36c32d50f8776fd007a241605b75c9c9ab58e533d8", transactionIndex: "4", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "219787", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000009000000000000000000000000c5d8356e6ff2693fb942bc9c78140d1e773815690000000000000000000000008ac6c962281122167b39df6b5c0b2d479201b0420000000000000000000000005e448026d1275006b51f8e689fd18af84b691f54000000000000000000000000c091c0e3f3e45612330b23cc9b45e8b16e05d6b5000000000000000000000000246552074c2dd8b239cb8b64f317c5ee7aa62cf6000000000000000000000000fde4cc6b5d0ae3127146eb98cf940569760842b2000000000000000000000000a58cf935145b39a65da6c86f1ad926edcc30d130000000000000000000000000be15b797addf9d90d40bc8c02827c0b984630387000000000000000000000000c98df3db909abce7dd287c6ccf7b6d97e867de6a", contractAddress: "", cumulativeGasUsed: "548622", gasUsed: "219787", confirmations: "3277787"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[248],addressList[249],addressList[250],addressList[251],addressList[252],addressList[253],addressList[254],addressList[255],addressList[256]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[248],addressList[249],addressList[250],addressList[251],addressList[252],addressList[253],addressList[254],addressList[255],addressList[256]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1509287098 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[257],addressList[258],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452139", timeStamp: "1509287151", hash: "0xb03bc2ad8f03095a9bec12a114c34baf6a6f44b2e4604726415876360523f3fc", nonce: "51", blockHash: "0x36586694c26f612c6bb5dfd2163d8c6eedd878db5751a37d018b976070e03ade", transactionIndex: "10", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "241704", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000efb47a2970386a75645f61d018e6f013c388f5e80000000000000000000000007af4717bb896af5de646d0440f331fe30a1dad58000000000000000000000000c12d995c12705628bb2fa0288a7e051b5c564ed4000000000000000000000000d8e32c2011c0b6675d28a03372d4048e3aca74ff000000000000000000000000509d8161f47d27b809797ce0e4f6a92235e6b772000000000000000000000000b08af849f539a2f2b0b25e34c65dd509e91a1c95000000000000000000000000c51d55e3ba91b2c24f8a17e9de099d9d76208cc8000000000000000000000000e26109cccf5319c23e58115fc21e0ce7aee085ab000000000000000000000000a2f57ee620ebde9a5e84636a2e577a4a4dc99c06000000000000000000000000cd0de9ec410d55b94ac6d6c32f0dd242420d6f40", contractAddress: "", cumulativeGasUsed: "708722", gasUsed: "241704", confirmations: "3277782"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[257],addressList[258],addressList[259],addressList[260],addressList[261],addressList[262],addressList[263],addressList[264],addressList[265],addressList[266]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[257],addressList[258],addressList[259],addressList[260],addressList[261],addressList[262],addressList[263],addressList[264],addressList[265],addressList[266]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1509287151 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[267],addressList[268],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452140", timeStamp: "1509287177", hash: "0x449153edb07d174f424c969be31d4028f20f1a243d804a51d5c411def7030cd6", nonce: "52", blockHash: "0xa1822990f26dd24805b4e305c42c3a963580d8e874d04d388f8321bfe437af79", transactionIndex: "7", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "263621", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000008c341809d1d3e0d8c6d3c1127033f2ce4f48e1d6000000000000000000000000bcc7e71ea1dfc94baa5352e179ea901f5a272e8d0000000000000000000000000dfd16e4094fa3895ce11ca15f890b9efb501478000000000000000000000000a0b8b814f2ab93f63a42e37ddcab994b5b21a29b000000000000000000000000c85306db94659182bec5b735cd70824ee079e2900000000000000000000000005934dcb2d2d0c6f02e2b16fbd1b94cd5d6e0055900000000000000000000000050481e60e1ed963302837e48badc1c077a5e6fd5000000000000000000000000ae631a37ad50bf03e8028d0ae8ba041c70ac4c7000000000000000000000000005798ea9e10d9dcb16495f7a1ef93d5a6c733bde000000000000000000000000c19412e413dfa68c7f74fb8c5af07e75887138f3000000000000000000000000842373a5c4559f3c6ba26804780c0e9a16f5eec5", contractAddress: "", cumulativeGasUsed: "774698", gasUsed: "263621", confirmations: "3277781"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[267],addressList[268],addressList[269],addressList[270],addressList[271],addressList[272],addressList[273],addressList[274],addressList[275],addressList[276],addressList[277]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[267],addressList[268],addressList[269],addressList[270],addressList[271],addressList[272],addressList[273],addressList[274],addressList[275],addressList[276],addressList[277]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1509287177 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[278],addressList[279],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452141", timeStamp: "1509287200", hash: "0x36a74db7c2b3fa512a3bf99c18665214a1a8127a2490a5047eb2e3a5e7508748", nonce: "53", blockHash: "0xbfc75b2833215c94591d13666e11a3399b3f9657f0998e62e91d7ba113d25776", transactionIndex: "13", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "248557", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000292264776e4d339f0cf4cc1ad1e1c94db1e9b877000000000000000000000000aeae7258e897d3027d872fa8ce401a0f714b015d00000000000000000000000060d488358411c52565339f3c5bb343b2f0a0da28000000000000000000000000f12fb47576d97a1227656a66d951d99ea79fdf34000000000000000000000000ce9412e6644e648c7dde7d0fb70b1bd24f2b4dc1000000000000000000000000fe0e21d6741378e7c2e0b6278981574459786635000000000000000000000000e65d7550a1619ec9c69658a787523bf8cc441cb3000000000000000000000000021eac92ce7bab8338a22845e78ad7ae0844bd12000000000000000000000000964da88c5339b8cfbdc008f0337400feef5e98940000000000000000000000009c4c521204b9e03e6d6d50bb303ee3e2dce8715c000000000000000000000000e3f0652433668a661748c4d4e4b7b77b15c34cfa", contractAddress: "", cumulativeGasUsed: "633252", gasUsed: "248557", confirmations: "3277780"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[278],addressList[279],addressList[280],addressList[281],addressList[282],addressList[283],addressList[284],addressList[285],addressList[286],addressList[243],addressList[287]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[278],addressList[279],addressList[280],addressList[281],addressList[282],addressList[283],addressList[284],addressList[285],addressList[286],addressList[243],addressList[287]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1509287200 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[288],addressList[289],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452143", timeStamp: "1509287234", hash: "0x83079a5f78d87efef89b217a1974a4f01d294edce6dfb4a50dc68f98d32978b1", nonce: "54", blockHash: "0xcc7df04854ae613ee7ba9a85c21a360eb807f269c67ae853a3d4cbe0048d2679", transactionIndex: "15", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "263493", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000008bbdf22aae90a83fc2b9b7f2f1a4d780a4ac219700000000000000000000000064821173b8d721006ea140886403225e752b4c020000000000000000000000003e03481bf2735cc396c0dc91e86edcb559262b760000000000000000000000002f553fe14819b07f142a6751c1fa326e0576119f0000000000000000000000007f15c2ab437f7cc6c6c29f7f20d98a48d6d97907000000000000000000000000dbd3957808604c13cb52d71bcdf66ce17255329e000000000000000000000000ddc85b17849e2907162e9ed534a01270d95fa8860000000000000000000000004ebc3c60f03c800d8435fd9c183c6e0fc07cc699000000000000000000000000b4893fad20549f470005a108eeceecbf0d6e075d000000000000000000000000b64353454723141f2cc64dae37f46f55981c03cc0000000000000000000000009dc9987e883373916dc08f3d0e6f07a726327acf", contractAddress: "", cumulativeGasUsed: "1461041", gasUsed: "263493", confirmations: "3277778"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[288],addressList[289],addressList[290],addressList[291],addressList[292],addressList[293],addressList[294],addressList[295],addressList[296],addressList[297],addressList[298]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[288],addressList[289],addressList[290],addressList[291],addressList[292],addressList[293],addressList[294],addressList[295],addressList[296],addressList[297],addressList[298]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1509287234 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4452146", timeStamp: "1509287256", hash: "0x19bb3698b3967a27d37603781b2e7fd639703e167eedc648ca3a50b92b2fcd8a", nonce: "10", blockHash: "0x0982836a2a6669eb9585ccf5661363c7e12069f446d9c51e7010f12bff3c42ce", transactionIndex: "0", from: "0x9adcabb1535535aae61e503e2f883e80902a7ef1", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "1000000000000000000", gas: "200000", gasPrice: "50000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "21415", gasUsed: "21415", confirmations: "3277775"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[299], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1509287256 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[299], balance: "98326668615592882" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[299], balance: ( await web3.eth.getBalance( addressList[299], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[300],addressList[301],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452146", timeStamp: "1509287256", hash: "0xe64be8ddadf2f8753991c772b40e6649d0b1269bec9d51e289580a1721a808c8", nonce: "55", blockHash: "0x0982836a2a6669eb9585ccf5661363c7e12069f446d9c51e7010f12bff3c42ce", transactionIndex: "14", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "285538", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000036fd363b456b7aaf6a6abb6b1049ff601f4a852900000000000000000000000003e17cf1fc585aa0cc9f5bc058629d79ccde1869000000000000000000000000af78e0c5ea7bf46ef3ca977ffa73a2ca8aa85e3e00000000000000000000000028f86f4346d83dcc1f9be54e40d866ee73057c5400000000000000000000000034f68fb168fbab42316bd83dd28c5fd3162cc1b10000000000000000000000003961e1070bcf504d01d3278536cc55cf21e549ae000000000000000000000000960416418b9f6946fc178095e5096066c6db656b0000000000000000000000003802dda14645de66eb3cc13c14f9bdb669d717ba000000000000000000000000e5cc1a4ecc73671705bcbd099e4705da4bae1654000000000000000000000000393739c14b6fd3968fb17ece3562ad4889da087b0000000000000000000000000a28a926ae9a0c9d9423cc8bf0159a2fec5fc082000000000000000000000000aa51116a9ddc36754fe8114c37ea9b7a80bb53b7", contractAddress: "", cumulativeGasUsed: "2879082", gasUsed: "285538", confirmations: "3277775"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[300],addressList[301],addressList[302],addressList[303],addressList[304],addressList[305],addressList[306],addressList[307],addressList[308],addressList[309],addressList[310],addressList[311]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[300],addressList[301],addressList[302],addressList[303],addressList[304],addressList[305],addressList[306],addressList[307],addressList[308],addressList[309],addressList[310],addressList[311]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1509287256 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[312],addressList[313],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452148", timeStamp: "1509287280", hash: "0x7b23f97877ede71ce41d8fac6ed28f90a44e69bc020b52fbfc9757ed175dc97c", nonce: "56", blockHash: "0xc2c627fbb1875532fe1370baf0a5c9b91cac09fe4d2b29b2271efef42151fe8c", transactionIndex: "4", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "263557", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000725b387fbae38309a7538f3e25ca711af8b917240000000000000000000000005b6d1f120e54f1040f91e84b11016c1ba1942cf20000000000000000000000007624ed59a74ae74922e860f139b0e817d5075904000000000000000000000000c5ae36e0800ecfc4e4c01ac6d8d9d0ddfa2cd180000000000000000000000000004535925130bdea28473b3be532fe9b24c2a984000000000000000000000000728ad87d02a24c5454a047ae6e3c91c0a5a64e660000000000000000000000006b2af5066d33afe71043d568694b0a8a5397bf09000000000000000000000000a17497c584116636903d1cfad32db95d87e3f67a0000000000000000000000009369710302ea1f54849eb90d032c1963f2527999000000000000000000000000a603a8ed8cfdd6d1d1ae7805b606ef8cd62a269f00000000000000000000000059f5b392e7eff58992e298f94aa355c36897557e", contractAddress: "", cumulativeGasUsed: "394145", gasUsed: "263557", confirmations: "3277773"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[312],addressList[313],addressList[314],addressList[315],addressList[316],addressList[317],addressList[318],addressList[319],addressList[320],addressList[321],addressList[322]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[312],addressList[313],addressList[314],addressList[315],addressList[316],addressList[317],addressList[318],addressList[319],addressList[320],addressList[321],addressList[322]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1509287280 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4452151", timeStamp: "1509287356", hash: "0xecf3a05daecd3e3f37db6ebd510167a1aa79e9e50aa345b38b45fc92b9cc725a", nonce: "108", blockHash: "0x83d67e072d6699c017cc035fc1497cbca04f27c4ccf1ef826e7c537a70fd27bb", transactionIndex: "111", from: "0x1c1bb5915cec7da52985a2765519fc23483c93b0", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "300000000000000000", gas: "200000", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3630202", gasUsed: "68282", confirmations: "3277770"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1509287356 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "LogParticipation", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogParticipation", events: [{name: "sender", type: "address", value: "0x1c1bb5915cec7da52985a2765519fc23483c93b0"}, {name: "value", type: "uint256", value: "300000000000000000"}], address: "0xe6766297571f8693adec94e5f8ef363d323e211d"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "LogTokenReceiver", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokenReceiver", events: [{name: "sender", type: "address", value: "0x1c1bb5915cec7da52985a2765519fc23483c93b0"}, {name: "value", type: "uint256", value: "8625000000000000000000"}], address: "0xe6766297571f8693adec94e5f8ef363d323e211d"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "1186762459148984356" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[323],addressList[324],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452151", timeStamp: "1509287356", hash: "0xba171d5b64bc6f6149832208c1a88ba97fd1dbc55627cc6c1e20ca7342801d6b", nonce: "57", blockHash: "0x83d67e072d6699c017cc035fc1497cbca04f27c4ccf1ef826e7c537a70fd27bb", transactionIndex: "124", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "248557", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000735421c52e312de675e26295ac5426e86fc7a1150000000000000000000000009f11eba694d633a715681f15b3f6c75b77f50a080000000000000000000000000b03e8ff011f91468c0da3a9486f73e779992ee10000000000000000000000003111d2d44e5cfcdfda3112af3aba868ccc6a4cac0000000000000000000000004fb324b848f75a1e8467a7fd5e57ad2f0aa4f36a000000000000000000000000fbb1b73c4f0bda4f67dca266ce6ef42f520fbb9800000000000000000000000044b73d79835d319d766c733a3bd4588e81e2fe3c000000000000000000000000d7db82f6c8446a36486611a3b6cb5bb2d5028e4b0000000000000000000000008629bf805749f90f00fbe7a390171d4bdde80e3c0000000000000000000000005df37d232702ed5ce393f3cff92406fe0c27bfd30000000000000000000000009fe294605dc4ddd5222359307ddc764d1753a98d", contractAddress: "", cumulativeGasUsed: "4841035", gasUsed: "248557", confirmations: "3277770"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[323],addressList[324],addressList[325],addressList[326],addressList[327],addressList[41],addressList[328],addressList[329],addressList[330],addressList[331],addressList[332]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[323],addressList[324],addressList[325],addressList[326],addressList[327],addressList[41],addressList[328],addressList[329],addressList[330],addressList[331],addressList[332]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1509287356 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4452152", timeStamp: "1509287384", hash: "0x4c4e883965e4fbdffb1704c2d4fa455540c308c23798b7c1773446d3af285b51", nonce: "0", blockHash: "0xb1ff1444aa6de3236bd7f9814d6405162482eb1f32929e7c4dda77da1422c50a", transactionIndex: "1", from: "0xc12d995c12705628bb2fa0288a7e051b5c564ed4", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "1000000000000000000", gas: "200000", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "156161", gasUsed: "68282", confirmations: "3277769"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[259], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1509287384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "LogParticipation", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogParticipation", events: [{name: "sender", type: "address", value: "0xc12d995c12705628bb2fa0288a7e051b5c564ed4"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0xe6766297571f8693adec94e5f8ef363d323e211d"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "LogTokenReceiver", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTokenReceiver", events: [{name: "sender", type: "address", value: "0xc12d995c12705628bb2fa0288a7e051b5c564ed4"}, {name: "value", type: "uint256", value: "28750000000000000000000"}], address: "0xe6766297571f8693adec94e5f8ef363d323e211d"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[259], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[259], balance: ( await web3.eth.getBalance( addressList[259], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelistAddresArray( [addressList[333],addressList[334],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4452152", timeStamp: "1509287384", hash: "0x2c174768588ab5b2e57117f8dc5c6d71d4f45624844f97fb251006886aa58229", nonce: "58", blockHash: "0xb1ff1444aa6de3236bd7f9814d6405162482eb1f32929e7c4dda77da1422c50a", transactionIndex: "26", from: "0x5ef33f97a8b716a11c40c74b5dab56d74d5e3c58", to: "0xe6766297571f8693adec94e5f8ef363d323e211d", value: "0", gas: "226704", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x61d3ba8a0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000004de7e57ee6a20d2fe4b0c2d6bc7d866fd436a94000000000000000000000000065f3ac1d439cb08a7be155c3b37581a63f0f3cae000000000000000000000000b238a2d5e2b411637269abe4d9fa117db3fd86d000000000000000000000000033a215c9c3d74385d97b878e854ee50bc5b916eb0000000000000000000000008c0a0ba507ce136c29ec050781ee80697a06e3e90000000000000000000000002e66d73ae7918a359a76486138c36e1d79a4aab900000000000000000000000069701d282af2fce1cc07445db27d046c7cbbf3230000000000000000000000008682794d9509ba171140d072a2276ac82de0704f0000000000000000000000004602c6ff42bbe2d315674a5dfbe4b794349ea0cc000000000000000000000000fbb1b73c4f0bda4f67dca266ce6ef42f520fbb98", contractAddress: "", cumulativeGasUsed: "1656401", gasUsed: "226704", confirmations: "3277769"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_addressesToAdd", value: [addressList[333],addressList[334],addressList[335],addressList[336],addressList[337],addressList[338],addressList[339],addressList[340],addressList[341],addressList[41]]}], name: "addWhitelistAddresArray", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelistAddresArray(address[])" ]( [addressList[333],addressList[334],addressList[335],addressList[336],addressList[337],addressList[338],addressList[339],addressList[340],addressList[341],addressList[41]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1509287384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "59779308000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
