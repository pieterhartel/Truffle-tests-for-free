const DAOPlayMarketTokenCrowdsale = artifacts.require( "./DAOPlayMarketTokenCrowdsale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "DAOPlayMarketTokenCrowdsale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x1818403C06eD28c55d533B526Ae8566Ec31D87d3", "0xbD10C6139181FEb926e608d97882F6AE113A73d7", "0xFa81b792cAFE81301A24Dad70F7d9E580F409a5d", "0x9b9B6Be27FC36033f5B5B67900F64D36470523E5", "0x2be3334e328e9599f697aCd8Ac29775e450151F2", "0x74aB8D6630587E1106CaFE9De34377fE12f4596C", "0x6Ee5A62D19CfCA8A2E545A2CC3715D0285785E1B", "0xC1322D8aE3B0e2E437e0AE36388D0CFD2C02f1c9", "0x7D4E07B9DFa7772cA38618F429fA86e93F666C49", "0xc062788d80124013C769A7593c33c1bF90c7b252", "0xbe161CE91d59e746655c8656A45A408B388e3040", "0x846dEB6cb2157C4744a8f66Ae96734d14B59aF4a", "0xD928Fc07325E65e17650C8443250612486F3350a", "0xA376712E8749dA538a5302146d6a8Fe12D1C9Ab3", "0x14AA3CfC4946daD87015aC91b83896E0dc460434", "0x9f857F07638a27C69595413051a2a8C7CCe4f963", "0x2BbEC636596d0a4BfB849dc84eAfca8CB5103ba6", "0x438347D7d5a1a87d7F411F9804BDbe62D4Fb448A", "0x812e3159dDdB7B2E55AEa40095c3a47e6326130e", "0x9CAd411adc0241C1c50D17D744cb713deC775786", "0xa582d333dFd1E8Dc3D35Df95276BA4b414374081", "0x3ef8739f79750c5cBBFF86e80766176B8524F05c", "0x0e5c4D29366fBaF45ebE299c7502b3A566069237", "0x6F58fb305be4b6b047EfA0D8E51E3e984F36538C", "0x3Bccc6646df900055Cee47105231121f215850d7", "0x7eD1E469fCb3EE19C0366D829e291451bE638E59", "0x4920092E390aF5BBd5E9B9c5E0FCb0e04C1715bc", "0xAa401B700411Eb10c838e6811098749e49c9080A", "0x830cc0792C7AEbf779Ef9f913c3ecE29e636DB5E", "0x33555f0026DE72Cf3e2Cd5e80bfeF5346c6e7349", "0x7ca6E145942e7B0AcC9494ACaB01FBD2EbEF8dF1", "0x347995D459D78Ef240A83B06aa61419644bdE6e4", "0x4deb7F5e426821d7eD7ff9CBfb37f2962C787544", "0x8842Ff3Db4C5FAC5741eFECd3E1B5c7b4B272502", "0xCf40605f087DFF565840B9E8Bf368fa46E65Fa8B", "0x099093521af1A73e6cB1cDfc7909E84FAE73e55f", "0x19D8aD18B0F42f603fE1f2ff4BE7bb290D60aBDE", "0x06De8b823BBdDac691ddec0181F3266cF96d9321", "0x8E46F9d8bd4CF734842a0AA682F14905c5BfE4a6", "0xA84273C34f4cA3eB07e2fBE0E4a608Ea78EB8982", "0x9690Ae94131d74ef2ddb8c6287c7Daf4789FaA96", "0x14b1c9fE0BC7652839EefE3EB588cA3C8a5c2f7A", "0x972597A794c7A405f143b8352a08EC2121095318", "0x35AEa27B525110D05010c6D4CbC83493F449fCbc", "0xBAF62f26ec8dC08E27324ba5061Bff3b0ceCdE51", "0x7c9A8e8Ee938e709DBdCaB3708c155605A2bfB96", "0xFEee5F6e86648A393Ac1BA5379145B9B9039ac6A", "0xa0af7354f37e644f27D6197Ef23be3bF387923b1", "0x0487d6a462E412662AE692056a76261BD0E3CEc4", "0x6e9EC43D29C62c8521bbc7e0a344701fE92dC0c0"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "endsAt", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getState", outputs: [{name: "", type: "uint8"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "investedAmountOf", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "cryptoAgent", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "tokensSold", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "tokenAmount", type: "uint256"}, {name: "tokensSoldTotal", type: "uint256"}], name: "isBreakingCap", outputs: [{name: "limitBroken", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "periodStage", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "stages", outputs: [{name: "start", type: "uint256"}, {name: "end", type: "uint256"}, {name: "period", type: "uint256"}, {name: "price1", type: "uint256"}, {name: "price2", type: "uint256"}, {name: "price3", type: "uint256"}, {name: "price4", type: "uint256"}, {name: "cap", type: "uint256"}, {name: "tokenSold", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "multisigWallet", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "tokenAmountOf", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "address"}], name: "tokenAmountOfPeriod", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "startsAt", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "finalized", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "stage", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "isCrowdsaleFull", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "investorCount", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "CAP", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_endsAt", type: "uint256"}], name: "EndsAtChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "DistributedTokens", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Invested(address,uint256,uint256)", "InvestedOtherCrypto(address,uint256,uint256)", "EndsAtChanged(uint256)", "DistributedTokens(address,uint256)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x9e9d071824fd57d062ca63fd8b786d8da48a6807eebbcb2d83f9e8d21398e28c", "0xc0ebdba142bb91de57a32a31e51ae4cf2fd13e568aa5062c6461bdcb38d15146", "0xd34bb772c4ae9baa99db852f622773b31c7827e8ee818449fef20d30980bd310", "0x9736a590bbeaea4c622a44de0385c4b9bc0757bf8fe5aff6f345672a06be6738", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4481915 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4515592 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_token", value: 4}, {type: "address", name: "_multisigWallet", value: 5}, {type: "uint256", name: "_start", value: "1510160400"}, {type: "uint256", name: "_cap", value: "2250000"}, {type: "uint256[20]", name: "_price", value: ["120000000000000000", "90000000000000000", "60000000000000000", "48000000000000000", "140000000000000000", "105000000000000000", "70000000000000000", "56000000000000000", "160000000000000000", "120000000000000000", "80000000000000000", "64000000000000000", "180000000000000000", "135000000000000000", "90000000000000000", "72000000000000000", "200000000000000000", "150000000000000000", "100000000000000000", "80000000000000000"]}, {type: "uint256", name: "_periodStage", value: "10"}, {type: "uint256", name: "_capPeriod", value: "450000"}], name: "DAOPlayMarketTokenCrowdsale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "endsAt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endsAt()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getState", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getState()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "investedAmountOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investedAmountOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cryptoAgent", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cryptoAgent()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "weiRaised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensSold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensSold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tokenAmount", value: random.range( maxRandom )}, {type: "uint256", name: "tokensSoldTotal", value: random.range( maxRandom )}], name: "isBreakingCap", outputs: [{name: "limitBroken", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isBreakingCap(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "periodStage", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "periodStage()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "stages", outputs: [{name: "start", type: "uint256"}, {name: "end", type: "uint256"}, {name: "period", type: "uint256"}, {name: "price1", type: "uint256"}, {name: "price2", type: "uint256"}, {name: "price3", type: "uint256"}, {name: "price4", type: "uint256"}, {name: "cap", type: "uint256"}, {name: "tokenSold", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "stages(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multisigWallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multisigWallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "tokenAmountOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenAmountOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "tokenAmountOfPeriod", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenAmountOfPeriod(uint256,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startsAt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startsAt()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "finalized", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "finalized()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "halted()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "stage", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "stage()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "newOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isCrowdsaleFull", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isCrowdsaleFull()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "investorCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "CAP", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "CAP()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "DAOPlayMarketTokenCrowdsale", function( accounts ) {

	it( "TEST: DAOPlayMarketTokenCrowdsale( addressList[4], addressList[5], \"151016... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4481915", timeStamp: "1509703923", hash: "0x5987318bed12a9726e2a6a486dda7e68f4b8f794bedde7d93eeb02cbcb45a4dd", nonce: "1", blockHash: "0x0f14372ff11013588ed18530cf2589f6fd6f1ea84a964f09a985fcd2726989fb", transactionIndex: "55", from: "0xbd10c6139181feb926e608d97882f6ae113a73d7", to: 0, value: "0", gas: "3252273", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xa951dd66000000000000000000000000fa81b792cafe81301a24dad70f7d9e580f409a5d0000000000000000000000009b9b6be27fc36033f5b5b67900f64d36470523e5000000000000000000000000000000000000000000000000000000005a033810000000000000000000000000000000000000000000000000000000000022551000000000000000000000000000000000000000000000000001aa535d3d0c0000000000000000000000000000000000000000000000000000013fbe85edc9000000000000000000000000000000000000000000000000000000d529ae9e86000000000000000000000000000000000000000000000000000000aa87bee538000000000000000000000000000000000000000000000000000001f161421c8e0000000000000000000000000000000000000000000000000000017508f1956a800000000000000000000000000000000000000000000000000000f8b0a10e47000000000000000000000000000000000000000000000000000000c6f3b40b6c000000000000000000000000000000000000000000000000000002386f26fc10000000000000000000000000000000000000000000000000000001aa535d3d0c0000000000000000000000000000000000000000000000000000011c37937e08000000000000000000000000000000000000000000000000000000e35fa931a00000000000000000000000000000000000000000000000000000027f7d0bdb92000000000000000000000000000000000000000000000000000001df9dc8e4ad8000000000000000000000000000000000000000000000000000013fbe85edc9000000000000000000000000000000000000000000000000000000ffcb9e57d4000000000000000000000000000000000000000000000000000002c68af0bb1400000000000000000000000000000000000000000000000000000214e8348c4f0000000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000011c37937e080000000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000006ddd0", contractAddress: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", cumulativeGasUsed: "5907645", gasUsed: "3152273", confirmations: "3252861"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}, {type: "address", name: "_multisigWallet", value: addressList[5]}, {type: "uint256", name: "_start", value: "1510160400"}, {type: "uint256", name: "_cap", value: "2250000"}, {type: "uint256[20]", name: "_price", value: ["120000000000000000","90000000000000000","60000000000000000","48000000000000000","140000000000000000","105000000000000000","70000000000000000","56000000000000000","160000000000000000","120000000000000000","80000000000000000","64000000000000000","180000000000000000","135000000000000000","90000000000000000","72000000000000000","200000000000000000","150000000000000000","100000000000000000","80000000000000000"]}, {type: "uint256", name: "_periodStage", value: "10"}, {type: "uint256", name: "_capPeriod", value: "450000"}], name: "DAOPlayMarketTokenCrowdsale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = DAOPlayMarketTokenCrowdsale.new( addressList[4], addressList[5], "1510160400", "2250000", ["120000000000000000","90000000000000000","60000000000000000","48000000000000000","140000000000000000","105000000000000000","70000000000000000","56000000000000000","160000000000000000","120000000000000000","80000000000000000","64000000000000000","180000000000000000","135000000000000000","90000000000000000","72000000000000000","200000000000000000","150000000000000000","100000000000000000","80000000000000000"], "10", "450000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1509703923 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = DAOPlayMarketTokenCrowdsale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setCryptoAgent( addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "4481933", timeStamp: "1509704150", hash: "0x904a0d31ac96f94281982f87f2e025fd8e1daafd94605e28e7c8e68836689142", nonce: "2", blockHash: "0xafefad93d66111055ff5e0c56942a4c46fdb270672397219a9616eea0dce8777", transactionIndex: "88", from: "0xbd10c6139181feb926e608d97882f6ae113a73d7", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "144357", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc8d619850000000000000000000000002be3334e328e9599f697acd8ac29775e450151f2", contractAddress: "", cumulativeGasUsed: "3205367", gasUsed: "44357", confirmations: "3252843"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_cryptoAgent", value: addressList[6]}], name: "setCryptoAgent", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setCryptoAgent(address)" ]( addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1509704150 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[7], \"226481533279538750\" )", async function( ) {
		const txOriginal = {blockNumber: "4482771", timeStamp: "1509715997", hash: "0x9b8ce1e8e450a5659b6f1105d5ad35c5557a1545beeee348eccdb6f51be0dcdf", nonce: "0", blockHash: "0x66764a2828d2310517faa9af1d2079948e2a33e0e81c7b4ca5e6b262322cb2d6", transactionIndex: "51", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "11500000000", isError: "1", txreceipt_status: "0", input: "0x0a20aba400000000000000000000000074ab8d6630587e1106cafe9de34377fe12f4596c00000000000000000000000000000000000000000000000003249fc12b500e3e", contractAddress: "", cumulativeGasUsed: "1943527", gasUsed: "250000", confirmations: "3252005"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[7]}, {type: "uint256", name: "_weiAmount", value: "226481533279538750"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[7], \"225807324903114400\" )", async function( ) {
		const txOriginal = {blockNumber: "4482865", timeStamp: "1509717147", hash: "0x76b4a1e82d4bec6248133e5e81f75f7eeb7e3e2b4ece61dde9f4668441abd2b3", nonce: "1", blockHash: "0x7a7dc8c4cb20f27f1b186777ca84b64bc742e7775bb45b1fe2aa55651aae7d79", transactionIndex: "62", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "15000000000", isError: "1", txreceipt_status: "0", input: "0x0a20aba400000000000000000000000074ab8d6630587e1106cafe9de34377fe12f4596c00000000000000000000000000000000000000000000000003223a90cc8806a0", contractAddress: "", cumulativeGasUsed: "2358793", gasUsed: "250000", confirmations: "3251911"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[7]}, {type: "uint256", name: "_weiAmount", value: "225807324903114400"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setMultisig( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "4495352", timeStamp: "1509889495", hash: "0xa0238b9684edc78ff103f04415f261e8c46b39701c87cc2a8743eb14c5b7d712", nonce: "7", blockHash: "0x540993ebba43b66def327fa8c6449272147a7a594f88d3c7f169ac6a22a79926", transactionIndex: "19", from: "0xbd10c6139181feb926e608d97882f6ae113a73d7", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "129383", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xf3283fba0000000000000000000000006ee5a62d19cfca8a2e545a2cc3715d0285785e1b", contractAddress: "", cumulativeGasUsed: "1281194", gasUsed: "29383", confirmations: "3239424"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[8]}], name: "setMultisig", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setMultisig(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1509889495 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setToken( addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "4495360", timeStamp: "1509889610", hash: "0x58796c9baa371964e770bda8eb06c28d29494ccd0a5a7642f3f3604efdb9f2e5", nonce: "8", blockHash: "0x3d6657ab3627815ef4780339281173ca6e4b72eb55a9332682c24f7b98b318c2", transactionIndex: "95", from: "0xbd10c6139181feb926e608d97882f6ae113a73d7", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "128701", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x144fa6d7000000000000000000000000c1322d8ae3b0e2e437e0ae36388d0cfd2c02f1c9", contractAddress: "", cumulativeGasUsed: "4791285", gasUsed: "28701", confirmations: "3239416"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[9]}], name: "setToken", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setToken(address)" ]( addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1509889610 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4514883", timeStamp: "1510160638", hash: "0x0a1fa2dca82e517ca94617ea9a01468b5ebaad7ea806d74ac40118057e12b049", nonce: "1", blockHash: "0xaf300bfab382ec060bbb3b3ad0bc3ffbe49928f55aec079e85bc45b5eb6eeb7c", transactionIndex: "33", from: "0x7d4e07b9dfa7772ca38618f429fa86e93f666c49", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "151656555000000000", gas: "222400", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1419151", gasUsed: "221951", confirmations: "3219893"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "151656555000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1510160638 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x7d4e07b9dfa7772ca38618f429fa86e93f666c49"}, {name: "weiAmount", type: "uint256", value: "151656555000000000"}, {name: "tokenAmount", type: "uint256", value: "12638"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4514921", timeStamp: "1510161065", hash: "0xf4b7b6ac12259ef076cdc9e711c65dc642f6c5051f0f4fa93e46aa1688819140", nonce: "6", blockHash: "0xd9664c43ddafb31f20391b1228314ec43f07cef3f729330ce6b9cd3d03b1c213", transactionIndex: "9", from: "0xc062788d80124013c769a7593c33c1bf90c7b252", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "4000000000000000000", gas: "162400", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "773004", gasUsed: "161951", confirmations: "3219855"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "4000000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1510161065 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xc062788d80124013c769a7593c33c1bf90c7b252"}, {name: "weiAmount", type: "uint256", value: "4000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "333333"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "16822544459110912" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4514933", timeStamp: "1510161366", hash: "0x3f3a51f9599a97083dcd3d926c538dff3ed455a071d3c2bc36507ebf3d88e81d", nonce: "10", blockHash: "0x54b6a31aa4769dc4c12c5983a84991fe0dcb4763b59f0696538620f0f96c75df", transactionIndex: "11", from: "0xbe161ce91d59e746655c8656a45a408b388e3040", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "90000000000000000", gas: "162400", gasPrice: "24000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "872037", gasUsed: "161951", confirmations: "3219843"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "90000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1510161366 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xbe161ce91d59e746655c8656a45a408b388e3040"}, {name: "weiAmount", type: "uint256", value: "90000000000000000"}, {name: "tokenAmount", type: "uint256", value: "7500"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "1723694198000001000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4514936", timeStamp: "1510161389", hash: "0xda46d98cd0d84b5c3bc6d02dbc71f3993716af9173784931e54679ad0884c460", nonce: "0", blockHash: "0x60e6646962c4999c97b900e578c9277e0d3cea405c71241c1bc653aff5da521c", transactionIndex: "14", from: "0x846deb6cb2157c4744a8f66ae96734d14b59af4a", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "600000000000000000", gas: "162400", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "800286", gasUsed: "161951", confirmations: "3219840"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "600000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1510161389 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x846deb6cb2157c4744a8f66ae96734d14b59af4a"}, {name: "weiAmount", type: "uint256", value: "600000000000000000"}, {name: "tokenAmount", type: "uint256", value: "50000"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4514987", timeStamp: "1510162145", hash: "0x531d34119e85b5e660d8e0c4a65a5f24082c7d2329b7762984b640b937320a87", nonce: "15", blockHash: "0xa0b8d3bcbaa1a6fc18bc64bfb1b88675e7963d0647ba74016efbedd4d9b2cb9c", transactionIndex: "61", from: "0xd928fc07325e65e17650c8443250612486f3350a", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "4000000000000000", gas: "21000", gasPrice: "21000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "3846337", gasUsed: "21000", confirmations: "3219789"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4514989", timeStamp: "1510162172", hash: "0xe4b8b7ce3fad9bde052f1edc81ac96d009f2b627dc75b099001f80408fa5ada5", nonce: "25", blockHash: "0x24adfb5d1c93420fd694e636dc3edfda23567cd17b154dee1f3d2d60d4bd40d9", transactionIndex: "18", from: "0xa376712e8749da538a5302146d6a8fe12d1c9ab3", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "1500000000000000000", gas: "21000", gasPrice: "21000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1661149", gasUsed: "21000", confirmations: "3219787"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1500000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "3516336934051286329" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4514997", timeStamp: "1510162244", hash: "0x7160beb8526b69ce72791b7e50d1f8a06a8c19c9e1816c6020b6d86c61e5ad9d", nonce: "10", blockHash: "0xa6e3390c8b12f93540e9627e42e4064607028cb26cba5c5214c1111f6edf713c", transactionIndex: "7", from: "0x14aa3cfc4946dad87015ac91b83896e0dc460434", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "200000000000000000", gas: "162400", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "379334", gasUsed: "161951", confirmations: "3219779"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510162244 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x14aa3cfc4946dad87015ac91b83896e0dc460434"}, {name: "weiAmount", type: "uint256", value: "200000000000000000"}, {name: "tokenAmount", type: "uint256", value: "16666"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "6292152000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[17], \"68328695150885060\" )", async function( ) {
		const txOriginal = {blockNumber: "4515005", timeStamp: "1510162340", hash: "0x2b114e53827e3eea7e9379ed8f341db9896098c2b721c32f8edc55a54b9136e5", nonce: "2", blockHash: "0xd18725d113a3efce57725643f1e0464776eb53b1a8f46838c647b903172058d8", transactionIndex: "82", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba40000000000000000000000009f857f07638a27c69595413051a2a8c7cce4f96300000000000000000000000000000000000000000000000000f2c096126f38c4", contractAddress: "", cumulativeGasUsed: "3407843", gasUsed: "156950", confirmations: "3219771"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[17]}, {type: "uint256", name: "_weiAmount", value: "68328695150885060"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[17], "68328695150885060", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510162340 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x9f857f07638a27c69595413051a2a8c7cce4f963"}, {name: "weiAmount", type: "uint256", value: "68328695150885060"}, {name: "tokenAmount", type: "uint256", value: "5694"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4515006", timeStamp: "1510162342", hash: "0xc65261de1dbd2cbc6fa227840e6df7ea7ed3a6c22da029e215bee92fefc67f35", nonce: "0", blockHash: "0x7db9742e65c67e059caec63dd9cc59b9c3d4775b95a8f3e9334f1ba7c46112b5", transactionIndex: "7", from: "0x2bbec636596d0a4bfb849dc84eafca8cb5103ba6", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "1000000000000000000", gas: "262400", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "581752", gasUsed: "161951", confirmations: "3219770"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1510162342 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x2bbec636596d0a4bfb849dc84eafca8cb5103ba6"}, {name: "weiAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "83333"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4515056", timeStamp: "1510162885", hash: "0xe3e37476accac676db65f90f0a0c1aefe4ab4ad41d2d46f5f153e59051c13830", nonce: "0", blockHash: "0x789d7d07e0437eff5fe90120f51f110f380346e7a8b3782d12df1d77232cc803", transactionIndex: "27", from: "0x438347d7d5a1a87d7f411f9804bdbe62d4fb448a", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "500000000000000000", gas: "162400", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1137668", gasUsed: "161951", confirmations: "3219720"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510162885 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x438347d7d5a1a87d7f411f9804bdbe62d4fb448a"}, {name: "weiAmount", type: "uint256", value: "500000000000000000"}, {name: "tokenAmount", type: "uint256", value: "41666"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "595763880000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4515067", timeStamp: "1510163023", hash: "0x65629812adb0e52b2ec5298305065a8bbbc28cab70b41448bff2f99ac78fbb24", nonce: "10", blockHash: "0x8182dff8c283b49aa49c45bc56a47165d77fc062de5913c9d38abd486946a7f4", transactionIndex: "25", from: "0x812e3159dddb7b2e55aea40095c3a47e6326130e", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "10000000000000000", gas: "162400", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1305632", gasUsed: "161951", confirmations: "3219709"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510163023 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x812e3159dddb7b2e55aea40095c3a47e6326130e"}, {name: "weiAmount", type: "uint256", value: "10000000000000000"}, {name: "tokenAmount", type: "uint256", value: "833"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "5113716135431500" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4515069", timeStamp: "1510163034", hash: "0x3a54b4b8d9021f874046842ce3f253fa657583719e8e0f195e603b0e8577527c", nonce: "1", blockHash: "0x80106404452d6ddb155fea9dee3d0bfead62310ccb398bcad880af31fd130151", transactionIndex: "9", from: "0x9cad411adc0241c1c50d17d744cb713dec775786", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "122000000000000000", gas: "162400", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "533210", gasUsed: "161951", confirmations: "3219707"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "122000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1510163034 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x9cad411adc0241c1c50d17d744cb713dec775786"}, {name: "weiAmount", type: "uint256", value: "122000000000000000"}, {name: "tokenAmount", type: "uint256", value: "10166"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[22], \"16995000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515086", timeStamp: "1510163290", hash: "0x75821973ef0c1d132b312dfa0512a64b2367999ac83c69bb268227129444e181", nonce: "3", blockHash: "0x9763fe70f8ef17156b0cef3ef71236f630058c67e871b4555b11ce6f9034c091", transactionIndex: "33", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba4000000000000000000000000a582d333dfd1e8dc3d35df95276ba4b414374081000000000000000000000000000000000000000000000000ebda5e74e5c38000", contractAddress: "", cumulativeGasUsed: "1444852", gasUsed: "156999", confirmations: "3219690"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[22]}, {type: "uint256", name: "_weiAmount", value: "16995000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[22], "16995000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1510163290 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0xa582d333dfd1e8dc3d35df95276ba4b414374081"}, {name: "weiAmount", type: "uint256", value: "16995000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1888333"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4515087", timeStamp: "1510163317", hash: "0x5f680c5c1f728ecc462890e036da76f38b6a262742304af21e0e5f511ce3545c", nonce: "0", blockHash: "0xb5a6dc2f31320938f5f3fd3cb420102f18008404a8978cc18ffe3631b66efa2e", transactionIndex: "6", from: "0x3ef8739f79750c5cbbff86e80766176b8524f05c", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "1400000000000000000", gas: "300000", gasPrice: "30100000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "356304", gasUsed: "161951", confirmations: "3219689"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "1400000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1510163317 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x3ef8739f79750c5cbbff86e80766176b8524f05c"}, {name: "weiAmount", type: "uint256", value: "1400000000000000000"}, {name: "tokenAmount", type: "uint256", value: "116666"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "95125274900000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[24], \"15595200000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515095", timeStamp: "1510163502", hash: "0xefaf492b32fb808f3416c629f020ee51aadcac91d194383cff2d9fc7113d415a", nonce: "4", blockHash: "0xba60b9406fc34e86d2241da15955bf5028ce145506ec873b574bd0ff38677493", transactionIndex: "140", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "19200000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba40000000000000000000000000e5c4d29366fbaf45ebe299c7502b3a566069237000000000000000000000000000000000000000000000000d86d47c5e92c0000", contractAddress: "", cumulativeGasUsed: "6291719", gasUsed: "156935", confirmations: "3219681"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[24]}, {type: "uint256", name: "_weiAmount", value: "15595200000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[24], "15595200000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1510163502 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x0e5c4d29366fbaf45ebe299c7502b3a566069237"}, {name: "weiAmount", type: "uint256", value: "15595200000000000000"}, {name: "tokenAmount", type: "uint256", value: "1732800"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[25], \"232893586233608860\" )", async function( ) {
		const txOriginal = {blockNumber: "4515107", timeStamp: "1510163657", hash: "0x9da024a5a17d8ffaee2c04c6a578f34f595397b4ebaccdab7814df1ca47bfba1", nonce: "5", blockHash: "0x83733863116dbdb7bb17a2f348dbc96106157d3fcddefbdd6b1099a8127bb7e9", transactionIndex: "35", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba40000000000000000000000006f58fb305be4b6b047efa0d8e51e3e984f36538c000000000000000000000000000000000000000000000000033b677b95ebca9c", contractAddress: "", cumulativeGasUsed: "1660251", gasUsed: "157014", confirmations: "3219669"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[25]}, {type: "uint256", name: "_weiAmount", value: "232893586233608860"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[25], "232893586233608860", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1510163657 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x6f58fb305be4b6b047efa0d8e51e3e984f36538c"}, {name: "weiAmount", type: "uint256", value: "232893586233608860"}, {name: "tokenAmount", type: "uint256", value: "19407"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[26], \"2416152283087639000\" )", async function( ) {
		const txOriginal = {blockNumber: "4515121", timeStamp: "1510163883", hash: "0x053bea1e1b400ebb15a014436f06290a4764f7616373ad0d0c922e2ebda86fa4", nonce: "6", blockHash: "0x87b5fa6e8d3272d1f812cea4c4d55e4c4861121eeda6ddd159d0aaa8717f599f", transactionIndex: "28", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba40000000000000000000000003bccc6646df900055cee47105231121f215850d70000000000000000000000000000000000000000000000002187e5b33cb011d8", contractAddress: "", cumulativeGasUsed: "1417465", gasUsed: "156950", confirmations: "3219655"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[26]}, {type: "uint256", name: "_weiAmount", value: "2416152283087639000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[26], "2416152283087639000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1510163883 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x3bccc6646df900055cee47105231121f215850d7"}, {name: "weiAmount", type: "uint256", value: "2416152283087639000"}, {name: "tokenAmount", type: "uint256", value: "201346"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4515125", timeStamp: "1510163915", hash: "0x9ba5f5dc222f3eeb93199e68ee06b85ddbedfd85b91644bf01d551161d6be42a", nonce: "145539", blockHash: "0xd51b253f2d2c51d3444f0d8abdfc676fd9902455d48c85190197d5f062303d82", transactionIndex: "9", from: "0x7ed1e469fcb3ee19c0366d829e291451be638e59", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "1023965320000000000", gas: "162400", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "672095", gasUsed: "161951", confirmations: "3219651"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "1023965320000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1510163915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x7ed1e469fcb3ee19c0366d829e291451be638e59"}, {name: "weiAmount", type: "uint256", value: "1023965320000000000"}, {name: "tokenAmount", type: "uint256", value: "85330"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "272671594221002000315" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[28], \"12446174541114778\" )", async function( ) {
		const txOriginal = {blockNumber: "4515130", timeStamp: "1510163949", hash: "0x57adea99d688fb349e6e251c627e20f2ff4da9cfb83bea246b4e131ed2ac1414", nonce: "7", blockHash: "0xfeefbb304742cd5d49aba4a6f36ad5aea26079c10e0071eb98952f9952391d13", transactionIndex: "52", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba40000000000000000000000004920092e390af5bbd5e9b9c5e0fcb0e04c1715bc000000000000000000000000000000000000000000000000002c37bad455ed9a", contractAddress: "", cumulativeGasUsed: "2539076", gasUsed: "156950", confirmations: "3219646"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[28]}, {type: "uint256", name: "_weiAmount", value: "12446174541114778"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[28], "12446174541114778", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1510163949 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x4920092e390af5bbd5e9b9c5e0fcb0e04c1715bc"}, {name: "weiAmount", type: "uint256", value: "12446174541114778"}, {name: "tokenAmount", type: "uint256", value: "1037"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4515169", timeStamp: "1510164403", hash: "0x7f98479abcaf5979ac301141d1d32731bd73bafaf57dd6334f347d8b4e5b4ede", nonce: "0", blockHash: "0x65dbd01c8b309458431ba66847831fd168cf39d3d6e92ecc8565252dcee1451d", transactionIndex: "123", from: "0xaa401b700411eb10c838e6811098749e49c9080a", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "480000000000000000", gas: "162400", gasPrice: "16700000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5122499", gasUsed: "161951", confirmations: "3219607"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "480000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1510164403 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xaa401b700411eb10c838e6811098749e49c9080a"}, {name: "weiAmount", type: "uint256", value: "480000000000000000"}, {name: "tokenAmount", type: "uint256", value: "40000"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "120402620000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[30], \"20995000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515173", timeStamp: "1510164438", hash: "0xb2a376f1b6229f8798a5dba20372a869f19b4ab3205b7f97e1101c19d614614e", nonce: "8", blockHash: "0x2842d1b8bb5202fb7f88e32e580d88257fe7917eaa0d3c1ace90392919b6adf0", transactionIndex: "34", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba4000000000000000000000000830cc0792c7aebf779ef9f913c3ece29e636db5e000000000000000000000000000000000000000000000001235d394383538000", contractAddress: "", cumulativeGasUsed: "1981923", gasUsed: "157063", confirmations: "3219603"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[30]}, {type: "uint256", name: "_weiAmount", value: "20995000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[30], "20995000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1510164438 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x830cc0792c7aebf779ef9f913c3ece29e636db5e"}, {name: "weiAmount", type: "uint256", value: "20995000000000000000"}, {name: "tokenAmount", type: "uint256", value: "2332777"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4515199", timeStamp: "1510164899", hash: "0xd87233c7983d30c2913f3aa47bacfec97d5d4ec67f4aa8a8f8d813041bec84a2", nonce: "16", blockHash: "0xcaab0caaa839459bc22d128804c4da8e374049ae742922bcbd21c3aa09b8a960", transactionIndex: "14", from: "0x33555f0026de72cf3e2cd5e80bfef5346c6e7349", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "100000000000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "663170", gasUsed: "161951", confirmations: "3219577"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1510164899 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x33555f0026de72cf3e2cd5e80bfef5346c6e7349"}, {name: "weiAmount", type: "uint256", value: "100000000000000000"}, {name: "tokenAmount", type: "uint256", value: "8333"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "12417000000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[32], \"10995000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515223", timeStamp: "1510165400", hash: "0x9bb85d391a4ea66b24ee56e97d5581b8622417359662b1b099e107c5f1973c8c", nonce: "9", blockHash: "0xf77b464feed7c64c112adc4a0dc723ba130a7e3262be64a2637a6a700d213d33", transactionIndex: "87", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba40000000000000000000000007ca6e145942e7b0acc9494acab01fbd2ebef8df10000000000000000000000000000000000000000000000009896163ef96b8000", contractAddress: "", cumulativeGasUsed: "3816441", gasUsed: "156999", confirmations: "3219553"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[32]}, {type: "uint256", name: "_weiAmount", value: "10995000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[32], "10995000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1510165400 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x7ca6e145942e7b0acc9494acab01fbd2ebef8df1"}, {name: "weiAmount", type: "uint256", value: "10995000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1221666"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4515228", timeStamp: "1510165509", hash: "0x71c78766af85e5e45aeff87f6487027d0e9c6197bb977cf9c5408871b492fd7e", nonce: "1", blockHash: "0x7ae64ad9a60bf17e03ccd11631cd01a0012f16f090e0b773ae57c35e4fde80e6", transactionIndex: "16", from: "0x347995d459d78ef240a83b06aa61419644bde6e4", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "1000000000000000000", gas: "162400", gasPrice: "24000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1106751", gasUsed: "161951", confirmations: "3219548"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1510165509 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x347995d459d78ef240a83b06aa61419644bde6e4"}, {name: "weiAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "83333"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[26], \"476706350771462300\" )", async function( ) {
		const txOriginal = {blockNumber: "4515231", timeStamp: "1510165576", hash: "0xa70474ace18bdef89ae5ef4a2d51f4168efa11c0e8db7231aaaed79d9d1e00cb", nonce: "10", blockHash: "0x1944511788bed8bb4c57bdd14348ef99013c9c3400f2bad1777e84e00c5b2a6b", transactionIndex: "113", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba40000000000000000000000003bccc6646df900055cee47105231121f215850d7000000000000000000000000000000000000000000000000069d99e67be7e09c", contractAddress: "", cumulativeGasUsed: "3434179", gasUsed: "91735", confirmations: "3219545"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[26]}, {type: "uint256", name: "_weiAmount", value: "476706350771462300"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[26], "476706350771462300", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1510165576 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x3bccc6646df900055cee47105231121f215850d7"}, {name: "weiAmount", type: "uint256", value: "476706350771462300"}, {name: "tokenAmount", type: "uint256", value: "39725"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[34], \"16795000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515236", timeStamp: "1510165627", hash: "0xd7f7d5e7e790b20a2f2710fce2043102de75df019b446bd3101101e29842b56b", nonce: "11", blockHash: "0x7729780f6578aee7ce4cf615194dd5f1a0354d4c89d14bd7f9c8fc9459015420", transactionIndex: "57", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba40000000000000000000000004deb7f5e426821d7ed7ff9cbfb37f2962c787544000000000000000000000000000000000000000000000000e913d3842aaf8000", contractAddress: "", cumulativeGasUsed: "2090451", gasUsed: "156999", confirmations: "3219540"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[34]}, {type: "uint256", name: "_weiAmount", value: "16795000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[34], "16795000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510165627 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x4deb7f5e426821d7ed7ff9cbfb37f2962c787544"}, {name: "weiAmount", type: "uint256", value: "16795000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1866111"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[35], \"8995000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4515266", timeStamp: "1510165939", hash: "0xdff09924f9dc3b9e317f42e148e18e3acd198aea615301408f83b672c7ac632c", nonce: "12", blockHash: "0x1584400dca540bacd67cfcb3f926d7210152168e62513542fc3385bf6fb9d1d2", transactionIndex: "91", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba40000000000000000000000008842ff3db4c5fac5741efecd3e1b5c7b4b2725020000000000000000000000000000000000000000000000007cd4a8d7aaa38000", contractAddress: "", cumulativeGasUsed: "3884888", gasUsed: "156950", confirmations: "3219510"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[35]}, {type: "uint256", name: "_weiAmount", value: "8995000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[35], "8995000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1510165939 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x8842ff3db4c5fac5741efecd3e1b5c7b4b272502"}, {name: "weiAmount", type: "uint256", value: "8995000000000000000"}, {name: "tokenAmount", type: "uint256", value: "749583"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[36], \"27675000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515278", timeStamp: "1510166130", hash: "0xb6cfc097549b45d31cfe5e5c238ffcd7322e6315e3ad69fcfee4ba8e7b679bca", nonce: "13", blockHash: "0x659fec45abf410da82f91a18b69e12ef7a7bc7f8dc32bfdcc3e4770113160d02", transactionIndex: "39", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba4000000000000000000000000cf40605f087dff565840b9e8bf368fa46e65fa8b000000000000000000000000000000000000000000000001801159df1eef8000", contractAddress: "", cumulativeGasUsed: "2718985", gasUsed: "157063", confirmations: "3219498"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[36]}, {type: "uint256", name: "_weiAmount", value: "27675000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[36], "27675000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1510166130 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0xcf40605f087dff565840b9e8bf368fa46e65fa8b"}, {name: "weiAmount", type: "uint256", value: "27675000000000000000"}, {name: "tokenAmount", type: "uint256", value: "3075000"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4515281", timeStamp: "1510166185", hash: "0x4a591e8d0547d6e7c4e9821ddc52fa72c75c6ef3b87096d9e8d5a772c53a88cc", nonce: "0", blockHash: "0x8e01eec5c2bf0bdf51856be3a5a7b42ddbe032538cf2e2c3ab41fc5d60409230", transactionIndex: "18", from: "0x099093521af1a73e6cb1cdfc7909e84fae73e55f", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "120000000000000000", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "798125", gasUsed: "161951", confirmations: "3219495"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[37], to: addressList[2], value: "120000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1510166185 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x099093521af1a73e6cb1cdfc7909e84fae73e55f"}, {name: "weiAmount", type: "uint256", value: "120000000000000000"}, {name: "tokenAmount", type: "uint256", value: "10000"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[37], balance: "190644100000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[37], balance: ( await web3.eth.getBalance( addressList[37], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[38], \"14997500000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515294", timeStamp: "1510166350", hash: "0x37cacd81e8eebac9a2350a49c4ddd2c964dcb79a025634ad5f354a94cf8ad265", nonce: "14", blockHash: "0x5b8c0c7f9c4aafcd3e675d91f4a62aefd44b3b7b5e8d418f78246658ffdf1890", transactionIndex: "87", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba400000000000000000000000019d8ad18b0f42f603fe1f2ff4be7bb290d60abde000000000000000000000000000000000000000000000000d021d2ca32ebc000", contractAddress: "", cumulativeGasUsed: "2619455", gasUsed: "156999", confirmations: "3219482"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[38]}, {type: "uint256", name: "_weiAmount", value: "14997500000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[38], "14997500000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1510166350 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x19d8ad18b0f42f603fe1f2ff4be7bb290d60abde"}, {name: "weiAmount", type: "uint256", value: "14997500000000000000"}, {name: "tokenAmount", type: "uint256", value: "1666388"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4515298", timeStamp: "1510166416", hash: "0x1edba5263fa00a1ed50346337972ffae98cccb4e9a476d406bb761802fe939b1", nonce: "12", blockHash: "0x819b6e9770beb63267e65abdec84404ba9895f7a1ddb7e60ff72e6c37597c280", transactionIndex: "14", from: "0x812e3159dddb7b2e55aea40095c3a47e6326130e", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "56000000000000000", gas: "97185", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "877407", gasUsed: "96736", confirmations: "3219478"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "56000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1510166416 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x812e3159dddb7b2e55aea40095c3a47e6326130e"}, {name: "weiAmount", type: "uint256", value: "56000000000000000"}, {name: "tokenAmount", type: "uint256", value: "4666"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "5113716135431500" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[39], \"421548326054851650\" )", async function( ) {
		const txOriginal = {blockNumber: "4515298", timeStamp: "1510166416", hash: "0xef1b43ba32d19e90f0b3b04ba6e0b6a08dd3c14be31c9d945175ab2a29c0113f", nonce: "15", blockHash: "0x819b6e9770beb63267e65abdec84404ba9895f7a1ddb7e60ff72e6c37597c280", transactionIndex: "28", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba400000000000000000000000006de8b823bbddac691ddec0181f3266cf96d932100000000000000000000000000000000000000000000000005d9a3f81628f442", contractAddress: "", cumulativeGasUsed: "1445575", gasUsed: "157014", confirmations: "3219478"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[39]}, {type: "uint256", name: "_weiAmount", value: "421548326054851650"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[39], "421548326054851650", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1510166416 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x06de8b823bbddac691ddec0181f3266cf96d9321"}, {name: "weiAmount", type: "uint256", value: "421548326054851650"}, {name: "tokenAmount", type: "uint256", value: "35129"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[40], \"284647527964074500\" )", async function( ) {
		const txOriginal = {blockNumber: "4515298", timeStamp: "1510166416", hash: "0xa2b83b3f47a71345246b6f811821992a1dc1f91f71a29f013d497bcc61e03ff1", nonce: "16", blockHash: "0x819b6e9770beb63267e65abdec84404ba9895f7a1ddb7e60ff72e6c37597c280", transactionIndex: "76", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba40000000000000000000000008e46f9d8bd4cf734842a0aa682f14905c5bfe4a600000000000000000000000000000000000000000000000003f3456b267de204", contractAddress: "", cumulativeGasUsed: "4187932", gasUsed: "157014", confirmations: "3219478"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[40]}, {type: "uint256", name: "_weiAmount", value: "284647527964074500"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[40], "284647527964074500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1510166416 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x8e46f9d8bd4cf734842a0aa682f14905c5bfe4a6"}, {name: "weiAmount", type: "uint256", value: "284647527964074500"}, {name: "tokenAmount", type: "uint256", value: "23720"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[41], \"18995000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515304", timeStamp: "1510166535", hash: "0x10466023850ec7280c95312bdd73a4e1d793b51c19dc21d99307719dba6c66a1", nonce: "17", blockHash: "0xa22239a3bb6c1966c9dbb89a5eac16d4c0f87871dc8fedad4302c2759656c6cd", transactionIndex: "27", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba4000000000000000000000000a84273c34f4ca3eb07e2fbe0e4a608ea78eb8982000000000000000000000000000000000000000000000001079bcbdc348b8000", contractAddress: "", cumulativeGasUsed: "934840", gasUsed: "157063", confirmations: "3219472"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[41]}, {type: "uint256", name: "_weiAmount", value: "18995000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[41], "18995000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1510166535 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0xa84273c34f4ca3eb07e2fbe0e4a608ea78eb8982"}, {name: "weiAmount", type: "uint256", value: "18995000000000000000"}, {name: "tokenAmount", type: "uint256", value: "2110555"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[42], \"24995000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515319", timeStamp: "1510166772", hash: "0x1285dfb31ecd1d4ae087bd9f8ae793a6830e8da96329f088c67a2d735f0be409", nonce: "18", blockHash: "0x525f18efce33b8a30b83695d68cd0e4a2f6ff5b13f20ad384e8d887d9deafcd4", transactionIndex: "54", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba40000000000000000000000009690ae94131d74ef2ddb8c6287c7daf4789faa960000000000000000000000000000000000000000000000015ae0141220e38000", contractAddress: "", cumulativeGasUsed: "1992299", gasUsed: "157063", confirmations: "3219457"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[42]}, {type: "uint256", name: "_weiAmount", value: "24995000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[42], "24995000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1510166772 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x9690ae94131d74ef2ddb8c6287c7daf4789faa96"}, {name: "weiAmount", type: "uint256", value: "24995000000000000000"}, {name: "tokenAmount", type: "uint256", value: "2777222"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[43], \"11995000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515333", timeStamp: "1510167014", hash: "0x9cb325b96b42b2295974593d2ee853dfb5a96c42c0ee4b1d2ff1ee2f141a66ce", nonce: "19", blockHash: "0x8f894d14beb6bd62aa62ee67d13263f64bcae5caf353800d15abca6f33169927", transactionIndex: "59", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba400000000000000000000000014b1c9fe0bc7652839eefe3eb588ca3c8a5c2f7a000000000000000000000000000000000000000000000000a676ccf2a0cf8000", contractAddress: "", cumulativeGasUsed: "2230556", gasUsed: "156999", confirmations: "3219443"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[43]}, {type: "uint256", name: "_weiAmount", value: "11995000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[43], "11995000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1510167014 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x14b1c9fe0bc7652839eefe3eb588ca3c8a5c2f7a"}, {name: "weiAmount", type: "uint256", value: "11995000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1332777"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[44], \"17995000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515392", timeStamp: "1510167913", hash: "0x7cba8b30ce31cdddb5bc9cebd239687423a0e05ac435560872ac0bf5a2126de3", nonce: "20", blockHash: "0x74bacf306d53febe94d0980cc0fdfc3e17d77626128e0c87e4e3e8edaa72006e", transactionIndex: "116", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba4000000000000000000000000972597a794c7a405f143b8352a08ec2121095318000000000000000000000000000000000000000000000000f9bb15288d278000", contractAddress: "", cumulativeGasUsed: "4239986", gasUsed: "156999", confirmations: "3219384"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[44]}, {type: "uint256", name: "_weiAmount", value: "17995000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[44], "17995000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1510167913 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x972597a794c7a405f143b8352a08ec2121095318"}, {name: "weiAmount", type: "uint256", value: "17995000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1999444"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[45], \"11497000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515459", timeStamp: "1510168818", hash: "0x0314b9a6648dc9c5677228009aaa97f991958de6b86fa88ddc36a4b886574d02", nonce: "21", blockHash: "0x78098b5402e661ace1935ab008e75d12e106e71dd48eb535ea8ad9af2d0414df", transactionIndex: "48", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba400000000000000000000000035aea27b525110d05010c6d4cbc83493f449fcbc0000000000000000000000000000000000000000000000009f8d8c9616aa8000", contractAddress: "", cumulativeGasUsed: "1815818", gasUsed: "156999", confirmations: "3219317"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[45]}, {type: "uint256", name: "_weiAmount", value: "11497000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[45], "11497000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1510168818 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x35aea27b525110d05010c6d4cbc83493f449fcbc"}, {name: "weiAmount", type: "uint256", value: "11497000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1277444"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[46], \"32995000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515507", timeStamp: "1510169511", hash: "0x8e863aaae6724087ca11e63cf88273bd1d2490118e06a806b5ef2f9c1489b4fe", nonce: "22", blockHash: "0x72c5d46cb73a830a6f45185566946d1a24b3c9e5bc3097dfedec470e4f4a6ae4", transactionIndex: "70", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba4000000000000000000000000baf62f26ec8dc08e27324ba5061bff3b0cecde51000000000000000000000000000000000000000000000001c9e5c9af5c038000", contractAddress: "", cumulativeGasUsed: "2707799", gasUsed: "157063", confirmations: "3219269"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[46]}, {type: "uint256", name: "_weiAmount", value: "32995000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[46], "32995000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1510169511 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0xbaf62f26ec8dc08e27324ba5061bff3b0cecde51"}, {name: "weiAmount", type: "uint256", value: "32995000000000000000"}, {name: "tokenAmount", type: "uint256", value: "3666111"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[47], \"6999000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4515522", timeStamp: "1510169699", hash: "0x9a930c5601710014fa8f6fcb4665c36ec5f90ebd9616abbb94927879af3b373c", nonce: "23", blockHash: "0xeb02758e4b11bfff76616d729d8b8496499432bdd6cc9de0f6ce43a44124f338", transactionIndex: "167", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba40000000000000000000000007c9a8e8ee938e709dbdcab3708c155605a2bfb960000000000000000000000000000000000000000000000006121716aeef58000", contractAddress: "", cumulativeGasUsed: "5851402", gasUsed: "156950", confirmations: "3219254"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[47]}, {type: "uint256", name: "_weiAmount", value: "6999000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[47], "6999000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1510169699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x7c9a8e8ee938e709dbdcab3708c155605a2bfb96"}, {name: "weiAmount", type: "uint256", value: "6999000000000000000"}, {name: "tokenAmount", type: "uint256", value: "583250"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[48], \"13997250000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515529", timeStamp: "1510169836", hash: "0x6f50315c7e120c2d502d62959b3629fbe2ce9011ae241252d7e42908a0703354", nonce: "24", blockHash: "0xde1c0bf8066b2b7ee4c341473f2519161ce46405d30641434c66513624a48340", transactionIndex: "100", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba4000000000000000000000000feee5f6e86648a393ac1ba5379145b9b9039ac6a000000000000000000000000000000000000000000000000c24038b6e2562000", contractAddress: "", cumulativeGasUsed: "3790225", gasUsed: "156999", confirmations: "3219247"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[48]}, {type: "uint256", name: "_weiAmount", value: "13997250000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[48], "13997250000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1510169836 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0xfeee5f6e86648a393ac1ba5379145b9b9039ac6a"}, {name: "weiAmount", type: "uint256", value: "13997250000000000000"}, {name: "tokenAmount", type: "uint256", value: "1555250"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[49], \"8996250000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4515541", timeStamp: "1510170010", hash: "0xc1c71122291a652f8a60a80d161866460ba5c3099b293bd357234d8b67bfd814", nonce: "25", blockHash: "0xab2463a20cbb1be0c90c64cb7e9f05762e801b396fa43228984962327dd04a85", transactionIndex: "108", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba4000000000000000000000000a0af7354f37e644f27d6197ef23be3bf387923b10000000000000000000000000000000000000000000000007cd919b5f89ba000", contractAddress: "", cumulativeGasUsed: "4510048", gasUsed: "156950", confirmations: "3219235"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[49]}, {type: "uint256", name: "_weiAmount", value: "8996250000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[49], "8996250000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1510170010 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0xa0af7354f37e644f27d6197ef23be3bf387923b1"}, {name: "weiAmount", type: "uint256", value: "8996250000000000000"}, {name: "tokenAmount", type: "uint256", value: "749687"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: investOtherCrypto( addressList[50], \"21499000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4515562", timeStamp: "1510170249", hash: "0x74ea6a7f7f08e8b0f861fcc003594c280ef1dd82afa697773eab626fd0bbd001", nonce: "26", blockHash: "0xed3f4a03387bbf40c1c6a0d99eac07b9bd08a5a6a71d84464a21c88bafcbc606", transactionIndex: "98", from: "0x2be3334e328e9599f697acd8ac29775e450151f2", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x0a20aba40000000000000000000000000487d6a462e412662ae692056a76261bd0e3cec40000000000000000000000000000000000000000000000012a5bca97ea1f8000", contractAddress: "", cumulativeGasUsed: "3880254", gasUsed: "157063", confirmations: "3219214"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "receiver", value: addressList[50]}, {type: "uint256", name: "_weiAmount", value: "21499000000000000000"}], name: "investOtherCrypto", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "investOtherCrypto(address,uint256)" ]( addressList[50], "21499000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1510170249 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "InvestedOtherCrypto", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InvestedOtherCrypto", events: [{name: "investor", type: "address", value: "0x0487d6a462e412662ae692056a76261bd0e3cec4"}, {name: "weiAmount", type: "uint256", value: "21499000000000000000"}, {name: "tokenAmount", type: "uint256", value: "2388777"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4515592", timeStamp: "1510170710", hash: "0xb312f387317af3bb49cd56962667fb9cf96ab990e80a4a7df63918853cf28584", nonce: "0", blockHash: "0xade6ef177cfef88b4fec1975f194602c5e395b4624abe62ba7b7384ab7d97450", transactionIndex: "12", from: "0x6e9ec43d29c62c8521bbc7e0a344701fe92dc0c0", to: "0x1818403c06ed28c55d533b526ae8566ec31d87d3", value: "120000000000000000", gas: "162400", gasPrice: "24000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "522804", gasUsed: "161951", confirmations: "3219184"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[51], to: addressList[2], value: "120000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1510170710 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x6e9ec43d29c62c8521bbc7e0a344701fe92dc0c0"}, {name: "weiAmount", type: "uint256", value: "120000000000000000"}, {name: "tokenAmount", type: "uint256", value: "10000"}], address: "0x1818403c06ed28c55d533b526ae8566ec31d87d3"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[51], balance: "377294000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[51], balance: ( await web3.eth.getBalance( addressList[51], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
