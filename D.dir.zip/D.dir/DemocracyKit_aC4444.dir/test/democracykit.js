const DemocracyKit = artifacts.require( "./DemocracyKit.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "DemocracyKit" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x705Cd9a00b87Bb019a87beEB9a50334219aC4444", "0x4cB3FD420555A09bA98845f0B816e45cFb230983", "0x595B34C93aA2c2ba0A38daEEdE629a0DfBDcc559", "0x314159265dD8dbb310642f98f50C066173C1259b", "0x909d05F384D0663eD4BE59863815aB43b4f347Ec", "0x546aA2EaE2514494EeaDb7bbb35243348983C59d", "0xfe507b1930A9460762f1D5b815aCF3E725697C6B", "0x625236038836CecC532664915BD0399647E7826b", "0x6df927e5555EaAc1AA90994A2906a7b916FFF4d8", "0xcA1F6d7d8E902617f8Bdd87866e00f9844C40a77", "0x3e71daBC6E05755Dc3d45175dEACABf6eA6b59c9", "0x50d271519510c55B15408C2C6aeed69800694EF4", "0xe31A0b2CaB18a62295a855C44955D1E99fE6dD1D", "0x0053e4814aAdBd8b2fCF86B4B2Aac9d8c909ef81", "0xF627E5F4BAd95a956468d8BB6Ee20b119F992E96", "0xa60F448D42518b598192312bBa5B5Ba1AbdD2C10", "0x1b1b6cAfD129220Cd3Ed0fCc0e6871b16BFCcd8f", "0x62A6f216A30135E185728f598DaF10BbA29D5c43", "0x1fED6704b5a0Bfb3102fC4A1576C1Ce4Db38acA8", "0x5E69F8D7a28A6518346C97cdE8a4173A4b22Fa4d", "0x9d0c3bFF441Ab2e521bD249CF4bc63d94217fD78", "0xE0a97c2634C0b1D2530B2F92E46697460692cA0c"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "minimeFac", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ens", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "fac", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "appId", type: "bytes32"}], name: "latestVersionAppBase", outputs: [{name: "base", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "aragonID", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "appIds", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}], name: "DeployInstance", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["DeployToken(address,address)", "DeployInstance(address,address)", "DeployInstance(address)", "InstalledApp(address,bytes32)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x07ab516ad4f19b4465f15fa7c2dbc064f18e734a0846d6e0932da244aa3d8a71", "0x4fa65b7b4efeaaebcd718c22be4cbfe3339447deee05146fa2ef6d9578015fd3", "0x8f42a14c9fe9e09f4fe8eeee69ae878731c838b6497425d4c30e1d09336cf34b", "0x2b183a501d4b1bbd30e6611ebac40ab18a00390e6c6bed324bf92a265c9ce6e3"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6593257 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6613949 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_fac", value: 4}, {type: "address", name: "_ens", value: 5}, {type: "address", name: "_minimeFac", value: 6}, {type: "address", name: "_aragonID", value: 7}, {type: "bytes32[4]", name: "_appIds", value: ["0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae", "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f", "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1", "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"]}], name: "DemocracyKit", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "minimeFac", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimeFac()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ens", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ens()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "fac", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fac()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "appId", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "latestVersionAppBase", outputs: [{name: "base", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "latestVersionAppBase(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "aragonID", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "aragonID()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "appIds", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "appIds(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "DemocracyKit", function( accounts ) {

	it( "TEST: DemocracyKit( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6593257", timeStamp: "1540645706", hash: "0x4f2629308f508c971b5321d275c0305167f79fdca42932b14315a8814cf3ea5f", nonce: "101", blockHash: "0x9e4b6ff6720d7d066f64ae571eeddf9f2fcdfa92bd9f15d29fcac8e1f980021b", transactionIndex: "24", from: "0x4cb3fd420555a09ba98845f0b816e45cfb230983", to: 0, value: "0", gas: "5900000", gasPrice: "10000000001", isError: "0", txreceipt_status: "1", input: "0x319ed0c8000000000000000000000000595b34c93aa2c2ba0a38daeede629a0dfbdcc559000000000000000000000000314159265dd8dbb310642f98f50c066173c1259b000000000000000000000000909d05f384d0663ed4be59863815ab43b4f347ec000000000000000000000000546aa2eae2514494eeadb7bbb35243348983c59dbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d19fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4", contractAddress: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", cumulativeGasUsed: "3888810", gasUsed: "3199882", confirmations: "1141297"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fac", value: addressList[4]}, {type: "address", name: "_ens", value: addressList[5]}, {type: "address", name: "_minimeFac", value: addressList[6]}, {type: "address", name: "_aragonID", value: addressList[7]}, {type: "bytes32[4]", name: "_appIds", value: ["0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae","0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f","0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1","0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"]}], name: "DemocracyKit", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = DemocracyKit.new( addressList[4], addressList[5], addressList[6], addressList[7], ["0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae","0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f","0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1","0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540645706 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = DemocracyKit.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "272881690079230255" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Genesis`, `DAO` )", async function( ) {
		const txOriginal = {blockNumber: "6593307", timeStamp: "1540646378", hash: "0x0fba4c7244c8dfe6b35c225d333026509b0595919cf6464597d118b7ebfcd509", nonce: "0", blockHash: "0x469f0e6861d9295c95c652202293d56c5a304ddb07f47e68ec6fb2ff8e77fd6a", transactionIndex: "13", from: "0xfe507b1930a9460762f1d5b815acf3e725697c6b", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "2643667", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000747656e6573697300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000344414f0000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2561785", gasUsed: "1738528", confirmations: "1141247"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Genesis`}, {type: "string", name: "symbol", value: `DAO`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Genesis`, `DAO`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540646378 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0xa72081b69f7335d81fa474e5a81ceebb33979448"}, {name: "cacheOwner", type: "address", value: "0xfe507b1930a9460762f1d5b815acf3e725697c6b"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "85544686651377948" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `genesis`, [addressList[8]], [\"10000000... )", async function( ) {
		const txOriginal = {blockNumber: "6593345", timeStamp: "1540646865", hash: "0xd4515a0723a7bb521c0465b549973c04cb281c64fc2dc7091edf88ec821e1dfb", nonce: "1", blockHash: "0x2a3db0df9750497c3b03c7d452d109aaf8067fa5a735640f4a535e27c2a95476", transactionIndex: "20", from: "0xfe507b1930a9460762f1d5b815acf3e725697c6b", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "6000000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000015180000000000000000000000000000000000000000000000000000000000000000767656e65736973000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000fe507b1930a9460762f1d5b815acf3e725697c6b00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "5950330", gasUsed: "4793565", confirmations: "1141209"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `genesis`}, {type: "address[]", name: "holders", value: [addressList[8]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "500000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "10000000000000000"}, {type: "uint64", name: "voteDuration", value: "86400"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `genesis`, [addressList[8]], ["1000000000000000000"], "500000000000000000", "10000000000000000", "86400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540646865 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0x8a83d4bce45b4c4f751f76cf565953d1e4a3bf0a"}, {name: "token", type: "address", value: "0xa72081b69f7335d81fa474e5a81ceebb33979448"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x9058a97f27925cd6298224879c912e9b2343fdeb"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x56ee376956374d70886049fa0a86727481319501"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x98516c82bda8b3de6e2670b718848949ae6a4643"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xef6faa213bd0a63f871152532c03c652099a1394"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "85544686651377948" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `111`, `11` )", async function( ) {
		const txOriginal = {blockNumber: "6610555", timeStamp: "1540890436", hash: "0xcee012d8f925f8a9f71370d1c37d576c85af54ab7cc930dff2c14ed234a6053f", nonce: "16", blockHash: "0xceda4efa5cb5597db5b316c488675ffb41f077d7592a6587f76dad61fa4d1dd6", transactionIndex: "85", from: "0xfe507b1930a9460762f1d5b815acf3e725697c6b", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938338", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000003313131000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000023131000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5609093", gasUsed: "1738208", confirmations: "1123999"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `111`}, {type: "string", name: "symbol", value: `11`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `111`, `11`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540890436 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x2df8873efc65a3c2613893abc489c19cf895e892"}, {name: "cacheOwner", type: "address", value: "0xfe507b1930a9460762f1d5b815acf3e725697c6b"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "85544686651377948" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Honey`, `HNY` )", async function( ) {
		const txOriginal = {blockNumber: "6611115", timeStamp: "1540897913", hash: "0x85fb5594f1c41b4f919a2b89c76e277a1fec96d71683c7df47df8c091b32c8b5", nonce: "1", blockHash: "0xb2db67bed819e6d3cd11d166d19a366eeb81804cb9ea3fea550dd88443e010a5", transactionIndex: "116", from: "0x625236038836cecc532664915bd0399647e7826b", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938549", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000005486f6e65790000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003484e590000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7438210", gasUsed: "1738400", confirmations: "1123439"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Honey`}, {type: "string", name: "symbol", value: `HNY`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Honey`, `HNY`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540897913 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x334fb326bc81966afeae27fc342b075d0919f506"}, {name: "cacheOwner", type: "address", value: "0x625236038836cecc532664915bd0399647e7826b"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "257656084236131062" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Honey`, `HNY` )", async function( ) {
		const txOriginal = {blockNumber: "6611124", timeStamp: "1540898084", hash: "0xb242341b0abd68bd3acbac8aaf141fdeac0520d259e741926a6f5c2afcefe6b1", nonce: "2", blockHash: "0x5598cf0b15fdde63115eb8ecf1b174093b530d33f9a396cc01b001ad0f6d5887", transactionIndex: "176", from: "0x625236038836cecc532664915bd0399647e7826b", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938549", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000005486f6e65790000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003484e590000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6584439", gasUsed: "1723400", confirmations: "1123430"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Honey`}, {type: "string", name: "symbol", value: `HNY`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Honey`, `HNY`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540898084 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x63bf8c32602555fcc44691790bff84ea44851a07"}, {name: "cacheOwner", type: "address", value: "0x625236038836cecc532664915bd0399647e7826b"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "257656084236131062" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `1hive`, [addressList[9]], [\"1000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6611131", timeStamp: "1540898178", hash: "0x69cc7535165dcf254a66b7128e83c0ef40aec3e754b26a21f181c5f0b957c9f9", nonce: "3", blockHash: "0x0ea6c0c90663921e162151f12a223da6e9d1abeb40fadadc5caecbf243fd0567", transactionIndex: "50", from: "0x625236038836cecc532664915bd0399647e7826b", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448325", gasPrice: "6600000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000015180000000000000000000000000000000000000000000000000000000000000000531686976650000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000625236038836cecc532664915bd0399647e7826b00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6897104", gasUsed: "4793437", confirmations: "1123423"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `1hive`}, {type: "address[]", name: "holders", value: [addressList[9]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "500000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "10000000000000000"}, {type: "uint64", name: "voteDuration", value: "86400"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `1hive`, [addressList[9]], ["1000000000000000000"], "500000000000000000", "10000000000000000", "86400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540898178 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0xdaf9bec2fdca88c43f587781c73f4d2ae049f48a"}, {name: "token", type: "address", value: "0x63bf8c32602555fcc44691790bff84ea44851a07"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[6,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x1a84085a3e019b542857fc14a9c0c8833439d0ed"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x9213737fbb72d8f924fca55d508ae2c004413d64"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x5ad3c83c49d5f0e0c2a3b3520bf2170c3272ffa8"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xbc5231084d86d26a09a2c63100431da7b63d6a5f"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[6,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "257656084236131062" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Consensys Token`, `CNSYS` )", async function( ) {
		const txOriginal = {blockNumber: "6611223", timeStamp: "1540899690", hash: "0x1204825ea497dd759c7e5a3bdd6fbfe19d0c2e705f5245582509c7c72fad7e6a", nonce: "5", blockHash: "0x430fbe4a99de21757156fe1a739f37c3b97e6c6a62ae2b8c19f6a35e23eff8ec", transactionIndex: "53", from: "0x625236038836cecc532664915bd0399647e7826b", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1939394", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000f436f6e73656e73797320546f6b656e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005434e535953000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4180846", gasUsed: "1739168", confirmations: "1123331"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Consensys Token`}, {type: "string", name: "symbol", value: `CNSYS`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Consensys Token`, `CNSYS`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540899690 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0xd862f6387f505799dcf32187d2b7c1dd6c82b1b4"}, {name: "cacheOwner", type: "address", value: "0x625236038836cecc532664915bd0399647e7826b"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "257656084236131062" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Consensys Token`, `CNSYS` )", async function( ) {
		const txOriginal = {blockNumber: "6611229", timeStamp: "1540899745", hash: "0x00c2bffb69310785e3c8d5407b3348a7d62dbeb4ded2ef24ed8a72dfe8105d01", nonce: "6", blockHash: "0x8ad4027c1188c3ece23a6a1dc6f8a027665ea34cd05454fc275132c90743ac5f", transactionIndex: "27", from: "0x625236038836cecc532664915bd0399647e7826b", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1939394", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000f436f6e73656e73797320546f6b656e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005434e535953000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2978779", gasUsed: "1724168", confirmations: "1123325"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Consensys Token`}, {type: "string", name: "symbol", value: `CNSYS`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Consensys Token`, `CNSYS`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540899745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x8cab24fb1000d0cdce286612a6cf3c13dda604d0"}, {name: "cacheOwner", type: "address", value: "0x625236038836cecc532664915bd0399647e7826b"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "257656084236131062" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `consensys`, [addressList[9]], [\"100000... )", async function( ) {
		const txOriginal = {blockNumber: "6611232", timeStamp: "1540899807", hash: "0x289eac6756609ae018c4b6ff287173637c2a3b3f67b81e603339be8f2d0afc76", nonce: "7", blockHash: "0xf02091711b58491d72c115b4c52160e2e04efc92f745e2b61f4f72a12c4c2440", transactionIndex: "29", from: "0x625236038836cecc532664915bd0399647e7826b", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448607", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000002386f26fc1000000000000000000000000000000000000000000000000000000000000000151800000000000000000000000000000000000000000000000000000000000000009636f6e73656e73797300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000625236038836cecc532664915bd0399647e7826b00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "5931703", gasUsed: "4793693", confirmations: "1123322"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `consensys`}, {type: "address[]", name: "holders", value: [addressList[9]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "500000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "10000000000000000"}, {type: "uint64", name: "voteDuration", value: "86400"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `consensys`, [addressList[9]], ["1000000000000000000"], "500000000000000000", "10000000000000000", "86400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540899807 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0x90a2aa12d5e04b5894234dcaf29cf12db500d97e"}, {name: "token", type: "address", value: "0x8cab24fb1000d0cdce286612a6cf3c13dda604d0"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x5220cf349ba754b44d31cd2e2a69f07f6ee68f81"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xce17d9587081314e29cc3189181e4898ed2b67a1"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xf5b0bdb416c5314310234c7ab82c01a844394ae4"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xff5727830399819b8e03f30c2a2b0dc170d5f204"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "257656084236131062" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Maria Token`, `MAR` )", async function( ) {
		const txOriginal = {blockNumber: "6611249", timeStamp: "1540900000", hash: "0x3aeccb8f7db821d168132162093f2464bcff6a58f3163c4286e0f35e987f930d", nonce: "0", blockHash: "0xb1d743f460391655360049759af2263e43fd809ed25ab6d2cefe9b923727ca69", transactionIndex: "82", from: "0x6df927e5555eaac1aa90994a2906a7b916fff4d8", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938971", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000b4d6172696120546f6b656e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034d41520000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6310530", gasUsed: "1738784", confirmations: "1123305"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Maria Token`}, {type: "string", name: "symbol", value: `MAR`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Maria Token`, `MAR`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540900000 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0xbf87a59fc7cdf3107741f570130ce529306e92bb"}, {name: "cacheOwner", type: "address", value: "0x6df927e5555eaac1aa90994a2906a7b916fff4d8"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "7153088268851857272" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `maria`, [addressList[10]], [\"100000000... )", async function( ) {
		const txOriginal = {blockNumber: "6611254", timeStamp: "1540900025", hash: "0x81592401bd9d642b0b7a5eecdecbaffcaf4b393e22b89d40b5c61a422637a259", nonce: "1", blockHash: "0x1312563a5d57bc2fea08d2c06e1e1d5a357763cf482062f9b9a7800468c6c185", transactionIndex: "46", from: "0x6df927e5555eaac1aa90994a2906a7b916fff4d8", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448396", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000713e24c437300000000000000000000000000000000000000000000000000000214e8348c4f0000000000000000000000000000000000000000000000000000000000000003f48000000000000000000000000000000000000000000000000000000000000000056d6172696100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000006df927e5555eaac1aa90994a2906a7b916fff4d800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "7271630", gasUsed: "4793501", confirmations: "1123300"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `maria`}, {type: "address[]", name: "holders", value: [addressList[10]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "510000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "150000000000000000"}, {type: "uint64", name: "voteDuration", value: "259200"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `maria`, [addressList[10]], ["1000000000000000000"], "510000000000000000", "150000000000000000", "259200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540900025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0xa3ff2560ad449a0cda0adf720b7f80030917d05b"}, {name: "token", type: "address", value: "0xbf87a59fc7cdf3107741f570130ce529306e92bb"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[11,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xc26757da350966d6fe95256c490c32f8f82620bc"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x2c73f0a53d4478efbabaf39a801d4acd7dc4ece8"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x33110dd92ba3e61d2ec21b2b0e9d2d0b539f5835"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xb086016d28632250cc736ee9fd9b44678731caa9"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[11,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "7153088268851857272" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `DesignDAO`, `DSGN` )", async function( ) {
		const txOriginal = {blockNumber: "6611650", timeStamp: "1540905625", hash: "0x19f1eb24eda6a0f98e3c355963c1a86477310da87c2429dc7aca778d1eab65cb", nonce: "0", blockHash: "0xc29f3ab55366ab9e5ddbbc5344f79b036dc2f67531bbc3172e3ff15b58ab0462", transactionIndex: "113", from: "0xca1f6d7d8e902617f8bdd87866e00f9844c40a77", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938901", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000944657369676e44414f000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000044453474e00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6386771", gasUsed: "1738720", confirmations: "1122904"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `DesignDAO`}, {type: "string", name: "symbol", value: `DSGN`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `DesignDAO`, `DSGN`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540905625 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x8d4a9db61d8142e8fc4373842eca316d192fa81e"}, {name: "cacheOwner", type: "address", value: "0xca1f6d7d8e902617f8bdd87866e00f9844c40a77"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "238905135804161108" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Luis Token`, `LUIS` )", async function( ) {
		const txOriginal = {blockNumber: "6611664", timeStamp: "1540905854", hash: "0xdf194b45092e00f6c677379343ddf2628c47cc0f1888eb329c81626f6c4eeab4", nonce: "4", blockHash: "0xdd15cc759bdc172194a55f912648e6c2346bdec46c725b6abbf3e9d74f088768", transactionIndex: "92", from: "0x3e71dabc6e05755dc3d45175deacabf6ea6b59c9", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938971", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a4c75697320546f6b656e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000044c55495300000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5765403", gasUsed: "1738784", confirmations: "1122890"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Luis Token`}, {type: "string", name: "symbol", value: `LUIS`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Luis Token`, `LUIS`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540905854 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x3f5b8a1af1f405da2f5b49fca6567cc4dd8fb165"}, {name: "cacheOwner", type: "address", value: "0x3e71dabc6e05755dc3d45175deacabf6ea6b59c9"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "105802482221166390" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `designdao`, [addressList[11]], [\"10000... )", async function( ) {
		const txOriginal = {blockNumber: "6611674", timeStamp: "1540905975", hash: "0x238ca199686969efa4b43d582a7712f4db50c2c82c8352636c63a6a41ac4034c", nonce: "1", blockHash: "0xea5ab04593ca720821b9cb5699d0fefba5832088b4047ee535f7da3d25c46f1e", transactionIndex: "28", from: "0xca1f6d7d8e902617f8bdd87866e00f9844c40a77", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448607", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000214e8348c4f0000000000000000000000000000000000000000000000000000000000000002a300000000000000000000000000000000000000000000000000000000000000000964657369676e64616f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ca1f6d7d8e902617f8bdd87866e00f9844c40a7700000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6095985", gasUsed: "4793693", confirmations: "1122880"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `designdao`}, {type: "address[]", name: "holders", value: [addressList[11]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "500000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "150000000000000000"}, {type: "uint64", name: "voteDuration", value: "172800"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `designdao`, [addressList[11]], ["1000000000000000000"], "500000000000000000", "150000000000000000", "172800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540905975 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0xd6ca28de548abc025fc6ed9ce2a8c89c8467c51f"}, {name: "token", type: "address", value: "0x8d4a9db61d8142e8fc4373842eca316d192fa81e"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[14,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x6d62b500c5d258a8f89af81716f7d0efb41dface"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xbd43d9e9a959b2107cde49051dc9d6ce9ce22788"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x6a5a86db1a7489b8bb5d0a57f00cbd9d7f44b6f0"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x9487d0f8a5a344b5415a97ede0801554b327c0fb"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[14,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "238905135804161108" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Luis Token`, `LUIS` )", async function( ) {
		const txOriginal = {blockNumber: "6611675", timeStamp: "1540905988", hash: "0x0751699b9e921a1f6e0a725d444f70903d83b64cbe260ae61f2e9fe65f94bd76", nonce: "5", blockHash: "0x88b3f73301209e614ec7149eb8f20bde90ab4f60506b73e4c6225f12a8b81d2f", transactionIndex: "73", from: "0x3e71dabc6e05755dc3d45175deacabf6ea6b59c9", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938971", gasPrice: "8304346624", isError: "0", txreceipt_status: "1", input: "0x4629ffea00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a4c75697320546f6b656e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000044c55495300000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5353499", gasUsed: "1723784", confirmations: "1122879"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Luis Token`}, {type: "string", name: "symbol", value: `LUIS`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Luis Token`, `LUIS`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540905988 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x6896305246b6c68ef3e09629442d5d37cee3ab81"}, {name: "cacheOwner", type: "address", value: "0x3e71dabc6e05755dc3d45175deacabf6ea6b59c9"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "105802482221166390" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `luis`, [addressList[12]], [\"1000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6611692", timeStamp: "1540906268", hash: "0x08d01b598b3c158d33008e230eb40e10311549412b62ea192821e97386aad4a7", nonce: "6", blockHash: "0x7621f951e87ed549c0f3eb4e91ddd765c523b044e578335e40e199548c79caaa", transactionIndex: "71", from: "0x3e71dabc6e05755dc3d45175deacabf6ea6b59c9", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448325", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000006f05b59d3b2000000000000000000000000000000000000000000000000000003782dace9d900000000000000000000000000000000000000000000000000000000000000093a8000000000000000000000000000000000000000000000000000000000000000046c7569730000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000003e71dabc6e05755dc3d45175deacabf6ea6b59c900000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "7309971", gasUsed: "4793437", confirmations: "1122862"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `luis`}, {type: "address[]", name: "holders", value: [addressList[12]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "500000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "250000000000000000"}, {type: "uint64", name: "voteDuration", value: "604800"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `luis`, [addressList[12]], ["1000000000000000000"], "500000000000000000", "250000000000000000", "604800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540906268 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0xf4353b07aa47dac0eaf3b614a70b0488961d7ad3"}, {name: "token", type: "address", value: "0x6896305246b6c68ef3e09629442d5d37cee3ab81"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x0554a8e81d6bdcc7b30e01a5016124e46df7961e"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x4ff5844b32e7f024fefcca4a7cfebcc12b357777"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xef0cc2dd5cfb670bc866dd5d2a84946c2f8546a4"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x094f832d34a07d576d26a7c91237083c712157f5"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "105802482221166390" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `LUKE`, `LUKE` )", async function( ) {
		const txOriginal = {blockNumber: "6611695", timeStamp: "1540906298", hash: "0xe29b9ce17affa6e4954e491fbaf5017b291ab9863b5fc8ab8b7cb6a46ca7f089", nonce: "24", blockHash: "0xc1e3702761702f99982999104a48632ff7dd52be62bce1666259843d5bc292b5", transactionIndex: "65", from: "0x625236038836cecc532664915bd0399647e7826b", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938549", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000044c554b450000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000044c554b4500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6210002", gasUsed: "1738400", confirmations: "1122859"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `LUKE`}, {type: "string", name: "symbol", value: `LUKE`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `LUKE`, `LUKE`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540906298 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x8c5010398407c14445c9bffb6326f2332d4d8e19"}, {name: "cacheOwner", type: "address", value: "0x625236038836cecc532664915bd0399647e7826b"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "257656084236131062" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `LUKE`, `LUKE` )", async function( ) {
		const txOriginal = {blockNumber: "6611700", timeStamp: "1540906335", hash: "0xd1fe7d8920b7876797a6b6cadd959ac10de49968c99f50f2846108585de0ccf9", nonce: "25", blockHash: "0xca2c2a95b5be6abc756e1900ae5be12c8e3d3fdbc170945026639dcbf4854503", transactionIndex: "72", from: "0x625236038836cecc532664915bd0399647e7826b", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938549", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000044c554b450000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000044c554b4500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3415431", gasUsed: "1723400", confirmations: "1122854"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `LUKE`}, {type: "string", name: "symbol", value: `LUKE`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `LUKE`, `LUKE`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540906335 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x39f375fdc59e531ae7d92538fa3f6f6bf599b90d"}, {name: "cacheOwner", type: "address", value: "0x625236038836cecc532664915bd0399647e7826b"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "257656084236131062" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `luke`, [addressList[9]], [\"10000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6611708", timeStamp: "1540906494", hash: "0x521d221f939963705254fc0fe0fc4fbda3fc5f1ed85f802c1f768699f09296e4", nonce: "26", blockHash: "0x19b596b1fe032b16cd4d4ccd161ea0292ea7d903e8e78349c94f4f32246d8915", transactionIndex: "29", from: "0x625236038836cecc532664915bd0399647e7826b", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448255", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000093a8000000000000000000000000000000000000000000000000000000000000000046c756b65000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000625236038836cecc532664915bd0399647e7826b00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "5794220", gasUsed: "4793373", confirmations: "1122846"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `luke`}, {type: "address[]", name: "holders", value: [addressList[9]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "500000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "10000000000000000"}, {type: "uint64", name: "voteDuration", value: "604800"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `luke`, [addressList[9]], ["1000000000000000000"], "500000000000000000", "10000000000000000", "604800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540906494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0xdf07aa953adde834651f55c1549a52e68b205d87"}, {name: "token", type: "address", value: "0x39f375fdc59e531ae7d92538fa3f6f6bf599b90d"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[19,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x05ff4d9ba715e7f57bfcf4033eb698f6836008ea"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x352edaaf49984c8d19cace5e408dd8e170bc9e77"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xffa4aa49fd8aa7f4aebc7762c618c19ca6fb2582"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xd081a913ce87bbd9cdc8d273b7e3530646b7d561"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[19,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "257656084236131062" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Jouni`, `JOU` )", async function( ) {
		const txOriginal = {blockNumber: "6611711", timeStamp: "1540906535", hash: "0xa162b4f4842eaed37c5051949d861313a265f0869d63eb0ae4804209849793df", nonce: "2", blockHash: "0xf36c99e77deeb074be05f8ac5b89b3cf084810104f75c278a9198d48bc2cd876", transactionIndex: "23", from: "0xca1f6d7d8e902617f8bdd87866e00f9844c40a77", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938549", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000054a6f756e6900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034a4f550000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4186175", gasUsed: "1738400", confirmations: "1122843"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Jouni`}, {type: "string", name: "symbol", value: `JOU`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Jouni`, `JOU`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540906535 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x568a51ddb77b0520d2a3ee0ac269637299adce4b"}, {name: "cacheOwner", type: "address", value: "0xca1f6d7d8e902617f8bdd87866e00f9844c40a77"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "238905135804161108" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Pierre`, `PIE` )", async function( ) {
		const txOriginal = {blockNumber: "6611728", timeStamp: "1540906837", hash: "0x6f289719b5025b53d07e86f08d23ace228349f8337966cc8c70044ca1c6d211f", nonce: "0", blockHash: "0xae2f32d4c9dca2405db585fb9f3ea37669de07be6f63aa05959faa62a7fd4c58", transactionIndex: "4", from: "0x50d271519510c55b15408c2c6aeed69800694ef4", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938619", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000006506965727265000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000035049450000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3829843", gasUsed: "1738464", confirmations: "1122826"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Pierre`}, {type: "string", name: "symbol", value: `PIE`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Pierre`, `PIE`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540906837 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x2fec0509b3b2f8a5bde917ff48b4ce86bea9c59d"}, {name: "cacheOwner", type: "address", value: "0x50d271519510c55b15408c2c6aeed69800694ef4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "68193698279773384" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `jouni`, [addressList[11]], [\"100000000... )", async function( ) {
		const txOriginal = {blockNumber: "6611732", timeStamp: "1540906874", hash: "0x1d5469bc3fc514cecf63b02f2d8f97a0b2c7fce980daaa67f03ea3f69278337a", nonce: "3", blockHash: "0x1cfd54a960a697aa735661e2a304722f53740eccf35a631d03d387b818794586", transactionIndex: "21", from: "0xca1f6d7d8e902617f8bdd87866e00f9844c40a77", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448396", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000214e8348c4f0000000000000000000000000000000000000000000000000000000000000001518000000000000000000000000000000000000000000000000000000000000000056a6f756e690000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ca1f6d7d8e902617f8bdd87866e00f9844c40a7700000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "5428964", gasUsed: "4793501", confirmations: "1122822"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `jouni`}, {type: "address[]", name: "holders", value: [addressList[11]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "500000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "150000000000000000"}, {type: "uint64", name: "voteDuration", value: "86400"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `jouni`, [addressList[11]], ["1000000000000000000"], "500000000000000000", "150000000000000000", "86400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540906874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0x028677ee4ebe2525b515bd1db8cdf748290d29ee"}, {name: "token", type: "address", value: "0x568a51ddb77b0520d2a3ee0ac269637299adce4b"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[22,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xe8ca1b7dfaebd00a87e8cd074929f59ce42ff8c9"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xd6e0169d945b42c5d0745e2a441e7e13e25ef34e"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x1ce0f0f4d6c23a10d2cae12079e8d7da30ee654f"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x6c6f25385e113ce8d476f7704e7844602e31ba57"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[22,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "238905135804161108" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `pierre`, [addressList[13]], [\"10000000... )", async function( ) {
		const txOriginal = {blockNumber: "6611737", timeStamp: "1540907004", hash: "0xb9b22886326fe1067d5e07d0e0a29b9af8cba476fd56888df10bd5540ce15f23", nonce: "1", blockHash: "0x8f3b6e7834ad55988aec5af85a780545d7c3cd8c32d35513b139e6fe815906fa", transactionIndex: "41", from: "0x50d271519510c55b15408c2c6aeed69800694ef4", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448396", gasPrice: "9906250000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000214e8348c4f0000000000000000000000000000000000000000000000000000000000000001518000000000000000000000000000000000000000000000000000000000000000067069657272650000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000050d271519510c55b15408c2c6aeed69800694ef400000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6113621", gasUsed: "4793501", confirmations: "1122817"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `pierre`}, {type: "address[]", name: "holders", value: [addressList[13]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "500000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "150000000000000000"}, {type: "uint64", name: "voteDuration", value: "86400"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `pierre`, [addressList[13]], ["1000000000000000000"], "500000000000000000", "150000000000000000", "86400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540907004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0xac725f446a61ed8da25691ccf087962e081bce35"}, {name: "token", type: "address", value: "0x2fec0509b3b2f8a5bde917ff48b4ce86bea9c59d"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[23,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x74c3121bd345ecb63fcb701bf837c9d41b1c93eb"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x9affa411cb231020e3c71dc49ddeccd7619f55e8"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x645dd8d15280c000889b51c65c000cd0ccb55761"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xd28ce08f519606613e76e5dfa136a3ca12d7d543"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[23,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "68193698279773384" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Smokyish`, `SMOKY` )", async function( ) {
		const txOriginal = {blockNumber: "6612027", timeStamp: "1540910645", hash: "0x82f9810d3401d1298a2d36ddb125103f237497d7ab60238ac56588e644cc00b7", nonce: "117", blockHash: "0xef1b03ff64214a16f24f304ac61b30534ed67d9e54c2ece4944df3bdba61e61f", transactionIndex: "62", from: "0xe31a0b2cab18a62295a855c44955d1e99fe6dd1d", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938901", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000008536d6f6b796973680000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005534d4f4b59000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6055176", gasUsed: "1738720", confirmations: "1122527"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Smokyish`}, {type: "string", name: "symbol", value: `SMOKY`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Smokyish`, `SMOKY`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540910645 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x64be8c00a06377c97d0961c10f3e99227c59d859"}, {name: "cacheOwner", type: "address", value: "0xe31a0b2cab18a62295a855c44955d1e99fe6dd1d"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "778784267800000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Smokyish`, `SMOKY` )", async function( ) {
		const txOriginal = {blockNumber: "6612029", timeStamp: "1540910666", hash: "0x659735e5167b800e5684826e7b17a32c5a04a5a825569937390e01252f9d6dc9", nonce: "118", blockHash: "0x919110cb91c38de32823e03b3e9ab32afb1e67f349541a3f4cbf0b72fe415b1b", transactionIndex: "19", from: "0xe31a0b2cab18a62295a855c44955d1e99fe6dd1d", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938901", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000008536d6f6b796973680000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005534d4f4b59000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5898080", gasUsed: "1723720", confirmations: "1122525"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Smokyish`}, {type: "string", name: "symbol", value: `SMOKY`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Smokyish`, `SMOKY`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540910666 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x34a28cccccedb807f7343c999acaed8614d09be6"}, {name: "cacheOwner", type: "address", value: "0xe31a0b2cab18a62295a855c44955d1e99fe6dd1d"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "778784267800000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `CuendeZeng`, `CZT` )", async function( ) {
		const txOriginal = {blockNumber: "6612088", timeStamp: "1540911404", hash: "0x99e3269a91e3dff8e6da31ba9de0a460b21ed526c15aa28dacb7ca8b51997fc3", nonce: "0", blockHash: "0xb80694d1dcd1985b245f59ea442963cae22dd1cd29e41d29900e3f7006ce477a", transactionIndex: "101", from: "0x0053e4814aadbd8b2fcf86b4b2aac9d8c909ef81", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938901", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a4375656e64655a656e67000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003435a540000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7495759", gasUsed: "1738720", confirmations: "1122466"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `CuendeZeng`}, {type: "string", name: "symbol", value: `CZT`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `CuendeZeng`, `CZT`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540911404 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x18cf8050712875b08c2b3139686ce41682791767"}, {name: "cacheOwner", type: "address", value: "0x0053e4814aadbd8b2fcf86b4b2aac9d8c909ef81"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `couple`, [addressList[15]], [\"10000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612095", timeStamp: "1540911525", hash: "0xc60a1d0ccfc6ee3cb2f9f53647d28a61a6fb4e164a3303702d6e6b42f4ea714d", nonce: "1", blockHash: "0xbaa730224bfe8efd72e623cceae3183f82ef86b8a44c6fcafee1e2c9faad91a9", transactionIndex: "53", from: "0x0053e4814aadbd8b2fcf86b4b2aac9d8c909ef81", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448677", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000dd0adac1b5a63d70000000000000000000000000000000000000000000000000dd0adac1b5a63d700000000000000000000000000000000000000000000000000000000000151800000000000000000000000000000000000000000000000000000000000000006636f75706c65000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000053e4814aadbd8b2fcf86b4b2aac9d8c909ef8100000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "7011447", gasUsed: "4793757", confirmations: "1122459"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `couple`}, {type: "address[]", name: "holders", value: [addressList[15]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "995486472353768407"}, {type: "uint64", name: "minAcceptanceQuorum", value: "995486472353768407"}, {type: "uint64", name: "voteDuration", value: "86400"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `couple`, [addressList[15]], ["1000000000000000000"], "995486472353768407", "995486472353768407", "86400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540911525 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0xa092ef957538cd20e08a558aa1884e01a0529670"}, {name: "token", type: "address", value: "0x18cf8050712875b08c2b3139686ce41682791767"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x6a6060adb7b4b38a3738e33806b66a8caa419b74"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xcdb249a27cd7ce6b2bd38d841bf9d1cb6649e6a5"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xd4fef800ffe9bc7916e1f157d2af7c73e1b25bb5"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x46632a78afc60e24514c3ebcd37eabcafab252e7"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `DAO`, `DAO` )", async function( ) {
		const txOriginal = {blockNumber: "6612184", timeStamp: "1540913033", hash: "0xcea9b06fe72ed8adf7bd990abd0eec920b67091cde3b1ab8f1b1cc6a61cb5aa7", nonce: "100", blockHash: "0xed2a4550064cf5fae5d26d210b303d29c3e5fb4756400ff55ec97c1b433a1bd9", transactionIndex: "27", from: "0xf627e5f4bad95a956468d8bb6ee20b119f992e96", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938408", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000344414f0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000344414f0000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7533493", gasUsed: "1738272", confirmations: "1122370"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `DAO`}, {type: "string", name: "symbol", value: `DAO`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `DAO`, `DAO`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540913033 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x914babe73f5627335830a6aa4561d93ae4b1ea5d"}, {name: "cacheOwner", type: "address", value: "0xf627e5f4bad95a956468d8bb6ee20b119f992e96"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "580123377485448213" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `cripto2020`, `CPO20` )", async function( ) {
		const txOriginal = {blockNumber: "6612293", timeStamp: "1540914481", hash: "0xc81b70af5b07627ff3f1ead8aca33d310f541e2edffed7a3419cfe8382823805", nonce: "8", blockHash: "0xb9892dcb32b6124997e9ce50fb121216b34422460f599a48dae9f29bdf07545a", transactionIndex: "12", from: "0xa60f448d42518b598192312bba5b5ba1abdd2c10", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1939042", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a63726970746f3230323000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000543504f3230000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2059422", gasUsed: "1738848", confirmations: "1122261"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `cripto2020`}, {type: "string", name: "symbol", value: `CPO20`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `cripto2020`, `CPO20`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540914481 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0xa9ae349552f694f79eb2b390772ba8c1aa6b0a8b"}, {name: "cacheOwner", type: "address", value: "0xa60f448d42518b598192312bba5b5ba1abdd2c10"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "5072973200000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `cripto2020`, [addressList[17]], [\"1000... )", async function( ) {
		const txOriginal = {blockNumber: "6612298", timeStamp: "1540914528", hash: "0xd5f5b2796d024b5f3b5dfdb31591d734fd8e922b761cc0286e5c09a8408e5afc", nonce: "9", blockHash: "0x0b71a4c59f1815da21207ceba11777f713705f42d7a5e60834534884a574408d", transactionIndex: "25", from: "0xa60f448d42518b598192312bba5b5ba1abdd2c10", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448748", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000003782dace9d90000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000015180000000000000000000000000000000000000000000000000000000000000000a63726970746f32303230000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000a60f448d42518b598192312bba5b5ba1abdd2c1000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "5965732", gasUsed: "4793821", confirmations: "1122256"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `cripto2020`}, {type: "address[]", name: "holders", value: [addressList[17]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "250000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "100000000000000000"}, {type: "uint64", name: "voteDuration", value: "86400"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `cripto2020`, [addressList[17]], ["1000000000000000000"], "250000000000000000", "100000000000000000", "86400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540914528 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0x0906d5585325b5917fd303096d41eab754ba07dc"}, {name: "token", type: "address", value: "0xa9ae349552f694f79eb2b390772ba8c1aa6b0a8b"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xfe6b2cae37795d19258698bd89bbcd472cf71560"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x3bf52d6fb53c908064f8ffbe390088ebf27452d9"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x1fa9ab66728ff5f664fc5fbc673b7783f1e48617"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x6658c13cb45c336e8111d01f6f47ea55484e8e29"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "5072973200000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Smokyish`, `SMOKY` )", async function( ) {
		const txOriginal = {blockNumber: "6612569", timeStamp: "1540918453", hash: "0x80f59b1883244c13c7edf4200fa771dd03667317b5e52b1007da37773e9d17b4", nonce: "119", blockHash: "0x3b0e8b19ac32cd70e52befc682d00eb525d3ff8515eeb23413432708459f57cd", transactionIndex: "7", from: "0xe31a0b2cab18a62295a855c44955d1e99fe6dd1d", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "6638901", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000008536d6f6b796973680000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005534d4f4b59000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2157408", gasUsed: "1723720", confirmations: "1121985"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Smokyish`}, {type: "string", name: "symbol", value: `SMOKY`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Smokyish`, `SMOKY`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540918453 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0xddce926536b48b09e68e17bfe91d1d942c678179"}, {name: "cacheOwner", type: "address", value: "0xe31a0b2cab18a62295a855c44955d1e99fe6dd1d"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "778784267800000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `asdf`, `ASDF` )", async function( ) {
		const txOriginal = {blockNumber: "6612588", timeStamp: "1540918709", hash: "0x9059c30c992f9ada90c8add2d5ab2392d533731541faaff7aa40e5791a5a811a", nonce: "120", blockHash: "0x4db92891071411f8b6a5a85bf0f8cd8a88ee4203d4a3a397081e3aa4cf9e37e9", transactionIndex: "15", from: "0xe31a0b2cab18a62295a855c44955d1e99fe6dd1d", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938549", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000004617364660000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000044153444600000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6004267", gasUsed: "1723400", confirmations: "1121966"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `asdf`}, {type: "string", name: "symbol", value: `ASDF`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `asdf`, `ASDF`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540918709 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0xbca4049f4ee73a52bf44d6d2ef02fc3cfcd2eccb"}, {name: "cacheOwner", type: "address", value: "0xe31a0b2cab18a62295a855c44955d1e99fe6dd1d"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "778784267800000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Smokyish`, `SMOKY` )", async function( ) {
		const txOriginal = {blockNumber: "6612588", timeStamp: "1540918709", hash: "0xc7767418a0d44b521dfbfb2ab5dcc1ed593386b6658ad0aecf847909f559c9e4", nonce: "121", blockHash: "0x4db92891071411f8b6a5a85bf0f8cd8a88ee4203d4a3a397081e3aa4cf9e37e9", transactionIndex: "16", from: "0xe31a0b2cab18a62295a855c44955d1e99fe6dd1d", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938901", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000008536d6f6b796973680000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005534d4f4b59000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7727987", gasUsed: "1723720", confirmations: "1121966"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Smokyish`}, {type: "string", name: "symbol", value: `SMOKY`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Smokyish`, `SMOKY`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540918709 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x192613441e8342eadd49d6a0f1036fbf96b99505"}, {name: "cacheOwner", type: "address", value: "0xe31a0b2cab18a62295a855c44955d1e99fe6dd1d"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "778784267800000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `LISEZMOI`, `LSZM` )", async function( ) {
		const txOriginal = {blockNumber: "6612634", timeStamp: "1540919513", hash: "0xe29374ac6e8d6e638bcd59ee539fd5397018276ce034edd9b6ce4462c33fd26d", nonce: "5", blockHash: "0x2bf97e5427c9195e7209e2889d5289876aea0ccda07af83755b30b95102c4706", transactionIndex: "71", from: "0x50d271519510c55b15408c2c6aeed69800694ef4", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938830", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000084c4953455a4d4f4900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000044c535a4d00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5635676", gasUsed: "1738656", confirmations: "1121920"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `LISEZMOI`}, {type: "string", name: "symbol", value: `LSZM`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `LISEZMOI`, `LSZM`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540919513 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x19ccf9d8fad81f1266d7ba5ec693eaf8fefa0a54"}, {name: "cacheOwner", type: "address", value: "0x50d271519510c55b15408c2c6aeed69800694ef4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "68193698279773384" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Gargantua`, `GARG` )", async function( ) {
		const txOriginal = {blockNumber: "6612638", timeStamp: "1540919581", hash: "0x868d49042769c6c805092fa2832e70e23c3d8b4ace72a0e08bbf79531a46bb19", nonce: "723", blockHash: "0x57de33316737f017148343f82625a0e6b1c8d5ec0b5b3418d0dfeefbfbc08e6a", transactionIndex: "96", from: "0x1b1b6cafd129220cd3ed0fcc0e6871b16bfccd8f", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938901", gasPrice: "10900000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000947617267616e747561000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000044741524700000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7122552", gasUsed: "1738720", confirmations: "1121916"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Gargantua`}, {type: "string", name: "symbol", value: `GARG`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Gargantua`, `GARG`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540919581 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x3ca5047660a1db01670432536644a923f99be64f"}, {name: "cacheOwner", type: "address", value: "0x1b1b6cafd129220cd3ed0fcc0e6871b16bfccd8f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "357105893136693682102" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `lisezmoi`, [addressList[13]], [\"100000... )", async function( ) {
		const txOriginal = {blockNumber: "6612639", timeStamp: "1540919601", hash: "0x0c20fa693e8ac4dafe13b3a4cf28a110138ca604d505b2bd5f0a17f6784c6938", nonce: "6", blockHash: "0x0a8eee2cbb928f1a7fda66843feb7d59d7f245b0d3e350605b7d9eb834681554", transactionIndex: "48", from: "0x50d271519510c55b15408c2c6aeed69800694ef4", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448537", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000214e8348c4f0000000000000000000000000000000000000000000000000000000000000001518000000000000000000000000000000000000000000000000000000000000000086c6973657a6d6f69000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000050d271519510c55b15408c2c6aeed69800694ef400000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6465813", gasUsed: "4793629", confirmations: "1121915"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `lisezmoi`}, {type: "address[]", name: "holders", value: [addressList[13]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "500000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "150000000000000000"}, {type: "uint64", name: "voteDuration", value: "86400"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `lisezmoi`, [addressList[13]], ["1000000000000000000"], "500000000000000000", "150000000000000000", "86400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540919601 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0x58a57102b88d60fa27494bb18db30c203e565abf"}, {name: "token", type: "address", value: "0x19ccf9d8fad81f1266d7ba5ec693eaf8fefa0a54"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[36,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xe7f5284d2460e6e8fd7c6e7b4610c6d1459ea370"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x327faae1d68cb6722cca4b12102864c28127b116"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x16a2cfe7ce08e11a340039650ad90a6cfa09d4cb"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xdd781178972fe65c072ac2ed925db7dec34eddb2"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[36,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "68193698279773384" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `gargantua`, [addressList[18]], [\"10000... )", async function( ) {
		const txOriginal = {blockNumber: "6612643", timeStamp: "1540919657", hash: "0x8ed37c1c2d533f8bd6dfd50d2dfa604a67b6f4bc4af731498f9dbf0b0fb3cbeb", nonce: "724", blockHash: "0x2baa392195088a2674197ac297d931ed3c51bf67e04b0f681cd1c102e5f31afd", transactionIndex: "30", from: "0x1b1b6cafd129220cd3ed0fcc0e6871b16bfccd8f", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448677", gasPrice: "10900000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000006f05b59d3b2000000000000000000000000000000000000000000000000000002c68af0bb1400000000000000000000000000000000000000000000000000000000000000015180000000000000000000000000000000000000000000000000000000000000000967617267616e747561000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000001b1b6cafd129220cd3ed0fcc0e6871b16bfccd8f00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6205726", gasUsed: "4793757", confirmations: "1121911"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `gargantua`}, {type: "address[]", name: "holders", value: [addressList[18]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "500000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "200000000000000000"}, {type: "uint64", name: "voteDuration", value: "86400"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `gargantua`, [addressList[18]], ["1000000000000000000"], "500000000000000000", "200000000000000000", "86400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540919657 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0x0cd37d0164c18b839a3e6052403a99a1dcab6113"}, {name: "token", type: "address", value: "0x3ca5047660a1db01670432536644a923f99be64f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[37,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x092fa017f6e3a0a2e70ff9592d5f9c0970af30e0"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xb1403a430e2b15a21bbee9590043e89f4b882e5a"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xd70c94f3d6b5505aa40cd8872a33c8e22c3d26d5"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x18cea47accc5a2f7eac607112afb1d96f374e212"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[37,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "357105893136693682102" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `wooomp`, `WOMP` )", async function( ) {
		const txOriginal = {blockNumber: "6612659", timeStamp: "1540919893", hash: "0x977de6ca836349451c956f6b87382399c7d17265ea6fe8790d0b24b52aadc41f", nonce: "27", blockHash: "0xdf62334fdd70857c9e068f5d4d7ddd148e587bddd95ab8ed71383578874a12ce", transactionIndex: "108", from: "0x62a6f216a30135e185728f598daf10bba29d5c43", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "210000", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000006776f6f6f6d7000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004574f4d5000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5442641", gasUsed: "204927", confirmations: "1121895"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `wooomp`}, {type: "string", name: "symbol", value: `WOMP`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `wooomp`, `WOMP`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540919893 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "85443412702435185" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `wooomp`, `WOMP` )", async function( ) {
		const txOriginal = {blockNumber: "6612671", timeStamp: "1540920074", hash: "0x4f34a2bda21725684f8b37da38d76bd524c790e9a42ed17d07d78303bf15862d", nonce: "28", blockHash: "0xa8cbc05b75d864b17144df53a3dab590440b10e2caf417909f258c60b118e6af", transactionIndex: "74", from: "0x62a6f216a30135e185728f598daf10bba29d5c43", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938690", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000006776f6f6f6d7000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004574f4d5000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5119277", gasUsed: "1738528", confirmations: "1121883"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `wooomp`}, {type: "string", name: "symbol", value: `WOMP`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `wooomp`, `WOMP`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540920074 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x05a721759e60804b6c1de802e621fc9146cc7279"}, {name: "cacheOwner", type: "address", value: "0x62a6f216a30135e185728f598daf10bba29d5c43"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "85443412702435185" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `wooomp`, [addressList[19]], [\"10000000... )", async function( ) {
		const txOriginal = {blockNumber: "6612678", timeStamp: "1540920250", hash: "0x1b5470589e741b7e92a954ae0f34e7613bc999c0deee71d7eda7b56d08e660cf", nonce: "29", blockHash: "0x8b883e80c77f1e35757add2921be0b80906b122c52848ba7f9f2d0bf5f813e82", transactionIndex: "45", from: "0x62a6f216a30135e185728f598daf10bba29d5c43", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448466", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000214e8348c4f0000000000000000000000000000000000000000000000000000000000000003f4800000000000000000000000000000000000000000000000000000000000000006776f6f6f6d700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000062a6f216a30135e185728f598daf10bba29d5c4300000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6788663", gasUsed: "4793565", confirmations: "1121876"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `wooomp`}, {type: "address[]", name: "holders", value: [addressList[19]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "500000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "150000000000000000"}, {type: "uint64", name: "voteDuration", value: "259200"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `wooomp`, [addressList[19]], ["1000000000000000000"], "500000000000000000", "150000000000000000", "259200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540920250 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0x55bc2610063f80b220e2900adac9d0dac279ebbf"}, {name: "token", type: "address", value: "0x05a721759e60804b6c1de802e621fc9146cc7279"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x88cba40cac6872bf1872a46f91956015b296d0e0"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xa2eb2911903cafc99a507d1e7e4bacddda41052f"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x83c461919601cb9f00ece162b246bb3cab21217b"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xa115c74812cbe946a3501469f29c16682b84f99a"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "85443412702435185" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `LOWTECH`, `LOWTK` )", async function( ) {
		const txOriginal = {blockNumber: "6612876", timeStamp: "1540923362", hash: "0xf470c49830351d63872c8efb2b8ba07f8912bc505c8ce886ee29974197d725b6", nonce: "0", blockHash: "0xe58d026b69086f555b04854710a82a276e02c1292d31f23f1005fe62a655b34e", transactionIndex: "16", from: "0x1fed6704b5a0bfb3102fc4a1576c1ce4db38aca8", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938830", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000074c4f57544543480000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000054c4f57544b000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2596730", gasUsed: "1738656", confirmations: "1121678"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `LOWTECH`}, {type: "string", name: "symbol", value: `LOWTK`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `LOWTECH`, `LOWTK`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1540923362 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x8265f06b1f3159684f9b50b4e15c0c697d3110f2"}, {name: "cacheOwner", type: "address", value: "0x1fed6704b5a0bfb3102fc4a1576c1ce4db38aca8"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "1012613440000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `Cupcoin`, `CUP` )", async function( ) {
		const txOriginal = {blockNumber: "6613155", timeStamp: "1540927402", hash: "0xe2f7d7e8901fa5d9c9b349fdb63847ae4a828f27e97694ceb2a1097a20d1022e", nonce: "0", blockHash: "0x91b9b10166cd9b8857e565271a2a56d062fb074169d2b52c079ddb15e00cfe0f", transactionIndex: "48", from: "0x5e69f8d7a28a6518346c97cde8a4173a4b22fa4d", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938690", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000007437570636f696e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034355500000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4200340", gasUsed: "1738528", confirmations: "1121399"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Cupcoin`}, {type: "string", name: "symbol", value: `CUP`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `Cupcoin`, `CUP`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540927402 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x0cb5ae49e627af98c86bbcb49ea6f47732b6c0ad"}, {name: "cacheOwner", type: "address", value: "0x5e69f8d7a28a6518346c97cde8a4173a4b22fa4d"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "111958128935186500" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `kotr`, [addressList[21]], [\"1000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6613158", timeStamp: "1540927436", hash: "0xdc0d777ab20e1cd0a4190a62c8cc063d0249e630cde1e33a7476d1144a62edbc", nonce: "1", blockHash: "0xec029fa2245777f8d0bc91e37fc8ea61c62a4e392d947f85d809e4355987cbd1", transactionIndex: "24", from: "0x5e69f8d7a28a6518346c97cde8a4173a4b22fa4d", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448255", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000a688906bd8b00000000000000000000000000000000000000000000000000000a688906bd8b0000000000000000000000000000000000000000000000000000000000000000a8c000000000000000000000000000000000000000000000000000000000000000046b6f74720000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000005e69f8d7a28a6518346c97cde8a4173a4b22fa4d00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "5759906", gasUsed: "4793373", confirmations: "1121396"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `kotr`}, {type: "address[]", name: "holders", value: [addressList[21]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "750000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "750000000000000000"}, {type: "uint64", name: "voteDuration", value: "43200"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `kotr`, [addressList[21]], ["1000000000000000000"], "750000000000000000", "750000000000000000", "43200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540927436 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0x550d6db34f923e57035c1dc58957789a80e5c4fd"}, {name: "token", type: "address", value: "0x0cb5ae49e627af98c86bbcb49ea6f47732b6c0ad"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[43,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xa8c30ba7d6e7596ec1326b14c769b4a62cf85e32"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xcd6c35d30c4dc19dbf9309fc8415bf3a60c521b0"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xa50bf961b498aac971afc12721be892fd1b749bb"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x280af317bfac726bb9231f098bed3778f39fe594"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[43,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "111958128935186500" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `PopMint`, `POPM` )", async function( ) {
		const txOriginal = {blockNumber: "6613510", timeStamp: "1540932372", hash: "0x347b30438ac16b96c31b7bc3e21ccced7650e2fecc077303c4c428f7183239e3", nonce: "0", blockHash: "0x465fca7445c9a1bc896bd8e945f2f4c8504563ceaee0f7ef66b4e2643487f2e2", transactionIndex: "12", from: "0x9d0c3bff441ab2e521bd249cf4bc63d94217fd78", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938760", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000007506f704d696e74000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004504f504d00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2055683", gasUsed: "1738592", confirmations: "1121044"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `PopMint`}, {type: "string", name: "symbol", value: `POPM`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `PopMint`, `POPM`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540932372 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0xfbc367bde057b3f045fa93b380ffd085c4060082"}, {name: "cacheOwner", type: "address", value: "0x9d0c3bff441ab2e521bd249cf4bc63d94217fd78"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "119774474000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `PopMint`, `POPM` )", async function( ) {
		const txOriginal = {blockNumber: "6613522", timeStamp: "1540932519", hash: "0xae44c9aab8bc33c8b4c1cf8bbcd17963b47b6b300cc2252c259f8d3afa1f9afc", nonce: "1", blockHash: "0x9e5a2580e2e700a9ed12c2ea641d617f26e76e1f2a3550700f18f784eba9d9b7", transactionIndex: "2", from: "0x9d0c3bff441ab2e521bd249cf4bc63d94217fd78", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1938760", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000007506f704d696e74000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004504f504d00000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1765592", gasUsed: "1723592", confirmations: "1121032"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `PopMint`}, {type: "string", name: "symbol", value: `POPM`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `PopMint`, `POPM`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540932519 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0xd06779b6b4c43ec9ad9b0282e55153845b1820ea"}, {name: "cacheOwner", type: "address", value: "0x9d0c3bff441ab2e521bd249cf4bc63d94217fd78"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "119774474000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `popmint`, [addressList[22]], [\"1000000... )", async function( ) {
		const txOriginal = {blockNumber: "6613525", timeStamp: "1540932629", hash: "0x9c2cf710a1f4671e102fdfb178dbd9dc22c27b9a07d84648bc2978054cde5b48", nonce: "2", blockHash: "0xc2596928fd49086e7d3e2d100b8ffa70f830ccdc4638c1801770f3b881781cc0", transactionIndex: "41", from: "0x9d0c3bff441ab2e521bd249cf4bc63d94217fd78", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448537", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000006f05b59d3b200000000000000000000000000000000000000000000000000000214e8348c4f000000000000000000000000000000000000000000000000000000000000000151800000000000000000000000000000000000000000000000000000000000000007706f706d696e740000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000009d0c3bff441ab2e521bd249cf4bc63d94217fd7800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "7050212", gasUsed: "4793629", confirmations: "1121029"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `popmint`}, {type: "address[]", name: "holders", value: [addressList[22]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "500000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "150000000000000000"}, {type: "uint64", name: "voteDuration", value: "86400"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `popmint`, [addressList[22]], ["1000000000000000000"], "500000000000000000", "150000000000000000", "86400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540932629 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0xa0ff959150ed4f0100345ce783c216fcbe4d4826"}, {name: "token", type: "address", value: "0xd06779b6b4c43ec9ad9b0282e55153845b1820ea"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x7b2ead8cc8abbbfa6d4d57b35f082243e2cd0942"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x6ebafa0acc58cf987442771224ea4b0a39678d2d"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x5262ce902b54cb9b7f80c5875b9ce6fb3dcede7b"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x0c7ebaed619d5c827044b9b267af4c54bc10da5d"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "119774474000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `One Enterprise`, `ONE` )", async function( ) {
		const txOriginal = {blockNumber: "6613937", timeStamp: "1540938654", hash: "0x857ce9e1c6b0b1d5b7a5ca280561ded907619f1241237e8668cc006da8434c52", nonce: "156", blockHash: "0x4f18ca59fa95b2a92b9514dd2ee33b5f58cf709329639f1f3213e725ecc4e111", transactionIndex: "24", from: "0xe0a97c2634c0b1d2530b2f92e46697460692ca0c", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1939182", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000e4f6e6520456e746572707269736500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034f4e450000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2927103", gasUsed: "1738976", confirmations: "1120617"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `One Enterprise`}, {type: "string", name: "symbol", value: `ONE`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `One Enterprise`, `ONE`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540938654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0xbaeb5b03ff387a5a23e6ae7366dabc6ddf7d1ee5"}, {name: "cacheOwner", type: "address", value: "0xe0a97c2634c0b1d2530b2f92e46697460692ca0c"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "50721805470707177302" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: newToken( `One Enterprise`, `ONE` )", async function( ) {
		const txOriginal = {blockNumber: "6613944", timeStamp: "1540938736", hash: "0x4b493fa1ef30641e8d56a63c249d83e2ad983be6c13596759f40f0f9a3aa6649", nonce: "157", blockHash: "0x778fc223591ce93e28212fb7e3d4401ab65f8863b06845f7dabab608234071b7", transactionIndex: "3", from: "0xe0a97c2634c0b1d2530b2f92e46697460692ca0c", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "1939182", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x4629ffea00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000e4f6e6520456e746572707269736500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034f4e450000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1786976", gasUsed: "1723976", confirmations: "1120610"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `One Enterprise`}, {type: "string", name: "symbol", value: `ONE`}], name: "newToken", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newToken(string,string)" ]( `One Enterprise`, `ONE`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540938736 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "token", type: "address"}, {indexed: true, name: "cacheOwner", type: "address"}], name: "DeployToken", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "DeployToken", events: [{name: "token", type: "address", value: "0x46279a778788060ae0e8f356ef0da085590868b6"}, {name: "cacheOwner", type: "address", value: "0xe0a97c2634c0b1d2530b2f92e46697460692ca0c"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "50721805470707177302" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: newInstance( `one`, [addressList[23]], [\"10000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6613949", timeStamp: "1540938784", hash: "0xcc53561658afc94b4dacd7dfb64206a9abec9e09579a2ced5a2f1b89c4442d63", nonce: "158", blockHash: "0x53116b00a91751f85bc26f8cd8c2ca0d7ec2143fef1fd0b8e4738fa3e7912d9f", transactionIndex: "22", from: "0xe0a97c2634c0b1d2530b2f92e46697460692ca0c", to: "0x705cd9a00b87bb019a87beeb9a50334219ac4444", value: "0", gas: "5448255", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xf1868e8b00000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000713e24c4373000000000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000000000000000003f48000000000000000000000000000000000000000000000000000000000000000036f6e6500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e0a97c2634c0b1d2530b2f92e46697460692ca0c00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6325440", gasUsed: "4793373", confirmations: "1120605"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `one`}, {type: "address[]", name: "holders", value: [addressList[23]]}, {type: "uint256[]", name: "tokens", value: ["1000000000000000000"]}, {type: "uint64", name: "supportNeeded", value: "510000000000000000"}, {type: "uint64", name: "minAcceptanceQuorum", value: "200000000000000000"}, {type: "uint64", name: "voteDuration", value: "259200"}], name: "newInstance", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newInstance(string,address[],uint256[],uint64,uint64,uint64)" ]( `one`, [addressList[23]], ["1000000000000000000"], "510000000000000000", "200000000000000000", "259200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540938784 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "dao", type: "address"}, {indexed: true, name: "token", type: "address"}], name: "DeployInstance", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeployInstance", events: [{name: "dao", type: "address", value: "0xedde8f5fae07678110fadbc97cb092934a7fd47f"}, {name: "token", type: "address", value: "0x46279a778788060ae0e8f356ef0da085590868b6"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "appProxy", type: "address"}, {indexed: false, name: "appId", type: "bytes32"}], name: "InstalledApp", type: "event"} ;
		console.error( "eventCallOriginal[49,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x9a8b596510c672967c78a4060bda4f0e4b7836c5"}, {name: "appId", type: "bytes32", value: "0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xe5359b8cc129bb377c4d5e3700e5bfbe4883add8"}, {name: "appId", type: "bytes32", value: "0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0x3f1f4fe23c7eedaaf014306d744a141cdd3b6971"}, {name: "appId", type: "bytes32", value: "0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}, {name: "InstalledApp", events: [{name: "appProxy", type: "address", value: "0xbddcc29ca2c9cab0e60b4d4d4f0da6208a503bfa"}, {name: "appId", type: "bytes32", value: "0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f"}], address: "0x705cd9a00b87bb019a87beeb9a50334219ac4444"}] ;
		console.error( "eventResultOriginal[49,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "50721805470707177302" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
