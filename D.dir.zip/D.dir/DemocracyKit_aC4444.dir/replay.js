var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "DemocracyKit"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0x705Cd9a00b87Bb019a87beEB9a50334219aC4444","0x4cB3FD420555A09bA98845f0B816e45cFb230983","0x595B34C93aA2c2ba0A38daEEdE629a0DfBDcc559","0x314159265dD8dbb310642f98f50C066173C1259b","0x909d05F384D0663eD4BE59863815aB43b4f347Ec","0x546aA2EaE2514494EeaDb7bbb35243348983C59d","0xfe507b1930A9460762f1D5b815aCF3E725697C6B","0x625236038836CecC532664915BD0399647E7826b","0x6df927e5555EaAc1AA90994A2906a7b916FFF4d8","0xcA1F6d7d8E902617f8Bdd87866e00f9844C40a77","0x3e71daBC6E05755Dc3d45175dEACABf6eA6b59c9","0x50d271519510c55B15408C2C6aeed69800694EF4","0xe31A0b2CaB18a62295a855C44955D1E99fE6dD1D","0x0053e4814aAdBd8b2fCF86B4B2Aac9d8c909ef81","0xF627E5F4BAd95a956468d8BB6Ee20b119F992E96","0xa60F448D42518b598192312bBa5B5Ba1AbdD2C10","0x1b1b6cAfD129220Cd3Ed0fCc0e6871b16BFCcd8f","0x62A6f216A30135E185728f598DaF10BbA29D5c43","0x1fED6704b5a0Bfb3102fC4A1576C1Ce4Db38acA8","0x5E69F8D7a28A6518346C97cdE8a4173A4b22Fa4d","0x9d0c3bFF441Ab2e521bD249CF4bc63d94217fD78","0xE0a97c2634C0b1D2530B2F92E46697460692cA0c"]
addressListOriginal.length = 24
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"minimeFac","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"ens","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"fac","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"appId","type":"bytes32"}],"name":"latestVersionAppBase","outputs":[{"name":"base","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"aragonID","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"appIds","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"}]
eventPrototypeListOriginal = [{"anonymous":false,"inputs":[{"indexed":false,"name":"token","type":"address"},{"indexed":true,"name":"cacheOwner","type":"address"}],"name":"DeployToken","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"dao","type":"address"},{"indexed":true,"name":"token","type":"address"}],"name":"DeployInstance","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"dao","type":"address"}],"name":"DeployInstance","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"appProxy","type":"address"},{"indexed":false,"name":"appId","type":"bytes32"}],"name":"InstalledApp","type":"event"}]
eventSignatureListOriginal = ["DeployToken(address,address)","DeployInstance(address,address)","DeployInstance(address)","InstalledApp(address,bytes32)"]
topicListOriginal = ["0x07ab516ad4f19b4465f15fa7c2dbc064f18e734a0846d6e0932da244aa3d8a71","0x4fa65b7b4efeaaebcd718c22be4cbfe3339447deee05146fa2ef6d9578015fd3","0x8f42a14c9fe9e09f4fe8eeee69ae878731c838b6497425d4c30e1d09336cf34b","0x2b183a501d4b1bbd30e6611ebac40ab18a00390e6c6bed324bf92a265c9ce6e3"]
nBlocksOriginal = 50
fromBlockOriginal = 6593257
toBlockOriginal = 6613949
constructorPrototypeOriginal = {"inputs":[{"type":"address","name":"_fac","value":4},{"type":"address","name":"_ens","value":5},{"type":"address","name":"_minimeFac","value":6},{"type":"address","name":"_aragonID","value":7},{"type":"bytes32[4]","name":"_appIds","value":["0xbf8491150dafc5dcaee5b861414dca922de09ccffa344964ae167212e8c673ae","0x6b20a3010614eeebf2138ccec99f028a61c811b3b1a3343b6ff635985c75c91f","0x7e852e0fcfce6551c13800f1e7476f982525c2b5277ba14b24339c68416336d1","0x9fa3927f639745e587912d4b0fea7ef9013bf93fb907d29faeab57417ba6e1d4"]}],"name":"DemocracyKit","outputs":[],"type":"function"}
FATAL ERROR: CALL_AND_RETRY_LAST Allocation failed - JavaScript heap out of memory
 1: node::Abort() [node]
 2: 0x5627fc42dc91 [node]
 3: v8::Utils::ReportOOMFailure(char const*, bool) [node]
 4: v8::internal::V8::FatalProcessOutOfMemory(char const*, bool) [node]
 5: v8::internal::Factory::NewRawOneByteString(int, v8::internal::PretenureFlag) [node]
 6: v8::internal::Handle<v8::internal::String> v8::internal::JsonParser<true>::SlowScanJsonString<v8::internal::SeqOneByteString, unsigned char>(v8::internal::Handle<v8::internal::String>, int, int) [node]
 7: v8::internal::JsonParser<true>::ParseJsonValue() [node]
 8: v8::internal::JsonParser<true>::ParseJsonObject() [node]
 9: v8::internal::JsonParser<true>::ParseJson() [node]
10: 0x5627fbde105b [node]
11: 0x3895752996dd
