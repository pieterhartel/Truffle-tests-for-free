const DolaCore = artifacts.require( "./DolaCore.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "DolaCore" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x0a00b643a01488cC24eD92CbFF0fC7De15fe7707", "0xD0e2Cb65A343C4A960D4B4348384534919Eb5Cc5", "0x89d24A6b4CcB1B6fAA2625fE562bDD9a23260359", "0xD0ba073bEe6DC9e710DDC15d3F583c5BBBC0788A"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "TOKEN_ADDRESS", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "EIP712_DOMAIN_SEPARATOR_SCHEMA_HASH", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "address"}], name: "requestEpoch", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "EIP712_DOMAIN_HASH", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}], name: "TransferRequestFilled", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["TransferRequestFilled(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xe8648c5df1a8811c588eb6483cd105631e0cf1e6dbd35ef772d740113b64455e"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6872806 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6905298 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_tokenAddress", value: 4}], name: "DolaCore", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "TOKEN_ADDRESS", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "TOKEN_ADDRESS()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "EIP712_DOMAIN_SEPARATOR_SCHEMA_HASH", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "EIP712_DOMAIN_SEPARATOR_SCHEMA_HASH()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "requestEpoch", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "requestEpoch(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "EIP712_DOMAIN_HASH", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "EIP712_DOMAIN_HASH()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "DolaCore", function( accounts ) {

	it( "TEST: DolaCore( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6872806", timeStamp: "1544616303", hash: "0x14d66c53e612748fb79b384a4ef9952edcac451587745cef6773ed8e1a7d1386", nonce: "0", blockHash: "0xe532aa4457375bb48d5b60566f185c9f92c0cee4bfe4af9a1e27166e96bdc859", transactionIndex: "69", from: "0xd0e2cb65a343c4a960d4b4348384534919eb5cc5", to: 0, value: "0", gas: "1119105", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xa01c772400000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359", contractAddress: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", cumulativeGasUsed: "4916932", gasUsed: "1119105", confirmations: "805342"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_tokenAddress", value: addressList[4]}], name: "DolaCore", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = DolaCore.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1544616303 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = DolaCore.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6879648", timeStamp: "1544713315", hash: "0x417410021ba98c73768e461910f31d182d211b6c9122d198c3475f6c3929c337", nonce: "0", blockHash: "0xaeeb3e78d9d80851e0b4c974c075a4377d134e662c5e735c24bb27fe84f18f58", transactionIndex: "208", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "120742", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef674980000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba8300000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000015da83dbda1fc00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041d17766f9cbeabaf55187f7edfe4a01ccf02676054e243391bc187459c800c52163ba0d08f5dce319c0063c4485e776d97549562916689ef1931d8355d053b0b41b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7531518", gasUsed: "120742", confirmations: "798500"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1544713315 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6880280", timeStamp: "1544722292", hash: "0xcd4167dc5d25035841a0fcb9a22175cf4002641f0bcb31443c03a72660b5ec9a", nonce: "1", blockHash: "0x7a31133c9e5708391017d77ea1020493a34317a1e19a69a6c6d72ad8d4aa4230", transactionIndex: "13", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90806", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba830000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef67498000000000000000000000000000000000000000000000000058d15e176280000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000019f112cedc0f000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000414dbf0c20ceabf83304e9f294eb96638037c26f4d3c39bda0c3606de417e514547e6b11b1bec4dd308e16dded39d3c7c24f46d6f6edb1a9efb2edc84f3c0624251c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "703242", gasUsed: "90806", confirmations: "797868"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1544722292 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6880390", timeStamp: "1544723819", hash: "0x9300d8eb375c18e09fe21e9a40ec84face3a49953dc5eb33a05dab6c2ef6c317", nonce: "2", blockHash: "0x09089ac4b9424f054772c66e019bfeb9775f1ed6816d756c31338c21997d3dd0", transactionIndex: "43", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90806", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000c72a7a1587895e04f78ed0c7956c01f8be7bc3b20000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba8300000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000019f112cedc0f000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004198716009c7ea36396ed508ee7bdff05affee6f1407a85485fe9ecbac61739966582e16313b8919d7a5157fa087f1c9938d904457344f7f1d4e3b7b274cc4da2d1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2047752", gasUsed: "90806", confirmations: "797758"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1544723819 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6880534", timeStamp: "1544725952", hash: "0x6c24fb1334f775958c50c1dc829d6f40a50c8cb550ac666c0a7fe9c809f8c828", nonce: "3", blockHash: "0x3b0f49df5cbd08e01261dc71a9549cd958723e1d6c25e7048808f0eb6a1acb76", transactionIndex: "54", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90870", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000000b9a15469aae9941409545e707a33763e94e25f1000000000000000000000000c72a7a1587895e04f78ed0c7956c01f8be7bc3b20000000000000000000000000000000000000000000000001a9fe195d9964000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000012143092f7f0600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041d8a5f82c16e7c82be4016bfd11b8819c02c1de3bcfe92a6e667ac3ff08b0ceff0dd10a5b7aad8e7c4dea2d35e114a194ba6089a7ae0d0d8869376508006730c51c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2653121", gasUsed: "90870", confirmations: "797614"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1544725952 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6880852", timeStamp: "1544730229", hash: "0xc107b96c5214ed76513d283b5b17c1013098236494743ba2f4b231a3dad8e1b9", nonce: "4", blockHash: "0x16ae64ab0e6347fb41ee3321d6f97aef9368ea65289237f1162b610617631ce1", transactionIndex: "110", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75870", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba830000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef6749800000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001319383dfb61100000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041f765765945f9eb817456b49ac91774e9b92a3891aa4d417957b8811ac307d12856ab1e227dc4b7810f7b87e53475c9e11dfc54ae4d2db68b3a90a099c214e5ce1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6101490", gasUsed: "75870", confirmations: "797296"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1544730229 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6881204", timeStamp: "1544735477", hash: "0xa61cfbe7daaebf1e00661986af71dda838b6ec1d8677fde2ddf32b9380c7fc0a", nonce: "5", blockHash: "0xa9e424e9a0f88fe805e6c1996fa3ef40d7f6b21adef566238c4645ae0cb2521e", transactionIndex: "111", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90870", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba830000000000000000000000000f32752b46f6dd95ec59bffe01be6b610966ccab900000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a0000000000000000000000000000000000000000000000000136cc98ef2b7000000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004119f1c474a9264a13c57c6a1fabd872fc016fb7a9307890a805a00a5dc7a4c1981bcfc9179e08a3f44f7970df01ea8d8b37b3353a7350e50cd51bf69f068c4fc01c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6906557", gasUsed: "90870", confirmations: "796944"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1544735477 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6884130", timeStamp: "1544776615", hash: "0x6b7fcf434b6b5a408aab69d95027bc8082807b03595a1e8ea27c44e972ebf055", nonce: "6", blockHash: "0x62da7867dcf2c64f3f7da43cdf4839f892dd5f4aa53e516468c3a5afbca67167", transactionIndex: "77", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90934", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef6749800000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f0000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000013b6af0c560b000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041bd14719823025cb1e359fc62fc3ba34bc1d6a0288cac425bdf47b20b3149073b7b7388e0cb19099bb03ffa3e7c35751367666aa108c4a7601771fd387b81d5121b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2511649", gasUsed: "90934", confirmations: "794018"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1544776615 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6884147", timeStamp: "1544776910", hash: "0x2b07e7dc58e999ecbf447758b300cbb65bd957512d79afee07b1a1b2514672c0", nonce: "7", blockHash: "0x5d6819c201dafb5098cb834d82090034ca50a2e3cd3552afcef42363409c7a30", transactionIndex: "49", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90934", gasPrice: "8000200000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef674980000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000013b6cf58d2a3ec0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004190070547b610fa7977a607aa1bfcc5cb06cf3883686e1ee64a5b544e572f136065dda701cad24b12f0746a1f857c1d6c499bd6b72c241fb86c079b9dc9900a0e1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1956402", gasUsed: "90934", confirmations: "794001"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1544776910 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6884156", timeStamp: "1544777069", hash: "0xde3bf0f9676d61b74a697b9225853f7ec7cc68b5f82c229c4c5cb02ec7b41a3e", nonce: "8", blockHash: "0xc987d314752470d227d8796690b2d538b0693361c90735e52045457fcdcfb3e3", transactionIndex: "54", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75998", gasPrice: "8000200000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f000000000000000000000000f32752b46f6dd95ec59bffe01be6b610966ccab90000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000013b6cf58d2a3ec0000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000418d6e11d4404a5a3dd85b8c31272d566227c8bd39326f287df507e8e146c938570d593b5d1f9702d36ce7f9c9015d126683324a4766afaf4b5e78068c5b485c471c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2466577", gasUsed: "75998", confirmations: "793992"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1544777069 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6884384", timeStamp: "1544780425", hash: "0x7eda45abda9b1d0d94cbf9e1221cc7bdc7e8083418fb7fcf5ff8b53344109d4b", nonce: "9", blockHash: "0x18b47afdba1335994ca2cbb9736a4b20246384499b592606d5971dc250a8e9aa", transactionIndex: "64", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75934", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba830000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef67498000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000018a45acf6b8dc10000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041dfe4101cc6a4a65a47b396c73940f3d77223f78310ce14dde907b88a24dd66b252024b7791a02bd08899a3b3eb07d6dd2f07dfab6c9ad6c7ce1a87d278187e791b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2396736", gasUsed: "75934", confirmations: "793764"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1544780425 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6884393", timeStamp: "1544780627", hash: "0xae5289070d1fdb37639c208981b6925992d9191bbea2bc001323e468a80b95b3", nonce: "10", blockHash: "0x424f86c15897ea7cc6d7d548e395c1d5192c76d4e5cef1f335f99cc7b76fcc4e", transactionIndex: "26", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75870", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef674980000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba8300000000000000000000000000000000000000000000000004d058f98476b0000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000018a45acf6b8dc10000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041695eb04b6f1d93e15239ce5ac908b62ff6898e2d0ddb6b753a2c122e41c5c9d9579a623f1a8da8d8a1a78322da17f9d8b54f9c7fb1508c66b3df6c00024e12581c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "957141", gasUsed: "75870", confirmations: "793755"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1544780627 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6884518", timeStamp: "1544782337", hash: "0x7b6e6af97cac8c32972b5f732742f38646f43371624f919d21552e878077e878", nonce: "11", blockHash: "0x3ec87c18f29e3e611cf09e71b6c5c27024ffbf8d69f24ed0777c294d9a6b94fb", transactionIndex: "67", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75934", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba830000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef67498000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000018a45acf6b8dc10000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041ed310a8cce03ffe15e336ccd5a66abac299be7dcad0308693892eb20b11fa0950c0eab70bfcccc8c6981f712f3f6eef26e851d0d50118f77c7de1e69e73162991c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2821873", gasUsed: "75934", confirmations: "793630"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1544782337 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6884637", timeStamp: "1544784342", hash: "0x87f44e1204b010230a9d4588924f41e586aea5bf686569555af41590b17c57dc", nonce: "12", blockHash: "0x72a8514514524ae5482f00f2d4c873ac154eeaa33673bb13f23d56236b79e6a0", transactionIndex: "48", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75870", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef674980000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba8300000000000000000000000000000000000000000000000000d2f13f7789f0000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000018a39da2a570c00000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004169ad2c0a7e9296feb138735fc25cd343df613398be1ee0360ce9a1369c9fbd8a29ca14bd52aa4b26a3c5d65c9cbb9e26f683dfe114af64a040cf3930ff7bc4f11c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1760242", gasUsed: "75870", confirmations: "793511"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1544784342 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6884732", timeStamp: "1544785589", hash: "0xa4d28af4a254f16f18d157d0d7a3fca643208ca014b5de3287a3e295e3a2ae86", nonce: "13", blockHash: "0xe29e83e400c4c46e42395da714b444f6b1efdd2473ab725a990b9209b48fd1b9", transactionIndex: "173", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75806", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef674980000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba830000000000000000000000000000000000000000000000000058d15e176280000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000018a04a5929ee400000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041554c4136702bef3dff5d648225ba7c7425420c76719100e20911396b8abf72462f899c8ba7d3da145e3ecdd21abf7b46bdb471df38cfc3a5831efae75a0865cb1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7508772", gasUsed: "75806", confirmations: "793416"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1544785589 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6884744", timeStamp: "1544785842", hash: "0x5ba1affbd0fa768383f7ed3feded7c1b06898d1e1b8540db289ce1dabd806f49", nonce: "14", blockHash: "0x67ea710d32b8c258597617d5554dbe929beda120595693be0e1a40f002632898", transactionIndex: "77", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75870", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef674980000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba83000000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000018a04a5929ee400000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000418deac48d73351e152c4c21f02fb125d33bf126455d921a445f178dd135ceccaf18379b1aaa96f0f6f64e590541a1cc41ec3fab35d208d237ab3c821c10b93f471c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4826482", gasUsed: "75870", confirmations: "793404"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1544785842 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6885165", timeStamp: "1544791989", hash: "0xff6dc97f66ddfd931f5a9df84f8bdc48ef1249614055451e0f2ae2e2c48f5c76", nonce: "15", blockHash: "0x464f146f9f9850b5a5de7430131fd9e609ab976fbd82fc9ceaf0fb625fa05668", transactionIndex: "140", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75934", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef674980000000000000000000000000000000000000000000000001bc16d674ec80000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a0000000000000000000000000000000000000000000000000188c85eb7666800000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004150f7f05bbd40203262b9c24a0cab479666052580e8e64b946615c0911fa4c47a3bac503084c37f32f06bfeae78e81546322b91ae01b62d9675db29f70bb418031c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6317890", gasUsed: "75934", confirmations: "792983"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1544791989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6886415", timeStamp: "1544809990", hash: "0xc55d2332e27ad0bcb25c2cedf70812d9db15377e160da1aeeb854c5136eef401", nonce: "16", blockHash: "0xd5cf3ff56a816abb0d58e8b98bbc24fa203b2055931176fb7ace8bf2e8ca22d9", transactionIndex: "7", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90870", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba830000000000000000000000000767854e14263a475a275ce8614c0af83b6ada39400000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a0000000000000000000000000000000000000000000000000181268c4942e400000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000414d799f2b3abf4632a84ed51fc4a4e3d4e82b271ce8d15fdd88671d64c3465f097471e1ac1cfc52128dc20c41852e59f162603b4e257b6195e7acc51eaccbf2251c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "299976", gasUsed: "90870", confirmations: "791733"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1544809990 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6893646", timeStamp: "1544912286", hash: "0x446b82d2131a7d1f21ba7fcc5377e96a856df77997b84717527dbf87dee866ed", nonce: "17", blockHash: "0x80112b2a70f96513a652b901f7c879d9b261e1b990e45f5952dd150cbc20b055", transactionIndex: "43", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75742", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef674980000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000009a2384df277000000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000410044b843d7a1c9989b9135a5c63c0859a78152ed43f5d502639ad6fe47006ffa246fd0588be401566e33a1b87d1d4d46c3991939db5fa4c0ea8c2e82b82c4de21c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2989298", gasUsed: "75742", confirmations: "784502"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1544912286 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6894055", timeStamp: "1544918134", hash: "0xd609ee3c691640f315890a5658d683280d41f43a7694096d894483c201e736c3", nonce: "18", blockHash: "0x14d50f18b0d88d9a6f269f5137eb268a7c70dea9622f7fc4fb82e9c20e7d4960", transactionIndex: "156", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75806", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef6749800000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f0000000000000000000000000000000000000000000000001bc16d674ec80000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000000734748b9ac0000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041bb7639bdde47216a8e5b1bbd24928b8baa9713c61527dc17da9b8ead7283893f5990d9ef7e10033366a0e40e6ec5fcb7fff71a1f1565f52f36616a792edea99b1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7234436", gasUsed: "75806", confirmations: "784093"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1544918134 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6902730", timeStamp: "1545043645", hash: "0x7e6d9cb77b4fb1ff3c4ec9f9ee9e192c08f27400a732577b99fb865432478a98", nonce: "19", blockHash: "0x1b93f0bb681197266969adfeda7758b177a06e7f2211fa4878d50f69f19de155", transactionIndex: "124", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75934", gasPrice: "7800000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef674980000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001349604c1a91000000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000413438ee75a02808d4574b811194ff109571d3f0cf7a905409e5b7847d9ef9b6b368277c31f07ae8aa6445ad90bc229f50c1be04bcba5b1939bca755f94c6ae03a1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5885724", gasUsed: "75934", confirmations: "775418"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1545043645 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6903722", timeStamp: "1545058243", hash: "0xb155d49fdb98909644e1b03af3f2ece489248a378a851085a3f312c4301f7f5e", nonce: "20", blockHash: "0xd59f5ea0ce809a5a4b02f9af90a32906bba3c4c0ecec79afe7c8c50f11bcf6e9", transactionIndex: "64", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90934", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f00000000000000000000000078e31ccc21244c59758e6aeaa7a2f75b2b47a64b0000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000019a72d5178bb000000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000419524617e80ab65b6afe4765f021b3c207c55b8b868f7161cdb1a799b7bb125113ba7290276795a67d4f594a462a36e81536d23073320b5fb3695f7f4109670621c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7068761", gasUsed: "90934", confirmations: "774426"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1545058243 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6903734", timeStamp: "1545058395", hash: "0xed3d1ab10ca257b55b0ce7a4ecab69cb3cc7aca8af4b17d1a5593e1f3ae3b745", nonce: "21", blockHash: "0x6a39dfdcac16ef183c552292c65e357d5128e343f28ce80291f86fd2be3d6b34", transactionIndex: "121", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90870", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f0000000000000000000000008f534808760426a19f6d108f90ffdb232356b1590000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000019a72d5178bb000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041ec438e4a5f8a0f496102eef3a651d2d53814302f31b1445eee5d0e151afce1ae118e0e60fa0035a9bace77958e3fb54602d1c3c60bbb6902d0f172fc537e4b661c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4669632", gasUsed: "90870", confirmations: "774414"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1545058395 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6903749", timeStamp: "1545058567", hash: "0x4fd24bba82f97fae8f155f0c0932113781a438b7b1c509a4df4b934655194ea3", nonce: "22", blockHash: "0x748af226cf3cbb253a60e32f5ad401ab576d27a7111f7fd2d7e5bbf3b9bd0c81", transactionIndex: "37", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90870", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000008f534808760426a19f6d108f90ffdb232356b15900000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000019a72d5178bb000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004126a8cf588559b279092f65d229c71d5c9b288ab1756bc93f720554c207bcc95d74678469ce4e2a073f6fd3156dbb338b3372d93b1918724777cecabc9c7658e81b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1811231", gasUsed: "90870", confirmations: "774399"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1545058567 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6904016", timeStamp: "1545062477", hash: "0x713dbf618c6dc76bb47eeb09bcd62267ba6bbbd5ecb3309c4ff11d7132aadece", nonce: "23", blockHash: "0x01e4eb2dcd8172d3dcb08b8618cef4f6fdf46504ddb1d1fc48b923927af0bab6", transactionIndex: "32", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75934", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef674980000000000000000000000008f534808760426a19f6d108f90ffdb232356b1590000000000000000000000000000000000000000000000001bc16d674ec80000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000019a72d5178bb000000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004117aa219475a9ddab7cbaffae14b45f985d512643880f981c12f5658436a08c682be2c59073ca4a8f0eda5be48f72730b8ff4cd07230d73923a2c68808a640cfb1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1290781", gasUsed: "75934", confirmations: "774132"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1545062477 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6904021", timeStamp: "1545062545", hash: "0x981a15585069a51066776d2f012d9a0b4a9ec12db580ea9ca4b8cab0940e59e4", nonce: "24", blockHash: "0xa5b9f96381ff34605dab03fec643ad533a77a24ffb76147266dc9d3280625990", transactionIndex: "139", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75934", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000008f534808760426a19f6d108f90ffdb232356b159000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef6749800000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000019a72d5178bb000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041047d9c52efa1680ddec508f7e648e6cc94c13bb57dde0cc503a5f2ba59b34beb025cab80a11df2e87fe24d2603cec738bed2a71ea36e44c4742dad2eee93404f1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6288492", gasUsed: "75934", confirmations: "774127"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1545062545 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6904641", timeStamp: "1545071380", hash: "0x2049852dabdc6cc7cfedbc0188778a68cf3ac06a984266f398a33b18de5102c6", nonce: "25", blockHash: "0xc163b5d54c6d56cb12a3755fe907abbb173dc75895c37d1378650da5acf8cbbb", transactionIndex: "40", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75870", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba830000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef6749800000000000000000000000000000000000000000000000009b6e64a8ec60000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000012b08940cd5b400000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041b5dee0cfbf28517bede4fb15844e33094172ac83a51dd62a448c3b40979c868f14c61bea6a716782a43bae5d1a296b1badafeb4cbcda0e2203a4ee5ac881b1651c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2590538", gasUsed: "75870", confirmations: "773507"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1545071380 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6904649", timeStamp: "1545071517", hash: "0x7f8b0dc0e97feb552650c61ac5dbc044970cfb43f2a5a1f7886fc0cbc51cfc9f", nonce: "26", blockHash: "0x1ff591dcea46d66cb5b9bf50aecd77b4ea98588b4f3f85e5a0293ff86a3595ce", transactionIndex: "104", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75870", gasPrice: "6300000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba830000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef67498000000000000000000000000000000000000000000000000013fbe85edc90000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000010d557639d61600000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041bf874d3fa1eac3954b744c8fdb77596ac9345f097fa295a0ded7d625e95755f0668e5883f278e9f54bc320068f0dbab0d75a40eb18faefe699c548d40b87c1b91c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5159612", gasUsed: "75870", confirmations: "773499"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1545071517 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905002", timeStamp: "1545076631", hash: "0xad84181f1f6e55eceb1b9c8e65cf514f3ff913718dfa2dc5dc70ea3605abae47", nonce: "27", blockHash: "0xb635a822948f0bbd61af71821b59babd33d5ea237198996bcefd270f3c041ba7", transactionIndex: "165", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90934", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f000000000000000000000000f5bd22ccd9bc8f622fafa39053d0e8824c43f4170000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001603a3711e54000000000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004125ee92bad98a3c11f8192f1e89ce748205310e8be5547b1c06cac0491f92f8a72b32274036521fff870b7f2a55cb7b0939b3cf4604c6edfca1f568406f9e34551c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6398976", gasUsed: "90934", confirmations: "773146"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1545076631 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905008", timeStamp: "1545076710", hash: "0xb9be845621ff4c7aad2a940c77accda9939891f9d7dba89f9534edcf7801ff5e", nonce: "28", blockHash: "0x451a74555d0a504603d37067507e4e8c281affca0da057908b3e8dde8ad86259", transactionIndex: "96", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90934", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f000000000000000000000000cdb051dcd21509515174f6afa51304409f565f920000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001603a3711e54000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004132e06bdf2164248c893329ac258cf128d94b40ddc99dec842bb85bdaaaa1440e10891e82c53e17340844c1b227cc1f69151cce84f43279c9365c3056b86e1aec1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4975695", gasUsed: "90934", confirmations: "773140"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1545076710 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905013", timeStamp: "1545076845", hash: "0x1c609d7681f7df5d5ebacbc5988b1cd376d9d627bfb0c2b4b2cad4b466d4809a", nonce: "29", blockHash: "0xb6bb94a707060ac76ef3b88932bf00583ed9f06621ffe8369c7353c3fd8e22d6", transactionIndex: "133", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75806", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba830000000000000000000000000f5bd22ccd9bc8f622fafa39053d0e8824c43f417000000000000000000000000000000000000000000000000008e1bc9bf040000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001603a3711e54000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000419b651d0185daeb2aa30d2ec2aea15cb19594b02bf858e0c66d1ce71144f3f16711970df5bb79b1bea488bf36652a5c506647593e7dd990d4ba04a647a5c196a61c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6276422", gasUsed: "75806", confirmations: "773135"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1545076845 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905028", timeStamp: "1545076975", hash: "0x73755b482fd3d3c228ec802cb8c04995033202053a8ad4eb1b2a99235d503b87", nonce: "30", blockHash: "0xa78c66254f092ec3a5ca1e94c846ba267b306d31262d95e5c2524afb15ce3398", transactionIndex: "51", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90934", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f00000000000000000000000067e99d62bca0b39a1d705514226548d4eb8d03130000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001603a3711e54000000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000417fe9a36f41e1b7a2a32d31b2107d1a1d0de030b56de6ff27506cd2eb84ee7fea42cd671650992e9544c27c72ebbaa8ee23977da7678e6ebe24135a256198e8401c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7124558", gasUsed: "90934", confirmations: "773120"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1545076975 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905030", timeStamp: "1545076989", hash: "0x330e7ca61286e96f2ccbfcf6acd09d5e9cedf01ddcdfa4ce343106951dc2ce54", nonce: "31", blockHash: "0x20fd981018a1ea2d5c3d6b7f77f43b316bf7b308ece88de16680d453e5c07dc3", transactionIndex: "29", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90934", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000008f534808760426a19f6d108f90ffdb232356b15900000000000000000000000067e99d62bca0b39a1d705514226548d4eb8d03130000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001603a3711e54000000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000413a7bfeabd08250fe7ba6585b71ce0dd7e088daa42f4ccae279e483556312fa2523515168521d8502fb0fd13d8debfe875b8f2358a74ea059b22f49ef90b5203d1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1222932", gasUsed: "75934", confirmations: "773118"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1545076989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905036", timeStamp: "1545077054", hash: "0x484cd92f7f44e474c1138a07b2c4b75ed366ec7f3e1180749703b1d508cb6dc5", nonce: "32", blockHash: "0x1a493aa53ac3d927f39f3bfb205f103af252ca41120ebad755c485bbb990c006", transactionIndex: "33", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90870", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f000000000000000000000000f0bdefa83ce83a01054a58c6c3589e4659a61a600000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001603a3711e54000000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041005a59cb6d258f867c26209cf49c6c664aa320d5b0ab9a254ff66333048f4f0d1da97986d9e17254358a1337a9a55dcf394812ef2e6a332d0fcd8ad08ec5c4351b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1961162", gasUsed: "90870", confirmations: "773112"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1545077054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905036", timeStamp: "1545077054", hash: "0x425ee521ddddf7119afc7c41e849df7502cd9200b8e8dd0764dfc5c1881a1cad", nonce: "33", blockHash: "0x1a493aa53ac3d927f39f3bfb205f103af252ca41120ebad755c485bbb990c006", transactionIndex: "34", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75870", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000008f534808760426a19f6d108f90ffdb232356b15900000000000000000000000067e99d62bca0b39a1d705514226548d4eb8d031300000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001603a3711e54000000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041b25c25cc0fa303110dac24ae46cec92bb38c14de4a1a6dedaf15b15a7724ef4e33f24f2e481ff1007e8fe3a1269e575eea465bc60cd4ec841a3fe71d014f08eb1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2037032", gasUsed: "75870", confirmations: "773112"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1545077054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905044", timeStamp: "1545077197", hash: "0x4f4185e73cdb9a1bea4d161d77aa5dd56110fd0cfef4ca500ac3169c49baf90a", nonce: "34", blockHash: "0xf62d76a463eff02fabadbc326cbc53040d81ef3b764839d7d747123d36878f3c", transactionIndex: "48", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90934", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f000000000000000000000000e610626c6b75b9cd8267ee38be7cd6ab3b30ac8b0000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001603a3711e54000000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000410c26f769722d80eea04de0217b1e80347307e2ca884f5881cabc1037748386ed58a012abd5833e1636339ac61345a8c37f06ec5b0ca4d51464ad326ef0a014351c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7158740", gasUsed: "90934", confirmations: "773104"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1545077197 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905044", timeStamp: "1545077197", hash: "0x98949adff562fe1780ead0a582688257b3f1c5afe26c3a6918972afcfa58d2eb", nonce: "35", blockHash: "0xf62d76a463eff02fabadbc326cbc53040d81ef3b764839d7d747123d36878f3c", transactionIndex: "49", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90934", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000008f534808760426a19f6d108f90ffdb232356b159000000000000000000000000e610626c6b75b9cd8267ee38be7cd6ab3b30ac8b00000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001603a3711e54000000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041a3b767a14c82cedff2b2c3c16527977187cbaa3147d5ae4f81c9ec1abfbfe50a60d45e865ed2137eb967edf15ade20871f97c74191cc1d01ea856c9e758f35751c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7234674", gasUsed: "75934", confirmations: "773104"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1545077197 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905053", timeStamp: "1545077297", hash: "0xecee6b7b29b9022fe71d80f4eef3743476ced58f5b1cfa34bd17a7c94b9a409f", nonce: "36", blockHash: "0xe4033992ae2e426d6f9c73be1563db71b2011e2507650ce82883772110918c15", transactionIndex: "12", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90870", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f0000000000000000000000006dfdd15c183221d26899ea00ba673e6e98d328880000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000016006312836e000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041719fb604d8e42efb4c3ff9822ada070bf0d2929cd56f7b7eb46f3e2e01e437d122c6e6ba4368dd5fce03f393769a1bc02957c31b45a3529d53a0f1fcf9ca28cc1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1180570", gasUsed: "90870", confirmations: "773095"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1545077297 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905085", timeStamp: "1545077743", hash: "0x9bfa01ee0e0701bf646a318d028a13c047a29703efac6737bbc07896a13a9dc9", nonce: "37", blockHash: "0xedb33f45dea4c0bbcae7b5d7666e3dfca26a5024b36822e1a4506caa078824bc", transactionIndex: "124", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75934", gasPrice: "7800000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef67498000000000000000000000000f5bd22ccd9bc8f622fafa39053d0e8824c43f4170000000000000000000000000000000000000000000000000de444324c2a8000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001603a3711e54000000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004131a487f59142cc00e34e21a76190bc99c815c62ac5ad5f19283c259951928c6202cc8b208e3791054a2bbe2574fe530e4426a35bf33733972ed87b51be8a94711c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4737061", gasUsed: "75934", confirmations: "773063"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1545077743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905085", timeStamp: "1545077743", hash: "0xeb566c343f2644096dcbcc8d88ef522faa93a11100728572e9bf62149c1ed9ff", nonce: "38", blockHash: "0xedb33f45dea4c0bbcae7b5d7666e3dfca26a5024b36822e1a4506caa078824bc", transactionIndex: "125", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90806", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000006dfdd15c183221d26899ea00ba673e6e98d32888000000000000000000000000e610626c6b75b9cd8267ee38be7cd6ab3b30ac8b0000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a0000000000000000000000000000000000000000000000000157393cba68b400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000415243866161975849fd5fcab57bb6d1c2546b756b7fe8f8bd473a86f85af943c07b7fda17b9d5ff809cd6158a0834df262fa6fcc3d9d1ac747167013e97aaf2dc1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4827867", gasUsed: "90806", confirmations: "773063"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1545077743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905091", timeStamp: "1545077813", hash: "0xd73bbaaec61130097dfd2a0534509438e308799b5fd0e5dd8319e1cab4a0c7eb", nonce: "39", blockHash: "0x16c0523661e017d5d1d4c3c0b477f46df9d24c6b28042be24540c3052c84555a", transactionIndex: "118", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75870", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef6749800000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f0000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001603a3711e54000000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041837762bdfac5dc705028bf281fe5004e7fb0651c347d600593fb9ed2cbbfb56a7c49f9eddb76d15d6502b2d63c6d270106588720a1ab33f8b25652c343be6a061b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5189900", gasUsed: "75870", confirmations: "773057"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1545077813 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905094", timeStamp: "1545077913", hash: "0x87ff1341c42d1f98894dcfb3aa6513f8d8e1e85c2a6e7256a6efc17ebd831700", nonce: "40", blockHash: "0x4dc1f59b9c827187f4b84f377a54d68173559afb8d8384f6cc4a2977ee3cff2d", transactionIndex: "38", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75998", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef67498000000000000000000000000e610626c6b75b9cd8267ee38be7cd6ab3b30ac8b0000000000000000000000000000000000000000000000000f6b6b9029efc000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000016006312836e000000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041f53e1fbf71ca23e6940175f553998b1d6b222382450775470fd932543e5ea7401c6a8b6666abe830e17594edbf0fa0baa69c9d071814390704918884b33bc1e31c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2785968", gasUsed: "75998", confirmations: "773054"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1545077913 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905104", timeStamp: "1545078014", hash: "0x5c076909bb3ea034aa4da6321b03e5b50eea517c478b12795937495e421da7d9", nonce: "41", blockHash: "0x6cbda86aa968d1de6974d2d4949fcb2d673e695d8dcc5e5591db45b618205f15", transactionIndex: "64", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90870", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000e610626c6b75b9cd8267ee38be7cd6ab3b30ac8b0000000000000000000000006dfdd15c183221d26899ea00ba673e6e98d32888000000000000000000000000000000000000000000000000025c510c7c4b4000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000016006312836e000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041bc7b6fb8e980cecfe680a286509c59fb87307b7e32cf06e012f8b79aad7ccf70668b201ab13541886bdb6b8d87af1f0d8044c13bbe1faa975ea6a0e9636b82f31c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2728939", gasUsed: "90870", confirmations: "773044"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1545078014 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905107", timeStamp: "1545078050", hash: "0x86d93368f668492badab5fd7e9353858b857c40ea11681467a0fcd2a4962861c", nonce: "42", blockHash: "0xd9fd590932a40b8d92d33d7af321fbb2670d447f9fe607b4bef790013d095be0", transactionIndex: "22", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75934", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef674980000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000016006312836e000000000000000000000000000000000000000000000000000000000000000000d00000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000414077a39113261773f00b1feb5eac8d6a6293ffc0e5a7bb35b43b4b6974f2e133240a6fc1f6b582b8183236661339a3dac3737ca6fc4f71981e8051d261165ce21b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1380266", gasUsed: "75934", confirmations: "773041"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1545078050 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905111", timeStamp: "1545078175", hash: "0xbbfe7cadd100645d34740b62d344762b99c067946cfa6e6cfcbbd1bc6ddd472f", nonce: "43", blockHash: "0x4a3f685e433862f02c9ed86c430b58705632542e0b47aac19fa6684a8e55bd99", transactionIndex: "89", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75742", gasPrice: "7800000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000008f534808760426a19f6d108f90ffdb232356b159000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef6749800000000000000000000000000000000000000000000000000b1a2bc2ec50000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a0000000000000000000000000000000000000000000000000157393cba68b400000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000419e9d2c8dc4b100effa598ab238688b467e0189fa9e1ee6881b9c4fda88e8f270564724109bd8f4a94fbc6b260ac3689c9fa51bd974a600b048bf498523ec25041c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4114685", gasUsed: "75742", confirmations: "773037"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1545078175 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905186", timeStamp: "1545079195", hash: "0xdd7ef33006d9c8967897e64c88cfb3e992171b58be0e79f9d0c4102235b2ee44", nonce: "44", blockHash: "0x0f261da25fba83c7534523b8c1f4829ebea697041f587d300d119162225b840a", transactionIndex: "27", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "90870", gasPrice: "7800000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f0000000000000000000000007a37c8c610c62736f4ac0b03962a37a61550b9120000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a0000000000000000000000000000000000000000000000000157393cba68b400000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000411b12fdd8a716b3d32840c0cac54498d2ca4f80c50e4b3fb986183cdf78cd2ce26147ec4ad8f9af8e3ab9499d13d238b34991ea55ad6600fd339e8ecb7f65dbbf1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1766547", gasUsed: "90870", confirmations: "772962"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1545079195 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905198", timeStamp: "1545079390", hash: "0x1ace0ad9168ffe5cc741f561d2783125254545528d7c290e4b67efe24e013dd8", nonce: "45", blockHash: "0x00e1111240279f3bd7403754c1eb45aa35cdaf96a187cb953c0305463ca1ece5", transactionIndex: "229", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75998", gasPrice: "7403912237", isError: "0", txreceipt_status: "1", input: "0x0d755ef7000000000000000000000000b6cd4bb71efcd27a3b881740c058f4648ef674980000000000000000000000008f534808760426a19f6d108f90ffdb232356b1590000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a0000000000000000000000000000000000000000000000000145cb65e8d5c6a0000000000000000000000000000000000000000000000000000000000000000b00000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041397a1c9d78d1e07ec1a5749c8f88d6b3be1341d86cc5020c354ecfb7e8cdfa277fa9c95d1accbb7d11ebfdb318c3d50f2044cf682681166133a268444c2a83c11c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7587960", gasUsed: "75998", confirmations: "772950"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1545079390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905228", timeStamp: "1545079890", hash: "0x7767f9e58e036323adf1354e55a5074e15ab4e66405ac2bbdbf971ea342d40a3", nonce: "46", blockHash: "0x874b74294affb44bc3631b9a38107668760078079638be6d5694df9af4057287", transactionIndex: "62", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75870", gasPrice: "7800000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000008f534808760426a19f6d108f90ffdb232356b1590000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba8300000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001576bf5b172b800000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004175b8da7fbd0e1e9a455bb3ccce7541be603ecbdfba8493a190815a505002e17452578e4752bc258fd2a41941561898cfa41e013cefeab6e7c7dd337822d8a2071b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4070712", gasUsed: "75870", confirmations: "772920"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1545079890 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905234", timeStamp: "1545079947", hash: "0xc34ba5f62c7727357ec052ef3215c26e4f26ae09ad03ce22b28090c181cad1bb", nonce: "47", blockHash: "0xe2c7cccef7dd9cd38c8c32e9f8420efc20f59130fc3881d789391d8098893e7a", transactionIndex: "27", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75870", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef700000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f0000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba8300000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a00000000000000000000000000000000000000000000000001576bf5b172b800000000000000000000000000000000000000000000000000000000000000000f00000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041b518827083f8bf4d15947d2c64e38bc20ba103bb031370e386a21350b6ff5b9625f99b7f10dd6161981910b31025f83a775423f711637fd41fca7fb443d3a24d1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1083443", gasUsed: "75870", confirmations: "772914"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1545079947 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6905298", timeStamp: "1545080753", hash: "0x861dd651900834c5286de3de8d7687b0bc997ef97fe6d78b4ad7647e1f0b54ab", nonce: "48", blockHash: "0x867093e92b679ca4fcb359917d2908b0de2d4f7c87028fa4990456f58107a619", transactionIndex: "78", from: "0xd0ba073bee6dc9e710ddc15d3f583c5bbbc0788a", to: "0x0a00b643a01488cc24ed92cbff0fc7de15fe7707", value: "0", gas: "75870", gasPrice: "6450000000", isError: "0", txreceipt_status: "1", input: "0x0d755ef70000000000000000000000001db8dc9f61b81e9217ccee87dc040600a29ba83000000000000000000000000005e817d0f1686f749d1b55edd2b85150c38c772f00000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000d0ba073bee6dc9e710ddc15d3f583c5bbbc0788a000000000000000000000000000000000000000000000000011bfbbc666da200000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000041e97be810a8a5e06f745face3f5cd9884f9dd63f72873671a5a87bfa6de8938c97341951519a0fd0dbf2af189fedf5a45f3e7097e971fdd4c45d401240f4775601b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5077660", gasUsed: "75870", confirmations: "772850"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1545080753 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "657243814920210360" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
