const Voterplayer = artifacts.require( "./Voterplayer.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Voterplayer" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x09f05B0876F2D5d0481D5EFDb4166dccB9FbA97D", "0x4129A6151049ac66AED0b7565a7B0f7CD617d0D4", "0x73fAdD839CCC9097bBCC87E1f9Af56157bc47dde", "0xa63a6A5eA2B001E76ba4Fdf4Eed44974772E34a7", "0xFD4efb117f4FE1a19FD6D2bBf6941FaBf6DA77f7", "0xD0669578327887D5eb0d64B6251F297Ff935AcC1", "0xA6705A4E8533e6484937Ad781A3cD3E58Eb525b8", "0xF25Cb16d9D3dcb5AdBc130Be530b24fC34e5dC91", "0x2587D0e234Cab7644A4Ad7444903b368F10a620C", "0xd234Ca4FF8db8de4e3F8d3d95FD59c7249BB63d4"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "uint256"}], name: "_addrs", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_id", type: "uint256"}], name: "getaddresstotal", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getAllPlayer", outputs: [{name: "", type: "address[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalplayers", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "started", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "winnerOfplayer", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "createTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "shutTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "RID", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_address", type: "address"}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalRef", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "EthOtherfee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_address", type: "address"}], name: "getTotalVoter", outputs: [{name: "totals", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "winners", outputs: [{name: "name", type: "uint256"}, {name: "value", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_address", type: "address"}], name: "refereesOf", outputs: [{name: "", type: "address[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_address", type: "address"}, {name: "_id", type: "uint256"}], name: "getTotalForVoter", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "voters", outputs: [{name: "id", type: "uint256"}, {name: "name", type: "uint256"}, {name: "value", type: "uint256"}, {name: "totalplayer", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "fee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "EthOther", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ids", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint256"}, {indexed: false, name: "_name", type: "uint256"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_vectoryvalue", type: "uint256"}], name: "NewVoter", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "isReady", type: "bool"}], name: "gameover", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "NewPlayer", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "isReady", type: "bool"}, {indexed: false, name: "_RID", type: "uint256"}], name: "restart", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "EgiveToVoterOnlyowner", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_address", type: "address"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: false, name: "_bool", type: "bool"}], name: "EgetPlayerCoin", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_ether", type: "uint256"}], name: "Ewithdraw", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_fee", type: "uint256"}], name: "EsetFee", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "Ebuygamecoin", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: false, name: "_totalplayers", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "EgetEveryDayEarnings", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["NewVoter(uint256,uint256,uint256,uint256)", "GiveVoter(address,uint256,uint256)", "gameover(bool)", "NewPlayer(uint256,address)", "restart(bool,uint256)", "EgiveToVoterOnlyowner(uint256,uint256)", "EgetPlayerCoin(address,uint256,bool)", "Ewithdraw(uint256)", "EsetFee(uint256,uint256)", "Ebuygamecoin(uint256,uint256,address)", "EgetEveryDayEarnings(uint256,uint256,uint256,address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x19daed4fce296c0a74aa1d93b2f354b5b1d521c8e6db312bbd9cc70352138f74", "0xf2aec651a179ce90e70dcbd52f8b3dd8ea0584780f92b6b03cf46f470a595f82", "0x7b118c85ef372183e084270dac522e118abb27180b1741552a55ddeca3b74a23", "0x125b747364a9643dd15fc004dbdb094509c65405b7702825907a136178a252a8", "0xca0659cef57c9cfecf8dbadd98464252354cce394e64fea484c180247616dfe5", "0xda7e54d1a9a71276d44d76242eec39dc31a98ca48c35a2fa8b2caaf7c1b6e283", "0xa0b676c1b4f6c4d50180324b5ebf0b05420eb58b980c92c7c7d0d62c537fc8ea", "0x0eba83e7ca4379de12c437f554ad4066ad953867ce4ca04ff0e2c2ffa89e279a", "0x5c7b4923ca98f3c16b15d41e8e3cd73fd47abfb1fb908e24cfe8da257440df6e", "0xc3290138d63dcaef254650f8cb4a3f7db343d5391f7a9c7c5ed9cd0e65b83a1e", "0xf7350dda2a288c44c62237ae68dc66e08ee55f073da3c32d3d9bfef844f7496b", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6645766 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6660451 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Voterplayer", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "_addrs", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_addrs(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_id", value: random.range( maxRandom )}], name: "getaddresstotal", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getaddresstotal(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getAllPlayer", outputs: [{name: "", type: "address[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAllPlayer()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalplayers", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalplayers()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "started", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "started()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "winnerOfplayer", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "winnerOfplayer()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "createTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "createTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "shutTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "shutTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "RID", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "RID()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_address", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalRef", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalRef()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "EthOtherfee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "EthOtherfee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_address", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getTotalVoter", outputs: [{name: "totals", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTotalVoter(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "winners", outputs: [{name: "name", type: "uint256"}, {name: "value", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "winners(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_address", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "refereesOf", outputs: [{name: "", type: "address[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "refereesOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_address", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_id", value: random.range( maxRandom )}], name: "getTotalForVoter", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTotalForVoter(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "voters", outputs: [{name: "id", type: "uint256"}, {name: "name", type: "uint256"}, {name: "value", type: "uint256"}, {name: "totalplayer", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "voters(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "fee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "EthOther", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "EthOther()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ids", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ids()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Voterplayer", function( accounts ) {

	it( "TEST: Voterplayer(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6645766", timeStamp: "1541389385", hash: "0x0432f570d124d912667c3b498326a4503869f169f10ec74a23a182160bf70f7a", nonce: "2", blockHash: "0x49c549eec1288a0e5f7eb7e331bcd1eef75abeae3b22c6cb593dbf5a1a2d667c", transactionIndex: "18", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: 0, value: "0", gas: "3000000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xc1440167", contractAddress: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", cumulativeGasUsed: "4352060", gasUsed: "2847782", confirmations: "1076164"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Voterplayer", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Voterplayer.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541389385 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Voterplayer.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: createAllVoter( [\"130\",\"131\",\"132\",\"133\",\"134\"... )", async function( ) {
		const txOriginal = {blockNumber: "6646456", timeStamp: "1541399763", hash: "0x803e73bc43d5122f732a55e2b40e957114d3295e219e6dc6af4aafbfb993a97c", nonce: "3", blockHash: "0x035542fb04c1dca82658b944eec84900677fe07a131efa61453cb83f72a9c5e0", transactionIndex: "36", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "2000000", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x3470c8a40000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001e00000000000000000000000000000000000000000000000000000000000000820000000000000000000000000000000000000000000000000000000000000083000000000000000000000000000000000000000000000000000000000000008400000000000000000000000000000000000000000000000000000000000000850000000000000000000000000000000000000000000000000000000000000086000000000000000000000000000000000000000000000000000000000000008700000000000000000000000000000000000000000000000000000000000000880000000000000000000000000000000000000000000000000000000000000089000000000000000000000000000000000000000000000000000000000000008a000000000000000000000000000000000000000000000000000000000000008b000000000000000000000000000000000000000000000000000000000000008c000000000000000000000000000000000000000000000000000000000000008d000000000000000000000000000000000000000000000000000000000000008e000000000000000000000000000000000000000000000000000000000000008f0000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000009100000000000000000000000000000000000000000000000000000000000000920000000000000000000000000000000000000000000000000000000000000093000000000000000000000000000000000000000000000000000000000000009400000000000000000000000000000000000000000000000000000000000000950000000000000000000000000000000000000000000000000000000000000096000000000000000000000000000000000000000000000000000000000000009700000000000000000000000000000000000000000000000000000000000000980000000000000000000000000000000000000000000000000000000000000099000000000000000000000000000000000000000000000000000000000000009a000000000000000000000000000000000000000000000000000000000000009b000000000000000000000000000000000000000000000000000000000000009c000000000000000000000000000000000000000000000000000000000000009d000000000000000000000000000000000000000000000000000000000000009e000000000000000000000000000000000000000000000000000000000000009f", contractAddress: "", cumulativeGasUsed: "3858195", gasUsed: "2000000", confirmations: "1075474"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "_voter", value: ["130","131","132","133","134","135","136","137","138","139","140","141","142","143","144","145","146","147","148","149","150","151","152","153","154","155","156","157","158","159"]}], name: "createAllVoter", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: createAllVoter( [\"130\",\"131\",\"132\",\"133\",\"134\"... )", async function( ) {
		const txOriginal = {blockNumber: "6646490", timeStamp: "1541400303", hash: "0xb96572e2d62804a9a8d475faeeab1928010fa930aa61cf9abac285b77a271d8b", nonce: "4", blockHash: "0x5d1cc9b3335389b0462b4cd772a5673e33d91ceb84afdef231b770beb5d59e31", transactionIndex: "32", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "3000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x3470c8a40000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001e00000000000000000000000000000000000000000000000000000000000000820000000000000000000000000000000000000000000000000000000000000083000000000000000000000000000000000000000000000000000000000000008400000000000000000000000000000000000000000000000000000000000000850000000000000000000000000000000000000000000000000000000000000086000000000000000000000000000000000000000000000000000000000000008700000000000000000000000000000000000000000000000000000000000000880000000000000000000000000000000000000000000000000000000000000089000000000000000000000000000000000000000000000000000000000000008a000000000000000000000000000000000000000000000000000000000000008b000000000000000000000000000000000000000000000000000000000000008c000000000000000000000000000000000000000000000000000000000000008d000000000000000000000000000000000000000000000000000000000000008e000000000000000000000000000000000000000000000000000000000000008f0000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000009100000000000000000000000000000000000000000000000000000000000000920000000000000000000000000000000000000000000000000000000000000093000000000000000000000000000000000000000000000000000000000000009400000000000000000000000000000000000000000000000000000000000000950000000000000000000000000000000000000000000000000000000000000096000000000000000000000000000000000000000000000000000000000000009700000000000000000000000000000000000000000000000000000000000000980000000000000000000000000000000000000000000000000000000000000099000000000000000000000000000000000000000000000000000000000000009a000000000000000000000000000000000000000000000000000000000000009b000000000000000000000000000000000000000000000000000000000000009c000000000000000000000000000000000000000000000000000000000000009d000000000000000000000000000000000000000000000000000000000000009e000000000000000000000000000000000000000000000000000000000000009f", contractAddress: "", cumulativeGasUsed: "3291443", gasUsed: "2123632", confirmations: "1075440"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "_voter", value: ["130","131","132","133","134","135","136","137","138","139","140","141","142","143","144","145","146","147","148","149","150","151","152","153","154","155","156","157","158","159"]}], name: "createAllVoter", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createAllVoter(uint256[])" ]( ["130","131","132","133","134","135","136","137","138","139","140","141","142","143","144","145","146","147","148","149","150","151","152","153","154","155","156","157","158","159"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541400303 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint256"}, {indexed: false, name: "_name", type: "uint256"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_vectoryvalue", type: "uint256"}], name: "NewVoter", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewVoter", events: [{name: "_id", type: "uint256", value: "0"}, {name: "_name", type: "uint256", value: "130"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "1"}, {name: "_name", type: "uint256", value: "131"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "2"}, {name: "_name", type: "uint256", value: "132"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "3"}, {name: "_name", type: "uint256", value: "133"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "4"}, {name: "_name", type: "uint256", value: "134"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "5"}, {name: "_name", type: "uint256", value: "135"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "6"}, {name: "_name", type: "uint256", value: "136"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "7"}, {name: "_name", type: "uint256", value: "137"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "8"}, {name: "_name", type: "uint256", value: "138"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "9"}, {name: "_name", type: "uint256", value: "139"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "10"}, {name: "_name", type: "uint256", value: "140"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "11"}, {name: "_name", type: "uint256", value: "141"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "12"}, {name: "_name", type: "uint256", value: "142"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "13"}, {name: "_name", type: "uint256", value: "143"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "14"}, {name: "_name", type: "uint256", value: "144"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "15"}, {name: "_name", type: "uint256", value: "145"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "16"}, {name: "_name", type: "uint256", value: "146"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "17"}, {name: "_name", type: "uint256", value: "147"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "18"}, {name: "_name", type: "uint256", value: "148"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "19"}, {name: "_name", type: "uint256", value: "149"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "20"}, {name: "_name", type: "uint256", value: "150"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "21"}, {name: "_name", type: "uint256", value: "151"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "22"}, {name: "_name", type: "uint256", value: "152"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "23"}, {name: "_name", type: "uint256", value: "153"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "24"}, {name: "_name", type: "uint256", value: "154"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "25"}, {name: "_name", type: "uint256", value: "155"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "26"}, {name: "_name", type: "uint256", value: "156"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "27"}, {name: "_name", type: "uint256", value: "157"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "28"}, {name: "_name", type: "uint256", value: "158"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}, {name: "NewVoter", events: [{name: "_id", type: "uint256", value: "29"}, {name: "_name", type: "uint256", value: "159"}, {name: "_value", type: "uint256", value: "0"}, {name: "_vectoryvalue", type: "uint256", value: "0"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: startGame( \"864000\", addressList[4], \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "6647829", timeStamp: "1541418592", hash: "0x7e46eb69cbd466f8b940549dc993e59d4fdd955bc026d6049a6476605d97f28e", nonce: "7", blockHash: "0x3432258010658ecf6ec0595fc29b16dace500b84251871e1c6e648cb1f686656", transactionIndex: "28", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "3000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x250a8da100000000000000000000000000000000000000000000000000000000000d2f0000000000000000000000000073fadd839ccc9097bbcc87e1f9af56157bc47dde0000000000000000000000000000000000000000000000000000000000000012", contractAddress: "", cumulativeGasUsed: "1037047", gasUsed: "121393", confirmations: "1074101"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_time", value: "864000"}, {type: "address", name: "_address", value: addressList[4]}, {type: "uint256", name: "_decimals", value: "18"}], name: "startGame", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startGame(uint256,address,uint256)" ]( "864000", addressList[4], "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541418592 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "isReady", type: "bool"}, {indexed: false, name: "_RID", type: "uint256"}], name: "restart", type: "event"} ;
		console.error( "eventCallOriginal[3,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "restart", events: [{name: "isReady", type: "bool", value: true}, {name: "_RID", type: "uint256", value: "1"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[3,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"1470000\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6647867", timeStamp: "1541419105", hash: "0xa1d0449744caa4be54ef76d0fb29c5ca907513c57dedcaf73724a91002ea996f", nonce: "1", blockHash: "0x30db746128411955dc05ee01a834da4d6ce5f533591497de360739a4623e0d1e", transactionIndex: "119", from: "0xa63a6a5ea2b001e76ba4fdf4eed44974772e34a7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "49980001000000000000", gas: "401128", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xd5e871fc0000000000000000000000000000000000000000000000000000000000166e30000000000000000000000000a63a6a5ea2b001e76ba4fdf4eed44974772e34a7", contractAddress: "", cumulativeGasUsed: "5627811", gasUsed: "267419", confirmations: "1074063"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "49980001000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "1470000"}, {type: "address", name: "_address", value: addressList[5]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "1470000", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541419105 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[4,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_id", type: "uint256", value: "0"}, {name: "_address", type: "address", value: "0xa63a6a5ea2b001e76ba4fdf4eed44974772e34a7"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[4,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "Ebuygamecoin", type: "event"} ;
		console.error( "eventCallOriginal[4,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Ebuygamecoin", events: [{name: "_time", type: "uint256", value: "1541419105"}, {name: "_number", type: "uint256", value: "1470000"}, {name: "_address", type: "address", value: "0xa63a6a5ea2b001e76ba4fdf4eed44974772e34a7"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[4,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "201572355000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: gameOver(  )", async function( ) {
		const txOriginal = {blockNumber: "6647927", timeStamp: "1541420030", hash: "0x2a814cd244b63caf3ad9be4f3a605ff2269e9569edf240695db1b8696962b5fa", nonce: "8", blockHash: "0x519e07864bdc2efac5109cee2579dcdd74b0bbe85b2388f496bb8e82f2147338", transactionIndex: "20", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "3000000", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0xbdb337d1", contractAddress: "", cumulativeGasUsed: "679605", gasUsed: "22941", confirmations: "1074003"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "gameOver", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gameOver()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541420030 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"1370000\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6647944", timeStamp: "1541420240", hash: "0x965dacafd7b308b6af860f2ee9fae0515aec425826e17b9883e8615f9c040327", nonce: "2", blockHash: "0x52cc3527839569f1fd0dcd5cc184df851d0544826d700059fbfcd1358e317715", transactionIndex: "73", from: "0xa63a6a5ea2b001e76ba4fdf4eed44974772e34a7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "46812807000000000000", gas: "126052", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xd5e871fc000000000000000000000000000000000000000000000000000000000014e790000000000000000000000000a63a6a5ea2b001e76ba4fdf4eed44974772e34a7", contractAddress: "", cumulativeGasUsed: "3599817", gasUsed: "84035", confirmations: "1073986"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "46812807000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "1370000"}, {type: "address", name: "_address", value: addressList[5]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "1370000", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541420240 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "Ebuygamecoin", type: "event"} ;
		console.error( "eventCallOriginal[6,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Ebuygamecoin", events: [{name: "_time", type: "uint256", value: "1541420240"}, {name: "_number", type: "uint256", value: "1370000"}, {name: "_address", type: "address", value: "0xa63a6a5ea2b001e76ba4fdf4eed44974772e34a7"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[6,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "201572355000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"100\", \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6647963", timeStamp: "1541420562", hash: "0x7f20e5ec7f1d623a442cda3c52117de8c865b143ee8c2a87ede1aff35c9318bb", nonce: "3", blockHash: "0x0c095492d04388c086be2498e3cd14fe8645dfbcfa6c25cb6dd85ff1087432e9", transactionIndex: "71", from: "0xa63a6a5ea2b001e76ba4fdf4eed44974772e34a7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "250597", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "5130290", gasUsed: "167065", confirmations: "1073967"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "100"}, {type: "uint256", name: "_id", value: "6"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "100", "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541420562 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xa63a6a5ea2b001e76ba4fdf4eed44974772e34a7"}, {name: "_toid", type: "uint256", value: "6"}, {name: "_number", type: "uint256", value: "100"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "201572355000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"100\", \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6647966", timeStamp: "1541420616", hash: "0x656c3b85eefa8950062652f129fa11ea995365b462f6306c8493fa4b009e9a9a", nonce: "4", blockHash: "0x4a52067fe080a40937f82d0a87973eb5c3be822403094820ca352943b2b1b925", transactionIndex: "69", from: "0xa63a6a5ea2b001e76ba4fdf4eed44974772e34a7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "250597", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000000640000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "7257484", gasUsed: "60268", confirmations: "1073964"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "100"}, {type: "uint256", name: "_id", value: "6"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "100", "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541420616 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xa63a6a5ea2b001e76ba4fdf4eed44974772e34a7"}, {name: "_toid", type: "uint256", value: "6"}, {name: "_number", type: "uint256", value: "100"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "201572355000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"2000\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6647993", timeStamp: "1541420875", hash: "0x561e2b9e9d9f688a1686cc6b8cbf7589d85a19a485d22b5e90cb0d8a31b5f784", nonce: "0", blockHash: "0x688e86094e4b07bdda3bb61e626435fc488909d5786305ab70aa675787a53455", transactionIndex: "3", from: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "7600027", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xd5e871fc00000000000000000000000000000000000000000000000000000000000007d0000000000000000000000000fd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", contractAddress: "", cumulativeGasUsed: "87755", gasUsed: "24755", confirmations: "1073937"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "2000"}, {type: "address", name: "_address", value: addressList[6]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "2000", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541420875 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "572300395139475200" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"2000\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6648013", timeStamp: "1541421126", hash: "0xa175973ae2766ca698f54d8602067b890e1b12c5894a59df04ea68e8f6c4f946", nonce: "1", blockHash: "0x041995c1f81dec105f20c1cd1535b25440935e2ee8024a05ffbc17c1b4275ada", transactionIndex: "38", from: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "68660000000000000", gas: "311032", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xd5e871fc00000000000000000000000000000000000000000000000000000000000007d0000000000000000000000000fd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", contractAddress: "", cumulativeGasUsed: "2932621", gasUsed: "207355", confirmations: "1073917"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "68660000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "2000"}, {type: "address", name: "_address", value: addressList[6]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "2000", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541421126 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_id", type: "uint256", value: "1"}, {name: "_address", type: "address", value: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "Ebuygamecoin", type: "event"} ;
		console.error( "eventCallOriginal[10,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Ebuygamecoin", events: [{name: "_time", type: "uint256", value: "1541421126"}, {name: "_number", type: "uint256", value: "2000"}, {name: "_address", type: "address", value: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[10,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "572300395139475200" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"1000\", \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "6648034", timeStamp: "1541421364", hash: "0x0bf0bf764ab2ab5eb023856ceb55a1cd6b01e7e83ba78c3c53f6ac91515b0de7", nonce: "2", blockHash: "0x7ec656518f073bb197e874c6d6a7fc632679db938834e37e82dc02243d1871c6", transactionIndex: "148", from: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "183193", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "7847418", gasUsed: "122129", confirmations: "1073896"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "1000"}, {type: "uint256", name: "_id", value: "6"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "1000", "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541421364 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7"}, {name: "_toid", type: "uint256", value: "6"}, {name: "_number", type: "uint256", value: "1000"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "572300395139475200" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"10000\", addressList[6] )", async function( ) {
		const txOriginal = {blockNumber: "6648044", timeStamp: "1541421548", hash: "0x0e666fb70dafd00cf8fb114743d7916dd74f2e3544c1f18a801e0edd7f66c500", nonce: "3", blockHash: "0x65122d19675c4a80c4a9af254f2a46c735c058ca471fa0a2887d2c210f48eb4c", transactionIndex: "163", from: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "343302000000000000", gas: "125956", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xd5e871fc0000000000000000000000000000000000000000000000000000000000002710000000000000000000000000fd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", contractAddress: "", cumulativeGasUsed: "6871996", gasUsed: "83971", confirmations: "1073886"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "343302000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "10000"}, {type: "address", name: "_address", value: addressList[6]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "10000", addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541421548 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "Ebuygamecoin", type: "event"} ;
		console.error( "eventCallOriginal[12,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Ebuygamecoin", events: [{name: "_time", type: "uint256", value: "1541421548"}, {name: "_number", type: "uint256", value: "10000"}, {name: "_address", type: "address", value: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[12,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "572300395139475200" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"2000\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6648109", timeStamp: "1541422431", hash: "0x62e2d6f92abba326d2243939550e6c56540833f5ce12f502fbee96f147f61575", nonce: "4", blockHash: "0x807f4c1793471002406fa70cf7836ee401570766cb7e4969cb98153c654a3b17", transactionIndex: "62", from: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "250693", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000007d00000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6907918", gasUsed: "167129", confirmations: "1073821"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "2000"}, {type: "uint256", name: "_id", value: "1"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "2000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541422431 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7"}, {name: "_toid", type: "uint256", value: "1"}, {name: "_number", type: "uint256", value: "2000"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "572300395139475200" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"1000\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6648113", timeStamp: "1541422502", hash: "0x6570b1f9b0b0f5bd51e4db0e3381c817178aec386d8255f333cb88ff712f708e", nonce: "5", blockHash: "0xa015a9bb56aec5ca8678eaf6c6b75d7ba76dbf54ddaf33319afb98a52ee1b578", transactionIndex: "69", from: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "250693", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "5368681", gasUsed: "167129", confirmations: "1073817"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "1000"}, {type: "uint256", name: "_id", value: "2"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "1000", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541422502 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7"}, {name: "_toid", type: "uint256", value: "2"}, {name: "_number", type: "uint256", value: "1000"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "572300395139475200" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"1000\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "6648115", timeStamp: "1541422518", hash: "0xa238c2885a934bd5c4bdd12cac92cb48610d7471c9ea24bb92fd4b68d2a34cbf", nonce: "6", blockHash: "0xc643c5347f2a4909bed7305be34edbe4d2469aab971e268bd52a0fcb0f1f01fe", transactionIndex: "122", from: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "250693", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "6482944", gasUsed: "167129", confirmations: "1073815"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "1000"}, {type: "uint256", name: "_id", value: "3"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "1000", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541422518 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7"}, {name: "_toid", type: "uint256", value: "3"}, {name: "_number", type: "uint256", value: "1000"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "572300395139475200" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"1000\", \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "6648115", timeStamp: "1541422518", hash: "0x52a92f1b4a033f946700e4e8e95588d4abd7abb8faa2168df9e51aec3514b97d", nonce: "7", blockHash: "0xc643c5347f2a4909bed7305be34edbe4d2469aab971e268bd52a0fcb0f1f01fe", transactionIndex: "123", from: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "250693", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000003e80000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "6650073", gasUsed: "167129", confirmations: "1073815"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "1000"}, {type: "uint256", name: "_id", value: "5"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "1000", "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541422518 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7"}, {name: "_toid", type: "uint256", value: "5"}, {name: "_number", type: "uint256", value: "1000"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "572300395139475200" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"1200\", \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6648125", timeStamp: "1541422663", hash: "0xd58278d2409a5f0ff4c646db684815b9f19a6926b211ce00c3cf786b99c725c6", nonce: "8", blockHash: "0x663b0159ecb51b5a6daeede77b2bf3415fb4869b4aedffba7ef329c754b1df7b", transactionIndex: "105", from: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "250693", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000004b00000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "7714028", gasUsed: "167129", confirmations: "1073805"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "1200"}, {type: "uint256", name: "_id", value: "4"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "1200", "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541422663 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7"}, {name: "_toid", type: "uint256", value: "4"}, {name: "_number", type: "uint256", value: "1200"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "572300395139475200" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: gameOver(  )", async function( ) {
		const txOriginal = {blockNumber: "6648151", timeStamp: "1541423057", hash: "0x05847698fcc07fede33700b1c570b230262a7afeb74cd0cbfc4794f8d033ff10", nonce: "10", blockHash: "0xb204aa8cb6d640041b66e33a842448b551ce902c3d8b05eff7be8aec8100afef", transactionIndex: "129", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "3000000", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0xbdb337d1", contractAddress: "", cumulativeGasUsed: "3422944", gasUsed: "22941", confirmations: "1073779"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "gameOver", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gameOver()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541423057 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: gameOver(  )", async function( ) {
		const txOriginal = {blockNumber: "6648697", timeStamp: "1541431118", hash: "0x81fcd7bada7eea235d45725179cbe8aefad674fd987e3dbabb54c7741c6ff13a", nonce: "11", blockHash: "0x04cda557ba13af47c4261f19d4eb9bde5cd7b1a5c2b84689eeaed58d0b9746f9", transactionIndex: "2", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "3000000", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0xbdb337d1", contractAddress: "", cumulativeGasUsed: "64941", gasUsed: "22941", confirmations: "1073233"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "gameOver", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gameOver()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541431118 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"600\", \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "6651601", timeStamp: "1541472324", hash: "0x16db953ff3088bead291ce40dbb07228abfa59667d45e4fca0837d5d8c7146c4", nonce: "9", blockHash: "0x19c097064aff7a3e3dbab9ff72565b39d9041316bea85faad22d455ed97b80ae", transactionIndex: "91", from: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "250693", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000002580000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "4445461", gasUsed: "167129", confirmations: "1070329"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "600"}, {type: "uint256", name: "_id", value: "7"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "600", "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541472324 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7"}, {name: "_toid", type: "uint256", value: "7"}, {name: "_number", type: "uint256", value: "600"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "572300395139475200" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"600\", \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "6651609", timeStamp: "1541472534", hash: "0xa82418a01bddd5698ea36301bf424a9a182cebae2653221c992f48790d06eee6", nonce: "10", blockHash: "0xad528f1d9ba1dba73a9032cd422a695c504980ef0169e2a07d1a66ce0843337c", transactionIndex: "169", from: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "250693", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000002580000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "7010415", gasUsed: "45332", confirmations: "1070321"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "600"}, {type: "uint256", name: "_id", value: "7"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "600", "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541472534 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7"}, {name: "_toid", type: "uint256", value: "7"}, {name: "_number", type: "uint256", value: "600"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "572300395139475200" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"600\", \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "6651612", timeStamp: "1541472546", hash: "0x0cb122857f66093e65ff51895b68505f229800742cf7bfd5a4ed3f1361c9c6e5", nonce: "11", blockHash: "0x5ad0a1f5aadc292e7d84361256eca1246f938c37dcf607e42431af1369d84f3c", transactionIndex: "41", from: "0xfd4efb117f4fe1a19fd6d2bbf6941fabf6da77f7", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "250693", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000002580000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "1904048", gasUsed: "24163", confirmations: "1070318"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "600"}, {type: "uint256", name: "_id", value: "7"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "600", "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541472546 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "572300395139475200" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"500\", addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "6652783", timeStamp: "1541489267", hash: "0xc3eb2eabbe369dd7d9bd2972ccca19cb065d9600abf8bccd987fd0a4cd1afbaf", nonce: "1", blockHash: "0x6bfabcdaa3e6d790b406dffff646aa9780e115b87eb0f3c7e5c16b07670c0ff8", transactionIndex: "23", from: "0xd0669578327887d5eb0d64b6251f297ff935acc1", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "17166000000000000", gas: "269561", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xd5e871fc00000000000000000000000000000000000000000000000000000000000001f4000000000000000000000000d0669578327887d5eb0d64b6251f297ff935acc1", contractAddress: "", cumulativeGasUsed: "1296613", gasUsed: "207355", confirmations: "1069147"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "17166000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "500"}, {type: "address", name: "_address", value: addressList[7]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "500", addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541489267 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[23,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_id", type: "uint256", value: "2"}, {name: "_address", type: "address", value: "0xd0669578327887d5eb0d64b6251f297ff935acc1"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[23,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "Ebuygamecoin", type: "event"} ;
		console.error( "eventCallOriginal[23,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Ebuygamecoin", events: [{name: "_time", type: "uint256", value: "1541489267"}, {name: "_number", type: "uint256", value: "500"}, {name: "_address", type: "address", value: "0xd0669578327887d5eb0d64b6251f297ff935acc1"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[23,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "172803585373966450" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: gameOver(  )", async function( ) {
		const txOriginal = {blockNumber: "6652892", timeStamp: "1541490621", hash: "0xa181e440aefa8e108cc6fbab32cb0a99fe6c30cd4a0df4e2173423a78359e84d", nonce: "12", blockHash: "0x5241df14ebd4832f522130b7622bf082111a0cb9de2b78cc01fd6660f7473402", transactionIndex: "109", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "2500000", gasPrice: "25000000000", isError: "1", txreceipt_status: "0", input: "0xbdb337d1", contractAddress: "", cumulativeGasUsed: "3092099", gasUsed: "22941", confirmations: "1069038"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "gameOver", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gameOver()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541490621 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: gameOver(  )", async function( ) {
		const txOriginal = {blockNumber: "6652898", timeStamp: "1541490693", hash: "0x6fde226b21bdfb096ab8a86f55bb161e0985a31816ce76dd661dc5fc11d15175", nonce: "13", blockHash: "0xc78a2273f29910fe7587cef9d59ab11982f93668fe55a9848c03420bee3e2402", transactionIndex: "17", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "2500000", gasPrice: "25000000000", isError: "1", txreceipt_status: "0", input: "0xbdb337d1", contractAddress: "", cumulativeGasUsed: "560737", gasUsed: "22941", confirmations: "1069032"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "gameOver", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gameOver()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541490693 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"20\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6653303", timeStamp: "1541496575", hash: "0x3d4c81bfe386cfeedc83a79c27cc890b9fb1464bea5dbb39426a102358ff55de", nonce: "2", blockHash: "0xe92c1b78ea6fe44ec2739bf4070641bb64ed5c83b3af797792a770adc66e0d8e", transactionIndex: "135", from: "0xd0669578327887d5eb0d64b6251f297ff935acc1", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "158684", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5405311", gasUsed: "122065", confirmations: "1068627"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "20"}, {type: "uint256", name: "_id", value: "1"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "20", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541496575 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xd0669578327887d5eb0d64b6251f297ff935acc1"}, {name: "_toid", type: "uint256", value: "1"}, {name: "_number", type: "uint256", value: "20"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "172803585373966450" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"20\", \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "6653321", timeStamp: "1541496901", hash: "0x703c0f83621041c5314eb1f9929f9006bbbc25e2b8ab7c05c8c66d95a7013db8", nonce: "3", blockHash: "0xcbe1d7f473532e7c632e2847e8079cc92a676a5e88a6ca84bb02c73edf645e8e", transactionIndex: "4", from: "0xd0669578327887d5eb0d64b6251f297ff935acc1", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "217184", gasPrice: "17000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "261097", gasUsed: "167065", confirmations: "1068609"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "20"}, {type: "uint256", name: "_id", value: "20"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "20", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541496901 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xd0669578327887d5eb0d64b6251f297ff935acc1"}, {name: "_toid", type: "uint256", value: "20"}, {name: "_number", type: "uint256", value: "20"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "172803585373966450" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: gameOver(  )", async function( ) {
		const txOriginal = {blockNumber: "6653540", timeStamp: "1541499900", hash: "0xa4f927eed336f2c6868fe4f5c6c47a0f1508636d2897a2c24f307647e62b8d89", nonce: "14", blockHash: "0xee0778c4f04f92b6a60985482eb90f8a7f6ce01edc672e2e9642ab7673ebad20", transactionIndex: "106", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "2500000", gasPrice: "25000000000", isError: "1", txreceipt_status: "0", input: "0xbdb337d1", contractAddress: "", cumulativeGasUsed: "3707456", gasUsed: "22941", confirmations: "1068390"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "gameOver", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gameOver()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541499900 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"500\", addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6653882", timeStamp: "1541504818", hash: "0xbf9c38c70238b5130ae6523cce114fad3f96239a2f2ee6aa5b8087edf84a972c", nonce: "0", blockHash: "0xbedcee63198fabaf42c6ec699c6e55c88b479437d91b36b7ebf8768d09441fed", transactionIndex: "76", from: "0xa6705a4e8533e6484937ad781a3cd3e58eb525b8", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "17166000000000000", gas: "311032", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xd5e871fc00000000000000000000000000000000000000000000000000000000000001f4000000000000000000000000a6705a4e8533e6484937ad781a3cd3e58eb525b8", contractAddress: "", cumulativeGasUsed: "3695338", gasUsed: "207355", confirmations: "1068048"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "17166000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "500"}, {type: "address", name: "_address", value: addressList[8]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "500", addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541504818 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[29,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_id", type: "uint256", value: "3"}, {name: "_address", type: "address", value: "0xa6705a4e8533e6484937ad781a3cd3e58eb525b8"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[29,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "Ebuygamecoin", type: "event"} ;
		console.error( "eventCallOriginal[29,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Ebuygamecoin", events: [{name: "_time", type: "uint256", value: "1541504818"}, {name: "_number", type: "uint256", value: "500"}, {name: "_address", type: "address", value: "0xa6705a4e8533e6484937ad781a3cd3e58eb525b8"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[29,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "480760771192362300" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"20\", \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "6653919", timeStamp: "1541505472", hash: "0x02cd911ea0059e26fb6cd0d5e060f0b3f24631a915035cc66f90255c74530381", nonce: "4", blockHash: "0x510018448b51d6c295d84ea48a3e6d7708d581eac30d9f69a3b3372b58124cb6", transactionIndex: "51", from: "0xd0669578327887d5eb0d64b6251f297ff935acc1", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "78348", gasPrice: "24000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "2600548", gasUsed: "60268", confirmations: "1068011"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "20"}, {type: "uint256", name: "_id", value: "20"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "20", "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541505472 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xd0669578327887d5eb0d64b6251f297ff935acc1"}, {name: "_toid", type: "uint256", value: "20"}, {name: "_number", type: "uint256", value: "20"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "172803585373966450" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: gameOver(  )", async function( ) {
		const txOriginal = {blockNumber: "6654091", timeStamp: "1541508275", hash: "0x17e8dd67fad7150a0a55b61c4c0aeb6433c236b69518585332929258f11efbb2", nonce: "15", blockHash: "0xfcbddaa848d8de101cf8eb72b49febe1d188ab6282cb1276e7dcec98ebab3cc0", transactionIndex: "35", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "2500000", gasPrice: "25000000000", isError: "1", txreceipt_status: "0", input: "0xbdb337d1", contractAddress: "", cumulativeGasUsed: "1716651", gasUsed: "22941", confirmations: "1067839"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "gameOver", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gameOver()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541508275 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: getEveryDayEarnings( addressList[7], \"86456\" )", async function( ) {
		const txOriginal = {blockNumber: "6654278", timeStamp: "1541510779", hash: "0xaab0d29a031e3ce0aa2b36690c50a29db1956aef59c1d2aac1bd5403e5824cff", nonce: "16", blockHash: "0xfeda6edb6ee9b2bfb54e444fc6c9a0fd50ae8ca9a27f667d1889fe59a92e4a31", transactionIndex: "18", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "2500000", gasPrice: "25000000000", isError: "0", txreceipt_status: "1", input: "0xfad4da9f000000000000000000000000d0669578327887d5eb0d64b6251f297ff935acc100000000000000000000000000000000000000000000000000000000000151b8", contractAddress: "", cumulativeGasUsed: "702862", gasUsed: "102217", confirmations: "1067652"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_address", value: addressList[7]}, {type: "uint256", name: "_number", value: "86456"}], name: "getEveryDayEarnings", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getEveryDayEarnings(address,uint256)" ]( addressList[7], "86456", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541510779 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: false, name: "_totalplayers", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "EgetEveryDayEarnings", type: "event"} ;
		console.error( "eventCallOriginal[32,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EgetEveryDayEarnings", events: [{name: "_time", type: "uint256", value: "1541510779"}, {name: "_number", type: "uint256", value: "86456"}, {name: "_totalplayers", type: "uint256", value: "4"}, {name: "_address", type: "address", value: "0xd0669578327887d5eb0d64b6251f297ff935acc1"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[32,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: gameOver(  )", async function( ) {
		const txOriginal = {blockNumber: "6654412", timeStamp: "1541512759", hash: "0x478be7e74caa3df98be2f11297ff815ebb1f50d627f63cb076fae3f0698879ac", nonce: "17", blockHash: "0xc93150413e7f8021241e97411e692452959f91f56ac2babcc561dca3bdb2aa2d", transactionIndex: "36", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "2500000", gasPrice: "25000000000", isError: "1", txreceipt_status: "0", input: "0xbdb337d1", contractAddress: "", cumulativeGasUsed: "2102354", gasUsed: "22941", confirmations: "1067518"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "gameOver", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "gameOver()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541512759 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"290000\", addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6659174", timeStamp: "1541580562", hash: "0xce2ecb63c11cf5cfc9caa2d67ebe98a283a174438036545118d2516d3b90ce2c", nonce: "0", blockHash: "0x579f4013b3fb4ee12315fdb7fee3dea6a20942324c99d18ef32956863b751b29", transactionIndex: "34", from: "0xf25cb16d9d3dcb5adbc130be530b24fc34e5dc91", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "9956111000000000000", gas: "269644", gasPrice: "24000000000", isError: "0", txreceipt_status: "1", input: "0xd5e871fc0000000000000000000000000000000000000000000000000000000000046cd0000000000000000000000000f25cb16d9d3dcb5adbc130be530b24fc34e5dc91", contractAddress: "", cumulativeGasUsed: "1269959", gasUsed: "207419", confirmations: "1062756"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "9956111000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "290000"}, {type: "address", name: "_address", value: addressList[9]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "290000", addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541580562 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[34,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_id", type: "uint256", value: "4"}, {name: "_address", type: "address", value: "0xf25cb16d9d3dcb5adbc130be530b24fc34e5dc91"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[34,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "Ebuygamecoin", type: "event"} ;
		console.error( "eventCallOriginal[34,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Ebuygamecoin", events: [{name: "_time", type: "uint256", value: "1541580562"}, {name: "_number", type: "uint256", value: "290000"}, {name: "_address", type: "address", value: "0xf25cb16d9d3dcb5adbc130be530b24fc34e5dc91"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[34,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "6627817774769552" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"80000\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6659224", timeStamp: "1541581250", hash: "0xfd5bb1d1634c6fa0e866e393c7a1ba1204cc87267fac8e7ca431237c58b1f911", nonce: "9", blockHash: "0x100c15ba0f78854a0a300d54561cadd735f1e2eba573830d887bfd5af68218e0", transactionIndex: "75", from: "0x2587d0e234cab7644a4ad7444903b368f10a620c", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "2749248000000000000", gas: "327178", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xd5e871fc00000000000000000000000000000000000000000000000000000000000138800000000000000000000000002587d0e234cab7644a4ad7444903b368f10a620c", contractAddress: "", cumulativeGasUsed: "6103182", gasUsed: "218119", confirmations: "1062706"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "2749248000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "80000"}, {type: "address", name: "_address", value: addressList[10]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "80000", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541581250 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[35,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_id", type: "uint256", value: "5"}, {name: "_address", type: "address", value: "0x2587d0e234cab7644a4ad7444903b368f10a620c"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[35,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "Ebuygamecoin", type: "event"} ;
		console.error( "eventCallOriginal[35,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Ebuygamecoin", events: [{name: "_time", type: "uint256", value: "1541581250"}, {name: "_number", type: "uint256", value: "80000"}, {name: "_address", type: "address", value: "0x2587d0e234cab7644a4ad7444903b368f10a620c"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[35,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "27541017527445783" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"60000\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6659228", timeStamp: "1541581277", hash: "0x854293e00c2c72d888901b2d81c7ce2090b7a58620569e0a92b8a8155c48ff2b", nonce: "10", blockHash: "0xd8d3c09bd6f6e414b30d45156dddee053f118107364e9bd0c247a8a41fedddb3", transactionIndex: "44", from: "0x2587d0e234cab7644a4ad7444903b368f10a620c", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "2061936000000000000", gas: "327082", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0xd5e871fc000000000000000000000000000000000000000000000000000000000000ea600000000000000000000000002587d0e234cab7644a4ad7444903b368f10a620c", contractAddress: "", cumulativeGasUsed: "4218709", gasUsed: "24755", confirmations: "1062702"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "2061936000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "60000"}, {type: "address", name: "_address", value: addressList[10]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "60000", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541581277 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "27541017527445783" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"120000\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6659248", timeStamp: "1541581541", hash: "0x1631b552701434852d851a881f528a713e349d95f27b9861aa798437f50f7753", nonce: "11", blockHash: "0x863c3ad19fbf342ad597ae20b34d89ab1b6061b465fab27fa8b269f94b516dca", transactionIndex: "32", from: "0x2587d0e234cab7644a4ad7444903b368f10a620c", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "4124439000000000000", gas: "126052", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xd5e871fc000000000000000000000000000000000000000000000000000000000001d4c00000000000000000000000002587d0e234cab7644a4ad7444903b368f10a620c", contractAddress: "", cumulativeGasUsed: "3638238", gasUsed: "84035", confirmations: "1062682"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "4124439000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "120000"}, {type: "address", name: "_address", value: addressList[10]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "120000", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541581541 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "Ebuygamecoin", type: "event"} ;
		console.error( "eventCallOriginal[37,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Ebuygamecoin", events: [{name: "_time", type: "uint256", value: "1541581541"}, {name: "_number", type: "uint256", value: "120000"}, {name: "_address", type: "address", value: "0x2587d0e234cab7644a4ad7444903b368f10a620c"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[37,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "27541017527445783" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"500\", addressList[9] )", async function( ) {
		const txOriginal = {blockNumber: "6659262", timeStamp: "1541581779", hash: "0x06cef4e936db87970804bac5eb440c4df5c5136c5e3a2f693099a67cfa4ed625", nonce: "1", blockHash: "0xc550a54f7b93dd67a48ae7d3e930c35050c1c4af508e349cdf660185418cf004", transactionIndex: "167", from: "0xf25cb16d9d3dcb5adbc130be530b24fc34e5dc91", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "17189000000000000", gas: "109162", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd5e871fc00000000000000000000000000000000000000000000000000000000000001f4000000000000000000000000f25cb16d9d3dcb5adbc130be530b24fc34e5dc91", contractAddress: "", cumulativeGasUsed: "7289037", gasUsed: "83971", confirmations: "1062668"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "17189000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "500"}, {type: "address", name: "_address", value: addressList[9]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "500", addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541581779 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "Ebuygamecoin", type: "event"} ;
		console.error( "eventCallOriginal[38,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Ebuygamecoin", events: [{name: "_time", type: "uint256", value: "1541581779"}, {name: "_number", type: "uint256", value: "500"}, {name: "_address", type: "address", value: "0xf25cb16d9d3dcb5adbc130be530b24fc34e5dc91"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[38,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "6627817774769552" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"90500\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6659263", timeStamp: "1541581786", hash: "0x482488f54553239b0776ed33bbb7379ba1b9b0a9d44ed897384a00f2c8e3926d", nonce: "12", blockHash: "0x61f2e8785d597ead661b507d4311ddac8fb8e3ef7cb14fc702a8ea5b20990fda", transactionIndex: "24", from: "0x2587d0e234cab7644a4ad7444903b368f10a620c", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "3111156000000000000", gas: "126052", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0xd5e871fc00000000000000000000000000000000000000000000000000000000000161840000000000000000000000002587d0e234cab7644a4ad7444903b368f10a620c", contractAddress: "", cumulativeGasUsed: "1163185", gasUsed: "24819", confirmations: "1062667"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "3111156000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "90500"}, {type: "address", name: "_address", value: addressList[10]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "90500", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541581786 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "27541017527445783" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"90500\", addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6659319", timeStamp: "1541582654", hash: "0x87cb118ccb43cf7484e725c0d62b0efa136975eff11ef74529034a03802e5838", nonce: "13", blockHash: "0xfe431783ae752f0816ee7969f961cc1cbd57c445e4d4e6118f5754506091527e", transactionIndex: "121", from: "0x2587d0e234cab7644a4ad7444903b368f10a620c", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "3111158000000000000", gas: "126052", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xd5e871fc00000000000000000000000000000000000000000000000000000000000161840000000000000000000000002587d0e234cab7644a4ad7444903b368f10a620c", contractAddress: "", cumulativeGasUsed: "7894031", gasUsed: "84035", confirmations: "1062611"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "3111158000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "90500"}, {type: "address", name: "_address", value: addressList[10]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "90500", addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541582654 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "Ebuygamecoin", type: "event"} ;
		console.error( "eventCallOriginal[40,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Ebuygamecoin", events: [{name: "_time", type: "uint256", value: "1541582654"}, {name: "_number", type: "uint256", value: "90500"}, {name: "_address", type: "address", value: "0x2587d0e234cab7644a4ad7444903b368f10a620c"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[40,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "27541017527445783" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"1000\", \"13\" )", async function( ) {
		const txOriginal = {blockNumber: "6659339", timeStamp: "1541582840", hash: "0x87bab3e1949e2bdbd6a0a5a111711319c51cf8469e8e13bdc9edf2870ba0f907", nonce: "14", blockHash: "0x55032d7a046e374acc7db4c383155139c801f94d96e70e7727fc3e530a700c9a", transactionIndex: "127", from: "0x2587d0e234cab7644a4ad7444903b368f10a620c", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "250693", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000000000000000000000000000000000000000000d", contractAddress: "", cumulativeGasUsed: "6913203", gasUsed: "167129", confirmations: "1062591"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "1000"}, {type: "uint256", name: "_id", value: "13"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "1000", "13", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541582840 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0x2587d0e234cab7644a4ad7444903b368f10a620c"}, {name: "_toid", type: "uint256", value: "13"}, {name: "_number", type: "uint256", value: "1000"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "27541017527445783" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"1000\", \"13\" )", async function( ) {
		const txOriginal = {blockNumber: "6659342", timeStamp: "1541582870", hash: "0x8b5bd27d6f8b8b71c15179d3c6737e27871a595e189ca1955d37942bffed391a", nonce: "15", blockHash: "0xa9e715e01e7baefa2910013bcc77de6ae06d68425f518d2e3e8cd6423f6f0b55", transactionIndex: "67", from: "0x2587d0e234cab7644a4ad7444903b368f10a620c", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "90498", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000003e8000000000000000000000000000000000000000000000000000000000000000d", contractAddress: "", cumulativeGasUsed: "2524474", gasUsed: "60332", confirmations: "1062588"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "1000"}, {type: "uint256", name: "_id", value: "13"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "1000", "13", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541582870 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0x2587d0e234cab7644a4ad7444903b368f10a620c"}, {name: "_toid", type: "uint256", value: "13"}, {name: "_number", type: "uint256", value: "1000"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "27541017527445783" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buyGameCoin( \"290000\", addressList[11] )", async function( ) {
		const txOriginal = {blockNumber: "6659365", timeStamp: "1541583152", hash: "0xf3decbae3b8aa5bfb8ce815c5bf550a36d50a7365be9547a7770aa73c6f8f7f4", nonce: "0", blockHash: "0x241e3344c98bb2be1901481f270136d3bf0e916271b4829208ac1e699fe3c969", transactionIndex: "126", from: "0xd234ca4ff8db8de4e3f8d3d95fd59c7249bb63d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "9971008000000000000", gas: "311128", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xd5e871fc0000000000000000000000000000000000000000000000000000000000046cd0000000000000000000000000d234ca4ff8db8de4e3f8d3d95fd59c7249bb63d4", contractAddress: "", cumulativeGasUsed: "7085913", gasUsed: "207419", confirmations: "1062565"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "9971008000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "290000"}, {type: "address", name: "_address", value: addressList[11]}], name: "buyGameCoin", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyGameCoin(uint256,address)" ]( "290000", addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541583152 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_id", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "NewPlayer", type: "event"} ;
		console.error( "eventCallOriginal[43,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewPlayer", events: [{name: "_id", type: "uint256", value: "6"}, {name: "_address", type: "address", value: "0xd234ca4ff8db8de4e3f8d3d95fd59c7249bb63d4"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[43,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: true, name: "_address", type: "address"}], name: "Ebuygamecoin", type: "event"} ;
		console.error( "eventCallOriginal[43,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Ebuygamecoin", events: [{name: "_time", type: "uint256", value: "1541583152"}, {name: "_number", type: "uint256", value: "290000"}, {name: "_address", type: "address", value: "0xd234ca4ff8db8de4e3f8d3d95fd59c7249bb63d4"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[43,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "47898677873291000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: getPlayerCoin( \"10000\" )", async function( ) {
		const txOriginal = {blockNumber: "6659460", timeStamp: "1541584536", hash: "0xf9ce7bf7f24fc9e3b59a913fa0808202bcdd2a3ae7b565b08e8fbb90db67dc54", nonce: "1", blockHash: "0x2d06230ec81c521fe8c74106030198af9957e725184c0910357ea734785f4b2a", transactionIndex: "119", from: "0xd234ca4ff8db8de4e3f8d3d95fd59c7249bb63d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "99972", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x1cdd34e60000000000000000000000000000000000000000000000000000000000002710", contractAddress: "", cumulativeGasUsed: "6490413", gasUsed: "66648", confirmations: "1062470"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_number", value: "10000"}], name: "getPlayerCoin", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getPlayerCoin(uint256)" ]( "10000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541584536 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_address", type: "address"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: false, name: "_bool", type: "bool"}], name: "EgetPlayerCoin", type: "event"} ;
		console.error( "eventCallOriginal[44,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EgetPlayerCoin", events: [{name: "_address", type: "address", value: "0xd234ca4ff8db8de4e3f8d3d95fd59c7249bb63d4"}, {name: "_number", type: "uint256", value: "10000"}, {name: "_bool", type: "bool", value: true}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[44,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "47898677873291000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"40\", \"13\" )", async function( ) {
		const txOriginal = {blockNumber: "6659483", timeStamp: "1541584860", hash: "0x0ce49606bb81bb9e695656d3502dae28ec8a352eb52bba8fe7895ee2f8e74831", nonce: "2", blockHash: "0x7279ebc1028b96a1c0f89fee7252f25302c3670b08268f1b36c879dce89cb46e", transactionIndex: "35", from: "0xf25cb16d9d3dcb5adbc130be530b24fc34e5dc91", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "158684", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f0000000000000000000000000000000000000000000000000000000000000028000000000000000000000000000000000000000000000000000000000000000d", contractAddress: "", cumulativeGasUsed: "1663894", gasUsed: "122065", confirmations: "1062447"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "40"}, {type: "uint256", name: "_id", value: "13"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "40", "13", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1541584860 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xf25cb16d9d3dcb5adbc130be530b24fc34e5dc91"}, {name: "_toid", type: "uint256", value: "13"}, {name: "_number", type: "uint256", value: "40"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "6627817774769552" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"200\", \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6660300", timeStamp: "1541596423", hash: "0x464c704e91f831768ab35544f5c99f8988417c2ad2b326ba351a37aab7a3e60a", nonce: "2", blockHash: "0x21100dcc366f175fadb30d205cf33f07ba6fa4bb22c7c558b57fce26dbed3fdf", transactionIndex: "83", from: "0xd234ca4ff8db8de4e3f8d3d95fd59c7249bb63d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "183097", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000000c80000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "3376911", gasUsed: "122065", confirmations: "1061630"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "200"}, {type: "uint256", name: "_id", value: "4"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "200", "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541596423 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xd234ca4ff8db8de4e3f8d3d95fd59c7249bb63d4"}, {name: "_toid", type: "uint256", value: "4"}, {name: "_number", type: "uint256", value: "200"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "47898677873291000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"200\", \"13\" )", async function( ) {
		const txOriginal = {blockNumber: "6660350", timeStamp: "1541597167", hash: "0xc946a24508a87fa33354c482b79e8134690a576c4c9d022f86e35b2b1f2087a1", nonce: "3", blockHash: "0x3403ba65b2e34fe03e4a1617dc52dbe4b4bee1a07cc675a9b58f18af1d1f7b74", transactionIndex: "14", from: "0xf25cb16d9d3dcb5adbc130be530b24fc34e5dc91", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "78348", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000000c8000000000000000000000000000000000000000000000000000000000000000d", contractAddress: "", cumulativeGasUsed: "530978", gasUsed: "60268", confirmations: "1061580"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "200"}, {type: "uint256", name: "_id", value: "13"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "200", "13", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541597167 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xf25cb16d9d3dcb5adbc130be530b24fc34e5dc91"}, {name: "_toid", type: "uint256", value: "13"}, {name: "_number", type: "uint256", value: "200"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "6627817774769552" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: giveToVoter( \"200\", \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "6660362", timeStamp: "1541597270", hash: "0x4b13c88cebe4014c605b849b4ae186716b08f538d6619d7d7265afcd4449d95a", nonce: "3", blockHash: "0x2a281fb149cccfbca57ad839f531b55296799fb3781820ffd34dd0c0a1475110", transactionIndex: "104", from: "0xd234ca4ff8db8de4e3f8d3d95fd59c7249bb63d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "90402", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x5d307c6f00000000000000000000000000000000000000000000000000000000000000c80000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "4648619", gasUsed: "60268", confirmations: "1061568"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_value", value: "200"}, {type: "uint256", name: "_id", value: "4"}], name: "giveToVoter", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "giveToVoter(uint256,uint256)" ]( "200", "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541597270 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromaddress", type: "address"}, {indexed: false, name: "_toid", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}], name: "GiveVoter", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GiveVoter", events: [{name: "_fromaddress", type: "address", value: "0xd234ca4ff8db8de4e3f8d3d95fd59c7249bb63d4"}, {name: "_toid", type: "uint256", value: "4"}, {name: "_number", type: "uint256", value: "200"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "47898677873291000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: getEveryDayEarnings( addressList[11], \"26394\" )", async function( ) {
		const txOriginal = {blockNumber: "6660451", timeStamp: "1541598451", hash: "0x27cd3a2b35c6ab601f700d2e6be1cf578350c18c66cfd3ac6e278fc8d757fcc9", nonce: "20", blockHash: "0x4dfe22ad6a8c4a2e78e999cbbef2814c6357a36d1559da09a5347758e36324bc", transactionIndex: "111", from: "0x4129a6151049ac66aed0b7565a7b0f7cd617d0d4", to: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d", value: "0", gas: "2500000", gasPrice: "25000000000", isError: "0", txreceipt_status: "1", input: "0xfad4da9f000000000000000000000000d234ca4ff8db8de4e3f8d3d95fd59c7249bb63d4000000000000000000000000000000000000000000000000000000000000671a", contractAddress: "", cumulativeGasUsed: "2790706", gasUsed: "97449", confirmations: "1061479"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_address", value: addressList[11]}, {type: "uint256", name: "_number", value: "26394"}], name: "getEveryDayEarnings", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "getEveryDayEarnings(address,uint256)" ]( addressList[11], "26394", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541598451 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_time", type: "uint256"}, {indexed: false, name: "_number", type: "uint256"}, {indexed: false, name: "_totalplayers", type: "uint256"}, {indexed: false, name: "_address", type: "address"}], name: "EgetEveryDayEarnings", type: "event"} ;
		console.error( "eventCallOriginal[49,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EgetEveryDayEarnings", events: [{name: "_time", type: "uint256", value: "1541598451"}, {name: "_number", type: "uint256", value: "26394"}, {name: "_totalplayers", type: "uint256", value: "7"}, {name: "_address", type: "address", value: "0xd234ca4ff8db8de4e3f8d3d95fd59c7249bb63d4"}], address: "0x09f05b0876f2d5d0481d5efdb4166dccb9fba97d"}] ;
		console.error( "eventResultOriginal[49,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "790450522562640466" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
