const BookERC20EthV1 = artifacts.require( "./BookERC20EthV1.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "BookERC20EthV1" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xf8d15960aa6Aaf5972DC54cF002951553906C7bd", "0x884378D7919125BDfd337145d871a1bA2a58c0E9", "0xd26114cd6EE289AccF82350c8d8487fedB8A0C07", "0xEc2ca0Ef7CBBB49D5305f2f85dda24A9C5EDa305", "0x81528e544Ca84525d7644E624800684229Bf4Bb5", "0xfeFc43fBa678a282fD354e29e0A9BCf5c10d053d", "0xeB198b469e4003a7b0c0395E2841d3E1Dfc88F87", "0xFA4E7035b34294407e5Df1603215983d65e5a773", "0x89f1757e9f7C4E7975fBe240aa043B426F0bDF2C"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "fromPrice", type: "uint16"}], name: "walkBook", outputs: [{name: "price", type: "uint16"}, {name: "depthBase", type: "uint256"}, {name: "orderCount", type: "uint256"}, {name: "blockNumber", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "orderId", type: "uint128"}], name: "getOrder", outputs: [{name: "client", type: "address"}, {name: "price", type: "uint16"}, {name: "sizeBase", type: "uint256"}, {name: "terms", type: "uint8"}, {name: "status", type: "uint8"}, {name: "reasonCode", type: "uint8"}, {name: "executedBase", type: "uint256"}, {name: "executedCntr", type: "uint256"}, {name: "feesBaseOrCntr", type: "uint256"}, {name: "feesRwrd", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getBookInfo", outputs: [{name: "_bookType", type: "uint8"}, {name: "_baseToken", type: "address"}, {name: "_rwrdToken", type: "address"}, {name: "_baseMinInitialSize", type: "uint256"}, {name: "_cntrMinInitialSize", type: "uint256"}, {name: "_feeDivisor", type: "uint256"}, {name: "_feeCollector", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "orderId", type: "uint128"}], name: "getOrderState", outputs: [{name: "status", type: "uint8"}, {name: "reasonCode", type: "uint8"}, {name: "executedBase", type: "uint256"}, {name: "executedCntr", type: "uint256"}, {name: "feesBaseOrCntr", type: "uint256"}, {name: "feesRwrd", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "client", type: "address"}], name: "getClientBalances", outputs: [{name: "bookBalanceBase", type: "uint256"}, {name: "bookBalanceCntr", type: "uint256"}, {name: "bookBalanceRwrd", type: "uint256"}, {name: "approvedBalanceBase", type: "uint256"}, {name: "approvedBalanceRwrd", type: "uint256"}, {name: "ownBalanceBase", type: "uint256"}, {name: "ownBalanceRwrd", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "client", type: "address"}, {name: "maybeLastOrderIdReturned", type: "uint128"}, {name: "minClosedOrderIdCutoff", type: "uint128"}], name: "walkClientOrders", outputs: [{name: "orderId", type: "uint128"}, {name: "price", type: "uint16"}, {name: "sizeBase", type: "uint256"}, {name: "terms", type: "uint8"}, {name: "status", type: "uint8"}, {name: "reasonCode", type: "uint8"}, {name: "executedBase", type: "uint256"}, {name: "executedCntr", type: "uint256"}, {name: "feesBaseOrCntr", type: "uint256"}, {name: "feesRwrd", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["ClientPaymentEvent(address,uint8,uint8,int256)", "ClientOrderEvent(address,uint8,uint128,uint256)", "MarketOrderEvent(uint256,uint128,uint8,uint16,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xcaa7be131f5091d6ed32c02b2ba1f45c6721442175b1c8e1a9a5b453e54efe75", "0x98f28571fb2c7cab95fb6ca13908a1ba4a08e2b417317f72037ea2fafd2bca47", "0x40d0a103f9440846844f8f9a0d6968bb70b1a10f7ce225d40eb8796c4993258d"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4402394 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4798550 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "BookERC20EthV1", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint16", name: "fromPrice", value: random.range( maxRandom )}], name: "walkBook", outputs: [{name: "price", type: "uint16"}, {name: "depthBase", type: "uint256"}, {name: "orderCount", type: "uint256"}, {name: "blockNumber", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "walkBook(uint16)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint128", name: "orderId", value: random.range( maxRandom )}], name: "getOrder", outputs: [{name: "client", type: "address"}, {name: "price", type: "uint16"}, {name: "sizeBase", type: "uint256"}, {name: "terms", type: "uint8"}, {name: "status", type: "uint8"}, {name: "reasonCode", type: "uint8"}, {name: "executedBase", type: "uint256"}, {name: "executedCntr", type: "uint256"}, {name: "feesBaseOrCntr", type: "uint256"}, {name: "feesRwrd", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOrder(uint128)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getBookInfo", outputs: [{name: "_bookType", type: "uint8"}, {name: "_baseToken", type: "address"}, {name: "_rwrdToken", type: "address"}, {name: "_baseMinInitialSize", type: "uint256"}, {name: "_cntrMinInitialSize", type: "uint256"}, {name: "_feeDivisor", type: "uint256"}, {name: "_feeCollector", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBookInfo()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint128", name: "orderId", value: random.range( maxRandom )}], name: "getOrderState", outputs: [{name: "status", type: "uint8"}, {name: "reasonCode", type: "uint8"}, {name: "executedBase", type: "uint256"}, {name: "executedCntr", type: "uint256"}, {name: "feesBaseOrCntr", type: "uint256"}, {name: "feesRwrd", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOrderState(uint128)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "client", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getClientBalances", outputs: [{name: "bookBalanceBase", type: "uint256"}, {name: "bookBalanceCntr", type: "uint256"}, {name: "bookBalanceRwrd", type: "uint256"}, {name: "approvedBalanceBase", type: "uint256"}, {name: "approvedBalanceRwrd", type: "uint256"}, {name: "ownBalanceBase", type: "uint256"}, {name: "ownBalanceRwrd", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getClientBalances(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "client", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint128", name: "maybeLastOrderIdReturned", value: random.range( maxRandom )}, {type: "uint128", name: "minClosedOrderIdCutoff", value: random.range( maxRandom )}], name: "walkClientOrders", outputs: [{name: "orderId", type: "uint128"}, {name: "price", type: "uint16"}, {name: "sizeBase", type: "uint256"}, {name: "terms", type: "uint8"}, {name: "status", type: "uint8"}, {name: "reasonCode", type: "uint8"}, {name: "executedBase", type: "uint256"}, {name: "executedCntr", type: "uint256"}, {name: "feesBaseOrCntr", type: "uint256"}, {name: "feesRwrd", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "walkClientOrders(address,uint128,uint128)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "BookERC20EthV1", function( accounts ) {

	it( "TEST: BookERC20EthV1(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4402394", timeStamp: "1508596158", hash: "0x2967005fa147f209a9fd1751e857c43c4264e41dd37847f1ab17aca7908017ec", nonce: "9", blockHash: "0xabf94d091beb807f56b1e61152d2b5fcccb5c8b4ec670fdb662841205f3bb88f", transactionIndex: "40", from: "0x884378d7919125bdfd337145d871a1ba2a58c0e9", to: 0, value: "0", gas: "3368274", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x17011011", contractAddress: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", cumulativeGasUsed: "5059606", gasUsed: "3368274", confirmations: "3320240"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "BookERC20EthV1", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = BookERC20EthV1.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1508596158 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = BookERC20EthV1.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "13717312240439179" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: init( addressList[4], addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4402529", timeStamp: "1508598163", hash: "0xd921ac075252748ea2c907124323846ddde47b59e58e7523a760aad28ae9a7b2", nonce: "10", blockHash: "0x5e721c54282d37316b30949bad28f1dc3e0b1478bdd1947f6e16b598761d4b7d", transactionIndex: "44", from: "0x884378d7919125bdfd337145d871a1ba2a58c0e9", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "70504", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xf09a4016000000000000000000000000d26114cd6ee289accf82350c8d8487fedb8a0c07000000000000000000000000ec2ca0ef7cbbb49d5305f2f85dda24a9c5eda305", contractAddress: "", cumulativeGasUsed: "2061722", gasUsed: "70504", confirmations: "3320105"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_baseToken", value: addressList[4]}, {type: "address", name: "_rwrdToken", value: addressList[5]}], name: "init", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "init(address,address)" ]( addressList[4], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1508598163 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "13717312240439179" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: transferFromBase(  )", async function( ) {
		const txOriginal = {blockNumber: "4403760", timeStamp: "1508614942", hash: "0xf2b01b8b2e5b1a6b2f82df1e2b06a70b17201ef212fc41f49421af528d448e52", nonce: "24", blockHash: "0xe2568b7868a4283a086e8645911cac6a842091c77a618cdbac0e5ba44a8b9e4b", transactionIndex: "13", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "250000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x61ea6ed7", contractAddress: "", cumulativeGasUsed: "630044", gasUsed: "56476", confirmations: "3318874"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "transferFromBase", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFromBase()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1508614942 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientPaymentEventType", type: "uint8", value: "2"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [50000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4403762", timeStamp: "1508614963", hash: "0xf680617cf11e92ae1fca93ebc0d0dab16b6a58b292ece758c0c6093e0e2973dd", nonce: "25", blockHash: "0x96efac6e9a076dc702e01513b84507103d1db309a7a7e4e9524b75573553e685", transactionIndex: "13", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "500000000000000000", gas: "150000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "501098", gasUsed: "44009", confirmations: "3318872"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1508614963 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 17, c: [5000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11952479723172084969889348712990210168... )", async function( ) {
		const txOriginal = {blockNumber: "4403769", timeStamp: "1508615050", hash: "0xae8e50512b3bb367e9cec5c69dfb67cae5c9c9f5f8ee1691dcfddb37330f796f", nonce: "26", blockHash: "0x7848e41ce90f553fc64f2c748a5de09fb676739ad4b1818e992cc878285ad2e8", transactionIndex: "5", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "300000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xbbec37680000000000000000000000000000000059eba37bd963476a8dabcf58ac7ab4b70000000000000000000000000000000000000000000000000000000000001bb2000000000000000000000000000000000000000000000001158e460913d0000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "545577", gasUsed: "246595", confirmations: "3318865"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119524797231720849698893487129902101687"}, {type: "uint16", name: "price", value: "7090"}, {type: "uint256", name: "sizeBase", value: "20000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119524797231720849698893487129902101687", "7090", "20000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1508615050 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11952479723, 17208496988934, 87129902101687]}}, {name: "maxMatches", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508615050"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba37bd963476a8dabcf58ac7ab4b7"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7090]}}, {name: "depthBase", type: "uint256", value: "20000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11952479959377333259401162352177817470... )", async function( ) {
		const txOriginal = {blockNumber: "4403772", timeStamp: "1508615074", hash: "0x6eedb4412adf63a387ac4caa566f11d99e89c131970eb5b0c8790195dcc7bba0", nonce: "27", blockHash: "0xb5d16dacd58c2c0757136b259ea398d43c54f4336d43a2ec2630c232d668e56d", transactionIndex: "7", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "300000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xbbec37680000000000000000000000000000000059eba399a9974c74896842a179288aed00000000000000000000000000000000000000000000000000000000000038eb0000000000000000000000000000000000000000000000004563918244f4000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "601934", gasUsed: "252606", confirmations: "3318862"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119524799593773332594011623521778174701"}, {type: "uint16", name: "price", value: "14571"}, {type: "uint256", name: "sizeBase", value: "5000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119524799593773332594011623521778174701", "14571", "5000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1508615074 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11952479959, 37733325940116, 23521778174701]}}, {name: "maxMatches", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508615074"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba399a9974c74896842a179288aed"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14571]}}, {name: "depthBase", type: "uint256", value: "5000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: transferFromBase(  )", async function( ) {
		const txOriginal = {blockNumber: "4403792", timeStamp: "1508615286", hash: "0x17bf74cf8ca5446f5e6472d7161e0c07e9962e916ad2df4c1af117103d3cfb83", nonce: "26", blockHash: "0xb02df74a78afb33e471f6dc7576b71ef59cef0e55681da076c64334b3a910a77", transactionIndex: "19", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "250000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x61ea6ed7", contractAddress: "", cumulativeGasUsed: "649477", gasUsed: "56476", confirmations: "3318842"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "transferFromBase", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFromBase()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1508615286 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientPaymentEventType", type: "uint8", value: "2"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 19, c: [100000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4403795", timeStamp: "1508615328", hash: "0xa6ece346fd66d497990c114262e661ec1409052a90461c1da94031efd03b6743", nonce: "27", blockHash: "0xb82791be07036ba7a6d3f57abf2feed290528d7016c89854b01b025d1746c904", transactionIndex: "29", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "250000000000000000", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "1773582", gasUsed: "44009", confirmations: "3318839"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1508615328 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 17, c: [2500]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11952482136084291724518019114872089912... )", async function( ) {
		const txOriginal = {blockNumber: "4403796", timeStamp: "1508615360", hash: "0xccae7e2c7a50921a392b3139bd882314df9c135ccca70d24456e1c61f287396b", nonce: "28", blockHash: "0x668c70f78201a41dc92a55a7b0a4ec814fc3754c608ed1b51a440f959abb1421", transactionIndex: "25", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "300000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xbbec37680000000000000000000000000000000059eba4ac66c9404ca2491efbd301c43500000000000000000000000000000000000000000000000000000000000038e60000000000000000000000000000000000000000000000008ac7230489e8000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1842414", gasUsed: "238276", confirmations: "3318838"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119524821360842917245180191148720899125"}, {type: "uint16", name: "price", value: "14566"}, {type: "uint256", name: "sizeBase", value: "10000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119524821360842917245180191148720899125", "14566", "10000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1508615360 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11952482136, 8429172451801, 91148720899125]}}, {name: "maxMatches", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508615360"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba4ac66c9404ca2491efbd301c435"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14566]}}, {name: "depthBase", type: "uint256", value: "10000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11952484295081460104640649819367493179... )", async function( ) {
		const txOriginal = {blockNumber: "4403811", timeStamp: "1508615618", hash: "0xeacf6209c89311c19c7d076ac7d78a7da1c3ee64c61e6cd0026b4f944a85fe09", nonce: "29", blockHash: "0xdc2a33999aa1e45bd6c4cfb431a67073220731f2f5982584379fe530c2a1858d", transactionIndex: "26", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xbbec37680000000000000000000000000000000059eba5bce7bf40ea864d40bd2b6d0e520000000000000000000000000000000000000000000000000000000000001bad00000000000000000000000000000000000000000000000053444835ec58000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1591710", gasUsed: "255774", confirmations: "3318823"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119524842950814601046406498193674931794"}, {type: "uint16", name: "price", value: "7085"}, {type: "uint256", name: "sizeBase", value: "6000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119524842950814601046406498193674931794", "7085", "6000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1508615618 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11952484295, 8146010464064, 98193674931794]}}, {name: "maxMatches", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508615618"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba5bce7bf40ea864d40bd2b6d0e52"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7085]}}, {name: "depthBase", type: "uint256", value: "6000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11952484571899118842868409666686075735... )", async function( ) {
		const txOriginal = {blockNumber: "4403814", timeStamp: "1508615666", hash: "0xd2f531bb7a758f94db52032d65cc7b31a375de492b231d806c5bfb57a236e77c", nonce: "30", blockHash: "0xace9df83ebf8f99200e69746d97c9ef1e38bc7e064f93a588b856d81dcd2cc4e", transactionIndex: "28", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "300000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xbbec37680000000000000000000000000000000059eba5dfd835423fb18105c8cbf3a1670000000000000000000000000000000000000000000000000000000000001ba30000000000000000000000000000000000000000000000004563918244f4000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2035282", gasUsed: "257114", confirmations: "3318820"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119524845718991188428684096666860757351"}, {type: "uint16", name: "price", value: "7075"}, {type: "uint256", name: "sizeBase", value: "5000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119524845718991188428684096666860757351", "7075", "5000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1508615666 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11952484571, 89911884286840, 96666860757351]}}, {name: "maxMatches", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[10,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508615666"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba5dfd835423fb18105c8cbf3a167"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7075]}}, {name: "depthBase", type: "uint256", value: "5000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[10,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4404736", timeStamp: "1508628384", hash: "0xb9055c686c8670ca24c6a843e182e08d30ea22c8963be61fc9c6622cd2f275cb", nonce: "22", blockHash: "0x51e03b5645cae09fee76e9d5b003961e220375f1a245e4be897225179e1d0a24", transactionIndex: "93", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "26500000000000000", gas: "150000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "3958024", gasUsed: "44009", confirmations: "3317898"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "26500000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1508628384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 16, c: [265]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11952585690275238628291132519217220326... )", async function( ) {
		const txOriginal = {blockNumber: "4404741", timeStamp: "1508628420", hash: "0x6cdd2ec309d1b6ad5bdef038896793efc48cf009a553bc063b1dadff3226342e", nonce: "23", blockHash: "0x6e47d69a4fcc93afb2177ab6ef9d6bd0973d46c91b9060da0a620a8dca376a17", transactionIndex: "18", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "600000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xbbec37680000000000000000000000000000000059ebd7bac72840068c0eef8983b1ed000000000000000000000000000000000000000000000000000000000000001b7b0000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "964729", gasUsed: "323847", confirmations: "3317893"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119525856902752386282911325192172203264"}, {type: "uint16", name: "price", value: "7035"}, {type: "uint256", name: "sizeBase", value: "1000000000000000000"}, {type: "uint8", name: "terms", value: "2"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119525856902752386282911325192172203264", "7035", "1000000000000000000", "2", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1508628420 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11952585690, 27523862829113, 25192172203264]}}, {name: "maxMatches", type: "uint256", value: "3"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508628420"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba4ac66c9404ca2491efbd301c435"}, {name: "marketOrderEventType", type: "uint8", value: "3"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14566]}}, {name: "depthBase", type: "uint256", value: "1000000000000000000"}, {name: "tradeBase", type: "uint256", value: "1000000000000000000"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11952482136084291724518019114872089912... )", async function( ) {
		const txOriginal = {blockNumber: "4418991", timeStamp: "1508825333", hash: "0x8467e42e806776823a2e9693747f175d8aa443279b93d4e2d0aab5335622e0ea", nonce: "31", blockHash: "0x5039d0c493743910d18d400e0c68ab1a6303b84431cb591bb22ca2b859ea3e9d", transactionIndex: "42", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "150000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xdbc913960000000000000000000000000000000059eba4ac66c9404ca2491efbd301c435", contractAddress: "", cumulativeGasUsed: "2098294", gasUsed: "64143", confirmations: "3303643"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119524821360842917245180191148720899125"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119524821360842917245180191148720899125", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1508825333 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "2"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11952482136, 8429172451801, 91148720899125]}}, {name: "maxMatches", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508825333"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba4ac66c9404ca2491efbd301c435"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14566]}}, {name: "depthBase", type: "uint256", value: "9000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11952484295081460104640649819367493179... )", async function( ) {
		const txOriginal = {blockNumber: "4418992", timeStamp: "1508825356", hash: "0xa1fa87d4b38fc662231d8d1d4e7c2fccf41040a5233516ddd9eb71ce554ca7d2", nonce: "33", blockHash: "0xb8f4b0959d463302def33689c327aaec5b2225b4a113cccc0ce2fe8fc6cfaff6", transactionIndex: "56", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "150000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xdbc913960000000000000000000000000000000059eba5bce7bf40ea864d40bd2b6d0e52", contractAddress: "", cumulativeGasUsed: "1560703", gasUsed: "49710", confirmations: "3303642"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119524842950814601046406498193674931794"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119524842950814601046406498193674931794", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1508825356 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "2"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11952484295, 8146010464064, 98193674931794]}}, {name: "maxMatches", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508825356"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba5bce7bf40ea864d40bd2b6d0e52"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7085]}}, {name: "depthBase", type: "uint256", value: "6000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4418995", timeStamp: "1508825375", hash: "0x90e2c9c060a931e408e9bb12c508d176d10d34b57d332f768146049d858bc7a2", nonce: "34", blockHash: "0xf0f876aade56ed257b8b88a28d00b2238e0759c291950731437809c87b89936e", transactionIndex: "38", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "200000000000000000", gas: "150000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "1615108", gasUsed: "29009", confirmations: "3303639"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1508825375 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 17, c: [2000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: transferFromBase(  )", async function( ) {
		const txOriginal = {blockNumber: "4418997", timeStamp: "1508825382", hash: "0x9f0a2d5e1a97c5994a4069749c0c35d585125eee47af646f9be999149e2f9b8b", nonce: "35", blockHash: "0x8251a77ce5f6c067e65aa2f0623de0dfa1408e92a08c4bcee5a86361401ddd8b", transactionIndex: "17", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "250000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x61ea6ed7", contractAddress: "", cumulativeGasUsed: "927444", gasUsed: "41476", confirmations: "3303637"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "transferFromBase", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFromBase()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1508825382 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientPaymentEventType", type: "uint8", value: "2"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 19, c: [100000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11954146497983869786587640540216325410... )", async function( ) {
		const txOriginal = {blockNumber: "4418999", timeStamp: "1508825437", hash: "0x69c63b441cf0bde58c29df90911e4171040058770c3d28eb451f051fc5a278a7", nonce: "36", blockHash: "0x479c6910f4a991e3ee9677083ca96169dc1a03a1a3682e0667c4db19f693aadb", transactionIndex: "71", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "300000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xbbec37680000000000000000000000000000000059eed944683547ba908ddac3dbb0935900000000000000000000000000000000000000000000000000000000000039080000000000000000000000000000000000000000000000004563918244f4000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2170067", gasUsed: "263720", confirmations: "3303635"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119541464979838697865876405402163254105"}, {type: "uint16", name: "price", value: "14600"}, {type: "uint256", name: "sizeBase", value: "5000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119541464979838697865876405402163254105", "14600", "5000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1508825437 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11954146497, 98386978658764, 5402163254105]}}, {name: "maxMatches", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508825437"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eed944683547ba908ddac3dbb09359"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14600]}}, {name: "depthBase", type: "uint256", value: "5000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11954146752092221732235534777095779606... )", async function( ) {
		const txOriginal = {blockNumber: "4419001", timeStamp: "1508825449", hash: "0x6adaa7eded0f25f6c55f41cd566a6ff10153a6501d498c372d80312d2f75470b", nonce: "37", blockHash: "0x49c3f0fcb6967bf19a713a8c80d3cd38d625e741169cd48e187e4c8cda4a5367", transactionIndex: "6", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "300000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xbbec37680000000000000000000000000000000059eed9647ae44d67a7ed700e571292e400000000000000000000000000000000000000000000000000000000000038fa0000000000000000000000000000000000000000000000008ac7230489e8000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "504551", gasUsed: "250596", confirmations: "3303633"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119541467520922217322355347770957796068"}, {type: "uint16", name: "price", value: "14586"}, {type: "uint256", name: "sizeBase", value: "10000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119541467520922217322355347770957796068", "14586", "10000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1508825449 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11954146752, 9222173223553, 47770957796068]}}, {name: "maxMatches", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508825449"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eed9647ae44d67a7ed700e571292e4"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14586]}}, {name: "depthBase", type: "uint256", value: "10000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11954147318397323477663023808870198212... )", async function( ) {
		const txOriginal = {blockNumber: "4419012", timeStamp: "1508825579", hash: "0xe7292a07563377b928d2a596e8e0198262e78ea20852f3dd0dd2a54b58ab8e0a", nonce: "38", blockHash: "0x973aa361f5f7c177faa5742b0874f259ecf243312bc67ff09a2218a9a1f7cdc1", transactionIndex: "41", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "300000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xbbec37680000000000000000000000000000000059eed9abf5324fd8aa1e2ebdc360b5ab0000000000000000000000000000000000000000000000000000000000001b85000000000000000000000000000000000000000000000000a688906bd8b0000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2707302", gasUsed: "261134", confirmations: "3303622"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119541473183973234776630238088701982123"}, {type: "uint16", name: "price", value: "7045"}, {type: "uint256", name: "sizeBase", value: "12000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119541473183973234776630238088701982123", "7045", "12000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1508825579 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11954147318, 39732347766302, 38088701982123]}}, {name: "maxMatches", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508825579"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eed9abf5324fd8aa1e2ebdc360b5ab"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7045]}}, {name: "depthBase", type: "uint256", value: "12000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4419147", timeStamp: "1508827424", hash: "0xdb16957741dd972fb38a0fde68123706cd1bf4a1205722a675a98b57838ff322", nonce: "24", blockHash: "0x31a2cd8a48f3070cedf6d126b9a7eedfe7e086118b4e5be47f9a30be6daf1a63", transactionIndex: "83", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "1000000000000000000", gas: "150000", gasPrice: "4200000000", isError: "0", txreceipt_status: "1", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "3114969", gasUsed: "44009", confirmations: "3303487"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1508827424 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [10000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11954164009017710525305955484045071875... )", async function( ) {
		const txOriginal = {blockNumber: "4419167", timeStamp: "1508827630", hash: "0x86a4242d664d564dd90a0bbcff98b195f8749b8b08bd1d2b485dbc2c68e93d71", nonce: "25", blockHash: "0x15c6ef24ebd491a18f8fc308137d8978bc166ea649762259d9f65fcb7aac47db", transactionIndex: "34", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "600000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xbbec37680000000000000000000000000000000059eee1e69c3a44b49e004e6c742c5c240000000000000000000000000000000000000000000000000000000000001b760000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "1779337", gasUsed: "309517", confirmations: "3303467"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119541640090177105253059554840450718756"}, {type: "uint16", name: "price", value: "7030"}, {type: "uint256", name: "sizeBase", value: "1000000000000000000"}, {type: "uint8", name: "terms", value: "2"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119541640090177105253059554840450718756", "7030", "1000000000000000000", "2", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1508827630 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11954164009, 1771052530595, 54840450718756]}}, {name: "maxMatches", type: "uint256", value: "3"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508827630"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba399a9974c74896842a179288aed"}, {name: "marketOrderEventType", type: "uint8", value: "3"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14571]}}, {name: "depthBase", type: "uint256", value: "1000000000000000000"}, {name: "tradeBase", type: "uint256", value: "1000000000000000000"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11954147318397323477663023808870198212... )", async function( ) {
		const txOriginal = {blockNumber: "4478809", timeStamp: "1509660307", hash: "0xb8ab400166fd37f155d751226789885d4e216e6ccac2c97874d14c9b4963052c", nonce: "39", blockHash: "0xc66aea37dc8762b6b7c73ea689a1a4a6202cf7c190194e6bad83d5a6f0854613", transactionIndex: "58", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xdbc913960000000000000000000000000000000059eed9abf5324fd8aa1e2ebdc360b5ab", contractAddress: "", cumulativeGasUsed: "2182509", gasUsed: "49710", confirmations: "3243825"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119541473183973234776630238088701982123"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119541473183973234776630238088701982123", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1509660307 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "2"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11954147318, 39732347766302, 38088701982123]}}, {name: "maxMatches", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1509660307"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eed9abf5324fd8aa1e2ebdc360b5ab"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7045]}}, {name: "depthBase", type: "uint256", value: "12000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11960765224770393065078766001431474030... )", async function( ) {
		const txOriginal = {blockNumber: "4478848", timeStamp: "1509660839", hash: "0x8f6d4ed1271e75202c59130daf766e9f6b44c3fb1ae36d1e202648b239af1779", nonce: "40", blockHash: "0xb313d650d3782d351672ea5fccfb391aae186c80b4dbcc199cc18cbb5a9cbb8d", transactionIndex: "52", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "300000", gasPrice: "9450000000", isError: "0", txreceipt_status: "1", input: "0xbbec37680000000000000000000000000000000059fb988d2cfd413899a3baa7d92a5a4e0000000000000000000000000000000000000000000000000000000000001bbc000000000000000000000000000000000000000000000000a688906bd8b0000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3143308", gasUsed: "253764", confirmations: "3243786"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119607652247703930650787660014314740302"}, {type: "uint16", name: "price", value: "7100"}, {type: "uint256", name: "sizeBase", value: "12000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119607652247703930650787660014314740302", "7100", "12000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1509660839 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11960765224, 77039306507876, 60014314740302]}}, {name: "maxMatches", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1509660839"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059fb988d2cfd413899a3baa7d92a5a4e"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7100]}}, {name: "depthBase", type: "uint256", value: "12000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: transferFromBase(  )", async function( ) {
		const txOriginal = {blockNumber: "4478851", timeStamp: "1509660874", hash: "0x1116293d6279226b7d96a831a65009933aed9ef8115e5832d21383c920814910", nonce: "42", blockHash: "0x14559c2a16d4f417dcf8dfeb57c0ae25d742e08b6b405c85ad321ba598eb3920", transactionIndex: "46", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "250000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x61ea6ed7", contractAddress: "", cumulativeGasUsed: "1627058", gasUsed: "41476", confirmations: "3243783"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "transferFromBase", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFromBase()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1509660874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientPaymentEventType", type: "uint8", value: "2"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [60000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11960766022203496977610603298599527197... )", async function( ) {
		const txOriginal = {blockNumber: "4478853", timeStamp: "1509660923", hash: "0x11f6d02224f4bd625d258c23e51b8bd854950ab8c7a207feecaad6ef15de263d", nonce: "43", blockHash: "0x37e17b07d56fd1d8aa0637633ecab69c54504e7b2ec1d070b4177f2215fe4d9b", transactionIndex: "81", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xbbec37680000000000000000000000000000000059fb98f1d37149d5835ee06f0578df2b00000000000000000000000000000000000000000000000000000000000038cd0000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3361181", gasUsed: "256626", confirmations: "3243781"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119607660222034969776106032985995271979"}, {type: "uint16", name: "price", value: "14541"}, {type: "uint256", name: "sizeBase", value: "8000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119607660222034969776106032985995271979", "14541", "8000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1509660923 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11960766022, 20349697761060, 32985995271979]}}, {name: "maxMatches", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1509660923"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059fb98f1d37149d5835ee06f0578df2b"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14541]}}, {name: "depthBase", type: "uint256", value: "8000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11968313170794816542146481748712617188... )", async function( ) {
		const txOriginal = {blockNumber: "4547565", timeStamp: "1510613511", hash: "0xa957aeb70de5c3de071fb4231335f467df7fe8471022e7cd8abcc173fecffeff", nonce: "44", blockHash: "0x572568e9e8840d1c54ab1aad96f9a97a0f1dda78ce301c045cff52529667348e", transactionIndex: "78", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "600000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xbbec3768000000000000000000000000000000005a0a21f9e6ad40b6ac786e2f261f90ee00000000000000000000000000000000000000000000000000000000000038be0000000000000000000000000000000000000000000000001bc16d674ec8000000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "2275263", gasUsed: "319529", confirmations: "3175069"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119683131707948165421464817487126171886"}, {type: "uint16", name: "price", value: "14526"}, {type: "uint256", name: "sizeBase", value: "2000000000000000000"}, {type: "uint8", name: "terms", value: "2"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119683131707948165421464817487126171886", "14526", "2000000000000000000", "2", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1510613511 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11968313170, 79481654214648, 17487126171886]}}, {name: "maxMatches", type: "uint256", value: "3"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1510613511"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba5dfd835423fb18105c8cbf3a167"}, {name: "marketOrderEventType", type: "uint8", value: "3"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7075]}}, {name: "depthBase", type: "uint256", value: "2000000000000000000"}, {name: "tradeBase", type: "uint256", value: "2000000000000000000"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: transferFromBase(  )", async function( ) {
		const txOriginal = {blockNumber: "4625451", timeStamp: "1511698250", hash: "0x669171406f56e74091bea73c0eb9bd3dd5b8c6f054e6255a8439ead7b0d11190", nonce: "300", blockHash: "0x145095c17d4a5b8392c66bfb73847b3d2e20b54ad71a64dc425dc43634ded6ed", transactionIndex: "145", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "250000", gasPrice: "1000000000", isError: "0", txreceipt_status: "0", input: "0x61ea6ed7", contractAddress: "", cumulativeGasUsed: "6078570", gasUsed: "24629", confirmations: "3097183"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "transferFromBase", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFromBase()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1511698250 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: transferFromBase(  )", async function( ) {
		const txOriginal = {blockNumber: "4625601", timeStamp: "1511700368", hash: "0xadcdd579a9db461edccb8e98f8ccf69f8601c54bd230a28d2e153f457c6f62df", nonce: "306", blockHash: "0xbc399faa5accdfafa509c0d8f1c0e86160415d0809e8668ace95a804a545e9e5", transactionIndex: "8", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x61ea6ed7", contractAddress: "", cumulativeGasUsed: "873815", gasUsed: "41476", confirmations: "3097033"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "transferFromBase", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFromBase()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1511700368 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientPaymentEventType", type: "uint8", value: "2"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [25000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11976895750445214176137910478804106590... )", async function( ) {
		const txOriginal = {blockNumber: "4625606", timeStamp: "1511700422", hash: "0x0dca544b50f117f4c4c8ebc40d93bc7247afe09a4abade9ad8321e57a8609714", nonce: "307", blockHash: "0x7163d6d1d5a2db1bd1f0f517e759cb8331e97f96194d4b2544a267796053c8d2", transactionIndex: "122", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "600000", gasPrice: "8800000000", isError: "0", txreceipt_status: "1", input: "0xbbec3768000000000000000000000000000000005a1aa983bfda4370a14a6a6e4a3a65ae00000000000000000000000000000000000000000000000000000000000038be00000000000000000000000000000000000000000000000022b1c8c1227a000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "4921701", gasUsed: "289995", confirmations: "3097028"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119768957504452141761379104788041065902"}, {type: "uint16", name: "price", value: "14526"}, {type: "uint256", name: "sizeBase", value: "2500000000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119768957504452141761379104788041065902", "14526", "2500000000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1511700422 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11976895750, 44521417613791, 4788041065902]}}, {name: "maxMatches", type: "uint256", value: "3"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1511700422"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba5dfd835423fb18105c8cbf3a167"}, {name: "marketOrderEventType", type: "uint8", value: "3"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7075]}}, {name: "depthBase", type: "uint256", value: "2500000000000000000"}, {name: "tradeBase", type: "uint256", value: "2500000000000000000"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawCntr( \"56221800000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4625616", timeStamp: "1511700519", hash: "0x9b8d26671de71caa704f89aeb2c17be42a92a1c435244b6bdc1c49472a3298bd", nonce: "308", blockHash: "0xb737bebfe9059d7e70edbc1641aa68b9188a7fe32c36294f9b150d82b7ae6319", transactionIndex: "145", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "150000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x199f079100000000000000000000000000000000000000000000000000c7bd6de1a21000", contractAddress: "", cumulativeGasUsed: "5902847", gasUsed: "37377", confirmations: "3097018"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amountCntr", value: "56221800000000000"}], name: "withdrawCntr", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawCntr(uint256)" ]( "56221800000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1511700519 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientPaymentEventType", type: "uint8", value: "1"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: -1, e: 16, c: [562, 21800000000000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transferFromBase(  )", async function( ) {
		const txOriginal = {blockNumber: "4625654", timeStamp: "1511701086", hash: "0x67a4f0c8b4c1b06ebacdefbfde827ac81a6f725af70c2eb0d6dea7a5f02726b7", nonce: "313", blockHash: "0x3a5ec7b1c45f2578c4129c26dcf6bc6cd48d6ff24bc79411bca4fbfe2d4f1c14", transactionIndex: "128", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x61ea6ed7", contractAddress: "", cumulativeGasUsed: "4013929", gasUsed: "56476", confirmations: "3096980"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "transferFromBase", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFromBase()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1511701086 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientPaymentEventType", type: "uint8", value: "2"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [53997, 40000000000000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11976908089873688711001613636757671734... )", async function( ) {
		const txOriginal = {blockNumber: "4625724", timeStamp: "1511701981", hash: "0x36a4e6bd8a5c06c80ecf928be13c2ccce087706becd3d6dbc5217e396a0215c5", nonce: "318", blockHash: "0xaddd0e99bac0aeeb0cb568e6f0c873b82ac56c9e0eec4d86d10c2c45a1f7d77c", transactionIndex: "47", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "700000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xbbec3768000000000000000000000000000000005a1aaf99344a4dfcba03b13bd2b8182000000000000000000000000000000000000000000000000000000000000038af0000000000000000000000000000000000000000000000004aefbaebc377c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "1750580", gasUsed: "353817", confirmations: "3096910"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119769080898736887110016136367576717344"}, {type: "uint16", name: "price", value: "14511"}, {type: "uint256", name: "sizeBase", value: "5399740000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "4"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119769080898736887110016136367576717344", "14511", "5399740000000000000", "0", "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1511701981 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11976908089, 87368871100161, 36367576717344]}}, {name: "maxMatches", type: "uint256", value: "4"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1511701981"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba5dfd835423fb18105c8cbf3a167"}, {name: "marketOrderEventType", type: "uint8", value: "2"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7075]}}, {name: "depthBase", type: "uint256", value: "500000000000000000"}, {name: "tradeBase", type: "uint256", value: "500000000000000000"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}, {name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1511701981"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba37bd963476a8dabcf58ac7ab4b7"}, {name: "marketOrderEventType", type: "uint8", value: "3"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7090]}}, {name: "depthBase", type: "uint256", value: "4899740000000000000"}, {name: "tradeBase", type: "uint256", value: "4899740000000000000"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawCntr( \"114087000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4625727", timeStamp: "1511702024", hash: "0xfda362557a89b7bba22d0b63b968f219b087314752b196a32ec61d8133c4ac3c", nonce: "319", blockHash: "0xb5ad7d2f71eaccbdf3a7c709c132eab44a2247ad337803df66bd11160bf91ed0", transactionIndex: "65", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "150000", gasPrice: "5568750000", isError: "0", txreceipt_status: "1", input: "0x199f079100000000000000000000000000000000000000000000000001955185a47d7000", contractAddress: "", cumulativeGasUsed: "2558268", gasUsed: "37441", confirmations: "3096907"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amountCntr", value: "114087000000000000"}], name: "withdrawCntr", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawCntr(uint256)" ]( "114087000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1511702024 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientPaymentEventType", type: "uint8", value: "1"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: -1, e: 17, c: [1140, 87000000000000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: transferFromBase(  )", async function( ) {
		const txOriginal = {blockNumber: "4625785", timeStamp: "1511702591", hash: "0x2fb8d70248566edcba65b1aae50a8c96cfcfac74ec02d0fe7e3827551589fb81", nonce: "324", blockHash: "0x522c5366a9d083d4a396148dc2ddf259e6f5a2b1c34f874a6e3bfdebbc7b5096", transactionIndex: "57", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "250000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x61ea6ed7", contractAddress: "", cumulativeGasUsed: "2073680", gasUsed: "56476", confirmations: "3096849"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "transferFromBase", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFromBase()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1511702591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientPaymentEventType", type: "uint8", value: "2"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [59708]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11976913346064451126909044674481360832... )", async function( ) {
		const txOriginal = {blockNumber: "4625788", timeStamp: "1511702644", hash: "0x84f80891544145dcc8c0b003a7736178401f430a712104ab4770dc1c6f02e91f", nonce: "325", blockHash: "0xd899d171bcb3e38d2c9b7357c504a17ee91f08e4767fccfa32d58670fcadf09d", transactionIndex: "114", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "600000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xbbec3768000000000000000000000000000000005a1ab230a0f94009828e24fb39289d8000000000000000000000000000000000000000000000000000000000000038af00000000000000000000000000000000000000000000000052dc8af720e7000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "4075428", gasUsed: "277005", confirmations: "3096846"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119769133460644511269090446744813608320"}, {type: "uint16", name: "price", value: "14511"}, {type: "uint256", name: "sizeBase", value: "5970800000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119769133460644511269090446744813608320", "14511", "5970800000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1511702644 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11976913346, 6445112690904, 46744813608320]}}, {name: "maxMatches", type: "uint256", value: "3"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1511702644"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba37bd963476a8dabcf58ac7ab4b7"}, {name: "marketOrderEventType", type: "uint8", value: "3"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7090]}}, {name: "depthBase", type: "uint256", value: "5970800000000000000"}, {name: "tradeBase", type: "uint256", value: "5970800000000000000"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawCntr( \"125324000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4625792", timeStamp: "1511702711", hash: "0x110afa8d8b2520e2069249ad7a7103b9444a4b44af874ac3a6f4d202770de3de", nonce: "326", blockHash: "0xf52ab0918235794ebf47dad1528af2242b852b014b52b1565b4d3012b9796b5a", transactionIndex: "67", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "150000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x199f079100000000000000000000000000000000000000000000000001bd3d8395d4c000", contractAddress: "", cumulativeGasUsed: "2716531", gasUsed: "37441", confirmations: "3096842"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amountCntr", value: "125324000000000000"}], name: "withdrawCntr", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawCntr(uint256)" ]( "125324000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1511702711 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientPaymentEventType", type: "uint8", value: "1"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: -1, e: 17, c: [1253, 24000000000000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: transferFromBase(  )", async function( ) {
		const txOriginal = {blockNumber: "4628277", timeStamp: "1511737732", hash: "0x4bd250e2ea51f42823715e9b5ef71d2ee6c90f6afa5e47f3dd8c70941826907b", nonce: "331", blockHash: "0xa5bc03ee50ea7ed9cad97dfbf14cf1c7042b1e5dee35a4f5dddc5402149f6ccc", transactionIndex: "143", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "250000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x61ea6ed7", contractAddress: "", cumulativeGasUsed: "6407959", gasUsed: "56476", confirmations: "3094357"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "transferFromBase", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFromBase()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1511737732 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientPaymentEventType", type: "uint8", value: "2"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [64670]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11977192203796491179847864136411522364... )", async function( ) {
		const txOriginal = {blockNumber: "4628294", timeStamp: "1511738022", hash: "0x12a8aae1f3fe63f66ba4dae753e24a16e7f9528e302bca0daf2af0d4a9dfe37e", nonce: "332", blockHash: "0x1d07a7c3d5b1da0baebfcf7c0ccf04a22461b907eb5980701c05a0fe05b2e259", transactionIndex: "35", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "600000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbbec3768000000000000000000000000000000005a1b3bad6c414a60894a95c833fd746100000000000000000000000000000000000000000000000000000000000038af00000000000000000000000000000000000000000000000059bf663c8273800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "2659982", gasUsed: "277069", confirmations: "3094340"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119771922037964911798478641364115223649"}, {type: "uint16", name: "price", value: "14511"}, {type: "uint256", name: "sizeBase", value: "6467000000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119771922037964911798478641364115223649", "14511", "6467000000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1511738022 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11977192203, 79649117984786, 41364115223649]}}, {name: "maxMatches", type: "uint256", value: "3"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1511738022"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba37bd963476a8dabcf58ac7ab4b7"}, {name: "marketOrderEventType", type: "uint8", value: "3"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7090]}}, {name: "depthBase", type: "uint256", value: "6467000000000000000"}, {name: "tradeBase", type: "uint256", value: "6467000000000000000"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawCntr( \"135739000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4628312", timeStamp: "1511738171", hash: "0x9cb9aaf4d7bee0c9a951dbd443187ba4a8fbfb1d7c8a783b04ec0324b72f8194", nonce: "333", blockHash: "0x6385a47af074ae591346943dc8e5ab62bfe2780dc8c583976e578efaa1c300ae", transactionIndex: "28", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "150000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x199f079100000000000000000000000000000000000000000000000001e23de6bd2ab000", contractAddress: "", cumulativeGasUsed: "1277157", gasUsed: "37441", confirmations: "3094322"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amountCntr", value: "135739000000000000"}], name: "withdrawCntr", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawCntr(uint256)" ]( "135739000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1511738171 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientPaymentEventType", type: "uint8", value: "1"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: -1, e: 17, c: [1357, 39000000000000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: transferFromBase(  )", async function( ) {
		const txOriginal = {blockNumber: "4628560", timeStamp: "1511742168", hash: "0x994c8d41113db17e7fed09f870b8a2e58ccb90cc504bd1f57f6b34648989f481", nonce: "338", blockHash: "0x56e24d50dca497ec02bc45ca799e1b4fde7f7ae47af42091eeb0c11105944da1", transactionIndex: "69", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "250000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x61ea6ed7", contractAddress: "", cumulativeGasUsed: "5731076", gasUsed: "56476", confirmations: "3094074"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "transferFromBase", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFromBase()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1511742168 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientPaymentEventType", type: "uint8", value: "2"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [75175, 40000000000000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11977227151203090731611536275736027421... )", async function( ) {
		const txOriginal = {blockNumber: "4628574", timeStamp: "1511742370", hash: "0xecc347c2a23a4b041a045ca2597520cf66c86cbcd1988cbce0aa33b7a4951851", nonce: "339", blockHash: "0xf4ac86c0317d355ad53172ec3b9401646f9a31008d818ea340e4543ebc9c4148", transactionIndex: "45", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "600000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbbec3768000000000000000000000000000000005a1b4ce867dd45a8acc7deda0b14cb2800000000000000000000000000000000000000000000000000000000000038af00000000000000000000000000000000000000000000000024f2f54380afc00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "2723867", gasUsed: "294787", confirmations: "3094060"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119772271512030907316115362757360274216"}, {type: "uint16", name: "price", value: "14511"}, {type: "uint256", name: "sizeBase", value: "2662460000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119772271512030907316115362757360274216", "14511", "2662460000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1511742370 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11977227151, 20309073161153, 62757360274216]}}, {name: "maxMatches", type: "uint256", value: "3"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1511742370"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059eba37bd963476a8dabcf58ac7ab4b7"}, {name: "marketOrderEventType", type: "uint8", value: "2"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7090]}}, {name: "depthBase", type: "uint256", value: "2662460000000000000"}, {name: "tradeBase", type: "uint256", value: "2662460000000000000"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11977228694722098155941320329504565624... )", async function( ) {
		const txOriginal = {blockNumber: "4628585", timeStamp: "1511742551", hash: "0xfecb8eb501cfd8834bf3edc60a3610b128dac09e77e933e49e1b100b0b5e53ec", nonce: "340", blockHash: "0x62acb8bd1a915e1e954362a78952dada35104f69baf9fddb512becf037e478b9", transactionIndex: "48", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "600000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xbbec3768000000000000000000000000000000005a1b4dab39a740a9bd239b8dd7b39eb400000000000000000000000000000000000000000000000000000000000038a50000000000000000000000000000000000000000000000004360b589641a800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "3065158", gasUsed: "293409", confirmations: "3094049"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119772286947220981559413203295045656244"}, {type: "uint16", name: "price", value: "14501"}, {type: "uint256", name: "sizeBase", value: "4855080000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119772286947220981559413203295045656244", "14501", "4855080000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1511742551 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11977228694, 72209815594132, 3295045656244]}}, {name: "maxMatches", type: "uint256", value: "3"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1511742551"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059fb988d2cfd413899a3baa7d92a5a4e"}, {name: "marketOrderEventType", type: "uint8", value: "3"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7100]}}, {name: "depthBase", type: "uint256", value: "4855080000000000000"}, {name: "tradeBase", type: "uint256", value: "4855080000000000000"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawCntr( \"152937000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4628597", timeStamp: "1511742667", hash: "0xe9b4a9e00248ff373cd2907fe7ceced8c06aeab10ff95234833f6403a4e3e860", nonce: "341", blockHash: "0x9c8a9ec977b5d86394a54cb92658a02ef8391a9261635cdcaba3d4973ebd8029", transactionIndex: "87", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "150000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x199f0791000000000000000000000000000000000000000000000000021f576426039000", contractAddress: "", cumulativeGasUsed: "2679646", gasUsed: "37441", confirmations: "3094037"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amountCntr", value: "152937000000000000"}], name: "withdrawCntr", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawCntr(uint256)" ]( "152937000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1511742667 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientPaymentEventType", type: "uint8", value: "1"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: -1, e: 17, c: [1529, 37000000000000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: transferFromBase(  )", async function( ) {
		const txOriginal = {blockNumber: "4628653", timeStamp: "1511743472", hash: "0x00e405694c660c0bee18552ce5bb151479f306a2eb3cac118991535a059f6b8b", nonce: "349", blockHash: "0xe344c38a52302d6fb9f471cc570cc09469d95ec566fcb47008d79ff1bec532e7", transactionIndex: "20", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "250000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x61ea6ed7", contractAddress: "", cumulativeGasUsed: "716941", gasUsed: "56476", confirmations: "3093981"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "transferFromBase", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFromBase()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1511743472 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientPaymentEventType", type: "uint8", value: "2"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [70980]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11977238546225481580889817416070940597... )", async function( ) {
		const txOriginal = {blockNumber: "4628670", timeStamp: "1511743684", hash: "0xbdb988fc85e089faba4313622a91d46c04fe1d465116b103a5a52930f3e86564", nonce: "350", blockHash: "0xf6250dbf83435693e122991ae8b9ef31a2e2cb932bcef6d0f6aeedf038a6599b", transactionIndex: "52", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "600000", gasPrice: "6000010000", isError: "0", txreceipt_status: "1", input: "0xbbec3768000000000000000000000000000000005a1b5286a8e549088d55de2eb484cd1800000000000000000000000000000000000000000000000000000000000038a500000000000000000000000000000000000000000000000062812964a7b9000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "2226395", gasUsed: "278345", confirmations: "3093964"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119772385462254815808898174160709405976"}, {type: "uint16", name: "price", value: "14501"}, {type: "uint256", name: "sizeBase", value: "7098000000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119772385462254815808898174160709405976", "14501", "7098000000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1511743684 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11977238546, 22548158088981, 74160709405976]}}, {name: "maxMatches", type: "uint256", value: "3"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1511743684"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059fb988d2cfd413899a3baa7d92a5a4e"}, {name: "marketOrderEventType", type: "uint8", value: "3"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7100]}}, {name: "depthBase", type: "uint256", value: "7098000000000000000"}, {name: "tradeBase", type: "uint256", value: "7098000000000000000"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawCntr( \"141889000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4628674", timeStamp: "1511743750", hash: "0xb9ed2081346aa82c0017f5497c401f16be0d2a44c884eaef78f9223166ade517", nonce: "351", blockHash: "0xb486a24f6935ca2ab718265f8d0a3629ce90a6c6ab2aac0bd289ec224ac49715", transactionIndex: "69", from: "0xfa4e7035b34294407e5df1603215983d65e5a773", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "150000", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0x199f079100000000000000000000000000000000000000000000000001f8174b32891000", contractAddress: "", cumulativeGasUsed: "2410160", gasUsed: "37441", confirmations: "3093960"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amountCntr", value: "141889000000000000"}], name: "withdrawCntr", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawCntr(uint256)" ]( "141889000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1511743750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfa4e7035b34294407e5df1603215983d65e5a773"}, {name: "clientPaymentEventType", type: "uint8", value: "1"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: -1, e: 17, c: [1418, 89000000000000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "44800614216334571" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4797501", timeStamp: "1514248232", hash: "0xc585dfd6dc5026e94c20473a5258236a36178aed07a11e24d95d4365719aebb8", nonce: "1", blockHash: "0xef406ff24b1c1ea31f180efed0cbbfd1679939866d975034cafd8be925ca78f9", transactionIndex: "27", from: "0x89f1757e9f7c4e7975fbe240aa043b426f0bdf2c", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "200000000000000000", gas: "150000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "1764298", gasUsed: "44009", confirmations: "2925133"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1514248232 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x89f1757e9f7c4e7975fbe240aa043b426f0bdf2c"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 17, c: [2000]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "225043095901968032" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11997112007303061094243570160853579881... )", async function( ) {
		const txOriginal = {blockNumber: "4797517", timeStamp: "1514248447", hash: "0x05854c56a0d9a215827bc6654d251d3fdcfc0895ac5c5eb669d015ab5cb7c4ab", nonce: "2", blockHash: "0x52ab309058c59713b6f0f5f1a6989781177a1d9518fd1a593bbf03090908ec54", transactionIndex: "45", from: "0x89f1757e9f7c4e7975fbe240aa043b426f0bdf2c", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xbbec3768000000000000000000000000000000005a4198e6195a4b87ba87a13f660fb4210000000000000000000000000000000000000000000000000000000000001b940000000000000000000000000000000000000000000000006f05b59d3b20000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "2000548", gasUsed: "323178", confirmations: "2925117"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119971120073030610942435701608535798817"}, {type: "uint16", name: "price", value: "7060"}, {type: "uint256", name: "sizeBase", value: "8000000000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119971120073030610942435701608535798817", "7060", "8000000000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1514248447 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}, {indexed: false, name: "maxMatches", type: "uint256"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0x89f1757e9f7c4e7975fbe240aa043b426f0bdf2c"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11997112007, 30306109424357, 1608535798817]}}, {name: "maxMatches", type: "uint256", value: "3"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1514248447"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059fb98f1d37149d5835ee06f0578df2b"}, {name: "marketOrderEventType", type: "uint8", value: "2"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14541]}}, {name: "depthBase", type: "uint256", value: "8000000000000000000"}, {name: "tradeBase", type: "uint256", value: "8000000000000000000"}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "225043095901968032" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: transferBase( \"7996000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4798550", timeStamp: "1514263000", hash: "0xc4aed3c79f3585f2aed53bff4b31ff81ff1b6e2fdb7651363f3512012eaaa9f5", nonce: "3", blockHash: "0xda26d48f279516cd6e63cec4736ae153bc98af429d356853a9af36d40844b08f", transactionIndex: "54", from: "0x89f1757e9f7c4e7975fbe240aa043b426f0bdf2c", to: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd", value: "0", gas: "250000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x3c13fc330000000000000000000000000000000000000000000000006ef77fa2a8060000", contractAddress: "", cumulativeGasUsed: "2220514", gasUsed: "45706", confirmations: "2924084"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amountBase", value: "7996000000000000000"}], name: "transferBase", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferBase(uint256)" ]( "7996000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1514263000 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x89f1757e9f7c4e7975fbe240aa043b426f0bdf2c"}, {name: "clientPaymentEventType", type: "uint8", value: "3"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: -1, e: 18, c: [79960]}}], address: "0xf8d15960aa6aaf5972dc54cf002951553906c7bd"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "225043095901968032" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1531302200000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
