const BMICOAffiliateProgramm = artifacts.require( "./BMICOAffiliateProgramm.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "BMICOAffiliateProgramm" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xbe44459058383729bE8247802d4314ea76ca9E5A", "0x956FdF7BE4453E26859B0c859D236c268b79CEB1", "0x19d7A9aD3B49252FD2EF640d0e43dFD651168499", "0xb8Cd11969dF4A021D4d9C72BB4A2ab07d29e06E2", "0xdAE0aca4B9B38199408ffaB32562Bf7B3B0495fE", "0xf3CCAB1FE47F07C686dE54e5Be986F9bFD3e8641", "0x88028E4E83e041c699128FF063089484dCc83e18", "0xE6fBFa4f8eca66e71A51fc6fC03131C4c220eF15", "0x54adD64d76aFA1d0BFFF950ad13a61610Be07E48", "0x9889B6250D1D215aBfe725409c03387450E614B4", "0xC2BA0EB60cF4DF1B0346d7B4ddF8355557e8BC82", "0xc66EAf7A7F6C42a793fb7C51d5cb5772803C9949", "0x64d5Dc419506163CBF5BB076dd3c24f74d8eC920", "0xD2cB60E5930ea6E365Ee4749544E4962d3aCB9AA", "0xb6020e51d006e933E7995E253FEE1d71F17a23aC", "0xE67d82e79C0F9Fc41F0de7899B08238f54BDa184", "0x241057cC3551e82cD551aDA290182Be47D62D9Fc", "0x758348250E38bc48cDAb94cf408633D8EaB29812", "0x6709c49270f5f7F5C57AD9a2E1e767653fcBAe43", "0x052ff9eafFd2871C0c25A769c8765382CF23B298", "0x03d618e2d50c8EECa5AAdDE7B4D5D6036aDf5e71", "0x831b122471d2058C3d694189284Dcc5CaD2084eC", "0x0D509a1937e5Ca2D2C3D99888D0730d79efF7caE", "0xbaB8c44106Dc795BF7dc67291712234E99bDE9c9", "0xbFa85Bf9013dbf46693EcA148EeD3da303A608B7", "0xA388B4C12Cc2Be2B621C2096f34217181D4cA32f", "0x1843906d36cC93F52B651F0aE78D3b5Ac1c7c5b2", "0x7fcA8cCa572e91918e9dAa1491d3024F395Ec2cF", "0x8ABc3D9D5E546714077a7B3bcF9Bd3878e0747dc", "0x763576754ca949163Af766475562AE94B7dD5937", "0x6E67d8A7Cd4009513fb53B044519280610560E56", "0xD430709A70dA06c5c25157A97dbA3C3e664590aF", "0xCde89B37188D891cC151E6EB55648fF29Ab767bc", "0x73FD3c61f22940F17dc6568F1c1E5CEc8b5465a9", "0xfd8A4D3812b76c5838AFF93F944FB545f659188D", "0x7BFd8695b8913f800B0acAdF1f1166fC57FB5a7B", "0x5D56A3857C02777Bc26038dEDEE9812a198b4A97", "0x78bA52ce8Caef22a5f4D45760061ba3BEB2f07B1", "0x95ec882af9e576F1Fd7f108E16E650b60BD3c548", "0xE4a66E669a257B8D0B1bd1565B136F9B5CD1B3f4", "0x0f6e7C3d193486BE7b57319250B5129ac0C65943", "0x2F2Bb1EeDeF5a16159939cC742F3CB0003cbFbB1", "0x3E3A69A49bEb0927B7E06f0A3D1eb0c3579421F7", "0x6C28E8bcA252dC74a007515E6b7cFbc476990AB0", "0x73734Ec6E4a0DbaBF39C47fD68E64c819B5B29c8", "0x7aaab6Ec7a6662D134cbBD089d288bb094BF3AC6", "0x07B453c09A85929cc95D386bd014BFF4C951C0d4", "0x1bC69E5D940e772BDF804EE42b1b8eeb9e29C82C", "0xc7Bc11FC9fd6288423CeFACfE3509151ac7f36F6", "0xfFc1a14E91702a99445bA9C5CdFA836Af8788839", "0x8cc1e6Ac73c8E5BBf06b9B61E5eec80bd89E4521", "0xD7a866C8B1249A8828B9e66C934097c99e30506b", "0xC5b491990b5004E8C6364B57dD17B4963E495D14", "0xBdd9F447f324Db9fCB4633FbbEd2c594566fA2AC", "0xaF88364f4794173D532674B77162918fF26965Cb", "0xa0d0DaF0B0D8458B7a1c35bD757A9FFf28431C9d", "0x7d7A2Ae37BB94D8dD6A89d704B0957584F059cb0", "0xfE369dddAB8f9789a65e5659Df575CA4621F4b3A", "0xf77fe2F825AB7A3b761D00127ca3283D4E0aD0f9", "0x7F8970d96B777172d0cCEEc41863D1c44fdc51Fe", "0xb886F3949078953dE4269730A7aFc6e4a42936b1", "0x12a15779F7E34EfF7d1E6f87a86f55B1bfb9Ba75", "0xd5f1C24Ca3fD01E9843411E9227AE90816B493Dd", "0xf7d6A313D77C624a295a611919D1B48B42F0Ee6c", "0x1a25d4d2fb6572C728598F349DC36cd943e1af8E", "0x91ebB42996f1d65e31FEe8203D1B39ac779e6Ea1", "0x6a432CB101C688C437fF36bF1c85115af7FE94E8", "0x5f5f2B9A72C1fA44A51Fc365B4136AEA2cc4BC63", "0x8f66C9529C155A863a09Dd7C4A2FbC4cd5cfA72E", "0xE868576f360F2884287eCB6351f15e9366dc0aad", "0x7A9aa06F9Cf111847db36a80B87E0A8be6cf5C54", "0x00aC77E033fF5ea56c8432815b62E3505f256FDF", "0x121808609d8ec3FDEBe9c26f1D6389C54377e9B6", "0x63dadbf34d653d895Af5F8FF10771DF2B141B994", "0xf40F2416814D2eF2aC874f7532CEbB488c971251", "0x11aF34d2a8a0d881DCfAe3dE0Ed2fcf039A54dCb", "0x0aba768AC87fB4384Fc08FF1B3021EE2454A8303", "0xC2B4dfA31512b678bcf129a3EEBaF0DD55DAbB95", "0x391D08F89a333EaA5f4998B6f28B70d9345068B4", "0x6cf3C0bB276292ebd829FfAc229fE350821eAac6", "0xe49C075C0b631d8b3e55862C2a3533b197DeBF45", "0x88967c84127e31B5780B63203B874Fd26e991D86", "0x75A1Ce1BD9e327D828fEBf7193a1D918c37FddED", "0xa7CFDb115614831433bA21b7ef49D82Baac10750", "0xb78b22340E247DB1D638D1430323f9B66D51e0F3", "0xea935b4AA19e9a3B45457E2139cE547322d36007", "0x4639B5ad1fC57a6AAb1099171DaDa00Da0b98EBa", "0x629c77BaD3FEdc593D12137C59879969188421b4", "0x80836Bc33c06Ddac7C0bf62968cad64c61989c2B", "0x2192d37471fBc1F5A3A0d48AE9014119015b7b6c", "0xd1ED9d7dA49B28adf279Cd6F3724371e7656a6e3", "0xb7Fa81c55203e3993112D6a774F31de617A23f7A", "0x162b12A47B503D90B813764b191Dc44a29bce02c", "0xfCf592Ced199b28fF1Ea76e1A2E50433c526407F", "0xc2875b2a55bdab74Ff04FF3B3E01e6d83cC2F1cF", "0x460Fb852aCcF750c895460aa774E1621B4418c51", "0x0D5F21A4922F8913c2D40240F10f9cE0d00b6eac", "0x7aDc44768E086A8D61e4A6473A3D798771c93be5", "0x0159d0D21185CEB8fF628917E8D5ea8863404e5F", "0x68F302562aEF1B6DbE8Cb6A7d8CA238aa3e2693c", "0x41bFe13b7bec7CB8A81281B4C48D80f9B2c1401c", "0xbd2f6A5665912A19B287C767FB21D20f552290aa", "0x45D472F4e9F58cC6dfEedb386A948e97A325cBd4", "0x6b9610B7Fac20EE1f20fA175C73bFa4d4dca8Af1", "0x1C6789D0F5622Ef130046804631fF8fea7608F72", "0xdCa683cA5cc6d49bc9D020EcE144081c688EBE6f", "0x66EB3d80528c8dDe86B379E507287BCCD310FcAB", "0xb5a7e2a01002854fe67ddb1BCf6a094A52Ea1b46", "0x3F3DdEfb0aA770f8fa7733D825D5E07A4e70919f", "0x3b55A11F50fAf4d278DF6Bb0186B99f1e5919705", "0x4452b58D2FDB19dc757085ef6200a5fF549FBdA9", "0x6C9c02059F4Da8A17fb0A0C2EE2D92f225d0677c", "0x11C0E2e6De0c78A8bCfCBE2a17a67545FdA7Be97", "0xB0103B1c235d58aa8065a6627a0331bB55807c73", "0xb2412DC96Fd03EA36c1e0BDe29BF3481204ad6A3", "0x600d72a8Bd076ed2aBBC39088AF54E0ee63ba6Ac", "0xd72C885dD93F6b409EB7A6F27aEd810F46aBA2b2", "0x5FBFaFc94523A817e2F59D83283Aa1d6B8088616", "0x6cD7c47c5954bC0b9c61bb4F8aD76294d02Af1d1", "0x72670A36a25680155EEeE7Dd11fd75D4006d44b7", "0x65de3aa3De5ED2b07293976EB44b77d02D27Fb70", "0x087D9B9754D11a60dc53577Fb8795067647650bD", "0x3B04eeCE9B08Db9b159A8206fEE8Ca7ed3e4fb79", "0x767f3E5Fa0aafF69FB80233e58f0C3AFeEDF04aC", "0xafbC7601129D8179f40E35a7E77756cd903e0657", "0x0E15eE423A2f73118E1Ba1D01236b29EB7F6D9D1", "0x52E323B066d1189735A3f9418D8df1daE18A433E", "0xaEe94133925A8767929938Bd08e1B4E155400d14", "0x55141A0dBc5C8B0B609BCe8BC392E90303EE126D", "0xC689200c07b79CBfF7171E60e4e25EEE7d19B3f9", "0xc1d688f961f9A4c706D58d185AE70876e1C2b2Eb", "0xa7C3455D43F34eeDCE2B209eA668266d5be2d69B", "0xEC959A871C83266A179d19c6512Bbe6B5f6c4724", "0x1F86C3Bd13B79Ba03648D7053097F4d448B09A2C", "0xa32d5006D5d43f7975B89d0936f881dE3A610b31", "0xB752d5aC0B00d98AE53e824542e5ADc6cbD510a8", "0xa46B32E2D55893b7a4Cb6A1DeFcA9C8CefD25666", "0x9889C5e68c21a5b10529B052cd4aE98C111c4537", "0xf0c6130c69EBff2a0E5b27Fc72034571F127628C", "0xd8fd1b0fa1A35B9dbfB0acB3D810FFB822fcC117", "0x1FC3f3E0Ae9228C059bCD09D43E769e37207deaF", "0x4132314204Cfb248479B4644b7D99062Dd1E18c5", "0xcd9E6E0E63C5611ab1988e0569E3aD89b86086c6", "0x79A4694E0539Eb6611507aB363fcf6F9d93c6bC6", "0x4B7FC9a9347E51f8959e02994D526FDB026b1cd9", "0xE3Cd587613e7B6fc47cA76bf8E4cC896ae8eb0a6", "0x3d3adF01B8B38D6C7A25B8eDE8E2dF254F7f7759", "0x8D73C4B5C50ad59C3923B9fE1e75Dbf035b7F110", "0xDb9d72FAB34eD9C9c9dE17f1ee87dbA46984510f", "0x4553c90540b35E3EE36BfcDb04fD46404dCBB27F", "0x5554E40290409C3EB164923F0836f5E04151b703", "0xEe53727c31B5790c3EF9511BBB545232705aDcBe", "0xE05Ff9F1cB76762E4b2F44Fa4Ac09fE9DB943bcB", "0x10A969537236A282574Cf159E412686EEE0faacb", "0xEf079573A14f9620e4400f14aF36B7438332fC5F", "0xFA5F19cFB5996be004Ca3DE2Afff19Cf7C290dFF", "0x66C4E8bE4e2C7bFa4FB9b1e56191839cCEB5288c", "0x94bDEe80334867BF5D9725aAe513Bb3d5F9f0E33", "0xF4DEB0c8A5da8bc25f5d096ab792425BA1600499", "0xa9De82B1452b3D17a755144E040c2ba8b5D6Ef29", "0x25aD8e40AC360D12D7096564F04FE6Da4197D019", "0xd9e5519f349b505Db17a985D9078664116A564D3", "0x0C95959EB2056d86552baa4B859288C84D74a7e9", "0xDE0bF7e29e763847b0596c7CA1747821f4f5582B", "0x7231f1497be3E1E4883A9289f2d908edad7943ED", "0x17417fd1EA21A12b927B836114EDF66AB58130E9", "0x4895c362216A8bF75C62b067B042DB2d1e492717", "0x5CA8f9C9EbC704eBB88E42E243Edc011cea50E42", "0x00535cf7066462210470166Cd36d7b8254eE0D3F", "0xb63513c128F0E92a42a62494634eC61634d730e9", "0x6b6C52a83795514B3E610a96d6Ae2e7c435CAab3", "0xFb9199F8E6e9bbf8dB8FB42a1F8d51ce6b48d664", "0xEae3080E3a41d38740c5374E8777dccCbE2f7a4d", "0xeAFD621cDB0D6E576bA86C321c30407EB7D7FdBb", "0xd361412e00563d1494FBBc7769A48fe52290f04F", "0xb4Dc963c33eBaE7e9B83941EA707AE39EaF5d960", "0xB4BC199Fb46ed2bd552c9253D27fD59A50eD7372", "0x0aeF85f7ac4dAd6126F63b2F92751984dbB3487f", "0xa3e6dA03A755C937fB32f7BCd76cfF750CCc05cd", "0xf858734521d3B0b6c774aEdA13eAaF5AaCB2706B", "0x715673237674343aDD4759c1c961e702c86a0a55", "0x7eBaDa6BF6b52a9c852aeb0c47A4fd2a537e83A2", "0x963D84387a798A3A6d434828fA34976D1Dbe3eca", "0x6053F9C1ABFa158396a6934fe897100296c7DA76", "0xDc168D1a292d957db8213184fD111df610C52Df1", "0xD3A4567f1C0C5d2fd6DF174eea78e03122B8AD55", "0x4eF2516C2C452f67dDD07ffb35A5E8699144694A", "0xa9C305522abF3B797d21967C5cE2d12A2Cd44c52", "0x095037Aa9B136184076445Ac21a64454752Fb878", "0xC5742aFA93De037a0041Fa6aA7bAe95997Bf8974", "0x9b8ADbD42bb5Ac763f5aE2A97C60B23737332886", "0x2e081852E88C22d2DA76a93bc37696A70d048717", "0xAd2D3F5CDe8a3FCd8954AE1eaB34Fa784583650B", "0x4Ec2cD9403Cfb2E04a0b073DFc22702eD2B50eef", "0x2DE79e18976842500Cfe5E4FB4C47d83d7EB6BEE", "0x2022222309FeDA8CAD2463585B5839edf90a188e", "0xaDA6B8c3c74C129C2B34332a270aD6172FffEed7", "0xeE0696EB59E25d7a95105C6F5Ba086c686DC09c0", "0xF2431f34CbFD80009bE83BD82bc5aaBB38E47679", "0x0Cd0909399134F6855A85f06170dD18935d53e92", "0x453bBEE98cb1787eCAf7bAa8513CF9abfbcf138E", "0x561bB66cc59726c04D51A7e5aB4194f7F6611bA3", "0x830ed592B2f26F5E7A7d0bEB36d46Ae3C3663517", "0xBF7fcc6CA052550eC5c4b4aD80092CA1EFa0038E", "0x4fdF6E883bF0A2Ae6F49ae39eE2d80283aFD7B86", "0x7a03ABA179CD2F96b7F56580796a84a9Be04dAe3", "0x29e0a70BB9B5b0A819B2E1473744a872C1C397a2", "0x4f14C30a70093fFa85FF5D9DaD02929af3B4a4eE", "0xD7Cc52A97c84Fa1A1e1926b05508A7Ed7D7A493C", "0xC080F1C31fCf41f9AABf6d41C7A2BF87c4f06EDC", "0xD5a9cC70E7f82EB9839b3f8f96B71BF71F33B6E7", "0x9a946fe02237E692Dbd417FEc46f433F45d21A3C", "0x0B2B4dffFa99338356945813cAB90d41ce17D135", "0x1437Ab9906c19eE262c64137D9420778f2833191", "0x6aF5D35D0109dCccbc87FDF90b065a65E6684bA7", "0xbDA7Dc4CDC959ebA0F5eD893b082CDCb1AB34395", "0x739340d28339B0af5F85B2dbCD01A50B0eba1E08", "0xd642e885FBDb068e7bB9E813Bd1E3A47566A8fE1", "0x92E3Ad441b552510635c8fE547FbFC785dee500B", "0x81A684560210dC2A7C13788b5822F0B00E854794", "0x9C1385840E27822Cc1B0caE3Cb7E487eEB1d5235", "0xCF5201efddE4f23b4C8814B88de28702F15A91b4", "0xa5b5837952C4d8222aE162D2095FC3722ad7087f", "0x94B7fa1a30A0dBCf98e56012606B6bc3b68340A3", "0x310FB2a1b1e92c693c3704cd44b654751316c6A6", "0x9D9a1dCC4598be0cdDBd4c5Db28d3633F60d0e35", "0x4fC7D5799191498BAC13bB1aefC79eCB594B8ba7", "0x7a3E2962e1cc04Bc37b052483F13E07201110725", "0xCCaA1570ADA0957f339Fed1c6d7A9F7409C8Df74", "0x875Deda9A100690Eb71c5df995db8F13B9646dcF", "0xC50952C16CBE77426D02AA1B4816fd11f656dc35", "0xAA47681C48E0340DF17682E4cB083720DfF07EB5", "0xff4Ca9FF8474F4aC408bFC55219AA4A37857F4Ab", "0x10CAd80Ca7AfCa7e66fAA73dEe13c18Ae4BC5A7c", "0x1B1F884FF9Ec02Ce46C86BF7fa62d037B46Deefd", "0x28aebFFCdC49e91e39D12DABfB6027219e7F8701", "0x281e10476fCe1D92F9D60e46b3d0793999B60729", "0x00074e65C81A692996676f5EdDb20b58e1475e0B", "0x50b0835737e92766478DF4f215b364c650F9Ba35", "0x90C3fa29B8D9f558a2A590aa1c94f73e4FDfC459", "0xe177810cc3C5600eF18FD5fEFCCf72Ad7D02cA57", "0xC93B0216deD2A55B22B5F8d5D52AB1d73bCA132e", "0xf509BCe7A014ca82f9760bf89a475320A4af428A", "0xB07a6C600d73B765dA6FF1b7f29f13abBCc3d52d", "0x8Ea2116FbEac10333297dfD6e5367329Aa71EF7C", "0xfB46fB4acac9BA2D5C882817C2df047d32F628fe"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "promo", type: "string"}], name: "checkPromo", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "partner_address", type: "address"}], name: "checkPartner", outputs: [{name: "isPartner", type: "bool"}, {name: "promo", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "amount_referral_invest", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "partner_address", type: "address"}], name: "partnerInfo", outputs: [{name: "promo", type: "bytes32"}, {name: "attracted_investments", type: "uint256"}, {name: "h_datetime", type: "uint256[]"}, {name: "h_invest", type: "uint256[]"}, {name: "h_referrals", type: "address[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "contractICO", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "referral", type: "address"}], name: "referralAmountInvest", outputs: [{name: "amount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "str", type: "string"}], name: "stringTobytes32", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ref_percent", outputs: [{name: "", type: "uint16"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = [] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = [] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4255625 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4281662 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "BMICOAffiliateProgramm", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "string", name: "promo", value: random.string( maxRandom )}], name: "checkPromo", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkPromo(string)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "partner_address", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "checkPartner", outputs: [{name: "isPartner", type: "bool"}, {name: "promo", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkPartner(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "amount_referral_invest", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "amount_referral_invest()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "partner_address", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "partnerInfo", outputs: [{name: "promo", type: "bytes32"}, {name: "attracted_investments", type: "uint256"}, {name: "h_datetime", type: "uint256[]"}, {name: "h_invest", type: "uint256[]"}, {name: "h_referrals", type: "address[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "partnerInfo(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "contractICO", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contractICO()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "referral", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "referralAmountInvest", outputs: [{name: "amount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "referralAmountInvest(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "string", name: "str", value: random.string( maxRandom )}], name: "stringTobytes32", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "stringTobytes32(string)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ref_percent", outputs: [{name: "", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ref_percent()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "BMICOAffiliateProgramm", function( accounts ) {

	it( "TEST: BMICOAffiliateProgramm(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4255625", timeStamp: "1504970450", hash: "0xc89dd7da58e4bed0c7626f956d65bac7aeff1a2a95833f3ea2a3675084c644dd", nonce: "24", blockHash: "0xd51002c30760636372e38dd81a3ce9ae3d90ec71fec64d13c6608e3bb5a170e2", transactionIndex: "97", from: "0x956fdf7be4453e26859b0c859d236c268b79ceb1", to: 0, value: "0", gas: "1333138", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x16831877", contractAddress: "0xbe44459058383729be8247802d4314ea76ca9e5a", cumulativeGasUsed: "4946770", gasUsed: "1333138", confirmations: "3449730"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "BMICOAffiliateProgramm", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = BMICOAffiliateProgramm.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1504970450 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = BMICOAffiliateProgramm.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "64728470575856743" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setContractICO( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4255669", timeStamp: "1504971441", hash: "0x478f9b0aec0290405ba8fb2e6da1576f88368cc5eeb7e2eb46f875b45f48e576", nonce: "27", blockHash: "0xdb1365a5e5b9b7547815a9ec5c29acf97c6ad38c8b32b83105de086bd446db15", transactionIndex: "38", from: "0x956fdf7be4453e26859b0c859d236c268b79ceb1", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "44226", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x4e40616700000000000000000000000019d7a9ad3b49252fd2ef640d0e43dfd651168499", contractAddress: "", cumulativeGasUsed: "1261361", gasUsed: "44226", confirmations: "3449686"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "new_address", value: addressList[4]}], name: "setContractICO", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setContractICO(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1504971441 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "64728470575856743" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `IQKMGQ` )", async function( ) {
		const txOriginal = {blockNumber: "4256276", timeStamp: "1504985900", hash: "0x5397f5bd46fdac8afd4a2eadd90e8a41766a009e88b25e70f9dde9120796dcf2", nonce: "2", blockHash: "0x5cbf28d4a8a73a3bf9c62bcba069158dd8e4a8f3547f284c25fdd82c3f80a3d6", transactionIndex: "49", from: "0xb8cd11969df4a021d4d9c72bb4a2ab07d29e06e2", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "133864", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000649514b4d47510000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2048260", gasUsed: "89242", confirmations: "3449079"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `IQKMGQ`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `IQKMGQ`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1504985900 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "13265682360000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setPartnerFromPreICOAffiliate( [addressList[6]], [\"0x00000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4256319", timeStamp: "1504987141", hash: "0x64c7d2953f8965dcb771b258251095d29b36a2d3af7d3831da51c42e415a3abd", nonce: "52", blockHash: "0xc4c9219349dbc6ed14d377011f92dfb1c85d1b305fbbc08f5b377c4a6824efd5", transactionIndex: "156", from: "0x956fdf7be4453e26859b0c859d236c268b79ceb1", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "143117", gasPrice: "5250000000", isError: "0", txreceipt_status: "", input: "0xde63dc35000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000001000000000000000000000000dae0aca4b9b38199408ffab32562bf7b3b0495fe0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000658464531394400000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5856218", gasUsed: "93117", confirmations: "3449036"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "partners", value: [addressList[6]]}, {type: "bytes32[]", name: "promo_codes", value: ["0x0000000000000000000000000000000000000000000000000006584645313944"]}, {type: "uint256[]", name: "attracted_invests", value: ["0"]}], name: "setPartnerFromPreICOAffiliate", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPartnerFromPreICOAffiliate(address[],bytes32[],uint256[])" ]( [addressList[6]], ["0x0000000000000000000000000000000000000000000000000006584645313944"], ["0"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1504987141 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "64728470575856743" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setPartnerFromPreICOAffiliate( [addressList[7]], [\"0x00000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4256506", timeStamp: "1504991391", hash: "0x1541325d6fa772c508c14a14381ba8f0b6ccb5a3f5bf7760284eab46a36cebfd", nonce: "53", blockHash: "0xfd830ff4df4cc1385d6ea69b5d3039a647ed2b10af9debcb4fb2f8f0c6338752", transactionIndex: "58", from: "0x956fdf7be4453e26859b0c859d236c268b79ceb1", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "158502", gasPrice: "5250000000", isError: "0", txreceipt_status: "", input: "0xde63dc35000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000001000000000000000000000000f3ccab1fe47f07c686de54e5be986f9bfd3e86410000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000644393242505800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "3268004", gasUsed: "108501", confirmations: "3448849"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "partners", value: [addressList[7]]}, {type: "bytes32[]", name: "promo_codes", value: ["0x0000000000000000000000000000000000000000000000000006443932425058"]}, {type: "uint256[]", name: "attracted_invests", value: ["10000000000000000000"]}], name: "setPartnerFromPreICOAffiliate", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPartnerFromPreICOAffiliate(address[],bytes32[],uint256[])" ]( [addressList[7]], ["0x0000000000000000000000000000000000000000000000000006443932425058"], ["10000000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1504991391 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "64728470575856743" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setPartnerFromPreICOAffiliate( [addressList[8],addressList[9],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4256522", timeStamp: "1504991783", hash: "0x351ec71f1643adc25f7ae4b4c47fe30378f70e0280dd1addf3e45f1d1d66e6da", nonce: "54", blockHash: "0xf71ae0dfe52f9ea47c3b09c57963d3b7db361c326b2e74f51fae1e8d74218fd5", transactionIndex: "25", from: "0x956fdf7be4453e26859b0c859d236c268b79ceb1", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "2932268", gasPrice: "5250000000", isError: "0", txreceipt_status: "", input: "0xde63dc350000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000052000000000000000000000000000000000000000000000000000000000000009e0000000000000000000000000000000000000000000000000000000000000002500000000000000000000000088028e4e83e041c699128ff063089484dcc83e18000000000000000000000000e6fbfa4f8eca66e71a51fc6fc03131c4c220ef1500000000000000000000000054add64d76afa1d0bfff950ad13a61610be07e480000000000000000000000009889b6250d1d215abfe725409c03387450e614b4000000000000000000000000c2ba0eb60cf4df1b0346d7b4ddf8355557e8bc82000000000000000000000000c66eaf7a7f6c42a793fb7c51d5cb5772803c994900000000000000000000000064d5dc419506163cbf5bb076dd3c24f74d8ec920000000000000000000000000d2cb60e5930ea6e365ee4749544e4962d3acb9aa000000000000000000000000b6020e51d006e933e7995e253fee1d71f17a23ac000000000000000000000000e67d82e79c0f9fc41f0de7899b08238f54bda184000000000000000000000000241057cc3551e82cd551ada290182be47d62d9fc000000000000000000000000758348250e38bc48cdab94cf408633d8eab298120000000000000000000000006709c49270f5f7f5c57ad9a2e1e767653fcbae43000000000000000000000000052ff9eaffd2871c0c25a769c8765382cf23b29800000000000000000000000003d618e2d50c8eeca5aadde7b4d5d6036adf5e71000000000000000000000000831b122471d2058c3d694189284dcc5cad2084ec0000000000000000000000000d509a1937e5ca2d2c3d99888d0730d79eff7cae000000000000000000000000bab8c44106dc795bf7dc67291712234e99bde9c9000000000000000000000000bfa85bf9013dbf46693eca148eed3da303a608b7000000000000000000000000a388b4c12cc2be2b621c2096f34217181d4ca32f0000000000000000000000001843906d36cc93f52b651f0ae78d3b5ac1c7c5b20000000000000000000000007fca8cca572e91918e9daa1491d3024f395ec2cf0000000000000000000000008abc3d9d5e546714077a7b3bcf9bd3878e0747dc000000000000000000000000763576754ca949163af766475562ae94b7dd59370000000000000000000000006e67d8a7cd4009513fb53b044519280610560e56000000000000000000000000d430709a70da06c5c25157a97dba3c3e664590af000000000000000000000000cde89b37188d891cc151e6eb55648ff29ab767bc00000000000000000000000073fd3c61f22940f17dc6568f1c1e5cec8b5465a9000000000000000000000000fd8a4d3812b76c5838aff93f944fb545f659188d0000000000000000000000007bfd8695b8913f800b0acadf1f1166fc57fb5a7b0000000000000000000000005d56a3857c02777bc26038dedee9812a198b4a9700000000000000000000000078ba52ce8caef22a5f4d45760061ba3beb2f07b100000000000000000000000095ec882af9e576f1fd7f108e16e650b60bd3c548000000000000000000000000e4a66e669a257b8d0b1bd1565b136f9b5cd1b3f40000000000000000000000000f6e7c3d193486be7b57319250b5129ac0c659430000000000000000000000002f2bb1eedef5a16159939cc742f3cb0003cbfbb10000000000000000000000003e3a69a49beb0927b7e06f0a3d1eb0c3579421f7000000000000000000000000000000000000000000000000000000000000002500000000000000000000000000000000000000000000000000064d31584a583800000000000000000000000000000000000000000000000000063737494150500000000000000000000000000000000000000000000000000006534e48314f5000000000000000000000000000000000000000000000000000063444554554300000000000000000000000000000000000000000000000000006524339554a430000000000000000000000000000000000000000000000000005424f4e5553000000000000000000000000000000000000000000000000000006494c4d494835000000000000000000000000000000000000000000000000000655564c52444f00000000000000000000000000000000000000000000000000063752334d424a00000000000000000000000000000000000000000000000000064d4c4d52465800000000000000000000000000000000000000000000000000064d4c334d38460000000000000000000000000000000000000000000000000003424d5400000000000000000000000000000000000000000000000000000000064b504747325000000000000000000000000000000000000000000000000000065251534e53310000000000000000000000000000000000000000000000000006334b384338310000000000000000000000000000000000000000000000000006364f34374d4d000000000000000000000000000000000000000000000000000656574642524300000000000000000000000000000000000000000000000000064c696b654d65000000000000000000000000000000000000000000000000000654304832373700000000000000000000000000000000000000000000000000063934423743490000000000000000000000000000000000000000000000000005436f737469000000000000000000000000000000000000000000000000000006304a5849565500000000000000000000000000000000000000000000000000064c39394132420000000000000000000000000000000000000000000000000006463858494d4d0000000000000000000000000000000000000000000000000006494950364c38000000000000000000000000000000000000000000000000000635424146534a00000000000000000000000000000000000000000000000000064243504f4a41000000000000000000000000000000000000000000000000000634343651533700000000000000000000000000000000000000000000000000064b44474436460000000000000000000000000000000000000000000000000006374e4f32544800000000000000000000000000000000000000000000000000065548453637380000000000000000000000000000000000000000000000000006444d4c48504c0000000000000000000000000000000000000000000000000006353746444843000000000000000000000000000000000000000000000000000643383839544d000000000000000000000000000000000000000000000000000656505433363600000000000000000000000000000000000000000000000000065643573553550000000000000000000000000000000000000000000000000006513243304254000000000000000000000000000000000000000000000000000000000000002500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001784a58fa2992140000000000000000000000000000000000000000000000000002c68af0bb14000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001331672c2c5d8000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000067eab853ae20000000000000000000000000000000000000000000000000000002ff62db077c0000000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000027f2218cb17c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000018e1fe3c5bfeab9c00000000000000000000000000000000000000000000000008053b59363dfc6b00000000000000000000000000000000000000000000000001ce4bff8165d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002d84e69f2f480000000000000000000000000000000000000000000000000000e5d0f042e8780000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002a29d5794ea056400000000000000000000000000000000000000000000000000003311fc80a570000000000000000000000000000000000000000000000000000dfb231190e858000000000000000000000000000000000000000000000000000b25a690f0be3400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001810ce218b10880000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d5db515ab4c500000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4281947", gasUsed: "2882267", confirmations: "3448833"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "partners", value: [addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44]]}, {type: "bytes32[]", name: "promo_codes", value: ["0x00000000000000000000000000000000000000000000000000064d31584a5838","0x0000000000000000000000000000000000000000000000000006373749415050","0x0000000000000000000000000000000000000000000000000006534e48314f50","0x0000000000000000000000000000000000000000000000000006344455455430","0x0000000000000000000000000000000000000000000000000006524339554a43","0x0000000000000000000000000000000000000000000000000005424f4e555300","0x0000000000000000000000000000000000000000000000000006494c4d494835","0x000000000000000000000000000000000000000000000000000655564c52444f","0x00000000000000000000000000000000000000000000000000063752334d424a","0x00000000000000000000000000000000000000000000000000064d4c4d524658","0x00000000000000000000000000000000000000000000000000064d4c334d3846","0x0000000000000000000000000000000000000000000000000003424d54000000","0x00000000000000000000000000000000000000000000000000064b5047473250","0x00000000000000000000000000000000000000000000000000065251534e5331","0x0000000000000000000000000000000000000000000000000006334b38433831","0x0000000000000000000000000000000000000000000000000006364f34374d4d","0x0000000000000000000000000000000000000000000000000006565746425243","0x00000000000000000000000000000000000000000000000000064c696b654d65","0x0000000000000000000000000000000000000000000000000006543048323737","0x0000000000000000000000000000000000000000000000000006393442374349","0x0000000000000000000000000000000000000000000000000005436f73746900","0x0000000000000000000000000000000000000000000000000006304a58495655","0x00000000000000000000000000000000000000000000000000064c3939413242","0x0000000000000000000000000000000000000000000000000006463858494d4d","0x0000000000000000000000000000000000000000000000000006494950364c38","0x000000000000000000000000000000000000000000000000000635424146534a","0x00000000000000000000000000000000000000000000000000064243504f4a41","0x0000000000000000000000000000000000000000000000000006343436515337","0x00000000000000000000000000000000000000000000000000064b4447443646","0x0000000000000000000000000000000000000000000000000006374e4f325448","0x0000000000000000000000000000000000000000000000000006554845363738","0x0000000000000000000000000000000000000000000000000006444d4c48504c","0x0000000000000000000000000000000000000000000000000006353746444843","0x000000000000000000000000000000000000000000000000000643383839544d","0x0000000000000000000000000000000000000000000000000006565054333636","0x0000000000000000000000000000000000000000000000000006564357355355","0x0000000000000000000000000000000000000000000000000006513243304254"]}, {type: "uint256[]", name: "attracted_invests", value: ["0","0","0","0","0","27114582338000000000","200000000000000000","0","1383000000000000000","0","7488000000000000000","216000000000000000","100000000000000000","179900000000000000","0","0","28687898589841242560","9246934104562190000","2082000000000000000","0","0","0","205000000000000000","1035000000000000000","0","100000000000000000","0","777777700000000000000","230000000000000000","16119000000000000000","12851700000000000000","0","0","27745800000000000000","0","15410000000000000000","0"]}], name: "setPartnerFromPreICOAffiliate", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPartnerFromPreICOAffiliate(address[],bytes32[],uint256[])" ]( [addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44]], ["0x00000000000000000000000000000000000000000000000000064d31584a5838","0x0000000000000000000000000000000000000000000000000006373749415050","0x0000000000000000000000000000000000000000000000000006534e48314f50","0x0000000000000000000000000000000000000000000000000006344455455430","0x0000000000000000000000000000000000000000000000000006524339554a43","0x0000000000000000000000000000000000000000000000000005424f4e555300","0x0000000000000000000000000000000000000000000000000006494c4d494835","0x000000000000000000000000000000000000000000000000000655564c52444f","0x00000000000000000000000000000000000000000000000000063752334d424a","0x00000000000000000000000000000000000000000000000000064d4c4d524658","0x00000000000000000000000000000000000000000000000000064d4c334d3846","0x0000000000000000000000000000000000000000000000000003424d54000000","0x00000000000000000000000000000000000000000000000000064b5047473250","0x00000000000000000000000000000000000000000000000000065251534e5331","0x0000000000000000000000000000000000000000000000000006334b38433831","0x0000000000000000000000000000000000000000000000000006364f34374d4d","0x0000000000000000000000000000000000000000000000000006565746425243","0x00000000000000000000000000000000000000000000000000064c696b654d65","0x0000000000000000000000000000000000000000000000000006543048323737","0x0000000000000000000000000000000000000000000000000006393442374349","0x0000000000000000000000000000000000000000000000000005436f73746900","0x0000000000000000000000000000000000000000000000000006304a58495655","0x00000000000000000000000000000000000000000000000000064c3939413242","0x0000000000000000000000000000000000000000000000000006463858494d4d","0x0000000000000000000000000000000000000000000000000006494950364c38","0x000000000000000000000000000000000000000000000000000635424146534a","0x00000000000000000000000000000000000000000000000000064243504f4a41","0x0000000000000000000000000000000000000000000000000006343436515337","0x00000000000000000000000000000000000000000000000000064b4447443646","0x0000000000000000000000000000000000000000000000000006374e4f325448","0x0000000000000000000000000000000000000000000000000006554845363738","0x0000000000000000000000000000000000000000000000000006444d4c48504c","0x0000000000000000000000000000000000000000000000000006353746444843","0x000000000000000000000000000000000000000000000000000643383839544d","0x0000000000000000000000000000000000000000000000000006565054333636","0x0000000000000000000000000000000000000000000000000006564357355355","0x0000000000000000000000000000000000000000000000000006513243304254"], ["0","0","0","0","0","27114582338000000000","200000000000000000","0","1383000000000000000","0","7488000000000000000","216000000000000000","100000000000000000","179900000000000000","0","0","28687898589841242560","9246934104562190000","2082000000000000000","0","0","0","205000000000000000","1035000000000000000","0","100000000000000000","0","777777700000000000000","230000000000000000","16119000000000000000","12851700000000000000","0","0","27745800000000000000","0","15410000000000000000","0"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1504991783 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "64728470575856743" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setPartnerFromPreICOAffiliate( [addressList[45],addressList[46],address... )", async function( ) {
		const txOriginal = {blockNumber: "4256524", timeStamp: "1504991825", hash: "0x5c6f247a59b37a7f7b07698a9a24bbc64cafafdbe6bde2df42ee8eb765dfc091", nonce: "55", blockHash: "0xcbd6fa052c12dd9331aa46fa440820421a897c8a47677f49fe8f3d69d50b3e47", transactionIndex: "25", from: "0x956fdf7be4453e26859b0c859d236c268b79ceb1", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "2731508", gasPrice: "5250000000", isError: "0", txreceipt_status: "", input: "0xde63dc350000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000052000000000000000000000000000000000000000000000000000000000000009e000000000000000000000000000000000000000000000000000000000000000250000000000000000000000006c28e8bca252dc74a007515e6b7cfbc476990ab000000000000000000000000073734ec6e4a0dbabf39c47fd68e64c819b5b29c80000000000000000000000007aaab6ec7a6662d134cbbd089d288bb094bf3ac600000000000000000000000007b453c09a85929cc95d386bd014bff4c951c0d40000000000000000000000001bc69e5d940e772bdf804ee42b1b8eeb9e29c82c000000000000000000000000c7bc11fc9fd6288423cefacfe3509151ac7f36f6000000000000000000000000ffc1a14e91702a99445ba9c5cdfa836af87888390000000000000000000000008cc1e6ac73c8e5bbf06b9b61e5eec80bd89e4521000000000000000000000000d7a866c8b1249a8828b9e66c934097c99e30506b000000000000000000000000c5b491990b5004e8c6364b57dd17b4963e495d14000000000000000000000000bdd9f447f324db9fcb4633fbbed2c594566fa2ac000000000000000000000000af88364f4794173d532674b77162918ff26965cb000000000000000000000000a0d0daf0b0d8458b7a1c35bd757a9fff28431c9d0000000000000000000000007d7a2ae37bb94d8dd6a89d704b0957584f059cb0000000000000000000000000fe369dddab8f9789a65e5659df575ca4621f4b3a000000000000000000000000f77fe2f825ab7a3b761d00127ca3283d4e0ad0f90000000000000000000000007f8970d96b777172d0cceec41863d1c44fdc51fe000000000000000000000000b886f3949078953de4269730a7afc6e4a42936b100000000000000000000000012a15779f7e34eff7d1e6f87a86f55b1bfb9ba75000000000000000000000000d5f1c24ca3fd01e9843411e9227ae90816b493dd000000000000000000000000f7d6a313d77c624a295a611919d1b48b42f0ee6c0000000000000000000000001a25d4d2fb6572c728598f349dc36cd943e1af8e00000000000000000000000091ebb42996f1d65e31fee8203d1b39ac779e6ea10000000000000000000000006a432cb101c688c437ff36bf1c85115af7fe94e80000000000000000000000005f5f2b9a72c1fa44a51fc365b4136aea2cc4bc630000000000000000000000008f66c9529c155a863a09dd7c4a2fbc4cd5cfa72e000000000000000000000000e868576f360f2884287ecb6351f15e9366dc0aad0000000000000000000000007a9aa06f9cf111847db36a80b87e0a8be6cf5c5400000000000000000000000000ac77e033ff5ea56c8432815b62e3505f256fdf000000000000000000000000121808609d8ec3fdebe9c26f1d6389c54377e9b600000000000000000000000063dadbf34d653d895af5f8ff10771df2b141b994000000000000000000000000f40f2416814d2ef2ac874f7532cebb488c97125100000000000000000000000011af34d2a8a0d881dcfae3de0ed2fcf039a54dcb0000000000000000000000000aba768ac87fb4384fc08ff1b3021ee2454a8303000000000000000000000000c2b4dfa31512b678bcf129a3eebaf0dd55dabb95000000000000000000000000391d08f89a333eaa5f4998b6f28b70d9345068b40000000000000000000000006cf3c0bb276292ebd829ffac229fe350821eaac600000000000000000000000000000000000000000000000000000000000000250000000000000000000000000000000000000000000000000006563556425536000000000000000000000000000000000000000000000000000650504d304f4f0000000000000000000000000000000000000000000000000006554f57545336000000000000000000000000000000000000000000000000000636425432584e0000000000000000000000000000000000000000000000000006424d57333746000000000000000000000000000000000000000000000000000642454232434600000000000000000000000000000000000000000000000000064c345339414a0000000000000000000000000000000000000000000000000006475352454a3300000000000000000000000000000000000000000000000000064a4548453952000000000000000000000000000000000000000000000000000651394e33584800000000000000000000000000000000000000000000000000063938343035480000000000000000000000000000000000000000000000000006334b4250553700000000000000000000000000000000000000000000000000064f4833303348000000000000000000000000000000000000000000000000000641324755394a00000000000000000000000000000000000000000000000000064f36564b48450000000000000000000000000000000000000000000000000006485851474b580000000000000000000000000000000000000000000000000006363441385847000000000000000000000000000000000000000000000000000655534c5553300000000000000000000000000000000000000000000000000006463349433054000000000000000000000000000000000000000000000000000635315554414c00000000000000000000000000000000000000000000000000064f584e564e3900000000000000000000000000000000000000000000000000064c4431444b3800000000000000000000000000000000000000000000000000064239533251370000000000000000000000000000000000000000000000000006414547304339000000000000000000000000000000000000000000000000000630504a3848350000000000000000000000000000000000000000000000000006554a314e4d570000000000000000000000000000000000000000000000000006737472696e67000000000000000000000000000000000000000000000000000647535039323700000000000000000000000000000000000000000000000000064c4c55554558000000000000000000000000000000000000000000000000000646533044523600000000000000000000000000000000000000000000000000064b37354432520000000000000000000000000000000000000000000000000006463133444936000000000000000000000000000000000000000000000000000656484b4942520000000000000000000000000000000000000000000000000006553444494f550000000000000000000000000000000000000000000000000006345448393057000000000000000000000000000000000000000000000000000645535635464d0000000000000000000000000000000000000000000000000006464831523336000000000000000000000000000000000000000000000000000000000000002500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d2f13f7789f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002079599a266a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000045b1ba646e0300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000429d069189e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006f05b59d3b2000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3708047", gasUsed: "2681507", confirmations: "3448831"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "partners", value: [addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81]]}, {type: "bytes32[]", name: "promo_codes", value: ["0x0000000000000000000000000000000000000000000000000006563556425536","0x000000000000000000000000000000000000000000000000000650504d304f4f","0x0000000000000000000000000000000000000000000000000006554f57545336","0x000000000000000000000000000000000000000000000000000636425432584e","0x0000000000000000000000000000000000000000000000000006424d57333746","0x0000000000000000000000000000000000000000000000000006424542324346","0x00000000000000000000000000000000000000000000000000064c345339414a","0x0000000000000000000000000000000000000000000000000006475352454a33","0x00000000000000000000000000000000000000000000000000064a4548453952","0x000000000000000000000000000000000000000000000000000651394e335848","0x0000000000000000000000000000000000000000000000000006393834303548","0x0000000000000000000000000000000000000000000000000006334b42505537","0x00000000000000000000000000000000000000000000000000064f4833303348","0x000000000000000000000000000000000000000000000000000641324755394a","0x00000000000000000000000000000000000000000000000000064f36564b4845","0x0000000000000000000000000000000000000000000000000006485851474b58","0x0000000000000000000000000000000000000000000000000006363441385847","0x000000000000000000000000000000000000000000000000000655534c555330","0x0000000000000000000000000000000000000000000000000006463349433054","0x000000000000000000000000000000000000000000000000000635315554414c","0x00000000000000000000000000000000000000000000000000064f584e564e39","0x00000000000000000000000000000000000000000000000000064c4431444b38","0x0000000000000000000000000000000000000000000000000006423953325137","0x0000000000000000000000000000000000000000000000000006414547304339","0x000000000000000000000000000000000000000000000000000630504a384835","0x0000000000000000000000000000000000000000000000000006554a314e4d57","0x0000000000000000000000000000000000000000000000000006737472696e67","0x0000000000000000000000000000000000000000000000000006475350393237","0x00000000000000000000000000000000000000000000000000064c4c55554558","0x0000000000000000000000000000000000000000000000000006465330445236","0x00000000000000000000000000000000000000000000000000064b3735443252","0x0000000000000000000000000000000000000000000000000006463133444936","0x000000000000000000000000000000000000000000000000000656484b494252","0x0000000000000000000000000000000000000000000000000006553444494f55","0x0000000000000000000000000000000000000000000000000006345448393057","0x000000000000000000000000000000000000000000000000000645535635464d","0x0000000000000000000000000000000000000000000000000006464831523336"]}, {type: "uint256[]", name: "attracted_invests", value: ["0","950000000000000000","0","0","0","0","100000000000000000","0","0","0","0","0","0","2340000000000000000","0","0","0","0","0","0","0","0","5022000000000000000","0","0","0","300000000000000000","0","0","0","0","0","0","0","500000000000000000","0","0"]}], name: "setPartnerFromPreICOAffiliate", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPartnerFromPreICOAffiliate(address[],bytes32[],uint256[])" ]( [addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81]], ["0x0000000000000000000000000000000000000000000000000006563556425536","0x000000000000000000000000000000000000000000000000000650504d304f4f","0x0000000000000000000000000000000000000000000000000006554f57545336","0x000000000000000000000000000000000000000000000000000636425432584e","0x0000000000000000000000000000000000000000000000000006424d57333746","0x0000000000000000000000000000000000000000000000000006424542324346","0x00000000000000000000000000000000000000000000000000064c345339414a","0x0000000000000000000000000000000000000000000000000006475352454a33","0x00000000000000000000000000000000000000000000000000064a4548453952","0x000000000000000000000000000000000000000000000000000651394e335848","0x0000000000000000000000000000000000000000000000000006393834303548","0x0000000000000000000000000000000000000000000000000006334b42505537","0x00000000000000000000000000000000000000000000000000064f4833303348","0x000000000000000000000000000000000000000000000000000641324755394a","0x00000000000000000000000000000000000000000000000000064f36564b4845","0x0000000000000000000000000000000000000000000000000006485851474b58","0x0000000000000000000000000000000000000000000000000006363441385847","0x000000000000000000000000000000000000000000000000000655534c555330","0x0000000000000000000000000000000000000000000000000006463349433054","0x000000000000000000000000000000000000000000000000000635315554414c","0x00000000000000000000000000000000000000000000000000064f584e564e39","0x00000000000000000000000000000000000000000000000000064c4431444b38","0x0000000000000000000000000000000000000000000000000006423953325137","0x0000000000000000000000000000000000000000000000000006414547304339","0x000000000000000000000000000000000000000000000000000630504a384835","0x0000000000000000000000000000000000000000000000000006554a314e4d57","0x0000000000000000000000000000000000000000000000000006737472696e67","0x0000000000000000000000000000000000000000000000000006475350393237","0x00000000000000000000000000000000000000000000000000064c4c55554558","0x0000000000000000000000000000000000000000000000000006465330445236","0x00000000000000000000000000000000000000000000000000064b3735443252","0x0000000000000000000000000000000000000000000000000006463133444936","0x000000000000000000000000000000000000000000000000000656484b494252","0x0000000000000000000000000000000000000000000000000006553444494f55","0x0000000000000000000000000000000000000000000000000006345448393057","0x000000000000000000000000000000000000000000000000000645535635464d","0x0000000000000000000000000000000000000000000000000006464831523336"], ["0","950000000000000000","0","0","0","0","100000000000000000","0","0","0","0","0","0","2340000000000000000","0","0","0","0","0","0","0","0","5022000000000000000","0","0","0","300000000000000000","0","0","0","0","0","0","0","500000000000000000","0","0"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1504991825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "64728470575856743" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setPartnerFromPreICOAffiliate( [addressList[82],addressList[83],address... )", async function( ) {
		const txOriginal = {blockNumber: "4256527", timeStamp: "1504991886", hash: "0x3f366d2dad79ce33e803dca413ab5c5e37b62adfee3dcef75cef531ffadfd2ef", nonce: "56", blockHash: "0xd889588049089ca8f61a5394f410dc2572354bc843ecb85864e56392348c8523", transactionIndex: "55", from: "0x956fdf7be4453e26859b0c859d236c268b79ceb1", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "2731700", gasPrice: "5250000000", isError: "0", txreceipt_status: "", input: "0xde63dc350000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000052000000000000000000000000000000000000000000000000000000000000009e00000000000000000000000000000000000000000000000000000000000000025000000000000000000000000e49c075c0b631d8b3e55862c2a3533b197debf4500000000000000000000000088967c84127e31b5780b63203b874fd26e991d8600000000000000000000000075a1ce1bd9e327d828febf7193a1d918c37fdded000000000000000000000000a7cfdb115614831433ba21b7ef49d82baac10750000000000000000000000000b78b22340e247db1d638d1430323f9b66d51e0f3000000000000000000000000ea935b4aa19e9a3b45457e2139ce547322d360070000000000000000000000004639b5ad1fc57a6aab1099171dada00da0b98eba000000000000000000000000629c77bad3fedc593d12137c59879969188421b400000000000000000000000080836bc33c06ddac7c0bf62968cad64c61989c2b0000000000000000000000002192d37471fbc1f5a3a0d48ae9014119015b7b6c000000000000000000000000d1ed9d7da49b28adf279cd6f3724371e7656a6e3000000000000000000000000b7fa81c55203e3993112d6a774f31de617a23f7a000000000000000000000000162b12a47b503d90b813764b191dc44a29bce02c000000000000000000000000fcf592ced199b28ff1ea76e1a2e50433c526407f000000000000000000000000c2875b2a55bdab74ff04ff3b3e01e6d83cc2f1cf000000000000000000000000460fb852accf750c895460aa774e1621b4418c510000000000000000000000000d5f21a4922f8913c2d40240f10f9ce0d00b6eac0000000000000000000000007adc44768e086a8d61e4a6473a3d798771c93be50000000000000000000000000159d0d21185ceb8ff628917e8d5ea8863404e5f00000000000000000000000068f302562aef1b6dbe8cb6a7d8ca238aa3e2693c00000000000000000000000041bfe13b7bec7cb8a81281b4c48d80f9b2c1401c000000000000000000000000bd2f6a5665912a19b287c767fb21d20f552290aa00000000000000000000000045d472f4e9f58cc6dfeedb386a948e97a325cbd40000000000000000000000006b9610b7fac20ee1f20fa175c73bfa4d4dca8af10000000000000000000000001c6789d0f5622ef130046804631ff8fea7608f72000000000000000000000000dca683ca5cc6d49bc9d020ece144081c688ebe6f00000000000000000000000066eb3d80528c8dde86b379e507287bccd310fcab000000000000000000000000b5a7e2a01002854fe67ddb1bcf6a094a52ea1b460000000000000000000000003f3ddefb0aa770f8fa7733d825d5e07a4e70919f0000000000000000000000003b55a11f50faf4d278df6bb0186b99f1e59197050000000000000000000000004452b58d2fdb19dc757085ef6200a5ff549fbda90000000000000000000000006c9c02059f4da8a17fb0a0c2ee2d92f225d0677c00000000000000000000000011c0e2e6de0c78a8bcfcbe2a17a67545fda7be97000000000000000000000000b0103b1c235d58aa8065a6627a0331bb55807c73000000000000000000000000b2412dc96fd03ea36c1e0bde29bf3481204ad6a3000000000000000000000000600d72a8bd076ed2abbc39088af54e0ee63ba6ac000000000000000000000000d72c885dd93f6b409eb7a6f27aed810f46aba2b20000000000000000000000000000000000000000000000000000000000000025000000000000000000000000000000000000000000000000000652424f5355580000000000000000000000000000000000000000000000000006495049574e3400000000000000000000000000000000000000000000000000064830554846510000000000000000000000000000000000000000000000000006574d4c42544a00000000000000000000000000000000000000000000000000063147374e3830000000000000000000000000000000000000000000000000000642334937344b00000000000000000000000000000000000000000000000000063258584d43300000000000000000000000000000000000000000000000000006495248324a4300000000000000000000000000000000000000000000000000064a3243334b43000000000000000000000000000000000000000000000000000647534d354a4d000000000000000000000000000000000000000000000000000644304833515300000000000000000000000000000000000000000000000000064958334a38480000000000000000000000000000000000000000000000000006324e4d5832450000000000000000000000000000000000000000000000000006434d334f41470000000000000000000000000000000000000000000000000006373944344d4b000000000000000000000000000000000000000000000000000637564150573500000000000000000000000000000000000000000000000000065550434752380000000000000000000000000000000000000000000000000006305555465535000000000000000000000000000000000000000000000000000645383451434d000000000000000000000000000000000000000000000000000645524849544a00000000000000000000000000000000000000000000000000064956414e383600000000000000000000000000000000000000000000000000063757544b4539000000000000000000000000000000000000000000000000000674617261626d000000000000000000000000000000000000000000000000000646314d49464500000000000000000000000000000000000000000000000000064336584739360000000000000000000000000000000000000000000000000006574b4f5136450000000000000000000000000000000000000000000000000005463172737400000000000000000000000000000000000000000000000000000655354b53453100000000000000000000000000000000000000000000000000064a514431374b0000000000000000000000000000000000000000000000000006425546484b3400000000000000000000000000000000000000000000000000064d46334b575100000000000000000000000000000000000000000000000000066265356e6f77000000000000000000000000000000000000000000000000000650375043535200000000000000000000000000000000000000000000000000063157544836330000000000000000000000000000000000000000000000000006574c3535365400000000000000000000000000000000000000000000000000065539374e5132000000000000000000000000000000000000000000000000000641354f4645560000000000000000000000000000000000000000000000000000000000000025000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002a303fe4b5300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001cc811b67512cd800000000000000000000000000000000000000000000000000075e22bcb74140000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000030b60667399f0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4601222", gasUsed: "2681699", confirmations: "3448828"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "partners", value: [addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118]]}, {type: "bytes32[]", name: "promo_codes", value: ["0x000000000000000000000000000000000000000000000000000652424f535558","0x0000000000000000000000000000000000000000000000000006495049574e34","0x0000000000000000000000000000000000000000000000000006483055484651","0x0000000000000000000000000000000000000000000000000006574d4c42544a","0x00000000000000000000000000000000000000000000000000063147374e3830","0x000000000000000000000000000000000000000000000000000642334937344b","0x00000000000000000000000000000000000000000000000000063258584d4330","0x0000000000000000000000000000000000000000000000000006495248324a43","0x00000000000000000000000000000000000000000000000000064a3243334b43","0x000000000000000000000000000000000000000000000000000647534d354a4d","0x0000000000000000000000000000000000000000000000000006443048335153","0x00000000000000000000000000000000000000000000000000064958334a3848","0x0000000000000000000000000000000000000000000000000006324e4d583245","0x0000000000000000000000000000000000000000000000000006434d334f4147","0x0000000000000000000000000000000000000000000000000006373944344d4b","0x0000000000000000000000000000000000000000000000000006375641505735","0x0000000000000000000000000000000000000000000000000006555043475238","0x0000000000000000000000000000000000000000000000000006305555465535","0x000000000000000000000000000000000000000000000000000645383451434d","0x000000000000000000000000000000000000000000000000000645524849544a","0x00000000000000000000000000000000000000000000000000064956414e3836","0x00000000000000000000000000000000000000000000000000063757544b4539","0x000000000000000000000000000000000000000000000000000674617261626d","0x000000000000000000000000000000000000000000000000000646314d494645","0x0000000000000000000000000000000000000000000000000006433658473936","0x0000000000000000000000000000000000000000000000000006574b4f513645","0x0000000000000000000000000000000000000000000000000005463172737400","0x000000000000000000000000000000000000000000000000000655354b534531","0x00000000000000000000000000000000000000000000000000064a514431374b","0x0000000000000000000000000000000000000000000000000006425546484b34","0x00000000000000000000000000000000000000000000000000064d46334b5751","0x00000000000000000000000000000000000000000000000000066265356e6f77","0x0000000000000000000000000000000000000000000000000006503750435352","0x0000000000000000000000000000000000000000000000000006315754483633","0x0000000000000000000000000000000000000000000000000006574c35353654","0x00000000000000000000000000000000000000000000000000065539374e5132","0x000000000000000000000000000000000000000000000000000641354f464556"]}, {type: "uint256[]", name: "attracted_invests", value: ["0","190000000000000000","0","0","0","0","0","0","1000000000000000000","0","0","0","0","0","0","0","0","0","0","0","0","100000000000000000","0","0","0","0","0","0","0","33182833660000000000","530900000000000000","0","0","3510000000000000000","0","0","0"]}], name: "setPartnerFromPreICOAffiliate", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPartnerFromPreICOAffiliate(address[],bytes32[],uint256[])" ]( [addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105],addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118]], ["0x000000000000000000000000000000000000000000000000000652424f535558","0x0000000000000000000000000000000000000000000000000006495049574e34","0x0000000000000000000000000000000000000000000000000006483055484651","0x0000000000000000000000000000000000000000000000000006574d4c42544a","0x00000000000000000000000000000000000000000000000000063147374e3830","0x000000000000000000000000000000000000000000000000000642334937344b","0x00000000000000000000000000000000000000000000000000063258584d4330","0x0000000000000000000000000000000000000000000000000006495248324a43","0x00000000000000000000000000000000000000000000000000064a3243334b43","0x000000000000000000000000000000000000000000000000000647534d354a4d","0x0000000000000000000000000000000000000000000000000006443048335153","0x00000000000000000000000000000000000000000000000000064958334a3848","0x0000000000000000000000000000000000000000000000000006324e4d583245","0x0000000000000000000000000000000000000000000000000006434d334f4147","0x0000000000000000000000000000000000000000000000000006373944344d4b","0x0000000000000000000000000000000000000000000000000006375641505735","0x0000000000000000000000000000000000000000000000000006555043475238","0x0000000000000000000000000000000000000000000000000006305555465535","0x000000000000000000000000000000000000000000000000000645383451434d","0x000000000000000000000000000000000000000000000000000645524849544a","0x00000000000000000000000000000000000000000000000000064956414e3836","0x00000000000000000000000000000000000000000000000000063757544b4539","0x000000000000000000000000000000000000000000000000000674617261626d","0x000000000000000000000000000000000000000000000000000646314d494645","0x0000000000000000000000000000000000000000000000000006433658473936","0x0000000000000000000000000000000000000000000000000006574b4f513645","0x0000000000000000000000000000000000000000000000000005463172737400","0x000000000000000000000000000000000000000000000000000655354b534531","0x00000000000000000000000000000000000000000000000000064a514431374b","0x0000000000000000000000000000000000000000000000000006425546484b34","0x00000000000000000000000000000000000000000000000000064d46334b5751","0x00000000000000000000000000000000000000000000000000066265356e6f77","0x0000000000000000000000000000000000000000000000000006503750435352","0x0000000000000000000000000000000000000000000000000006315754483633","0x0000000000000000000000000000000000000000000000000006574c35353654","0x00000000000000000000000000000000000000000000000000065539374e5132","0x000000000000000000000000000000000000000000000000000641354f464556"], ["0","190000000000000000","0","0","0","0","0","0","1000000000000000000","0","0","0","0","0","0","0","0","0","0","0","0","100000000000000000","0","0","0","0","0","0","0","33182833660000000000","530900000000000000","0","0","3510000000000000000","0","0","0"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1504991886 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "64728470575856743" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: setPartnerFromPreICOAffiliate( [addressList[119],addressList[120],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4256529", timeStamp: "1504991989", hash: "0x598efdc3c7bf2cc042cba20190eb462d0b8886f2a07d15a072487fe12cd78ea5", nonce: "57", blockHash: "0x9e0feedb2d346a1ae7cee9ff7e0ae92882d856be816dd646781187b7c9575dee", transactionIndex: "73", from: "0x956fdf7be4453e26859b0c859d236c268b79ceb1", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "2747019", gasPrice: "5250000000", isError: "0", txreceipt_status: "", input: "0xde63dc350000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000052000000000000000000000000000000000000000000000000000000000000009e000000000000000000000000000000000000000000000000000000000000000250000000000000000000000005fbfafc94523a817e2f59d83283aa1d6b80886160000000000000000000000006cd7c47c5954bc0b9c61bb4f8ad76294d02af1d100000000000000000000000072670a36a25680155eeee7dd11fd75d4006d44b700000000000000000000000065de3aa3de5ed2b07293976eb44b77d02d27fb70000000000000000000000000087d9b9754d11a60dc53577fb8795067647650bd0000000000000000000000003b04eece9b08db9b159a8206fee8ca7ed3e4fb79000000000000000000000000767f3e5fa0aaff69fb80233e58f0c3afeedf04ac000000000000000000000000afbc7601129d8179f40e35a7e77756cd903e06570000000000000000000000000e15ee423a2f73118e1ba1d01236b29eb7f6d9d100000000000000000000000052e323b066d1189735a3f9418d8df1dae18a433e000000000000000000000000aee94133925a8767929938bd08e1b4e155400d1400000000000000000000000055141a0dbc5c8b0b609bce8bc392e90303ee126d000000000000000000000000c689200c07b79cbff7171e60e4e25eee7d19b3f9000000000000000000000000c1d688f961f9a4c706d58d185ae70876e1c2b2eb000000000000000000000000a7c3455d43f34eedce2b209ea668266d5be2d69b000000000000000000000000ec959a871c83266a179d19c6512bbe6b5f6c47240000000000000000000000001f86c3bd13b79ba03648d7053097f4d448b09a2c000000000000000000000000a32d5006d5d43f7975b89d0936f881de3a610b31000000000000000000000000b752d5ac0b00d98ae53e824542e5adc6cbd510a8000000000000000000000000a46b32e2d55893b7a4cb6a1defca9c8cefd256660000000000000000000000009889c5e68c21a5b10529b052cd4ae98c111c4537000000000000000000000000f0c6130c69ebff2a0e5b27fc72034571f127628c000000000000000000000000d8fd1b0fa1a35b9dbfb0acb3d810ffb822fcc1170000000000000000000000001fc3f3e0ae9228c059bcd09d43e769e37207deaf0000000000000000000000004132314204cfb248479b4644b7d99062dd1e18c5000000000000000000000000cd9e6e0e63c5611ab1988e0569e3ad89b86086c600000000000000000000000079a4694e0539eb6611507ab363fcf6f9d93c6bc60000000000000000000000004b7fc9a9347e51f8959e02994d526fdb026b1cd9000000000000000000000000e3cd587613e7b6fc47ca76bf8e4cc896ae8eb0a60000000000000000000000003d3adf01b8b38d6c7a25b8ede8e2df254f7f77590000000000000000000000008d73c4b5c50ad59c3923b9fe1e75dbf035b7f110000000000000000000000000db9d72fab34ed9c9c9de17f1ee87dba46984510f0000000000000000000000004553c90540b35e3ee36bfcdb04fd46404dcbb27f0000000000000000000000005554e40290409c3eb164923f0836f5e04151b703000000000000000000000000ee53727c31b5790c3ef9511bbb545232705adcbe000000000000000000000000e05ff9f1cb76762e4b2f44fa4ac09fe9db943bcb00000000000000000000000010a969537236a282574cf159e412686eee0faacb00000000000000000000000000000000000000000000000000000000000000250000000000000000000000000000000000000000000000000006514132483049000000000000000000000000000000000000000000000000000650554e3450530000000000000000000000000000000000000000000000000006313656314c51000000000000000000000000000000000000000000000000000655504147394700000000000000000000000000000000000000000000000000065452524c345100000000000000000000000000000000000000000000000000066b61636f6e6b00000000000000000000000000000000000000000000000000064f33464c4357000000000000000000000000000000000000000000000000000647505658344600000000000000000000000000000000000000000000000000064b4c3252445200000000000000000000000000000000000000000000000000065357305733520000000000000000000000000000000000000000000000000006493846423146000000000000000000000000000000000000000000000000000639434241464e000000000000000000000000000000000000000000000000000648465738354b00000000000000000000000000000000000000000000000000065749434b454200000000000000000000000000000000000000000000000000064e304644433100000000000000000000000000000000000000000000000000064f58374f524b0000000000000000000000000000000000000000000000000006473430363255000000000000000000000000000000000000000000000000000652334d434b52000000000000000000000000000000000000000000000000000637484c485342000000000000000000000000000000000000000000000000000549434f424d000000000000000000000000000000000000000000000000000006534739686b37000000000000000000000000000000000000000000000000000647344d44505100000000000000000000000000000000000000000000000000063343564c55430000000000000000000000000000000000000000000000000006324a514d4934000000000000000000000000000000000000000000000000000639504a4b564f0000000000000000000000000000000000000000000000000006564f3531355500000000000000000000000000000000000000000000000000064a4141574930000000000000000000000000000000000000000000000000000653314a4e3832000000000000000000000000000000000000000000000000000641383053545500000000000000000000000000000000000000000000000000066d61686f6e690000000000000000000000000000000000000000000000000006454d3343503600000000000000000000000000000000000000000000000000065045374c454800000000000000000000000000000000000000000000000000064e454835304c0000000000000000000000000000000000000000000000000006534e46315548000000000000000000000000000000000000000000000000000633585830434f000000000000000000000000000000000000000000000000000655455755524200000000000000000000000000000000000000000000000000063151325733450000000000000000000000000000000000000000000000000000000000000025000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000058d15e176280000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000029378f43a6e9000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000172d0826e6e7000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002494e1d80f08c0000000000000000000000000000000000000000000000000000e9ec8ab16dfc0000000000000000000000000000000000000000000000000007c8637330dff800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001aa535d3d0c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6384869", gasUsed: "2697019", confirmations: "3448826"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "partners", value: [addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155]]}, {type: "bytes32[]", name: "promo_codes", value: ["0x0000000000000000000000000000000000000000000000000006514132483049","0x000000000000000000000000000000000000000000000000000650554e345053","0x0000000000000000000000000000000000000000000000000006313656314c51","0x0000000000000000000000000000000000000000000000000006555041473947","0x00000000000000000000000000000000000000000000000000065452524c3451","0x00000000000000000000000000000000000000000000000000066b61636f6e6b","0x00000000000000000000000000000000000000000000000000064f33464c4357","0x0000000000000000000000000000000000000000000000000006475056583446","0x00000000000000000000000000000000000000000000000000064b4c32524452","0x0000000000000000000000000000000000000000000000000006535730573352","0x0000000000000000000000000000000000000000000000000006493846423146","0x000000000000000000000000000000000000000000000000000639434241464e","0x000000000000000000000000000000000000000000000000000648465738354b","0x00000000000000000000000000000000000000000000000000065749434b4542","0x00000000000000000000000000000000000000000000000000064e3046444331","0x00000000000000000000000000000000000000000000000000064f58374f524b","0x0000000000000000000000000000000000000000000000000006473430363255","0x000000000000000000000000000000000000000000000000000652334d434b52","0x000000000000000000000000000000000000000000000000000637484c485342","0x000000000000000000000000000000000000000000000000000549434f424d00","0x0000000000000000000000000000000000000000000000000006534739686b37","0x000000000000000000000000000000000000000000000000000647344d445051","0x00000000000000000000000000000000000000000000000000063343564c5543","0x0000000000000000000000000000000000000000000000000006324a514d4934","0x000000000000000000000000000000000000000000000000000639504a4b564f","0x0000000000000000000000000000000000000000000000000006564f35313555","0x00000000000000000000000000000000000000000000000000064a4141574930","0x000000000000000000000000000000000000000000000000000653314a4e3832","0x0000000000000000000000000000000000000000000000000006413830535455","0x00000000000000000000000000000000000000000000000000066d61686f6e69","0x0000000000000000000000000000000000000000000000000006454d33435036","0x00000000000000000000000000000000000000000000000000065045374c4548","0x00000000000000000000000000000000000000000000000000064e454835304c","0x0000000000000000000000000000000000000000000000000006534e46315548","0x000000000000000000000000000000000000000000000000000633585830434f","0x0000000000000000000000000000000000000000000000000006554557555242","0x0000000000000000000000000000000000000000000000000006315132573345"]}, {type: "uint256[]", name: "attracted_invests", value: ["0","0","0","400000000000000000","0","0","0","0","2970000000000000000","0","0","0","0","0","0","0","0","0","0","0","1670000000000000000","0","0","0","0","2635980000000000000","1053500000000000000","8972920000000000000","0","0","0","0","0","0","120000000000000000","0","0"]}], name: "setPartnerFromPreICOAffiliate", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPartnerFromPreICOAffiliate(address[],bytes32[],uint256[])" ]( [addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155]], ["0x0000000000000000000000000000000000000000000000000006514132483049","0x000000000000000000000000000000000000000000000000000650554e345053","0x0000000000000000000000000000000000000000000000000006313656314c51","0x0000000000000000000000000000000000000000000000000006555041473947","0x00000000000000000000000000000000000000000000000000065452524c3451","0x00000000000000000000000000000000000000000000000000066b61636f6e6b","0x00000000000000000000000000000000000000000000000000064f33464c4357","0x0000000000000000000000000000000000000000000000000006475056583446","0x00000000000000000000000000000000000000000000000000064b4c32524452","0x0000000000000000000000000000000000000000000000000006535730573352","0x0000000000000000000000000000000000000000000000000006493846423146","0x000000000000000000000000000000000000000000000000000639434241464e","0x000000000000000000000000000000000000000000000000000648465738354b","0x00000000000000000000000000000000000000000000000000065749434b4542","0x00000000000000000000000000000000000000000000000000064e3046444331","0x00000000000000000000000000000000000000000000000000064f58374f524b","0x0000000000000000000000000000000000000000000000000006473430363255","0x000000000000000000000000000000000000000000000000000652334d434b52","0x000000000000000000000000000000000000000000000000000637484c485342","0x000000000000000000000000000000000000000000000000000549434f424d00","0x0000000000000000000000000000000000000000000000000006534739686b37","0x000000000000000000000000000000000000000000000000000647344d445051","0x00000000000000000000000000000000000000000000000000063343564c5543","0x0000000000000000000000000000000000000000000000000006324a514d4934","0x000000000000000000000000000000000000000000000000000639504a4b564f","0x0000000000000000000000000000000000000000000000000006564f35313555","0x00000000000000000000000000000000000000000000000000064a4141574930","0x000000000000000000000000000000000000000000000000000653314a4e3832","0x0000000000000000000000000000000000000000000000000006413830535455","0x00000000000000000000000000000000000000000000000000066d61686f6e69","0x0000000000000000000000000000000000000000000000000006454d33435036","0x00000000000000000000000000000000000000000000000000065045374c4548","0x00000000000000000000000000000000000000000000000000064e454835304c","0x0000000000000000000000000000000000000000000000000006534e46315548","0x000000000000000000000000000000000000000000000000000633585830434f","0x0000000000000000000000000000000000000000000000000006554557555242","0x0000000000000000000000000000000000000000000000000006315132573345"], ["0","0","0","400000000000000000","0","0","0","0","2970000000000000000","0","0","0","0","0","0","0","0","0","0","0","1670000000000000000","0","0","0","0","2635980000000000000","1053500000000000000","8972920000000000000","0","0","0","0","0","0","120000000000000000","0","0"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1504991989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "64728470575856743" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: setPartnerFromPreICOAffiliate( [addressList[156],addressList[157],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4256532", timeStamp: "1504992070", hash: "0x1337c99f3527f73369528bbe3b89bad17d79b1227198bb889468c0573ed3d17b", nonce: "58", blockHash: "0x689fd1b097330fe370b67da1586d1bd1e4ca389de2f67ca3a4372fd7f5b98208", transactionIndex: "66", from: "0x956fdf7be4453e26859b0c859d236c268b79ceb1", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "2793300", gasPrice: "5250000000", isError: "0", txreceipt_status: "", input: "0xde63dc350000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000052000000000000000000000000000000000000000000000000000000000000009e00000000000000000000000000000000000000000000000000000000000000025000000000000000000000000ef079573a14f9620e4400f14af36b7438332fc5f000000000000000000000000fa5f19cfb5996be004ca3de2afff19cf7c290dff00000000000000000000000066c4e8be4e2c7bfa4fb9b1e56191839cceb5288c00000000000000000000000094bdee80334867bf5d9725aae513bb3d5f9f0e33000000000000000000000000f4deb0c8a5da8bc25f5d096ab792425ba1600499000000000000000000000000a9de82b1452b3d17a755144e040c2ba8b5d6ef2900000000000000000000000025ad8e40ac360d12d7096564f04fe6da4197d019000000000000000000000000d9e5519f349b505db17a985d9078664116a564d30000000000000000000000000c95959eb2056d86552baa4b859288c84d74a7e9000000000000000000000000de0bf7e29e763847b0596c7ca1747821f4f5582b0000000000000000000000007231f1497be3e1e4883a9289f2d908edad7943ed00000000000000000000000017417fd1ea21a12b927b836114edf66ab58130e90000000000000000000000004895c362216a8bf75c62b067b042db2d1e4927170000000000000000000000005ca8f9c9ebc704ebb88e42e243edc011cea50e4200000000000000000000000000535cf7066462210470166cd36d7b8254ee0d3f000000000000000000000000b63513c128f0e92a42a62494634ec61634d730e90000000000000000000000006b6c52a83795514b3e610a96d6ae2e7c435caab3000000000000000000000000fb9199f8e6e9bbf8db8fb42a1f8d51ce6b48d664000000000000000000000000eae3080e3a41d38740c5374e8777dcccbe2f7a4d000000000000000000000000eafd621cdb0d6e576ba86c321c30407eb7d7fdbb000000000000000000000000d361412e00563d1494fbbc7769a48fe52290f04f000000000000000000000000b4dc963c33ebae7e9b83941ea707ae39eaf5d960000000000000000000000000b4bc199fb46ed2bd552c9253d27fd59a50ed73720000000000000000000000000aef85f7ac4dad6126f63b2f92751984dbb3487f000000000000000000000000a3e6da03a755c937fb32f7bcd76cff750ccc05cd000000000000000000000000f858734521d3b0b6c774aeda13eaaf5aacb2706b000000000000000000000000715673237674343add4759c1c961e702c86a0a550000000000000000000000007ebada6bf6b52a9c852aeb0c47a4fd2a537e83a2000000000000000000000000963d84387a798a3a6d434828fa34976d1dbe3eca0000000000000000000000006053f9c1abfa158396a6934fe897100296c7da76000000000000000000000000dc168d1a292d957db8213184fd111df610c52df1000000000000000000000000d3a4567f1c0c5d2fd6df174eea78e03122b8ad550000000000000000000000004ef2516c2c452f67ddd07ffb35a5e8699144694a000000000000000000000000a9c305522abf3b797d21967c5ce2d12a2cd44c52000000000000000000000000095037aa9b136184076445ac21a64454752fb878000000000000000000000000c5742afa93de037a0041fa6aa7bae95997bf89740000000000000000000000009b8adbd42bb5ac763f5ae2a97c60b2373733288600000000000000000000000000000000000000000000000000000000000000250000000000000000000000000000000000000000000000000006574e4d364532000000000000000000000000000000000000000000000000000658564934473000000000000000000000000000000000000000000000000000065837554c4b3800000000000000000000000000000000000000000000000000064542494d424700000000000000000000000000000000000000000000000000064838425737380000000000000000000000000000000000000000000000000006573743324e5500000000000000000000000000000000000000000000000000064d504e58584c000000000000000000000000000000000000000000000000000636353341504300000000000000000000000000000000000000000000000000064a564e4255440000000000000000000000000000000000000000000000000006394a415832370000000000000000000000000000000000000000000000000006494b31564c52000000000000000000000000000000000000000000000000000635414c47354f00000000000000000000000000000000000000000000000000064e4b433339450000000000000000000000000000000000000000000000000006354a455130460000000000000000000000000000000000000000000000000006424d41414c35000000000000000000000000000000000000000000000000000643364a4244430000000000000000000000000000000000000000000000000006364c4f453158000000000000000000000000000000000000000000000000000646385548524700000000000000000000000000000000000000000000000000064c30434242580000000000000000000000000000000000000000000000000006504a5752394f000000000000000000000000000000000000000000000000000646523142445200000000000000000000000000000000000000000000000000064e31353430420000000000000000000000000000000000000000000000000006424d474946540000000000000000000000000000000000000000000000000006726164323238000000000000000000000000000000000000000000000000000637394139394400000000000000000000000000000000000000000000000000063539554748380000000000000000000000000000000000000000000000000006495139324f4b000000000000000000000000000000000000000000000000000633524c3356390000000000000000000000000000000000000000000000000006434741543841000000000000000000000000000000000000000000000000000639444a39455000000000000000000000000000000000000000000000000000064a4b573643480000000000000000000000000000000000000000000000000006474d53313643000000000000000000000000000000000000000000000000000649384b3352510000000000000000000000000000000000000000000000000006524a384f564400000000000000000000000000000000000000000000000000063741585645370000000000000000000000000000000000000000000000000006524348504c3300000000000000000000000000000000000000000000000000064b54454d513000000000000000000000000000000000000000000000000000000000000000250000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000029a2241af62c000000000000000000000000000000000000000000000000000050e741434f18400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000089aaeb710be0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001d167ce519380000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000051bd7bcb1f0d000000000000000000000000000000000000000000000000000036b4cc1d489700000000000000000000000000000000000000000000000000000efcee47256c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001ab9ffe14d9da820000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002914085137280000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001aa535d3d0c00000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5042075", gasUsed: "2743299", confirmations: "3448823"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "partners", value: [addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192]]}, {type: "bytes32[]", name: "promo_codes", value: ["0x0000000000000000000000000000000000000000000000000006574e4d364532","0x0000000000000000000000000000000000000000000000000006585649344730","0x00000000000000000000000000000000000000000000000000065837554c4b38","0x00000000000000000000000000000000000000000000000000064542494d4247","0x0000000000000000000000000000000000000000000000000006483842573738","0x0000000000000000000000000000000000000000000000000006573743324e55","0x00000000000000000000000000000000000000000000000000064d504e58584c","0x0000000000000000000000000000000000000000000000000006363533415043","0x00000000000000000000000000000000000000000000000000064a564e425544","0x0000000000000000000000000000000000000000000000000006394a41583237","0x0000000000000000000000000000000000000000000000000006494b31564c52","0x000000000000000000000000000000000000000000000000000635414c47354f","0x00000000000000000000000000000000000000000000000000064e4b43333945","0x0000000000000000000000000000000000000000000000000006354a45513046","0x0000000000000000000000000000000000000000000000000006424d41414c35","0x000000000000000000000000000000000000000000000000000643364a424443","0x0000000000000000000000000000000000000000000000000006364c4f453158","0x0000000000000000000000000000000000000000000000000006463855485247","0x00000000000000000000000000000000000000000000000000064c3043424258","0x0000000000000000000000000000000000000000000000000006504a5752394f","0x0000000000000000000000000000000000000000000000000006465231424452","0x00000000000000000000000000000000000000000000000000064e3135343042","0x0000000000000000000000000000000000000000000000000006424d47494654","0x0000000000000000000000000000000000000000000000000006726164323238","0x0000000000000000000000000000000000000000000000000006373941393944","0x0000000000000000000000000000000000000000000000000006353955474838","0x0000000000000000000000000000000000000000000000000006495139324f4b","0x000000000000000000000000000000000000000000000000000633524c335639","0x0000000000000000000000000000000000000000000000000006434741543841","0x000000000000000000000000000000000000000000000000000639444a394550","0x00000000000000000000000000000000000000000000000000064a4b57364348","0x0000000000000000000000000000000000000000000000000006474d53313643","0x000000000000000000000000000000000000000000000000000649384b335251","0x0000000000000000000000000000000000000000000000000006524a384f5644","0x0000000000000000000000000000000000000000000000000006374158564537","0x0000000000000000000000000000000000000000000000000006524348504c33","0x00000000000000000000000000000000000000000000000000064b54454d5130"]}, {type: "uint256[]", name: "attracted_invests", value: ["0","0","0","0","0","3000000000000000000","5829700000000000000","0","0","620000000000000000","0","131000000000000000","0","0","5890000000000000000","3942000000000000000","1080000000000000000","0","0","30813626541000000000","0","0","0","0","0","0","0","0","0","0","0","0","185000000000000000","0","0","120000000000000000","0"]}], name: "setPartnerFromPreICOAffiliate", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPartnerFromPreICOAffiliate(address[],bytes32[],uint256[])" ]( [addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192]], ["0x0000000000000000000000000000000000000000000000000006574e4d364532","0x0000000000000000000000000000000000000000000000000006585649344730","0x00000000000000000000000000000000000000000000000000065837554c4b38","0x00000000000000000000000000000000000000000000000000064542494d4247","0x0000000000000000000000000000000000000000000000000006483842573738","0x0000000000000000000000000000000000000000000000000006573743324e55","0x00000000000000000000000000000000000000000000000000064d504e58584c","0x0000000000000000000000000000000000000000000000000006363533415043","0x00000000000000000000000000000000000000000000000000064a564e425544","0x0000000000000000000000000000000000000000000000000006394a41583237","0x0000000000000000000000000000000000000000000000000006494b31564c52","0x000000000000000000000000000000000000000000000000000635414c47354f","0x00000000000000000000000000000000000000000000000000064e4b43333945","0x0000000000000000000000000000000000000000000000000006354a45513046","0x0000000000000000000000000000000000000000000000000006424d41414c35","0x000000000000000000000000000000000000000000000000000643364a424443","0x0000000000000000000000000000000000000000000000000006364c4f453158","0x0000000000000000000000000000000000000000000000000006463855485247","0x00000000000000000000000000000000000000000000000000064c3043424258","0x0000000000000000000000000000000000000000000000000006504a5752394f","0x0000000000000000000000000000000000000000000000000006465231424452","0x00000000000000000000000000000000000000000000000000064e3135343042","0x0000000000000000000000000000000000000000000000000006424d47494654","0x0000000000000000000000000000000000000000000000000006726164323238","0x0000000000000000000000000000000000000000000000000006373941393944","0x0000000000000000000000000000000000000000000000000006353955474838","0x0000000000000000000000000000000000000000000000000006495139324f4b","0x000000000000000000000000000000000000000000000000000633524c335639","0x0000000000000000000000000000000000000000000000000006434741543841","0x000000000000000000000000000000000000000000000000000639444a394550","0x00000000000000000000000000000000000000000000000000064a4b57364348","0x0000000000000000000000000000000000000000000000000006474d53313643","0x000000000000000000000000000000000000000000000000000649384b335251","0x0000000000000000000000000000000000000000000000000006524a384f5644","0x0000000000000000000000000000000000000000000000000006374158564537","0x0000000000000000000000000000000000000000000000000006524348504c33","0x00000000000000000000000000000000000000000000000000064b54454d5130"], ["0","0","0","0","0","3000000000000000000","5829700000000000000","0","0","620000000000000000","0","131000000000000000","0","0","5890000000000000000","3942000000000000000","1080000000000000000","0","0","30813626541000000000","0","0","0","0","0","0","0","0","0","0","0","0","185000000000000000","0","0","120000000000000000","0"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1504992070 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "64728470575856743" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: setPartnerFromPreICOAffiliate( [addressList[193],addressList[194],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4256534", timeStamp: "1504992117", hash: "0x6b68d5aec16ee7596a07918e0ac80a479de16a6590f75ba60e9852a44aeec313", nonce: "59", blockHash: "0xbc0548d0998031f655f09de664120d2ea9c19037d72304506a94a2b9af5f3870", transactionIndex: "86", from: "0x956fdf7be4453e26859b0c859d236c268b79ceb1", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "1267996", gasPrice: "5250000000", isError: "0", txreceipt_status: "", input: "0xde63dc35000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000002a000000000000000000000000000000000000000000000000000000000000004e000000000000000000000000000000000000000000000000000000000000000110000000000000000000000002e081852e88c22d2da76a93bc37696a70d048717000000000000000000000000ad2d3f5cde8a3fcd8954ae1eab34fa784583650b0000000000000000000000004ec2cd9403cfb2e04a0b073dfc22702ed2b50eef0000000000000000000000002de79e18976842500cfe5e4fb4c47d83d7eb6bee0000000000000000000000002022222309feda8cad2463585b5839edf90a188e000000000000000000000000ada6b8c3c74c129c2b34332a270ad6172fffeed7000000000000000000000000ee0696eb59e25d7a95105c6f5ba086c686dc09c0000000000000000000000000f2431f34cbfd80009be83bd82bc5aabb38e476790000000000000000000000000cd0909399134f6855a85f06170dd18935d53e92000000000000000000000000453bbee98cb1787ecaf7baa8513cf9abfbcf138e000000000000000000000000561bb66cc59726c04d51a7e5ab4194f7f6611ba3000000000000000000000000830ed592b2f26f5e7a7d0beb36d46ae3c3663517000000000000000000000000bf7fcc6ca052550ec5c4b4ad80092ca1efa0038e0000000000000000000000004fdf6e883bf0a2ae6f49ae39ee2d80283afd7b860000000000000000000000007a03aba179cd2f96b7f56580796a84a9be04dae300000000000000000000000029e0a70bb9b5b0a819b2e1473744a872c1c397a20000000000000000000000004f14c30a70093ffa85ff5d9dad02929af3b4a4ee000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000064d44563437450000000000000000000000000000000000000000000000000006555432304d5400000000000000000000000000000000000000000000000000064a524f5648560000000000000000000000000000000000000000000000000006464c33303449000000000000000000000000000000000000000000000000000636515656433500000000000000000000000000000000000000000000000000064947574e54570000000000000000000000000000000000000000000000000006364e50464241000000000000000000000000000000000000000000000000000631374853503600000000000000000000000000000000000000000000000000064c56534a444b00000000000000000000000000000000000000000000000000064c36424b5350000000000000000000000000000000000000000000000000000645524156583100000000000000000000000000000000000000000000000000065353334e4345000000000000000000000000000000000000000000000000000641534838514c00000000000000000000000000000000000000000000000000063130584835320000000000000000000000000000000000000000000000000006553550584c4b00000000000000000000000000000000000000000000000000064d3333414a54000000000000000000000000000000000000000000000000000658564147574300000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008257163d327800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3346848", gasUsed: "1217995", confirmations: "3448821"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "partners", value: [addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209]]}, {type: "bytes32[]", name: "promo_codes", value: ["0x00000000000000000000000000000000000000000000000000064d4456343745","0x0000000000000000000000000000000000000000000000000006555432304d54","0x00000000000000000000000000000000000000000000000000064a524f564856","0x0000000000000000000000000000000000000000000000000006464c33303449","0x0000000000000000000000000000000000000000000000000006365156564335","0x00000000000000000000000000000000000000000000000000064947574e5457","0x0000000000000000000000000000000000000000000000000006364e50464241","0x0000000000000000000000000000000000000000000000000006313748535036","0x00000000000000000000000000000000000000000000000000064c56534a444b","0x00000000000000000000000000000000000000000000000000064c36424b5350","0x0000000000000000000000000000000000000000000000000006455241565831","0x00000000000000000000000000000000000000000000000000065353334e4345","0x000000000000000000000000000000000000000000000000000641534838514c","0x0000000000000000000000000000000000000000000000000006313058483532","0x0000000000000000000000000000000000000000000000000006553550584c4b","0x00000000000000000000000000000000000000000000000000064d3333414a54","0x0000000000000000000000000000000000000000000000000006585641475743"]}, {type: "uint256[]", name: "attracted_invests", value: ["0","0","0","0","0","0","0","0","587000000000000000","0","0","0","0","0","0","0","0"]}], name: "setPartnerFromPreICOAffiliate", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPartnerFromPreICOAffiliate(address[],bytes32[],uint256[])" ]( [addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209]], ["0x00000000000000000000000000000000000000000000000000064d4456343745","0x0000000000000000000000000000000000000000000000000006555432304d54","0x00000000000000000000000000000000000000000000000000064a524f564856","0x0000000000000000000000000000000000000000000000000006464c33303449","0x0000000000000000000000000000000000000000000000000006365156564335","0x00000000000000000000000000000000000000000000000000064947574e5457","0x0000000000000000000000000000000000000000000000000006364e50464241","0x0000000000000000000000000000000000000000000000000006313748535036","0x00000000000000000000000000000000000000000000000000064c56534a444b","0x00000000000000000000000000000000000000000000000000064c36424b5350","0x0000000000000000000000000000000000000000000000000006455241565831","0x00000000000000000000000000000000000000000000000000065353334e4345","0x000000000000000000000000000000000000000000000000000641534838514c","0x0000000000000000000000000000000000000000000000000006313058483532","0x0000000000000000000000000000000000000000000000000006553550584c4b","0x00000000000000000000000000000000000000000000000000064d3333414a54","0x0000000000000000000000000000000000000000000000000006585641475743"], ["0","0","0","0","0","0","0","0","587000000000000000","0","0","0","0","0","0","0","0"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1504992117 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "64728470575856743" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `617B6G` )", async function( ) {
		const txOriginal = {blockNumber: "4257506", timeStamp: "1505015833", hash: "0xa8b4d37e6b6b5e4ae836f5d70a023bb5f9132a2b35579c69525815fc16072aea", nonce: "1", blockHash: "0x0282fd198d8f915a695eff9972c41f9d58688a09f087d971c91da2ae438256ba", transactionIndex: "56", from: "0xd7cc52a97c84fa1a1e1926b05508a7ed7d7a493c", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "133864", gasPrice: "24002862279", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000063631374236470000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2751772", gasUsed: "89242", confirmations: "3447849"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[210], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `617B6G`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `617B6G`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1505015833 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[210], balance: "18346433102997482" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[210], balance: ( await web3.eth.getBalance( addressList[210], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `U92BKE` )", async function( ) {
		const txOriginal = {blockNumber: "4258151", timeStamp: "1505031827", hash: "0xd019bf90009fb6c6d321d8c05f0ef8a3445e9abf7b35fb8a6a38d71f46cb1e15", nonce: "2", blockHash: "0x0929b55f2e856270b1183da6584d40ca96c509e6d2c48608f77a5d65adee6177", transactionIndex: "118", from: "0xd7cc52a97c84fa1a1e1926b05508a7ed7d7a493c", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "25000", gasPrice: "20675578460", isError: "1", txreceipt_status: "", input: "0x06faebbe00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000006553932424b450000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4527597", gasUsed: "25000", confirmations: "3447204"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[210], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `U92BKE`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[210], balance: "18346433102997482" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[210], balance: ( await web3.eth.getBalance( addressList[210], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `3ORN48` )", async function( ) {
		const txOriginal = {blockNumber: "4258310", timeStamp: "1505035754", hash: "0xcf83b45bbf0a4cc3866d3cb1edfecc2bfe4c303b2905383654fede5786ffa0d6", nonce: "0", blockHash: "0x6dfdde2f307dabbaf80f0761f5f86a45f29c1f8989f3d7194364d9ffcbc24685", transactionIndex: "9", from: "0xc080f1c31fcf41f9aabf6d41c7a2bf87c4f06edc", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "30234837538", isError: "0", txreceipt_status: "", input: "0x06faebbe00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000006334f524e34380000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "380147", gasUsed: "89242", confirmations: "3447045"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[211], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `3ORN48`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `3ORN48`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1505035754 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[211], balance: "157549353448048884" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[211], balance: ( await web3.eth.getBalance( addressList[211], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: setPartnerFromPreICOAffiliate( [addressList[209],addressList[212],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4258697", timeStamp: "1505045232", hash: "0x1f8f293494bd874c43289d3de7758fa190d26924361214e3f0154444003878c3", nonce: "66", blockHash: "0xaa760cc617a8ee20fca9d7b596e09841097b62ee3c0f0650d78c4405d7c85fc1", transactionIndex: "90", from: "0x956fdf7be4453e26859b0c859d236c268b79ceb1", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "423223", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0xde63dc3500000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000022000000000000000000000000000000000000000000000000000000000000000060000000000000000000000004f14c30a70093ffa85ff5d9dad02929af3b4a4ee000000000000000000000000d5a9cc70e7f82eb9839b3f8f96b71bf71f33b6e70000000000000000000000009a946fe02237e692dbd417fec46f433f45d21a3c0000000000000000000000000b2b4dfffa99338356945813cab90d41ce17d1350000000000000000000000001437ab9906c19ee262c64137d9420778f28331910000000000000000000000006af5d35d0109dcccbc87fdf90b065a65e6684ba70000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000658564147574300000000000000000000000000000000000000000000000000064a46364f4c42000000000000000000000000000000000000000000000000000647555137333100000000000000000000000000000000000000000000000000064843444a4e340000000000000000000000000000000000000000000000000006464d4731434a00000000000000000000000000000000000000000000000000064c46303632310000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2791899", gasUsed: "373223", confirmations: "3446658"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "partners", value: [addressList[209],addressList[212],addressList[213],addressList[214],addressList[215],addressList[216]]}, {type: "bytes32[]", name: "promo_codes", value: ["0x0000000000000000000000000000000000000000000000000006585641475743","0x00000000000000000000000000000000000000000000000000064a46364f4c42","0x0000000000000000000000000000000000000000000000000006475551373331","0x00000000000000000000000000000000000000000000000000064843444a4e34","0x0000000000000000000000000000000000000000000000000006464d4731434a","0x00000000000000000000000000000000000000000000000000064c4630363231"]}, {type: "uint256[]", name: "attracted_invests", value: ["0","0","0","0","0","0"]}], name: "setPartnerFromPreICOAffiliate", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPartnerFromPreICOAffiliate(address[],bytes32[],uint256[])" ]( [addressList[209],addressList[212],addressList[213],addressList[214],addressList[215],addressList[216]], ["0x0000000000000000000000000000000000000000000000000006585641475743","0x00000000000000000000000000000000000000000000000000064a46364f4c42","0x0000000000000000000000000000000000000000000000000006475551373331","0x00000000000000000000000000000000000000000000000000064843444a4e34","0x0000000000000000000000000000000000000000000000000006464d4731434a","0x00000000000000000000000000000000000000000000000000064c4630363231"], ["0","0","0","0","0","0"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1505045232 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "64728470575856743" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `50L32L` )", async function( ) {
		const txOriginal = {blockNumber: "4259079", timeStamp: "1505054693", hash: "0x0d5447dca1967ac1032379d066900eb525782f20aae9f8e496de7c8f52cb8402", nonce: "1", blockHash: "0x062edd641595164ff3a8315498fa9977a1bfd6d850449ae08480d25f001c1a0d", transactionIndex: "51", from: "0xbda7dc4cdc959eba0f5ed893b082cdcb1ab34395", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90242", gasPrice: "21834513098", isError: "0", txreceipt_status: "", input: "0x06faebbe0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000635304c33324c0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2750525", gasUsed: "89242", confirmations: "3446276"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[217], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `50L32L`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `50L32L`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1505054693 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[217], balance: "716572087064472" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[217], balance: ( await web3.eth.getBalance( addressList[217], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `9JR7L4` )", async function( ) {
		const txOriginal = {blockNumber: "4259149", timeStamp: "1505056043", hash: "0xc339102a2cf7da7ca91536923bd082c6f08e8ebd383eb1666a7582f63ed7561e", nonce: "2", blockHash: "0xda5bc6b1a8dd6d3338be4879414f4ade0e5547cf7be45b8dd5648287397e70a4", transactionIndex: "88", from: "0x739340d28339b0af5f85b2dbcd01a50b0eba1e08", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "21834513098", isError: "0", txreceipt_status: "", input: "0x06faebbe00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000006394a52374c340000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3037250", gasUsed: "89242", confirmations: "3446206"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[218], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `9JR7L4`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `9JR7L4`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1505056043 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[218], balance: "3541556735622728" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[218], balance: ( await web3.eth.getBalance( addressList[218], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `ESUJCQ` )", async function( ) {
		const txOriginal = {blockNumber: "4261871", timeStamp: "1505122746", hash: "0x3c796a59c9c97412bb8f1169c778641c6636b938d08b4843af20cb0e808baf28", nonce: "3", blockHash: "0xaa764e10e2cc917eb67908ae08b35e936407469179e55884ee777e64d5a5a068", transactionIndex: "14", from: "0xd642e885fbdb068e7bb9e813bd1e3a47566a8fe1", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90242", gasPrice: "21767967327", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000064553554a43510000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "608707", gasUsed: "89242", confirmations: "3443484"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[219], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `ESUJCQ`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `ESUJCQ`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1505122746 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[219], balance: "858985659376717" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[219], balance: ( await web3.eth.getBalance( addressList[219], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `WOWWIA` )", async function( ) {
		const txOriginal = {blockNumber: "4262060", timeStamp: "1505127236", hash: "0xca6bf48abbbf1c37b661370b4b6dc1dd48547e0381f2c5546c210f94009a2589", nonce: "8", blockHash: "0x484e8c38ba7e7e5dc0e2db80f2283d9223d591f7976fce9496d0232cc8460b27", transactionIndex: "166", from: "0x92e3ad441b552510635c8fe547fbfc785dee500b", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "133864", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000006574f575749410000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5489159", gasUsed: "89242", confirmations: "3443295"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[220], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `WOWWIA`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `WOWWIA`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1505127236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[220], balance: "2949978798859000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[220], balance: ( await web3.eth.getBalance( addressList[220], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `3RBCOM` )", async function( ) {
		const txOriginal = {blockNumber: "4262366", timeStamp: "1505134056", hash: "0x13b767cabbc6a6c5553fea3188f430925e3f89781111ea4ef1b777ebaf033421", nonce: "0", blockHash: "0x9e9221c9a0e69b5ef971c748b330b2cf51932ec4e84dfce1ace74a362dc38be0", transactionIndex: "43", from: "0x81a684560210dc2a7c13788b5822f0b00e854794", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000006335242434f4d0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1691434", gasUsed: "89242", confirmations: "3442989"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[221], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `3RBCOM`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `3RBCOM`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1505134056 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[221], balance: "45123838000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[221], balance: ( await web3.eth.getBalance( addressList[221], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `4U6SPX` )", async function( ) {
		const txOriginal = {blockNumber: "4262381", timeStamp: "1505134441", hash: "0xdfc3ae37e38ee7fa4cbf3d2bf3ffde421f514fb4578498ba8e0ed00b7e42c21d", nonce: "1", blockHash: "0x8b0404b2e5173e7abdbfc98f521d50808486ccaff3cd0a6344e0bb6c7aa8cef0", transactionIndex: "111", from: "0x9c1385840e27822cc1b0cae3cb7e487eeb1d5235", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000063455365350580000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2851059", gasUsed: "89242", confirmations: "3442974"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[222], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `4U6SPX`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `4U6SPX`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1505134441 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[222], balance: "18195918000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[222], balance: ( await web3.eth.getBalance( addressList[222], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `NVM4VI` )", async function( ) {
		const txOriginal = {blockNumber: "4262736", timeStamp: "1505142503", hash: "0x2099ef228ef86ebf3e07a5279255293ea7bbeac1404c3eac5b3a1cf381186824", nonce: "0", blockHash: "0x59d62df3226cbe3b038052f2de1e9d09924a541912655dc04359cb5e66ad8cdd", transactionIndex: "27", from: "0xcf5201efdde4f23b4c8814b88de28702f15a91b4", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000064e564d3456490000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1358352", gasUsed: "89242", confirmations: "3442619"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[223], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `NVM4VI`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `NVM4VI`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1505142503 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[223], balance: "700570426000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[223], balance: ( await web3.eth.getBalance( addressList[223], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `ABX6JL` )", async function( ) {
		const txOriginal = {blockNumber: "4263025", timeStamp: "1505149611", hash: "0xdb67f124c7bf0af103e4ed8c02a851ffea9950bd640d65fafb175dd634d1e9db", nonce: "4", blockHash: "0xf6c40147f5d53ab9311ca15e4644b5420ffea25c1ed902e2866e2c2689f54129", transactionIndex: "79", from: "0xa5b5837952c4d8222ae162d2095fc3722ad7087f", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000006414258364a4c0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2338289", gasUsed: "89242", confirmations: "3442330"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[224], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `ABX6JL`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `ABX6JL`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1505149611 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[224], balance: "22000000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[224], balance: ( await web3.eth.getBalance( addressList[224], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `H5XBLS` )", async function( ) {
		const txOriginal = {blockNumber: "4263061", timeStamp: "1505150385", hash: "0x861f1815acaf8fd2bd7c859e6da551e28d63a34a69b79a4f2929a666b5182a80", nonce: "1", blockHash: "0x3a9cd34a7b59df68c6fa29d2d133de4116ee944e27d096bda1c9d624bc14161e", transactionIndex: "62", from: "0x94b7fa1a30a0dbcf98e56012606b6bc3b68340a3", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90242", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000006483558424c530000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2900976", gasUsed: "89242", confirmations: "3442294"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[225], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `H5XBLS`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `H5XBLS`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1505150385 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[225], balance: "1439623000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[225], balance: ( await web3.eth.getBalance( addressList[225], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `SDWOS3` )", async function( ) {
		const txOriginal = {blockNumber: "4263254", timeStamp: "1505154952", hash: "0xa79370f9a4bfa7c2c2be0e6b6a8c4f21834c2166764ccb75a4dc550e6c533b8d", nonce: "1", blockHash: "0x84f176247df95750dd882a7f0846c2f22a676e557a332748b27f378d094736f0", transactionIndex: "51", from: "0x310fb2a1b1e92c693c3704cd44b654751316c6a6", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90242", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000065344574f53330000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2226638", gasUsed: "89242", confirmations: "3442101"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[226], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `SDWOS3`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `SDWOS3`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1505154952 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[226], balance: "6745598000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[226], balance: ( await web3.eth.getBalance( addressList[226], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `HD26VR` )", async function( ) {
		const txOriginal = {blockNumber: "4263732", timeStamp: "1505166581", hash: "0xb603f8dcb023091f8a6a6a7f2e58b47267e87eecfa69c2666a2f79797df7e579", nonce: "0", blockHash: "0xd59aa1aee874cc95099e49c5636a619701b7a009bb57e144ca09efe20f202c49", transactionIndex: "233", from: "0x9d9a1dcc4598be0cddbd4c5db28d3633f60d0e35", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90242", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000064844323656520000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6424401", gasUsed: "89242", confirmations: "3441623"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[227], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `HD26VR`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `HD26VR`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1505166581 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[227], balance: "29171909711720224" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[227], balance: ( await web3.eth.getBalance( addressList[227], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `JEL58R` )", async function( ) {
		const txOriginal = {blockNumber: "4264993", timeStamp: "1505196909", hash: "0x97a719492e866bf7021f1ce1aeb000c771285a6c86cb3e9843bc0e0ba91e8a50", nonce: "1", blockHash: "0x75edac04af9dc1a4da737a8c7c34b75f9650b0acb22f5c35da4c329607f5212d", transactionIndex: "81", from: "0x4fc7d5799191498bac13bb1aefc79ecb594b8ba7", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "27398149959", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000064a454c3538520000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2960569", gasUsed: "89242", confirmations: "3440362"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[228], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `JEL58R`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `JEL58R`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1505196909 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[228], balance: "40309564481345674" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[228], balance: ( await web3.eth.getBalance( addressList[228], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `OHRFGH` )", async function( ) {
		const txOriginal = {blockNumber: "4265008", timeStamp: "1505197190", hash: "0x73175de84ebbe705f377cc79e62a5957f6c000ae75a1921cc848c7091c5e6286", nonce: "4", blockHash: "0x7602aad61b08372021789fd19ad65c097362bcfee5fbb9aa35db8031162d4d3e", transactionIndex: "65", from: "0x7a3e2962e1cc04bc37b052483f13e07201110725", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90242", gasPrice: "27398149959", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000064f48524647480000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2407944", gasUsed: "89242", confirmations: "3440347"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[229], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `OHRFGH`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `OHRFGH`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1505197190 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[229], balance: "826484851358922" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[229], balance: ( await web3.eth.getBalance( addressList[229], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `VQ453Q` )", async function( ) {
		const txOriginal = {blockNumber: "4265192", timeStamp: "1505201448", hash: "0x1319963843eaf151d6aea8732d5a19e9ec5923e56d9445010de0d1b9e7abd156", nonce: "1", blockHash: "0x2ba9b3224409acb99b04d505af8d3040876572880d0377c2a4c76d302d8800e1", transactionIndex: "58", from: "0xccaa1570ada0957f339fed1c6d7a9f7409c8df74", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "22930166766", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000065651343533510000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2179474", gasUsed: "89242", confirmations: "3440163"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[230], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `VQ453Q`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `VQ453Q`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1505201448 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[230], balance: "3289996799265872" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[230], balance: ( await web3.eth.getBalance( addressList[230], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `` )", async function( ) {
		const txOriginal = {blockNumber: "4265676", timeStamp: "1505213268", hash: "0xecb6de61b4911aa2420bfc8ee578f72c927b61618db33d71c3be35ed35011a65", nonce: "7", blockHash: "0x593d34598617b3c70af20123cfb427095611f127e6ee1363d09dc17d9e16c0bc", transactionIndex: "154", from: "0x875deda9a100690eb71c5df995db8f13b9646dcf", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "21592", gasPrice: "1000000000", isError: "1", txreceipt_status: "", input: "0x06faebbe00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3349932", gasUsed: "21592", confirmations: "3439679"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[231], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: ``}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[231], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[231], balance: ( await web3.eth.getBalance( addressList[231], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `icologs` )", async function( ) {
		const txOriginal = {blockNumber: "4265685", timeStamp: "1505213468", hash: "0xf6d2b8a6a2c6df3984bc1d28715b63883442bac667ba98997bcfb7ce3ea5be40", nonce: "8", blockHash: "0xb17fcfe6ff8ce63162f890c411f72bbf1e39a94c0be8e2cf1a2b1c2e2af2ded8", transactionIndex: "52", from: "0x875deda9a100690eb71c5df995db8f13b9646dcf", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "23000", gasPrice: "1000000000", isError: "1", txreceipt_status: "", input: "0x06faebbe0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000769636f6c6f677300000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1115000", gasUsed: "23000", confirmations: "3439670"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[231], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `icologs`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[231], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[231], balance: ( await web3.eth.getBalance( addressList[231], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `icologs` )", async function( ) {
		const txOriginal = {blockNumber: "4265831", timeStamp: "1505216936", hash: "0x8ef563229395af1b6509e26d1726c7e30fbc048bec3dfe53ae9b1df4006a657f", nonce: "9", blockHash: "0xf2b43ef669028da374b6debbd97c33d947f0657a1ca7d491f13fcec9f58c94cf", transactionIndex: "51", from: "0x875deda9a100690eb71c5df995db8f13b9646dcf", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "30000", gasPrice: "1000000000", isError: "1", txreceipt_status: "", input: "0x06faebbe0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000769636f6c6f677300000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1120457", gasUsed: "30000", confirmations: "3439524"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[231], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `icologs`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[231], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[231], balance: ( await web3.eth.getBalance( addressList[231], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `icolog` )", async function( ) {
		const txOriginal = {blockNumber: "4265869", timeStamp: "1505218060", hash: "0xf07d280933bf58421289df983fb61ebaa33539e5943bdff2b3b493bc069d4953", nonce: "10", blockHash: "0xfc629c8cf8b48662a3060669239a87beb415fb125f48aa5ed69e606a910bb6b2", transactionIndex: "31", from: "0x875deda9a100690eb71c5df995db8f13b9646dcf", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "89242", gasPrice: "1000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000669636f6c6f670000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1006993", gasUsed: "89242", confirmations: "3439486"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[231], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `icolog`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `icolog`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1505218060 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[231], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[231], balance: ( await web3.eth.getBalance( addressList[231], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `H3U5P0` )", async function( ) {
		const txOriginal = {blockNumber: "4265901", timeStamp: "1505218649", hash: "0x817835aa3bf6a39cab263ac5b9e6c01ef9dbe1393664430c95a44b53a034e0ac", nonce: "0", blockHash: "0xf8990d0334620235e8611f53af13a57e1f21dc5d426d79327f80bfe27f3cdd94", transactionIndex: "56", from: "0xc50952c16cbe77426d02aa1b4816fd11f656dc35", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000064833553550300000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2057938", gasUsed: "89242", confirmations: "3439454"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[232], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `H3U5P0`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `H3U5P0`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1505218649 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[232], balance: "27993899112886100" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[232], balance: ( await web3.eth.getBalance( addressList[232], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `W5BDRG` )", async function( ) {
		const txOriginal = {blockNumber: "4265982", timeStamp: "1505220421", hash: "0xae574379ce76fa3431db9d7ed9b51d0bdf19e00918921b7061cb82b379f1fc44", nonce: "1", blockHash: "0xa0c75fbdfc7bef32071da24a7634cc06f8f5bb75b1d9bcf35e3794e0058621e8", transactionIndex: "38", from: "0xaa47681c48e0340df17682e4cb083720dff07eb5", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "21947999998", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000065735424452470000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1412783", gasUsed: "89242", confirmations: "3439373"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[233], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `W5BDRG`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `W5BDRG`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1505220421 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[233], balance: "189765084584178436" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[233], balance: ( await web3.eth.getBalance( addressList[233], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `5AIOHA` )", async function( ) {
		const txOriginal = {blockNumber: "4266398", timeStamp: "1505230691", hash: "0xdff0176dd4093b8e64081e842916c250ddb880d0d4e87cbc6185af796b1943c5", nonce: "8", blockHash: "0xb9d0bbd3a47a45bf2f269544b34c44565bb3a4af9d97fc03e55136dfe64b8249", transactionIndex: "210", from: "0xff4ca9ff8474f4ac408bfc55219aa4a37857f4ab", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90242", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000063541494f48410000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6338922", gasUsed: "89242", confirmations: "3438957"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[234], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `5AIOHA`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `5AIOHA`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1505230691 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[234], balance: "25546551455920104" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[234], balance: ( await web3.eth.getBalance( addressList[234], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `QDKRRC` )", async function( ) {
		const txOriginal = {blockNumber: "4267444", timeStamp: "1505255592", hash: "0xa853e1d6f946355041b368d7816bf7e3718c2d39fb9b9af6f02678b18f23ffd4", nonce: "10", blockHash: "0x1d154a6a9a13b3342d32fcd9d33bf70744a3daee4883a850a24d34a50e59669b", transactionIndex: "116", from: "0x10cad80ca7afca7e66faa73dee13c18ae4bc5a7c", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90242", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000651444b5252430000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4736815", gasUsed: "89242", confirmations: "3437911"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[235], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `QDKRRC`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `QDKRRC`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1505255592 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[235], balance: "22570413000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[235], balance: ( await web3.eth.getBalance( addressList[235], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `X9JG30` )", async function( ) {
		const txOriginal = {blockNumber: "4268937", timeStamp: "1505292453", hash: "0x51a8b0584487d2304a9797e854a7b29fb6855a0b3bc9b38ab6db60052dc2811a", nonce: "1", blockHash: "0xedd259ae82e37ed15d82080a9a7e1eabb4628d6256ac106f1488eaf5c5518eab", transactionIndex: "77", from: "0x1b1f884ff9ec02ce46c86bf7fa62d037b46deefd", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "22463230501", isError: "0", txreceipt_status: "", input: "0x06faebbe0000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000658394a4733300000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3303812", gasUsed: "89242", confirmations: "3436418"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[236], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `X9JG30`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `X9JG30`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1505292453 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[236], balance: "19010885383629758" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[236], balance: ( await web3.eth.getBalance( addressList[236], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `RCQO8B` )", async function( ) {
		const txOriginal = {blockNumber: "4269554", timeStamp: "1505307175", hash: "0xe30330068817b84aa51a744cb1cb26a16ba2086bf392fe5c1f22a4f40a62bbb4", nonce: "1", blockHash: "0x269982c647e547ac49de50e2a4f2cc03b33cc54795f6d3b71d46ac2c972594a0", transactionIndex: "114", from: "0x28aebffcdc49e91e39d12dabfb6027219e7f8701", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "22463230501", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000065243514f38420000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3322318", gasUsed: "89242", confirmations: "3435801"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[237], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `RCQO8B`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `RCQO8B`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1505307175 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[237], balance: "3050482383629758" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[237], balance: ( await web3.eth.getBalance( addressList[237], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `ARTOX` )", async function( ) {
		const txOriginal = {blockNumber: "4269969", timeStamp: "1505317178", hash: "0xcad767eb321602b1c1276968a250864289be3c93a48b23dcad4b2f1f6bd2ce58", nonce: "0", blockHash: "0x252beb4138dcdf8c26fe8313cdea5bb3e1c55ad466f5c70da77eac25a2dce51d", transactionIndex: "64", from: "0x281e10476fce1d92f9d60e46b3d0793999b60729", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "89178", gasPrice: "18000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000054152544f58000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2210984", gasUsed: "89178", confirmations: "3435386"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[238], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `ARTOX`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `ARTOX`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1505317178 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[238], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[238], balance: ( await web3.eth.getBalance( addressList[238], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `haha` )", async function( ) {
		const txOriginal = {blockNumber: "4270205", timeStamp: "1505322805", hash: "0xc98edeb3530f12837eea79912665b09243e0cde8c87e7cd6dd489a31d145767b", nonce: "1", blockHash: "0x20105357fc0fbddd5aabacbb6d80ea4cb0dfe6f79f00d12e6b57d445065ff9c7", transactionIndex: "102", from: "0x00074e65c81a692996676f5eddb20b58e1475e0b", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "89114", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000046861686100000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3810260", gasUsed: "89114", confirmations: "3435150"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[239], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `haha`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `haha`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1505322805 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[239], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[239], balance: ( await web3.eth.getBalance( addressList[239], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `GRYPH` )", async function( ) {
		const txOriginal = {blockNumber: "4270272", timeStamp: "1505324487", hash: "0xd80f0757ebac53be1cdde5079f4517271bafe090f57e50206fcb2f69e903ce15", nonce: "1", blockHash: "0xdc51ebfb69c06f1d41be06339b489298841c9b815f254663b3d8d5e869828b7e", transactionIndex: "135", from: "0x50b0835737e92766478df4f215b364c650f9ba35", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "5000000000000000", gas: "89178", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000054752595048000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4665262", gasUsed: "89178", confirmations: "3435083"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[240], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `GRYPH`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[240], balance: "999432799777777777" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[240], balance: ( await web3.eth.getBalance( addressList[240], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `GRYPH` )", async function( ) {
		const txOriginal = {blockNumber: "4270324", timeStamp: "1505325849", hash: "0x5fb56c3cdee1e155dcfa3359963320e1c0e4ad9f6eed428a57a088dc7665fb11", nonce: "2", blockHash: "0x841be596cb3125056647519c2078fa99365694bcf4c87f3a4975ba56d338d707", transactionIndex: "97", from: "0x50b0835737e92766478df4f215b364c650f9ba35", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "89178", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000054752595048000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5934890", gasUsed: "89178", confirmations: "3435031"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[240], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `GRYPH`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `GRYPH`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1505325849 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[240], balance: "999432799777777777" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[240], balance: ( await web3.eth.getBalance( addressList[240], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `JT4OQ5` )", async function( ) {
		const txOriginal = {blockNumber: "4273338", timeStamp: "1505398840", hash: "0xcd9ce32b7eef8aebcaf628e9f075976dc81951b6c98552151204ab36f24a2ccb", nonce: "0", blockHash: "0xea1f3c7c108b3596bdd50fbf4dfe30816450713efc0b145c1751baf5c6de7472", transactionIndex: "136", from: "0x90c3fa29b8d9f558a2a590aa1c94f73e4fdfc459", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90242", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000064a54344f51350000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3760573", gasUsed: "89242", confirmations: "3432017"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[241], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `JT4OQ5`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `JT4OQ5`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1505398840 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[241], balance: "20462545000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[241], balance: ( await web3.eth.getBalance( addressList[241], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `4M9WXV` )", async function( ) {
		const txOriginal = {blockNumber: "4276666", timeStamp: "1505478457", hash: "0x01bbb25fc5ea927a95b94261d6779675407b63505f5050b56f4a9cc565a9ba10", nonce: "0", blockHash: "0x26b04da92a07bd64c6d6189119ebeeea07fb91b75893b0d3b1d2fff47228d4d4", transactionIndex: "241", from: "0xe177810cc3c5600ef18fd5fefccf72ad7d02ca57", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000006344d395758560000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5756170", gasUsed: "89242", confirmations: "3428689"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[242], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `4M9WXV`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `4M9WXV`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1505478457 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[242], balance: "154740000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[242], balance: ( await web3.eth.getBalance( addressList[242], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `6G8BXR` )", async function( ) {
		const txOriginal = {blockNumber: "4277793", timeStamp: "1505505773", hash: "0x5eb8b2530403754677d81b15de6aea2f2c361687104e3da83ca4df6cacd70ede", nonce: "1", blockHash: "0x28c30fb9d0804ddbb0ff0101a190b684e709172a7bbc976d2ca88f0e760871e2", transactionIndex: "80", from: "0xc93b0216ded2a55b22b5f8d5d52ab1d73bca132e", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90242", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000063647384258520000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2795002", gasUsed: "89242", confirmations: "3427562"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[243], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `6G8BXR`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `6G8BXR`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1505505773 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[243], balance: "84254540000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[243], balance: ( await web3.eth.getBalance( addressList[243], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `snegurka` )", async function( ) {
		const txOriginal = {blockNumber: "4280531", timeStamp: "1505571352", hash: "0x3308b74a90f5443ec918d6b530e861e802b81c76794e5ac32c9a436da0f591d0", nonce: "5", blockHash: "0x265a5f48942f3e7885c675b108be567553ea61a7e074a7688b079f8c76980803", transactionIndex: "116", from: "0xf509bce7a014ca82f9760bf89a475320a4af428a", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "300000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x06faebbe00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000008736e656775726b61000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5350820", gasUsed: "300000", confirmations: "3424824"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[244], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `snegurka`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[244], balance: "3148010000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[244], balance: ( await web3.eth.getBalance( addressList[244], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `C516PR` )", async function( ) {
		const txOriginal = {blockNumber: "4280731", timeStamp: "1505576495", hash: "0xd7d47309fea7a99da1031b71172afcd3f1901cf1cb6b91901738d51cc8710476", nonce: "1", blockHash: "0xc8ce9684a7e9bd10df5ac2c8ede2dcc9f0284e014fd07ad1b7d91b23d686e7a6", transactionIndex: "74", from: "0xb07a6c600d73b765da6ff1b7f29f13abbcc3d52d", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "31172369841", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000064335313650520000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3397152", gasUsed: "89242", confirmations: "3424624"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[245], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `C516PR`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `C516PR`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1505576495 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[245], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[245], balance: ( await web3.eth.getBalance( addressList[245], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `N25TGM` )", async function( ) {
		const txOriginal = {blockNumber: "4281077", timeStamp: "1505584774", hash: "0x1999a8352b07ad420c9ec06af64d622e594bda0578c8f726d257f91feb8c92d6", nonce: "0", blockHash: "0x44c80679c9c17b86d0cfa15b365526c24fc01f5acdb7eddf952b3823fb414be7", transactionIndex: "57", from: "0x8ea2116fbeac10333297dfd6e5367329aa71ef7c", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "23914135089", isError: "0", txreceipt_status: "", input: "0x06faebbe000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000064e323554474d0000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2681375", gasUsed: "89242", confirmations: "3424278"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[246], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `N25TGM`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `N25TGM`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1505584774 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[246], balance: "87865854756387478" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[246], balance: ( await web3.eth.getBalance( addressList[246], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: setPromoToPartner( `8J4GTP` )", async function( ) {
		const txOriginal = {blockNumber: "4281662", timeStamp: "1505598363", hash: "0xaa6b9cefd7352b87ce5edf3ffbe3f1b58a9fd572fd5c453c6324fbb20264c7f6", nonce: "1", blockHash: "0x5e2671ddd8f9ef3a23c204e5b1739f79a198ec9f9dc0af5789a4f3a8b67d753b", transactionIndex: "21", from: "0xfb46fb4acac9ba2d5c882817c2df047d32f628fe", to: "0xbe44459058383729be8247802d4314ea76ca9e5a", value: "0", gas: "90243", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0x06faebbe00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000006384a344754500000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1235296", gasUsed: "89242", confirmations: "3423693"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[247], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "code", value: `8J4GTP`}], name: "setPromoToPartner", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPromoToPartner(string)" ]( `8J4GTP`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1505598363 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[247], balance: "767877000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[247], balance: ( await web3.eth.getBalance( addressList[247], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
